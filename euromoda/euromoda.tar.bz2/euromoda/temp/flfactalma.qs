
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod
{
    //var calculoStockBloqueado_ = false;
	var codFamEstampado_, codFamCrudo_, codSubfamEstampado_, codSubfamCrudo_, codSubfamLaminas_, codFamTPPE_, codSubfamEstampadoGen_;
	var stocksPtes_, curReservaPteRx_;
	var idSesion_, rutasTejidoPrep_;
	var curMoviStockNoCI_;
    //var curMoviStock;
	var bloqueoHistoricoArticuloscli_;
	var curStockRes_;
	var enProcesaStocks_;
	var oMargenes_;
	var oCostes_;
	function euromoda(context)
	{
		prod(context);
	}
	function beforeCommit_articulos(curArticulo)
	{
		return this.ctx.euromoda_beforeCommit_articulos(curArticulo);
	}
	function controlIdArticulo(curArticulo)
	{
		return this.ctx.euromoda_controlIdArticulo(curArticulo);
	}
	function calculaReferencia(curArticulo)
	{
		return this.ctx.euromoda_calculaReferencia(curArticulo);
	}
	function calculaCodBarras(curArticulo)
	{
		return this.ctx.euromoda_calculaCodBarras(curArticulo);
	}
	function digitoControlEAN(valorSinDC)
	{
		return this.ctx.euromoda_digitoControlEAN(valorSinDC);
	}	
	function actualizarStockPteServir(idStock, codSubfamiliaTP)
	{
		return this.ctx.euromoda_actualizarStockPteServir(idStock, codSubfamiliaTP);
	}
	function marcaStockPte(idStock, tipoA, codSubfamiliaTP)
	{
		return this.ctx.euromoda_marcaStockPte(idStock, tipoA, codSubfamiliaTP);
	}
	function crearStock(codAlmacen, aDatosArt)
	{
		return this.ctx.euromoda_crearStock(codAlmacen, aDatosArt);
	}
	function beforeCommit_stocks(curStock)
	{
		return this.ctx.euromoda_beforeCommit_stocks(curStock);
	}
	function controlAltaStock(curStock)
	{
		return this.ctx.euromoda_controlAltaStock(curStock);
	}
	function afterCommit_movistock(curMS)
	{
		return this.ctx.euromoda_afterCommit_movistock(curMS);
	}
	function controlReservaLoteMovAlbaranCli(curMS)
	{
		return this.ctx.euromoda_controlReservaLoteMovAlbaranCli(curMS);
	}
	function beforeCommit_movistock(curMS)
	{
		return this.ctx.euromoda_beforeCommit_movistock(curMS);
	}
	function controlPartidas(curMS)
	{
		return this.ctx.euromoda_controlPartidas(curMS);
	}
	function actualizarMetrosPartida(codLote)
	{
		return this.ctx.euromoda_actualizarMetrosPartida(codLote);
	}
	function dameDatosStockLinea(curLinea, curArticuloComp)
	{
		return this.ctx.euromoda_dameDatosStockLinea(curLinea, curArticuloComp);
	}
	function creaRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp)
	{
		return this.ctx.euromoda_creaRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp);
	}
	function datosArticulo(cursor, codLote)
	{
		return this.ctx.euromoda_datosArticulo(cursor, codLote);
	}
	function crearLote(datosArt, cantidad, idLinea, prefijoLote, codFormato)
	{
		return this.ctx.euromoda_crearLote(datosArt, cantidad, idLinea, prefijoLote, codFormato);
	}
	function albaranaDatosMoviStock(curMSOrigen, curLA)
	{
		return this.ctx.euromoda_albaranaDatosMoviStock(curMSOrigen, curLA);
	}
	function dameFamEstampado()
	{
		return this.ctx.euromoda_dameFamEstampado();
	}
	function dameFamTPPE()
	{
		return this.ctx.euromoda_dameFamTPPE();
	}
	function dameSubfamEstampadoGen()
	{
		return this.ctx.euromoda_dameSubfamEstampadoGen();
	}
	function dameSubfamEstampado()
	{
		return this.ctx.euromoda_dameSubfamEstampado();
	}
	function dameSubfamLaminas()
	{
		return this.ctx.euromoda_dameSubfamLaminas();
	}
	function esFamiliaEstampado(codFamilia)
	{
		return this.ctx.euromoda_esFamiliaEstampado(codFamilia);
	}
	function esFamiliaTPPE(codFamilia)
	{
		return this.ctx.euromoda_esFamiliaTPPE(codFamilia);
	}
	function esSubfamEstampadoGen(codSubfamilia)
	{
		return this.ctx.euromoda_esSubfamEstampadoGen(codSubfamilia);
	}
	function esSubfamiliaEstampado(codSubfamilia)
	{
		return this.ctx.euromoda_esSubfamiliaEstampado(codSubfamilia);
	}
	function dameFamCrudo()
	{
		return this.ctx.euromoda_dameFamCrudo();
	}
	function dameSubfamCrudo()
	{
		return this.ctx.euromoda_dameSubfamCrudo();
	}
	function esFamiliaCrudo(codFamilia)
	{
		return this.ctx.euromoda_esFamiliaCrudo(codFamilia);
	}
	function esSubfamiliaCrudo(codSubfamilia)
	{
		return this.ctx.euromoda_esSubfamiliaCrudo(codSubfamilia);
	}
	
	function generarEstructura(curLinea)
	{
		return this.ctx.euromoda_generarEstructura(curLinea);
	}
	function asignarMoviStockSinLote(codLote)
	{
		return this.ctx.euromoda_asignarMoviStockSinLote(codLote);
	}
	function generaConsumosLineaPedidoCli(curLinea)
	{
		return this.ctx.euromoda_generaConsumosLineaPedidoCli(curLinea);
	}
	function borrarLote(codLote, curMS)
	{
		return this.ctx.euromoda_borrarLote(codLote, curMS);
	}
	function albaranarLineaPedProv(curLA)
	{
		return this.ctx.euromoda_albaranarLineaPedProv(curLA);
	}
	function desalbaranarLineaPedProv(curLA)
	{
		return this.ctx.euromoda_desalbaranarLineaPedProv(curLA);
	}
	function generarMoviStock(curLinea, codLote, cantidad, curArticuloComp, idProceso)
	{
		return this.ctx.euromoda_generarMoviStock(curLinea, codLote, cantidad, curArticuloComp, idProceso);
	}
	function revisarComponente(curAC, idLinea, codLote)
	{
		return this.ctx.euromoda_revisarComponente(curAC, idLinea, codLote);
	}
	function afterCommit_lotesstock(curLote)
	{
		return this.ctx.euromoda_afterCommit_lotesstock(curLote);
	}
	function controlCantidadLoteProducto(curLote)
	{
		return this.ctx.euromoda_controlCantidadLoteProducto(curLote);
	}
	function controlUbiacionPieza(curLote)
	{
		return this.ctx.euromoda_controlUbiacionPieza(curLote);
	}
	function actualizaUbicacionStock(referencia, codAlmacen, ubicacion)
	{
		return this.ctx.euromoda_actualizaUbicacionStock(referencia, codAlmacen, ubicacion);
	}
	function controlOrdenLote(curLote)
	{
		return this.ctx.euromoda_controlOrdenLote(curLote);
	}
	function controlStockLote(curLote)
	{
		return this.ctx.euromoda_controlStockLote(curLote);
	}
	function actualizaOrdenLote(codOrden)
	{
		return this.ctx.euromoda_actualizaOrdenLote(codOrden);
	}
	function datosProcesoArticulo(referencia)
	{
		return this.ctx.euromoda_datosProcesoArticulo(referencia);
	}
	function generarLoteStock(curLinea, cantidad, curArticuloComp, idProceso)
	{
		return this.ctx.euromoda_generarLoteStock(curLinea, cantidad, curArticuloComp, idProceso);
	}
	function controlStockPedidosMarcoCli(curLP)
	{
		return this.ctx.euromoda_controlStockPedidosMarcoCli(curLP);
	}
	function controlStockPrevisto(curLinea, codAlmacen)
	{
		return this.ctx.euromoda_controlStockPrevisto(curLinea, codAlmacen);
	}
	function actualizaStockPrevisto(referencia, codAlmacen)
	{
		return this.ctx.euromoda_actualizaStockPrevisto(referencia, codAlmacen);
	}
	function cambiarCosteMedio(referencia)
	{
		return this.ctx.euromoda_cambiarCosteMedio(referencia);
	}
	function datosRevisarEstadoLote(curLote)
	{
		return this.ctx.euromoda_datosRevisarEstadoLote(curLote);
	}
	function crearMovRegularizacionLote(codLote, cantidad)
	{
		return this.ctx.euromoda_crearMovRegularizacionLote(codLote, cantidad);
	}
	function preguntarSiCrearLote(codLote)
	{
		return this.ctx.euromoda_preguntarSiCrearLote(codLote);
	}
	//   function revisarStocksComponentesLote(codLote)
	//   {
	//     return this.ctx.euromoda_revisarStocksComponentesLote(codLote);
	//   }
	function generarMoviStockComponentes(aDatosArt, idProceso)
	{
		return this.ctx.euromoda_generarMoviStockComponentes(aDatosArt, idProceso);
	}
	function crearComposicion(curLoteStock, curComponente, refProceso, idProceso, primeraLlamada)
	{
		return this.ctx.euromoda_crearComposicion(curLoteStock, curComponente, refProceso, idProceso, primeraLlamada);
	}
	function dameEmbalajeArticulo(referencia, codCliente, mostrarSMS)
	{
		return this.ctx.euromoda_dameEmbalajeArticulo(referencia, codCliente, mostrarSMS);
	}
	function acumulaLotesPendientes(curLote)
	{
		return this.ctx.euromoda_acumulaLotesPendientes(curLote);
	}
	function fundeLotes(codLoteStock, codLotePed)
	{
		return this.ctx.euromoda_fundeLotes(codLoteStock, codLotePed);
	}
	function albaranarLineaPedCli(curLA)
	{
		return this.ctx.euromoda_albaranarLineaPedCli(curLA);
	}
	function establecerCantidad(curLinea)
	{
		return this.ctx.euromoda_establecerCantidad(curLinea);
	}
	function borrarMoviStock(curLinea)
	{
		return this.ctx.euromoda_borrarMoviStock(curLinea);
	}
	function actualizarStocksMoviStock(curMS)
	{
		return this.ctx.euromoda_actualizarStocksMoviStock(curMS);
	}
	function actualizarStockPrevisto(idStock)
	{
		return this.ctx.euromoda_actualizarStockPrevisto(idStock);
	}
	function revisarReservasStock(idStock, nivelComp, nivelTejido, codSubfamiliaTP) 
	{
		return this.ctx.euromoda_revisarReservasStock(idStock, nivelComp, nivelTejido, codSubfamiliaTP);
	}
	function calculaReservasStock(curStock)
	{
		return this.ctx.euromoda_calculaReservasStock(curStock);
	}
	/*
	function creaReservaPteRx(idMovReserva, qPteRx, cantidad)
	{
		return this.ctx.euromoda_creaReservaPteRx(idMovReserva, qPteRx, cantidad);
	}*/
	function compruebaLoteAFaltas(curMS)
	{
		return this.ctx.euromoda_compruebaLoteAFaltas(curMS);
	}
	function creaLoteAFaltas(curMS)
	{
		return this.ctx.euromoda_creaLoteAFaltas(curMS);
	}
	function eliminaLoteAFaltas(codLote)
	{
		return this.ctx.euromoda_eliminaLoteAFaltas(codLote);
	}
	function actualizarStockPteRecibir(idStock, codSubfamiliaTP)
	{
		return this.ctx.euromoda_actualizarStockPteRecibir(idStock, codSubfamiliaTP);
	}
	function actualizarStockPteRecibirT0(idStock, codSubfamiliaTP)
	{
		return this.ctx.euromoda_actualizarStockPteRecibirT0(idStock, codSubfamiliaTP);
	}
	function actualizarStock(idStock, codSubfamiliaTP)
	{
		return this.ctx.euromoda_actualizarStock(idStock, codSubfamiliaTP);
	}
	function actualizarStockT0(idStock, codSubfamiliaTP)
	{
		return this.ctx.euromoda_actualizarStockT0(idStock, codSubfamiliaTP);
	}
	function borraReservasMSAFaltas(curMS, forzar)
	{
		return this.ctx.euromoda_borraReservasMSAFaltas(curMS, forzar);
	}
	function creaReservasMSAFaltas(curMS)
	{
		return this.ctx.euromoda_creaReservasMSAFaltas(curMS);
	}
	function controlPrevision(curMS)
	{
		return this.ctx.euromoda_controlPrevision(curMS);
	}
	function datosDesalbaranarLineaPedProv(curLA)
	{
		return this.ctx.euromoda_datosDesalbaranarLineaPedProv(curLA);
	}
	function esReferenciaXPartidas(referencia)
	{
		return this.ctx.euromoda_esReferenciaXPartidas(referencia);
	}
	function esReferenciaXPiezas(referencia)
	{
		return this.ctx.euromoda_esReferenciaXPiezas(referencia);
	}
	function esReferenciaTPPE(referencia)
	{
		return this.ctx.euromoda_esReferenciaTPPE(referencia);
	}
	function esReferenciaEstampadoGen(referencia)
	{
		return this.ctx.euromoda_esReferenciaEstampadoGen(referencia);
	}
	function dameIdStockEM(codAlmacen, referencia)
	{
		return this.ctx.euromoda_dameIdStockEM(codAlmacen, referencia);
	}
	function controlArticuloVariable(curAC)
	{
		return this.ctx.euromoda_controlArticuloVariable(curAC);
	}
	function controlRepeticionArticulo(curA)
	{
		return this.ctx.euromoda_controlRepeticionArticulo(curA);
	}
	function controlColorGit(curArticulo)
	{
		return this.ctx.euromoda_controlColorGit(curArticulo);
	}
	function afterCommit_em_traspasosstock(curTS)
	{
		return this.ctx.euromoda_afterCommit_em_traspasosstock(curTS);
	}
	function afterCommit_em_dibujos(curD)
	{
		return this.ctx.euromoda_afterCommit_em_dibujos(curD);
	}
	function controlDesDibujo(curD)
	{
		return this.ctx.euromoda_controlDesDibujo(curD);
	}
	function beforeCommit_em_traspasosstock(curTS)
	{
		return this.ctx.euromoda_beforeCommit_em_traspasosstock(curTS);
	}
	function controlStockTraspasoStock(curTS)
	{
		return this.ctx.euromoda_controlStockTraspasoStock(curTS);
	}
	function controlStockBCTraspasoStock(curTS)
	{
		return this.ctx.euromoda_controlStockBCTraspasoStock(curTS);
	}
	function borrarEstructura(curLinea)
	{
		return this.ctx.euromoda_borrarEstructura(curLinea);
	}
	function consistenciaLinea(curLinea)
	{
		return this.ctx.euromoda_consistenciaLinea(curLinea);
	}
	function datosEvolStock(qryArticulos, fechaDesde, avisar)
	{
		return this.ctx.euromoda_datosEvolStock(qryArticulos, fechaDesde, avisar);
	}
	function planificarPedStock(arrayEvolStock, plazoPedido)
	{
		return this.ctx.euromoda_planificarPedStock(arrayEvolStock, plazoPedido);
	}
	function esTrazable(referencia)
	{
		return this.ctx.euromoda_esTrazable(referencia);
	}
	function controlStockAlbaranesProv(curLA)
	{
		return this.ctx.euromoda_controlStockAlbaranesProv(curLA);
	}
	function controlStockAlbaranesCli(curLA)
	{
		return this.ctx.euromoda_controlStockAlbaranesCli(curLA);
	}
	function controlStockAlbCliTrazable(curLA)
	{
		return this.ctx.euromoda_controlStockAlbCliTrazable(curLA);
	}
	function controlStockAlbProvEstampado(curLA)
	{
		return this.ctx.euromoda_controlStockAlbProvEstampado(curLA);
	}
	function controlStockAlbProvCrudo(curLA)
	{
		return this.ctx.euromoda_controlStockAlbProvCrudo(curLA);
	}
	function datosStockLineaCambian(curLinea)
	{
		return this.ctx.euromoda_datosStockLineaCambian(curLinea);
	}
	function generaConsumosProducto(referencia, cantidad, idLineaPedido, codLote, codAlmacen, soloTejido, hechos)
	{
		return this.ctx.euromoda_generaConsumosProducto(referencia, cantidad, idLineaPedido, codLote, codAlmacen, soloTejido, hechos);
	}
	function activaTransactionSignals()
	{
		return this.ctx.euromoda_activaTransactionSignals();
	}
	function processEndTran(obj)
	{
		return this.ctx.euromoda_processEndTran(obj);
	}
	function processRollbackTran()
	{
		return this.ctx.euromoda_processRollbackTran();
	}
	function procesaStocks(usuario) {
		return this.ctx.euromoda_procesaStocks(usuario);
	}
	function rpcDatosPieza(args)
	{
		return this.ctx.euromoda_rpcDatosPieza(args);
	}
	function rpcRestaMetrosPieza(args)
	{
		return this.ctx.euromoda_rpcRestaMetrosPieza(args);
	}
	function trRestaMetrosPieza(oParam)
	{
		return this.ctx.euromoda_trRestaMetrosPieza(oParam);
	}
	function dameDatosPiezaRPC(codLote)
	{
		return this.ctx.euromoda_dameDatosPiezaRPC(codLote);
	}
	function controlStockFisicoArticulos(curStock)
	{
		return this.ctx.euromoda_controlStockFisicoArticulos(curStock);
	}
	function controlIdSincroStock(curStock)
	{
		return this.ctx.euromoda_controlIdSincroStock(curStock);
	}
	function controlIdSincroRegStock(curL)
	{
		return this.ctx.euromoda_controlIdSincroRegStock(curL);
	}
	function estadosMovBorrablesComp()
	{
		return this.ctx.euromoda_estadosMovBorrablesComp();
	}
	function controlStockPedidosProv(curLP)
	{
		return this.ctx.euromoda_controlStockPedidosProv(curLP);
	}
	function controlStockPedidosProvXPartidas(curLP)
	{
		return this.ctx.euromoda_controlStockPedidosProvXPartidas(curLP);
	}
	function recalcularMovPartidasPtesPP(curLP)
	{
		return this.ctx.euromoda_recalcularMovPartidasPtesPP(curLP);
	}
	function controlLineaPedidoProvMerma(curMS)
	{
		return this.ctx.euromoda_controlLineaPedidoProvMerma(curMS);
	}
	function dameSesion()
	{
		return this.ctx.euromoda_dameSesion();
	}
	function distribuyeStockPteClientes(idStock, codCliente:optional)
	{
		return this.ctx.euromoda_distribuyeStockPteClientes(idStock, codCliente);
	}
	function afterCommit_articulos(curArticulo)
	{
		return this.ctx.euromoda_afterCommit_articulos(curArticulo);
	}
	function controlCambioDatosArticulo(curA)
	{
		return this.ctx.euromoda_controlCambioDatosArticulo(curA);
	}
	function dameSiguienteTejidoPrep(codSubfamilia, idStock)
	{
		return this.ctx.euromoda_dameSiguienteTejidoPrep(codSubfamilia, idStock);
	}
	function cargaRutasTejidoPrep()
	{
		return this.ctx.euromoda_cargaRutasTejidoPrep();
	}
	function controlACTejidoPrep(curMS)
	{
		return this.ctx.euromoda_controlACTejidoPrep(curMS);
	}
	function controlBCTejidoPrep(curMS)
	{
		return this.ctx.euromoda_controlBCTejidoPrep(curMS);
	}
	function creaMovTejidoPrep(curMS)
	{
		return this.ctx.euromoda_creaMovTejidoPrep(curMS);
	}
	function borraMovTejidoPrep(curMS)
	{
		return this.ctx.euromoda_borraMovTejidoPrep(curMS);
	}
	function afterCommit_subfamilias(curS)
	{
		return this.ctx.euromoda_afterCommit_subfamilias(curS);
	}
	function recargaRutasTejidoPrep()
	{
		return this.ctx.euromoda_recargaRutasTejidoPrep();
	}
	function esProcesoBatch()
	{
		return this.ctx.euromoda_esProcesoBatch();
	}
	function revisaReservasMSAFaltas(curMS,oStockMod)
	{
		return this.ctx.euromoda_revisaReservasMSAFaltas(curMS,oStockMod);
	}
	function calculaReservasStockComp(idStock, nivelComp)
	{
		return this.ctx.euromoda_calculaReservasStockComp(idStock, nivelComp);
	}
	function afterCommit_em_reservaspterx(curR) {
		return this.ctx.euromoda_afterCommit_em_reservaspterx(curR);
	}
	function totalizaReservasPteRx(curR) {
		return this.ctx.euromoda_totalizaReservasPteRx(curR);
	}
	function revisaReservasLoteProd(codLote) {
		return this.ctx.euromoda_revisaReservasLoteProd(codLote);
	}
	function revisaReservasPedidoProd(idLineaPedido, idArticuloComp) {
		return this.ctx.euromoda_revisaReservasPedidoProd(idLineaPedido, idArticuloComp);
	}
	function borraReservasQuery(q) {
		return this.ctx.euromoda_borraReservasQuery(q);
	}
	function calculaReservasArray(qNecesaria, qDisponible) {
		return this.ctx.euromoda_calculaReservasArray(qNecesaria, qDisponible);
	}
	function creaReservaStock(idMovNec, idMovDis, cantidad, idRLP) {
		return this.ctx.euromoda_creaReservaStock(idMovNec, idMovDis, cantidad, idRLP);
	}
   function afterCommit_em_articuloscli(curArtCli) {
		return this.ctx.euromoda_afterCommit_em_articuloscli(curArtCli);
	} 
	function actualizaHistoricoArtCli(curArtCli) {
		return this.ctx.euromoda_actualizaHistoricoArtCli(curArtCli);
	}
	function insertaHistoricoArtCli(curArtCli) {
		return this.ctx.euromoda_insertaHistoricoArtCli(curArtCli);
	}
	function datosArticulosCliCambian(curArtCli) {
		return this.ctx.euromoda_datosArticulosCliCambian(curArtCli);
	}
	function eliminaHistoricoArtCli(curArtCli) {
		return this.ctx.euromoda_eliminaHistoricoArtCli(curArtCli);
	}
	function afterCommit_em_articulosclihis(curArtCliHis) {
		return this.ctx.euromoda_afterCommit_em_articulosclihis(curArtCliHis);
	}
	function actualizaArticulosCli(idArticulosCli, idPrimerRegistroHis) {
		return this.ctx.euromoda_actualizaArticulosCli(idArticulosCli, idPrimerRegistroHis);
	}
	function idPrimerRegistro(idArticulosCli) {
		return this.ctx.euromoda_idPrimerRegistro(idArticulosCli);
	}
	function controlCabeceraArticuosCli(curArtCliHis) {
		return this.ctx.euromoda_controlCabeceraArticuosCli(curArtCliHis);
	}
	function controlRegStock(curLRS) {
		return this.ctx.euromoda_controlRegStock(curLRS);
	}
	function reservasConsumoLineaPedido(idLineaPedido) {
		return this.ctx.euromoda_reservasConsumoLineaPedido(idLineaPedido);
	}
	function reservasConsumoLote(codLote) {
		return this.ctx.euromoda_reservasConsumoLote(codLote);
	}
	function borraReservasPRLote(codLote) {
		return this.ctx.euromoda_borraReservasPRLote(codLote);
	}
	function reservasConsumoEstampacion(idLineaOrdenEst) {
		return this.ctx.euromoda_reservasConsumoEstampacion(idLineaOrdenEst);
	}
	function calculaReservasStockDerivadas(idStock, nivelComp, nivelTejido, codSubfamiliaTP) {
	    return this.ctx.euromoda_calculaReservasStockDerivadas(idStock, nivelComp, nivelTejido, codSubfamiliaTP);
	}
	function calculaReservasStockTP(idStock, codSubfamiliaTP) {
	    return this.ctx.euromoda_calculaReservasStockTP(idStock, codSubfamiliaTP);
	}
	function abreCursorStock(idStock) {
	    return this.ctx.euromoda_abreCursorStock(idStock);
	}
	function totalizaReservasStock(curStock, nivelComp, nivelTejido, codSubfamiliaTP) {
	    return this.ctx.euromoda_totalizaReservasStock(curStock, nivelComp, nivelTejido, codSubfamiliaTP);
	}
	function delMovTejidoPrepRecursivo1(idMovPadre) {
	    return this.ctx.euromoda_delMovTejidoPrepRecursivo1(idMovPadre);
	}
	function delMovTejidoPrepRecursivoN(idMovTP) {
	    return this.ctx.euromoda_delMovTejidoPrepRecursivoN(idMovTP);
	}	
	function beforeCommit_em_lineasbajapiezasmas(curLB) {
		return this.ctx.euromoda_beforeCommit_em_lineasbajapiezasmas(curLB)
	}
	function controlBCStockLBPiezasMas(curLB) {
		return this.ctx.euromoda_controlBCStockLBPiezasMas(curLB);
	}
	function borraMovsLBPiezasMas(curLB) {
		return this.ctx.euromoda_borraMovsLBPiezasMas(curLB);
	}
	function afterCommit_em_lineasbajapiezasmas(curLB) {
		return this.ctx.euromoda_afterCommit_em_lineasbajapiezasmas(curLB)
	}
	function datosStockLBCambian(curLB) {
		return this.ctx.euromoda_datosStockLBCambian(curLB);
	}
	function generaMovsLBPiezasMas(curLB) {
		return this.ctx.euromoda_generaMovsLBPiezasMas(curLB);
	}
	function controlStockLBPiezasMas(curLB) {
		return this.ctx.euromoda_controlStockLBPiezasMas(curLB);
	}
	function borraReservasPedidoProd(idLineaPedido) {
		return this.ctx.euromoda_borraReservasPedidoProd(idLineaPedido);
	}
	function borraReservasLoteProd(codLote) {
		return this.ctx.euromoda_borraReservasLoteProd(codLote);
	}
	function creaReservasPedidoProd(idLineaPedido, codLote, cantidad, idRLP) {
		return this.ctx.euromoda_creaReservasPedidoProd(idLineaPedido, codLote, cantidad, idRLP);
	}
	function datosRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp) {
		return this.ctx.euromoda_datosRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp);
	}
	function validaReservaMovistock(curMS) {
		return this.ctx.euromoda_validaReservaMovistock(curMS);
	}
	function esPartidaXTramos(codPartida)
	{
		return this.ctx.euromoda_esPartidaXTramos(codPartida);
	}
	function dameReferenciaAnverso(producto, referencia, idArtComp)
	{
		return this.ctx.euromoda_dameReferenciaAnverso(producto, referencia, idArtComp);
	}
	function controlAlmacenLoteAlbCli(curMS) {
		return this.ctx.euromoda_controlAlmacenLoteAlbCli(curMS);
	}
	function asignaColorUnico(curD) {
		return this.ctx.euromoda_asignaColorUnico(curD);
	}
	function beforeCommit_em_plantillasaltamasivacompleta(curPA) {
		return this.ctx.euromoda_beforeCommit_em_plantillasaltamasivacompleta(curPA);
	}
	function afterCommit_em_plantillasaltamasivacompleta(curPA) {
		return this.ctx.euromoda_afterCommit_em_plantillasaltamasivacompleta(curPA);
	}
	function esSubfamiliaLaminas(codSubfamilia) {
		return this.ctx.euromoda_esSubfamiliaLaminas(codSubfamilia);
	}
	function afterCommit_em_valoresmercado(curVM) {
		return this.ctx.euromoda_afterCommit_em_valoresmercado(curVM);
	}
	function actualizarDatosVM(curVM) {
		return this.ctx.euromoda_actualizarDatosVM(curVM);
	}
	function dameDatosVM(curVM) {
		return this.ctx.euromoda_dameDatosVM(curVM);
	}		
	function actualizarDatosUltCompra(referencia) {
		return this.ctx.euromoda_actualizarDatosUltCompra(referencia);
	}
	function actualizarFechaUltVenta(referencia) {
		return this.ctx.euromoda_actualizarFechaUltVenta(referencia);
	}	
	function dameUltimoCoste(referencia) {
		return this.ctx.euromoda_dameUltimoCoste(referencia);
	}
	function beforeCommit_em_sustcompocol(curS) {
		return this.ctx.euromoda_beforeCommit_em_sustcompocol(curS);
	}
	function beforeCommit_em_valoresmercado(curVM) {
		return this.ctx.euromoda_beforeCommit_em_valoresmercado(curVM);
	}
	function beforeCommit_lotesstock(curLote) {
		return this.ctx.euromoda_beforeCommit_lotesstock(curLote);
	}
	function borraReservasLote(curLote) {
		return this.ctx.euromoda_borraReservasLote(curLote);
	}
	function beforeCommit_em_bajapiezasmas(curB) {
		return this.ctx.euromoda_beforeCommit_em_bajapiezasmas(curB);
	}
	function actualizarDatosUltCompraAlm(idStock) {
		return this.ctx.euromoda_actualizarDatosUltCompraAlm(idStock);
	}
	function actualizarFechaUltVentaAlm(idStock) {
		return this.ctx.euromoda_actualizarFechaUltVentaAlm(idStock);
	}
	function controlDatosModCosteProd(curA) {
		return this.ctx.euromoda_controlDatosModCosteProd(curA);
	}
	function hayCambioCosteProd(curA) {
		return this.ctx.euromoda_hayCambioCosteProd(curA);
	}
	function hayCambioMargenProd(curA) {
		return this.ctx.euromoda_hayCambioMargenProd(curA);
	}
	function beforeCommit_familias(curF) {
		return this.ctx.euromoda_beforeCommit_familias(curF);
	}
	function beforeCommit_subfamilias(curSF) {
		return this.ctx.euromoda_beforeCommit_subfamilias(curSF);
	}
	function beforeCommit_em_tamanossubfam(curTSF) {
		return this.ctx.euromoda_beforeCommit_em_tamanossubfam(curTSF);
	}
	function beforeCommit_em_plantillasprod(curPP) {
		return this.ctx.euromoda_beforeCommit_em_plantillasprod(curPP);
	}
	function beforeCommit_inventarios(curInv) {
		return this.ctx.euromoda_beforeCommit_inventarios(curInv);
	}
	function beforeCommit_reglotestock(curRlt) {
		return this.ctx.euromoda_beforeCommit_reglotestock(curRlt);
	}
	function beforeCommit_lineasregstocks(curLrls) {
		return this.ctx.euromoda_beforeCommit_lineasregstocks(curLrls);
	}
	function afterCommit_lineasregstocks(curLRS)  {
		return this.ctx.euromoda_afterCommit_lineasregstocks(curLRS);
	}
	function pedidoAlmDep(curMS) {
		return this.ctx.euromoda_pedidoAlmDep(curMS);
	}	
	function estructuraDepositoAlbaranCli(curLA) {
    	return this.ctx.euromoda_estructuraDepositoAlbaranCli(curLA);
    }
    function datosDescontarProducto(curLinea, aDatosStockLinea, curArticuloComp) {
    	return this.ctx.euromoda_datosDescontarProducto(curLinea,aDatosStockLinea, curArticuloComp);
    }
    function creaReservasPedidoProdComp(oParam) {
    	return this.ctx.euromoda_creaReservasPedidoProdComp(oParam);
	}
    function beforeCommit_em_altamasivasubfam(curAMS) {
        return this.ctx.euromoda_beforeCommit_em_altamasivasubfam(curAMS);
    }
    function controlBorradoAltaMasSubFam(curAMS) {
        return this.ctx.euromoda_controlBorradoAltaMasSubFam(curAMS);
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends pubMedidas
{
	function pubEuromoda(context)
	{
		pubMedidas(context);
	}
	function pub_dameFamEstampado()
	{
		return this.dameFamEstampado();
	}
	function pub_dameSubfamEstampado()
	{
		return this.dameSubfamEstampado();
	}
	function pub_dameSubfamLaminas()
	{
		return this.dameSubfamLaminas();
	}
	function pub_esFamiliaEstampado(codFamilia)
	{
		return this.esFamiliaEstampado(codFamilia);
	}
	function pub_esFamiliaTPPE(codFamilia)
	{
		return this.esFamiliaTPPE(codFamilia);
	}
	function pub_esSubfamEstampadoGen(codSubfamilia)
	{
		return this.esSubfamEstampadoGen(codSubfamilia);
	}
	function pub_esSubfamiliaEstampado(codSubfamilia)
	{
		return this.esSubfamiliaEstampado(codSubfamilia);
	}
	function pub_dameFamCrudo()
	{
		return this.dameFamCrudo();
	}
	function pub_dameSubfamCrudo()
	{
		return this.dameSubfamCrudo();
	}
	function pub_esFamiliaCrudo(codFamilia)
	{
		return this.esFamiliaCrudo(codFamilia);
	}
	function pub_esSubfamiliaCrudo(codFamilia)
	{
		return this.esSubfamiliaCrudo(codFamilia);
	}
	function pub_controlStockPedidosMarcoCli(curLP)
	{
		return this.controlStockPedidosMarcoCli(curLP);
	}
	//   function pub_revisarStocksComponentesLote(codLote) {
	//     return this.revisarStocksComponentesLote(codLote);
	//   }
	function pub_acumulaLotesPendientes(curLote)
	{
		return this.acumulaLotesPendientes(curLote);
	}
	function pub_calculaReservasStock(curStock)
	{
		return this.calculaReservasStock(curStock);
	}
	function pub_dameEmbalajeArticulo(referencia, codCliente, mostrarSMS)
	{
		return this.dameEmbalajeArticulo(referencia, codCliente, mostrarSMS);
	}
	function pub_esReferenciaXPartidas(referencia)
	{
		return this.esReferenciaXPartidas(referencia);
	}
	function pub_esReferenciaXPiezas(referencia)
	{
		return this.esReferenciaXPiezas(referencia);
	}
	function pub_esReferenciaTPPE(referencia)
	{
		return this.esReferenciaTPPE(referencia);
	}
	function pub_esReferenciaEstampadoGen(referencia)
	{
		return this.esReferenciaEstampadoGen(referencia);
	}
	function pub_generaConsumosProducto(referencia, cantidad, idLineaPedido, codLote, codAlmacen, soloTejido)
	{
		return this.generaConsumosProducto(referencia, cantidad, idLineaPedido, codLote, codAlmacen, soloTejido);
	}
	function pub_generaConsumosLineaPedidoCli(curLinea)
	{
		return this.generaConsumosLineaPedidoCli(curLinea);
	}
	function pub_rpcDatosPieza(args)
	{
		return this.rpcDatosPieza(args);
	}
	function pub_rpcRestaMetrosPieza(args)
	{
		return this.rpcRestaMetrosPieza(args);
	}
	function pub_dameSesion()
	{
		return this.dameSesion();
	}
	function pub_distribuyeStockPteClientes(idStock, codCliente:optional)
	{
		return this.distribuyeStockPteClientes(idStock, codCliente);
	}/**
	function pub_procesaStocks(usuario) {
		return this.procesaStocks(usuario);
	}*/
	function pub_actualizaOrdenLote(codOrden)
	{
		return this.actualizaOrdenLote(codOrden);
	}
	function pub_revisarReservasStock(idStock)
	{
		return this.revisarReservasStock(idStock);
	}
	function pub_revisaReservasLoteProd(codLote)
	{
		return this.revisaReservasLoteProd(codLote);
	}
	function pub_revisaReservasMSAFaltas(curMS,oStockMod)
	{
		return this.revisaReservasMSAFaltas(curMS,oStockMod);
	}
	function pub_reservasConsumoLote(codLote) 
	{
		return this.reservasConsumoLote(codLote);
	}
	function pub_reservasConsumoEstampacion(idLineaOrdenEst) 
	{
		return this.reservasConsumoEstampacion(idLineaOrdenEst);
	}
	function pub_esPartidaXTramos(codPartida) {
		return this.esPartidaXTramos(codPartida);
	}
	function pub_crearLote(datosArt, cantidad, idLinea, prefijoLote, codFormato) {
		return this.crearLote(datosArt, cantidad, idLinea, prefijoLote, codFormato);
	}
	function pub_esSubfamiliaLaminas(codSubfamilia)
	{
		return this.esSubfamiliaLaminas(codSubfamilia);
	}
	function pub_actualizarDatosUltCompra(referencia) {
		return this.actualizarDatosUltCompra(referencia);
	}
	function pub_actualizarFechaUltVenta(referencia) {
		return this.actualizarFechaUltVenta(referencia);
	}	
	function pub_actualizarDatosUltCompraAlm(idStock) {
		return this.actualizarDatosUltCompraAlm(idStock);
	}
	function pub_actualizarFechaUltVentaAlm(idStock) {
		return this.actualizarFechaUltVentaAlm(idStock);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////

function euromoda_afterCommit_em_reservaspterx(curR)
{
	var _i = this.iface;
	if (!_i.totalizaReservasPteRx(curR)) {
		return false;
	}
	
	return true;
}

function euromoda_totalizaReservasPteRx(curR)
{
	//debug("Totalizando con mov reserva = " + curR.valueBuffer("idmovreserva") + " Mov Pte Rx " + curR.valueBuffer("idmovpterx"));
	var _i = this.iface;
	//if (!_i.curMoviStock) {
		//_i.curMoviStock = new FLSqlCursor("movistock"); // Se usa este cursor porque solo se modifica el campo en reserva, que no debe forzar un rec�lculo del stock. La llamada debe hacerse desde fuera
	//}
	var c = new FLSqlCursor("movistock");
	c.select("idmovimiento = " + curR.valueBuffer("idmovreserva"));
	if (c.first()) {
	//debug("Totalizando movimiento reserva " + c.valueBuffer("idmovimiento"));
		c.setModeAccess(c.Edit);
		c.refreshBuffer();
		c.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", c));
		if (!c.commitBuffer()) {
			return false;
		}
	}
	c.select("idmovimiento = " + curR.valueBuffer("idmovpterx"));
	if (c.first()) {
	//debug("Totalizando movimiento PR " + c.valueBuffer("idmovimiento"));
		c.setModeAccess(c.Edit);
		c.refreshBuffer();
		c.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", c));
		if (!c.commitBuffer()) {
			return false;
		}
	}
	return true;
	
}
/** \D
\end */
function euromoda_beforeCommit_articulos(curArticulo)
{
	var _i = this.iface;
	if (!_i.controlIdArticulo(curArticulo)) {
		return false;
	}
	if (!_i.__beforeCommit_articulos(curArticulo)) {
		return false;
	}
	if (!_i.controlColorGit(curArticulo)) {
		return false;
	}
	if (!_i.controlRepeticionArticulo(curArticulo)) {
		return false;
	}
	
	if (!_i.controlDatosModCosteProd(curArticulo)) {
		return false;
	}
	
	return true;
}

function euromoda_controlColorGit(curA)
{
	switch (curA.modeAccess()) {
	case curA.Insert:
	case curA.Edit: {
			if (curA.isNull("codcolorem") && !curA.isNull("emcolorgit")) {
				curA.setNull("emcolorgit");
			}
			if (!curA.isNull("codcolorem") && curA.isNull("emcolorgit")) {
				var cG = AQUtil.quickSqlSelect("em_colores", "codigogit", "codcolorem = '" + curA.valueBuffer("codcolorem") + "'");
				if (cG) {
					curA.setValueBuffer("emcolorgit", cG);
				}
			}
			break;
		}
	}
	return true;
}

function euromoda_controlRepeticionArticulo(curA)
{
	switch (curA.modeAccess()) {
	case curA.Insert: {
			break;
		}
	case curA.Edit: {
			if (curA.valueBuffer("codsubfamilia") != curA.valueBufferCopy("codsubfamilia") || curA.valueBuffer("codcolorem") != curA.valueBufferCopy("codcolorem") || curA.valueBuffer("codtamanoem") != curA.valueBufferCopy("codtamanoem") || curA.valueBuffer("coddibestamp") != curA.valueBufferCopy("coddibestamp")) {
				break;
			} else {
				return true;
			}
		}
	case curA.Del: {
			return true;
		}
	}
	var refRepetida = AQUtil.sqlSelect("articulos", "referencia", "codsubfamilia = '" + curA.valueBuffer("codsubfamilia") + "' AND codcolorem = '" + curA.valueBuffer("codcolorem") + "' AND codtamanoem = '" + curA.valueBuffer("codtamanoem") + "' AND coddibestamp = " + curA.valueBuffer("coddibestamp") + " AND referencia <> '" + curA.valueBuffer("referencia") + "'");
	if (refRepetida && !formRecordem_altamasivacompleta.iface.preguntado_) {
		var combinacion = curA.valueBuffer("codsubfamilia") + " - " + curA.valueBuffer("codtamanoem") + " - " + curA.valueBuffer("codcolorem") + " - " + curA.valueBuffer("coddibestamp");
		var res = MessageBox.warning(sys.translate("Ya existe un art�culo (ref %1) con la combinaci�n subfamilia - tama�o - color - dibujo:\n%2\n�Desea continuar?").arg(refRepetida).arg(combinacion), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	return true;
}

function euromoda_controlIdArticulo(curArticulo)
{
	var _i = this.iface;
	if (curArticulo.modeAccess() != curArticulo.Insert) {
		return true;
	}
	if (curArticulo.valueBuffer("referencia") != "No Asignada") {
		return true;
	}
	var referencia = _i.calculaReferencia(curArticulo)
									 if (!referencia) {
		MessageBox.warning(sys.translate("Error al calcular la referencia del art�culo"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	curArticulo.setValueBuffer("referencia", referencia);
	var codBarras = _i.calculaCodBarras(curArticulo);
	if (!codBarras) {
		MessageBox.warning(sys.translate("Error al calcular el c�digo de baras del art�culo"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	curArticulo.setValueBuffer("tipocodbarras", "EAN");
	curArticulo.setValueBuffer("codbarras", codBarras);
	return true;
}

function euromoda_calculaReferencia(curArticulo)
{
	var tipo = curArticulo.valueBuffer("em_tipoarticulo");
	
	var ultimo = AQUtil.sqlSelect("secuenciasart", "valor", "tipo = '" + tipo + "'");
	if (!ultimo) {
		var idUltimo = AQUtil.sqlSelect("articulos", "referencia", "em_tipoarticulo = '" + tipo + "' AND referencia ~ '^[0-9]+$' ORDER BY CAST(referencia AS INTEGER) DESC");
		ultimo = idUltimo ? idUltimo : 0;
		ultimo = parseFloat(ultimo) + 1;
		AQUtil.sqlInsert("secuenciasart", "tipo, valor", tipo + "," + ultimo)
			} else {
		do {
			ultimo = parseFloat(ultimo) + 1;
		} while (AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + ultimo + "'"));
		AQUtil.sqlUpdate("secuenciasart", "valor", ultimo, "tipo = '" + tipo + "'");
	}
	return ultimo;
}

function euromoda_calculaCodBarras(curArticulo)
{
	var _i = this.iface;
	var referencia = curArticulo.valueBuffer("referencia");
	if (!referencia || referencia == undefined) {
		return false;
	}
	var codFamilia = curArticulo.valueBuffer("codfamilia");
	if(!codFamilia || codFamilia == "") {
		debug("Sin familia");
		return false;
	}
	var tipoEan = AQUtil.sqlSelect("familias", "tipoean", "codfamilia = '" + codFamilia + "'");
	var tabla = tipoEan == "Interno" ? "em_eaninternos" : "em_eanexternos";
	var valor = AQUtil.sqlSelect(tabla, "ean", "true ORDER BY ean");
	if (!valor) {
		debug("No encuentra EAN");
		return false;
	}
	if (!AQSql.del(tabla, "ean = '" + valor + "'")) {
		return false;
	}
	//var valorSinDC = "8420778" + flfactppal.iface.pub_cerosIzquierda(referencia, 5);
	//var valor = valorSinDC + _i.digitoControlEAN(valorSinDC);
	return valor;
}

function euromoda_digitoControlEAN(valorSinDC)
{
	var pesos: Array;
	if (!valorSinDC || valorSinDC == "") {
		return false;
	}
	var longValorSinDC = valorSinDC.length;
	switch (longValorSinDC) {
	case 12: { /// EAN 13
			pesos = [1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3];
			break;
		}
	case 13: { /// EAN 14
			pesos = [3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3];
			break;
		}
	default: {
			return false;
		}
	}
	var suma = 0;
	for (var i = 0; i < longValorSinDC; i++) {
		suma += parseInt(valorSinDC.charAt(i)) * parseInt(pesos[i]);
	}
	//debug("suma = " + suma);
	var decenaSuperior = (Math.floor(suma / 10) + 1) * 10;
	//debug("decenaSuperior = " + decenaSuperior);
	var valor = decenaSuperior - suma;
	if (valor == 10) {
		valor = 0;
	}
	//debug("valor = " + valor);
	return valor.toString();
}


function euromoda_afterCommit_movistock(curMS)
{
	//debug("euromoda_afterCommit_movistock " + curMS.valueBuffer("referencia") + " Id " + curMS.valueBuffer("idmovimiento") + " estado " + curMS.valueBuffer("estado") + " Cantidad " + curMS.valueBuffer("cantidad"));
	var _i = this.iface;
	debug(" euromoda_afterCommit_movistock 1");
	if (!_i.controlACTejidoPrep(curMS)) {
		return false;
	}
	//debug(" euromoda_afterCommit_movistock 2");
	if (!_i.__afterCommit_movistock(curMS)) {
		return false;
	}
	//debug(" euromoda_afterCommit_movistock 3");
	if (!_i.controlPartidas(curMS)) {
		return false;
	}
	//debug(" euromoda_afterCommit_movistock 4");
	if (!_i.controlPrevision(curMS)) {
		return false;
	}
	//debug(" euromoda_afterCommit_movistock 5");
	if (!_i.controlLineaPedidoProvMerma(curMS)) {
		return false;
	}
	//debug(" euromoda_afterCommit_movistock 6");	
	if (!_i.controlReservaLoteMovAlbaranCli(curMS)) {
		return false;
	}
	//debug(" euromoda_afterCommit_movistock 7");
	if(!_i.controlAlmacenLoteAlbCli(curMS)) {
		return false;	
	}
	debug(" euromoda_afterCommit_movistock 8");
	return true;
}

/** NUEVO */
function euromoda_controlReservaLoteMovAlbaranCli(curMS)
{
//debug("controlReservaLoteMovAlbaranCli");
	if (curMS.isNull("idlineaac")) {
		return true;
	}
	switch (curMS.modeAccess()) {
		case curMS.Insert: {
			var qLote = new AQSqlQuery;
			qLote.setSelect("rlp.codlote, mslp.idmovimiento, mslp.cantidad, mslp.enreserva");
			qLote.setFrom("lineasalbaranescli la INNER JOIN em_reservaslotepedido rlp ON la.idlineapedido = rlp.idlineapc INNER JOIN movistock mslp ON rlp.codlote = mslp.codlote");
			qLote.setWhere("la.idlinea = " + curMS.valueBuffer("idlineaac"));
			if (!qLote.exec()) {
				return false;
			}
//debug("qLote " + qLote.sql() + "tama�o " + qLote.size());
			var aAsignar = curMS.valueBuffer("cantidad") * -1;
			var codLote;
			var curRPR = new FLSqlCursor("em_reservaspterx");
			var asignada;
			var canPR;
var vuelta = 0;
			while (qLote.next() && aAsignar > 0) {
//debug("Vuelta ___________________ " + vuelta++);
				canPR = qLote.value("mslp.cantidad") - qLote.value("mslp.enreserva");
				canPR = isNaN(canPR) ? 0 : canPR;
				asignada = aAsignar < canPR ? aAsignar : canPR;
				asignada = AQUtil.roundFieldValue(asignada, "em_reservaspterx", "cantidad");
				codLote = qLote.value("rlp.codlote");
//debug("X codLote " + codLote + " Asignada " + asignada);
				curRPR.setModeAccess(curRPR.Insert);
				curRPR.refreshBuffer();
				curRPR.setValueBuffer("idmovreserva", curMS.valueBuffer("idmovimiento"));
				curRPR.setValueBuffer("idmovpterx", qLote.value("mslp.idmovimiento"));
				curRPR.setValueBuffer("cantidad", asignada);
//debug("lanzando commitBuffer controlReservaLoteMovAlbaranCli");
				if (!curRPR.commitBuffer()) {
					return false;
				}
				aAsignar -= asignada;
			}
			break;
		}
	}
	
	return true;
}
/** FIN NUEVO */


function euromoda_controlACTejidoPrep(curMS)
{

	var _i = this.iface;
	if (curMS.isNull("codsubfamiliatp")) {
		return true;
	}
	switch (curMS.modeAccess()) {
		case curMS.Del: {
			if (!_i.borraMovTejidoPrep(curMS)) {
				return false;
			}
			break;
		}
		case curMS.Edit: {
			if (curMS.valueBufferCopy("estado") == "PTE" && curMS.valueBuffer("estado") == "OFF") {
				if (!_i.borraMovTejidoPrep(curMS)) {
					return false;
				}
			} else if (curMS.valueBufferCopy("estado") == "OFF" && curMS.valueBuffer("estado") == "PTE") {
				if (!_i.creaMovTejidoPrep(curMS)) {
					return false;
				}
			}
			break;
		}
	}
	return true;
}

function euromoda_controlBCTejidoPrep(curMS)
{
	/// Reservas tejido preparado
	/*if (sys.nameBD() == "abanq_creaciones") {
		return true;
	}*/
	var _i = this.iface;
	if (!curMS.isNull("codsubfamiliatp")) {
		return true;
	}
	switch (curMS.modeAccess()) {
	case curMS.Insert: {
			var referencia = curMS.valueBuffer("referencia");
			if (_i.esReferenciaXPiezas(referencia)) {
				var codSubfamilia = AQUtil.sqlSelect("articulos", "codsubfamilia", "referencia = '" + referencia + "'");
				curMS.setValueBuffer("codsubfamiliatp", codSubfamilia);
			}
			break;
		}
	}
	return true;
}

function euromoda_esProcesoBatch()
{
	return formmt_procesos.iface.batchOn_;
}

function euromoda_creaMovTejidoPrep(curMS)
{
	/// Reservas tejido preparado
	var _i = this.iface;
	
	if (curMS.isNull("codsubfamiliatp") || curMS.valueBuffer("estado") == "OFF") {
		return true;
	}	
	var cantidad = -1 * curMS.valueBuffer("reservaaf");
	if (!cantidad) {
		return true;
	}
	
	var codSubfamilia = curMS.valueBuffer("codsubfamiliatp");
	
	var primero = false;
	if (curMS.isNull("idmovtejidoprep")) {
		var codSFArt = AQUtil.sqlSelect("articulos", "codsubfamilia", "referencia = '" + curMS.valueBuffer("referencia") + "'");
		if (codSFArt == codSubfamilia) {
			primero = true;
		}
	}
	var refMS = curMS.valueBuffer("referencia");
	var oDatosTP = _i.dameSiguienteTejidoPrep(codSubfamilia, primero ? 0 : curMS.valueBuffer("idstock"));
	if (!oDatosTP) {

		return false;
	}
	var refTP = oDatosTP.referencia;
	if (!refTP) {

		return false;
	}
	if (refTP == -1) {
		return true;
	}
	var idStock = oDatosTP.idStock;
	
	if (!_i.curMoviStock) {
		_i.curMoviStock = new FLSqlCursor("movistock");
	}
	
	var curMTP = new FLSqlCursor("movistock");
	curMTP.setActivatedCheckIntegrity(false);	
	curMTP.setActivatedCommitActions(false);
	curMTP.setModeAccess(curMTP.Insert);
	curMTP.refreshBuffer();
	curMTP.setValueBuffer("idmovtejidoprep", curMS.valueBuffer("idmovimiento"));
	curMTP.setValueBuffer("referencia", refTP);
	curMTP.setValueBuffer("estado", "PTE");
		
	cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");
	curMTP.setValueBuffer("cantidad", cantidad);
	curMTP.setValueBuffer("fechaprev", curMS.valueBuffer("fechaprev"));
	curMTP.setValueBuffer("idstock", idStock);
	curMTP.setValueBuffer("concepto", curMS.valueBuffer("concepto"));
	curMTP.setValueBuffer("codsubfamiliatp", codSubfamilia);	
	
	if(primero) {		
		curMTP.setValueBuffer("idmovtejidopadre", curMS.valueBuffer("idmovimiento"));		
	} else {			
		curMTP.setValueBuffer("idmovtejidopadre", curMS.valueBuffer("idmovtejidopadre"));
	}
	
	if (!curMTP.commitBuffer()) {

		curMTP.setActivatedCheckIntegrity(true);
		return false;
	}
	curMTP.setActivatedCheckIntegrity(true);
	return true;
}

function euromoda_borraMovTejidoPrep(curMS)
{
	/// Reservas tejido preparado
	/*if (sys.nameBD() == "abanq_creaciones") {
		return true;
	}*/
	var _i = this.iface;
	
	if (curMS.isNull("codsubfamiliatp")) {
		return true;
	}
	if (!AQSql.del("movistock", "idmovtejidoprep = " + curMS.valueBuffer("idmovimiento"))) {
		return false;
	}
	return true;
}

function euromoda_controlLineaPedidoProvMerma(curMS)
{
	if (curMS.isNull("idlineapp")) {
		return true;
	}
	if (curMS.isNull("codpartida")) {
		return true;
	}
	if (curMS.cursorRelation() && curMS.cursorRelation().action() == "lineaspedidosprov") {
		return true;
	}
	var curLinea = new FLSqlCursor("lineaspedidosprov");
	curLinea.select("idlinea = " + curMS.valueBuffer("idlineapp"));
	if (curLinea.first()) {
		curLinea.setModeAccess(curLinea.Edit);
		curLinea.refreshBuffer();
		if (!curLinea.valueBuffer("xpartidas")) {
			return true;
		}
		curLinea.setValueBuffer("cerrada", formRecordlineaspedidosprov.iface.pub_commonCalculateField("cerradaxpartidas", curLinea));
		if (!curLinea.commitBuffer()) {
			return false;
		}
	}
	return true;
}

function euromoda_beforeCommit_movistock(curMS)
{
	var _i = this.iface;
	//debug("euromoda_beforeCommit_movistock 1");
	if (!_i.__beforeCommit_movistock(curMS)) {
		return false;
	}
	//debug("euromoda_beforeCommit_movistock 2");
	if (!_i.borraReservasMSAFaltas(curMS, false)) {
		return false;
	}
	//debug("euromoda_beforeCommit_movistock 3");
	if (!_i.controlBCTejidoPrep(curMS)) {
		return false;
	}
	//debug("euromoda_beforeCommit_movistock 4");
	if (!_i.validaReservaMovistock(curMS)) {
		return false;
	}
	//debug("euromoda_beforeCommit_movistock 5");
	return true;
}

function euromoda_controlPartidas(curMS)
{
	var _i = this.iface;
	var codLote = curMS.valueBuffer("codpartida");
	if (codLote && codLote != "") {
		if (!_i.actualizarMetrosPartida(codLote)) {
			return false;
		}
	}
	
	if (curMS.modeAccess() == curMS.Edit) {
		var codLoteAnt = curMS.valueBufferCopy("codpartida");
		if (codLoteAnt && codLoteAnt != "" && codLoteAnt != codLote) {
			if (!_i.actualizarMetrosPartida(codLote)) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_actualizarMetrosPartida(codLote)
{
	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("codlote = '" + codLote + "'");
	if (!curLote.first()) {
		return false;
	}
	var _iLS = formRecordlotesstock.iface;
	curLote.setModeAccess(curLote.Edit);
	curLote.refreshBuffer();
	curLote.setValueBuffer("msalidas", _iLS.pub_commonCalculateField("msalidas", curLote));
	curLote.setValueBuffer("mdistribuidos", _iLS.pub_commonCalculateField("mdistribuidos", curLote));
	curLote.setValueBuffer("mrecibidos", _iLS.pub_commonCalculateField("mrecibidos", curLote));
	curLote.setValueBuffer("mmerma", _iLS.pub_commonCalculateField("mmerma", curLote));
	curLote.setValueBuffer("distribucionfin", _iLS.pub_commonCalculateField("distribucionfin", curLote));
	curLote.setValueBuffer("pormerma", _iLS.pub_commonCalculateField("pormerma", curLote));
	curLote.setValueBuffer("mpterec", _iLS.pub_commonCalculateField("mpterec", curLote));
	curLote.setValueBuffer("canusada", _iLS.pub_commonCalculateField("canusada", curLote));
	curLote.setValueBuffer("candisponible", _iLS.pub_commonCalculateField("candisponible", curLote));
	curLote.setValueBuffer("mptedist", _iLS.pub_commonCalculateField("mptedist", curLote));
	//debug("//28-07-2015");
	//curLote.setValueBuffer("canlote", _iLS.pub_commonCalculateField("canlote", curLote));
	if (!curLote.commitBuffer()) {
		return false;
	}
	return true;
}

function euromoda_dameDatosStockLinea(curLinea, curArticuloComp)
{
	var _i = this.iface;
	//debug("\n\neuromoda_dameDatosStockLinea");
	var util = new FLUtil;
	var aDatos = [];
	var aAux: Array;
	var tabla = curLinea.table();
	var curRelation = curLinea.cursorRelation();
	var tablaRel = curRelation ? curRelation.table() : "";
	var codAlmacen, hora;

	switch (tabla) {
	case "lineaspedidoscli": { /// Usamos la fecha de servicio en lugar de la fecha de salida.
			aDatos.idLinea = curLinea.valueBuffer("idlinea");
			var fechaPrev;
			if (tablaRel == "pedidoscli") {
				if (AQUtil.daysTo(curLinea.valueBuffer("fechaservicio"), curRelation.valueBuffer("fechaservicio")) > 0) {
					fechaPrev = curRelation.valueBuffer("fechaservicio");
				} else {
					fechaPrev = curLinea.valueBuffer("fechaservicio")
				}
				aDatos.codAlmacen = curRelation.valueBuffer("codalmacen");
				aDatos.fechaPrev = fechaPrev;
				aDatos.concepto = curRelation.valueBuffer("codigo");
				aDatos.concepto += " " + curRelation.valueBuffer("nombrecliente");
			} else {
				aAux = flfactppal.iface.pub_ejecutarQry("pedidoscli", "codalmacen,fechaservicio,codigo,nombrecliente", "idpedido = " + curLinea.valueBuffer("idpedido"), false);
				if (aAux.result != 1) {
					return false;
				}
//debug("FECHA PREV ??????????????????" + curLinea.valueBuffer("fechaservicio") + aAux.fechaservicio);
				if (AQUtil.daysTo(curLinea.valueBuffer("fechaservicio"), aAux.fechaservicio) > 0) {
					fechaPrev = aAux.fechaservicio;
				} else {
					fechaPrev = curLinea.valueBuffer("fechaservicio")
				}
//debug("FECHA PREV ??????????????????" + fechaPrev);
				aDatos.codAlmacen = aAux.codalmacen;
				aDatos.fechaPrev = fechaPrev;
				aDatos.concepto = aAux.codigo;
				aDatos.concepto += " " + aAux.nombrecliente;
			}
			if(curLinea.valueBuffer("numlinea")) {		
				aDatos.concepto += " - N.L. " + curLinea.valueBuffer("numlinea");
			}
			aDatos.concepto = sys.translate("Pedido cliente %1").arg(aDatos.concepto);

			break;
		}
		
	case "lineaspedidosprov": {
			aDatos.codPartida = curLinea.valueBuffer("codpartida");
			aDatos.idLinea = curLinea.valueBuffer("idlinea");
			var codOrden;
			if (!curLinea.isNull("codloteprod")) {
				codOrden = AQUtil.sqlSelect("lotesstock", "codordenproduccion", "codlote = '" + curLinea.valueBuffer("codloteprod") + "'");
				aDatos.codLote = curLinea.valueBuffer("codloteprod");
			}
			codOrden = codOrden ? codOrden : "";
			if (tablaRel == "pedidosprov") {
				aDatos.codAlmacen = curRelation.valueBuffer("codalmacen");
				aDatos.fechaPrev = curRelation.valueBuffer("fechaentrada");
				aDatos.concepto = curRelation.valueBuffer("codigo");
				aDatos.concepto += " " + curRelation.valueBuffer("nombre");
			} else {
				aAux = flfactppal.iface.pub_ejecutarQry("pedidosprov", "codalmacen,fechaentrada,codigo,nombre", "idpedido = " + curLinea.valueBuffer("idpedido"), false);
				if (aAux.result != 1) {
					return false;
				}
				aDatos.codAlmacen = aAux.codalmacen;
				aDatos.fechaPrev = aAux.fechaentrada;
				aDatos.concepto = aAux.codigo;
				aDatos.concepto += " " + aAux.nombre;
			}
			aDatos.concepto = (codOrden ? (codOrden + " - "): "") + sys.translate("Pedido proveedor %1").arg(aDatos.concepto);			
			break;
		}
		/** NUEVO */
	case "lineasalbaranesprov": {
			aDatos = _i.__dameDatosStockLinea(curLinea, curArticuloComp);
			if (!aDatos) {
				return false;
			}
			if (!curLinea.isNull("codloteprod")) {
				aDatos.codLote = curLinea.valueBuffer("codloteprod");
			}
			break;
		}
		/** FIN NUEVO */
	case "lineastransstock": {
			aDatos = _i.__dameDatosStockLinea(curLinea, curArticuloComp);
			aDatos.codPartida = curLinea.valueBuffer("codpartida");
			break;
		}
	case "pr_procesos": {
			aDatos.idLinea = false;
			var codOrden = curLinea.valueBuffer("idobjeto");
			var fechaPrev = AQUtil.sqlSelect("pr_ordenesproduccion", "fechaentrega", "codorden = '" + codOrden + "'");
			aDatos.fechaPrev = fechaPrev;
			aDatos.codAlmacen = this.iface.almacenFabricacion(curLinea);
			aDatos.concepto = sys.translate("Orden producci�n %1").arg(codOrden);			
			break;
		}
	case "lineaspedidomarcocli": {
			aDatos.idLinea = curLinea.valueBuffer("idlinea");
			if (tablaRel == "pedidosmarcocli") {
				aDatos.fechaPrev = curRelation.valueBuffer("fecha");
				aDatos.concepto = curRelation.valueBuffer("codpedidomarco");
				aDatos.concepto += " " + curRelation.valueBuffer("nombrecliente");
			} else {
				aAux = flfactppal.iface.pub_ejecutarQry("pedidosmarcocli", "fecha,nombrecliente", "codpedidomarco = '" + curLinea.valueBuffer("codpedidomarco") + "'", false);
				if (aAux.result != 1) {
					return false;
				}
				aDatos.fechaPrev = aAux.fecha;
				aDatos.concepto = curLinea.valueBuffer("codpedidomarco");
				aDatos.concepto += " " + aAux.nombrecliente;
			}
			aDatos.codAlmacen = _i.almacenFabricacion(curLinea);
			aDatos.concepto = sys.translate("Pedido marco %1").arg(aDatos.concepto);
			break;
		}
	default: {
			aDatos = _i.__dameDatosStockLinea(curLinea, curArticuloComp);
		}
	}
	return aDatos;
}

function euromoda_creaRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp)
{
	//debug("euromoda_creaRegMoviStock 1");
	var _i = this.iface;
	var tabla = curLinea.table();
    //debug("tabla: "+tabla);
	var cantidad = aDatosStockLinea.cantidad;
	//   debug("euromoda_creaRegMoviStock " + cantidad);
	var idLinea = aDatosStockLinea.idLinea;
	var idStock: String;
	switch (tabla) {
	case "lineaspedidosprov": {
			idStock = _i.dameIdStock(aDatosStockLinea.codAlmacen, aDatosArt);
//			debug("euromoda_creaRegMoviStock idStock " + idStock);
			if (!idStock) {
				return false;
			}
			cantidad = parseFloat(cantidad);
			_i.curMoviStock.setModeAccess(_i.curMoviStock.Insert);
			_i.curMoviStock.refreshBuffer();
			_i.curMoviStock.setValueBuffer("idlineapp", idLinea);
			_i.curMoviStock.setValueBuffer("estado", "PTE");
			_i.curMoviStock.setValueBuffer("fechaprev", aDatosStockLinea.fechaPrev);
			_i.curMoviStock.setValueBuffer("cantidad", cantidad);
			_i.curMoviStock.setValueBuffer("idstock", idStock);
			if ("concepto" in aDatosStockLinea) {
				_i.curMoviStock.setValueBuffer("concepto", aDatosStockLinea.concepto);
			}
			if (!_i.datosArticuloMS(aDatosArt, aDatosStockLinea)) {
				return false;
			}
			if (aDatosStockLinea.codLote) {
				_i.curMoviStock.setValueBuffer("codlote", aDatosStockLinea.codLote);
			} else {
				_i.curMoviStock.setNull("codlote");
			}
			
			_i.curMoviStock.setValueBuffer("codpartida", aDatosStockLinea.codPartida);
			_i.curMoviStock.setValueBuffer("em_merma", curLinea.valueBuffer("cerrada"));
			
			if (!_i.curMoviStock.commitBuffer()) {
				return false;
			}
			break;
		}
	case "lineasalbaranesprov": {
			/// TEMPORAL
			if (!_i.__creaRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp)) {
				return false;
			}		
			//P065/M5
			var oDescontarProducto = _i.datosDescontarProducto(curLinea, aDatosStockLinea, curArticuloComp);
			if(oDescontarProducto.desContarProducto) {				
				if (!_i.__creaRegMoviStock(curLinea, aDatosArt, oDescontarProducto.aDatosStockLineaOrigen, curArticuloComp)) {
					return false;
				}
			}		
			//fin P065/M5


			break;
			/// TEMPORAL END
			cantidad = parseFloat(cantidad);
			var idLineaPedido: String = curLinea.valueBuffer("idlineapedido");
			if (idLineaPedido && idLineaPedido != "" && idLineaPedido != 0) {
				if (!_i.__creaRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp)) {
					return false;
				}
			} else {
				idStock = this.iface.dameIdStock(aDatosStockLinea.codAlmacen, aDatosArt);
				if (!idStock) {
					return false;
				}
				this.iface.curMoviStock.setModeAccess(this.iface.curMoviStock.Insert);
				this.iface.curMoviStock.refreshBuffer();
				this.iface.curMoviStock.setValueBuffer("cantidad", cantidad);
				this.iface.curMoviStock.setValueBuffer("idstock", idStock);
				if ("concepto" in aDatosStockLinea) {
					_i.curMoviStock.setValueBuffer("concepto", aDatosStockLinea.concepto);
				}
				if (!this.iface.datosArticuloMS(aDatosArt, aDatosStockLinea)) {
					return false;
				}
			}
			this.iface.curMoviStock.setValueBuffer("idlineaap", idLinea);
			this.iface.curMoviStock.setValueBuffer("estado", "HECHO");
			this.iface.curMoviStock.setValueBuffer("fechareal", aDatosStockLinea.fechaReal);
			this.iface.curMoviStock.setValueBuffer("horareal", aDatosStockLinea.horaReal);
			if (aDatosStockLinea.codLote) {
				this.iface.curMoviStock.setValueBuffer("codlote", aDatosStockLinea.codLote);
			} else {
				this.iface.curMoviStock.setNull("codlote");
			}
			_i.curMoviStock.setValueBuffer("codpartida", curLinea.valueBuffer("codpartida"));
			if (!this.iface.curMoviStock.commitBuffer()) {
				return false;
			}
			break;
		}
	case "lineastransstock": {
            //debug("euromoda_creaRegMoviStock 2");
			var referencia = curLinea.valueBuffer("referencia");
			var forzarNuevoLote = curLinea.valueBuffer("forzarnuevolote");
			var codLote;
			if (aDatosStockLinea.codLote) {
				codLote = aDatosStockLinea.codLote;
			} else if (aDatosStockLinea.codPartida) {
				codLote = aDatosStockLinea.codPartida;
			}
			var codLoteDestino = codLote;
			/// Cuando se transfiere parte de una partida se crea una nueva en el almac�n destino
			//      var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
			//      if (_i.esFamiliaCrudo(codFamilia)) {
			if (_i.esReferenciaXPartidas(referencia) || forzarNuevoLote) {
				codLote = aDatosStockLinea.codPartida;
				if (!codLote) {
					sys.warnMsgBox(sys.translate("Intenta crear una l�nea de transferencia para un art�culo por partidas (%1) sin indicar la partida").arg(referencia));
					return false;
				}
				aDatosArt.codalmacen = aDatosStockLinea.codAlmaDestino;
				aDatosArt.codproveedor = AQUtil.sqlSelect("lotesstock", "codproveedor", "codlote = '" + codLote + "'");
				aDatosArt.codpedidoprov = AQUtil.sqlSelect("lotesstock", "codpedidoprov", "codlote = '" + codLote + "'");
				if(forzarNuevoLote) { 
					codLoteDestino = _i.crearLote(aDatosArt, cantidad,"", "TT");
				} else {
					codLoteDestino = _i.crearLote(aDatosArt, cantidad);
				}
				if (!codLoteDestino) {
					return false;
				}
			}
			var conceptoO = aDatosStockLinea.concepto;
			var conceptoD = aDatosStockLinea.concepto;
			
			idStock = _i.dameIdStock(aDatosStockLinea.codAlmaOrigen, aDatosArt);
			if (!idStock) {
				return false;
			}
			cantidad = parseFloat(cantidad);
			_i.curMoviStock.setModeAccess(_i.curMoviStock.Insert);
			_i.curMoviStock.refreshBuffer();
			_i.curMoviStock.setValueBuffer("idlineats", idLinea);
			_i.curMoviStock.setValueBuffer("estado", "HECHO");
			_i.curMoviStock.setValueBuffer("fechareal", aDatosStockLinea.fechaReal);
			_i.curMoviStock.setValueBuffer("horareal", aDatosStockLinea.horaReal);
			_i.curMoviStock.setValueBuffer("cantidad", (cantidad * -1));
			_i.curMoviStock.setValueBuffer("idstock", idStock);
			
			if (!_i.datosArticuloMS(aDatosArt, aDatosStockLinea)) {
				return false;
			}
			if ("concepto" in aDatosStockLinea) {
				if (codLoteDestino) {
					conceptoO  += ". " + sys.translate("Partida destino %1").arg(codLoteDestino);
				}
				_i.curMoviStock.setValueBuffer("concepto", conceptoO);
			}
			if (codLote) {
				_i.curMoviStock.setValueBuffer("codlote", codLote);
			} else {
				_i.curMoviStock.setNull("codlote");
			}
			if (!_i.curMoviStock.commitBuffer()) {
				MessageBox.critical(util.translate("scripts", "Error: No pudo crearse el movimiento de stock para el art�culo %1 y el almac�n %2").arg(aDatosArt["referencia"]).arg(aDatosStockLinea.codAlmaOrigen), MessageBox.Ok, MessageBox.NoButton);
				return false;
			}
			
			var idStockDestino: String = _i.dameIdStock(aDatosStockLinea.codAlmaDestino, aDatosArt);
			if (!idStockDestino) {
				return false;
			}
			_i.curMoviStock.setModeAccess(_i.curMoviStock.Insert);
			_i.curMoviStock.refreshBuffer();
			_i.curMoviStock.setValueBuffer("idlineats", idLinea);
			_i.curMoviStock.setValueBuffer("estado", "HECHO");
			_i.curMoviStock.setValueBuffer("fechareal", aDatosStockLinea.fechaReal);
			_i.curMoviStock.setValueBuffer("horareal", aDatosStockLinea.horaReal);
			_i.curMoviStock.setValueBuffer("cantidad", cantidad);
			_i.curMoviStock.setValueBuffer("idstock", idStockDestino);
			if (!_i.datosArticuloMS(aDatosArt, aDatosStockLinea)) {
				return false;
			}
			if ("concepto" in aDatosStockLinea) {
				if (codLote) {
					conceptoD += ". " + sys.translate("Partida origen %1").arg(codLote);
				}
				_i.curMoviStock.setValueBuffer("concepto", conceptoD);
			}
			if (codLoteDestino) {
				_i.curMoviStock.setValueBuffer("codlote", codLoteDestino);
			} else {
				_i.curMoviStock.setNull("codlote");
			}
			if (!_i.curMoviStock.commitBuffer()) {
				MessageBox.critical(util.translate("scripts", "Error: No pudo crearse el movimiento de stock para el art�culo %1 y el almac�n %2").arg(aDatosArt["referencia"]).arg(aDatosStockLinea.codAlmaDestino), MessageBox.Ok, MessageBox.NoButton);
				return false;
			}
            //debug("euromoda_creaRegMoviStock 3");
			break;
		}
	case "lineaspedidomarcocli": {
			idStock = _i.dameIdStock(aDatosStockLinea.codAlmacen, aDatosArt);
			if (!idStock) {
				return false;
			}
			cantidad = parseFloat(cantidad);
			_i.curMoviStock.setModeAccess(_i.curMoviStock.Insert);
			_i.curMoviStock.refreshBuffer();
			_i.curMoviStock.setValueBuffer("idlineapm", idLinea);
			_i.curMoviStock.setValueBuffer("estado", "PREV");
			_i.curMoviStock.setValueBuffer("fechaprev", aDatosStockLinea.fechaPrev);
			_i.curMoviStock.setValueBuffer("cantidad", cantidad);
			_i.curMoviStock.setValueBuffer("idstock", idStock);
			if ("concepto" in aDatosStockLinea) {
				_i.curMoviStock.setValueBuffer("concepto", aDatosStockLinea.concepto);
			}
			if (!_i.datosArticuloMS(aDatosArt, aDatosStockLinea)) {
				return false;
			}
			if (aDatosStockLinea.codLote) {
				_i.curMoviStock.setValueBuffer("codlote", aDatosStockLinea.codLote);
			} else {
				_i.curMoviStock.setNull("codlote");
			}
			if (!_i.curMoviStock.commitBuffer()) {
				return false;
			}
			break;
		}
	case "lotesstock": {
            //debug("euromoda_creaRegMoviStock 4");
			debug("1. estoy en crear registro movistock con cantidad: "+cantidad);
			idStock = _i.dameIdStock(aDatosStockLinea.codAlmacen, aDatosArt);
			if (!idStock) {
				return false;
			}
			cantidad = parseFloat(cantidad) * -1;
			debug("2. estoy en crear registro movistock con cantidad: "+cantidad);
			_i.curMoviStock.setModeAccess(_i.curMoviStock.Insert);
			_i.curMoviStock.refreshBuffer();
			_i.curMoviStock.setValueBuffer("codloteprod", curLinea.valueBuffer("codlote"));
			if (curLinea.valueBuffer("estado") == "PREVISION") {
				_i.curMoviStock.setValueBuffer("estado", "PREV");
			} else {
				_i.curMoviStock.setValueBuffer("estado", "PTE");
			}
			if ("concepto" in aDatosStockLinea) {
				_i.curMoviStock.setValueBuffer("concepto", aDatosStockLinea.concepto);
			}
            //debug("euromoda_creaRegMoviStock 5");
			if (!_i.datosArticuloMS(aDatosArt, aDatosStockLinea)) {
				return false;
			}
             //debug("euromoda_creaRegMoviStock 6");
			_i.curMoviStock.setValueBuffer("fechaprev", aDatosStockLinea.fechaPrev);
			_i.curMoviStock.setValueBuffer("cantidad", cantidad);
			_i.curMoviStock.setValueBuffer("idarticulocomp", curArticuloComp.valueBuffer("id"));
			var idTipoTareaPro = curArticuloComp.valueBuffer("idtipotareapro");
			_i.curMoviStock.setValueBuffer("idtipotareapro", idTipoTareaPro);
			var idProceso = aDatosStockLinea.idProceso;
			if (idProceso) {
				this.iface.curMoviStock.setValueBuffer("idproceso", idProceso);
				var idTarea: String = util.sqlSelect("pr_tareas", "idtarea", "idproceso = " + idProceso + " AND idtipotareapro = " + idTipoTareaPro);
				if (!idTarea) {
					MessageBox.warning(util.translate("scripts", "Error al crear el movimiento de stock:\nNo se ha encontrado una tarea para el proceso %1 y el tipo %2\nal crear el movimiento de stock para el art�culo %3").arg(idProceso).arg(idTipoTareaPro).arg(curArticuloComp.valueBuffer("refcomponente")), MessageBox.Ok, MessageBox.NoButton);
					return false;
				}
				_i.curMoviStock.setValueBuffer("idtarea", idTarea);
			}
			_i.curMoviStock.setValueBuffer("idstock", idStock);
			if (aDatosStockLinea.codLote) {
				_i.curMoviStock.setValueBuffer("codlote", aDatosStockLinea.codLote);
			} else {
				_i.curMoviStock.setNull("codlote");
			}
            //debug("euromoda_creaRegMoviStock 7");
			if (!_i.curMoviStock.commitBuffer()) {
				return false;
			}
			debug("3. estoy en crear registro movistock con cantidad: "+curMoviStock.valueBuffer("cantidad"));
			debug("3. estoy en crear registro movistock con idmovimiento: "+curMoviStock.valueBuffer("idmovimiento"));
            //debug("euromoda_creaRegMoviStock 8");
			break;
		}
	default: {
			if (!_i.__creaRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp)) {
				return false;
			}
		}
	}
//	debug("euromoda_creaRegMoviStock OK");
	return true;
}

function euromoda_datosArticulo(cursor, codLote)
{
	var util: FLUtil = new FLUtil;
	var res: Array = [];
	
	switch (cursor.table()) {
	case "lineaspedidosprov":
	case "lineasalbaranesprov": {
			res = this.iface.__datosArticulo(cursor, codLote);
			var codAlmacen, codPedidoProv, codAlbaranProv, codProveedor, fechaEntrada;
			var cR = cursor.cursorRelation();
			if (cR) {
				res["codalmacen"] = cR.valueBuffer("codalmacen");;
				res["codproveedor"] = cR.valueBuffer("codproveedor");;
				if (cursor.table() == "lineaspedidosprov") {
					res["codpedidoprov"] = cR.valueBuffer("codigo");
				} else {
					res["codalbaranprov"] = cR.valueBuffer("codigo");
					res["fechaentradaem"] = cR.valueBuffer("fecha");
				}
			} else {
				if (cursor.table() == "lineaspedidosprov") {
					var d = flfactppal.iface.pub_ejecutarQry("pedidosprov", "codigo,codalmacen,codproveedor", "idpedido = " + cursor.valueBuffer("idpedido"), false);
					if (d.result != 1) {
						return false;
					}
					res["codalmacen"] = d.codalmacen;
					res["codpedidoprov"] = d.codigo;
					res["codproveedor"] = d.codproveedor;
				} else {
					var d = flfactppal.iface.pub_ejecutarQry("albaranesprov", "codigo,codalmacen,codproveedor,fecha", "idalbaran = " + cursor.valueBuffer("idalbaran"), false);
					if (d.result != 1) {
						return false;
					}
					res["codalmacen"] = d.codalmacen;
					res["codalbaranprov"] = d.codigo;
					res["codproveedor"] = d.codproveedor;
					res["fechaentradaem"] = d.fecha;
				}
			}
			if (!res["codalmacen"]) {
				MessageBox.warning(sys.translate("No se ha podido establecer el almac�n de destino asociado a la l�nea"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
			}
			break;
		}
	case "pr_procesos": {
			res["referencia"] = AQUtil.sqlSelect("lotesstock", "referencia", "codlote = '" + codLote + "'");
			res["codalmacen"] = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
			res["localizador"] = "referencia = '" + res["referencia"] + "'";
			break;
		}
	case "lineaspedidomarcocli": {
			res["referencia"] = cursor.valueBuffer("referencia");
			res["codalmacen"] = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
			res["localizador"] = "referencia = '" + res["referencia"] + "'";
			res["estadolote"] = "PREVISION";
			break;
		}
	default: {
			res = this.iface.__datosArticulo(cursor, codLote);
			break;
		}
	}
	
	return res;
}

function euromoda_crearLote(datosArt, cantidad, idLinea, prefijoLote, codFormato)
{
	var hoy = new Date;
	var curLoteStock = new FLSqlCursor("lotesstock");
	curLoteStock.setModeAccess(curLoteStock.Insert);
	curLoteStock.refreshBuffer();
	curLoteStock.setValueBuffer("referencia", datosArt["referencia"]);

	var codLote = formRecordlotesstock.iface.pub_calculateCounter(curLoteStock, prefijoLote);
	curLoteStock.setValueBuffer("codlote", codLote);
	if ("estadolote" in datosArt) {
		curLoteStock.setValueBuffer("estado", datosArt["estadolote"]);
	} else {
		curLoteStock.setValueBuffer("estado", "PTE");
	}
	curLoteStock.setValueBuffer("canlote", cantidad);
	curLoteStock.setValueBuffer("cantotal", 0);
	curLoteStock.setValueBuffer("canusada", 0);
	curLoteStock.setValueBuffer("candisponible", 0);
	curLoteStock.setValueBuffer("fechaentrada", hoy);
	
	if ("codalmacen" in datosArt) {
		curLoteStock.setValueBuffer("codalmacen", datosArt["codalmacen"]);
	}
	if ("ubicacion" in datosArt) {
		// debug("ubicacion lote " + datosArt["ubicacion"]);
		curLoteStock.setValueBuffer("ubicacion", datosArt["ubicacion"]);
	}
	if ("codproveedor" in datosArt) {
		curLoteStock.setValueBuffer("codproveedor", datosArt["codproveedor"]);
	}
	if ("codpedidoprov" in datosArt) {
		curLoteStock.setValueBuffer("codpedidoprov", datosArt["codpedidoprov"]);
	}
	if ("codpartida" in datosArt) {
		curLoteStock.setValueBuffer("codpartida", datosArt["codpartida"]);
	}
	if ("codalbaranprov" in datosArt) {
		curLoteStock.setValueBuffer("codalbaranprov", datosArt["codalbaranprov"]);
	}
	if ("fechaentradaem" in datosArt) {
		curLoteStock.setValueBuffer("fechaentradaem", datosArt["fechaentradaem"]);
	}
	
	if (idLinea && idLinea != 0) {
		curLoteStock.setValueBuffer("idlineapc", idLinea);
	}
	curLoteStock.setValueBuffer("articulo", formRecordlotesstock.iface.pub_commonCalculateField("articulo", curLoteStock));

	if(codFormato && codFormato != "" && codFormato != undefined) {
		curLoteStock.setValueBuffer("codformato",codFormato);
	}

	if (!curLoteStock.commitBuffer()) {
		return false;
	}
	
	return codLote;
}

function euromoda_albaranaDatosMoviStock(curMSOrigen, curLA)
{
	var _i = this.iface;
	if (!_i.__albaranaDatosMoviStock(curMSOrigen, curLA)) {
		return false;
	}
	if (curLA.table() != "lineasalbaranesprov") {
		return true;
	}
	
	var referencia = curMSOrigen.valueBuffer("referencia");
	if (!_i.esRefereniciaCrudo(referencia)) {
		return true;
	}
	//  var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
	//  if (!_i.esFamiliaCrudo(codFamilia)) {
	//   return true;
	//  }
	
	var cantidad = _i.curMoviStock.valueBuffer("cantidad");
	if (cantidad <= 0) {
		return true;
	}
	/// Generaci�n de partida
	var oArticulo = _i.datosArticulo(curLA);
	var codLote = _i.crearLote(oArticulo, cantidad);
	// debug("codlote crudo " + codLote);
	if (!codLote) {
		return false;
	}
	_i.curMoviStock.setValueBuffer("codlote", codLote);
	return true;
}

function euromoda_dameFamEstampado()
{
	var _i = this.iface;
	if (!_i.codFamEstampado_) {
		var s = _i.valorDefectoAlmacen("codfamiliaestampado");
		if (!s) {
			MessageBox.warning(sys.translate("Error al obtener las familias de tejido estampado del formulario de configuraci�n de almac�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		_i.codFamEstampado_ = "'" + s.split(",").join("', '") + "'";
	}
	return _i.codFamEstampado_;
}

function euromoda_dameFamTPPE()
{
	var _i = this.iface;
	if (!_i.codFamTPPE_) {
		var s = _i.valorDefectoAlmacen("codfamiliatppe");
		if (!s) {
			MessageBox.warning(sys.translate("Error al obtener las familias de tejido preparado para estampar"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		_i.codFamTPPE_ = "'" + s.split(",").join("', '") + "'";
	}
	return _i.codFamTPPE_;
}

function euromoda_dameSubfamEstampadoGen()
{
	var _i = this.iface;
	if (!_i.codSubfamEstampadoGen_) {
		var s = _i.valorDefectoAlmacen("subfamestampadogen");
		if (!s) {
			MessageBox.warning(sys.translate("Error al obtener las subfamilias de tejido estampado gen�rico del formulario de configuraci�n de almac�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		_i.codSubfamEstampadoGen_ = "'" + s.split(",").join("', '") + "'";
	}
	return _i.codSubfamEstampadoGen_;
}

function euromoda_dameSubfamEstampado()
{
	var _i = this.iface;
	if (!_i.codSubfamEstampado_) {
		var s = _i.valorDefectoAlmacen("codsubfamiliaestampado");
		if (!s) {
			MessageBox.warning(sys.translate("Error al obtener las subfamilias de tejido estampado del formulario de configuraci�n de almac�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		_i.codSubfamEstampado_ = "'" + s.split(",").join("', '") + "'";
	}
	return _i.codSubfamEstampado_;
}

function euromoda_dameSubfamLaminas()
{
	var _i = this.iface;
	if (!_i.codSubfamLaminas_) {
		var s = _i.valorDefectoAlmacen("codsubfamilialaminas");
		if (!s) {
			MessageBox.warning(sys.translate("Error al obtener las subfamilias de l�minas del formulario de configuraci�n de almac�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		_i.codSubfamLaminas_ = "'" + s.split(",").join("', '") + "'";
	}
	return _i.codSubfamLaminas_;
}
function euromoda_esSubfamiliaLaminas(codSubfamilia) 
{
	var _i = this.iface;
	if (!codSubfamilia) {
		return false;
	}
	var codSubfamLaminas = _i.dameSubfamLaminas();
	if (!codSubfamLaminas) {
		return false;
	}
	return (codSubfamLaminas.find("'" + codSubfamilia + "'") >= 0);
}


function euromoda_esFamiliaEstampado(codFamilia)
{
	var _i = this.iface;
	if (!codFamilia) {
		return false;
	}
	var codFamEstampado = _i.dameFamEstampado();
	if (!codFamEstampado) {
		return false;
	}
	return (codFamEstampado.find("'" + codFamilia + "'") >= 0);
}

function euromoda_esFamiliaTPPE(codFamilia)
{
	var _i = this.iface;
	if (!codFamilia) {
		return false;
	}
	var codFamTPPE = _i.dameFamTPPE();
	if (!codFamTPPE) {
		return false;
	}
	return (codFamTPPE.find("'" + codFamilia + "'") >= 0);
}

function euromoda_esSubfamEstampadoGen(codSubfamilia)
{
	var _i = this.iface;
	if (!codSubfamilia) {
		return false;
	}
	var codSubfamEstampadoGen = _i.dameSubfamEstampadoGen();
	if (!codSubfamEstampadoGen) {
		return false;
	}
	return (codSubfamEstampadoGen.find("'" + codSubfamilia + "'") >= 0);
}

function euromoda_esSubfamiliaEstampado(codSubfamilia)
{
	var _i = this.iface;
	if (!codSubfamilia) {
		return false;
	}
	var codSubfamEstampado = _i.dameSubfamEstampado();
	if (!codSubfamEstampado) {
		return false;
	}
	return (codSubfamEstampado.find("'" + codSubfamilia + "'") >= 0);
}


function euromoda_dameFamCrudo()
{
	var _i = this.iface;
	if (!_i.codFamCrudo_) {
		var s = _i.valorDefectoAlmacen("codfamiliacrudo");
		if (!s) {
			MessageBox.warning(sys.translate("Error al obtener las familias de tejido en crudo del formulario de configuraci�n de almac�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		_i.codFamCrudo_ = "'" + s.split(",").join("', '") + "'";
	}
	return _i.codFamCrudo_;
}

function euromoda_dameSubfamCrudo()
{
	var _i = this.iface;
	if (!_i.codSubfamCrudo_) {
		var s = _i.valorDefectoAlmacen("codsubfamiliacrudo");
		if (!s) {
			sys.warnMsgBox(sys.translate("Error al obtener las subfamilias de tejido en crudo del formulario de configuraci�n de almac�n"));
			return false;
		}
		_i.codSubfamCrudo_ = "'" + s.split(",").join("', '") + "'";
	}
	return _i.codSubfamCrudo_;
}

function euromoda_esFamiliaCrudo(codFamilia)
{
	var _i = this.iface;
	if (!codFamilia) {
		return false;
	}
	var codFamCrudo = _i.dameFamCrudo();
	if (!codFamCrudo) {
		return false;
	}
	return (codFamCrudo.find("'" + codFamilia + "'") >= 0);
}

function euromoda_esSubfamiliaCrudo(codSubfamilia)
{
	var _i = this.iface;
	if (!codSubfamilia) {
		return false;
	}
	var codSubfamCrudo = _i.dameSubfamCrudo();
	if (!codSubfamCrudo) {
		return false;
	}
	return (codSubfamCrudo.find("'" + codSubfamilia + "'") >= 0);
}

function euromoda_generarEstructura(curLinea)
{
	var _i = this.iface;
	switch (curLinea.table()) {
	case "lineaspedidosprov": {
	
			/// Las piezas de tela estampada o de tela en crudo no generan lote en el pedido, sino en el albar�n
			var referencia = curLinea.valueBuffer("referencia");
			if (!referencia || referencia == "") {
				return true;
			}			
			/// Los productos fabricados no generan lote desde l�neas de pedido proveedor, sino desde �rdenes de producci�n
			var fabricado = AQUtil.sqlSelect("articulos", "fabricado", "referencia = '" + referencia + "'");		
			if (!_i.esReferenciaXPiezas(referencia) &&  !_i.esReferenciaXPartidas(referencia) && !fabricado) {
				return _i.__generarEstructura(curLinea);
			}		
			var codLote = curLinea.isNull("codloteprod") ? false : curLinea.valueBuffer("codloteprod");
			if (codLote) {
				var idMovLote = AQUtil.sqlSelect("movistock", "idmovimiento", "codlote = '" + codLote + "' AND cantidad = " + curLinea.valueBuffer("cantidad") + " AND estado = 'PTE'");
				if (idMovLote) {
					//el concepto del movimiento se modifica para que sea igual que el concepto como si viniera de un pedido que no tiene lote.
					var aDatosStockLinea = _i.dameDatosStockLinea(curLinea);					
					if (!AQSql.update("movistock", ["idlineapp","concepto"], [curLinea.valueBuffer("idlinea"), aDatosStockLinea.concepto], "idmovimiento = " + idMovLote)) {
						return false;
					}
				} else {
					if (!_i.generarMoviStock(curLinea, codLote, false, false, false)) {
						return false;
					}
				}
			} else {
				if (!_i.generarMoviStock(curLinea, false, false, false, false)) {
					return false;
				}
			}
			break;
		}
	case "lineasalbaranesprov": {
			var referencia = curLinea.valueBuffer("referencia");
			if (!referencia || referencia == "") {
				return true;
			}
			/// Los productos fabricados no generan lote desde l�neas de pedido proveedor, sino desde �rdenes de producci�n
			var fabricado = AQUtil.sqlSelect("articulos", "fabricado", "referencia = '" + referencia + "'");
			if (!fabricado) {
				return _i.__generarEstructura(curLinea);
			}
			if (curLinea.isNull("codloteprod")) {
				/// Art�culos fabricados que se compran
				return _i.__generarEstructura(curLinea);
				/*
				/// Art�culos fabricados que se dan de alta por venir de �rdenes del GIT no terminadas antes de la migraci�n
				var curA = curLinea.cursorRelation();
				var codProveedor;
				if (!curA || curA.table() != "albaranesprov") {
					codProveedor = AQUtil.sqlSelect("albaranesprov", "codproveedor", "idalbaran = " + curLinea.valueBuffer("idalbaran"));
				} else {
					codProveedor = curA.valueBuffer("codproveedor");
				}
				var oProv = flfactppal.iface.pub_ejecutarQry("proveedores", "codalmacen,emdescontarmat", "codproveedor = '" + codProveedor + "'");
				if (oProv.result != 1) {
					return false;
				}
				if (oProv.emdescontarmat) {
					if (!oProv.codalmacen || oProv.codalmacen == "") {
						sys.warnMsgBox(sys.translate("El proveedor del albar�n no tiene un almac�n asociado"));
						return false;
					}
					if (!_i.__generarEstructura(curLinea)) {
						return false;
					}
					var codLote = AQUtil.sqlSelect("movistock", "codlote", "idlineaap = " + curLinea.valueBuffer("idlinea"));
					if (!_i.generaConsumosProducto(curLinea.valueBuffer("referencia"), curLinea.valueBuffer("cantidad"), false, codLote, oProv.codalmacen, false, true)) {
						return false;
					}
				}
				*/
			} else {
				var codLote = curLinea.valueBuffer("codloteprod");
				if (!_i.generarMoviStock(curLinea, codLote, false, false, false)) {
					return false;
				}
				if (!_i.revisaReservasLoteProd(codLote)) { 
					return false;
				}
			}
			break;
		}
	case "lineaspedidoscli": {
			/// Aunque el art�culo sea de fabricado por lotes, en principio se crea s�lo el movimiento y luego se crear� o no el lote
			
			//movida para pasar la cantidad
			// si no es prenda, es un tejido		
			var referencia = curLinea.valueBuffer("referencia");
			var cantidad  = _i.establecerCantidad(curLinea);
			//if(flfactalma.iface.esReferenciaXPiezas(curStock.valueBuffer("referencia"))) {
			if(flfactalma.iface.esReferenciaXPiezas(referencia)) {
				var codSubfamilia = AQUtil.sqlSelect("articulos","codsubfamilia","referencia = '" + referencia + "'");	
				cantidad = fleumoesta.iface.dameCantidadMargenLT(referencia, codSubfamilia, cantidad, true);				
			}	
			
			if (!this.iface.generarMoviStock(curLinea, false, cantidad, false, false)) {
				return false;
			}
			//      if (!_i.generaConsumosLineaPedidoCli(curLinea)) {
			//        return false;
			//      }
			break;
		}
	case "lineaspedidomarcocli": {
			var estado;
			var curR = curLinea.cursorRelation();
			if (curR) {
				estado = curR.valueBuffer("emestado");
			} else {
				estado = AQUtil.sqlSelect("pedidosmarcocli", "emestado", "codpedidomarco = '" + curLinea.valueBuffer("codpedidomarco") + "'");
			}
			if (estado != "Pendiente") {
				return true;
			}
			if (!this.iface.generarMoviStock(curLinea, false, false, false, false)) {
				return false;
			}
			break;
		}
	case "em_traspasosstock": {
			//      if (_i.esReferenciaXPiezas(curLinea.valueBuffer("refdesde")) || _i.esReferenciaXPiezas(curLinea.valueBuffer("refhasta"))) {
			//        MessageBox.warning(sys.translate("No puede realizar un traspaso de tejido estampado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			//        return false;
			//      }
			var codAlmacen = curLinea.valueBuffer("codalmacen");
			var codTraspaso = curLinea.valueBuffer("codtraspaso");
			var cantidad = curLinea.valueBuffer("cantidad");
			var oArtDesde = new Object;
			oArtDesde.referencia = curLinea.valueBuffer("refdesde");
			var idStockDesde = _i.dameIdStock(codAlmacen, oArtDesde);
			if (!idStockDesde) {
				return false;
			}
			if (!_i.curMoviStock) {
				_i.curMoviStock = new FLSqlCursor("movistock");
			}
			_i.curMoviStock.setModeAccess(_i.curMoviStock.Insert);
			_i.curMoviStock.refreshBuffer();
			_i.curMoviStock.setValueBuffer("em_codtraspaso", codTraspaso);
			_i.curMoviStock.setValueBuffer("estado", "HECHO");
			_i.curMoviStock.setValueBuffer("fechareal", curLinea.valueBuffer("fecha"));
			_i.curMoviStock.setValueBuffer("horareal", curLinea.valueBuffer("hora"));
			_i.curMoviStock.setValueBuffer("cantidad", (cantidad * -1));
			_i.curMoviStock.setValueBuffer("idstock", idStockDesde);
			_i.curMoviStock.setValueBuffer("concepto", sys.translate("Traspaso stock %1").arg(curLinea.valueBuffer("codtraspaso")));
			var codLote;
			if (!curLinea.isNull("codlotedesde")) {
				codLote = curLinea.valueBuffer("codlotedesde");
				_i.curMoviStock.setValueBuffer("codlote", codLote);
			}
			
			if (!_i.datosArticuloMS(oArtDesde)) {
				return false;
			}
			if (!_i.curMoviStock.commitBuffer()) {
				MessageBox.critical(util.translate("scripts", "Error: No pudo crearse el movimiento de stock para el art�culo %1 y el almac�n %2").arg(oArtDesde["referencia"]).arg(codAlmacen), MessageBox.Ok, MessageBox.NoButton);
				return false;
			}
			
			var oArtHasta = new Object;
			oArtHasta.referencia = curLinea.valueBuffer("refhasta");
			var idStockHasta = _i.dameIdStock(codAlmacen, oArtHasta);
			if (!idStockHasta) {
				return false;
			}
			var canHasta = curLinea.isNull("canhasta") ? curLinea.valueBuffer("cantidad") : curLinea.valueBuffer("canhasta");
			_i.curMoviStock.setModeAccess(_i.curMoviStock.Insert);
			_i.curMoviStock.refreshBuffer();
			_i.curMoviStock.setValueBuffer("em_codtraspaso", codTraspaso);
			_i.curMoviStock.setValueBuffer("estado", "HECHO");
			_i.curMoviStock.setValueBuffer("fechareal", curLinea.valueBuffer("fecha"));
			_i.curMoviStock.setValueBuffer("horareal", curLinea.valueBuffer("hora"));
			_i.curMoviStock.setValueBuffer("cantidad", canHasta);
			_i.curMoviStock.setValueBuffer("idstock", idStockHasta);
			_i.curMoviStock.setValueBuffer("concepto", sys.translate("Traspaso stock %1").arg(curLinea.valueBuffer("codtraspaso")));
			if (!curLinea.isNull("codlotedesde")) {
				var aDatosArt = new Object();
				aDatosArt.referencia = curLinea.valueBuffer("refhasta");
				aDatosArt.codalmacen = codAlmacen;
				aDatosArt.codproveedor = AQUtil.sqlSelect("lotesstock", "codproveedor", "codlote = '" + codLote + "'");
				aDatosArt.codpedidoprov = AQUtil.sqlSelect("lotesstock", "codpedidoprov", "codlote = '" + codLote + "'");
				var codLoteHasta = _i.crearLote(aDatosArt, canHasta);
				if (!codLoteHasta) {
					return false;
				}
				_i.curMoviStock.setValueBuffer("codlote", codLoteHasta);
			}
			if (!_i.datosArticuloMS(oArtHasta)) {
				return false;
			}
			if (!_i.curMoviStock.commitBuffer()) {
				MessageBox.critical(util.translate("scripts", "Error: No pudo crearse el movimiento de stock para el art�culo %1 y el almac�n %2").arg(oArtHasta["referencia"]).arg(codAlmacen), MessageBox.Ok, MessageBox.NoButton);
				return false;
			}
			break;
		}
	default: {
			return _i.__generarEstructura(curLinea);
		}
	}
	return true;
}

function euromoda_asignarMoviStockSinLote(codLote)
{
	return true; /// Evita que salte al generar piezas de tejido estampado
}

function euromoda_generaConsumosLineaPedidoCli(curLinea)
{
	var _i = this.iface;
	var v = curLinea.valueBuffer;
	if (!AQUtil.sqlSelect("lotesstock", "codlote", "idlineapc = " + v("idlinea"))) {
		var codAlmacen;
		var curPedido = curLinea.cursorRelation();
		if (curPedido) {
			codAlmacen = curPedido.valueBuffer("codalmacen");
		} else {
			codAlmacen = AQUtil.sqlSelect("pedidoscli", "codalmacen", "idpedido = " + v("idpedido"));
		}
		if (!_i.generaConsumosProducto(v("referencia"), v("cantidad"), v("idlinea"), false, codAlmacen, true)) {
			return false;
		}
	}
	return true;
}

function euromoda_borrarLote(codLote, curMS)
{
	// debug("euromoda_borrarLote");
	var _i = this.iface;
	if (AQUtil.sqlSelect("em_tramostejido", "idtramo", "codpartida = '" + codLote + "'") || AQUtil.sqlSelect("em_tramostejido", "idtramo", "codpartidaorigen = '" + codLote + "'")) {
		// No borramos lotes con tramos asociados
		return true;
	}
	var idMov = curMS.valueBuffer("idmovimiento");
	if (!AQUtil.sqlSelect("movistock", "idmovimiento", "codlote = '" + codLote + "' AND idmovimiento <> " + idMov + " AND (idproceso = 0 OR idproceso IS NULL)")) {
		/// Los lotes asociados a una orden no se borran autom�ticamente, se sacan de forma manual de la orden
		if (AQUtil.sqlSelect("lotesstock", "codordenproduccion", "codlote = '" + codLote + "'")) {			
			return true;
		}
		var codPedido = AQUtil.sqlSelect("movistock ms INNER JOIN lineaspedidosprov lp ON ms.idlineapp = lp.idlinea INNER JOIN pedidosprov p ON lp.idpedido = p.idpedido", "p.codigo", "ms.codpartida = '" + codLote + "'", "pedidosprov");
		if (codPedido) {
			sys.warnMsgBox(sys.translate("La partida %1 ya est� siendo usada en el pedido %2. No es posible eliminarla").arg(codLote).arg(codPedido));
			return false;
		}
		
		if (!AQUtil.sqlDelete("lotesstock", "codlote = '" + codLote + "'")) {
			return false;
		}
	}
	return true;
}

function euromoda_albaranarLineaPedProv(curLA)
{
	var _i = this.iface;
	var referencia = curLA.valueBuffer("referencia");
	if (_i.esReferenciaXPiezas(referencia)) {
		return true;
	}
	//   var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
	//  if (_i.esFamiliaEstampado(codFamilia)) {
	//     return true;
	//   }
	
	if (!_i.__albaranarLineaPedProv(curLA)) {
		return false;
	}
	return true;
}

function euromoda_desalbaranarLineaPedProv(curLA)
{
	var _i = this.iface;
	var referencia = curLA.valueBuffer("referencia");
	if (_i.esReferenciaXPiezas(referencia)) {
		return true;
	}
	//   var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + curLA.valueBuffer("referencia") + "'");
	//   if (_i.esFamiliaEstampado(codFamilia)) {
	//     return true;
	//   }
	
	if (!_i.__desalbaranarLineaPedProv(curLA)) {
		return false;
	}
	return true;
}

function euromoda_generarMoviStock(curLinea, codLote, cantidad, curArticuloComp, idProceso)
{
	var _i = this.iface;
	
	var util = new FLUtil;
	var tabla = curLinea.table();
	
	switch (tabla) {
	case "lineaspedidosprov": {
//			debug("euromoda_generarMoviStock 1");
			/// Las l�neas cerradas de estampado se cuentan como merma.
			//        if (curLinea.valueBuffer("cerrada")) {
			var referencia = curLinea.valueBuffer("referencia");
			if (!_i.esReferenciaXPiezas(referencia)) {
				return _i.__generarMoviStock(curLinea, codLote, cantidad, curArticuloComp, idProceso);
			}
			//      var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
			//       if (!_i.esFamiliaEstampado(codFamilia)) {
			//         return _i.__generarMoviStock(curLinea, codLote, cantidad, curArticuloComp, idProceso);
			//       }
			//pozu pusimos s
			var datosArt;
			datosArt = this.iface.datosArticulo(curLinea, codLote);
			if (datosArt["referencia"] == "") {
//				debug("euromoda_generarMoviStock 2");
				return true;
			}
			cantidad = curLinea.valueBuffer("pendiente");
			//       debug("pendiente " + cantidad);
			var aDatosStockLinea: Array = this.iface.dameDatosStockLinea(curLinea, curArticuloComp);
			if (!aDatosStockLinea) {
//				debug("euromoda_generarMoviStock 3");
				return false;
			}
			
			if (!this.iface.curMoviStock) {
//				debug("euromoda_generarMoviStock 4");
				this.iface.curMoviStock = new FLSqlCursor("movistock");
			}
//			debug("euromoda_generarMoviStock 5 OK");
			aDatosStockLinea.cantidad = cantidad;
			aDatosStockLinea.idProceso = idProceso;
			aDatosStockLinea.codLote = codLote;
			
			if (!this.iface.creaRegMoviStock(curLinea, datosArt, aDatosStockLinea, curArticuloComp)) {
//				debug("euromoda_generarMoviStock 6");
				return false;
			}
			//      } else {
			//        if (!_i.__generarMoviStock(curLinea, codLote, cantidad, curArticuloComp, idProceso)) {
			//          return false;
			//        }
			//      }
			break;
		}
	default: {
			if (!_i.__generarMoviStock(curLinea, codLote, cantidad, curArticuloComp, idProceso)) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_revisarComponente(curAC, idLinea, codLote)
{
	var _i = this.iface;
	var res = new Array();
	
	res["referencia"] = curAC.valueBuffer("refcomponente");
	
	var f = curAC.valueBuffer("factor");
	f = f ? f : 1;
	var c = curAC.valueBuffer("cantidad");
	c = c ? c : 1;
	var cantidad = parseFloat(f) * parseFloat(c);
	res["cantidad"] = cantidad;
	return res;
}

function euromoda_afterCommit_lotesstock(curLote)
{
	var _i = this.iface;
	if (!_i.__afterCommit_lotesstock(curLote)) {
		return false;
	}
	if (!_i.controlCantidadLoteProducto(curLote)) {
		return false;
	}
	if (!_i.controlOrdenLote(curLote)) {
		return false;
	}
	if (!_i.controlStockLote(curLote)) {
		return false;
	}
	if (!_i.controlUbiacionPieza(curLote)) {
		return false;
	}
	
	return true;
}

/// Si la cantidad de un lote de producci�n cambia regeneramos los consumos y la cantidad de entrada prevista
function euromoda_controlCantidadLoteProducto(curLote)
{
//	debug("euromoda_controlCantidadLoteProducto");
	if (curLote.isNull("codordenproduccion")) {
		return true;
	}
	if (curLote.modeAccess() == curLote.Edit && curLote.valueBufferCopy("canlote") != curLote.valueBuffer("canlote")) {
		if (!formpr_generarordenesprodem.iface.pub_creaConsumosFT(curLote)) {
			return false;
		}
	}
	return true;
}

function euromoda_controlUbiacionPieza(curLote)
{
	// debug("euromoda_controlUbiacionPieza " + curLote.valueBuffer("ubicacion"));
	var _i = this.iface;
	var referencia = curLote.valueBuffer("referencia");
	
	var codAlmacen = curLote.valueBuffer("codalmacen");
	if (!_i.esReferenciaXPiezas(referencia)) {
		return true;
	}
	//  var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
	//  if (!_i.esFamiliaEstampado(codFamilia)) {
	//    return true;
	//  }
	var ubicacion = curLote.valueBuffer("ubicacion");
	switch (curLote.modeAccess()) {
	case curLote.Insert: {
			if (ubicacion) {
				if (!_i.actualizaUbicacionStock(referencia, codAlmacen, ubicacion)) {
					return false;
				}
			}
			break;
		}
	case curLote.Edit: {
			var ubicacionPrevia = curLote.valueBufferCopy("ubicacion");
			if (ubicacion && ubicacion != ubicacionPrevia) {
				if (!_i.actualizaUbicacionStock(referencia, codAlmacen, ubicacion)) {
					return false;
				}
			}
			break;
		}
	}
	return true;
}

function euromoda_actualizaUbicacionStock(referencia, codAlmacen, ubicacion)
{
	// debug("euromoda_actualizaUbicacionStock ref " + referencia + " almacen " + codAlmacen + " ubicacion "  + ubicacion);
	if (!AQSql.update("stocks", ["ubicacion"], [ubicacion], "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'")) {
		return false;
	}
	return true;
}

function euromoda_controlStockLote(curLote)
{
	var _i = this.iface;
    //debug("tarda un huevo_9__");
	var referencia = curLote.valueBuffer("referencia");
	if (!_i.esReferenciaXPartidas(referencia)) {
		return true;
	}
    //debug("tarda un huevo_10__");
	//  var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
	//  if (!_i.esFamiliaCrudo(codFamilia)) {
	//    return true;
	//  }
	var codAlmacen = curLote.valueBuffer("codalmacen");
	// debug("codAlmacen " + codAlmacen );
	switch (curLote.modeAccess()) {
	case curLote.Insert:
	case curLote.Del: {
            //debug("tarda un huevo_11__");
			var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
			if (!idStock) {
				var oArticulo = new Object;
				oArticulo.referencia = referencia;
				idStock = _i.crearStock(codAlmacen, oArticulo);
				if (!idStock) {
					return false;
				}
			}
            //debug("tarda un huevo_12__");
			if (!_i.actualizarStock(idStock)) {
				return false;
			}
            //debug("tarda un huevo_13__");
			break;
		}
	case curLote.Edit: {
            //debug("tarda un huevo_14__");
			var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
			if (!idStock) {
				var oArticulo = new Object;
				oArticulo.referencia = referencia;
				idStock = _i.crearStock(codAlmacen, oArticulo);
				if (!idStock) {
					return false;
				}
			}
            //debug("tarda un huevo_15__");
			if (!_i.actualizarStock(idStock)) {
				return false;
			}
            //debug("tarda un huevo_16__");
			var pteDistribuir = curLote.valueBuffer("mptedist");
			var distFin = curLote.valueBuffer("distribucionfin");
			
			var referenciaAnt = curLote.valueBufferCopy("referencia");
			var codAlmacenAnt = curLote.valueBufferCopy("codalmacen");
			var pteDistribuirAnt = curLote.valueBufferCopy("mptedist");
			var distFinAnt = curLote.valueBufferCopy("distribucionfin");
            //debug("tarda un huevo_17__");
			if (referencia != referenciaAnt || codAlmacen != codAlmacenAnt || pteDistribuir != pteDistribuirAnt || distFin != distFinAnt) {
				idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referenciaAnt + "' AND codalmacen = '" + codAlmacenAnt + "'");
				if (!idStock) {
					oArticulo.referencia = referenciaAnt;
					idStock = _i.crearStock(codAlmacenAnt, oArticulo);
					if (!idStock) {
						return false;
					}
				}
                //debug("tarda un huevo_18__");
				if (!_i.actualizarStock(idStock)) {
					return false;
				}
			}
            //debug("tarda un huevo_19__");
			break;
		}
	}
    //debug("tarda un huevo_20__");
	return true;
}

function euromoda_controlOrdenLote(curLote)
{
	var _i = this.iface;
	var codOrden = curLote.valueBuffer("codordenproduccion")
								 switch (curLote.modeAccess()) {
	case curLote.Insert: {
			if (!_i.actualizaOrdenLote(codOrden)) {
				return false;
			}
			break;
		}
	case curLote.Edit: {
			var codOrdenPrevia = curLote.valueBufferCopy("codordenproduccion");
			if (codOrdenPrevia != codOrden || curLote.valueBuffer("canlote") != curLote.valueBufferCopy("canlote")) {
				if (codOrdenPrevia != codOrden) {
					if (!_i.actualizaOrdenLote(codOrdenPrevia)) {
						return false;
					}
				}
				if (!_i.actualizaOrdenLote(codOrden)) {
					return false;
				}
			}
			break;
		}
	case curLote.Del: {
			if (!_i.actualizaOrdenLote(codOrden)) {
				return false;
			}
			break;
		}
	}
	return true;
}

function euromoda_actualizaOrdenLote(codOrden)
{
	if (!codOrden || codOrden == "") {
		return true;
	}
	var qLote = new FLSqlQuery;
	qLote.setSelect("fechafabricacion, codcliente, codlote, canlote");
	qLote.setFrom("lotesstock");
	qLote.setWhere("codordenproduccion = '" + codOrden + "'");
	qLote.setForwardOnly(true);
	if (!qLote.exec()) {
		return false;
	}
	var fechaEntrega = undefined;
	var codCliente = undefined;
	var fechaFab, codCli;
	var totalLotes = 0, totalUds = 0;
//	debug(qLote.sql());
	while (qLote.next()) {
		totalLotes++;
		totalUds += parseFloat(qLote.value("canlote"));
//		debug(qLote.value("codlote") + " totalLotes " + totalLotes + " totalUds " + totalUds);
		codCli = qLote.value("codcliente");
		if (!codCli || codCli == "") {
			codCliente = "no unico";
		}
		if (codCliente != "no unico") {
			if (codCli) {
				if (codCliente == undefined) {
					codCliente = codCli;
				} else {
					if (codCliente != codCli) {
						codCliente = "no unico";
					}
				}
			}
		}
	}
	codCliente = codCliente == "no unico" ? undefined : codCliente;
	totalLotes = isNaN(totalLotes) ? 0 : totalLotes;
	totalUds = isNaN(totalUds) ? 0 : totalUds;
	//  var nombreCliente = codCliente ? AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + codCliente + "'") : undefined;
	
	if (!AQSql.update("pr_ordenesproduccion", ["totallotes", "totaluds"], [totalLotes, totalUds], "codorden = '" + codOrden + "'")) {
		return false;
	}
	return true;
}

function euromoda_datosProcesoArticulo(referencia)
{
	var _i = this.iface;
	var aDatos = _i.__datosProcesoArticulo(referencia);
	if (!aDatos) {
		return false;
	}
	aDatos["procesoporlote"] = false;
	
	return aDatos;
}

function euromoda_generarLoteStock(curLinea, cantidad, curArticuloComp, idProceso)
{
	var _i = this.iface;
	var codLote;
	var referencia;
	switch (curLinea.table()) {
	case "lineaspedidosprov": {
			codLote = curLinea.valueBuffer("codloteprod");
			if (!codLote || codLote == "") {
				if (!curLinea.valueBuffer("cerrada") && curLinea.valueBufferCopy("cerrada")) {
		        /// Para l�neas que estaban cerradas se busca el lote original, asociado a otro movimiento ya hecho de la misma l�nea
		        codLote = util.sqlSelect("movistock", "codlote", "idlineapp = " + curLinea.valueBuffer("idlinea") + " AND estado = 'HECHO'");
		      }
		      var datosArt = _i.datosArticulo(curLinea);
		      if (!codLote) {
		        codLote = _i.crearLote(datosArt, curLinea.valueBuffer("cantidad"), false, false, curLinea.valueBuffer("codformato"));
		        if (!codLote) {
		          return false;
		        }
		      }
		      if (!_i.generarMoviStock(curLinea, codLote, false, false, idProceso)) {
		        return false;
		      }
			}
			else {
				if (!cantidad) {
					cantidad = curLinea.valueBuffer("cantidad");
				}
				var idM = AQUtil.sqlSelect("movistock", "idmovimiento", "codlote = '" + codLote + "' AND cantidad = " + cantidad + " AND estado = 'PTE' AND idlineapp IS NULL");
				if (idM) {
					/// Se trata del movimiento de alta de stock creado al asociar el lote a la orden de producci�n
					if (!AQSql.update("movistock", ["idlineapp"], [curLinea.valueBuffer("idlinea")], "idmovimiento = " + idM)) {
						return false;
					}
				} else {
					if (!_i.generarMoviStock(curLinea, codLote, false, false, idProceso)) {
						return false;
					}
				}
			}
			break;
		}
	case "lineasalbaranesprov": {
			codLote = curLinea.valueBuffer("codloteprod");
			if (!codLote || codLote == "") {
				var datosArt = _i.datosArticulo(curLinea);
				codLote = _i.crearLote(datosArt, curLinea.valueBuffer("cantidad"), false, false, curLinea.valueBuffer("codformato"));
				if (!codLote) {
					return false;
				}
				if (!_i.generarMoviStock(curLinea, codLote, false, false, idProceso)) {
					return false;
				}
			}
			else {
				/// Las l�neas con lote informado son las de productos terminados. No se genera el lote porque ya existe.
				if (!cantidad) {
					cantidad = curLinea.valueBuffer("cantidad");
				}
				if (!_i.generarMoviStock(curLinea, codLote, false, false, idProceso)) {
					return false;
				}
			}
			break;
		}
	case "lineaspedidomarcocli": {
			var curPM = curLinea.cursorRelation();
			if (!curPM) {
				curPM = new FLSqlCursor("pedidosmarcocli");
				curPM.select("codpedidomarco = '" + curLinea.valueBuffer("codpedidomarco") + "'");
				if (!curPM.first()) {
					return false;
				}
				curPM.setModeAccess(curPM.Browse);
				curPM.refreshBuffer();
			}
			if (!curPM.valueBuffer("activo")) {
				return true;
			}
			var datosArt = _i.datosArticulo(curLinea);
			codLote = _i.crearLote(datosArt, curLinea.valueBuffer("canpendiente"));
			if (!codLote) {
				return false;
			}
			if (!_i.generarMoviStock(curLinea, codLote, false, false, idProceso)) {
				return false;
			}
			break;
		}
	default: {
			return _i.__generarLoteStock(curLinea, cantidad, curArticuloComp, idProceso);
		}
	}
	
	if (!_i.consistenciaLinea(curLinea)) {
		return false;
	}
	return true;
}

function euromoda_controlStockPedidosMarcoCli(curLP)
{
	var util: FLUtil = new FLUtil;
	if (util.sqlSelect("articulos", "nostock", "referencia = '" + curLP.valueBuffer("referencia") + "'")) {
		return true;
	}
	switch (curLP.modeAccess()) {
	case curLP.Insert: {
			if (!this.iface.generarEstructura(curLP)) {
				return false;
			}
			break;
		}
	case curLP.Edit: {
			///if (this.iface.datosStockLineaCambian(curLP)) { /// Eliminado porque el c�lculo depende de la cabecera del pedido marco (campo emestado)
			if (!this.iface.borrarEstructura(curLP)) {
				return false;
			}
			if (!this.iface.generarEstructura(curLP)) {
				return false;
			}
			//}
			break;
		}
	case curLP.Del: {
			if (!this.iface.borrarEstructura(curLP)) {
				return false;
			}
			break;
		}
	}
	
	return true;
}
/*
function euromoda_controlStockPrevisto(curLinea, codAlmacen)
{
	var _i = this.iface;
	var referencia = curLinea.valueBuffer("referencia");
	if (referencia && referencia != "") {
		if (!_i.actualizaStockPrevisto(referencia, codAlmacen)) {
			return false;
		}
	}
	
	var referenciaPrevia = curLinea.valueBufferCopy("referencia");
	if (referenciaPrevia && referenciaPrevia != "" && referenciaPrevia != referencia) {
		if (!_i.actualizaStockPrevisto(referenciaPrevia, codAlmacen)) {
			return false;
		}
	}
	
	return true;
}
*/
function euromoda_actualizaStockPrevisto(referencia, codAlmacen)
{
	var _i = this.iface;
	var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
	if (!idStock) {
		var oArticulo = new Object;
		oArticulo.referencia = referencia;
		idStock = this.iface.crearStock(codAlmacen, oArticulo);
		if (!idStock) {
			return false;
		}
	}
	
	var curStock: FLSqlCursor = new FLSqlCursor("stocks");
	curStock.select("idstock = " + idStock);
	if (!curStock.first()) {
		return false;
	}
	curStock.setModeAccess(curStock.Edit);
	curStock.refreshBuffer();
	curStock.setValueBuffer("prevision", formRecordregstocks.iface.pub_commonCalculateField("prevision", curStock));
	if (!curStock.commitBuffer()) {
		return false;
	}
	return true;
}

function euromoda_cambiarCosteMedio(referencia)
{
	return true;
	if (referencia == "") {
		return true;
	}	
	var coste = AQUtil.sqlSelect("lineasfacturasprov lf INNER JOIN facturasprov f ON lf.idfactura = f.idfactura", "lf.pvpunitario", "lf.referencia = '" + referencia + "' ORDER BY f.fecha DESC, f.idfactura DESC", "lineasfacturasprov,facturasprov");
	//   debug("select lf.pvpunitario from lineasfacturasprov lf INNER JOIN facturasprov f ON lf.idfactura = f.idfactura where lf.referencia = '" + referencia + "' ORDER BY f.fecha DESC, f.idfactura DESC");
	if (!coste) {
		return true;
	}
	//coste = isNaN(coste) ? 0 : coste, //pineboo 21-08-2019
	if(isNaN(coste)) {
		coste = 0;
	}
	
	if (!AQSql.update("articulos", ["costemedio"], [coste], "referencia = '" + referencia + "'")) {
		return false;
	}
	
	return true;
}

function euromoda_datosRevisarEstadoLote(curLote)
{
	var _i = this.iface;
	if (!_i.__datosRevisarEstadoLote(curLote)) {
		return false;
	}
	curLote.setValueBuffer("msalidas", formRecordlotesstock.iface.pub_commonCalculateField("msalidas", curLote));
	curLote.setValueBuffer("mptedist", formRecordlotesstock.iface.pub_commonCalculateField("mptedist", curLote));
	curLote.setValueBuffer("fechaentradaem", formRecordlotesstock.iface.pub_commonCalculateField("fechaentradaem", curLote));
	curLote.setValueBuffer("distribucionfin", formRecordlotesstock.iface.pub_commonCalculateField("distribucionfin", curLote));
	//debug("//28-07-2015");	
	//curLote.setValueBuffer("canlote", formRecordlotesstock.iface.pub_commonCalculateField("canlote", curLote));
	return true;
}

/// Evita que se cree el movimiento en la migraci�n inicial. Luego no debe ser usado nunca
function euromoda_crearMovRegularizacionLote(codLote, cantidad)
{
	return true;
}

function euromoda_preguntarSiCrearLote(codLote)
{
	/// No pregunta al usuario
	return codLote;
}

/// Pasa de A Faltas a Reservado (o viceversa) los componentes con reservar = fase en la composici�n.
// function euromoda_revisarStocksComponentesLote(codLote)
// {
//  var _i = this.iface;
//  var q = new FLSqlQuery;
//  q.setSelect("ms.idstock");
//  q.setFrom("movistock ms LEFT OUTER JOIN articuloscomp ac ON ms.idarticulocomp = ac.id");
//  q.setWhere("ms.codloteprod = '" + codLote + "' AND ms.estado = 'PTE' AND ms.cantidad < 0  AND (ms.idarticulocomp IS NOT NULL AND NOT ac.reservar)");
//  q.setForwardOnly(true);
//  if (!q.exec()) {
//    return false;
//  }
//  while (q.next()) {
//    if (!formregstocks.iface.revisarStock("idstock = " + q.value("ms.idstock"))) {
//      return false;
//    }
//  }
//  return true;
// }

function euromoda_generarMoviStockComponentes(aDatosArt, idProceso)
{
	return false;
}

function euromoda_crearComposicion(curLoteStock, curComponente, refProceso, idProceso, primeraLlamada)
{
	return true;/// Las composiciones se crean con una llamada directa a pr_generarordenesprodem.creaConsumosFT
}


function euromoda_dameEmbalajeArticulo(referencia, codCliente, mostrarSMS)
{
	


	var _i = this.iface;
	// debug("Caja de " + referencia);
	var encontrado =false;
	var aDatos = false;
	var q = new FLSqlQuery;
	q.setSelect("te1.referencia, a.unidadesemb, a.codsubfamilia,a.codtamanoem,a.codcoleccionem");
	q.setFrom("articulos a LEFT OUTER JOIN em_tiposemb te1 ON a.em_codtipoemb = te1.em_codtipoemb");
	q.setWhere("a.referencia = '" + referencia + "'");
	q.setForwardOnly(true);
	
	if (!q.exec()) {
		return false;
	}
	if (!q.first()) {
		MessageBox.warning(sys.translate("No se ha encontrado datos de embalaje para el art�culo %1").arg(referencia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false
	}
	aDatos = new Object;
	if (q.value("te1.referencia") && q.value("te1.referencia") != "") {			
		
		//1. si tiene informada en su ficha los datos de tipo de embalaje y unidades por embalaje cogemos estos
		aDatos.referencia = q.value("te1.referencia");
		aDatos.capacidad = q.value("a.unidadesemb");

		encontrado = true;

	} 
	if(!encontrado) {
		var codSubfamilia = q.value("a.codsubfamilia");
		var codTamano = q.value("a.codtamanoem");
		var codColeccion = q.value("a.codcoleccionem");

		if(codCliente && codCliente != "") {
			//2.Busqueda por subfamilia-tama�o-coleccion-cliente

			var q2 = new FLSqlQuery;
			q2.setSelect("te1.referencia, s.em_unidadesemb");
			q2.setFrom("em_embsubfamclicol s LEFT OUTER JOIN em_tiposemb te1 ON s.em_codtipoemb = te1.em_codtipoemb");
			q2.setWhere("s.codsubfamilia = '" + codSubfamilia + "' and s.codtamanoem = '" + codTamano + "' and s.codcoleccionem = '" + codColeccion + "' and s.codcliente = '" + codCliente + "'");					
			
			if (!q2.exec()) {
				return false;
			}
			if (q2.first()) {
				
				aDatos.referencia = q2.value("te1.referencia");
				aDatos.capacidad = q2.value("s.em_unidadesemb");
				encontrado = true;
			}
			if(!encontrado) {
				//3.Busqueda por subfamilia-tama�o-cliente
				var q3 = new FLSqlQuery;
				q3.setSelect("te1.referencia, s.em_unidadesemb");
				q3.setFrom("em_embsubfamclicol s LEFT OUTER JOIN em_tiposemb te1 ON s.em_codtipoemb = te1.em_codtipoemb");
				q3.setWhere("s.codsubfamilia = '" + codSubfamilia + "' and s.codtamanoem = '" + codTamano + "' and s.codcliente = '" + codCliente + "' AND (s.codcoleccionem is null or s.codcoleccionem ='')");					
				
				if (!q3.exec()) {
					return false;
				}
				if (q3.first()) {
					
					aDatos.referencia = q3.value("te1.referencia");
					aDatos.capacidad = q3.value("s.em_unidadesemb");
					encontrado = true;
				}
			}
		} 

		if(!encontrado) {
			//4. Busqueda por subfamilia-tama�o-coleccion
			var q4 = new FLSqlQuery;
			q4.setSelect("te1.referencia, s.em_unidadesemb");
			q4.setFrom("em_embsubfamclicol s LEFT OUTER JOIN em_tiposemb te1 ON s.em_codtipoemb = te1.em_codtipoemb");
			q4.setWhere("s.codsubfamilia = '" + codSubfamilia + "' and s.codtamanoem = '" + codTamano + "' and s.codcoleccionem = '" + codColeccion + "' and (s.codcliente is null or s.codcliente = '')");					
			
			if (!q4.exec()) {
				return false;
			}
			if (q4.first()) {
				
				aDatos.referencia = q4.value("te1.referencia");
				aDatos.capacidad = q4.value("s.em_unidadesemb");
				encontrado = true;
			}
		}
		if(!encontrado) {
			//5. Busqueda por tama�o de subfamilia 

			var q5 = new FLSqlQuery;
			q5.setSelect("te2.referencia, t.unidadesemb");
			q5.setFrom("articulos a LEFT OUTER JOIN em_tamanossubfam t ON (a.codsubfamilia = t.codsubfamilia AND a.codtamanoem = t.codtamanoem) LEFT JOIN em_tiposemb te2 ON t.em_codtipoemb = te2.em_codtipoemb");
			q5.setWhere("a.referencia = '" + referencia + "'");
			q5.setForwardOnly(true);
			
			if (!q5.exec()) {
				return false;
			}
			if (q5.first()) {
				
				aDatos.referencia = q5.value("te2.referencia");
				aDatos.capacidad = q5.value("t.unidadesemb");
				encontrado = true;
			}
		}
	}
	if(!encontrado || (isNaN(aDatos.capacidad) || aDatos.capacidad == 0)) {		
		if(mostrarSMS) {
			MessageBox.warning(sys.translate("Error al buscar la unidades por embalaje del art�culo %1.\nDebe verificar que este dato est� informado en la ficha del art�culo, en la ficha de la subfamilia o en la de tama�o por subfamilia.").arg(referencia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
			return false;
		} else {
			
			return true;
		}

	}
	// debug("Caja = " + aDatos.referencia + " de " + aDatos.capacidad + " unidades");
	return aDatos;
}

function euromoda_acumulaLotesPendientes(curLote)
{
	// debug("oficial_acumulaLotesPendientes " );
	
	var _i = this.iface;
	var canDispFutura = curLote.valueBuffer("canlote") - curLote.valueBuffer("canreservada");
	var hayMas = true;
	var canLote;
	var q = new FLSqlQuery();
	while (hayMas) {
		q.setSelect("l.codlote, l.canlote, p.fechaservicio");
		q.setFrom("lotesstock l INNER JOIN movistock ms ON l.codlote = ms.codlote INNER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido INNER JOIN series s ON p.codserie = s.codserie");
		q.setWhere("l.estado = 'PTE' AND l.codordenproduccion IS NULL AND l.referencia = '" + curLote.valueBuffer("referencia") + "' AND l.canlote <= " + canDispFutura + " AND NOT s.exportprod ORDER BY p.fechaservicio");
		q.setForwardOnly(true)
				if (!q.exec()) {
			return false;
		}
		if (q.first()) {
			//  debug("oficial_acumulaLotesPendientes " );
			if (!_i.fundeLotes(curLote.valueBuffer("codlote"), q.value("l.codlote"))) {
				return false;
			}
			canLote = q.value("l.canlote");
			canLote = isNaN(canLote) ? 0 : canLote;
			if (canLote == 0) {
				hayMas = false;
			}
			canDispFutura -= canLote;
		} else {
			hayMas = false;
		}
	}
	return true;
}

/// Pasa los movimientos de stock del lote de pedido al lote de stock, y elimina el lote de pedido
function euromoda_fundeLotes(codLoteStock, codLotePed)
{
	var _i = this.iface;
	if (!AQSql.update("movistock", ["codlote"], [codLoteStock], "codlote = '" + codLotePed + "'")) {
		return false;
	}
	if (!AQSql.del("movistock", "codloteprod = '" + codLotePed + "'")) {
		return false;
	}
	if (!AQSql.del("lotesstock", "codlote = '" + codLotePed + "'")) {
		return false;
	}
	return true;
}

function euromoda_albaranarLineaPedCli(curLA)
{
	var _i = this.iface;
	if (curLA.valueBuffer("cantidad") == 0) { /// Para los albaranes distibuidos
		return true;
	} else {
		return _i.__albaranarLineaPedCli(curLA);
	}
}

function euromoda_establecerCantidad(curLinea)
{
	var _i = this.iface;
	var cantidad;
	switch (curLinea.table()) {
	case "lineaspedidomarcocli": {
			cantidad = curLinea.valueBuffer("canpendiente");
			break;
		}
	default: {
			cantidad = _i.__establecerCantidad(curLinea);
		}
	}
	return cantidad;
}

function euromoda_borrarMoviStock(curLinea)
{
	var _i = this.iface;
	var tabla = curLinea.table();
	var idLinea;
	//debug("XXXXXXXXXXXXXXXeuromoda_borrarMoviStock");
	switch (tabla) {
	case "lineaspedidomarcocli": {
			idLinea = curLinea.valueBuffer("idlinea");
			if (!AQUtil.sqlDelete("movistock", "idlineapm = " + idLinea))
				return false;
			break;
		}
	case "em_traspasosstock": {
			idLinea = curLinea.valueBuffer("codtraspaso");
			// debug("borrando " + idLinea);
			if (!AQUtil.sqlDelete("movistock", "em_codtraspaso = '" + idLinea + "'")) {
				return false;
			}
			break;
		}
	default: {
			if (!_i.__borrarMoviStock(curLinea)) {
				return false;
			}
		}
	}
	
	return true;
}

function euromoda_actualizarStocksMoviStock(curMS)
{
	//debug("tarda un huevo_6__");
	var _i = this.iface;
	if (_i.calculoStockBloqueado_) {
		return true;
	}
    //debug("tarda un huevo_7__");
	var idStock =  curMS.valueBuffer("idstock");
	var estado = curMS.valueBuffer("estado");
	var cantidad = curMS.valueBuffer("cantidad");

	switch (curMS.modeAccess()) {
		case curMS.Insert:
		case curMS.Del: {
			if (estado != "PREV") { 
				if (estado == "PTE") {
					if (cantidad > 0) {
						if (!_i.actualizarStockPteRecibir(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
							return false;
						}
					}
					if (cantidad < 0) {
						if (!_i.actualizarStockPteServir(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
							return false;
						}
					}
				} else {
					if (!_i.actualizarStock(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
						return false;
					}
				}
			} else {
				if (!_i.actualizarStockPrevisto(idStock)) {
					return false;
				}
			}
			break;
		}
		case curMS.Edit: {
			if (estado != "PREV") { 
				var estadoPrevio = curMS.valueBufferCopy("estado");
				var cantidadPrevia = curMS.valueBufferCopy("cantidad");
				if (estado != estadoPrevio) {
					if (estadoPrevio == "PTE") {
						if (cantidad > 0 || cantidadPrevia > 0) {
							if (!_i.actualizarStockPteRecibir(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
								return false;
							}
						}
						if (cantidad < 0 || cantidadPrevia < 0) {
							if (!_i.actualizarStockPteServir(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
								return false;
							}
						}
					} else {
						if (!_i.actualizarStock(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
							return false;
						}
					}
				}
				if (estado == "PTE") {
					if (cantidad > 0 || cantidadPrevia > 0) {
						if (!_i.actualizarStockPteRecibir(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
							return false;
						}
					}
					if (cantidad < 0 || cantidadPrevia < 0) {
						if (!_i.actualizarStockPteServir(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
							return false;
						}
					}
				} else {
					if (!_i.actualizarStock(idStock, curMS.valueBuffer("codsubfamiliatp"))) {
						return false;
					}
				}
			} else {
				if (!_i.actualizarStockPrevisto(idStock)) {
					return false;
				}			
			}
			break;
		}
	}
    //debug("tarda un huevo_8__");
	return true;
}

function euromoda_actualizarStockPrevisto(idStock)
{
	var _i = this.iface;
	var curStock = new FLSqlCursor("stocks");
	curStock.select("idstock = " + idStock);
	if (!curStock.first()) {
		return false;
	}
	curStock.setModeAccess(curStock.Edit);
	curStock.refreshBuffer();
	curStock.setValueBuffer("prevision", formRecordregstocks.iface.pub_commonCalculateField("prevision", curStock));
	if (!curStock.commitBuffer()) {
		return false;
	}
	return true;
}

/** Revisa las reservas de todos los movimientos de stock pendientes para el stock indicado
@param nivelComp: Indica si hay que revisar tambi�n las reservas de los componentes del art�culo del stock (nivelComp = 0)
@param nivelTejido: Indica si hay que revisar tambi�n las reservas de los tejidos preparados del art�culo del stock (nivelTejido = 0)
*/
function euromoda_revisarReservasStock(idStock, nivelComp, nivelTejido, codSubfamiliaTP)
{
	
	var _i = this.iface;
	var curStock = _i.abreCursorStock(idStock);
	if (!curStock) {
		return false;
	}
	if (!_i.totalizaReservasStock(curStock, nivelComp, nivelTejido, codSubfamiliaTP)) {
		return false;
	}
	
	return true;
}
function euromoda_calculaReservasStock(curStock)
{
	var _i = this.iface;
	
	var respuesta = "OK";	
	var idStock = curStock.valueBuffer("idstock");

	// Permite que la funci�n se pueda llamar desde el c�lculo de stock pte servir  y el pte recibir
	curStock.setValueBuffer("pterecibir", formRecordregstocks.iface.pub_commonCalculateField("pterecibir", curStock));
	
	var aReservas = new Object;
	var existencias = parseFloat(curStock.valueBuffer("cantidad"));
	existencias = isNaN(existencias) ? 0 : existencias;

	var qResIni = new AQSqlQuery();
	qResIni.setSelect("SUM(rpr.cantidad), mpr.estado");
	qResIni.setFrom("movistock ms INNER JOIN em_reservaspterx rpr ON ms.idmovimiento = rpr.idmovreserva INNER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
	qResIni.setWhere("ms.idstock = " + idStock + " AND mpr.cantidad > 0 AND ms.estado = 'PTE' AND mpr.estado IN ('HECHO', 'PTE') AND mpr.enreserva <> 0 GROUP BY mpr.estado");
	if (!qResIni.exec()) {
		return false;
	}
	var existenciasRes = 0, pteRecibirRes = 0;
	while (qResIni.next()) {
		if (qResIni.value("mpr.estado") == "PTE") {
			pteRecibirRes = parseFloat(qResIni.value("SUM(rpr.cantidad)"))
			pteRecibirRes = isNaN(pteRecibirRes) ? 0 : pteRecibirRes;	
		} else {
			existenciasRes = parseFloat(qResIni.value("SUM(rpr.cantidad)"))
			existenciasRes = isNaN(existenciasRes) ? 0 : existenciasRes;	
		}
	}	
	var pteRecibir = parseFloat(curStock.valueBuffer("pterecibir"));
	pteRecibir = isNaN(pteRecibir) ? 0 : pteRecibir;

	var enReservaPteRx = parseFloat(curStock.valueBuffer("enreservapterx"));
	enReservaPteRx = isNaN(enReservaPteRx) ? 0 : enReservaPteRx;

	//var disponible = Math.round(existencias - existenciasRes); 
	var disponible = existencias - existenciasRes;
	disponible = isNaN(disponible) ? 0 : disponible;
	disponible = parseFloat(AQUtil.roundFieldValue(disponible, "stocks", "cantidad"));

	if (disponible < 0 && existencias >= 0) {
		var aQuitar = disponible * -1;
		var qEx = new AQSqlQuery;
		qEx.setSelect("rpr.id, rpr.cantidad");
		qEx.setFrom("movistock ms INNER JOIN em_reservaspterx rpr ON ms.idmovimiento = rpr.idmovreserva INNER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
		qEx.setWhere("ms.idstock = " + idStock + " AND mpr.cantidad > 0 AND ms.estado = 'PTE' AND mpr.estado = 'HECHO' AND mpr.enreserva <> 0 ORDER BY ms.fechaprev DESC, ms.idmovimiento DESC");
		if (!qEx.exec()) {
			return false;
		}
		var quitable;
		var curRPR = new FLSqlCursor("em_reservaspterx");
		while (qEx.next() && aQuitar > 0) {
			curRPR.select("id = " + qEx.value("rpr.id"));
			if (!curRPR.first()) {
				return false;
			}
			curRPR.setModeAccess(curRPR.Edit);
			curRPR.refreshBuffer();
			quitable = curRPR.valueBuffer("cantidad");
			quitable -= aQuitar > quitable ? quitable : aQuitar;
			quitable = AQUtil.roundFieldValue(quitable, "em_reservaspterx", "cantidad");
			curRPR.setValueBuffer("cantidad", quitable);
			if (!curRPR.commitBuffer()) {
				return false;
			}
			aQuitar -= quitable;
		}
		aQuitar = AQUtil.roundFieldValue(aQuitar, "em_reservaspterx", "cantidad");
		pteRecibir -= aQuitar;	
		disponible = 0;		
	}
	if (pteRecibir < 0) {
		pteRecibir = 0;
	}	
	var disponibleRx = pteRecibir - pteRecibirRes;
	if (disponibleRx < 0) {
		disponibleRx = 0;
	}	
	var aFaltas = 0, cambiaAF;
	var canMS, reservaMS, codLote, codNuevoLote, codLoteAEliminar, sinAsignar, reservaEx, reservaPR, reservaAF, reservaPRPte;	

	var qRes = new AQSqlQuery;
	qRes.setSelect("ms.estado, SUM(r.cantidad)");
	qRes.setFrom("em_reservaspterx r INNER JOIN movistock ms ON r.idmovpterx = ms.idmovimiento");
	var estadoRes, reservaPRRes, reservaExRes;

	var curMS = new FLSqlCursor("movistock");
	curMS.setActivatedCommitActions(false);
	curMS.setActivatedCheckIntegrity(false);
	
	//24-12-2015 se cambia la prioridad para reservar, las primeras ser�n las ordenes de estampacion
	
	//curMS.select("idstock = " + idStock + " AND estado = 'PTE' AND cantidad < 0 AND NOT em_merma  ORDER BY reservamanual DESC, idlineapc, idmovimiento");
	curMS.select("idstock = " + idStock + " AND estado = 'PTE' AND cantidad < 0 AND NOT em_merma  ORDER BY reservamanual DESC, emidlineaest, idmovimiento");
	
	
	while (curMS.next()) {

		codLoteAEliminar = false;
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		codLote = curMS.valueBuffer("codlote");
		canMS = (curMS.valueBuffer("cantidad") + curMS.valueBuffer("enreserva")) * -1;	

		sinAsignar = canMS;
		reservaEx = 0;
		reservaPR = 0;
		reservaAF = 0;
		reservaExRes = 0;
		reservaPRRes = 0;
		
		/// QryReservas
		if (!curMS.isNull("enreserva") && curMS.valueBuffer("enreserva") != 0) {
			qRes.setWhere("r.idmovreserva = " + curMS.valueBuffer("idmovimiento") + " GROUP BY ms.estado");
//debug("qRes = " + qRes.sql());
			if (!qRes.exec()) {
				return false;
			}
			while (qRes.next()) {
				estadoRes = qRes.value("ms.estado");
//debug("estadoRes " + estadoRes);
				switch (estadoRes) {
					case "PTE": {
						reservaPRRes += qRes.value("SUM(r.cantidad)");
//debug("reservaPRRes " + reservaPRRes);
						reservaPRRes = isNaN(reservaPRRes) ? 0 : reservaPRRes;
						break;
					} 
					case "HECHO": {
						reservaExRes += qRes.value("SUM(r.cantidad)");
//debug("reservaExRes " + reservaExRes);
						reservaExRes = isNaN(reservaExRes) ? 0 : reservaExRes;
						break;
					}
				}
			}
		}
//debug("sinAsignar " + sinAsignar + " disponible " + disponible);
		if (sinAsignar > 0 && disponible > 0) {
			if (!curMS.valueBuffer("forzarafaltas")) {
				reservaEx = sinAsignar > disponible ? disponible : sinAsignar;
			}
			disponible -= reservaEx;
			sinAsignar -= reservaEx;
		}
		if (sinAsignar > 0 && disponibleRx > 0) {
			if (!curMS.valueBuffer("forzarafaltas") && !curMS.valueBuffer("agotarexistencias")) {
				reservaPR = sinAsignar > disponibleRx ? disponibleRx : sinAsignar;
			}
			disponibleRx -= reservaPR;
			sinAsignar -= reservaPR;
		}
		if (sinAsignar > 0) {
			reservaAF = sinAsignar;		
			aFaltas += reservaAF;
			sinAsignar -= reservaAF;
		}
//debug("reservaEx " + reservaEx + " reservaPR " + reservaPR + " reservaAF " + reservaAF);
//debug("reservaExRes2 " + reservaExRes);		
		reservaEx = parseFloat(reservaEx) + parseFloat(reservaExRes);
		reservaPR = parseFloat(reservaPR) + parseFloat(reservaPRRes);
		reservaPRPte = reservaPR;	

//debug("reservaEx2 " + reservaEx + " reservaPR " + reservaPR + " reservaAF " + reservaAF);

		if (curMS.valueBuffer("reservaex") == reservaEx && curMS.valueBuffer("reservapr") == reservaPR && curMS.valueBuffer("reservaaf") == reservaAF) {
			continue;
		}
		curMS.setValueBuffer("reservaex", AQUtil.roundFieldValue(reservaEx, "movistock", "reservaex"));
		curMS.setValueBuffer("reservapr", AQUtil.roundFieldValue(reservaPR, "movistock", "reservapr"));
		curMS.setValueBuffer("reservaaf", AQUtil.roundFieldValue(reservaAF, "movistock", "reservaaf"));
			
		cambiaAF = (Math.abs(curMS.valueBuffer("reservaaf") - curMS.valueBufferCopy("reservaaf")) > 0.0001);

		if (cambiaAF) {
			respuesta = "A FALTAS";
		}
		//debug("cambiaAF " + cambiaAF );
		if (cambiaAF && curMS.valueBufferCopy("reservaaf") != 0) {
			if (!_i.borraReservasMSAFaltas(curMS, true)) {
				return false;
			}
			if (!_i.borraMovTejidoPrep(curMS)) {
				return false;
			}
		}
		if (!curMS.commitBuffer()) {
			return false;
		}
		if (cambiaAF) {
			if (!_i.creaReservasMSAFaltas(curMS)) {
				return false;
			}
			if (!_i.creaMovTejidoPrep(curMS)) {
				return false;
			}
		}
	}
	curStock.setValueBuffer("disponible", disponible);
	curStock.setValueBuffer("reservada", existencias - disponible);
	curStock.setValueBuffer("disponiblepterecibir", disponibleRx);
	curStock.setValueBuffer("reservadapterecibir", pteRecibir - disponibleRx);
	curStock.setValueBuffer("afaltas", aFaltas);
	curStock.setValueBuffer("em_reservadaoe", AQUtil.sqlSelect("movistock mt  INNER JOIN movistock me ON me.idmovimiento = mt.idmovtejidopadre","SUM(mt.reservaex)","mt.idstock = " + idStock + " AND me.emidlineaest is not null","movistock"));

	if (!_i.distribuyeStockPteClientes(curStock.valueBuffer("idstock"))) {
		return false;
	}

	return respuesta;
}
/*
function euromoda_creaReservaPteRx(idMovReserva, qPteRx, cantidad)
{
	//debug("euromoda_creaReservaPteRx " + cantidad);
	var _i = this.iface;
	if (!_i.curReservaPteRx_) {
		_i.curReservaPteRx_ = new FLSqlCursor("em_reservaspterx");
		_i.curReservaPteRx_.setActivatedCommitActions(false);
		_i.curReservaPteRx_.setActivatedCheckIntegrity(false);
	}
	_i.curReservaPteRx_.setModeAccess(_i.curReservaPteRx_.Insert);
	_i.curReservaPteRx_.refreshBuffer();
	_i.curReservaPteRx_.setValueBuffer("idmovreserva", idMovReserva);
	_i.curReservaPteRx_.setValueBuffer("idmovpterx", qPteRx.value("idmovimiento"));
	_i.curReservaPteRx_.setValueBuffer("cantidad", cantidad);
	if (!_i.curReservaPteRx_.commitBuffer()) {
		return false;
	}
	//debug("euromoda_creaReservaPteRx " + cantidad + " OK");
	return true;
}*/

function euromoda_distribuyeStockPteClientes(idStock, codCliente:optional)
{
	return true; /// Congelado hasta que hablemos Jos� y yo
	
	var _i = this.iface;
	var whereCliente = codCliente ? (" AND p.codcliente = '" + codCliente + "'") : "";
	var q = new AQSqlQuery;
	q.setSelect("p.codcliente, SUM(ms.reservaex), SUM(ms.reservapr), SUM(ms.reservaaf), COUNT(p.codcliente)");
	q.setFrom("movistock ms INNER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido");
	q.setWhere("ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0 " + whereCliente + " GROUP BY p.codcliente");
	if (!q.exec()) {
		return false;
	}
	var disponible, disponibleRx, aFaltas, rTotal;
	var qCli = new AQSqlQuery;
	qCli.setSelect("ms.idmovimiento, ms.cantidad, ms.reservaex, ms.reservapr, ms.reservaaf");
	qCli.setFrom("movistock ms INNER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido");
	
	var canMS, reservaEx, reservaPR, reservaAF, sinAsignar, cambiaAF;
	var curMS = new FLSqlCursor("movistock");
	curMS.setActivatedCommitActions(false); /// La redistribuci�n no afectar� al stock total �y a la fecha de servicio?
	
	while (q.next()) {
//		debug("COUNT " + q.value("COUNT(p.codcliente)"));
		if (q.value("COUNT(p.codcliente)") == 1) {
//			debug("continue 1");
			continue;
		}
		disponible = parseFloat(q.value("SUM(ms.reservaex)"));
		disponible = isNaN(disponible) ? 0 : disponible;
		disponibleRx = parseFloat(q.value("SUM(ms.reservapr)"));
		disponibleRx = isNaN(disponibleRx) ? 0 : disponibleRx;
		aFaltas = parseFloat(q.value("SUM(ms.reservaaf)"));
		aFaltas = isNaN(aFaltas) ? 0 : aFaltas;
		rTotal = parseFloat(disponible) + parseFloat(disponibleRx) + parseFloat(aFaltas);
		if (rTotal == disponible || rTotal == disponibleRx || rTotal == aFaltas) {
//			debug("Continue");
			continue;
		}
		qCli.setWhere("ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0 AND p.codcliente = '" + q.value("p.codcliente") + "' ORDER BY p.fechasalida, ms.cantidad DESC, ms.idmovimiento");
//		debug("qCli " + qCli.sql());
		if (!qCli.exec()) {
			return false;
		}
		while (qCli.next()) {
			canMS = qCli.value("ms.cantidad") * -1;
			
			sinAsignar = canMS;
			reservaEx = 0;
			reservaPR = 0;
			reservaAF = 0;
			if (sinAsignar > 0 && disponible > 0) {
				reservaEx = sinAsignar > disponible ? disponible : sinAsignar;
				disponible -= reservaEx;
				sinAsignar -= reservaEx;
			}
			if (sinAsignar > 0 && disponibleRx > 0) {
				reservaPR = sinAsignar > disponibleRx ? disponibleRx : sinAsignar;
				disponibleRx -= reservaPR;
				sinAsignar -= reservaPR;
			}
			if (sinAsignar > 0) {
				reservaAF = sinAsignar;
				aFaltas += reservaAF;
				sinAsignar -= reservaAF;
			}
//			debug("Reservaex " + reservaEx + " ReservaPr " + reservaPR + " aFaltas " + aFaltas);
			if (qCli.value("ms.reservaex") == reservaEx && qCli.value("ms.reservapr") == reservaPR && qCli.value("ms.reservaaf") == reservaAF) {
				continue;
			}
			curMS.select("idmovimiento = " + qCli.value("ms.idmovimiento"));
			if (!curMS.first()) {
				return false;
			}
			curMS.setModeAccess(curMS.Edit);
			curMS.refreshBuffer();
			// debug("reservaEx " + reservaEx + " , reservaPR " + reservaPR + " , reservaAF " + reservaAF);
			curMS.setValueBuffer("reservaex", reservaEx);
			curMS.setValueBuffer("reservapr", reservaPR);
			curMS.setValueBuffer("reservaaf", reservaAF);
			
			cambiaAF = (q.value("ms.reservaaf") != reservaAF);
			if (cambiaAF && curMS.valueBufferCopy("reservaaf") != 0) {
				if (!_i.borraReservasMSAFaltas(curMS, true)) {
					return false;
				}
			}
			if (!curMS.commitBuffer()) {
				return false;
			}
			if (cambiaAF) {
				if (!_i.creaReservasMSAFaltas(curMS)) {
					return false;
				}
			}
		}
	}
	return true;
}

function euromoda_borraReservasMSAFaltas(curMS, forzar)
{
   var _i = this.iface;
	if (!forzar) {
		switch (curMS.modeAccess()) {
		case curMS.Edit:
		case curMS.Insert: {
					return true;
					break;
				}
			case curMS.Del: {
					if (curMS.valueBuffer("reservaaf") == 0) {
						return true;
					}
					break;
				}
			}
	}
	
	var cBorrar = new FLSqlCursor("movistock");
	cBorrar.setActivatedCheckIntegrity(false);
	if(forzar) {
		cBorrar.setActivatedCommitActions(false);
	}
	cBorrar.select("idmovproducto = " + curMS.valueBuffer("idmovimiento"));
	while (cBorrar.next()) {
	    cBorrar.setModeAccess(cBorrar.Del);
	    cBorrar.refreshBuffer();
	    if (!_i.borraMovTejidoPrep(cBorrar)) {
		return false;
	    }
	    if (!cBorrar.commitBuffer()) {
		return false;
	    }
	}
	return true;
}

/** Crea la previsi�n de los componentes del art�culo (pedidos marco)
*/
function euromoda_controlPrevision(curMS)
{
	var _i = this.iface;
	if (curMS.valueBuffer("estado") != "PREV") {
		return true;
	}
	if (!curMS.isNull("idmovproducto")) {
		return true;
	}
	switch (curMS.modeAccess()) {
	case curMS.Insert: {
			var qryFT = new FLSqlQuery();
			qryFT.setSelect("refcomponente, SUM(cantidad*factor), MIN(id)");
			qryFT.setFrom("articuloscomp");
			qryFT.setWhere("refcompuesto = '" + curMS.valueBuffer("referencia") + "' GROUP BY refcomponente");
			if (!qryFT.exec()) {
				return false;
			}
			var codAlmacen = AQUtil.sqlSelect("stocks", "codalmacen", "idstock = " + curMS.valueBuffer("idstock"));
			var curMSRes = new FLSqlCursor("movistock");
			curMSRes.setActivatedCheckIntegrity(false); /// Porque est� muy controlado y aumenta el rendimiento (la tabla tiene muchas relaciones)
			var referencia, cantidad, idStock;
			while (qryFT.next()) {
				referencia = qryFT.value("refcomponente");
				idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
				if (!idStock) {
					var oArticulo = new Object;
					oArticulo["referencia"] = referencia;
					idStock = _i.crearStock(codAlmacen, oArticulo);
					if (!idStock) {
						return false;
					}
				}
				curMSRes.setModeAccess(curMSRes.Insert);
				curMSRes.refreshBuffer();
				curMSRes.setValueBuffer("idmovproducto", curMS.valueBuffer("idmovimiento"));
				curMSRes.setValueBuffer("idarticulocomp", qryFT.value("MIN(id)"));
				curMSRes.setValueBuffer("referencia", referencia);
				curMSRes.setValueBuffer("estado", "PREV");
				cantidad = curMS.valueBuffer("cantidad") * qryFT.value("SUM(cantidad*factor)");
				cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");
				curMSRes.setValueBuffer("cantidad", cantidad);
				//        curMSRes.setValueBuffer("fechaprev", qryFT.value("fechaprev"));
				curMSRes.setValueBuffer("idstock", idStock);
				curMSRes.setValueBuffer("concepto", curMS.valueBuffer("concepto"));
				if (!curMSRes.commitBuffer()) {
					return false;
				}
			}
			break;
		}
	case curMS.Del: {
			if (!AQSql.del("movistock", "idmovproducto = " + curMS.valueBuffer("idmovimiento"))) {
				return false;
			}
			break;
		}
		return true;
	}
	return true;
}

/*function euromoda_creaReservasMSAFaltas(curMS)
{
	debug("euromoda_creaReservasMSAFaltas");
	var _i = this.iface;
	if (curMS.valueBuffer("reservaaf") == 0) {
		return true;
	}
	if (!curMS.isNull("idmovproducto")) {
		return true;
	}
	if (!curMS.isNull("codloteprod")) {
		return true;
	}
	var qryFT = new FLSqlQuery();
	qryFT.setSelect("ac.refcomponente, a.codsubfamilia, SUM(ac.cantidad*ac.factor), MIN(ac.id)");
	qryFT.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia");
	qryFT.setWhere("ac.refcompuesto = '" + curMS.valueBuffer("referencia") + "' GROUP BY ac.refcomponente, a.codsubfamilia");
	if (!qryFT.exec()) {
		return false;
	}
	
	var codAlmacen = AQUtil.sqlSelect("stocks", "codalmacen", "idstock = " + curMS.valueBuffer("idstock"));
	var curMSRes = new FLSqlCursor("movistock");
	curMSRes.setActivatedCommitActions(false); /// Porque est� muy controlado y aumenta el rendimiento (la tabla tiene muchas relaciones)
	curMSRes.setActivatedCheckIntegrity(false); /// Porque est� muy controlado y aumenta el rendimiento (la tabla tiene muchas relaciones)
	var referencia, cantidad, idStock, codSubfamilia;
	while (qryFT.next()) {
		codSubfamilia = qryFT.value("a.codsubfamilia");
		referencia = qryFT.value("ac.refcomponente");
		idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
		if (!idStock) {
			var oArticulo = new Object;
			oArticulo["referencia"] = referencia;
			idStock = _i.crearStock(codAlmacen, oArticulo);
			if (!idStock) {
				return false;
			}
		}
		curMSRes.setModeAccess(curMSRes.Insert);
		curMSRes.refreshBuffer();
		curMSRes.setValueBuffer("idmovproducto", curMS.valueBuffer("idmovimiento"));
		curMSRes.setValueBuffer("idarticulocomp", qryFT.value("MIN(ac.id)"));
		curMSRes.setValueBuffer("referencia", referencia);
		curMSRes.setValueBuffer("estado", "PTE");
		cantidad = -1 * curMS.valueBuffer("reservaaf") * qryFT.value("SUM(ac.cantidad*ac.factor)");
		
		debug("---------------------------------------------------------------------------------------------------------------");
		debug("producto: "+curMS.valueBuffer("referencia"));
		debug("componente: "+referencia);
		var referenciaMargen = _i.dameReferenciaAnverso(curMS.valueBuffer("referencia"), referencia);
		debug("referenciaMargen: "+referenciaMargen);
		if(referenciaMargen) {
			var codSubfamProd = AQUtil.sqlSelect("articulos","codsubfamilia","referencia = '" + curMS.valueBuffer("referencia") + "' ");
			cantidad = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, cantidad, true)
		}
		debug("---------------------------------------------------------------------------------------------------------------");
		
		cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");
		curMSRes.setValueBuffer("cantidad", cantidad);
		curMSRes.setValueBuffer("fechaprev", curMS.valueBuffer("fechaprev"));
		curMSRes.setValueBuffer("idstock", idStock);
		curMSRes.setValueBuffer("concepto", curMS.valueBuffer("concepto"));
		if (_i.esReferenciaXPiezas(referencia)) {
			curMSRes.setValueBuffer("codsubfamiliatp", codSubfamilia);
		}
		if (!curMSRes.commitBuffer()) {
			return false;
		}
	}
	return true;
}*/

function euromoda_creaReservasMSAFaltas(curMS)
{
	//debug("\n\neuromoda_creaReservasMSAFaltas");
	var _i = this.iface;
	if (curMS.valueBuffer("reservaaf") == 0) {
		return true;
	}
	if (!curMS.isNull("idmovproducto")) {
		return true;
	}
	if (!curMS.isNull("codloteprod")) {
		return true;
	}

	
	/********* H2114  13-02-2020 ****************/

	if(_i.pedidoAlmDep(curMS)) {
		return true;
	}
	/******** FIN        H2114 *****************/

	var qryFT = new FLSqlQuery();
	qryFT.setSelect("ac.refcomponente, a.codsubfamilia, ac.cantidad*ac.factor, ac.id, ac.piezasancho, ac.cantidad");
	qryFT.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia");
	qryFT.setWhere("ac.refcompuesto = '" + curMS.valueBuffer("referencia") + "'");
	if (!qryFT.exec()) {
		return false;
	}
	var margen = 0;
	var oParamMargen = new Object;
	var codAlmacen = AQUtil.sqlSelect("stocks", "codalmacen", "idstock = " + curMS.valueBuffer("idstock"));
	var curMSRes = new FLSqlCursor("movistock");
	curMSRes.setActivatedCommitActions(false); /// Porque est� muy controlado y aumenta el rendimiento (la tabla tiene muchas relaciones)
	curMSRes.setActivatedCheckIntegrity(false); /// Porque est� muy controlado y aumenta el rendimiento (la tabla tiene muchas relaciones)
	var referencia, cantidad, idStock, codSubfamilia;
	while (qryFT.next()) {
		codSubfamilia = qryFT.value("a.codsubfamilia");
		referencia = qryFT.value("ac.refcomponente");
		idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
		if (!idStock) {
			var oArticulo = new Object;
			oArticulo["referencia"] = referencia;
			idStock = _i.crearStock(codAlmacen, oArticulo);
			if (!idStock) {
				return false;
			}
		}
		curMSRes.setModeAccess(curMSRes.Insert);
		curMSRes.refreshBuffer();
		curMSRes.setValueBuffer("idmovproducto", curMS.valueBuffer("idmovimiento"));
		curMSRes.setValueBuffer("idarticulocomp", qryFT.value("ac.id"));
		curMSRes.setValueBuffer("referencia", referencia);
		curMSRes.setValueBuffer("estado", "PTE");
		cantidad  = -1 * curMS.valueBuffer("reservaaf") * qryFT.value("ac.cantidad*ac.factor");
		
		//debug("---------------------------------------------------------------------------------------------------------------");
		//debug("producto: "+curMS.valueBuffer("referencia"));
		//debug("componente: "+referencia);
		//debug("ac.cantidad: "+qryFT.value("ac.cantidad"));
		//debug("ac.cantidad*ac.factor: "+qryFT.value("ac.cantidad*ac.factor"));
		//var referenciaMargen = _i.dameReferenciaAnverso(curMS.valueBuffer("referencia"), referencia);
		var oAnverso = _i.dameReferenciaAnverso(curMS.valueBuffer("referencia"), referencia, qryFT.value("ac.id"));
		var referenciaMargen = oAnverso.referenciaAnverso;
		var factor = oAnverso.factor;
		
		//debug("referenciaMargen: "+referenciaMargen);
		//debug("factor: "+factor);
		if(referenciaMargen) {
			var codSubfamProd = AQUtil.sqlSelect("articulos","codsubfamilia","referencia = '" + curMS.valueBuffer("referencia") + "' ");
			//cantidad = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, cantidad, true)	

			oParamMargen.referencia = referenciaMargen;
			oParamMargen.codSubfamilia = codSubfamProd
			oParamMargen.cantidad = cantidad;
			oParamMargen.noInicio = true
			oParamMargen.factor = factor;
			oParamMargen.cantidadM = curMS.valueBuffer("reservaaf");
			oParamMargen.cantidadFT = qryFT.value("ac.cantidad");
			oParamMargen.piezasAncho =  qryFT.value("ac.piezasancho");

			//margen = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, cantidad, true, factor);
			margen = fleumoesta.iface.dameCantidadMargen(oParamMargen);
			//debug("margen: "+margen);
			/*var piezasAncho = qryFT.value("ac.piezasancho"); 15-11-2017
			if(piezasAncho && piezasAncho != 0)  {
				margen = margen / piezasAncho;
			}*/
		}

		if(factor && factor != "" && referenciaMargen) {
			//factor += margen; 15-11-2017
			//cantidad = -1 * curMS.valueBuffer("reservaaf") * factor; 15-11-2017
			cantidad = -1 * (curMS.valueBuffer("reservaaf") * factor + margen);
			
		}
		//debug("cantidad: "+cantidad);
		//debug("---------------------------------------------------------------------------------------------------------------");
		


		cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");
		curMSRes.setValueBuffer("cantidad", cantidad);
		curMSRes.setValueBuffer("fechaprev", curMS.valueBuffer("fechaprev"));
		curMSRes.setValueBuffer("idstock", idStock);
		curMSRes.setValueBuffer("concepto", curMS.valueBuffer("concepto"));
		if (_i.esReferenciaXPiezas(referencia)) {
			curMSRes.setValueBuffer("codsubfamiliatp", codSubfamilia);
		}
		if (!curMSRes.commitBuffer()) {
			return false;
		}

		/************* POZU 27-05-2020 SI EXISTE rservaslotepedido crearla *****/
		//debug("-----------------------------pasa por aqui 2");
		var qRLP = new AQSqlQuery;
		qRLP.setSelect("idlineapc, codlote, cantidad, idrlp,idarticulocomp");
		qRLP.setFrom("em_reservaslotepedido");
		qRLP.setWhere("idlineapc = " +  curMS.valueBuffer("idlineapc") + " AND idarticulocomp = " + qryFT.value("ac.id"));
		if (!qRLP.exec()) {
			return false;
		}
		while (qRLP.next()) {	

			//debug("------------ crea reservas para producto componente");
			var oParam = new Object;
			oParam["idLineaPedido"] = curMS.valueBuffer("idlineapc"); 
			oParam["codLote"] = qRLP.value("codlote"); 
			oParam["cantidad"] = qRLP.value("cantidad"); 
			oParam["idRLP"] = qRLP.value("idrlp");
			oParam["idArticuloComp"] = qryFT.value("ac.id");
			if (!_i.creaReservasPedidoProdComp(oParam)) {
				return false;
			}
		
		}

		/************* POZU 27-05-2020 SI EXISTE *****/





	}

	var refProducto = curMS.valueBuffer("referencia");
	//debug("\n\n*****");
	//debug("refProducto: "+refProducto);
	if(refProducto && refProducto != "") {

		var idLineaPedido = curMS.valueBuffer("idlineapc");
		//debug("idLineaPedido: "+idLineaPedido);
		if(idLineaPedido && idLineaPedido != "") {
			var codCliente = AQUtil.sqlSelect("lineaspedidoscli lp INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido","p.codcliente","lp.idlinea = " + idLineaPedido,"lineaspedidoscli,pedidoscli");
			

			var aDatosEmbalaje = flfactalma.iface.dameEmbalajeArticulo(refProducto, codCliente, false);
			if (!aDatosEmbalaje) {
				return false;
			}
			if(aDatosEmbalaje == true) {
			
				return true
			}
			if ("referencia" in aDatosEmbalaje && aDatosEmbalaje.referencia) {
				var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + aDatosEmbalaje.referencia + "' AND codalmacen = '" + codAlmacen + "'");
				if (!idStock) {
					var oArticulo = new Object;
					oArticulo["referencia"] = aDatosEmbalaje.referencia;
					idStock = flfactalma.iface.pub_crearStock(codAlmacen, oArticulo);
					if (!idStock) {
						return false;
					}
				}
				var canEmbal = Math.ceil(curMS.valueBuffer("reservaaf") / aDatosEmbalaje.capacidad);
				canEmbal *= -1;
				var curMSRes = new FLSqlCursor("movistock");
				curMSRes.setModeAccess(curMS.Insert);
				curMSRes.refreshBuffer();
				curMSRes.setValueBuffer("idmovproducto", curMS.valueBuffer("idmovimiento"));
				curMSRes.setValueBuffer("referencia", aDatosEmbalaje.referencia);
				curMSRes.setValueBuffer("estado", "PTE");
				curMSRes.setValueBuffer("fechaprev",  curMS.valueBuffer("fechaprev"));				
				curMSRes.setValueBuffer("cantidad", canEmbal);
				curMSRes.setValueBuffer("idstock", idStock);				
				curMSRes.setValueBuffer("concepto", curMS.valueBuffer("concepto"));
				if (!curMSRes.commitBuffer()) {
					return false;
				}				
			}			
		}	

	}
	return true;
}

function euromoda_compruebaLoteAFaltas(curMS)
{
	var _i = this.iface;
	var referencia = curMS.valueBuffer("referencia");
	if (!AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + referencia + "' AND fabricado AND tipostock = 'Lotes'")) {
		return true;
	}
	var codLote = curMS.valueBuffer("codlote");
	if (codLote && codLote != "") {
		var cantidad = curMS.valueBuffer("reservaaf");
		if (AQUtil.sqlSelect("lotesstock", "canlote", "codlote = '" + codLote + "' AND estado = 'PTE'") == cantidad) {
			return true;
		}
		if (!_i.eliminaLoteAFaltas(codLote)) {
			return false;
		}
	}
	var codNuevoLote = _i.creaLoteAFaltas(curMS);
	if (codNuevoLote) {
		curMS.setValueBuffer("codlote", codNuevoLote);
	}
	return true;
}

function euromoda_creaLoteAFaltas(curMS)
{
	var _i = this.iface;
	var cantidad = curMS.valueBuffer("reservaaf");
	var curLote = new FLSqlCursor("lotesstock");
	curLote.setModeAccess(curLote.Insert);
	curLote.refreshBuffer();
	curLote.setValueBuffer("referencia", curMS.valueBuffer("referencia"));
	var codLote = formRecordlotesstock.iface.pub_calculateCounter(curLote);
	curLote.setValueBuffer("codlote", codLote);
	curLote.setValueBuffer("codalmacen", AQUtil.sqlSelect("stocks", "codalmacen", "idstock = " + curMS.valueBuffer("idstock")));
	curLote.setValueBuffer("estado", "PTE");
	curLote.setValueBuffer("canlote", cantidad);
	curLote.setValueBuffer("cantotal", 0);
	curLote.setValueBuffer("canusada", 0);
	curLote.setValueBuffer("candisponible", 0);
	if (!curLote.commitBuffer()) {
		return false;
	}
	return codLote;
}

function euromoda_eliminaLoteAFaltas(codLote)
{
	var _i = this.iface;
	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("codlote = '" + codLote + "'");
	if (!curLote.first()) {
		return false;
	}
	curLote.setModeAccess(curLote.Del);
	curLote.refreshBuffer();
	if (!curLote.isNull("codordenproduccion")) { /// No se eliminan los lotes en orden porque forman parte del pte de
		return true;
	}
	if (curLote.valueBuffer("estado") != "PTE") {
		MessageBox.warning(sys.translate("scripts", "Error al eliminar el lote a faltas. El estado no es PTE"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	if (!curLote.commitBuffer()) {
		return false;
	}
	return true;
}

/// Se ejecuta s�lo cuando el nivel de transacci�n es 0
function euromoda_actualizarStockPteRecibirT0(idStock, codSubfamiliaTP)
{
	var _i = this.iface;
	return _i.revisarReservasStock(idStock); // Igual que euromoda, no pasar si no se ve claro
	
	var curStock = _i.abreCursorStock(idStock);
	if (!curStock) {
		return false;
	}	curStock.setValueBuffer("pterecibir", formRecordregstocks.iface.pub_commonCalculateField("pterecibir", curStock));
	if (!_i.totalizaReservasStock(curStock, codSubfamiliaTP)) {
		return false;
	}
	return true;
}

function euromoda_calculaReservasStockComp(idStock, nivelComp)
{
	
	var _i = this.iface;	
	
	var q = new AQSqlQuery();
	q.setSelect("s2.idstock, s2.referencia");
	q.setFrom("stocks s INNER JOIN articuloscomp ap ON s.referencia = ap.refcompuesto INNER JOIN stocks s2 ON (s.codalmacen = s2.codalmacen AND ap.refcomponente = s2.referencia)");
	q.setWhere("s.idstock = " + idStock);
	if (!q.exec()) {
		return false;
	}
	var idStockComp;
	while (q.next()) {
		idStockComp = q.value("s2.idstock");
		_i.marcaStockPte(idStockComp, "PTE_SERVIR");
	}
	return true;
}

function euromoda_actualizarStockT0(idStock, codSubfamiliaTP)
{
	var _i = this.iface;
	var curStock = _i.abreCursorStock(idStock);
	if (!curStock) {
		return false;
	}
	curStock.setValueBuffer("cantidad", formRecordregstocks.iface.pub_commonCalculateField("cantidad", curStock));
	if (!_i.totalizaReservasStock(curStock, 0, 0, codSubfamiliaTP)) {
		return false;
	}
	return true;
}	

function euromoda_crearStock(codAlmacen, aDatosArt)
{
	var curStock: FLSqlCursor = new FLSqlCursor("stocks");
	curStock.setModeAccess(curStock.Insert);
	curStock.refreshBuffer();
	curStock.setValueBuffer("codalmacen", codAlmacen);
	curStock.setValueBuffer("referencia", aDatosArt["referencia"]);
	curStock.setValueBuffer("cantidad", 0);
	if (!curStock.commitBuffer()) {
		return false;
	}
	return curStock.valueBuffer("idstock");
}

function euromoda_beforeCommit_stocks(curStock)
{
	var _i = this.iface;
	if (!_i.__beforeCommit_stocks(curStock)) {
		return false;
	}
	if (!_i.controlAltaStock(curStock)) {
		return false;
	}
	return true;
}

function euromoda_controlAltaStock(curStock)
{
	if (curStock.modeAccess() != curStock.Insert) {
		return true;
	}
	var codAlmacen = curStock.valueBuffer("codalmacen");
	var referencia = curStock.valueBuffer("referencia");
	curStock.setValueBuffer("nombre", AQUtil.sqlSelect("almacenes", "nombre", "codalmacen = '" + codAlmacen + "'"));
	var dA = flfactppal.iface.ejecutarQry("articulos", "descripcion,codtamanoem,codcolorem,coddibestamp,emdibujo,codbarras", "referencia = '" + referencia + "'");
	if (dA.result != 1) {
		return false;
	}
	curStock.setValueBuffer("articulo", dA.descripcion);
	if (dA.codtamanoem) {
		curStock.setValueBuffer("codtamanoem", dA.codtamanoem);
	}
	if (dA.codcolorem) {
		curStock.setValueBuffer("codcolorem", dA.codcolorem);
	}
	if (dA.coddibestamp) {
		curStock.setValueBuffer("coddibestamp", dA.coddibestamp);
		curStock.setValueBuffer("emdibujo", dA.emdibujo);
	}
	if (dA.codbarras) {
		curStock.setValueBuffer("codbarras", dA.codbarras);
	}
	return true;
}

function euromoda_datosDesalbaranarLineaPedProv(curLA)
{
	var _i = this.iface;
	
	var idLineaPedido = curLA.valueBuffer("idlineapedido");
	if (!_i.__datosDesalbaranarLineaPedProv(curLA)) {
		return false;
	}
	var referencia = _i.curMoviStock.valueBuffer("referencia");
	if (!_i.esReferenciaXPartidas(referencia)) {
		return true;
	}
	/// Cuando es tejido en crudo es posible que el albar�n haya ido a otro almac�n. Hay que restituir el del pedido. Adem�s, los lotes se generan con el albar�n, por lo que hay que eliminarlo del movimiento
	var codAlmacen = AQUtil.sqlSelect("lineaspedidosprov lp INNER JOIN pedidosprov p ON lp.idpedido = p.idpedido", "p.codalmacen", "lp.idlinea = " + idLineaPedido, "pedidosprov");
	var idStock = _i.dameIdStockEM(codAlmacen, referencia);
	if (!idStock) {
		return false;
	}
	_i.curMoviStock.setNull("codlote");
	_i.curMoviStock.setValueBuffer("idstock", idStock);
	
	return true;
}

function euromoda_esReferenciaXPartidas(referencia)
{
	var _i = this.iface;
	var d = flfactppal.iface.pub_ejecutarQry("articulos", "piezasem,codfamilia,codsubfamilia", "referencia = '" + referencia + "'", false);
	if (d.result != 1) {
		return false;
	}
	if (_i.esSubfamiliaCrudo(d.codsubfamilia)) {
		return true;
	}
	if (_i.esFamiliaCrudo(d.codfamilia)) {
		return true;
	}
	return false;
	//  var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
	//  return _i.esFamiliaCrudo(codFamilia);
}

function euromoda_esReferenciaXPiezas(referencia)
{
	var _i = this.iface;
	var d = flfactppal.iface.pub_ejecutarQry("articulos", "piezasem,codfamilia,codsubfamilia", "referencia = '" + referencia + "'", false);
	if (d.result != 1) {
		return false;
	}
	if (_i.esSubfamiliaEstampado(d.codsubfamilia)) {
		return true;
	}
	if (_i.esFamiliaEstampado(d.codfamilia)) {
		return true;
	}
	return false;
}

function euromoda_esReferenciaTPPE(referencia)
{
	var _i = this.iface;
	var d = flfactppal.iface.pub_ejecutarQry("articulos", "codfamilia,codsubfamilia", "referencia = '" + referencia + "'", false);
	if (d.result != 1) {
		return false;
	}
	if (_i.esFamiliaTPPE(d.codfamilia)) {
		return true;
	}
	return false;
}

function euromoda_esReferenciaEstampadoGen(referencia)
{
	var _i = this.iface;
	var d = flfactppal.iface.pub_ejecutarQry("articulos", "codfamilia,codsubfamilia", "referencia = '" + referencia + "'", false);
	if (d.result != 1) {
		return false;
	}
	if (_i.esSubfamEstampadoGen(d.codsubfamilia)) {
		return true;
	}
	return false;
}

function euromoda_dameIdStockEM(codAlmacen, referencia)
{
	var _i = this.iface;
	
	var oArticulo = new Object;
	oArticulo.referencia = referencia;
	oArticulo.localizador = "referencia = '" + referencia + "'";
	
	return _i.dameIdStock(codAlmacen, oArticulo);
}

function euromoda_controlArticuloVariable(curAC)
{
	return true;
}

function euromoda_afterCommit_em_traspasosstock(curTS)
{
	var _i = this.iface;
	if (!_i.controlStockTraspasoStock(curTS)) {
		return false;
	}
	return true;
}

function euromoda_afterCommit_em_dibujos(curD)
{
	var _i = this.iface;
	if (!_i.controlDesDibujo(curD)) {
		return false;
	}
	if (!_i.asignaColorUnico(curD)) {
		return false;
	}
	return true;
}

function euromoda_controlDesDibujo(curD)
{
	var _i = this.iface;
	if (curD.modeAccess() == curD.Edit && curD.valueBuffer("descripcion") != curD.valueBufferCopy("descripcion")) {
		AQUtil.execSql("UPDATE articulos SET emdibujo = '" + curD.valueBuffer("descripcion") + "' WHERE coddibestamp = " + curD.valueBuffer("coddibujoem"));
		AQUtil.execSql("UPDATE stocks SET emdibujo = '" + curD.valueBuffer("descripcion") + "' WHERE coddibestamp = " + curD.valueBuffer("coddibujoem"));
	}
	return true;
}

function euromoda_beforeCommit_em_traspasosstock(curTS)
{
	var _i = this.iface;
	if (!_i.controlStockBCTraspasoStock(curTS)) {
		return false;
	}

	if (!flfactppal.iface.pub_controlDatosMod(curTS)) {
		return false;
	}
	
	return true;
}

function euromoda_controlStockTraspasoStock(curTS)
{
	var _i = this.iface;
	switch (curTS.modeAccess()) {
	case curTS.Insert: {
			if (!_i.generarEstructura(curTS)) {
				return false;
			}
			if (!_i.consistenciaLinea(curTS)) {
				return false;
			}
			break;
		}
	case curTS.Edit: {
			if (curTS.valueBuffer("codalmacen") != curTS.valueBufferCopy("codalmacen") || curTS.valueBuffer("refdesde") != curTS.valueBufferCopy("refdesde") || curTS.valueBuffer("refhasta") != curTS.valueBufferCopy("refhasta") || curTS.valueBuffer("cantidad") != curTS.valueBufferCopy("cantidad") || curTS.valueBuffer("fecha") != curTS.valueBufferCopy("fecha") ||  curTS.valueBuffer("canhasta") != curTS.valueBufferCopy("canhasta") || curTS.valueBuffer("codlotedesde") != curTS.valueBufferCopy("codlotedesde")) {
				if (!_i.borrarEstructura(curTS)) {
					return false;
				}
				if (!_i.generarEstructura(curTS)) {
					return false;
				}
				if (!_i.consistenciaLinea(curTS)) {
					return false;
				}
			}
			break;
		}
	}
	
	return true;
}

function euromoda_controlStockBCTraspasoStock(curTS)
{
	var _i = this.iface;
	switch (curTS.modeAccess()) {
	case curTS.Del: {
			if (!_i.borrarEstructura(curTS)) {
				return false;
			}
			break;
		}
	}
	
	return true;
}

function euromoda_borrarEstructura(curLinea)
{
	var _i = this.iface;
	var tabla = curLinea.table();
	if (tabla != "em_traspasosstock") {
		return _i.__borrarEstructura(curLinea);
	}
	if (!_i.borrarMoviStock(curLinea)) {
		return false;
	}
	return true;
}

function euromoda_consistenciaLinea(curLinea)
{
	var _i = this.iface;
	var tabla = curLinea.table();
	
	if (tabla == "em_traspasosstock") {
	
		var canDesde = curLinea.valueBuffer("cantidad");
		var canHasta = curLinea.isNull("canhasta") ? curLinea.valueBuffer("cantidad") : curLinea.valueBuffer("canhasta");
		var codTraspaso = curLinea.valueBuffer("codtraspaso");
		var canPos = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "em_codtraspaso = '" + codTraspaso + "' AND cantidad > 0");
		canPos = isNaN(canPos) ? 0 : canPos;
		var canNeg = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "em_codtraspaso = '" + codTraspaso + "' AND cantidad < 0");
		canNeg = isNaN(canNeg) ? 0 : canNeg;
		canNeg *= -1;
		if (canHasta != canPos || canDesde != canNeg) {
			MessageBox.warning(sys.translate("Error al verificar la consistencia del traspaso de stock"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}			
	} else if (tabla == "lineasalbaranesprov") {  	
		var totalCan:Number = parseFloat(AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idlineaap = " + curLinea.valueBuffer("idlinea")));
		var numMov = AQUtil.sqlSelect("movistock", "COUNT(*)", "idlineaap = " + curLinea.valueBuffer("idlinea"));
      	if (!totalCan || isNaN(totalCan)) {
      		totalCan = 0;	
      	}
      	if(numMov == 2) {
			if (totalCan != 0) {
				formUI.ponMsgWarn(sys.translate("Error de consistencia en la l�nea de albar�n. La cantidad de movimientos (%1) deber�a de ser 0").arg(totalCan));		
				return false;
			}      			
      	} else {
	      	if (totalCan != parseFloat(curLinea.valueBuffer("cantidad"))) {
	        	if (totalCan == 0 && AQUtil.sqlSelect("articulos", "nostock", "referencia = '" + curLinea.valueBuffer("referencia") + "'")) {
	          		return true;
	        	}
	        	formUI.ponMsgWarn(sys.translate("Error de consistencia en la l�nea de albar�n. La cantidad de movimientos (%1) es distinta de la cantidad de la l�nea (%2)").arg(totalCan).arg(curLinea.valueBuffer("cantidad")));               	
	        	return false;
	      	}      
      	}         
    } else {
		return _i.__consistenciaLinea(curLinea);		
	}
	return true;
}

function euromoda_datosEvolStock(qryArticulos, fechaDesde, avisar)
{
	var _i = this.iface;
	var arrayEvolStock = [];
	arrayEvolStock["avisar"] = avisar;
	var stock = qryArticulos.value("s.disponible")
							arrayEvolStock[0] = _i.initPeriodoStock();
	arrayEvolStock[0]["fecha"] = fechaDesde.toString().left(10) + "T00:00:00";
	arrayEvolStock[0]["stock"] = stock;
	arrayEvolStock[0]["D"] = stock;
	arrayEvolStock[0]["NB"] = qryArticulos.value("s.reservada");
	arrayEvolStock[0]["SS"] = qryArticulos.value("a.stockmax");
	//    arrayEvolStock[0]["NN"] = arrayEvolStock[0]["NB"] - arrayEvolStock[0]["D"] + arrayEvolStock[0]["SS"] - arrayEvolStock[0]["RP"];
	arrayEvolStock[0]["NN"] = qryArticulos.value("s.afaltas");
	if (arrayEvolStock[0]["NN"] < 0) {
		arrayEvolStock[0]["NN"] = 0;
	}
	var aFaltas = qryArticulos.value("s.afaltas");
	aFaltas = isNaN(aFaltas) ? 0 : aFaltas;
	var sMin = qryArticulos.value("a.stockmin");
	sMin = isNaN(sMin) ? 0 : sMin;
	var disponible = qryArticulos.value("s.disponible");
	disponible = isNaN(disponible) ? 0 : disponible;
	var disponiblePteRx = qryArticulos.value("s.disponiblepterecibir");
	disponiblePteRx = isNaN(disponiblePteRx) ? 0 : disponiblePteRx;
	arrayEvolStock[0]["RPP"] = aFaltas + sMin - disponible - disponiblePteRx;
	
	return arrayEvolStock;
}

function euromoda_planificarPedStock(arrayEvolStock, plazoPedido)
{
	//  arrayEvolStock[0]["RPP"] = 1; // arrayEvolStock[0]["NN"];
	arrayEvolStock[0]["LPP"] = 1; // arrayEvolStock[0]["NN"];
	
	return arrayEvolStock;
}

function euromoda_esTrazable(referencia)
{
	var _i = this.iface;
	
	var trazable = false;
	if (referencia && referencia != "") {
		trazable = _i.esReferenciaXPiezas(referencia) || _i.esReferenciaXPartidas(referencia);
	}
	return trazable;
}

function euromoda_controlStockAlbaranesProv(curLA)
{
	var _i = this.iface;
	
	var referencia = curLA.valueBuffer("referencia");
	var xPiezas = _i.esReferenciaXPiezas(referencia);
	var xPartidas = _i.esReferenciaXPartidas(referencia);
	 if (xPiezas || (xPartidas && !curLA.isNull("codpartida"))) {
		return _i.controlStockAlbProvEstampado(curLA);
	} else if (xPartidas) {
		return _i.controlStockAlbProvCrudo(curLA);
	}
	return _i.__controlStockAlbaranesProv(curLA);
}

function euromoda_controlStockAlbProvEstampado(curLA)
{
	var _i = this.iface;
	if (curLA.modeAccess() == curLA.Del) {
		return _i.__controlStockAlbaranesProv(curLA);
	}
	if (curLA.isNull("idlineapedido") || !curLA.valueBuffer("idlineapedido")) {
		return _i.__controlStockAlbaranesProv(curLA);
	}
	return true;
}

function euromoda_controlStockAlbProvCrudo(curLA)
{
	var _i = this.iface;
	if (curLA.modeAccess() == curLA.Del || curLA.modeAccess() == curLA.Insert) {
		return _i.__controlStockAlbaranesProv(curLA);
	}
	if (curLA.valueBuffer("referencia") == curLA.valueBufferCopy("referencia") && curLA.valueBuffer("cantidad") != curLA.valueBufferCopy("cantidad")) {
		var codLoteDist = AQUtil.sqlSelect("movistock ms INNER JOIN lotesstock ls ON ms.codlote = ls.codlote", "ls.codlote", "ms.idlineaap = " + curLA.valueBuffer("idlinea") + " AND ls.distribucionfin", "movistock");
		if (codLoteDist) {
			sys.warnMsgBox(sys.translate("La partida %1 ya est� distribuida, no puede modificar la cantidad").arg(codLoteDist));
			return false;
		}
		if (!AQSql.update("movistock", ["cantidad"] , [curLA.valueBuffer("cantidad")], "idlineaap = " + curLA.valueBuffer("idlinea"))) {
			return false;
		}
	} else {
		return _i.__controlStockAlbaranesProv(curLA);
	}
	return true;
}


function euromoda_controlStockAlbaranesCli(curLA)
{
	var _i = this.iface;
	
	//  var curR = curLA.cursorRelation();
	//  if (curR && curR.table() == "albaranescli") {
	//    if (curR.valueBuffer("idgit") != 0 && !curR.isNull("idgit")) {
	//      return true;
	//    }
	//  } else {
	//    if (AQUtil.sqlSelect("albaranescli", "idgit", "idalbaran = " + curLA.valueBuffer("idlinea"))) {
	//      return true;
	//    }
	//  }
	//
	var referencia = curLA.valueBuffer("referencia")
									 if (_i.esReferenciaXPiezas(referencia) || (_i.esReferenciaXPartidas(referencia))) {
		return _i.controlStockAlbCliTrazable(curLA);
	}
	return _i.__controlStockAlbaranesCli(curLA);
}

/// Las l�neas de albar�n de piezas o partidas se meten a mano, por lo que no han de recalcularse
function euromoda_controlStockAlbCliTrazable(curLA)
{
	var _i = this.iface;
	if (curLA.modeAccess() == curLA.Del) {
		return _i.__controlStockAlbaranesCli(curLA);
	}
	return true;
}

function euromoda_datosStockLineaCambian(curLinea)
{
	var _i = this.iface;	
	var cambian = _i.__datosStockLineaCambian(curLinea);
	if (!cambian) {	
		switch (curLinea.table()) {
			case "lineaspedidomarcocli": {
				var cantidad = curLinea.valueBuffer("canpendiente");
				var cantidadAnterior = curLinea.valueBufferCopy("canpendiente");
				var referencia = curLinea.valueBuffer("referencia");
				var referenciaAnterior = curLinea.valueBufferCopy("referencia");
				cambian = (cantidad != cantidadAnterior || referencia != referenciaAnterior);
				break;
			}
			case "lineaspedidoscli": {
				//cambian = curLinea.valueBuffer("forzarafaltas") != curLinea.valueBufferCopy("forzarafaltas");
				cambian = (curLinea.valueBuffer("forzarafaltas") != curLinea.valueBufferCopy("forzarafaltas") || curLinea.valueBuffer("agotarexistencias") != curLinea.valueBufferCopy("agotarexistencias"));
				break;
			}
			default: {
				cambian = _i.__datosStockLineaCambian(curLinea);
			}
		}
	}
	return cambian;
}

function euromoda_generaConsumosProducto(referencia, cantidad, idLineaPedido, codLote, codAlmacen, soloTejido, hechos)
{
	var _i = this.iface;
	var curComponentes = new FLSqlCursor("articuloscomp");
	var whereComponentes = "refcompuesto = '" + referencia + "'";
	if (soloTejido) {
		whereComponentes += "";
	}
	curComponentes.select(whereComponentes);
	
	var numComponentes = curComponentes.size();
	//  var codAlmacen = curLote.valueBuffer("codalmacen")
	// debug("euromoda_generaConsumosProducto " + codLote + " = " + idLineaPedido);
	var idComp, canComponente, refComponente, nuevaCantidad, idStock;
	var curMS = new FLSqlCursor("movistock");
	//  curMS.setActivatedCommitActions(false);
	//  curMS.setActivatedCheckIntegrity(false);
	var hoy = new Date;
	var datosOrden = flfactppal.iface.pub_ejecutarQry("lotesstock ls INNER JOIN pr_ordenesproduccion op ON ls.codordenproduccion = op.codorden LEFT OUTER JOIN proveedores p ON op.codconfeccionista = p.codproveedor", "op.estado,op.codorden,p.codalmacen", "ls.codlote = '" + codLote + "'", "lotesstock", false);
	if (datosOrden.result != 1) {
		datosOrden["op.codorden"] = sys.translate("(Sin orden)");
		datosOrden["op.estado"] = false;
		datosOrden["p.codalmacen"] = false;
	}
	datosOrden["p.codalmacen"] = datosOrden["p.codalmacen"] ? datosOrden["p.codalmacen"] : codAlmacen;
	
	var estadoOrden = datosOrden["op.estado"]; //AQUtil.sqlSelect("lotesstock ls INNER JOIN pr_ordenesproduccion op ON ls.codordenproduccion = op.codorden", "op.estado", "ls.codlote = '" + codLote + "'", "lotesstock");
	estadoOrden = estadoOrden ? estadoOrden : "PTE";
	var concepto = sys.translate("Consumo en la orden %1 para el lote %2").arg(datosOrden["op.codorden"]).arg(codLote);
	var codAlmacenComp, esXPiezas, codSubfamiliaComponente;
	var oParamMargen = new Object;
	while (curComponentes.next()) {
		
		refComponente = curComponentes.valueBuffer("refcomponente");
		esXPiezas = flfactalma.iface.pub_esReferenciaXPiezas(refComponente);
		codAlmacenComp = esXPiezas ? codAlmacen : datosOrden["p.codalmacen"];
		
		canComponente = curComponentes.valueBuffer("cantidad");
		idComp = curComponentes.valueBuffer("id");
		nuevaCantidad = cantidad * canComponente * curComponentes.valueBuffer("factor") * -1;
		/// A�adido por Antonio, a revisar por Pozu. �no es redundante pasar la subfamilia si ya pasamos la referencia?		
		


		//var referenciaMargen = _i.dameReferenciaAnverso(curComponentes.valueBuffer("refcompuesto"), refComponente, idComp);	
		var oAnverso = _i.dameReferenciaAnverso(curComponentes.valueBuffer("refcompuesto"), refComponente, idComp);
		var referenciaMargen = oAnverso.referenciaAnverso;
		var factor = oAnverso.factor;
		
		//debug("referenciaMargen: "+referenciaMargen);
		//debug("factor: "+factor);
		if(referenciaMargen) {
			var codSubfamProd = AQUtil.sqlSelect("articulos","codsubfamilia","referencia = '" + curComponentes.valueBuffer("refcompuesto") + "' ");
			//cantidad = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, cantidad, true)			
			//margen = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, nuevaCantidad, true, factor);	


			oParamMargen.referencia = referenciaMargen;
			oParamMargen.codSubfamilia = codSubfamProd
			oParamMargen.cantidad = nuevaCantidad;
			oParamMargen.noInicio = true
			oParamMargen.factor = factor;
			oParamMargen.cantidadM =  cantidad;
			oParamMargen.cantidadFT = canComponente;
			oParamMargen.piezasAncho = curComponentes.valueBuffer("piezasancho");

			margen = fleumoesta.iface.dameCantidadMargen(oParamMargen);

			/*var piezasAncho = curComponentes.valueBuffer("piezasancho"); 15-11-2017
			if(piezasAncho && piezasAncho != 0)  {
				margen = margen / piezasAncho;
			}*/
		}

		if(factor && factor != "" && referenciaMargen) {
			//factor += margen; 15-11-2017
			//nuevaCantidad = -1 * cantidad * factor; 15-11-2017
			nuevaCantidad = -1*(cantidad*factor + margen);
			
		}
		//debug("---------------------------------------------------------------------------------------------------------------");

		
		/*if(referenciaMargen) {
			var codSubfamProd = AQUtil.sqlSelect("articulos","codsubfamilia","referencia = '" + curComponentes.valueBuffer("refcompuesto") + "' ");
			nuevaCantidad = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, nuevaCantidad, true)
		}	*/
		
		//var codSubfamiliaComponente = AQUtil.quickSqlSelect("articulos", "codsubfamilia", "referencia = '" + refComponente + "'");
		//nuevaCantidad = fleumoesta.iface.dameCantidadMargen(refComponente, codSubfamiliaComponente, nuevaCantidad)
		/// Fin a�adido
		
		var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + refComponente + "' AND codalmacen = '" + codAlmacenComp + "'");
		if (!idStock) {
			var oArticulo = new Object;
			oArticulo["referencia"] = refComponente;
			idStock = flfactalma.iface.pub_crearStock(codAlmacenComp, oArticulo);
			if (!idStock) {
				return false;
			}
		}
		curComponentes.setModeAccess(curComponentes.Browse);
		curComponentes.refreshBuffer();
		
		curMS.setModeAccess(curMS.Insert);
		curMS.refreshBuffer();
		curMS.setValueBuffer("referencia", refComponente);
		if (hechos) {
			if (esXPiezas) {
				curMS.setValueBuffer("estado", "OFF");
			} else {
				curMS.setValueBuffer("estado", "HECHO");
			}
			curMS.setValueBuffer("fechareal", hoy);
			curMS.setValueBuffer("horareal", hoy.toString().right(8));
		} else {
			if (estadoOrden != "PTE" && esXPiezas) {
				curMS.setValueBuffer("estado", "OFF");
			} else {
				curMS.setValueBuffer("estado", "PTE");
			}
			curMS.setValueBuffer("fechaprev", hoy);
		}
		curMS.setValueBuffer("cantidad", AQUtil.roundFieldValue(nuevaCantidad, "movistock", "cantidad"));
		
		curMS.setValueBuffer("idStock", idStock);
		if (codLote) {
			curMS.setValueBuffer("codloteprod", codLote);

		} else if (idLineaPedido) {
			curMS.setValueBuffer("idlineapc", idLineaPedido);

		}
		curMS.setValueBuffer("concepto", concepto);
		
		curMS.setValueBuffer("idarticulocomp", idComp);
		if (!curMS.commitBuffer()) {
			return false;
		}
		//    _i.apuntaStockARevisar(idStock);
		//    if (!_i.generarMoviStock(curLote, false, nuevaCantidad, curComponentes, false)) {
		//      return false;
		//    }


		/************* POZU 27-05-2020 SI EXISTE rservaslotepedido crearla *****/





		
		//debug("codLote: "+codLote);
		//debug("idComp: "+idComp);
		//debug("idLineaPedido: "+idLineaPedido);

		var idLineaProducto = AQUtil.sqlSelect("em_reservaslotepedido","idlineapc","codlote = '" + codLote + "'");

		if(idLineaProducto) {
			var qRLP = new AQSqlQuery;	
			qRLP.setSelect("idlineapc, codlote, cantidad, idrlp,idarticulocomp");
			qRLP.setFrom("em_reservaslotepedido");
			qRLP.setWhere("idlineapc = " + idLineaProducto + " AND idarticulocomp = " + idComp);
			//debug("qRLP: "+qRLP.sql());
			if (!qRLP.exec()) {
				return false;
			}
			while (qRLP.next()) {	
				//debug("------------ crea reservas para producto componente");
				var oParam = new Object;
				oParam["idLineaPedido"] = qRLP.value("idlineapc"); 
				oParam["codLote"] = qRLP.value("codlote"); 
				oParam["cantidad"] = qRLP.value("cantidad"); 
				oParam["idRLP"] = qRLP.value("idrlp");
				oParam["idArticuloComp"] = idComp;
				if (!_i.creaReservasPedidoProdComp(oParam)) {
					return false;
				}				
			}
		}
		//idLineaPedido = false;
		/************* POZU 27-05-2020 SI EXISTE *****/

	}


	if (!soloTejido) {
		var codCliente = false;

		if(codLote && codLote != "") {
			codCliente = AQUtil.sqlSelect("em_reservaslotepedido r left outer join lineaspedidoscli lp on r.idlineapc = lp.idlinea left outer join pedidoscli p on lp.idpedido = p.idpedido","p.codcliente","r.codlote = '" + codLote + "'","em_reservaslotepedido,pedidoscli,lineaspedidoscli");
			
		} else if (idLineaPedido) {
			codCliente = AQUtil.sqlSelect("lineaspedidoscli lp inner join pedidoscli p on lp.idpedido = p.idpedido","p.codcliente","lp.idlinea = " + idLineaPedido,"pedidoscli,lineaspedidoscli");				
		}


		

		var aDatosEmbalaje = flfactalma.iface.dameEmbalajeArticulo(referencia, codCliente, true);
		if (!aDatosEmbalaje) {
			return false;
		}
		if (aDatosEmbalaje.referencia) {
			var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + aDatosEmbalaje.referencia + "' AND codalmacen = '" + datosOrden["p.codalmacen"] + "'");
			if (!idStock) {
				var oArticulo = new Object;
				oArticulo["referencia"] = aDatosEmbalaje.referencia;
				idStock = flfactalma.iface.pub_crearStock(datosOrden["p.codalmacen"], oArticulo);
				if (!idStock) {
					return false;
				}
			}
			var canEmbal = Math.ceil(cantidad / aDatosEmbalaje.capacidad);
			canEmbal *= -1;
			var curMS = new FLSqlCursor("movistock");
			curMS.setModeAccess(curMS.Insert);
			curMS.refreshBuffer();
			curMS.setValueBuffer("referencia", aDatosEmbalaje.referencia);
			if (hechos) {
				curMS.setValueBuffer("estado", "HECHO");
				curMS.setValueBuffer("fechareal", hoy);
				curMS.setValueBuffer("horareal", hoy.toString().right(8));
			} else {
				curMS.setValueBuffer("estado", "PTE");
				curMS.setValueBuffer("fechaprev", hoy);
			}
			curMS.setValueBuffer("cantidad", canEmbal);
			curMS.setValueBuffer("idstock", idStock);
			curMS.setValueBuffer("codloteprod", codLote);
			curMS.setValueBuffer("concepto", concepto);
			if (idLineaPedido) {
				curMS.setValueBuffer("idlineapc", idLineaPedido);
			}
			if (!curMS.commitBuffer()) {
				return false;
			}
			//      _i.apuntaStockARevisar(idStock);
		}
	}
	return true;
}


// function euromoda_actualizarStockT0(idStock)
// {
//  var _i = this.iface;
//  return _i.__actualizarStock(idStock);
// // Copiado de El Ganso
// //   var curStock:FLSqlCursor = new FLSqlCursor("stocks");
// //   curStock.select("idstock = " + idStock);
// //   if (!curStock.first()) {
// //     return false;
// //   }
// //   curStock.setModeAccess(curStock.Edit);
// //   curStock.refreshBuffer();
// //   curStock.setValueBuffer("cantidad", formRecordregstocks.iface.pub_commonCalculateField("cantidad", curStock));
// //   curStock.setValueBuffer("disponible", formRecordregstocks.iface.pub_commonCalculateField("disponible", curStock));
// // debug("Actualizando stock de " + curStock.valueBuffer("barcode") + ", " + curStock.valueBuffer("codalmacen") + " a " + curStock.valueBuffer("cantidad"));
// //   if (!curStock.commitBuffer()) {
// //     return false;
// //   }
//  return true;
// }
//
// function euromoda_actualizarStockPteRecibirT0(idStock)
// {
//  var _i = this.iface;
//  return _i.__actualizarStockPteRecibir(idStock);
// }
//
// function euromoda_actualizarStockPteServirT0(idStock)
// {
//  var _i = this.iface;
//  return _i.__actualizarStockPteServir(idStock);
// }

function euromoda_activaTransactionSignals()
{
	var _i = this.iface;
	//debug("euromoda_activaTransactionSignals");
	//  if (!aqApp.notifyEndTransaction()) {
	aqApp.setNotifyEndTransaction(false);
	disconnect(aqApp.self(), "transactionEnd(QObject*)", _i, "processEndTran()");
	aqApp.setNotifyEndTransaction(true);
	connect(aqApp.self(), "transactionEnd(QObject*)", _i, "processEndTran()");
	//   }
	
	//   if (!aqApp.notifyRollbackTransaction()) {
	aqApp.setNotifyRollbackTransaction(false);
	disconnect(aqApp.self(), "transactionRollback(QObject*)", _i, "processRollbackTran()");
	aqApp.setNotifyRollbackTransaction(true);
	connect(aqApp.self(), "transactionRollback(QObject*)", _i, "processRollbackTran()");
	//   }
	return true;
}


function euromoda_actualizarStock(idStock, codSubfamiliaTP)
{
	var _i = this.iface;	
	
	
	if (!_i.activaTransactionSignals()) {
	//debug("Falla 5");
		return false;
	}
	if (!_i.marcaStockPte(idStock, "STOCK_FISICO", codSubfamiliaTP)) {
	//debug("Falla 6");
		return false;
	}	
    //debug("tarda un huevo_2__");
	if (sys.transactionLevel() == 0 && !_i.enProcesaStocks_) {
        //debug("tarda un huevo_3__");
		_i.procesaStocks(idStock);
		//_i.procesaStocks();
	}
    //debug("tarda un huevo_4__");
	return true;
		
}

function euromoda_marcaStockPte(idStock, tipoA, codSubfamiliaTP)
{
	var idUsuario = sys.nameUser();
	var stockDiferido = AQUtil.sqlSelect("au_general", "stockdiferido", "1 = 1");
	/*if (stockDiferido && codSubfamiliaTP && codSubfamiliaTP != "") {
		idUsuario = "stockdiferido";
	}*/

	if (stockDiferido) {
		idUsuario = "stockdiferido";
	}
	var valorSql;
	if (codSubfamiliaTP && codSubfamiliaTP != "") {
		if (AQUtil.quickSqlSelect("stocksptes", "idstockpte", "idstock = " + idStock + " AND idusuario = '" + idUsuario + "' AND tipoactualizacion = '" + tipoA + "' AND codsubfamiliatp = '" + codSubfamiliaTP + "'")) {
			return true;
		}
		valorSql = "'" + codSubfamiliaTP + "'";
	} else {
		if (AQUtil.quickSqlSelect("stocksptes", "idstockpte", "idstock = " + idStock + " AND idusuario = '" + idUsuario + "' AND tipoactualizacion = '" + tipoA + "' AND codsubfamiliatp IS NULL")) {
			return true;
		}
		valorSql = "NULL";
	}
	if (!AQUtil.execSql("INSERT INTO stocksptes (idstock, idusuario, tipoactualizacion, fecha, timestamp, codsubfamiliatp) VALUES (" + idStock + ", '" + idUsuario + "', '" + tipoA + "', CURRENT_DATE, CURRENT_TIMESTAMP, " + valorSql + ")")) {
		return false;
	}	
    //debug("tarda un huevo_1__");
	return true;
}

function euromoda_actualizarStockPteServir(idStock, codSubfamiliaTP)
{
	var _i = this.iface;	

	
	if (!_i.activaTransactionSignals()) {
	//debug("Falla 3");
		return false;
	}
	if (!_i.marcaStockPte(idStock, "PTE_SERVIR", codSubfamiliaTP)) {
	//debug("Falla 4");
		return false;
	}
	
	if (sys.transactionLevel() == 0 && !_i.enProcesaStocks_) {
		_i.procesaStocks(idStock);
		//_i.procesaStocks();
	}

	return true;
}

function euromoda_actualizarStockPteRecibir(idStock, codSubfamiliaTP)
{
	var _i = this.iface;
	
	if (!_i.activaTransactionSignals()) {
	   //debug("Falla 1");
		return false;
	}
	if (!_i.marcaStockPte(idStock, "PTE_SERVIR", codSubfamiliaTP)) { /// Se marca lo mismo que pte servir porque la funci�n calcula los dos valores
	   //debug("Falla 2");
		return false;
	}

	if (sys.transactionLevel() == 0 && !_i.enProcesaStocks_) {
		_i.procesaStocks(idStock);
		//_i.procesaStocks();
	}

	
	return true;
}

function euromoda_processEndTran(obj)
{
	//debug("oficial_processEndTran");
	
	//  if (obj) {
	//    debug(obj);
	//    debug(obj.name);
	//    debug(obj.metadata().name);
	//    debug(obj.lastQuery());
	//    print("====");
	//  }
	
	var _i = this.iface;
	if (!_i.procesaStocks()) {
		return false;
	}
}

function euromoda_processRollbackTran()
{
	return;
	//  var _i = this.iface;
	//  debug("Borrando cach� stocks....");
	//  if (!_i.stocksPtes_) {
	//    return false;
	//  }
	//  delete _i.stocksPtes_;
}

function euromoda_procesaStocks(usuario)
{
	
	
	var idUsuario = usuario ? usuario : sys.nameUser();

	var _i = this.iface;
	_i.enProcesaStocks_ = true;
	_i.estadoProcesoStock0_ = undefined;
	_i.estadoProcesoStock0_ = new Object;
	_i.estadoProcesoStock0_["activo"] = true;

	var curSP = new FLSqlCursor("stocksptes");
	curSP.select("idusuario = '" + idUsuario + "' ORDER BY idstockpte");
	var idStock;

	var hayStock = AQUtil.sqlSelect("stocksptes", "idstock", "idusuario = '" + idUsuario + "'");
	var vuelta = 0;
	var codSubfamiliaTP;
	while (hayStock) {
		//debug("VUELTA VUELTA VUELTA VUELTA VUELTA VUELTA VUELTA VUELTA VUELTA VUELTA VUELTA VUELTA " + ++vuelta);
		var p = 0;
		curSP.select("idusuario = '" + idUsuario + "'");
		while (curSP.next()) {
			curSP.setModeAccess(curSP.Del);
			curSP.refreshBuffer();
			idStock = curSP.valueBuffer("idstock");
			codSubfamiliaTP = curSP.isNull("codsubfamiliatp") ? false : curSP.valueBuffer("codsubfamiliatp");
			//debug("procesando stock " + idStock + " tipo " + curSP.valueBuffer("tipoactualizacion"));
			_i.estadoProcesoStock0_["idstockactivo"] = idStock;
			switch (curSP.valueBuffer("tipoactualizacion")) {
				case "STOCK_FISICO": {
					if (!_i.actualizarStockT0(idStock, codSubfamiliaTP)) {
						_i.estadoProcesoStock0_["activo"] = false;
						_i.enProcesaStocks_ = false;
						return false;
					}
					break;
				}
				case "PTE_SERVIR": {
					if (!_i.revisarReservasStock(idStock,0,0, codSubfamiliaTP)) { //preguntar a Antonio que le he puesto los 0, 0
						_i.estadoProcesoStock0_["activo"] = false;
						_i.enProcesaStocks_ = false;
						return false;
					}
					break;
				}
				case "PTE_RECIBIR": {
					if (!_i.actualizarStockPteRecibirT0(idStock, codSubfamiliaTP)) {
						_i.estadoProcesoStock0_["activo"] = false;
						_i.enProcesaStocks_ = false;
						return false;
					}
					break;
				}
			}
			if (!curSP.commitBuffer()) {
				_i.estadoProcesoStock0_["activo"] = false;
				//debug("Error al procesar stock pte " + idStock);
				_i.enProcesaStocks_ = false;
				return false;
			}
		}
		hayStock = AQUtil.sqlSelect("stocksptes", "idstock", "idusuario = '" + idUsuario + "'");
	}
	_i.estadoProcesoStock0_["activo"] = false;
	_i.enProcesaStocks_ = false;
	//debug("euromoda_procesaStocks ok");
	return true;
}

function euromoda_rpcDatosPieza(args)
{
	var _i = this.iface;
	if (!args) {
		return "<valor error='2' DesError='No se ha indicado c�digo de pieza' ART='' M=''/>";
	}
	var codLote = args;
	var xml;
	var d = _i.dameDatosPiezaRPC(codLote);
	if (d.result == 1) {
		xml = "<valor error='0' DesError='' ART='" + d.referencia + "' M='" + d.candisponible + "' />";
	} else {
		xml = "<valor error='1' DesError='Pieza no encontrada' ART='' M='' />";
	}
	return xml;
}

function euromoda_dameDatosPiezaRPC(codLote)
{
	var _i = this.iface;
	var d = flfactppal.iface.pub_ejecutarQry("lotesstock", "referencia,articulo,candisponible,codlote", "codlote = '" + codLote +  "'", false);
	if (d.result == 1) {
		return d;
	}
	// debug("codLote.length " + codLote.length);
	var codPiezaGit = false;
	if (codLote.length == 12) {
		codPiezaGit = codLote.mid(0, 6);
	}
	if (codLote.length == 13) {
		codPiezaGit = codLote.mid(1, 6);
	}
	// debug("codPiezaGit " + codPiezaGit );
	if (codPiezaGit) {
		return flfactppal.iface.pub_ejecutarQry("lotesstock", "referencia,articulo,candisponible,codlote", "codigogit = '" + codPiezaGit + "'", false);
	}
	return d;
}

function euromoda_rpcRestaMetrosPieza(args)
{
	var _i = this.iface;
	if (!args) {
		return "<valor error='2' DesError='No se ha indicado c�digo de pieza' ART='' M=''/>";
	}
	
	var oParam = new Object;
	var datos = args.split(";");
	oParam.codLote = datos[0];
	var m = datos[1];
	
	var d = _i.dameDatosPiezaRPC(oParam.codLote);
	// debug("1");
	if (d.result != 1) {
		return "<valor error='0' DesError='' ART='" + d.referencia + "' M='" + d.candisponible + "' />";
	}
	// debug("2");
	oParam.codLote = d.codlote;
	oParam.referencia = d.referencia;
	oParam.codAlmacen = AQUtil.sqlSelect("lotesstock", "codalmacen", "codlote = '" + d.codlote + "'");
	
	if (!oParam.codAlmacen) {
	
		oParam.codAlmacen = flfactppal.iface.valorDefectoEmpresa("codalmacen");
	}
	oParam.idStock = _i.dameIdStock(oParam.codAlmacen, oParam);
	if (!oParam.idStock) {
		return "<valor error='10' DesError='Error al obtener el registro de stock' ART='' M=''/>";
	}
	
	var canDisponible = parseFloat(d.candisponible);
	if (!canDisponible || canDisponible < m) {
		return "<valor error='3' DesError='No hay suficientes metros disponibles de tela' ART='' M=''/>";
	}
	
	oParam.consumo = m * -1;
	oParam.errorMsg = sys.translate("Error restar metros de la pieza");
	
	if (!_i.trRestaMetrosPieza(oParam)) {
		return "<valor error='4' DesError='" + oParam.errorMsg + "' ART='' M=''/>";
	}
	
	d = _i.dameDatosPiezaRPC(oParam.codLote);
	
	if (d.result == 1) {
		xml = "<valor error='0' DesError='' ART='" + d.referencia + "' M='" + d.candisponible + "' />";
	} else {
		xml = "<valor error='5' DesError='Pieza no encontrada tras restar los metros' ART='' M='' />";
	}
	
	return xml;
}

function euromoda_trRestaMetrosPieza(oParam)
{
	
	var hoy = new Date();
	var curMS = new FLSqlCursor("movistock");
	curMS.setModeAccess(curMS.Insert);
	curMS.refreshBuffer();
	curMS.setValueBuffer("referencia", oParam.referencia);
	curMS.setValueBuffer("estado", "HECHO");
	curMS.setValueBuffer("cantidad", oParam.consumo);
	curMS.setValueBuffer("fechareal", hoy.toString().left(10));
	curMS.setValueBuffer("horareal", hoy.toString().right(8));
	curMS.setValueBuffer("idstock", oParam.idStock);
	curMS.setValueBuffer("codlote", oParam.codLote);
	if (!curMS.commitBuffer()) {
		oParam.errorMsg = sys.translate("Error al guardar el movimiento de stock");
		return false;
	}
	return true;
}

function euromoda_controlStockFisicoArticulos(curStock)
{
	return true;
}

function euromoda_controlIdSincroStock(curStock)
{
	return true;
}

function euromoda_controlIdSincroRegStock(curL)
{
	return true;
}

function euromoda_estadosMovBorrablesComp()
{
	var _i = this.iface;
	var e = _i.__estadosMovBorrablesComp();
	e.push("OFF");
	return e;
}

function euromoda_calculaFechasPedidos(masW)
{
	var _i = this.iface;
	if (!_i.calculaFechasPedidosMov(masW)) {
		return false;
	}
	return true;
}

// function euromoda_calculaFechasPedidosMov(masW)
// {
//  var _i = this.iface;
//  var w = "p.servido IN ('No', 'Parcial') AND NOT lp.cerrada AND lp.cantidad - lp.totalenalbaran > 0 AND ms.estado = 'PTE'";
//
//  var q = new AQSqlQuery;
//  q.setSelect("ms.idmovimiento, ms.cantidad, ms.reservaex, ms.reservapr, ms.reservaaf");
//  q.setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN movistock ms ON lp.idlinea = ms.idlineapc");
//  w += masW != "" ? (" AND " + masW) : "";
//  q.setWhere(w)
//  flfactppal.iface.pub_creaDialogoProceso(sys.translate("Actualizando fechas en movimientos de stock"), q.size());
//  var p = 0;
//  var hoy = new Date;
//
//  var reservaEx, reservaPr, reservaAf;
//  while (q.next()) {
//    AQUtil.setProgress(p++);
//    reservaEx = q.value("reservadoex")
//    reservaEx = isNaN(reservaEx) ? 0 : reservaEx;
//    reservaPr = q.value("reservadopr")
//    reservaPr = isNaN(reservaPr) ? 0 : reservaPr;
//    reservaAf = q.value("reservadoaf")
//    reservaAf = isNaN(reservaAf) ? 0 : reservaAf;
//    if (reservaAf > 0) {
//
//    }
//  }
// }

function euromoda_controlStockPedidosProv(curLP)
{
	var _i = this.iface;
	
	if (curLP.valueBuffer("xpartidas")) {
		return _i.controlStockPedidosProvXPartidas(curLP);
	}
	return _i.__controlStockPedidosProv(curLP);
}

function euromoda_controlStockPedidosProvXPartidas(curLP)
{
	var _i = this.iface;
	if (curLP.modeAccess() == curLP.Del) {
		return _i.__controlStockPedidosProv(curLP);
	}
	if (curLP.modeAccess() == curLP.Edit) {
		/* Eliminado porque la crean con xpartidas = false y luego la editan para asociarle la partida
		if (!curLP.valueBufferCopy("xpartidas")) {
			if (!_i.borrarEstructura(curLP)) {
				return false;
			}
		}
		*/
		if (curLP.valueBuffer("totalenalbaran") != curLP.valueBufferCopy("totalenalbaran") || curLP.valueBuffer("cerrada") != curLP.valueBufferCopy("cerrada")) {
			if (!_i.recalcularMovPartidasPtesPP(curLP)) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_recalcularMovPartidasPtesPP(curLP)
{
	
	var curMS = new FLSqlCursor("movistock");
	curMS.select("idlineapp = " + curLP.valueBuffer("idlinea"));
	var canRecibida, canPedida, canPte;
	while (curMS.next()) {
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		/// Eliminado porque si est� cerrada o en merma no se contar� el stock, pero debe permanecer el movimiento para calcular correctamente la merma
		//    if (curLP.valueBuffer("cerrada") || curMS.valueBuffer("merma")) {
		//      canPte = 0;
		//    } else {
		canRecibida = formRecordem_movistockpartidaspp.iface.pub_commonCalculateField("canrecibida", curMS);
		canPte = curMS.valueBuffer("canpedida") - canRecibida;
		canPte = canPte < 0 ? 0 : canPte;
		//    }
		if (canPte == curMS.valueBuffer("cantidad") && curLP.valueBuffer("cerrada") == curLP.valueBufferCopy("cerrada")) {
			continue;
		}
		//    canPte = canPte < 0 ? 0 : canPte /// Hay que tener en cuenta mermas negativas
		curMS.setValueBuffer("cantidad", canPte);
		if (curLP.valueBuffer("cerrada")) {
			curMS.setValueBuffer("em_merma", true);
		} else {
			if (canPte < 0) {
				curMS.setValueBuffer("em_merma", true);
			} else {
				curMS.setValueBuffer("em_merma", false);
			}
		}
		if (!curMS.commitBuffer()) {
			//debug("euromoda_recalcularMovPartidasPtesPP false");
			return false;
		}
	}
	
	return true;
}

function euromoda_dameSesion()
{
	var _i = this.iface;
	if (_i.idSesion_) {
		return _i.idSesion_;
	}
	var d = new Date;
	var t = d.getTime();
	var hace2dias = t - 172800000;
	var s2D = flfactppal.iface.pub_cerosIzquierda(hace2dias.toString(), 30);
	var idS2D = sys.nameUser() + "_" + s2D;
	AQUtil.execSql("DELETE FROM em_filtrosarticulos WHERE sesion < '" + idS2D + "'");
	
	var sT = flfactppal.iface.pub_cerosIzquierda(t.toString(), 30);
	_i.idSesion_ = sys.nameUser() + "_" + sT;
	return _i.idSesion_;
}

function euromoda_afterCommit_articulos(curA)
{
	var _i = this.iface;
	if (!_i.__afterCommit_articulos(curA)) {
		return false;
	}
	if (!_i.controlCambioDatosArticulo(curA)) {
		return false;
	}
	return true;
}

function euromoda_controlCambioDatosArticulo(curA)
{
	if (curA.modeAccess() != curA.Edit) {
		return true;
	}
	var campos = ["descripcion", "codtamanoem", "codcolorem", "coddibestamp", "emdibujo", "codbarras"];
	var mod = false;
	for (var i = 0; i < campos.length; i++) {
		if (curA.valueBuffer(campos[i]) != curA.valueBufferCopy(campos[i])) {
			mod = true;
			break;
		}
	}
	if (!mod) {
		return true;
	}
	var referencia = curA.valueBuffer("referencia");
	var vB = curA.valueBuffer;
	if (!AQUtil.execSql("UPDATE stocks SET articulo = '" + flfactppal.iface.pub_formateaDescripcionSQL(vB("descripcion")) + "', codtamanoem = '" + vB("codtamanoem") + "', codcolorem = '" + vB("codcolorem") + "', coddibestamp = '" + vB("coddibestamp") + "', emdibujo = '" + flfactppal.iface.pub_formateaDescripcionSQL(vB("emdibujo")) + "', codbarras = '" + vB("codbarras") + "' WHERE referencia = '" + vB("referencia") + "'")) {
		return false;
	}
	if (!AQUtil.execSql("UPDATE lotesstock SET articulo = '" + flfactppal.iface.pub_formateaDescripcionSQL(vB("descripcion")) + "' WHERE referencia = '" + vB("referencia") + "'")) {
		return false;
	}
	return true;
}

/** Obtiene la siguiente referencia de tejido preparado para la ruta de tejidos preparados de una subfamilia de tejido estampado.
Si la ruta no existe o la referencia indicada es la �ltima de la ruta, devuelve -1
**/
function euromoda_dameSiguienteTejidoPrep(codSubfamilia, idStock)
{
	var _i = this.iface;
	var o = new Object;

	var refTejido2, idStock2;
	if (!_i.rutasTejidoPrep_) {
		if (!_i.cargaRutasTejidoPrep()) {
			return false;
		}
	}

	if (!(codSubfamilia in _i.rutasTejidoPrep_)) {
	   //debug("Subfamilia " + codSubfamilia + " no est� en las rutas");
		o.referencia = -1;
		return o;
	}
	var iRuta;
	if (idStock) {		
		if (!(idStock in _i.rutasTejidoPrep_[codSubfamilia]["stocks"])) {		
			iRuta = -1;
		} else {
			iRuta = _i.rutasTejidoPrep_[codSubfamilia]["stocks"][idStock];
		}
	} else {
		iRuta = -1;
	}
	var lonRuta = _i.rutasTejidoPrep_[codSubfamilia]["referencia"].length;
	if (iRuta < (lonRuta - 1)) {
		iRuta++;
		refTejido2 = _i.rutasTejidoPrep_[codSubfamilia]["referencia"][iRuta];
		idStock2 = _i.rutasTejidoPrep_[codSubfamilia]["idstock"][iRuta];
	} else {
		refTejido2 = -1;
		idStock2 = "";
	}
	o.referencia = refTejido2;
	o.idStock = idStock2;
	return o;
}

function euromoda_cargaRutasTejidoPrep()
{
	var _i = this.iface;
	
	var codSubfamiliaAnt, codSubfamilia, refTejido, codAlmacen;
	var q = new AQSqlQuery;
	q.setSelect("r.codsubfamilia, r.referencia, t.codalmacen, s.idstock");
	q.setFrom("em_rutastpsubfam r INNER JOIN em_tipostejidoprep t ON r.codtipotejidoprep = t.codtipotejidoprep LEFT OUTER JOIN stocks s ON (r.referencia = s.referencia AND t.codalmacen = s.codalmacen)");
	q.setWhere("1 = 1 ORDER BY r.codsubfamilia, r.numlinea");
	if (!q.exec()) {
		return false;
	}
	_i.rutasTejidoPrep_ = new Object;
	var iRuta = 0, idStock;
	while (q.next()) {
		codAlmacen = q.value("t.codalmacen");
		codSubfamilia = q.value("r.codsubfamilia");
		refTejido = q.value("r.referencia");
		if (codSubfamilia != codSubfamiliaAnt || codSubfamiliaAnt == undefined) {
			_i.rutasTejidoPrep_[codSubfamilia] = new Object;
			_i.rutasTejidoPrep_[codSubfamilia]["referencia"] = [];
			_i.rutasTejidoPrep_[codSubfamilia]["idstock"] = [];
			_i.rutasTejidoPrep_[codSubfamilia]["stocks"] = new Object;
			iRuta = 0;
			codSubfamiliaAnt = codSubfamilia;
		}
		idStock = q.value("s.idstock");
		if (!idStock) {
			var oStock = new Object;
			oStock.referencia = refTejido;
			idStock = _i.crearStock(codAlmacen, oStock);
			if (!idStock) {
				return false;
			}
		}
		_i.rutasTejidoPrep_[codSubfamilia]["referencia"][iRuta] = refTejido;
		_i.rutasTejidoPrep_[codSubfamilia]["idstock"][iRuta] = idStock;
		_i.rutasTejidoPrep_[codSubfamilia]["stocks"][idStock] = iRuta;
		//debug("Ruta para subfamilia " + codSubfamilia  + " id " + idStock + " Ref " + refTejido);
		iRuta++;
	}
	return true;
}

function euromoda_afterCommit_subfamilias(curS)
{
	var _i = this.iface;
	if (!_i.recargaRutasTejidoPrep()) {
		return false;
	}
	return true;
}

function euromoda_recargaRutasTejidoPrep()
{
	var _i = this.iface;
	_i.rutasTejidoPrep_ = undefined;
	if (!_i.cargaRutasTejidoPrep()) {
		return false;
	}

	return true;
}

function euromoda_revisaReservasMSAFaltas(curMS,oStockMod)
{
	var _i = this.iface;
	//debug("\n\n\n\n-------------------euromoda_revisaReservasMSAFaltas");
	if (!curMS.isNull("idmovproducto")) {
		return true;
	}
	if (!curMS.isNull("codloteprod")) {
		return true;
	}
	//debug("-------------------euromoda_revisaReservasMSAFaltas 1");
	if (curMS.valueBuffer("reservaaf") == 0) {
	    var curMSResAFaltas = new FLSqlCursor("movistock");		
	    curMSResAFaltas.setActivatedCommitActions(false);
	    curMSResAFaltas.setActivatedCheckIntegrity(false);
	    curMSResAFaltas.select("idmovproducto = " + curMS.valueBuffer("idmovimiento"));
	    while (curMSResAFaltas.next()) {
			curMSResAFaltas.setModeAccess(curMSResAFaltas.Del);
			curMSResAFaltas.refreshBuffer();			
			if (!_i.delMovTejidoPrepRecursivo1(curMSResAFaltas.valueBuffer("idmovimiento"))) {
				return false;
			}
			if (!curMSResAFaltas.commitBuffer()) {
				return false;
			}
	    }
	    return true;
	}
	//debug("-------------------------euromoda_revisaReservasMSAFaltas 2");
	var qryFT = new FLSqlQuery();
	//qryFT.setSelect("ac.refcomponente, a.codsubfamilia, SUM(ac.cantidad*ac.factor), MIN(ac.id)");
	qryFT.setSelect("ac.refcomponente, a.codsubfamilia, ac.cantidad*ac.factor, ac.id");
	qryFT.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia");
	//qryFT.setWhere("ac.refcompuesto = '" + curMS.valueBuffer("referencia") + "' GROUP BY ac.refcomponente, a.codsubfamilia");
	qryFT.setWhere("ac.refcompuesto = '" + curMS.valueBuffer("referencia") + "'");
	if (!qryFT.exec()) {
		return false;
	}
	//debug("euromoda_revisaReservasMSAFaltas 3: "+qryFT.sql());
	var codAlmacen = AQUtil.sqlSelect("stocks", "codalmacen", "idstock = " + curMS.valueBuffer("idstock"));
	var curMSRes = new FLSqlCursor("movistock");
	curMSRes.setActivatedCheckIntegrity(false); /// Porque est� muy controlado y aumenta el rendimiento (la tabla tiene muchas relaciones)
	curMSRes.setActivatedCommitActions(false);
	var referencia, cantidad, idStock, codSubfamilia;
	var aMovProcesados = [];
	while (qryFT.next()) {
		codSubfamilia = qryFT.value("a.codsubfamilia");
		referencia = qryFT.value("ac.refcomponente");
		idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
		if (!idStock) {			
			var oArticulo = new Object;
			oArticulo["referencia"] = referencia;
			idStock = _i.crearStock(codAlmacen, oArticulo);
			if (!idStock) {
				return false;
			}
		}
		cantidad = -1 * curMS.valueBuffer("reservaaf") * qryFT.value("ac.cantidad*ac.factor");
		cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");

		curMSRes.select("idmovproducto = " + curMS.valueBuffer("idmovimiento") + " AND idarticulocomp = " + qryFT.value("ac.id") + " AND referencia = '" + referencia + "'");
		if (curMSRes.first()) {
			
			curMSRes.setModeAccess(curMSRes.Edit);
			curMSRes.refreshBuffer();

			if (cantidad == curMSRes.valueBuffer("cantidad") && idStock == curMSRes.valueBuffer("idstock")) {
				continue;
			}
			curMSRes.setValueBuffer("cantidad", cantidad);
			curMSRes.setValueBuffer("fechaprev", curMS.valueBuffer("fechaprev"));
			curMSRes.setValueBuffer("idstock", idStock);
		} else {
			
			curMSRes.setModeAccess(curMSRes.Insert);
			curMSRes.refreshBuffer();
			curMSRes.setValueBuffer("idmovproducto", curMS.valueBuffer("idmovimiento"));
			curMSRes.setValueBuffer("idarticulocomp", qryFT.value("ac.id"));
			curMSRes.setValueBuffer("referencia", referencia);
			curMSRes.setValueBuffer("estado", "PTE");
			curMSRes.setValueBuffer("cantidad", cantidad);
			curMSRes.setValueBuffer("fechaprev", curMS.valueBuffer("fechaprev"));
			curMSRes.setValueBuffer("idstock", idStock);
			curMSRes.setValueBuffer("concepto", curMS.valueBuffer("concepto"));
			if (_i.esReferenciaXPiezas(referencia)) {
				curMSRes.setValueBuffer("codsubfamiliatp", codSubfamilia);
			}
		}
		 //aqui 19-04-2018 
		if (!curMSRes.commitBuffer()) {
			
			return false;
		}

		/************* POZU 27-05-2020 SI EXISTE rservaslotepedido crearla *****/
		//debug("-----------------------------Pasa por aqui");
		var qRLP = new AQSqlQuery;
		qRLP.setSelect("idlineapc, codlote, cantidad, idrlp,idarticulocomp");
		qRLP.setFrom("em_reservaslotepedido");
		qRLP.setWhere("idlineapc = " +  curMS.valueBuffer("idlineapc") + " AND idarticulocomp = " + qryFT.value("ac.id"));
		if (!qRLP.exec()) {
			return false;
		}
		while (qRLP.next()) {	

			//debug("------------ crea reservas para producto componente");
			var oParam = new Object;
			oParam["idLineaPedido"] = curMS.valueBuffer("idlineapc"); 
			oParam["codLote"] = qRLP.value("codlote"); 
			oParam["cantidad"] = qRLP.value("cantidad"); 
			oParam["idRLP"] = qRLP.value("idrlp");
			oParam["idArticuloComp"] = qryFT.value("ac.id");
			if (!_i.creaReservasPedidoProdComp(oParam)) {
				return false;
			}
		
		}

		/************* POZU 27-05-2020 SI EXISTE *****/

		

		aMovProcesados.push(curMSRes.valueBuffer("idmovimiento"));
	}

	/*var refProducto = curMS.valueBuffer("referencia");
	debug("\n\n*****");
	debug("refProducto: "+refProducto);
	if(refProducto && refProducto != "") {

		var idLineaPedido = curMS.valueBuffer("idlineapc");
		debug("idLineaPedido: "+idLineaPedido);
		if(idLineaPedido && idLineaPedido != "") {
			var codCliente = AQUtil.sqlSelect("lineaspedidoscli lp INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido","p.codcliente","lp.idlinea = " + idLinea,"lineaspedidoscli,pedidoscli");
			debug("codCliente: "+codCliente);
			var aDatosEmbalaje = flfactalma.iface.dameEmbalajeArticulo(refProducto, codCliente);
			if (!aDatosEmbalaje) {
				return false;
			}
			if (aDatosEmbalaje.referencia) {
				var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + aDatosEmbalaje.referencia + "' AND codalmacen = '" + datosOrden["p.codalmacen"] + "'");
				if (!idStock) {
					var oArticulo = new Object;
					oArticulo["referencia"] = aDatosEmbalaje.referencia;
					idStock = flfactalma.iface.pub_crearStock(datosOrden["p.codalmacen"], oArticulo);
					if (!idStock) {
						return false;
					}
				}
				var canEmbal = Math.ceil(curMS.valueBuffer("reservaaf") / aDatosEmbalaje.capacidad);
				canEmbal *= -1;
				var curMS = new FLSqlCursor("movistock");
				curMS.setModeAccess(curMS.Insert);
				curMS.refreshBuffer();
				curMSRes.setValueBuffer("idmovproducto", curMS.valueBuffer("idmovimiento"));
				curMS.setValueBuffer("referencia", aDatosEmbalaje.referencia);
				curMS.setValueBuffer("estado", "PTE");
				curMS.setValueBuffer("fechaprev",  curMS.valueBuffer("fechaprev"));				
				curMS.setValueBuffer("cantidad", canEmbal);
				curMS.setValueBuffer("idstock", idStock);				
				curMS.setValueBuffer("concepto", curMS.valueBuffer("concepto"));
				if (!curMS.commitBuffer()) {
					return false;
				}				
			}
			aMovProcesados.push(curMSRes.valueBuffer("idmovimiento"));
		}	

	}*/


	//debug("-----------------------euromoda_revisaReservasMSAFaltas 4");
	if (aMovProcesados.length > 0) {
		var sMovProcesados = aMovProcesados.join(",");
		var curMSProcesados = new FLSqlCursor("movistock");	
		curMSProcesados.setActivatedCommitActions(false);
		curMSProcesados.select("idmovproducto = " + curMS.valueBuffer("idmovimiento") + " AND idmovimiento NOT IN (" + sMovProcesados + ")");
		while (curMSProcesados.next()) {		    	
			curMSProcesados.setModeAccess(curMSProcesados.Del);
			curMSProcesados.refreshBuffer();			
			if (!_i.delMovTejidoPrepRecursivo1(curMSProcesados.valueBuffer("idmovimiento"))) {
				return false;
			}
			var idStock = curMSProcesados.valueBuffer("idstock");
			if (!curMSProcesados.commitBuffer()) {
				return false;
			}
		}
	}
	//debug("-------------------euromoda_revisaReservasMSAFaltas 5");
	return true;
}

/*
Al crear el movimiento de lote en ordenes produccion. Al crear  / modificar el movimiento de pedido y albar�n a confecciones
*/


/* 21-05-2020 Reescribimos funcion por funcionalidad #EUR #H2176 P0067 Consola de Producci�n de prendas incluir fabricar componentes de Fichas T�cnicas

function euromoda_revisaReservasLoteProd(codLote)
{
	//debug("\n\neuromoda_revisaReservasLoteProd");
	var _i = this.iface;


	if(!_i.borraReservasPRLote(codLote)) { //26-02-2018 Lo hemos sacado a una funci�n para poder llamarla desde creaConsumosFT antes de actualizar la cantidad reservada
		return false;		
	}
	
	//22-09-2016 se incluye para que borre las reservas en el caso de que se haya servido el pedido y luego se cree la orden de producci�n
	var q = new AQSqlQuery;
	q.setSelect("lp.idlinea, mres.idmovimiento, rpr.id, mpr.idmovimiento, mres.idstock");
	q.setFrom("lineasalbaranescli lp INNER JOIN movistock mres ON lp.idlinea = mres.idlineaac INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva LEFT OUTER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
	q.setWhere("mpr.codlote = '" + codLote + "'");
//debug("\n\nrevisaReservasLoteProd 2 " + q.sql());
	if (!_i.borraReservasQuery(q)) {
		return false;
	}

	var qRLP = new AQSqlQuery;
	qRLP.setSelect("idlineapc, codlote, cantidad, idrlp");
	qRLP.setFrom("em_reservaslotepedido");
	qRLP.setWhere("codLote = '" + codLote + "'");
	if (!qRLP.exec()) {
		return false;
	}
//debug("\n\nrevisaReservasLoteProd 3 " + qRLP.sql());
	while (qRLP.next()) {
		if (!_i.creaReservasPedidoProd(qRLP.value("idlineapc"), qRLP.value("codlote"), qRLP.value("cantidad"), qRLP.value("idrlp"))) {
			return false;
		}
			
	}
	return true;
}*/


function euromoda_revisaReservasLoteProd(codLote)
{
	//debug("\n\neuromoda_revisaReservasLoteProd");
	var _i = this.iface;


	if(!_i.borraReservasPRLote(codLote)) { //26-02-2018 Lo hemos sacado a una funci�n para poder llamarla desde creaConsumosFT antes de actualizar la cantidad reservada
		return false;		
	}
	
	//22-09-2016 se incluye para que borre las reservas en el caso de que se haya servido el pedido y luego se cree la orden de producci�n
	var q = new AQSqlQuery;
	q.setSelect("lp.idlinea, mres.idmovimiento, rpr.id, mpr.idmovimiento, mres.idstock");
	q.setFrom("lineasalbaranescli lp INNER JOIN movistock mres ON lp.idlinea = mres.idlineaac INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva LEFT OUTER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
	q.setWhere("mpr.codlote = '" + codLote + "'");
//debug("\n\nrevisaReservasLoteProd 2 " + q.sql());
	if (!_i.borraReservasQuery(q)) {
		return false;
	}

	var qRLP = new AQSqlQuery;
	qRLP.setSelect("idlineapc, codlote, cantidad, idrlp,idarticulocomp");
	qRLP.setFrom("em_reservaslotepedido");
	qRLP.setWhere("codLote = '" + codLote + "'");
	if (!qRLP.exec()) {
		return false;
	}
//debug("\n\nrevisaReservasLoteProd 3 " + qRLP.sql());
	while (qRLP.next()) {
		var idArticuloComp = qRLP.value("idarticulocomp");
		//21-05-2020 si en el registro viene informado el idarticulocomp es porque es un producto que deriva de otro producto (almohada), si no es como siempre (cama)
		if(!idArticuloComp || idArticuloComp == "")  {	
			debug("------------ crea reservas para producto");		
			if (!_i.creaReservasPedidoProd(qRLP.value("idlineapc"), qRLP.value("codlote"), qRLP.value("cantidad"), qRLP.value("idrlp"))) {
				return false;
			}
		} else {
			debug("------------ crea reservas para producto componente");
			var oParam = new Object;
			oParam["idLineaPedido"] = qRLP.value("idlineapc"); 
			oParam["codLote"] = qRLP.value("codlote"); 
			oParam["cantidad"] = qRLP.value("cantidad"); 
			oParam["idRLP"] = qRLP.value("idrlp");
			oParam["idArticuloComp"] = idArticuloComp;
			if (!_i.creaReservasPedidoProdComp(oParam)) {
				return false;
			}
		}
	}
	return true;
}


function euromoda_revisaReservasPedidoProd(idLineaPedido, idArticuloComp)
{
	var _i = this.iface;

	var where = "rlp.idlineapc = " + idLineaPedido;

	if(idArticuloComp && idArticuloComp != "") {
		where += " AND rlp.idarticulocomp = " + idArticuloComp;
	} else {
		where += " AND rlp.idarticulocomp IS NULL";
	}

	var q = new AQSqlQuery();
	q.setSelect("rpr.id, mres.idmovimiento, mpr.idmovimiento");
	q.setFrom("em_reservaslotepedido rlp INNER JOIN em_reservaspterx rpr ON rlp.idrlp = rpr.idrlp INNER JOIN movistock mres ON rpr.idmovreserva = mres.idmovimiento INNER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
	q.setWhere(where);
	if (!_i.borraReservasQuery(q)) {
		return false;
	}

	
	var qRLP = new AQSqlQuery;
	qRLP.setSelect("rlp.idlineapc, rlp.codlote, rlp.cantidad, rlp.idrlp");
	qRLP.setFrom("em_reservaslotepedido rlp");
	qRLP.setWhere(where);
	if (!qRLP.exec()) {
		return false;
	}
	while (qRLP.next()) {
		if (!_i.creaReservasPedidoProd(idLineaPedido, qRLP.value("rlp.codlote"), qRLP.value("rlp.cantidad"), qRLP.value("rlp.idrlp"))) {
			return false;
		}
	}
	return true;
}

function euromoda_borraReservasQuery(q)
{
	var _i = this.iface;
	var curMS = new FLSqlCursor("movistock");
	curMS.setActivatedCommitActions(false);
	curMS.setActivatedCheckIntegrity(false);
	if (!q.exec()) {
		return false;
	}
	while (q.next()) {
		/*if (!AQUtil.execSql("DELETE FROM em_reservaspterx WHERE id = " + q.value("rpr.id"))) {
			return false;
		}*/
		if (!AQUtil.sqlDelete("em_reservaspterx", "id = " + q.value("rpr.id"))) {
			return false;
		}	
		curMS.select("idmovimiento = " + q.value("mres.idmovimiento"));
		if (!curMS.first()) {
			return false;
		}
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		curMS.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMS));
		if (!curMS.commitBuffer()) {
			return false;
		}
		if (q.value("mpr.idmovimiento")) {
			curMS.select("idmovimiento = " + q.value("mpr.idmovimiento"));
			if (!curMS.first()) {
				return false;
			}
			curMS.setModeAccess(curMS.Edit);
			curMS.refreshBuffer();
			curMS.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curMS));
			if (!curMS.commitBuffer()) {
				return false;
			}
		}
	}

	return true;
}

function euromoda_borraReservasQueryZZZZZZZZZZZZZZZZZZ(q)
{
	var _i = this.iface;

	//debug("-----borraReservasQuery");
	//debug("query a borrar: "+q.sql());
	formUI.ponMsgWarn(sys.translate("Sacar query a borrar"));		


		debug("\n\n----------- borraReservasQuery 1 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			//debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			//debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		//debug("\n------------------------------------------");


	var curMS = new FLSqlCursor("movistock");
	curMS.setActivatedCommitActions(false);
	curMS.setActivatedCheckIntegrity(false);

	if (!q.exec()) {
		return false;
	}
	//debug("q.size(): "+q.size());


		//debug("\n\n----------- borraReservasQuery 2 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			//debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			//debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		//debug("\n------------------------------------------");





	while (q.next()) {
		/*if (!AQUtil.execSql("DELETE FROM em_reservaspterx WHERE id = " + q.value("rpr.id"))) {
			return false;
		}*/		

		//debug("lp.idlinea: "+q.value("lp.idlinea"));	
		//debug("mres.idmovimiento: "+q.value("mres.idmovimiento"));
		//debug("rpr.id: "+q.value("mpr.idmovimiento"));
		//debug("mres.idstock: "+q.value("mres.idstock"));
	

		if (!AQUtil.sqlDelete("em_reservaspterx", "id = " + q.value("rpr.id"))) {
			return false;
		}	

		//debug("\n\n----------- borraReservasQuery 3 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		debug("\n------------------------------------------");




		curMS.select("idmovimiento = " + q.value("mres.idmovimiento"));
		if (!curMS.first()) {
			return false;
		}

		debug("\n\n----------- borraReservasQuery 4 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		debug("\n------------------------------------------");






		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		curMS.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMS));
		if (!curMS.commitBuffer()) {
			return false;
		}

		debug("\n\n----------- borraReservasQuery 5 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		debug("\n------------------------------------------");

		if (q.value("mpr.idmovimiento")) {
			curMS.select("idmovimiento = " + q.value("mpr.idmovimiento"));
			if (!curMS.first()) {
				return false;
			}


		debug("\n\n----------- borraReservasQuery 6 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		debug("\n------------------------------------------");


			curMS.setModeAccess(curMS.Edit);
			curMS.refreshBuffer();
			curMS.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curMS));
			if (!curMS.commitBuffer()) {
				return false;
			}


		debug("\n\n----------- borraReservasQuery 7 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		debug("\n------------------------------------------");



		}
	}

		debug("\n\n----------- borraReservasQuery 8 ----------------");
		var q = new FLSqlQuery();	
		q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
		q.setFrom("em_reservaslotepedido");
		q.setWhere("idlineapc = 1219390");	
		if (!q.exec()){
			return false;
		}
		while(q.next()) {
			debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
			debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
		}
		debug("\n------------------------------------------");








	return true;
}

function euromoda_calculaReservasArray(qNecesaria, qDisponible)
{
	var _i = this.iface;
	
	if (!qNecesaria.exec() || !qDisponible.exec()) {
	
		return false;
	}
	if (qNecesaria.size() < 1 || qDisponible.size() < 1) {
		debug("Consultas vac�as ");
		return true;
	}
	
	var aDisponible = [];
	while (qDisponible.next()) {
		aDisponible.push(qDisponible.value("ms.idmovimiento"));
	}
	var aNecesaria = [];
	while (qNecesaria.next()) {
		aNecesaria.push(qNecesaria.value("ms.idmovimiento"));
	}

	if (!aNecesaria || !aDisponible  || aNecesaria.length == 0 || aDisponible.length == 0) {
	debug("No hay arrays o est�n vac�os");
		return true;
	}
	var sNecesaria = aNecesaria.join(",");
	var sDisponible = aDisponible.join(",");


	
	var curNecesaria = new FLSqlCursor("movistock"); /// Globales?
	curNecesaria.setActivatedCheckIntegrity(false);
	curNecesaria.setActivatedCommitActions(false);
	
	var curDisponible = new FLSqlCursor("movistock");
	curDisponible.setActivatedCheckIntegrity(false);
	curDisponible.setActivatedCommitActions(false);
	
	curNecesaria.select("idmovimiento in (" + sNecesaria + ")");
	curDisponible.select("idmovimiento in (" + sDisponible + ") order by idmovimiento DESC");  //25-10-2017
	var canNecesaria, canDisponible;
	var cNecAbierto = curNecesaria.next();
	var cDisAbierto = curDisponible.next();
	var sigue = cNecAbierto && cDisAbierto;
//debug("sigue " + sigue);
	var idStock;
	if (!sigue) {
		return true;
	}
	curNecesaria.setModeAccess(curNecesaria.Edit);
	curNecesaria.refreshBuffer();
	idStock = curNecesaria.valueBuffer("idstock"); /// Cualquier valor de los cursores usados debe coincidir
	curDisponible.setModeAccess(curNecesaria.Edit);
	curDisponible.refreshBuffer();
	canNecesaria = (curNecesaria.valueBuffer("cantidad") * -1) - curNecesaria.valueBuffer("enreserva");
//debug("canNecesaria " + canNecesaria + " idmov " + curNecesaria.valueBuffer("idmovimiento"));
	canDisponible = curDisponible.valueBuffer("cantidad") - curDisponible.valueBuffer("enreserva");
//debug("canDisponible " + canDisponible + " idmov " + curDisponible.valueBuffer("idmovimiento"));
	
	while (sigue) {

		if (canNecesaria == canDisponible) {
			if (!_i.creaReservaStock(curNecesaria.valueBuffer("idmovimiento"), curDisponible.valueBuffer("idmovimiento"), canDisponible)) {
				return false;
			}
			curDisponible.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curDisponible));
			if (!curDisponible.commitBuffer()) {
				return false;
			}
			curNecesaria.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curNecesaria));
			if (!curNecesaria.commitBuffer()) {
				return false;
			}
			cNecAbierto = curNecesaria.next();
			cDisAbierto = curDisponible.next();
			sigue = cNecAbierto && cDisAbierto;
			if (!sigue) {
				curNecesaria.setModeAccess(curNecesaria.Edit);
				curNecesaria.refreshBuffer();
				curDisponible.setModeAccess(curDisponible.Edit);
				curDisponible.refreshBuffer();
				canNecesaria = (curNecesaria.valueBuffer("cantidad") * -1) - curNecesaria.valueBuffer("enreserva");
				canDisponible = curDisponible.valueBuffer("cantidad") - curDisponible.valueBuffer("enreserva");
			}
		} else if (canNecesaria > canDisponible) {
			if (!_i.creaReservaStock(curNecesaria.valueBuffer("idmovimiento"), curDisponible.valueBuffer("idmovimiento"), canDisponible)) {
				return false;
			}
			curDisponible.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curDisponible));
			if (!curDisponible.commitBuffer()) {
				return false;
			}
			canNecesaria -= canDisponible;
			cDisAbierto = curDisponible.next();
			sigue = cNecAbierto && cDisAbierto;
			if (sigue) {
				curDisponible.setModeAccess(curDisponible.Edit);
				curDisponible.refreshBuffer();
				canDisponible = curDisponible.valueBuffer("cantidad") - curDisponible.valueBuffer("enreserva");
			}
		} else {
			if (!_i.creaReservaStock(curNecesaria.valueBuffer("idmovimiento"), curDisponible.valueBuffer("idmovimiento"), canNecesaria)) {
				return false;
			}
			curNecesaria.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curNecesaria));
			if (!curNecesaria.commitBuffer()) {
				return false;
			}
			canDisponible -= canNecesaria;
			cNecAbierto = curNecesaria.next();
			sigue = cNecAbierto && cDisAbierto;
			if (sigue) {
				curNecesaria.setModeAccess(curNecesaria.Edit);
				curNecesaria.refreshBuffer();
				canNecesaria = (curNecesaria.valueBuffer("cantidad") * -1) - curNecesaria.valueBuffer("enreserva");
			}
		}
	}
	if (cNecAbierto) {
		curNecesaria.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curNecesaria));
		if (!curNecesaria.commitBuffer()) {
			return false;
		}
	}
	if (cDisAbierto) {
		curDisponible.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curDisponible));
		if (!curDisponible.commitBuffer()) {
			return false;
		}
	}
	/** No porque desde los dos sitios (reservas de productos desde lotes y desde pedidos, luego se hace una llamada a esto
	if (!_i.actualizarStockPteRecibirT0(idStock)) {
		return false;
	}
	*/
	return true;
}

function euromoda_creaReservaStock(idMovNec, idMovDis, cantidad, idRLP)
{
	var sql;
	if(cantidad == 0) {
		return true;
	}
	if (idRLP) {
		sql = "INSERT INTO em_reservaspterx (idmovreserva, idmovpterx, cantidad, idrlp) VALUES (" + idMovNec + ", "+ idMovDis + ", " + cantidad + ", " + idRLP + ")";
	} else {
		sql = "INSERT INTO em_reservaspterx (idmovreserva, idmovpterx, cantidad) VALUES (" + idMovNec + ", "+ idMovDis + ", " + cantidad + ")";
	}
	
	return AQUtil.execSql(sql);
}

function euromoda_afterCommit_em_articuloscli(curArtCli)
{
	var _i = this.iface;	
	
	if (!_i.bloqueoHistoricoArticuloscli_ || _i.bloqueoHistoricoArticuloscli_ == undefined) {
		_i.bloqueoHistoricoArticuloscli_ = true;
		if (!_i.actualizaHistoricoArtCli(curArtCli)) {
			_i.bloqueoHistoricoArticuloscli_ = false;
		}
		_i.bloqueoHistoricoArticuloscli_ = false;
	}
	return true;
}

function euromoda_actualizaHistoricoArtCli(curArtCli)
{
	var _i = this.iface;
	switch (curArtCli.modeAccess()) {
		case curArtCli.Insert: {
			if(!_i.insertaHistoricoArtCli(curArtCli)) {
				return false;
			}
			break;
		}
		case curArtCli.Edit: {
			var cambioRegistro = _i.datosArticulosCliCambian(curArtCli);
			//0 no hay cambio, 1 cambia fechavalidez, 2 cambia pero fechavalidez no
			switch (cambioRegistro) {
				case 1: {
					if(!_i.insertaHistoricoArtCli(curArtCli)) {
						return false;
					}
					break;
				}
				case 2: {
					if(!_i.eliminaHistoricoArtCli(curArtCli)) {
						return false;
					}	
					if(!_i.insertaHistoricoArtCli(curArtCli)) {
						return false;
					}
					break;
				}
				default: {
					return true;
				}

			}
			break;
		}
		default: {
			return true;
		}
	}
	return true;
}
function euromoda_datosArticulosCliCambian(curArtCli) 
{
	var retorno = 0;
	var fechaValidez = curArtCli.valueBuffer("fechavalidez");
	var pvpBase = curArtCli.valueBuffer("pvpbase");
	var dtoPor = curArtCli.valueBuffer("dtopor");
	var pvpDto = curArtCli.valueBuffer("pvpdto");
	var pvpSinIva = curArtCli.valueBuffer("pvpsiniva");
	var dtoEmoda = curArtCli.valueBuffer("dtoemoda");
	var pvpEuromoda = curArtCli.valueBuffer("pvpeuromoda");

	var fechaValidezC = curArtCli.valueBufferCopy("fechavalidez");
	var pvpBaseC = curArtCli.valueBufferCopy("pvpbase");
	var dtoPorC = curArtCli.valueBufferCopy("dtopor");
	var pvpDtoC = curArtCli.valueBufferCopy("pvpdto");
	var pvpSinIvaC = curArtCli.valueBufferCopy("pvpsiniva");
	var dtoEmodaC = curArtCli.valueBufferCopy("dtoemoda");
	var pvpEuromodaC = curArtCli.valueBufferCopy("pvpeuromoda");

	if(fechaValidez != fechaValidezC) {
		retorno = 1;
	} else if (pvpBase != pvpBaseC || dtoPor != dtoPorC || pvpDto != pvpDtoC || pvpSinIva != pvpSinIvaC || dtoEmoda != dtoEmodaC || pvpEuromoda != pvpEuromodaC) {
		retorno = 2;
	}
	return retorno;
}
function euromoda_insertaHistoricoArtCli(curArtCli)
{
	var _i = this.iface;			
	var curArtCliHis = new FLSqlCursor("em_articulosclihis");
	curArtCliHis.setActivatedCheckIntegrity(false);
	curArtCliHis.setActivatedCommitActions(false);
	curArtCliHis.setModeAccess(curArtCliHis.Insert);
	curArtCliHis.refreshBuffer();
	curArtCliHis.setValueBuffer("idarticuloscli", curArtCli.valueBuffer("id"));
	curArtCliHis.setValueBuffer("pvpbase", curArtCli.valueBuffer("pvpbase"));
	curArtCliHis.setValueBuffer("dtopor", curArtCli.valueBuffer("dtopor"));
	curArtCliHis.setValueBuffer("pvpdto", curArtCli.valueBuffer("pvpdto"));
	curArtCliHis.setValueBuffer("pvpsiniva", curArtCli.valueBuffer("pvpsiniva"));
	curArtCliHis.setValueBuffer("dtoemoda", curArtCli.valueBuffer("dtoemoda"));
	curArtCliHis.setValueBuffer("pvpeuromoda", curArtCli.valueBuffer("pvpeuromoda"));
	curArtCliHis.setValueBuffer("fechavalidez", curArtCli.valueBuffer("fechavalidez"));
	if (!curArtCliHis.commitBuffer()) {
		return false;
	}
	return true;
}
function euromoda_eliminaHistoricoArtCli(curArtCli)
{
	var curArtCliHis = new FLSqlCursor("em_articulosclihis");
	curArtCliHis.select("idarticuloscli = " + curArtCli.valueBuffer("id") + " and fechavalidez = ' " + curArtCli.valueBuffer("fechavalidez") + "' " );
   if (!curArtCliHis.first()) {
		return false;
  	}
	curArtCliHis.setModeAccess(curArtCliHis.Del);
	curArtCliHis.refreshBuffer();		
	if (!curArtCliHis.commitBuffer()) {
		return false;
	}
	return true;
}

function euromoda_afterCommit_em_articulosclihis(curArtCliHis)
{
	var _i = this.iface;
	
	if (!_i.bloqueoHistoricoArticuloscli_ || _i.bloqueoHistoricoArticuloscli_ == undefined) {
		_i.bloqueoHistoricoArticuloscli_ = true;
		if (!_i.controlCabeceraArticuosCli(curArtCliHis)) {
			_i.bloqueoHistoricoArticuloscli_ = false;
		}
		_i.bloqueoHistoricoArticuloscli_ = false;
	}
	return true;
}

function euromoda_controlCabeceraArticuosCli(curArtCliHis)
{
	var _i = this.iface;
	var idArticulosCli = curArtCliHis.valueBuffer("idarticuloscli");
	var idArticulosCliHis = curArtCliHis.valueBuffer("id");
	var idPrimerRegistroHis = _i.idPrimerRegistro(idArticulosCli);

	if(!idPrimerRegistroHis) {
	     return true;
	}
	switch (curArtCliHis.modeAccess()) {
		case curArtCliHis.Insert: 
		case curArtCliHis.Del: {
			 if(!_i.actualizaArticulosCli(idArticulosCli, idPrimerRegistroHis)) {
			      return false;
			 }
			break;
		}
		case curArtCliHis.Edit: {
			if (idArticulosCliHis == idPrimerRegistroHis) {
			if(!_i.actualizaArticulosCli(idArticulosCli, idPrimerRegistroHis)) {
				return false;
			}
	    } 
			 break;
		     }
		default: {
			 return true;
		     }
		}	

	return true;
}
function euromoda_actualizaArticulosCli(idArticulosCli, idPrimerRegistroHis)
{
		
	var curArtCli = new FLSqlCursor("em_articuloscli");
	curArtCli.setActivatedCommitActions(false);
	curArtCli.select("id = " + idArticulosCli);
	if (!curArtCli.first()) {
		return true;
	}
	curArtCli.setModeAccess(curArtCli.Edit);
	curArtCli.refreshBuffer();

	var curArtCliHisPrim = new FLSqlCursor("em_articulosclihis");	
	curArtCliHisPrim.select("id = " + idPrimerRegistroHis);
	if (!curArtCliHisPrim.first()) {
		return true;
	}
	curArtCliHisPrim.setModeAccess(curArtCli.Browse);
	curArtCliHisPrim.refreshBuffer();
	
	curArtCli.setValueBuffer("pvpbase", curArtCliHisPrim.valueBuffer("pvpbase"));
	curArtCli.setValueBuffer("dtopor", curArtCliHisPrim.valueBuffer("dtopor"));
	curArtCli.setValueBuffer("pvpdto", curArtCliHisPrim.valueBuffer("pvpdto"));
	curArtCli.setValueBuffer("pvpsiniva", curArtCliHisPrim.valueBuffer("pvpsiniva"));
	curArtCli.setValueBuffer("dtoemoda", curArtCliHisPrim.valueBuffer("dtoemoda"));
	curArtCli.setValueBuffer("pvpeuromoda", curArtCliHisPrim.valueBuffer("pvpeuromoda"));
	curArtCli.setValueBuffer("fechavalidez", curArtCliHisPrim.valueBuffer("fechavalidez"));
	if (!curArtCli.commitBuffer()) {
		return false;
	}
	return true; 
}
function euromoda_idPrimerRegistro(idArticulosCli)
{              
     return AQUtil.sqlSelect("em_articulosclihis", "id", "idarticuloscli =" + idArticulosCli + " order by fechavalidez DESC ");
}


function euromoda_controlRegStock(curLRS)
{
	var _i = this.iface;

	var curRel = curLRS.cursorRelation();
	if (curRel && curRel.table() == "stocks") {
		return true;
	}
	var curStock = new FLSqlCursor("stocks");
	curStock.select("idstock = " + curLRS.valueBuffer("idstock"));
	if (!curStock.first()) {

		return false;
	}
	curStock.setModeAccess(curStock.Edit);
	curStock.refreshBuffer();

	var fechaUltReg:String = formRecordregstocks.iface.commonCalculateField("fechaultreg", curStock);
	if (fechaUltReg) {
		curStock.setValueBuffer("fechaultreg", fechaUltReg);
		curStock.setValueBuffer("horaultreg", formRecordregstocks.iface.commonCalculateField("horaultreg", curStock));
		curStock.setValueBuffer("cantidadultreg", formRecordregstocks.iface.commonCalculateField("cantidadultreg", curStock));
	} else {
		curStock.setNull("fechaultreg");
		curStock.setNull("horaultreg");
		curStock.setValueBuffer("cantidadultreg", 0);
	}
	curStock.setValueBuffer("cantidad", formRecordregstocks.iface.commonCalculateField("cantidad", curStock));
	curStock.setValueBuffer("disponible", formRecordregstocks.iface.commonCalculateField("disponible", curStock));
	/// Euromoda
	if (!_i.calculaReservasStock(curStock)) {
		return false;
	}
	/// FIN Euromoda
	if (!curStock.commitBuffer()) {
		debug("!curStock.commitBuffer");
		return false;
	}
	return true;
}

/*
Al regenerar el movimiento de stock asociado a la l�nea de pedido
Si el movimiento es nuevo no tiene sentido el borrado de reservas
*/
function euromoda_reservasConsumoLineaPedido(idLineaPedido)
{
	var _i = this.iface;
	var q = new AQSqlQuery();
	q.setSelect("lp.idlinea, mres.idmovimiento, rpr.id, mpr.idmovimiento, mres.idstock");	
	q.setFrom("lineaspedidoscli lp INNER JOIN movistock mprod ON lp.idlinea = mprod.idlineapc INNER JOIN movistock mres ON (mprod.idmovimiento = mres.idmovproducto OR mprod.idmovimiento = mres.idmovimiento) INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva LEFT OUTER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento INNER JOIN em_reservasestpedido rep ON lp.idlinea = rep.idlineapc");
	q.setWhere("lp.idlinea = " + idLineaPedido);
	if (!_i.borraReservasQuery(q)) {
		return false;
	}
	
	q = undefined;
	q = new AQSqlQuery;
	q.setSelect("le.referencia");
	q.setFrom("lineaspedidoscli lp INNER JOIN em_reservasestpedido rep ON lp.idlinea = rep.idlineapc INNER JOIN em_lineasordenest le ON le.idlinea = rep.idlineaest");
	q.setWhere("lp.idlinea = " + idLineaPedido);
	if (!q.exec()) {
		return false;
	}
	var qDisponible = new AQSqlQuery;
	var qNecesario = new AQSqlQuery;
	var aDisponible, aNecesario;

	while (q.next()) {
		qDisponible.setSelect("ms.idmovimiento");
		qDisponible.setFrom("lineaspedidoscli lp INNER JOIN em_reservasestpedido rep ON lp.idlinea = rep.idlineapc INNER JOIN em_lineasordenest le ON le.idlinea = rep.idlineaest INNER JOIN movistock ms ON le.idlinea = ms.emidlineaest");
		qDisponible.setWhere("lp.idlinea = " + idLineaPedido + " AND ms.cantidad > 0 AND ms.estado IN ('HECHO', 'PTE') AND ms.referencia = '" + q.value("le.referencia") + "'");

		qNecesario.setSelect("ms.idmovimiento");
		qNecesario.setFrom("lineaspedidoscli lp INNER JOIN em_reservasestpedido rep ON lp.idlinea = rep.idlineapc INNER JOIN em_lineasordenest le ON le.idlinea = rep.idlineaest INNER JOIN movistock mprod ON lp.idlinea = mprod.idlineapc INNER JOIN movistock ms ON (mprod.idmovimiento = ms.idmovproducto OR mprod.idmovimiento = ms.idmovimiento) AND le.referencia = ms.referencia");
		qNecesario.setWhere("lp.idlinea = " + idLineaPedido + " AND ms.cantidad < 0 AND ms.estado IN ('HECHO', 'PTE') AND ms.referencia = '" + q.value("le.referencia") + "'");

		if (!_i.calculaReservasArray(qNecesario, qDisponible)) {
			return false;
		}
	}
	return true;
}

/*
Al generar el lote desde orden de producci�n o al modificar la cantidad del lote
*/
function euromoda_reservasConsumoLote(codLote)
{
	var _i = this.iface;

	var q = new AQSqlQuery();
	q.setSelect("ls.codlote, mres.idmovimiento, rpr.id, mpr.idmovimiento");
	q.setFrom("lotesstock ls INNER JOIN movistock mres ON ls.codlote = mres.codloteprod INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva LEFT OUTER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
	q.setWhere("ls.codlote = '" + codLote + "'");
	if (!_i.borraReservasQuery(q)) {
		return false;
	}

	q = undefined;
	q = new AQSqlQuery;
	q.setSelect("le.referencia");
	q.setFrom("lotesstock ls INNER JOIN movistock ms ON ls.codlote = ms.codloteprod INNER JOIN em_reservasestlote rel ON ls.codlote = rel.codlote INNER JOIN em_lineasordenest le ON rel.idlineaest = le.idlinea AND ms.referencia = le.referencia");
	q.setWhere("ls.codlote = '" + codLote + "' GROUP BY le.referencia");
	if (!q.exec()) {
		return false;
	}
	var qDisponible = new AQSqlQuery;
	var qNecesario = new AQSqlQuery;
	var aDisponible, aNecesario;

	while (q.next()) {
		qDisponible.setSelect("ms.idmovimiento");
		qDisponible.setFrom("lotesstock ls INNER JOIN em_reservasestlote rel ON ls.codlote = rel.codlote INNER JOIN em_lineasordenest le ON rel.idlineaest = le.idlinea INNER JOIN movistock ms ON le.idlinea = ms.emidlineaest");
		qDisponible.setWhere("ls.codlote = '" + codLote + "' AND ms.cantidad > 0 AND ms.estado IN ('HECHO', 'PTE') AND ms.referencia = '" + q.value("le.referencia") + "' ORDER BY rel.idrel");

		qNecesario.setSelect("ms.idmovimiento");
		qNecesario.setFrom("lotesstock ls INNER JOIN movistock ms ON ls.codlote = ms.codloteprod");
		qNecesario.setWhere("ls.codlote = '" + codLote + "' AND ms.cantidad < 0 AND ms.estado IN ('HECHO', 'PTE') AND ms.referencia = '" + q.value("le.referencia") + "'");
		if (!_i.calculaReservasArray(qNecesario, qDisponible)) {
			return false;
		}
	}
	return true;
}

function euromoda_borraReservasPRLote(codLote)
{
	//debug("----------euromoda_borraReservasPRLote del lote: "+codLote);
	var _i  = this.iface;
	var q = new AQSqlQuery();
	q.setSelect("lp.idlinea, mres.idmovimiento, rpr.id, mpr.idmovimiento, mres.idstock");
	q.setFrom("lineaspedidoscli lp INNER JOIN movistock mres ON lp.idlinea = mres.idlineapc INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva LEFT OUTER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento INNER JOIN em_reservaslotepedido rlp ON lp.idlinea = rlp.idlineapc AND rlp.idrlp = rpr.idrlp");
	q.setWhere("rlp.codlote = '" + codLote + "'");
	//debug("q: "+q.sql());
	if (!_i.borraReservasQuery(q)) {
		return false;
	}
	return true;
}

/*
Al generar la l�nea en orden de estampaci�n o al modificar los movimientos de stock asociados a la l�nea.
Hacer que los movimientos de piezas se asocien tambi�n a las l�neas de orden de estampaci�n para que se pueda reservar de ellos
Al modificar el disponible de la l�nea de estampaci�n regenerar �nicamente los mov que ahora se regeneran pero no borrar los que vienen de piezas o partidas  de estampado
*/
function euromoda_reservasConsumoEstampacion(idLineaOrdenEst)
{
	var _i = this.iface;
	
	var referencia = AQUtil.sqlSelect("em_lineasordenest", "referencia", "idlinea = " + idLineaOrdenEst);

	var q = new AQSqlQuery();
	q.setSelect("lp.idlinea, mres.idmovimiento, rpr.id, mpr.idmovimiento, mres.idstock");
	q.setFrom("lineaspedidoscli lp INNER JOIN movistock mprod ON lp.idlinea = mprod.idlineapc INNER JOIN movistock mres ON (mprod.idmovimiento = mres.idmovproducto OR mprod.idmovimiento = mres.idmovimiento) INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva LEFT OUTER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento INNER JOIN em_reservasestpedido rep ON lp.idlinea = rep.idlineapc");
	q.setWhere("rep.idlineaest = " + idLineaOrdenEst + " AND mres.referencia = '" + referencia + "'");
	if (!_i.borraReservasQuery(q)) {
		return false;
	}

	q = undefined;
	q = new AQSqlQuery;
	q.setSelect("mres.idmovimiento, rpr.id, mpr.idmovimiento, mres.idstock");
	q.setFrom("lotesstock ls INNER JOIN movistock mres ON ls.codlote = mres.codloteprod INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva LEFT OUTER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento INNER JOIN em_reservasestlote rel ON ls.codlote = rel.codlote");
	q.setWhere("rel.idlineaest = " + idLineaOrdenEst + " AND mres.referencia = '" + referencia + "'");
	if (!_i.borraReservasQuery(q)) {
		return false;
	}
	
	q = undefined;

	var qDisponible = new AQSqlQuery;
	var qNecesario = new AQSqlQuery;
	var aDisponible, aNecesario;

	qDisponible.setSelect("ms.idmovimiento");
	qDisponible.setFrom("em_lineasordenest le INNER JOIN movistock ms ON le.idlinea = ms.emidlineaest");
	qDisponible.setWhere("le.idlinea = " + idLineaOrdenEst + " AND ms.cantidad > 0 AND ms.estado IN ('HECHO', 'PTE') AND ms.referencia = '" + referencia + "'");

	qNecesario.setSelect("ms.idmovimiento");
	qNecesario.setFrom("lineaspedidoscli lp INNER JOIN em_reservasestpedido rep ON lp.idlinea = rep.idlineapc INNER JOIN em_lineasordenest le ON le.idlinea = rep.idlineaest INNER JOIN movistock mprod ON lp.idlinea = mprod.idlineapc INNER JOIN movistock ms ON (mprod.idmovimiento = ms.idmovproducto OR mprod.idmovimiento = ms.idmovimiento) AND le.referencia = ms.referencia");
	qNecesario.setWhere("rep.idlineaest = " + idLineaOrdenEst + " AND ms.cantidad < 0 AND ms.estado = 'PTE' AND ms.referencia = '" + referencia + "'");
	if (!_i.calculaReservasArray(qNecesario, qDisponible)) {
		return false;
	}	
	qNecesario.setFrom("lotesstock ls INNER JOIN movistock ms ON ls.codlote = ms.codloteprod INNER JOIN em_reservasestlote rel ON ls.codlote = rel.codlote ");
	qNecesario.setWhere("rel.idlineaest = " + idLineaOrdenEst + " AND ms.cantidad < 0 AND ms.estado = 'PTE' AND ms.referencia = '" + referencia + "'");
	if (!_i.calculaReservasArray(qNecesario, qDisponible)) {
		return false;
	}

	return true;
}

function euromoda_calculaReservasStockDerivadas(idStock, nivelComp, nivelTejido, codSubfamiliaTP)
{
	//debug("\n\neuromoda_calculaReservasStockDerivadas codSubfamiliaTP "+codSubfamiliaTP);
	var _i = this.iface;
	if (nivelComp == 0 && !codSubfamiliaTP) {
		nivelComp++;
		if (!_i.calculaReservasStockComp(idStock, nivelComp)) {
			return false;
		}
	}
	if (nivelTejido == 0) {
		if (!_i.calculaReservasStockTP(idStock, codSubfamiliaTP)) {
			return false;
		}
	}
	return true;
}

function euromoda_calculaReservasStockTP(idStock, codSubfamiliaTP)
{
	//debug("euromoda_calculaReservasStockTP: "+idStock);
	//debug("euromoda_calculaReservasStockTP codSubfamiliaTP: "+codSubfamiliaTP);
	var _i = this.iface;	
	var codSubfamilia;
	if (codSubfamiliaTP && codSubfamiliaTP != "") {
		codSubfamilia = codSubfamiliaTP;
	} else {
		codSubfamilia = AQUtil.sqlSelect("stocks s INNER JOIN articulos a ON s.referencia = a.referencia", "a.codsubfamilia", "s.idstock = " + idStock, "stocks");
	}	
	if (!codSubfamilia) {	
		return true;
	}
	var oTP = _i.dameSiguienteTejidoPrep(codSubfamilia, idStock);
	if (!oTP) {		
		return false;
	}
	if (oTP.referencia != -1) {
		_i.marcaStockPte(oTP.idStock, "PTE_SERVIR", codSubfamilia);	
	}
	return true;
}

function euromoda_abreCursorStock(idStock)
{
	var _i = this.iface;
	var curStock = new FLSqlCursor("stocks");
	curStock.setActivatedCheckIntegrity(false);
	curStock.select("idstock = " + idStock);
	if (!curStock.first()) {
		return false;
	}
	curStock.setModeAccess(curStock.Edit);
	curStock.refreshBuffer();
	return curStock;
}

function euromoda_totalizaReservasStock(curStock, nivelComp, nivelTejido, codSubfamiliaTP)
{
	//debug("euromoda_totalizaReservasStock codSubfamiliaTP: "+codSubfamiliaTP);
	var _i = this.iface;
	
	if (nivelComp == undefined) {
		nivelComp = 0;
	}
	if (nivelTejido == undefined) {
		nivelTejido = 0;
	}

	curStock.setValueBuffer("cantidad", formRecordregstocks.iface.commonCalculateField("cantidad", curStock));
	curStock.setValueBuffer("disponible", formRecordregstocks.iface.commonCalculateField("disponible", curStock));
	var estado = _i.calculaReservasStock(curStock)
	if (!estado || estado == "ERROR") {
		return false;
	}
	var idStock = curStock.valueBuffer("idstock");
	if (!curStock.commitBuffer()) {
		return false;
	}
	if (estado == "A FALTAS") {
		if (!_i.calculaReservasStockDerivadas(idStock, nivelComp, nivelTejido, codSubfamiliaTP)) {
			return false;
		}
	}	
	return true;
}

function euromoda_delMovTejidoPrepRecursivo1(idMovPadre)
{
	var _i = this.iface;	
	var idMovTP = AQUtil.quickSqlSelect("movistock", "idmovimiento", "idmovtejidoprep = " + idMovPadre);
	if (!idMovTP) {
		return true;
	}
	if (!_i.delMovTejidoPrepRecursivoN(idMovTP)) {
		return false;
	}
	return true;
}

function euromoda_delMovTejidoPrepRecursivoN(idMovTP)
{
	var _i = this.iface;	
	var idMov = AQUtil.quickSqlSelect("movistock", "idmovimiento", "idmovtejidoprep = " + idMovTP);
	if (idMov) {
		if (!_i.delMovTejidoPrepRecursivoN(idMov)) {
			return false;
		}
	}
	if (!AQUtil.execSql("DELETE FROM movistock WHERE idmovimiento = " + idMovTP)) {
		return false;
	}
	return true;
}

function euromoda_beforeCommit_em_lineasbajapiezasmas(curLB)
{
	var _i = this.iface;
	if (!_i.controlBCStockLBPiezasMas(curLB)) {
		return false;
	}
	return true;
} 


function euromoda_controlBCStockLBPiezasMas(curLB)
{
	var _i = this.iface;
	switch (curLB.modeAccess()) {
		case curLB.Del: {
			if (!_i.borraMovsLBPiezasMas(curLB)) {
				return false;
			}
			break;
		}
	}
	
	return true;
}

function euromoda_borraMovsLBPiezasMas(curLB)
{
	
	var _i = this.iface;
	var estado = curLB.valueBuffer("estado");
	
	if(estado != "HECHO") {
		return true;
	}
	if (!AQSql.del("movistock", "emidlineabpm = " + curLB.valueBuffer("idlinea"))) {
		return false;
	}
	return true;
}

function euromoda_afterCommit_em_lineasbajapiezasmas(curLB)
{
	
	var _i = this.iface;	
	if (!_i.controlStockLBPiezasMas(curLB)) {
		return false;
	}
	
	return true;	
	
}

function euromoda_controlStockLBPiezasMas(curLB)
{
	var _i = this.iface;
	switch (curLB.modeAccess()) {
		case curLB.Insert: {			
			if (!_i.generaMovsLBPiezasMas(curLB)) {
				return false;
			}
			break;
		}
		case curLB.Edit: {
			if (_i.datosStockLBCambian(curLB)) {
				if (!_i.borraMovsLBPiezasMas(curLB)) {
					return false;
				}
				if (!_i.generaMovsLBPiezasMas(curLB)) {
					return false;
				}
			}
			break;
		}
	}
	
	return true;
}

function euromoda_datosStockLBCambian(curLB)
{
	var campos = ["canaumentar", "canadescontar"];
	for (var i = 0; i < campos.length; i++) {
		if (curLB.valueBufferCopy(campos[i]) != curLB.valueBuffer(campos[i])) {
			return true;
		}
	}
	return false;
}
 
function euromoda_generaMovsLBPiezasMas(curLB)
{
	var _i = this.iface;
	var estado = curLB.valueBuffer("estado");
	if(estado != "HECHO") {
		return true;
	}
	var cantidad = curLB.valueBuffer("canaumentar") - curLB.valueBuffer("canadescontar");
	if (cantidad == 0) {
		return true;
	}

	var curMS = new FLSqlCursor("movistock");
	var codPieza = curLB.valueBuffer("codpieza");
	var codAlmaPieza = AQUtil.sqlSelect("lotesstock", "codalmacen", "codlote = '" + codPieza + "'");

	if (!codAlmaPieza) {
		return false;
	}
	var referencia = curLB.valueBuffer("referencia");
	var aDatosArt = new Object;
	aDatosArt["referencia"] = referencia;
	
	var idStock = flfactalma.iface.pub_dameIdStock(codAlmaPieza, aDatosArt);
	if (!idStock) {
		return false;
	}	
	var concepto = sys.translate("Consumo pieza %1 pistola masiva c�d. baja masivo %2").arg(codPieza).arg(curLB.valueBuffer("idbaja"));
	
	var ahora = new Date;
	curMS.setModeAccess(curMS.Insert);
	curMS.refreshBuffer();
	curMS.setValueBuffer("emidlineabpm", curLB.valueBuffer("idlinea"));	
	curMS.setValueBuffer("cantidad", cantidad);
	curMS.setValueBuffer("estado", "HECHO");
	curMS.setValueBuffer("referencia", referencia);
	curMS.setValueBuffer("fechareal", ahora.toString());
	curMS.setValueBuffer("horareal", ahora.toString().right(8));
	curMS.setValueBuffer("idstock", idStock);
	curMS.setValueBuffer("codlote", codPieza);
	curMS.setValueBuffer("concepto", concepto);
	if (!curMS.commitBuffer()) {
		return false;
	}
	return true;
}

function euromoda_borraReservasPedidoProd(idLineaPedido)
{
	var _i = this.iface;

	var q = new AQSqlQuery();
	q.setSelect("rpr.id, mres.idmovimiento, mpr.idmovimiento");
	q.setFrom("em_reservaslotepedido rlp INNER JOIN em_reservaspterx rpr ON rlp.idrlp = rpr.idrlp INNER JOIN movistock mres ON rpr.idmovreserva = mres.idmovimiento INNER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
	q.setWhere("rlp.idlineapc = " + idLineaPedido);
	if (!_i.borraReservasQuery(q)) {
		return false;
	}
	if (!AQSql.del("em_reservaslotepedido", "idlineapc =" + idLineaPedido)) {
		return false;
	}
	return true;
}

function euromoda_borraReservasLoteProd(codLote)
{
	var _i = this.iface;

	var q = new AQSqlQuery();
	q.setSelect("rpr.id, mres.idmovimiento, mpr.idmovimiento");
	q.setFrom("em_reservaslotepedido rlp INNER JOIN em_reservaspterx rpr ON rlp.idrlp = rpr.idrlp INNER JOIN movistock mres ON rpr.idmovreserva = mres.idmovimiento INNER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento");
	q.setWhere("rlp.codlote = '" + codLote + "'");
	if (!_i.borraReservasQuery(q)) {
		return false;
	}
	if (!AQSql.del("em_reservaslotepedido", "codlote = '" + codLote + "'")) {
		return false;
	}
	return true;
}

function euromoda_creaReservasPedidoProd(idLineaPedido, codLote, cantidad, idRLP)
{
	var _i = this.iface;
	
	var curMSLote = new FLSqlCursor("movistock");
	var curMSPedido = new FLSqlCursor("movistock");
	
	curMSLote.setActivatedCheckIntegrity(false);
	curMSLote.setActivatedCommitActions(false);
	
	curMSPedido.setActivatedCheckIntegrity(false);
	curMSPedido.setActivatedCommitActions(false);
	
	var porReservar = cantidad;
	
	curMSPedido.select("idlineapc = " + idLineaPedido + " AND cantidad < 0");
	curMSLote.select("codlote = '" + codLote + "' AND cantidad > 0");
	
	var cPedAbierto = curMSPedido.next();
	var cLotAbierto = curMSLote.next();

	var sigue = cPedAbierto && cLotAbierto;
//debug("sigue " + sigue);
	var idStock;
	if (!sigue) {
		return true;
	}
	curMSPedido.setModeAccess(curMSPedido.Edit);
	curMSPedido.refreshBuffer();
	idStock = curMSPedido.valueBuffer("idstock"); /// Cualquier valor de los cursores usados debe coincidir
	curMSLote.setModeAccess(curMSLote.Edit);
	curMSLote.refreshBuffer();
	
	var canNecesaria = (curMSPedido.valueBuffer("cantidad") * -1) - curMSPedido.valueBuffer("enreserva");
	canNecesaria = isNaN(canNecesaria) ? 0 : canNecesaria;
//debug("canNecesaria " + canNecesaria + " idmov " + curMSPedido.valueBuffer("idmovimiento"));
	var canDisponible = curMSLote.valueBuffer("cantidad") - curMSLote.valueBuffer("enreserva");
	canDisponible = isNaN(canDisponible) ? 0 : canDisponible;
//debug("canDisponible " + canDisponible + " idmov " + curMSLote.valueBuffer("idmovimiento"));
	if (!canNecesaria || !canDisponible) {
		return true;
	}
	var aReservar;
	while (sigue) {
		aReservar = Math.min(canNecesaria, canDisponible);
		if (aReservar > porReservar) {
			aReservar = porReservar;
		}
//debug("aReservar " + aReservar);
		if (!_i.creaReservaStock(curMSPedido.valueBuffer("idmovimiento"), curMSLote.valueBuffer("idmovimiento"), aReservar, idRLP)) {
			return false;
		}
		if (aReservar == canNecesaria) {
			curMSPedido.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMSPedido));
			if (!curMSPedido.commitBuffer()) {
				return false;
			}
			cPedAbierto = curMSPedido.next();
			if (cPedAbierto) {
				curMSPedido.setModeAccess(curMSPedido.Edit);
				curMSPedido.refreshBuffer();
				canNecesaria = (curMSPedido.valueBuffer("cantidad") * -1) - curMSPedido.valueBuffer("enreserva");
//debug("canNecesaria " + canNecesaria + " idmov " + curMSPedido.valueBuffer("idmovimiento"));
			}
		}		
		if (aReservar == canDisponible) {
			curMSLote.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curMSLote));
			if (!curMSLote.commitBuffer()) {
				return false;
			}
			cLotAbierto = curMSLote.next();
			if (cLotAbierto) {
				curMSLote.setModeAccess(curMSLote.Edit);
				curMSLote.refreshBuffer();
				canDisponible = curMSLote.valueBuffer("cantidad") - curMSLote.valueBuffer("enreserva");
//debug("canDisponible " + canDisponible + " idmov " + curMSLote.valueBuffer("idmovimiento"));
			}
		}	
		porReservar -= aReservar;
		sigue = cLotAbierto && cPedAbierto && porReservar > 0;
	}
	if (cPedAbierto) {
		curMSPedido.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMSPedido));
		if (!curMSPedido.commitBuffer()) {
			return false;
		}
	}
	if (cLotAbierto) {
		curMSLote.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curMSLote));
		if (!curMSLote.commitBuffer()) {
			return false;
		}
	}
	
	return true;
}

function euromoda_datosRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp)
{
	var _i = this.iface;
	if (!_i.__datosRegMoviStock(curLinea, aDatosArt, aDatosStockLinea, curArticuloComp)) {
		return false;
	}
	switch (curLinea.table()) {
		case "lineaspedidoscli": {
			_i.curMoviStock.setValueBuffer("forzarafaltas", curLinea.valueBuffer("forzarafaltas"));
			_i.curMoviStock.setValueBuffer("agotarexistencias", curLinea.valueBuffer("agotarexistencias"));
			break;
		}
	}
	return true;
}

function euromoda_validaReservaMovistock(curMS)
{
	var cantidad = curMS.valueBuffer("cantidad");
	cantidad = cantidad < 0 ? cantidad * -1 : cantidad;
	
	var enReserva = curMS.valueBuffer("enreserva");
	enReserva = isNaN(enReserva) ? 0 : enReserva;

	if (enReserva > cantidad) {
		sys.warnMsgBox(sys.translate("Error en el movimiento de stock %1 Ref %2. La cantidad reservada %3 excede la cantidad del movimiento %4").arg(curMS.valueBuffer("idmovimiento").toString()).arg(curMS.valueBuffer("referencia")).arg(enReserva).arg(cantidad));
		return false;
	}
	return true;
}

function euromoda_esPartidaXTramos(codPartida)
{
		
	return AQUtil.sqlSelect("lotesstock", "portramos","codlote = '" + codPartida + "' ");		
}

/*function euromoda_dameReferenciaAnverso(producto, referencia, idArtComp)

	FUNCIONAMIENTO HASTA 25-09-2019, A PETICION DE JOSE SE CAMBIA A QUE EL REVERSO NO COJA LOS DATOS DEL ANVERSO Y COJA LOS SUYOS PROPIOS Y EL REVERSO COJIN NO CAOJA LOS DATOS DEL ANVERSO COJIN Y COJA LOS SUYOS PROOPIOS. COMENTO LA FUNCI�N

{
	debug("euromoda_dameReferenciaAnvers");
	var _i = this.iface;
	var oParam = new Object;
	var valor = false;
	var compNormal;
	var factor;
	var cantidadAnverso;
	var cantidadFT = 1; // 15-11-2017
	//1. Sacamos componente normalizado y su factor
	var q = new AQSqlQuery;	
	//q.setSelect("componormal, factor"); 15-11-2017
	q.setSelect("componormal, factor, cantidad");
	q.setFrom("articuloscomp");
	q.setWhere("id = " + idArtComp);	
	debug("q: " + q.sql());		
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		compNormal = q.value("componormal");
		factor = q.value("factor");		
		cantidadFT = q.value("cantidad");	//15-11-2017	
	}	
	debug("compNormal: "+compNormal);
	debug("factor: "+factor);
	debug("cantidadFT: "+cantidadFT);
	if(!compNormal || compNormal == "") {
		if(flfactalma.iface.esReferenciaXPiezas(referencia)) {
			valor = referencia;	
		}	
	}
	debug("compNormal: "+compNormal);
	debug("valor: "+valor);
	if(!valor) {
		switch(compNormal) {
			case "ANVERSO":
			case "ANVERSO COJIN": {
				valor = referencia;	
				debug("lo coge en anverso");				
				break;
			}
			case "REVERSO": {
				var q = new AQSqlQuery;	
				q.setSelect("refcomponente, factor,cantidad");
				q.setFrom("articuloscomp");
				q.setWhere("refcompuesto = '" + producto + "' and componormal = 'ANVERSO'");			
				if (!q.exec()){
					return;
				}  
				if(q.first()) {
					valor = q.value("refcomponente");
					factor = q.value("factor");		
					cantidadFT = q.value("cantidad");//15-11-2017						
				}		
				debug("lo coge en reverso");
				break;
			}
			case "REVERSO COJIN": {
				var q = new AQSqlQuery;	
				q.setSelect("refcomponente, factor,cantidad");
				q.setFrom("articuloscomp");
				q.setWhere("refcompuesto = '" + producto + "' and componormal = 'ANVERSO COJIN'");			
				if (!q.exec()){
					return;
				}  
				if(q.first()) {
					valor = q.value("refcomponente");
					factor = q.value("factor");	
					cantidadFT = q.value("cantidad");	//15-11-2017	
					debug("lo coge en reverso cojin");	
				}					
				break;
			}		
		}

	}
	debug("valor: "+valor);		
	debug("factor: "+factor);
	debug("cantidadFT: "+cantidadFT);
	oParam.referenciaAnverso = valor;
	//oParam.factor = factor;
	oParam.factor = factor*cantidadFT;//15-11-2017

	return oParam;

}*/

function euromoda_dameReferenciaAnverso(producto, referencia, idArtComp)
{
	debug("euromoda_dameReferenciaAnvers");
	var _i = this.iface;
	var oParam = new Object;
	var valor = false;
	var compNormal;
	var factor;
	var cantidadAnverso;
	var cantidadFT = 1; // 15-11-2017
	//1. Sacamos componente normalizado y su factor
	var q = new AQSqlQuery;	
	//q.setSelect("componormal, factor"); 15-11-2017
	q.setSelect("componormal, factor, cantidad");
	q.setFrom("articuloscomp");
	q.setWhere("id = " + idArtComp);	
	debug("q: " + q.sql());		
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		compNormal = q.value("componormal");
		factor = q.value("factor");		
		cantidadFT = q.value("cantidad");	//15-11-2017	
	}	
	debug("compNormal: "+compNormal);
	debug("factor: "+factor);
	debug("cantidadFT: "+cantidadFT);
	if(!compNormal || compNormal == "") {
		if(flfactalma.iface.esReferenciaXPiezas(referencia)) {
			valor = referencia;	
		}	
	}
	debug("compNormal: "+compNormal);
	debug("valor: "+valor);
	if(!valor) {
		switch(compNormal) {
			case "ANVERSO":
			case "ANVERSO COJIN": 
			case "REVERSO":
			case "REVERSO COJIN": {
				valor = referencia;									
				break;
			}
			
		}

	}
	debug("valor: "+valor);		
	debug("factor: "+factor);
	debug("cantidadFT: "+cantidadFT);
	oParam.referenciaAnverso = valor;
	//oParam.factor = factor;
	oParam.factor = factor*cantidadFT;//15-11-2017

	return oParam;

}


function euromoda_controlAlmacenLoteAlbCli(curMS)
{
	
	var _i = this.iface;
	
	if (curMS.isNull("idlineaac") || curMS.isNull("codlote")) {
		return true;
	}
	switch (curMS.modeAccess()) {
		case curMS.Del: {
			var referencia = curMS.valueBuffer("referencia");
			var codLote = curMS.valueBuffer("codlote");

			var oDatosLote = flfactppal.iface.pub_ejecutarQry("lotesstock","codalmacen,em_codalmacenori","codlote= '" + codLote + "' ","lotesstock", false);
			if(oDatosLote.result != 1) {
				return false;
			}
			var codAlmacen = oDatosLote.codalmacen;
			var codAlmacenOrigen = oDatosLote.em_codalmacenori;

			if(!codAlmacenOrigen || codAlmacenOrigen =="") {
				return true;
			}			
			if(codAlmacen != codAlmacenOrigen) {
				if (!AQUtil.execSql("UPDATE lotesstock SET codalmacen = '" + codAlmacenOrigen + "' WHERE codlote = '" + codLote + "'")) {
					return false;
				}			
				//actualizamos el stock del almacen origen
				//var idStockAnt = AQUtil.sqlSelect("stocks", "idstock", "codalmacen = '" + codAlmacenOrigen + "' AND referencia = '" + referencia + "'");
				//flfactalma.iface.pub_actualizarStock(idStockAnt);
			}
			
			break;		
		}		
	}
	return true;
}

function euromoda_asignaColorUnico(curD)
{
	var _i = this.iface;
	if (curD.modeAccess() == curD.Insert) {
		var codDibujo = curD.valueBuffer("coddibujoem");	
		
		var curDibujoColor = new FLSqlCursor("em_dibujoscolor");
		curDibujoColor.select("coddibujoem = " + codDibujo);
		if (!curDibujoColor.first()) {
			curDibujoColor.setModeAccess(curDibujoColor.Insert);
			curDibujoColor.refreshBuffer();
			curDibujoColor.setValueBuffer("coddibujoem", codDibujo);
			curDibujoColor.setValueBuffer("codcolorem","UNICO");
			if(!curDibujoColor.commitBuffer()) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_afterCommit_em_plantillasaltamasivacompleta(curPA)
{
	return true;
}

function euromoda_beforeCommit_em_plantillasaltamasivacompleta(curPA)
{
	var _i = this.iface;

	/*if(curPA.modeAccess() == curPA.Insert) {
		if(!formRecordem_altamasivacompleta.iface.altaPlantillaAltaMasivaCompleta(curPA)) {
			return false;
		}
	}
	if(curPA.modeAccess() == curPA.Del) {
		if(!formRecordem_altamasivacompleta.iface.bajaPlantillaAltaMasivaCompleta(curPA)) {
			return false;
		}
	}*/
	return true;
}

function euromoda_afterCommit_em_valoresmercado(curVM)
{
	var _i = this.iface;
	if (!_i.actualizarDatosVM(curVM)) {
		return false;
	}
	return true;
}

function euromoda_actualizarDatosVM(curVM)
{
	var _i = this.iface;
	var oDatosVM = _i.dameDatosVM(curVM);
	if(!oDatosVM){
		return true;
	}
	var cursor = new FLSqlCursor( "articulos" );
	cursor.select( "referencia = '" + curVM.valueBuffer("referencia") + "'");
	if ( !cursor.first() ) {
		return false;
	}

	cursor.setModeAccess( cursor.Edit );
	cursor.refreshBuffer();	
	cursor.setValueBuffer("em_controlvalmercado", true);
	cursor.setValueBuffer("em_valmercado", oDatosVM.em_valmercado);
	cursor.setValueBuffer("em_unidmercado", oDatosVM.em_unidmercado);
	cursor.setValueBuffer("em_fechavalmercado", oDatosVM.em_fechavalmercado);
	cursor.setValueBuffer("em_observacionesvm", oDatosVM.em_observaciones);	

	if ( !cursor.commitBuffer() ) {
		return false;
	}
	return true;
}

function euromoda_dameDatosVM(curVM)
{
	var _i = this.iface;
	var oDatosVM = new Object();

	var q = new FLSqlQuery;
	q.setSelect("em_valmercado, em_unidmercado, em_fechavalmercado, em_observaciones");
	q.setFrom("em_valoresmercado");
	q.setWhere("referencia = '" + curVM.valueBuffer("referencia") + "' ORDER BY em_fechavalmercado DESC, id DESC");
	if (!q.exec()) {
		return false;
	}
	if (q.first()) {
		oDatosVM.em_valmercado = q.value("em_valmercado");
		oDatosVM.em_unidmercado = q.value("em_unidmercado");
		oDatosVM.em_fechavalmercado = q.value("em_fechavalmercado");
		oDatosVM.em_observaciones = q.value("em_observaciones");
	}else {
		return false;
	}

	return oDatosVM;

}
function euromoda_actualizarDatosUltCompra(referencia)
{
	var _i = this.iface;
	if(!referencia || referencia =="") {
		return true;
	}
	var oParam = _i.dameUltimoCoste(referencia);

	if(!oParam) {
		return true;
	}

	
	var curArticulo = new FLSqlCursor("articulos");
	curArticulo.select("referencia = '" + referencia + "'");
	if (!curArticulo.first()) {
		return false;
	}
	curArticulo.setModeAccess(curArticulo.Edit);
	curArticulo.refreshBuffer();
	curArticulo.setValueBuffer("em_fechaultcompra", formRecordarticulos.iface.pub_commonCalculateField("em_fechaultcompra", curArticulo));
	curArticulo.setValueBuffer("em_fechaultcoste", oParam.fecha);
	curArticulo.setValueBuffer("costemedio", oParam.coste);
	
	if (!curArticulo.commitBuffer()) {
		return false;
	}
	return true;

}

function euromoda_dameUltimoCoste(referencia)
{
	var oParam = new Object;
	if (referencia == "") {
		return true;
	}
	var coste;
	var fecha;
	var hora;
	var costeF;
	var fechaF;
	var horaF;
	var hayAlbaran = false;
	var hayFactura = false;
	var q = new FLSqlQuery;
	q.setSelect("a.fecha,a.hora, la.pvpunitario, a.tasaconv");
	q.setFrom("lineasalbaranesprov la INNER JOIN albaranesprov a ON la.idalbaran = a.idalbaran");
	q.setWhere("la.referencia = '" + referencia + "' AND la.pvpunitario > 0 AND la.cantidad > 0 ORDER BY a.fecha DESC, a.idalbaran DESC, la.idlinea DESC");
	q.setForwardOnly(true);
	//debug("qAlb: "+q.sql());
	if (!q.exec()) {
	  return false;
	}
	if (q.first()) {
		fecha = q.value("a.fecha");
		hora = q.value("a.hora");
		coste = q.value("la.pvpunitario") * parseFloat(q.value("a.tasaconv"));
		coste = AQUtil.roundFieldValue(coste, "articulos", "costemedio");
		fecha = new Date(Date.parse(fecha.toString().left(10)+hora.toString().right(9)));
		hayAlbaran = true;
	}
	coste = isNaN(coste) ? 0 : coste;
	if(!fecha || fecha == "") {
		fecha = 0;
	}

	var qF = new FLSqlQuery;
	qF.setSelect("f.fecha,f.hora, lf.pvpunitario, f.tasaconv");
	qF.setFrom("lineasfacturasprov lf INNER JOIN facturasprov f ON lf.idfactura = f.idfactura");
	qF.setWhere("lf.referencia = '" + referencia + "' AND lf.pvpunitario > 0 AND lf.cantidad > 0 ORDER BY f.fecha DESC, f.idfactura DESC, lf.idlinea DESC");
	qF.setForwardOnly(true);
	//debug("qF: "+qF.sql());
	if (!qF.exec()) {
	  return false;
	}
	if (qF.first()) {
		fechaF = qF.value("f.fecha");
		horaF = qF.value("f.hora");
		costeF = qF.value("lf.pvpunitario") * parseFloat(qF.value("f.tasaconv"));
		costeF = AQUtil.roundFieldValue(costeF, "articulos", "costemedio");
		fechaF = new Date(Date.parse(fechaF.toString().left(10)+horaF.toString().right(9)));
		hayFactura = true;
	}
	costeF = isNaN(costeF) ? 0 : costeF;
	if(!fechaF || fechaF == "") {
		fechaF = 0;
	}
	if(hayAlbaran && hayFactura) {
		//debug("1");
		valor = (fecha.getTime() - fechaF.getTime())/1000; 	
		//debug("valor: "+valor);
		if(valor > 0) {
			//debug("2");
			oParam.fecha = q.value("a.fecha");
			oParam.coste = coste;
		} else {
			//debug("3");
			oParam.fecha = qF.value("f.fecha");
			oParam.coste = costeF;
		}
	} else if(hayAlbaran) {
		//debug("4");
		oParam.fecha = q.value("a.fecha");
		oParam.coste = coste;
	} else if(hayFactura) {
		///debug("5");
		oParam.fecha = qF.value("f.fecha");
		oParam.coste = costeF;
	} else {
		//debug("6");
		return false;
	}	
	return oParam;
}


function euromoda_actualizarFechaUltVenta(referencia)
{
	var _i = this.iface;
	if (referencia == "") {
		return true;
	}
	var curArticulo = new FLSqlCursor("articulos");
	curArticulo.select("referencia = '" + referencia + "'");
	if (!curArticulo.first()) {
		return false;
	}
	curArticulo.setModeAccess(curArticulo.Edit);
	curArticulo.refreshBuffer();
	
	curArticulo.setValueBuffer("em_fechaultventa", formRecordarticulos.iface.pub_commonCalculateField("em_fechaultventa", curArticulo));
	if (!curArticulo.commitBuffer()) {
		return false;
	}
	return true;

}
							   
function euromoda_beforeCommit_em_sustcompocol(curS)
{
	
	var _i  = this.iface;
	if (!flfactppal.iface.pub_controlDatosMod(curS)) {
		return false;
	}
	return true;
}

function euromoda_beforeCommit_em_valoresmercado(curVM){
	
	var _i  = this.iface;
	if (!flfactppal.iface.pub_controlDatosMod(curVM)) {
		return false;
	}
	return true;
}

function euromoda_beforeCommit_lotesstock(curLote)
{
	var _i = this.iface;
	if(!_i.__beforeCommit_lotesstock(curLote)) {
		return false;
	}
	
	if(!_i.borraReservasLote(curLote)) {
		return false;
	}
	return true;
}

function euromoda_borraReservasLote(curLote)
{
	var _i = this.iface;
	
	if(curLote.modeAccess() == curLote.Del) {
		if (!AQUtil.sqlDelete("em_reservasestlote", "codlote = '" + curLote.valueBuffer("codLote") + "'")) {
			return false;
		}
	}
	return true;	
}

function euromoda_beforeCommit_em_bajapiezasmas(curB)
{
	var _i = this.iface;
	
	if (!_i.controlDatosMod(curB)) {
		return false;
	}
	
	return true;
}

function euromoda_actualizarDatosUltCompraAlm(idStock)
{
	var _i = this.iface;
	if(!idStock || idStock =="") {
		return true;
	}	
	var curStock = new FLSqlCursor("stocks");
	curStock.select("idstock = " + idStock);
	if (!curStock.first()) {
		return false;
	}
	curStock.setModeAccess(curStock.Edit);
	curStock.refreshBuffer();
	curStock.setValueBuffer("em_fechaultcompraalm", formRecordstocks.iface.pub_commonCalculateField("em_fechaultcompraalm", curStock));	
	if (!curStock.commitBuffer()) {
		return false;
	}
	return true;

}

function euromoda_actualizarFechaUltVentaAlm(idStock)
{
	var _i = this.iface;		
	if (!idStock || idStock == "") {
		return true;
	}	
	var curStock = new FLSqlCursor("stocks");
	curStock.select("idstock = '" + idStock + "'");
	if (!curStock.first()) {
		return false;
	}	
	curStock.setModeAccess(curStock.Edit);
	curStock.refreshBuffer();	
	curStock.setValueBuffer("em_fechaultventaalm", formRecordstocks.iface.pub_commonCalculateField("em_fechaultventaalm", curStock));
	
	if (!curStock.commitBuffer()) {
		return false;
	}	
	return true;

}

function euromoda_controlDatosModCosteProd(curA)
{
	//debug("euromoda_controlDatosModCosteProd 1");
	var _i = this.iface;	
	if(curA.modeAccess() == curA.Insert || curA.modeAccess() == curA.Edit) {	
		//debug("euromoda_controlDatosModCosteProd 2");
		var usuario = sys.nameUser();
		var d = new Date;
		if(curA.table() == "articulos" && curA.valueBuffer("em_tipocoste") == "Heredado") {
			
		}else if(curA.table() == "articulos" || curA.table() == "em_plantillasprod" || curA.table() == "em_tamanossubfam" || curA.table() == "em_plantillasprod" || curA.table() == "subfamilias") {		
			//debug("euromoda_controlDatosModCosteProd 3");
			if (_i.hayCambioCosteProd(curA)) {
				//debug("euromoda_controlDatosModCosteProd 4");
				curA.setValueBuffer("em_idusuariocosteprod", usuario);			
				curA.setValueBuffer("em_fechacosteprod", d.toString());
				curA.setValueBuffer("em_horacosteprod", d.toString().right(8));
				//debug("euromoda_controlDatosModCosteProd 5");
			}
		}
		//debug("euromoda_controlDatosModCosteProd 6");		
		if(curA.table() == "articulos" && curA.valueBuffer("em_tipomargen") == "Heredado") {
		
		} else if (_i.hayCambioMargenProd(curA)) {	
			//debug("euromoda_controlDatosModCosteProd 7");
			curA.setValueBuffer("em_idusuariomargenprod", usuario);			
			curA.setValueBuffer("em_fechamargenprod", d.toString());
			curA.setValueBuffer("em_horamargenprod", d.toString().right(8));
		}		
	}	
	//debug("euromoda_controlDatosModCosteProd 8");
	return true;
}

function euromoda_hayCambioCosteProd(curA)
{
	//debug("\n\n euromoda_hayCambioCosteProd 1");
	var _i = this.iface;
	/*debug("costeprod: "+curA.valueBuffer("em_costeprod"));
	debug("costeprodCopy: "+curA.valueBufferCopy("em_costeprod"));
	debug("em_observcosteprod: "+curA.valueBuffer("em_observcosteprod"));
	debug("em_observcosteprodCopy: "+curA.valueBufferCopy("em_observcosteprod"));*/

	if(_i.oCostes_ && "em_costeprod" in _i.oCostes_ && "em_observcosteprod" in _i.oCostes_) {
		//debug("euromoda_hayCambioCosteProd 2");
		//debug("ocostes coste: "+_i.oCostes_["em_costeprod"]);
		//debug("ocostes observ: "+_i.oCostes_["em_observcosteprod"]);
		if(_i.oCostes_["em_costeprod"] == curA.valueBuffer("em_costeprod") && _i.oCostes_["em_observcosteprod"] == curA.valueBuffer("em_observcosteprod")) {
			//debug("euromoda_hayCambioCosteProd 3");
			return false;
		}	
		//debug("euromoda_hayCambioCosteProd 4");
	} else {		
		//debug("euromoda_hayCambioCosteProd 5");
		if(curA.table() == "articulos" && curA.valueBuffer("em_tipocoste") != curA.valueBufferCopy("em_tipocoste")) {
			return true;
		} else if (curA.valueBuffer("em_costeprod") == curA.valueBufferCopy("em_costeprod") && curA.valueBuffer("em_observcosteprod") == curA.valueBufferCopy("em_observcosteprod")) {	
			//debug("euromoda_hayCambioCosteProd 6");
			return false;
		}	
		//debug("euromoda_hayCambioCosteProd 7");
	}
	//debug("euromoda_hayCambioCosteProd 8");
	return true;
}

function euromoda_hayCambioMargenProd(curA)
{	
	var _i = this.iface;
	if(_i.oMargenes_ && "em_margenprod" in _i.oMargenes_ && "em_observmargenprod" in _i.oMargenes_) {		
		if(_i.oMargenes_["em_margenprod"] == curA.valueBuffer("em_margenprod") && _i.oMargenes_["em_observmargenprod"] == curA.valueBuffer("em_observmargenprod")) {
			return false;
		}		
	} else {

		if(curA.table() == "articulos" && curA.valueBuffer("em_tipomargen") != curA.valueBufferCopy("em_tipomargen")) {
			return true;
		} else if (curA.valueBuffer("em_margenprod") == curA.valueBufferCopy("em_margenprod") && curA.valueBuffer("em_observmargenprod") == curA.valueBufferCopy("em_observmargenprod")) {						
			return false;
		}
	}

	return true;
}

function euromoda_beforeCommit_familias(curF)
{	
	var _i = this.iface;	
	if(!_i.__beforeCommit_familias(curF)) {
		return false;
	}
	if(!formRecordfamilias.iface.actualizaHerencia_) {		
		if (!_i.controlDatosModCosteProd(curF)) {
			return false;
		}
		if(!formRecordarticulos.iface.ponDatosLogCostes("familias", curF)) {
			return false;
		}
	}	
	return true;
}

function euromoda_beforeCommit_subfamilias(curSF)
{
	var _i = this.iface;
	//debug("euromoda_beforeCommit_subfamilias 1");
	if(!_i.__beforeCommit_subfamilias(curSF)) {
		return false;
	}	
	//debug("euromoda_beforeCommit_subfamilias 2");
	if(!formRecordsubfamilias.iface.actualizaHerencia_) {	
		//debug("euromoda_beforeCommit_subfamilias 3");	
		if (!_i.controlDatosModCosteProd(curSF)) {
			//debug("euromoda_beforeCommit_subfamilias 4");
			return false;
		}
		//debug("euromoda_beforeCommit_subfamilias 5");
		if(!formRecordarticulos.iface.ponDatosLogCostes("subfamilias", curSF)) {
			//debug("euromoda_beforeCommit_subfamilias 6");
			return false;
		}
		//debug("euromoda_beforeCommit_subfamilias 7");
	}
	//debug("euromoda_beforeCommit_subfamilias 8");
	return true;
}
						
function euromoda_beforeCommit_em_tamanossubfam(curTSF)
{
	var _i = this.iface;
	if(!formRecordem_tamanossubfam.iface.actualizaHerencia_) {	
		if (!_i.controlDatosModCosteProd(curTSF)) {
			return false;
		}
		if(!formRecordarticulos.iface.ponDatosLogCostes("tama�os por subfamilia", curTSF)) {
			return false;
		}
	}
	return true;
}

function euromoda_beforeCommit_em_plantillasprod(curPP)
{
	var _i = this.iface;
	if(!formRecordem_plantillasprod.iface.actualizaHerencia_) {	
		if (!_i.controlDatosModCosteProd(curPP)) {
			return false;
		}
		if(!formRecordarticulos.iface.ponDatosLogCostes("plantillas", curPP)) {
			return false;
		}
	}
	return true;
}

function euromoda_beforeCommit_inventarios(curInv)
{
	var _i = this.iface;

	if (!flfactppal.iface.pub_controlDatosMod(curInv)) {
		return false;
	}

	return true;
}

function euromoda_beforeCommit_reglotestock(curRlt)
{
	var _i = this.iface;
    debug("euromoda_beforeCommit_reglotestock 1");
	if (!flfactppal.iface.pub_controlDatosMod(curRlt)) {
		return false;
	}
    debug("euromoda_beforeCommit_reglotestock 2");
	return true;
}

function euromoda_beforeCommit_lineasregstocks(curLrls)
{
	var _i = this.iface;

	if(!_i.__beforeCommit_lineasregstocks(curLrls)) {
		return false;
	}
	if (!flfactppal.iface.pub_controlDatosMod(curLrls)) {
		return false;
	}

	return true;
}

function euromoda_afterCommit_lineasregstocks(curLRS) 
{
	var _i = this.iface;
	if(!_i.__afterCommit_lineasregstocks(curLRS)) {
		return false;
	}	 	
	//if(curLRS.modeAccess() == curLRS.Del) {
		if(curLRS.valueBuffer("codinventario") && curLRS.valueBuffer("codinventario") != "") {	
			if (!flfactalma.iface.calculaReservasStockDerivadas(curLRS.valueBuffer("idstock"), 0, 0, undefined)) {			
				return false;
			}
			if (!flfactalma.iface.procesaStocks()) {
				return false;
			}
		}
	//}
	return true;
}

function euromoda_pedidoAlmDep(curMS)
{
	var esDeposito = false;
	var idLineaPedido = curMS.valueBuffer("idlineapc");
	debug("idLineaPedido: "+idLineaPedido);
	if(idLineaPedido && idLineaPedido != "") {
		esDeposito = AQUtil.sqlSelect("lineaspedidoscli lp INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido INNER JOIN almacenes a ON a.codalmacen = p.codalmacen","em_deposito","lp.idlinea = " + idLineaPedido,"lineaspedidoscli,pedidoscli");
	}
	//debug("esDeposito: "+esDeposito);
	return esDeposito;
}

function euromoda_estructuraDepositoAlbaranCli(curLA)
{
	var _i = this.iface;
	
	if (curLA.modeAccess() == curLA.Edit && !_i.datosStockLineaCambian(curLA)) {
		return true;
	}
	var curAlbaran = curLA.cursorRelation();
	var tipoDeposito;
	if (curAlbaran && curAlbaran.table() == "albaranescli") {
		tipoDeposito = curAlbaran.valueBuffer("tipodeposito");
	} else {
		tipoDeposito = AQUtil.sqlSelect("albaranescli", "tipodeposito", "idalbaran = " + curLA.valueBuffer("idalbaran"));
	}
	if(tipoDeposito && tipoDeposito == "Venta dep�sito") {
		return true;
	}
	return _i.__estructuraDepositoAlbaranCli(curLA);
}

function euromoda_datosDescontarProducto(curLinea, aDatosStockLinea, curArticuloComp)
{
	var _i = this.iface;
	var oRes = new Object;
	oRes["desContarProducto"] = false;	
	var aDatosStockLineaOrigen = new Object;

	for(dato in aDatosStockLinea) {
		aDatosStockLineaOrigen[dato] = aDatosStockLinea[dato];
	}				
	aDatosStockLineaOrigen["cantidad"] = aDatosStockLineaOrigen["cantidad"]*-1;
	var idPedido = curLinea.valueBuffer("idpedido");
	if(idPedido && idPedido != "") {
		var q = new AQSqlQuery;	
		q.setSelect("p.codalmaorigen, prov.emdescontarprod");
		q.setFrom("pedidosprov p INNER JOIN  proveedores prov ON p.codproveedor = prov.codproveedor");
		q.setWhere("idpedido = " + idPedido); 		
		//debug("q.sql(): "+q.sql());		
		if (!q.exec()){
			return oRes;
		}  
		if(!q.first()) {
			return oRes;
		}
		var codAlmacenOri = q.value("p.codalmaorigen");
		var descontar = q.value("prov.emdescontarprod");
		if(codAlmacenOri && codAlmacenOri != "" && descontar) {
			oRes["desContarProducto"] = true;
			aDatosStockLineaOrigen["codAlmacen"] = codAlmacenOri;
			aDatosStockLineaOrigen["concepto"] = aDatosStockLineaOrigen["concepto"] + " Alm.Ori.: "+codAlmacenOri;
		}		
	} else {
		var codProveedor = "";
		var curRel = curLinea.cursorRelation();
		if (curRel && curRel.table() == "albaranesprov") {						
			codProveedor = curRel.valueBuffer("codproveedor");
		} else {
			codProveedor = AQUtil.sqlSelect("albaranesprov", "codproveedor", "idalbaran = " + curLinea.valueBuffer("idalbaran"));
		}
		var q = new AQSqlQuery;	
		q.setSelect("codalmacen, emdescontarprod");
		q.setFrom("proveedores");
		q.setWhere("codproveedor = '" + codProveedor + "'"); 
		//debug("q.sql(): "+q.sql());				
		if (!q.exec()){
			return oRes;
		}  
		if(!q.first()) {
			return oRes;
		}
		var codAlmacenOri = q.value("codalmacen");
		var descontar = q.value("emdescontarprod");

		if(codAlmacenOri && codAlmacenOri != "" && descontar) {
			oRes.desContarProducto = true;
			aDatosStockLineaOrigen["codAlmacen"] = codAlmacenOri;
			aDatosStockLineaOrigen["concepto"] = aDatosStockLineaOrigen["concepto"] + " Alm.Ori.: "+codAlmacenOri;
		}		
	}		
	oRes["aDatosStockLineaOrigen"] = aDatosStockLineaOrigen;
	return oRes; 			
}


function euromoda_creaReservasPedidoProdComp(oParam)
{

	var _i = this.iface;


	/*vamos a poner por aqui el mensaje a ver donde se pierde pozu*/ 
	var idLineaPedido = oParam["idLineaPedido"]; 
	var codLote = oParam["codLote"]; 
	var cantidad = oParam["cantidad"]; 
	var idRLP = oParam["idRLP"];
	var idArticuloComp = oParam["idArticuloComp"];

	
	var curMSLote = new FLSqlCursor("movistock");
	var curMSPedido = new FLSqlCursor("movistock");
	
	curMSLote.setActivatedCheckIntegrity(false);
	curMSLote.setActivatedCommitActions(false);
	
	curMSPedido.setActivatedCheckIntegrity(false);
	curMSPedido.setActivatedCommitActions(false);
	
	var porReservar = cantidad;
	var idMovPadre = AQUtil.sqlSelect("movistock","idmovimiento","idlineapc = " + idLineaPedido + " AND cantidad < 0");

	
	if(idMovPadre && AQUtil.sqlSelect("movistock","idmovimiento","idmovproducto = " + idMovPadre + " AND cantidad < 0 AND idarticulocomp = " + idArticuloComp)) {	
		//en este caso a�n no se ha generado la op del padre y el componente cuelga del movimiento de la l�nea del padre
		curMSPedido.select("idmovproducto = " + idMovPadre + " AND cantidad < 0 AND idarticulocomp = " + idArticuloComp);
	} else {
		//en este caso ya se ha generado la op del padre, ya no tiene movimientos que cuelgan del padre si no que hay consumos
		var codLoteProd = AQUtil.sqlSelect("em_reservaslotepedido","codlote","idlineapc = " + idLineaPedido + " AND idarticulocomp is null");

		curMSPedido.select("codloteprod = '" + codLoteProd + "' AND cantidad < 0 AND idarticulocomp = " + idArticuloComp);
	}	
	
	curMSLote.select("codlote = '" + codLote + "' AND cantidad > 0");
	
	var cPedAbierto = curMSPedido.next();
	var cLotAbierto = curMSLote.next();

	var sigue = cPedAbierto && cLotAbierto;
//debug("sigue " + sigue);
	var idStock;
	if (!sigue) {
		return true;
	}
	curMSPedido.setModeAccess(curMSPedido.Edit);
	curMSPedido.refreshBuffer();
	idStock = curMSPedido.valueBuffer("idstock"); /// Cualquier valor de los cursores usados debe coincidir
	curMSLote.setModeAccess(curMSLote.Edit);
	curMSLote.refreshBuffer();
	
	var canNecesaria = (curMSPedido.valueBuffer("cantidad") * -1) - curMSPedido.valueBuffer("enreserva");
	canNecesaria = isNaN(canNecesaria) ? 0 : canNecesaria;
//debug("canNecesaria " + canNecesaria + " idmov " + curMSPedido.valueBuffer("idmovimiento"));
	var canDisponible = curMSLote.valueBuffer("cantidad") - curMSLote.valueBuffer("enreserva");
	canDisponible = isNaN(canDisponible) ? 0 : canDisponible;
//debug("canDisponible " + canDisponible + " idmov " + curMSLote.valueBuffer("idmovimiento"));
	if (!canNecesaria || !canDisponible) {
		return true;
	}
	var aReservar;
	while (sigue) {
		aReservar = Math.min(canNecesaria, canDisponible);
		if (aReservar > porReservar) {
			aReservar = porReservar;
		}
//debug("aReservar " + aReservar);


		if (!_i.creaReservaStock(curMSPedido.valueBuffer("idmovimiento"), curMSLote.valueBuffer("idmovimiento"), aReservar, idRLP)) {
			return false;
		}

		if (aReservar == canNecesaria) {
			curMSPedido.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMSPedido));
			if (!curMSPedido.commitBuffer()) {
				return false;
			}
			cPedAbierto = curMSPedido.next();
			if (cPedAbierto) {
				curMSPedido.setModeAccess(curMSPedido.Edit);
				curMSPedido.refreshBuffer();
				canNecesaria = (curMSPedido.valueBuffer("cantidad") * -1) - curMSPedido.valueBuffer("enreserva");
//debug("canNecesaria " + canNecesaria + " idmov " + curMSPedido.valueBuffer("idmovimiento"));
			}
		}		
		if (aReservar == canDisponible) {
			curMSLote.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curMSLote));
			if (!curMSLote.commitBuffer()) {
				return false;
			}
			cLotAbierto = curMSLote.next();
			if (cLotAbierto) {
				curMSLote.setModeAccess(curMSLote.Edit);
				curMSLote.refreshBuffer();
				canDisponible = curMSLote.valueBuffer("cantidad") - curMSLote.valueBuffer("enreserva");
//debug("canDisponible " + canDisponible + " idmov " + curMSLote.valueBuffer("idmovimiento"));
			}
		}	
		porReservar -= aReservar;
		sigue = cLotAbierto && cPedAbierto && porReservar > 0;
	}
	if (cPedAbierto) {
		curMSPedido.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMSPedido));
		if (!curMSPedido.commitBuffer()) {
			return false;
		}
	}
	if (cLotAbierto) {
		curMSLote.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservapterx", curMSLote));
		if (!curMSLote.commitBuffer()) {
			return false;
		}
	}
	
	return true;
}

function euromoda_beforeCommit_em_altamasivasubfam(curAMS)
{     
    const _i = this.iface;
    debug("euromoda_beforeCommit_em_altamasivasubfam");
    if(!_i.controlBorradoAltaMasSubFam(curAMS)) {
        return false;
    }
    return true;
}

function euromoda_controlBorradoAltaMasSubFam(curAMS) 
{
    if(curAMS.modeAccess() == curAMS.Del) {
        var idAltaSubFam = curAMS.valueBuffer("idaltasubfam");
        if (!AQUtil.sqlDelete("em_altamasivatamsub", "idaltasubfam = " + idAltaSubFam)) {
            return false;
        }
    }

    return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
