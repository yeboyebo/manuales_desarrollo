
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
class euromoda extends oficial {
    function euromoda( context ) { oficial ( context ); }
    function calculateFieldFacturasCli(fN, curFactura) {
    	return this.ctx.euromoda_calculateFieldFacturasCli(fN, curFactura);
    }
	function calculateFieldFacturasProv(fN, curFactura) {
    	return this.ctx.euromoda_calculateFieldFacturasProv(fN, curFactura);
    }    
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////

function euromoda_calculateFieldFacturasCli(fN, curFactura)
{
	
	var _i = this.iface;
    var ret;
    switch(fN){
        case "descripcionoperacion": {

        	var idFactura = curFactura.valueBuffer("idfactura");
        	ret =  AQUtil.sqlSelect("lineasfacturascli l left outer join articulos a on l.referencia = a.referencia left outer join familias f on f.codfamilia = a.codfamilia left outer join co_subcuentas sc on sc.idsubcuenta = l.idsubcuenta","array_to_string(array_agg(distinct(COALESCE(f.em_descopersii,sc.descripcion))),', ')","l.idfactura = " + idFactura,"lineasfacturascli,articulos,familias,co_subcuentas");
        	if(ret &&  ret != "") {
        		ret = ret.left(500);
        	}
        	break;
        }
        default: {
        	return _i.__calculateFieldFacturasCli(fN, curFactura);
        } 
    }    
    if (!ret) ret = "";
    return ret;
}

function euromoda_calculateFieldFacturasProv(fN, curFactura)
{
	
	var _i = this.iface;
    var ret;
    switch(fN){
        case "descripcionoperacion": {

        	var idFactura = curFactura.valueBuffer("idfactura");
        	ret =  AQUtil.sqlSelect("lineasfacturasprov l left outer join articulos a on l.referencia = a.referencia left outer join familias f on f.codfamilia = a.codfamilia left outer join co_subcuentas sc on sc.idsubcuenta = l.idsubcuenta","array_to_string(array_agg(distinct(COALESCE(f.em_descopersii,sc.descripcion))),', ')","l.idfactura = " + idFactura,"lineasfacturasprov,articulos,familias,co_subcuentas");
        	if(ret &&  ret != "") {
        		ret = ret.left(500);
        	}
        	break;
        }
        case "fechaoperacion": {
            if (!curFactura.valueBuffer("fechaoperacion")){
                ret = curFactura.valueBuffer("fechavalor");
                if (!ret) {
                    ret = _i.__calculateFieldFacturasProv(fN, curFactura);
                }
            } else {
                ret = curFactura.valueBuffer("fechaoperacion");
            }
            break;
        }
        case "fechaexpedicion": {
            if (!curFactura.valueBuffer("fechaexpedicion")){
                //ret = curFactura.valueBuffer("fechavalor"); 23-11-2020 Jose nos pide que sea fecha factura
                ret = curFactura.valueBuffer("fecha");
                if (!ret) {
                    ret = _i.__calculateFieldFacturasProv(fN, curFactura);
                }
            } else {
                ret = curFactura.valueBuffer("fechaexpedicion");
        	}
        	break;
        }
        default: {
        	return _i.__calculateFieldFacturasProv(fN, curFactura);
        } 
    }    
    if (!ret) ret = "";
    return ret;
}

//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
