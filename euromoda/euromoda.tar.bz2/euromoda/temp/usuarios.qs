
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function habilitaPorResAgente() {
		return this.ctx.euromoda_habilitaPorResAgente();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();	 
	_i.habilitaPorResAgente();
}

function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "restrigidoagente": {
			if (!cursor.valueBuffer("restrigidoagente")) {
				sys.setObjText(this, "fdbAgentesPermitidos", "");
			}
			_i.habilitaPorResAgente();
			break;
		}
	}
}

function euromoda_habilitaPorResAgente()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.valueBuffer("restrigidoagente")) {
		sys.enableObj(this, "fdbAgentesPermitidos");
	} else {
		sys.disableObj(this, "fdbAgentesPermitidos");
	}
}
//// EUROMODA ////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
