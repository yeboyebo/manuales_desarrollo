/***************************************************************************
                 em_asignarpiezas.qs  -  description
                             -------------------
    begin                : lun jul 11 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
  function calculateField(fN: String)
  {
    return this.ctx.interna_calculateField(fN);
  }
  function validateForm()
  {
    return this.ctx.interna_validateForm();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	var cLON, cCAN;
  var codFamEstampado_, codFamCrudo_, codSubfamEstampado_, codSubfamCrudo_;
	var curLineaPedido_;
	var numLineaProv_;
  function oficial(context)
  {
    interna(context);
  }
  function tbnDividirEnPiezas_clicked()
  {
    return this.ctx.oficial_tbnDividirEnPiezas_clicked();
  }
  function iniciaTablaPiezas()
  {
    return this.ctx.oficial_iniciaTablaPiezas();
  }
  function estableceUbicacion()
  {
    return this.ctx.oficial_estableceUbicacion();
  }
  function tblPiezas_valueChanged(f, c)
  {
    return this.ctx.oficial_tblPiezas_valueChanged(f, c);
  }
  function generaLineasPiezas(c, nP, lP, ubicacion)
  {
    return this.ctx.oficial_generaLineasPiezas(c, nP, lP, ubicacion);
  }
  function tbnGuardarPiezas_clicked()
  {
    return this.ctx.oficial_tbnGuardarPiezas_clicked();
  }
  function tbnPedidoProv_clicked()
  {
    return this.ctx.oficial_tbnPedidoProv_clicked();
  }
  function trGuardarPiezas(oParam)
  {
    return this.ctx.oficial_trGuardarPiezas(oParam);
  }
  function calculaTotal()
  {
    return this.ctx.oficial_calculaTotal();
  }
  function tbnQuitarPieza_clicked()
  {
    return this.ctx.oficial_tbnQuitarPieza_clicked();
  }
  function iniciarTablas()
  {
    return this.ctx.oficial_iniciarTablas()
  }
  function dameFiltroLineas()
  {
    return this.ctx.oficial_dameFiltroLineas()
  }
  function filtraLineas()
  {
    return this.ctx.oficial_filtraLineas()
  }
  function filtraPiezas()
  {
    return this.ctx.oficial_filtraPiezas()
  }
  function tbnCerrarLinea_clicked()
  {
    return this.ctx.oficial_tbnCerrarLinea_clicked()
  }
  function pbnVerPartida_clicked()
  {
    return this.ctx.oficial_pbnVerPartida_clicked()
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
Este formulario realiza la gestion de los albaranes a clientes.

Los albaranes pueden ser generados de forma manual o a partir de uno o mas pedidos.
\end */
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  _i.codFamEstampado_ = flfactalma.iface.pub_dameFamEstampado();
	_i.codFamCrudo_ = flfactalma.iface.pub_dameFamCrudo();
	
	_i.codSubfamEstampado_ = flfactalma.iface.pub_dameSubfamEstampado();
	_i.codSubfamCrudo_ = flfactalma.iface.pub_dameSubfamCrudo();
  
	connect(this.child("tbnQuitarPieza"), "clicked()", _i, "tbnQuitarPieza_clicked()");
	connect(this.child("tbnCerrarLinea"), "clicked()", _i, "tbnCerrarLinea_clicked()");
	connect(this.child("pbnVerPartida"), "clicked()", _i, "pbnVerPartida_clicked()");
	connect(this.child("tbnPedidoProv"), "clicked()", _i, "tbnPedidoProv_clicked");
	
	connect(this.child("tbnGuardarPiezas"), "clicked()", _i, "tbnGuardarPiezas_clicked()");
	connect(this.child("tblPiezas"), "valueChanged(int, int)", _i, "tblPiezas_valueChanged");
	connect(this.child("tdbLineasPedidosProv"), "currentChanged()", _i, "estableceUbicacion");
  
	_i.iniciarTablas();
	_i.filtraPiezas();  
	_i.iniciaTablaPiezas();
}

function interna_calculateField(fN)
{
  return 0;
}

function interna_validateForm()
{
  var cursor = this.cursor();
  return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnPedidoProv_clicked()
{
	var _i = this.iface;
	var f = new FLFormSearchDB("em_buspedprov");
	f.setMainWidget();
	var curA = f.cursor()
	var curAlbaran = formRecordalbaranesprov.cursor();
	curA.setMainFilter("codproveedor = '" + curAlbaran.valueBuffer("codproveedor") + "'");
	var codigo = f.exec("codigo");
	if (!codigo) {
		sys.setObjText(this, "lblPedidoProv", "");
		return;
	}
	sys.setObjText(this, "lblPedidoProv", codigo);
	_i.filtraLineas();
}

function oficial_tbnGuardarPiezas_clicked()
{
	var _i = this.iface;
	
	var curMS = this.child("tdbLineasPedidosProv").cursor();
	if (curMS.valueBuffer("em_merma")) {
		sys.warnMsgBox(sys.translate("El movimiento es de merma."));
		return;
	}
	
	var total = _i.calculaTotal();
	var t = this.child("tblPiezas");
	total = isNaN(l) ? 0 : total;
  
  var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al generar las piezas");
	var f;
	var ver = sys.version();
	var verBuild = parseInt(ver.mid(ver.lastIndexOf("Build") + 6));
  if (!isNaN(verBuild) && verBuild > 34895) {
    f = new Function("oParam", "return formem_asignarpiezas.iface.trGuardarPiezas(oParam)");
	} else {
    f = new Function("oParam", "return formSearchem_asignarpiezas.iface.trGuardarPiezas(oParam)");
	}
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	
	t.setNumRows(1);
	t.setText(0, _i.cLON, "");
	t.setText(0, _i.cCAN, "1");
// 	this.child("tdbLineasPedidosProv").refresh();
	_i.filtraLineas();
	this.child("tdbPiezas").refresh();
	sys.setObjText(this, "lblTotal", sys.translate("Total %1").arg(_i.calculaTotal()));
}

function oficial_trGuardarPiezas(oParam)
{
  var _i = this.iface;
	var l, c;
	var curLP = this.child("tdbLineasPedidosProv").cursor();
	var ubicacion = this.child("ledUbicacion").text;
  var t = this.child("tblPiezas");
	var nR = t.numRows();
	AQUtil.createProgressDialog(sys.translate("Creando piezas"), nR);
	var p = 0;
	this.iface.numLineaProv_ = 0;
	for (var f = 0; f < nR; f++) {
		AQUtil.setProgress(++p);
		l = t.text(f, _i.cLON);
		c = t.text(f, _i.cCAN);
		if (l != "" && c != "" && l > 0 && c > 0) {
			if (!_i.generaLineasPiezas(curLP, c, l, ubicacion)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_generaLineasPiezas(c, nP, lP, ubicacion)
{
	debug("oficial_generaLineasPiezas " + ubicacion);
	var _i = this.iface;
	if (nP <= 0) {
		return false;
	}

	var curLA = new FLSqlCursor("lineasalbaranesprov");
	var curAlbaran = formRecordalbaranesprov.cursor();
	if (curAlbaran.modeAccess() == curAlbaran.Insert) {
		var curLA2 = formRecordalbaranesprov.child("tdbLineasAlbaranesProv").cursor();
		if (!curLA2.commitBufferCursorRelation()) {
			return false;
		}
	}
	var idAlbaran = curAlbaran.valueBuffer("idalbaran");
	var codFormato = curAlbaran.valueBuffer("codformato");
	// 	var idLineaPedido = c.valueBuffer("idlinea");
	var idLineaPedido = c.valueBuffer("idlineapp");
	var codPartida = c.valueBuffer("codpartida");
	var referencia = c.valueBuffer("referencia");

	/// Localizamos o creamos la l�nea de albar�n a la que asociar las piezas
	var idLA;
	curLA.select("idalbaran = " + idAlbaran + " AND idlineapedido = " + idLineaPedido);
	if (!curLA.first()) {
		var datosLineaP = flfactppal.iface.pub_ejecutarQry("lineaspedidosprov", "descripcion,pvpunitario,codimpuesto,idpedido,iva,recargo", "idlinea = " + idLineaPedido);
		if (datosLineaP.result != 1) {
			return false;
		}

		this.iface.numLineaProv_++;
		curLA.setModeAccess(curLA.Insert);
		curLA.refreshBuffer();
		curLA.setValueBuffer("idalbaran", idAlbaran);
		curLA.setValueBuffer("codformato", codFormato);
		curLA.setValueBuffer("referencia", referencia);
		curLA.setValueBuffer("descripcion", datosLineaP.descripcion);
		curLA.setValueBuffer("pvpunitario", datosLineaP.pvpunitario);
		curLA.setValueBuffer("codimpuesto", datosLineaP.codimpuesto);
		curLA.setValueBuffer("idlineapedido", idLineaPedido);
		curLA.setValueBuffer("codpartida", codPartida);
		curLA.setValueBuffer("idpedido", datosLineaP.idpedido);
		curLA.setValueBuffer("iva", datosLineaP.iva);
		curLA.setValueBuffer("recargo", datosLineaP.recargo);
		curLA.setValueBuffer("cantidad", 0);
		curLA.setValueBuffer("pvpsindto", 0);
		curLA.setValueBuffer("pvptotal", 0);
		curLA.setValueBuffer("numlinea", this.iface.numLineaProv_);

		var q = new AQSqlQuery;	
		q.setSelect("codtamanoem,codcolorem");
		q.setFrom("articulos");
		q.setWhere("referencia = '" + referencia + "'");		
		if (!q.exec()){
			return;
		}  
		if(q.first()) {
			curLA.setValueBuffer("codtamanoem", q.value("codtamanoem"));
			curLA.setValueBuffer("codcolorem", q.value("codcolorem"));	
		}

		if (!curLA.commitBuffer()) {
			return false;
		}
		idLA = curLA.valueBuffer("idlinea");
		curLA.select("idlinea = " + idLA);
		if (!curLA.first()) {
			debug("!curLA.first()");
			return false;
		}
	}
	curLA.setModeAccess(curLA.Edit);
	curLA.refreshBuffer();
	idLA = curLA.valueBuffer("idlinea");

	/// Creamos los movimientos de stock HECHO y sus lotes
	var curMS = new FLSqlCursor("movistock");
	var codLote;
	var oArticulo = new Object();
	oArticulo.referencia = referencia;
	oArticulo.ubicacion = ubicacion;
	oArticulo.codpartida = codPartida;
	oArticulo.codalbaranprov = AQUtil.sqlSelect("albaranesprov", "codigo", "idalbaran = " + idAlbaran);
	oArticulo.codproveedor = AQUtil.sqlSelect("albaranesprov", "codproveedor", "idalbaran = " + idAlbaran);
	oArticulo.codalmacen = curAlbaran.valueBuffer("codalmacen");
	var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + oArticulo.codalmacen + "'");
	if ( !idStock ) {
		idStock = flfactalma.iface.pub_crearStock( oArticulo.codalmacen, oArticulo );
		if ( !idStock ) {
			return false;
		}
	}
	for (var i = 0; i < nP; i++) {
		var codLote = flfactalma.iface.pub_crearLote(oArticulo, lP, false, false, codFormato);
		if (!codLote) {
			debug("!codLote");
			return false;
		}
		curMS.setModeAccess(curMS.Insert);
		curMS.refreshBuffer();
		curMS.setValueBuffer("referencia", referencia);
		curMS.setValueBuffer("estado", "HECHO");
		curMS.setValueBuffer("cantidad", lP);
		curMS.setValueBuffer("fechareal", curAlbaran.valueBuffer("fecha"));
		curMS.setValueBuffer("horareal", curAlbaran.valueBuffer("hora"));
		curMS.setValueBuffer("idstock", idStock);
		curMS.setValueBuffer("idlineaap", idLA);
		debug("COD PARTIDA " + codPartida);
		curMS.setValueBuffer("codpartida", codPartida);
		curMS.setValueBuffer("codlote", codLote);
		curMS.setValueBuffer("concepto", sys.translate("Albar�n proveedor %1 %2").arg(curAlbaran.valueBuffer("codigo")).arg(curAlbaran.valueBuffer("nombre")));
		if (!curMS.commitBuffer()) {
			debug("!curMS.commitBuffer");
		return false;
		}
	// 		canPendiente -= lP;
	}
	
	/// Actualizamos el movimiento pendiente
// 	curMSPte.setValueBuffer("cantidad", canPendiente);
// 	if (!curMSPte.commitBuffer()) {
// debug("!curMSPte.commitBuffer");
// 		return false;
// 	}
	
	/// Actualizamos la cantidad de la l�nea de albar�n con los nuevos movimientos
	var canLinea = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idlineaap = " + idLA);
	curLA.setValueBuffer("cantidad", canLinea);
	curLA.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLA));
	curLA.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLA));
	if (!curLA.commitBuffer()) {
		debug("!curLA.commitBuffer()");
		return false;
	}
	
	formRecordalbaranesprov.iface.calcularTotales();
	formRecordalbaranesprov.child("tdbLineasAlbaranesProv").refresh();
	debug("ok");
	return true;
}

function oficial_tblPiezas_valueChanged(f, c)
{
	var _i = this.iface;
	var t = this.child("tblPiezas");
	var valor = t.text(f, c);
	if (isNaN(valor)) {
		valor = (c == _i.cCAN ? 1 : "");
		t.setText(f, c, valor);
	}
	if (c == _i.cCAN && valor != Math.abs(valor)) {
		valor = Math.abs(valor);
		t.setText(f, c, valor);
	}
	var nR = t.numRows();
	//if (c = _i.cCAN && f == nR - 1) { //pineboo 21-08-2019
	c = _i.cCAN; //pineboo 21-08-2019
	if (f == nR - 1) { //pineboo 21-08-2019
		t.insertRows(nR);
		t.setText(nR, _i.cCAN, "1");
	}
	sys.setObjText(this, "lblTotal", sys.translate("Total %1").arg(_i.calculaTotal()));
}

function oficial_calculaTotal()
{
	var _i = this.iface;
	var t = this.child("tblPiezas");
	var nR = t.numRows();
	var total = 0;
	for (var f = 0; f < nR; f++) {
		l = t.text(f, _i.cLON);
		c = t.text(f, _i.cCAN);
		if (l != "" && c != "") {
			total += (c * l);
		}
	}
	return total;
}

function oficial_iniciaTablaPiezas()
{
	var _i = this.iface;
	var t = this.child("tblPiezas");
	var c = 0, sep = "*", cab = "";
	_i.cLON = c++;
	cab = sys.translate("Longitud");
	cab += sep;
	_i.cCAN = c++;
	cab += sys.translate("Piezas");
	
	t.setNumCols(c);
	t.setNumRows(1);
	t.setColumnLabels(sep, cab);
	t.setText(0, _i.cCAN, "1");
	t.setColumnWidth(_i.cLON, 70);
	t.setColumnWidth(_i.cCAN, 70);
}

function oficial_estableceUbicacion()
{
	var _i = this.iface;
	var curLP = this.child("tdbLineasPedidosProv").cursor();
	var referencia = curLP.valueBuffer("referencia");
	var codAlmacen = "1";
	var ubicacion = AQUtil.sqlSelect("stocks", "ubicacion", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
	this.child("ledUbicacion").text = ubicacion ? ubicacion : "";	
}

function oficial_tbnDividirEnPiezas_clicked()
{
	var _i = this.iface;
	_i.curLineaPedido_ = this.child("tdbLineasPedidosProv").cursor();
	
	if (_i.curLineaPedido_.valueBuffer("cerrada")) {
		MessageBox.warning(sys.translate("scripts", "La l�nea de pedido est� cerrada. Debe reabrirla antes de continuar"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	
  var f = new FLFormSearchDB("em_dividirpiezas");
  f.setMainWidget();
  f.exec();
	this.child("tdbPiezas").refresh();
}

function oficial_tbnCerrarLinea_clicked()
{
	var _i = this.iface;
	_i.curLineaPedido_ = this.child("tdbLineasPedidosProv").cursor();
debug("merma " + _i.curLineaPedido_.valueBuffer("em_merma"));
	if (!AQSql.update("movistock", ["em_merma"], [!_i.curLineaPedido_.valueBuffer("em_merma")], "idmovimiento = " + _i.curLineaPedido_.valueBuffer("idmovimiento"))) {
		return false;
	}
	var idPedido = AQUtil.sqlSelect("lineaspedidosprov", "idpedido", "idlinea = " + _i.curLineaPedido_.valueBuffer("idlineapp"));
	if (!flfacturac.iface.pub_actualizarEstadoPedidoProv(idPedido)) {
		return;
	}
// 	var curLP = new FLSqlCursor("lineaspedidosprov");
// 	curLP.select("idlinea = " + _i.curLineaPedido_.valueBuffer("idlineapp"));
// 	if (curLP.first()) {
// 		curLP.setModeAccess(curLP.Edit);
// 		curLP.commitBuffer();
// 		flfactalma.iface.recalcularMovPiezasPtesPP(curLP);
// 	}

// // 	var idLinea = _i.curLineaPedido_.valueBuffer("idlinea");
// 	var idLinea = _i.curLineaPedido_.valueBuffer("idlineapp");
// 	if (!idLinea) {
// 		return;
// 	}
// 	var cerrada = _i.curLineaPedido_.valueBuffer("cerrada");
// 	if (!AQSql.update("lineaspedidosprov", ["cerrada"], [!cerrada], "idlinea = " + idLinea)) {
// 		return false;
// 	}
// 	var idPedido = _i.curLineaPedido_.valueBuffer("idpedido");
// 	if (!flfacturac.iface.pub_actualizarEstadoPedidoProv(idPedido)) {
// 		return;
// 	}
	_i.filtraLineas();
// 	this.child("tdbLineasPedidosProv").refresh();
}

function oficial_tbnQuitarPieza_clicked()
{
	var _i = this.iface;
	var curPieza = this.child("tdbPiezas").cursor();
	var codLote = curPieza.valueBuffer("codlote");
	var curAlbaran = formRecordalbaranesprov.cursor();
	var idAlbaran = curAlbaran.valueBuffer("idalbaran");
	
	var curMS = new FLSqlCursor("movistock");
	curMS.select("codlote = '" + codLote + "' AND idlineaap IS NOT NULL");
	if (!curMS.first()) {
		return false;
	}
	var idLA = curMS.valueBuffer("idlineaap");
	var idLP = curMS.valueBuffer("idlineapp");
	
	if (AQUtil.sqlSelect("lineaspedidosprov", "cerrada", "idlinea = " + idLP)) {
		MessageBox.warning(sys.translate("scripts", "La l�nea de pedido est� cerrada. Debe reabrirla antes de continuar"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}

	var curLA = new FLSqlCursor("lineasalbaranesprov");
	curLA.select("idlinea = " + idLA);
	if (!curLA.first()) {
		return false;
	}
	
	var canMS = curMS.valueBuffer("cantidad");
	curMS.setModeAccess(curMS.Del);
	curMS.refreshBuffer();
	if (!curMS.commitBuffer()) {
		return false;
	}
	
	var canLinea = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idlineaap = " + idLA);
	curLA.setModeAccess(curLA.Edit);
	curLA.refreshBuffer();
	curLA.setValueBuffer("cantidad", canLinea);
	curLA.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLA));
	curLA.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLA));
	if (!curLA.commitBuffer()) {
		return false;
	}
	if (canLinea == 0) {
		curLA.select("idlinea = " + idLA);
		if (!curLA.first()) {
			return false;
		}
		curLA.setModeAccess(curLA.Del);
		curLA.refreshBuffer();
		if (!curLA.commitBuffer()) {
			return false;
		}
	}

	this.child("tdbPiezas").refresh();
	_i.filtraLineas();
// 	this.child("tdbLineasPedidosProv").refresh();
	formRecordalbaranesprov.iface.calcularTotales();
	formRecordalbaranesprov.child("tdbLineasAlbaranesProv").refresh();
	
	return true;
}

function oficial_iniciarTablas()
{
  var _i = this.iface;
	  
//   var lp = ["idlinea", "referencia", "descripcion", "cantidad", "totalenalbaran", "pendiente", "cerrada", "codpartida"];
//   this.child("tdbLineasPedidosProv").setOrderCols(lp);
	var lpz = ["codlote", "referencia", "cantotal", "ubicacion"];
  this.child("tdbPiezas").setOrderCols(lpz);
	
	_i.filtraLineas();
}

function oficial_filtraLineas()
{
	var _i = this.iface;
	var filtro = _i.dameFiltroLineas();
	this.child("tdbLineasPedidosProv").setFilter(filtro);
	this.child("tdbLineasPedidosProv").refresh();
}

function oficial_dameFiltroLineas()
{
  var _i = this.iface;
	var filtro = "";
	var curAlbaran = formRecordalbaranesprov.cursor();
  var codPedido = this.child("lblPedidoProv").text;
	var where = "p.codproveedor = '" + curAlbaran.valueBuffer("codproveedor") + "' AND (a.codfamilia IN (" + _i.codFamEstampado_ + ", " + _i.codFamCrudo_ + ") OR a.codsubfamilia IN (" + _i.codSubfamEstampado_ + ", " + _i.codSubfamCrudo_ + ")) AND NOT l.cerrada AND ms.cantidad > 0";
	if (codPedido != "") {
		where += (" AND p.codigo = '" + codPedido + "'");
	}
debug("where " + where);
  var q = new FLSqlQuery;
  q.setTablesList("lineaspedidosprov,pedidosprov,articulos");
	q.setSelect("ms.idmovimiento");
  q.setFrom("lineaspedidosprov l INNER JOIN pedidosprov p ON l.idpedido = p.idpedido INNER JOIN articulos a ON l.referencia = a.referencia INNER JOIN movistock ms ON l.idlinea = ms.idlineapp AND NOT ms.em_merma");
  q.setWhere(where);
  q.setForwardOnly(true);
  if (!q.exec()) {
    filtro = "false";
    return false;
  }
  while (q.next()) {
		filtro += (filtro != "" ? ", " : "") + q.value("ms.idmovimiento");
  }
  if (filtro != "") {
		filtro = "idmovimiento IN (" + filtro + ")";
  } else {
		filtro = "false";
	}
debug("filtro " + filtro); 
	return filtro;
}


function oficial_filtraPiezas()
{
	var curAlbaran = formRecordalbaranesprov.cursor();
	var idAlbaran = curAlbaran.valueBuffer("idalbaran");
	var filtro = "codlote IN (SELECT codlote FROM movistock ms INNER JOIN lineasalbaranesprov lp ON ms.idlineaap = lp.idlinea WHERE lp.idalbaran = " + idAlbaran + ")";
	this.child("tdbPiezas").setFilter(filtro);
	this.child("tdbPiezas").refresh();
}

function oficial_pbnVerPartida_clicked()
{
	var _i = this.iface;
	_i.curLineaPedido_ = this.child("tdbLineasPedidosProv").cursor();
	
// 	var idLinea = _i.curLineaPedido_.valueBuffer("idlinea");
	var idLinea = _i.curLineaPedido_.valueBuffer("idlineapp");
	if (!idLinea) {
		return;
	}
	var codPartida = _i.curLineaPedido_.valueBuffer("codpartida");
	if (!codPartida) {
		return false;
	}
	var curPartida = new FLSqlCursor("lotesstock");
	curPartida.select("codlote = '" + codPartida + "'");
	if (!curPartida.first()) {
		return false;
	}
	curPartida.editRecord();
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
