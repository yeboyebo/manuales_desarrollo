/***************************************************************************
                 em_imppednoc.qs  -  description
                             -------------------
    begin                : mar oct 28 2014
    copyright            : (C) 2014 by YeboYebo S.L.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{	
  	var curPedido_, curLineaPed_;
	var importado_;
	function oficial(context) {
		interna(context);
  	} 
	function tbnBuscarFichero_clicked() {
		return this.ctx.oficial_tbnBuscarFichero_clicked();	
	}
	function tbnCargarLineas_clicked() {
		return this.ctx.oficial_tbnCargarLineas_clicked();	
	}
	function tbnGenerarPedidos_clicked() {
		return this.ctx.oficial_tbnGenerarPedidos_clicked();
	}
	function crearPedido(idImportacion, codClienteImp, codAlmacen, fecha) {
		return this.ctx.oficial_crearPedido(idImportacion, codClienteImp, codAlmacen, fecha);
	}
	function crearCabPedido(idImportacion,codAlmacen, fecha) {
		return this.ctx.oficial_crearCabPedido(idImportacion,codAlmacen, fecha);
	}
	function crearLineasPedido(idImportacion, codClienteImp, idPedido, codAlmacen, fecha) {
		return this.ctx.oficial_crearLineasPedido(idImportacion, codClienteImp, idPedido,  codAlmacen, fecha);
	}
	function crearLineaPedido(oParam) {
		return this.ctx.oficial_crearLineaPedido(oParam);
	}
	function prevalidacionLineas(aDatos, codClienteImp) {
		return this.ctx.oficial_prevalidacionLineas(aDatos, codClienteImp);
	}
	function colorError(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_colorError(fN, fV, cursor, fT, sel);
	}
	function labelError() {
		return this.ctx.oficial_labelError();
	}
	function damePVPNoctalia(codCliente, referencia, fecha) {
		return this.ctx.oficial_damePVPNoctalia(codCliente, referencia, fecha);
	}
	function habilitaImportado() {
		return this.ctx.oficial_habilitaImportado();
	}
	function estaImportado() {
		return this.ctx.oficial_estaImportado();
	}
	/*function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}*/
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
  function pub_damePVPNoctalia(codCliente, referencia, fecha) {
    return this.damePVPNoctalia(codCliente, referencia, fecha);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
Este formulario realiza la gestion de los albaranes a clientes.

Los albaranes pueden ser generados de forma manual o a partir de uno o mas pedidos.
\end */
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();  
  
	connect(this.child("tbnBuscarFichero"), "clicked()", _i, "tbnBuscarFichero_clicked");
	connect(this.child("tbnCargarLineas"), "clicked()", _i, "tbnCargarLineas_clicked");
	connect(this.child("tbnGenerarPedidos"), "clicked()", _i, "tbnGenerarPedidos_clicked");
	connect(this.child("tdbLineas"), "currentChanged()", _i, "labelError");
	//connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");
	_i.estaImportado();
	_i.habilitaImportado();
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnBuscarFichero_clicked()
{
	var _i = this.iface;	
	var f = FileDialog.getOpenFileName("*.csv");
	if (!f) {
		return;
	}
	sys.setObjText(this, "fdbNombreFichero", f);
}

function oficial_tbnCargarLineas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(!cursor.commitBuffer()) {
	     return false;
	}
	var codClienteImp = cursor.valueBuffer("codcliente");
	var idImportacion = cursor.valueBuffer("idimportacion");
	var numReg = AQUtil.sqlSelect("em_lineasimppednoc", "COUNT(*)", "idimportacion=" + idImportacion );
	if(numReg && numReg != 0) {
		var res = MessageBox.information(sys.translate("Ya hay datos cargados en las l�neas, estos datos se eliminar�n �Desea continuar?"), MessageBox.Yes, MessageBox.No)
		if (res != MessageBox.Yes) {
			return;
		}
		AQUtil.sqlDelete("em_lineasimppednoc", "idimportacion=" + idImportacion);
	}
	f = cursor.valueBuffer("nombrefichero");
	var sep= ";";	
	var file = new File(f);
  	try {
  		file.open(File.ReadOnly);
  	} catch(e) {
    	sys.warnMsgBox(sys.translate("Error al abrir el fichero:\n%1").arg(f));
		return false;
  	}
	
	var steps = 0;
	var step = 0;
  	while (!file.eof) {
 		file.readLine();
    	++steps;
  	}	
	debug("Pasos: "+steps);
  	file.close();
  	file.open(File.ReadOnly);

	AQUtil.createProgressDialog(sys.translate("Cargando datos"), steps);	
  	while (!file.eof) {
		AQUtil.setProgress(step+1);		
   	var line = file.readLine();	
		if (!line) {
			AQUtil.destroyProgressDialog();
			sys.warnMsgBox(sys.translate("Error al leer la l��nea %1:\n%2").arg(step).arg(line));
			return false;
		}
		if (step > 0) {
			aDatos = line.split(sep);
			var centro = aDatos[0];
			var codAlmacen = aDatos[1];
			var codBarras = aDatos[2];
			var referencia = aDatos[3];
			var descripcion = aDatos[4];
			var cantidad = aDatos[5];

			var tipoError = _i.prevalidacionLineas(aDatos, codClienteImp);

			var curLineas = new FLSqlCursor("em_lineasimppednoc");
			curLineas.setModeAccess(curLineas.Insert);
    		curLineas.refreshBuffer(); 			
			curLineas.setValueBuffer("idimportacion",idImportacion);
			curLineas.setValueBuffer("codcentro",centro);
			curLineas.setValueBuffer("codalmacen",codAlmacen);
			curLineas.setValueBuffer("codbarras",codBarras);
			curLineas.setValueBuffer("referencia",referencia);
			if (tipoError.indexOf("31") == -1 && tipoError.indexOf("41") == -1) {				
				curLineas.setValueBuffer("descripcion",AQUtil.sqlSelect("em_articuloscli", "descripcioncliente", "referencia = '" + aDatos.referenciBC + "' and codcliente = '" + codClienteImp + "'"));
			}
			curLineas.setValueBuffer("cantidad",cantidad);
			curLineas.setValueBuffer("numlinea",step+1);
			curLineas.setValueBuffer("tipoerror",tipoError);
			if (!curLineas.commitBuffer()) {
      		return false;
    		}

		}
		++step;
		
	}		
  	AQUtil.destroyProgressDialog();	
	
	this.child("tdbLineas").refresh();
  	return true;

	
}

function oficial_tbnGenerarPedidos_clicked()
{
	var _i = this.iface;	
	var i = 1;
	var cursor = this.cursor();
	var idImportacion = cursor.valueBuffer("idimportacion");	
	var codClienteImp = cursor.valueBuffer("codcliente");
	var fecha = cursor.valueBuffer("fecha");
	var almaPed = [];
	var q = new AQSqlQuery;	
	q.setSelect("codalmacen");
	q.setFrom("em_lineasimppednoc");
	//q.setWhere("idimportacion = " + idImportacion + " and tipoerror ='' group by codalmacen order by codalmacen" );
	q.setWhere("idimportacion = " + idImportacion + " and tipoerror ='' order by numlinea " );
					
	debug("SELECT DE PEDIDOS: "+q.sql());
	if (!q.exec()){
		return;
	}  
	
	AQUtil.createProgressDialog(sys.translate("Generando pedidos..."), q.size());	
	while(q.next())
	{
		AQUtil.setProgress(i);
		var codAlmacen = q.value("codalmacen");
		if (codAlmacen in almaPed) {
			continue;
		}
		almaPed[codAlmacen] = codAlmacen;
		var codPedido = _i.crearPedido(idImportacion, codClienteImp, codAlmacen, fecha);
		debug ("Pedido creado: "+codPedido);
		i++;
	}
	AQUtil.destroyProgressDialog();
	var numPedidos= i-1;
	if(numPedidos == 0) {
		sys.infoMsgBox(sys.translate("No se ha generado ning�n pedido."));
	} else {
		var mensaje = numPedidos == 1 ? sys.translate("Se ha generado 1 pedido.") : sys.translate("Se han generado %1 pedidos.").arg(numPedidos);
		sys.infoMsgBox(mensaje);
		//AQUtil.sqlUpdate("em_imppednoc", "importadoped", true, "idimportacion = '" + idImportacion + "'");
		//this.child("fdbImportadoPed").setValue(true);		
		_i.estaImportado();
		_i.habilitaImportado();
		this.child("tbwFT").showPage("pedidos");
		this.child("tdbPedidos").refresh();
	}
}
function oficial_crearPedido(idImportacion, codClienteImp, codAlmacen, fecha)
{
	var _i = this.iface;
	
	if (!_i.curPedido_) {
    _i.curPedido_ = new FLSqlCursor("pedidoscli");
	}
  	_i.curPedido_.setModeAccess(_i.curPedido_.Insert);
  	_i.curPedido_.refreshBuffer(); 
  	if (!_i.crearCabPedido(idImportacion,codAlmacen, fecha)) {
  		return false;
  	}
  	if (!_i.curPedido_.commitBuffer()) {
  		return false;
	}
	var idPedido = _i.curPedido_.valueBuffer("idpedido");
 	if (!_i.crearLineasPedido(idImportacion, codClienteImp, idPedido, codAlmacen, fecha)) {
		return false;
	}
	_i.curPedido_.select("idpedido = " + idPedido);
  	if (!_i.curPedido_.first()) {
		return res;
  	}
	_i.curPedido_.setModeAccess(_i.curPedido_.Edit);
	_i.curPedido_.refreshBuffer();
	formpresupuestoscli.iface.curPedido = _i.curPedido_;
	if (!formpresupuestoscli.iface.totalesPedido()) {
		return false;
  	}
  	if (!_i.curPedido_.commitBuffer()) {
		return false;
  	}
	var codPedido = _i.curPedido_.valueBuffer("codigo");
  	return codPedido;
}

function oficial_crearCabPedido(idImportacion,codAlmacen, fecha)
{
	var _i = this.iface;
	_i.curPedido_.setValueBuffer("fecha", fecha);

	var qCli = new AQSqlQuery;	
	qCli.setSelect("cli.codcliente, cli.nombre, cli.cifnif, cli.coddivisa, cli.codpago, cli.codagente, cli.codclientefac, cli.codgrupoivaneg ");
	qCli.setFrom("clientes cli ");
	qCli.setWhere("em_codalmacliente = '" + codAlmacen + "' "); 			
	if (!qCli.exec()){
		return;
	}  
	if(!qCli.first())
	{			
		return false;	
	}

	

	_i.curPedido_.setValueBuffer("codcliente", qCli.value("cli.codcliente"));
	_i.curPedido_.setValueBuffer("nombrecliente", qCli.value("cli.nombre"));
	_i.curPedido_.setValueBuffer("cifnif", qCli.value("cli.cifnif"));
	_i.curPedido_.setValueBuffer("fechasalida", fecha);
	_i.curPedido_.setValueBuffer("fechaservicio", formpedidoscli.iface.pub_commonCalculateField("fechaservicio", _i.curPedido_)); 
	_i.curPedido_.setValueBuffer("coddivisa", qCli.value("cli.coddivisa"));
	_i.curPedido_.setValueBuffer("codserie", formpedidoscli.iface.pub_commonCalculateField("codserie", _i.curPedido_));
	_i.curPedido_.setValueBuffer("codpago", qCli.value("cli.codpago"));
	_i.curPedido_.setValueBuffer("codagente", qCli.value("cli.codagente"));
	_i.curPedido_.setValueBuffer("codalmacen", "1");
	
	
	//var codDir = formpedidoscli.iface.pub_commonCalculateField("coddir", _i.curPedido_);
	var codDir = AQUtil.sqlSelect("dirclientes", "id", "codcliente='" + qCli.value("cli.codcliente") + "' and domenvio");
	if(!codDir) {
		codDir = formpedidoscli.iface.pub_commonCalculateField("coddir", _i.curPedido_);
	}
	var qDir = new AQSqlQuery;	
	qDir.setSelect("dir.direccion, dir.codpostal, dir.ciudad, dir.idprovincia,dir.apartado, dir.codpais");
	qDir.setFrom("dirclientes dir ");
	qDir.setWhere("dir.id = " + codDir); 			
	if (!qDir.exec()){
		return;
	}  
	if(!qDir.first())
	{			
		return false;	
	}
	_i.curPedido_.setValueBuffer("coddir", codDir);
_i.curPedido_.setValueBuffer("irpf", formpedidoscli.iface.pub_commonCalculateField("irpf", _i.curPedido_));
	_i.curPedido_.setValueBuffer("direccion", qDir.value("dir.direccion"))
	_i.curPedido_.setValueBuffer("codpostal", qDir.value("dir.codpostal"));
	_i.curPedido_.setValueBuffer("ciudad", qDir.value("dir.ciudad"));
	if (qDir.value("dir.idprovincia") != 0 ) {
		_i.curPedido_.setValueBuffer("idprovincia", qDir.value("dir.idprovincia"));
	} 
	_i.curPedido_.setValueBuffer("provincia", qDir.value("dir.provincia"));
	_i.curPedido_.setValueBuffer("apartado", qDir.value("dir.apartado"));
	_i.curPedido_.setValueBuffer("codpais", formpedidoscli.iface.pub_commonCalculateField("codpais", _i.curPedido_));
	_i.curPedido_.setValueBuffer("codejercicio",flfactppal.iface.pub_ejercicioActual());
	_i.curPedido_.setValueBuffer("tasaconv",AQUtil.sqlSelect("divisas", "tasaconv", "coddivisa = '" + qCli.value("cli.coddivisa") + "'"));
	_i.curPedido_.setValueBuffer("codclientefac", qCli.value("cli.codclientefac"));
	_i.curPedido_.setValueBuffer("codgrupoivaneg", qCli.value("cli.codgrupoivaneg"));
	_i.curPedido_.setValueBuffer("em_idimpnoctalia", idImportacion );
	
	 return true;


}
function oficial_crearLineasPedido(idImportacion, codClienteImp, idPedido, codAlmacen, fecha)
{
	var _i = this.iface;
	var contLineas = 1;
	if (!_i.curLineaPed_) {
		_i.curLineaPed_ = new FLSqlCursor("lineaspedidoscli");
	}

	//la referencia que tengo en la excel es refcliente, el barcode si que es barcode de la referencia, tengo que sacar la referencia de em_articuloscli donde el cliente sea codClienteImp y la refcliente sea la referencia de la excel

	var qLin = new AQSqlQuery;	
	qLin.setSelect("codbarras, referencia, descripcion, cantidad");
	qLin.setFrom("em_lineasimppednoc ");
	qLin.setWhere("idimportacion = " + idImportacion + " and codalmacen = '" + codAlmacen + "' and tipoerror ='' order by numlinea" );					
	if (!qLin.exec()){
		return;
	}  
	debug("******2 sql: "+qLin.sql());
	while(qLin.next())
	{
	     debug("Linea: "+contLineas); 
		_i.curLineaPed_.setModeAccess(_i.curLineaPed_.Insert);
    	_i.curLineaPed_.refreshBuffer();
    	_i.curLineaPed_.setValueBuffer("idpedido", idPedido);
		var oParam = new Object();
		oParam.codBarras = qLin.value("codbarras");
		var referenciaCliente  = qLin.value("referencia");

		oParam.referencia = AQUtil.sqlSelect("em_articuloscli", "referencia", "codcliente='" + codClienteImp + "' and referenciacliente = '" + referenciaCliente + "'");
		oParam.descripcion = qLin.value("descripcion");
		oParam.cantidad = qLin.value("cantidad");
		oParam.fecha = fecha;
		oParam.codCliente = codClienteImp;

		
    	if (!_i.crearLineaPedido(oParam)) {
      	return false;
   	 }
    	if (!_i.curLineaPed_.commitBuffer()) {
      	return false;
    	}		
	}
	return true;
}
function oficial_crearLineaPedido(oParam)
{
	var _i = this.iface;
	var qArt = new AQSqlQuery;	
	qArt.setSelect("art.codtamanoem, art.codcolorem ");
	qArt.setFrom("articulos art");
	qArt.setWhere("referencia = '" + oParam.referencia + "' "); 			
	if (!qArt.exec()){
		return;
	}  
	if(!qArt.first())
	{			
		return false;	
	}
  	var iva;
  	var recargo;
  	_i.curLineaPed_.setValueBuffer("numlinea", formRecordlineaspedidoscli.iface.pub_commonCalculateField("numlinea", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("referencia",oParam.referencia);
	formRecordlineaspedidoscli.iface.pub_cargaDatosStock(_i.curLineaPed_);
	_i.curLineaPed_.setValueBuffer("emcodbarras",oParam.codBarras);
	_i.curLineaPed_.setValueBuffer("descripcion",oParam.descripcion);
	_i.curLineaPed_.setValueBuffer("codtamanoem", qArt.value("art.codtamanoem"));
	_i.curLineaPed_.setValueBuffer("codcolorem", qArt.value("art.codcolorem"));
	_i.curLineaPed_.setValueBuffer("cantidad", oParam.cantidad);	
	_i.curLineaPed_.setValueBuffer("pvpunitario",_i.damePVPNoctalia(oParam.codCliente, oParam.referencia, oParam.fecha)); 	
	_i.curLineaPed_.setValueBuffer("pvpsindto",formRecordlineaspedidoscli.iface.pub_commonCalculateField("pvpsindto", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("pvptotal",formRecordlineaspedidoscli.iface.pub_commonCalculateField("pvptotal", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("dtolineal",formRecordlineaspedidoscli.iface.pub_commonCalculateField("dtolineal", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("dtopor",formRecordlineaspedidoscli.iface.pub_commonCalculateField("dtopor", _i.curLineaPed_));	 
	
	_i.curLineaPed_.setValueBuffer("codimpuesto",formRecordlineaspedidoscli.iface.pub_commonCalculateField("codimpuesto", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("iva",formRecordlineaspedidoscli.iface.pub_commonCalculateField("iva", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("recargo", formRecordlineaspedidoscli.iface.pub_commonCalculateField("recargo", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("diasservicio",formRecordlineaspedidoscli.iface.pub_commonCalculateField("diasservicio", _i.curLineaPed_)); 
	_i.curLineaPed_.setValueBuffer("fechaservicio",formRecordlineaspedidoscli.iface.pub_commonCalculateField("fechaservicio", _i.curLineaPed_)); 
	_i.curLineaPed_.setValueBuffer("tipoconcepto","Producto");
	_i.curLineaPed_.setValueBuffer("codsubcuenta",formRecordlineaspedidoscli.iface.pub_commonCalculateField("codsubcuenta", _i.curLineaPed_));
	_i.curLineaPed_.setValueBuffer("idsubcuenta",formRecordlineaspedidoscli.iface.pub_commonCalculateField("idsubcuenta", _i.curLineaPed_));

  return true;
}
function oficial_prevalidacionLineas(aDatos, codClienteImp)
{
	var _i = this.iface;
	var tipoError = "";
	var centro = aDatos[0];
	var codAlmacen = aDatos[1];
	var codBarras = aDatos[2];
	var referenciaCliente = aDatos[3];
	var descripcion = aDatos[4];
	var cantidad = aDatos[5];
	var referenciaBC, referencia;
	//centro	
	if (centro == "") {  
		tipoError = "1";
	}

	// codAlmacen
	if (codAlmacen == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "2";
	} else {
		var codCliente = AQUtil.sqlSelect("clientes", "codcliente", "em_codalmacliente ='" + codAlmacen + "'"); 
		if (!codCliente || codCliente == "") {
			tipoError += tipoError == "" ? "" : "|";
			tipoError += "21";
		}
	} 

	// codBarras
	if (codBarras == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "3";
 	} else {
		referenciaBC = AQUtil.sqlSelect("articulos", "referencia", "codbarras ='" + codBarras + "'"); 
		
		if (!referenciaBC || referenciaBC == "") {
			tipoError += tipoError == "" ? "" : "|";
			tipoError += "31";
		} else {
			aDatos.referenciBC = referenciaBC;
		}
	}
	
	//refCliente
	if (referenciaCliente == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "4";
 	} else {
		referencia= AQUtil.sqlSelect("em_articuloscli", "referencia", "codcliente='" + codClienteImp + "' and referenciacliente = '" + referenciaCliente + "'"); 
		if (!referencia || referencia == "") {
			tipoError += tipoError == "" ? "" : "|";
			tipoError += "41";
		}
	}
	if (referenciaBC && referenciaBC != "" && referencia && referencia !="" && referenciaBC != referencia) {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "42";
	}

	//descripcion
	if (descripcion == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "5";
 	}

	//cantidad
	if (cantidad == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "6";
 	}
	
	return tipoError;

}
function oficial_colorError(fN, fV, cursor, fT, sel)
{
	var _i = this.iface;
	var tipoErrores = cursor.valueBuffer("tipoerror");
	var tipoError = tipoErrores.split("|");
	var color = "";
	for (var i = 0; i < tipoError.length; i++) {		
		switch (tipoError[i]) {
			case "1": {
				if(fN == "codcentro") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "2":
			case "21": {
				if(fN == "codalmacen") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "3":
			case "31":
			case "42": {
				if(fN == "codbarras") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "4":
			case "41":
			case "42": {
				if(fN == "referencia") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "5": {
				if(fN == "descripcion") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "6": {
				if(fN == "cantidad") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			default: {
				//color = flfactppal.iface.pub_dameColor("fondo_blanco");
			}

		}
	}
  	
  	if (color != "") {
		var a = [color, "#000000", "SolidPattern", "SolidPattern"];
    	return a;
  	}
}
function oficial_labelError()
{
	var cursor = this.child("tdbLineas").cursor();
	var tipoErrores = cursor.valueBuffer("tipoerror");
	if (!tipoErrores || tipoErrores == "") {
	     this.child("lblerrores").setText("");
		return;
	}
	var tipoError = tipoErrores.split("|");
	var labelError = "";
	for (var i = 0; i < tipoError.length; i++) {		
		switch (tipoError[i]) {
			case "1": {				
				labelError = "C�digo de centro vac�o.";
				break;
			}
			case "2": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "C�digo de almac�n vac�o.";				
				break;
			}
			case "21": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "No se ha encontrado c�digo de cliente para el almac�n " + cursor.valueBuffer("codalmacen") +".";								
				break;
			}

			case "3": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "C�digo de barras vac�o.";				
				break;
			}
			case "31": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "No existe ninguna referencia para el c�digo de barras " + cursor.valueBuffer("codbarras")+ ".";				
				break;
			}
			case "4": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Referencia de cliente vac�a.";				
				break;
			}
			case "41": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "No existe ninguna referencia para la referencia de cliente " + cursor.valueBuffer("referencia") + " y para el cliente " + this.cursor().valueBuffer("codcliente")+".";				
				break;
			}
			case "42": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "La referencia del c�digo de barras no coincide con la referencia.";				
				break;
			}
			case "5": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Descripci�n de la referencia vac�a.";				
				break;
			}
			case "6": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Cantidad a cero.";				
				break;
			}
		}
	}	
	this.child("lblerrores").setText(labelError);
	
}
/*function oficial_damePVPNoctalia(codCliente, referencia, fecha)
{
	var valor =0;	
	var  pvpSinIva = 0;
	var q = new AQSqlQuery;	
	q.setSelect("his.pvpsiniva");
	q.setFrom("em_articuloscli artcli LEFT OUTER JOIN em_articulosclihis his ON artcli.id=his.idarticuloscli");
	q.setWhere("artcli.codcliente='" + codCliente + "' and artcli.referencia='" + referencia + "' and his.fechavalidez >= '" + fecha + "' order by his.fechavalidez asc limit 1");	
	debug("**********************: "+q.sql());
	if (!q.exec()){
		return ;
	}  
	if (q.first())
	{
	     pvpSinIva = q.value("his.pvpsiniva");	
	}
	
	var porcReparto = AQUtil.sqlSelect("em_porcrepardepcli", "porcdeposito", "codcliente='" + codCliente + "'");
	
	if(pvpSinIva && pvpSinIva != "" and porcReparto and porcReparto !="") {
		valor = (parseFloat(pvpSinIva) * parseFloat(porcReparto))/100;
	}

	valor = AQUtil.roundFieldValue(valor, "lineaspedidoscli", "pvpsindto");
	return valor;

}*/
function oficial_damePVPNoctalia(codCliente, referencia, fecha)
{
	var valor =0;	
	
	var q = new AQSqlQuery;	
	q.setSelect("his.pvpeuromoda");
	q.setFrom("em_articuloscli artcli LEFT OUTER JOIN em_articulosclihis his ON artcli.id=his.idarticuloscli");
	q.setWhere("artcli.codcliente='" + codCliente + "' and artcli.referencia='" + referencia + "' and his.fechavalidez >= '" + fecha + "' order by his.fechavalidez asc limit 1");	
	debug("**********************: "+q.sql());
	if (!q.exec()){
		return ;
	}  
	if (q.first())
	{
	     valor = q.value("his.pvpeuromoda");	
	}	
	valor = parseFloat(valor);
	valor = AQUtil.roundFieldValue(valor, "lineaspedidoscli", "pvpsindto");
	return valor;

}
function oficial_habilitaImportado()
{
	var _i = this.iface;
	
	if(_i.importado_) {	
		this.child("tbnBuscarFichero").setEnabled(false);
		this.child("tbnCargarLineas").setEnabled(false);
		this.child("tbnGenerarPedidos").setEnabled(false);
		sys.setObjText(this, "lblImportado", "Pedidos importados");
	} else {
		this.child("tbnBuscarFichero").setEnabled(true);
		this.child("tbnCargarLineas").setEnabled(true);
		this.child("tbnGenerarPedidos").setEnabled(true);
		sys.setObjText(this, "lblImportado", "");
	}
}
function oficial_estaImportado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idImportacion = cursor.valueBuffer("idimportacion");
	var numPedidos = AQUtil.sqlSelect("pedidoscli", "count(*)", "em_idimpnoctalia=" + idImportacion );	
	if(numPedidos && numPedidos !=0) {
		_i.importado_ = true;
	}else {
		_i.importado_ = false;	
	}

}
/*function oficial_habilitaImportado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var importadoPed = cursor.valueBuffer("importadoped");
	if(importadoPed) {
		this.child("tbnBuscarFichero").setEnabled(false);
		this.child("tbnCargarLineas").setEnabled(false);
		this.child("tbnGenerarPedidos").setEnabled(false);
	} else {
		this.child("tbnBuscarFichero").setEnabled(true);
		this.child("tbnCargarLineas").setEnabled(true);
		this.child("tbnGenerarPedidos").setEnabled(true);

	}
}*/
/*function oficial_bufferChanged(fN) 
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "importadoped": {
			_i.habilitaImportado();
      break;
    }

	}
}*/
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
