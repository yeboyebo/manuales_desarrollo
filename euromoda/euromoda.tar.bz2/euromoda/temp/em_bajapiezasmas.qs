/**************************************************************************
                 em_lineasbajapiezasmasqs.qs  -  description
                             -------------------
    begin                : mie jun 24 2015
    copyright            : (C) 2015 by YeboYebo S.L.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblLineas_;	
	var cNoSel_, cSel_, colVerde_, colRojo_, colBlanco_; 	
	var cLIN_,cREF_,cDES_,cPIE_,cCPE_,cMUS_,cMEP_,cSFA_,cADC_,cAAM_,cFEP_,cTDC_,cALM_,cEST_,cIDST_;
	var modo_;
   function oficial( context ) { interna( context ); }
	function pbnDescontarTodo_clicked() {
		return this.ctx.oficial_pbnDescontarTodo_clicked();
	}
	function pbnLimpiar_clicked() {
		return this.ctx.oficial_pbnLimpiar_clicked();
	}	
	function tbnBuscar_clicked() {
		return this.ctx.oficial_tbnBuscar_clicked();
	}	
	function iniciaTabla() {
		return this.ctx.oficial_iniciaTabla();
	}
	function tblLineas_clicked(f, c) {
		return this.ctx.oficial_tblLineas_clicked(f, c);
	}
	function colores() {
		return this.ctx.oficial_colores();
	}
	function trBajaPiezas(oParam) {
		return this.ctx.oficial_trBajaPiezas(oParam);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}	
  	function tblLineas_valueChanged(f, c)  {
 	   return this.ctx.oficial_tblLineas_valueChanged(f, c);
  	}
	function calculaFinalPieza(f,limpiando) {
		return this.ctx.oficial_calculaFinalPieza(f,limpiando);
	}
	function colSFAClicked(f) {
		return this.ctx.oficial_colSFAClicked(f);
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function crearLineasOrden(oParam) {
		return this.ctx.oficial_crearLineasOrden(oParam);
	}
	function insertaLinea(f) {
		return this.ctx.oficial_insertaLinea(f);
	}
	function habilitaCodigos() {
		return this.ctx.oficial_habilitaCodigos();
	}
	function cargaDatosLineas(idBaja, tipoDoc) {
		return this.ctx.oficial_cargaDatosLineas(idBaja, tipoDoc);
	}
	function habilitaCampos() {
		return this.ctx.oficial_habilitaCampos();
	}
	function rellenaComboAlm() {
		return this.ctx.oficial_rellenaComboAlm();
	}
	function cargaDatosCabecera() {
		return this.ctx.oficial_cargaDatosCabecera();
	}
	function compruebaBobina(codBobina) {
		return this.ctx.oficial_compruebaBobina(codBobina);
	}
	function compruebaStockPieza(fila) {
		return this.ctx.oficial_compruebaStockPieza(fila);
	}
	function pintaColorEstado() {
		return this.ctx.oficial_pintaColorEstado();
	}
	function coloreaFila(f) {
		return this.ctx.oficial_coloreaFila(f);
	}
	function cbAlmacen_activated() {
		return this.ctx.oficial_cbAlmacen_activated();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
 
function interna_init()
{
	var _i = this.iface;

	var cursor = this.cursor();
	_i.colores();	
	_i.tblLineas_ = this.child("tblLineas");	
	_i.iniciaTabla();	
	_i.rellenaComboAlm();
	
	connect(_i.tblLineas_, "doubleClicked(int, int)", _i, "tblLineas_clicked");		
	connect(this.child("pbnDescontarTodo"), "clicked()", _i, "pbnDescontarTodo_clicked");
	connect(this.child("pbnLimpiar"), "clicked()", _i, "pbnLimpiar_clicked");	
	connect(this.child("tbnBuscar"), "clicked()", _i, "tbnBuscar_clicked");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(_i.tblLineas_, "valueChanged(int, int)", _i, "tblLineas_valueChanged");
	connect(this.child("cbAlmacen"), "activated(QString)", _i, "cbAlmacen_activated");
	
	var idBaja = cursor.valueBuffer("idbaja");

	var codOrden = cursor.valueBuffer("codordenest");
	var tipoDoc = "";
	if(codOrden && codOrden != "") {
		tipoDoc = "OE";
	}
	 
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			_i.modo_ = "INSERTANDO";		
			disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
			connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
			cursor.setValueBuffer("idusuario",sys.nameUser());	
			this.child("cbAlmacen").currentText = "1";
			break;
		}
		case cursor.Browse:{
			_i.modo_ = "MOSTRANDO";
			_i.cargaDatosCabecera();
			_i.cargaDatosLineas(idBaja, tipoDoc);
			break;
		}
		case cursor.Edit: {
			_i.modo_ = "EDITANDO";
			disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
			connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
			_i.cargaDatosCabecera();
			_i.cargaDatosLineas(idBaja, tipoDoc);
			break;
		}
	} 

	_i.habilitaCodigos();
	_i.habilitaCampos();
	//**************   #H1400 ********************** 
	_i.pintaColorEstado();	
	//**************   #H1400 **********************
	
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_rellenaComboAlm()
{
	var aAlmacenes = [];
	aAlmacenes.push("TODOS");
	aAlmacenes.push("1");
	
	var q = new AQSqlQuery;	
	q.setSelect("distinct(codalmacen)");
	q.setFrom("em_incidensaldos");
	q.setWhere("codalmacen <> '1'"); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		aAlmacenes.push(q.value("distinct(codalmacen)"));	
	}	
	
	this.child("cbAlmacen").clear();
	this.child("cbAlmacen").insertStringList(aAlmacenes);


}

function oficial_iniciaTabla()
{
	var _i = this.iface;

	
	var c = 0, cH = [];

	
	_i.cREF_ = c++;
	_i.cDES_ = c++;
	_i.cPIE_ = c++;
	_i.cCPE_ = c++;
	_i.cMUS_ = c++;
	_i.cMEP_ = c++;
	_i.cSFA_ = c++;
	_i.cADC_ = c++;
	_i.cAAM_ = c++;
	_i.cFEP_ = c++;
	_i.cTDC_ = c++;  
   _i.cALM_ = c++;
   	_i.cEST_ = c++;//#H1400 
   	_i.cIDST_= c++;//#H1400 
   	_i.cLIN_ = c++;
  
	cH[_i.cLIN_] = AQUtil.translate("scripts", "L�nea");
	cH[_i.cREF_] = AQUtil.translate("scripts", "Referencia");
	cH[_i.cDES_] = AQUtil.translate("scripts", "Descripci�n");
	cH[_i.cPIE_] = AQUtil.translate("scripts", "Pieza");
	cH[_i.cCPE_] = AQUtil.translate("scripts", "Cant.Pedida");
	cH[_i.cMUS_] = AQUtil.translate("scripts", "Metros usados");
	cH[_i.cMEP_] = AQUtil.translate("scripts", "Metros en pieza");
	cH[_i.cSFA_] = AQUtil.translate("scripts", "Stock f�sico actual");
	cH[_i.cADC_] = AQUtil.translate("scripts", "A descontar");
	cH[_i.cAAM_] = AQUtil.translate("scripts", "A aumentar");
	cH[_i.cFEP_] = AQUtil.translate("scripts", "Final en pieza");
	cH[_i.cTDC_] = AQUtil.translate("scripts", "Tipo doc"); //OE PC
	cH[_i.cALM_] = AQUtil.translate("scripts", "Almac�n");
	cH[_i.cEST_] = AQUtil.translate("scripts", "Estado");// #H1400
	cH[_i.cIDST_] = AQUtil.translate("scripts", "Idstock");// #H1400

	
  	_i.tblLineas_.setNumCols(c);  

	_i.tblLineas_.setColumnWidth(_i.cLIN_, 180);
	_i.tblLineas_.setColumnWidth(_i.cREF_, 80);
  	_i.tblLineas_.setColumnWidth(_i.cDES_, 450);
  	_i.tblLineas_.setColumnWidth(_i.cPIE_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cCPE_, 80);
  	_i.tblLineas_.setColumnWidth(_i.cMUS_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cMEP_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cSFA_, 120);
  	_i.tblLineas_.setColumnWidth(_i.cADC_, 80);
  	_i.tblLineas_.setColumnWidth(_i.cAAM_, 80);
  	_i.tblLineas_.setColumnWidth(_i.cFEP_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cTDC_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cALM_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cEST_, 100);// #H1400 
  	_i.tblLineas_.setColumnWidth(_i.cIDST_, 100);// #H1400 

  	
  	_i.tblLineas_.setColumnReadOnly(_i.cLIN_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cREF_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cDES_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cPIE_, true);  
  	_i.tblLineas_.setColumnReadOnly(_i.cCPE_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cMUS_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cMEP_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cSFA_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cFEP_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cTDC_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cALM_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cEST_, true); //#H1400
  	_i.tblLineas_.setColumnReadOnly(_i.cIDST_, true); //#H1400
  	
  	//_i.tblLineas_.hideColumn(_i.cIDST_);


 	_i.tblLineas_.setColumnLabels("*", cH.join("*"));




}

function oficial_tbnBuscar_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.tblLineas_.setNumRows(0);
	
	var where = "";
	var codAlmacen = this.child("cbAlmacen").currentText;
	if(codAlmacen != "TODOS") {
		where ="st.codalmacen = '" + codAlmacen + "' ";
	}

	var codPedido = cursor.valueBuffer("codpedidoprov");
	if(codPedido && codPedido != "") {
		where += where == "" ? "" : " AND ";		
		where += "p.codigo = '"+ codPedido + "'";
		
		var f =0;
		var q = new AQSqlQuery;
		var metrosAcu = 0;
		q.setSelect("lp.idlinea,lp.referencia,lp.descripcion,ms.codlote,SUM(ms.cantidad),ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock");
		q.setFrom("pedidosprov p inner join lineaspedidosprov lp on p.idpedido = lp.idpedido inner join lineasalbaranesprov la on lp.idlinea = la.idlineapedido inner join movistock ms on la.idlinea = ms.idlineaap inner join lotesstock ls on ms.codlote=ls.codlote  inner join stocks st on st.idstock=ms.idstock ");		
		q.setWhere(where +" GROUP BY lp.idlinea,lp.referencia,lp.descripcion,ms.codlote,ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock order by lp.idlinea,lp.referencia,ms.codlote");			
		debug("consulta: "+q.sql());
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			_i.tblLineas_.insertRows(f);
			var cantidad = parseFloat(q.value("SUM(ms.cantidad)"));		   
		   var canUsada = parseFloat(q.value("ls.canusada"));		   
		   var canDisponible = parseFloat(q.value("ls.candisponible"));		  	
		 	var stockFisico = parseFloat(q.value("st.cantidad"));		  			  	
		  	var codAlmacen = q.value("st.codalmacen");
		   
		   cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad"); 		   
		   canUsada = AQUtil.roundFieldValue(canUsada, "lotesstock", "canusada");
		   canDisponible = AQUtil.roundFieldValue(canDisponible, "lotesstock", "candisponible");		 
		   stockFisico = AQUtil.roundFieldValue(stockFisico, "stocks", "cantidad");
		   
		   _i.tblLineas_.setText(f, _i.cLIN_, q.value("lp.idlinea"));
		   _i.tblLineas_.setText(f, _i.cREF_, q.value("lp.referencia"));
		   _i.tblLineas_.setText(f, _i.cDES_, q.value("lp.descripcion"));
		   _i.tblLineas_.setText(f, _i.cPIE_, q.value("ms.codlote"));
		   _i.tblLineas_.setText(f, _i.cCPE_, cantidad);
		   _i.tblLineas_.setText(f, _i.cMUS_, canUsada);
		   _i.tblLineas_.setText(f, _i.cMEP_, canDisponible);
		   _i.tblLineas_.setText(f, _i.cSFA_, stockFisico);
		   _i.tblLineas_.setText(f, _i.cADC_, 0);      
		   _i.tblLineas_.setText(f, _i.cAAM_, 0);
		   _i.tblLineas_.setText(f, _i.cFEP_, canDisponible);  
		   _i.tblLineas_.setText(f, _i.cTDC_, "PC");
			_i.tblLineas_.setText(f, _i.cALM_, codAlmacen);
			_i.tblLineas_.setText(f, _i.cEST_, "PTE"); // #H1400
			_i.tblLineas_.setText(f, _i.cIDST_, q.value("st.idstock")); // #H1400

			f++;
		}	
	
	
	}
	
	
	var codOrden = cursor.valueBuffer("codordenest");
	
	if(codOrden && codOrden != "") {
		var f =0;
		var q = new AQSqlQuery;
		var metrosAcu = 0;
		where += where == "" ? "" : " AND ";		
		where += "lo.codordenest = '"+ codOrden + "'";
		
		//q.setSelect("lo.idlinea,lo.referencia,lo.tejido,ms.codlote,SUM(ms.cantidad),ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock");
		q.setSelect("array_to_string(array_agg(lo.idlinea),',') as lineas,lo.referencia,lo.tejido,ms.codlote,SUM(ms.cantidad),ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock");
		q.setFrom("em_lineasordenest lo inner join movistock ms on ms.emidlineaest = lo.idlinea inner join lotesstock ls on ms.codlote=ls.codlote inner join stocks st on st.idstock=ms.idstock");		
		q.setWhere(where + " GROUP BY lo.referencia,lo.tejido,ms.codlote,ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock order by lo.referencia,ms.codlote");	
		debug("consulta: "+q.sql());		
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			_i.tblLineas_.insertRows(f);
			//_i.tblLineas_.setCellBackgroundColor(f, _i.cFEP_, _i.cNoSel_);
			var cantidad = parseFloat(q.value(4));		      
		   var canUsada = parseFloat(q.value(5));
		  	var canDisponible = parseFloat(q.value(6));		  	
			var stockFisico = parseFloat(q.value(7));	
			var codAlmacen = q.value(8);
		   		
		   cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");
		   canUsada = AQUtil.roundFieldValue(canUsada, "lotesstock", "canusada");
		  	canDisponible = AQUtil.roundFieldValue(canDisponible, "lotesstock", "candisponible");		 
			stockFisico = AQUtil.roundFieldValue(stockFisico, "stocks", "cantidad");	   


		   _i.tblLineas_.setText(f, _i.cLIN_, q.value(0));
		   _i.tblLineas_.setText(f, _i.cREF_, q.value(1));
		   _i.tblLineas_.setText(f, _i.cDES_, q.value(2));
		   _i.tblLineas_.setText(f, _i.cPIE_, q.value(3));
			_i.tblLineas_.setText(f, _i.cCPE_, cantidad);
			_i.tblLineas_.setText(f, _i.cMUS_, canUsada);
			_i.tblLineas_.setText(f, _i.cMEP_, canDisponible);
			_i.tblLineas_.setText(f, _i.cSFA_, stockFisico);
			_i.tblLineas_.setText(f, _i.cADC_, 0);      
			_i.tblLineas_.setText(f, _i.cAAM_, 0);
			
			_i.tblLineas_.setText(f, _i.cFEP_, canDisponible);  
			_i.tblLineas_.setText(f, _i.cTDC_, "OE");
			_i.tblLineas_.setText(f, _i.cALM_, codAlmacen);
			_i.tblLineas_.setText(f, _i.cEST_, "PTE"); // #H1400
			_i.tblLineas_.setText(f, _i.cIDST_, q.value(9)); // #H1400
			f++;
		}	
	}
//**************   #H1400 **********************
	var codBobina = cursor.valueBuffer("codbobina");
	if(codBobina && codBobina != "") {
		if(!_i.compruebaBobina(codBobina)) {
			//mostrar mensaje diciendo que la bobina no es de rollado
			return false;
		}
		var f =0;
		var q = new AQSqlQuery;
		var metrosAcu = 0;
		where += where == "" ? "" : " AND ";		
		where += "tt.codbobinapiezaroll = '"+ codBobina + "'";

		q.setSelect("MIN(tt.caninicio),lo.idlinea,lo.referencia,lo.tejido,ms.codlote,SUM(ms.cantidad),ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock");
		q.setFrom("em_lineasordenest lo inner join movistock ms on ms.emidlineaest = lo.idlinea inner join lotesstock ls on ms.codlote=ls.codlote inner join stocks st on st.idstock=ms.idstock inner join em_tramostejido tt on tt.codpartida =ls.codlote");		
		q.setWhere(where + " GROUP BY lo.idlinea,lo.referencia,lo.tejido,ms.codlote,ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock order by MIN(tt.caninicio),lo.idlinea,lo.referencia,ms.codlote");	
		debug("consulta: "+q.sql());		
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			_i.tblLineas_.insertRows(f);
			//_i.tblLineas_.setCellBackgroundColor(f, _i.cFEP_, _i.cNoSel_);
			var cantidad = parseFloat(q.value("SUM(ms.cantidad)"));		      
			var canUsada = parseFloat(q.value("ls.canusada"));
			var canDisponible = parseFloat(q.value("ls.candisponible"));		  	
			var stockFisico = parseFloat(q.value("st.cantidad"));	
			var codAlmacen = q.value("st.codalmacen");

			cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");
			canUsada = AQUtil.roundFieldValue(canUsada, "lotesstock", "canusada");
			canDisponible = AQUtil.roundFieldValue(canDisponible, "lotesstock", "candisponible");		 
			stockFisico = AQUtil.roundFieldValue(stockFisico, "stocks", "cantidad");

			_i.tblLineas_.setText(f, _i.cLIN_, q.value("lo.idlinea"));
			_i.tblLineas_.setText(f, _i.cREF_, q.value("lo.referencia"));
			_i.tblLineas_.setText(f, _i.cDES_, q.value("lo.tejido"));
			_i.tblLineas_.setText(f, _i.cPIE_, q.value("ms.codlote"));
			_i.tblLineas_.setText(f, _i.cCPE_, cantidad);
			_i.tblLineas_.setText(f, _i.cMUS_, canUsada);
			_i.tblLineas_.setText(f, _i.cMEP_, canDisponible);
			_i.tblLineas_.setText(f, _i.cSFA_, stockFisico);
			_i.tblLineas_.setText(f, _i.cADC_, 0);      
			_i.tblLineas_.setText(f, _i.cAAM_, 0);

			_i.tblLineas_.setText(f, _i.cFEP_, canDisponible);  
			_i.tblLineas_.setText(f, _i.cTDC_, "OE");
			_i.tblLineas_.setText(f, _i.cALM_, codAlmacen);
			_i.tblLineas_.setText(f, _i.cEST_, "PTE");
			_i.tblLineas_.setText(f, _i.cIDST_, q.value("st.idstock")); // #H1400
			f++;
		}	
	}
	//**************   #H1400 **********************
	//**************   #H1775 **********************
	var soloAlmacen = cursor.valueBuffer("soloporalmacen");
	var soloDisponible = cursor.valueBuffer("solocondisponible");
  	var famPartidas = flfactalma.iface.pub_dameFamEstampado();
  	var subfamPartidas = flfactalma.iface.pub_dameSubfamEstampado();

	if(soloAlmacen) {

		if(soloDisponible) {
			var res = formUI.preguntaMsg(sys.translate("OJO: va a buscar TODAS las piezas del almac�n %1 CON DISPONIBLE �Est� seguro?").arg(codAlmacen), "info", this, MessageBox.Yes, MessageBox.No);
   			if(res != MessageBox.Yes) {
   				return false;
			}
			where += where == "" ? "" : " AND ";		
			where += "ls.candisponible > 0";			
		} else {
			var res = formUI.preguntaMsg(sys.translate("OJO: va a buscar TODAS las piezas del almac�n %1 �Est� seguro?").arg(codAlmacen), "info", this, MessageBox.Yes, MessageBox.No);
   			if(res != MessageBox.Yes) {
   				return false;
			}	
		}
		

		var f =0;
		var p=0;
		var q = new AQSqlQuery;
		q.setSelect("st.referencia,st.articulo,ms.codlote,SUM(ms.cantidad),ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock");
		q.setFrom("movistock ms INNER JOIN lotesstock ls ON ms.codlote=ls.codlote INNER JOIN stocks st ON st.idstock=ms.idstock INNER JOIN articulos a ON a.referencia = st.referencia ");		
		q.setWhere(where + " AND (a.codfamilia IN (" + famPartidas + ") OR a.codsubfamilia IN (" + subfamPartidas + ")) GROUP BY st.referencia,st.articulo,ms.codlote,ls.canusada,ls.candisponible,st.cantidad,st.codalmacen,st.idstock");	
		debug("consulta: "+q.sql());		
		if (!q.exec()){
			return;
		}
		//flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando l�neas"), q.size());  
		var oParam = new Object;
		oParam.caption = "Cargando datos";
		formUI.creaDialogoEstado(oParam);	
		formUI.ponLogDialogo("Cargando datos lineas");
		while(q.next())
		{
			_i.tblLineas_.insertRows(f);
			formUI.ponLogDialogo("Datos lote: "+q.value("ms.codlote"));
			//AQUtil.setProgress(p++);
			//_i.tblLineas_.setCellBackgroundColor(f, _i.cFEP_, _i.cNoSel_);
			var cantidad = parseFloat(q.value("SUM(ms.cantidad)"));		      
			var canUsada = parseFloat(q.value("ls.canusada"));
			var canDisponible = parseFloat(q.value("ls.candisponible"));		  	
			var stockFisico = parseFloat(q.value("st.cantidad"));	
			var codAlmacen = q.value("st.codalmacen");

			cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");
			canUsada = AQUtil.roundFieldValue(canUsada, "lotesstock", "canusada");
			canDisponible = AQUtil.roundFieldValue(canDisponible, "lotesstock", "candisponible");		 
			stockFisico = AQUtil.roundFieldValue(stockFisico, "stocks", "cantidad");

			_i.tblLineas_.setText(f, _i.cLIN_, f+1);
			_i.tblLineas_.setText(f, _i.cREF_, q.value("st.referencia"));
			_i.tblLineas_.setText(f, _i.cDES_, q.value("st.articulo"));
			_i.tblLineas_.setText(f, _i.cPIE_, q.value("ms.codlote"));
			_i.tblLineas_.setText(f, _i.cCPE_, cantidad);
			_i.tblLineas_.setText(f, _i.cMUS_, canUsada);
			_i.tblLineas_.setText(f, _i.cMEP_, canDisponible);
			_i.tblLineas_.setText(f, _i.cSFA_, stockFisico);
			_i.tblLineas_.setText(f, _i.cADC_, 0);      
			_i.tblLineas_.setText(f, _i.cAAM_, 0);

			_i.tblLineas_.setText(f, _i.cFEP_, canDisponible);  
			_i.tblLineas_.setText(f, _i.cTDC_, "ALM");
			_i.tblLineas_.setText(f, _i.cALM_, codAlmacen);
			_i.tblLineas_.setText(f, _i.cEST_, "PTE");
			_i.tblLineas_.setText(f, _i.cIDST_, q.value("st.idstock")); // #H1400
			f++;
		}
		//AQUtil.destroyProgressDialog();	
		formUI.destruyeDialogoEstado();

	}
	//**************   #H1775 **********************

}


function oficial_tblLineas_clicked(f, c)
{
	
	var _i = this.iface;
	if(_i.modo_ == "INSERTANDO") {

	  	switch (c) {
	  		case _i.cFEP_: {
	  			_i.tblLineas_.setRowReadOnly(f, true);
	  			_i.colSFAClicked(f);  	
	  			_i.tblLineas_.setRowReadOnly(f, false);			
				  		
		  		break;
	 		}
		}
	}else {
		_i.tblLineas_.setRowReadOnly(f, true);	
	}
}
function oficial_colores()
{
	var _i = this.iface;

	_i.cNoSel_ = new Color("grey");
	_i.cSel_ = new Color("green");
	//**************   #H1400 **********************
	_i.colVerde_ = new Color(flfactppal.iface.pub_dameColor("fondo_verde"));
	_i.colRojo_ = new Color(flfactppal.iface.pub_dameColor("fondo_rojo"));
	_i.colBlanco_ = new Color(flfactppal.iface.pub_dameColor("fondo_blanco"));
	//**************   #H1400 **********************
 
}

function oficial_bufferChanged(fN)
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "codordenest": 
		case "codpedidoprov": 
		case "codbobina": 
		case "soloporalmacen": 
		case "solocondisponible": {
			_i.habilitaCodigos();
			break;
		}    
			
		default: {
		}
	}
}

function oficial_habilitaCodigos()
{
	var cursor = this.cursor();
	var codOrden = cursor.valueBuffer("codordenest");
	var codPedido = cursor.valueBuffer("codpedidoprov");
	var codBobina = cursor.valueBuffer("codbobina");// #H1400 
	var soloAlmacen = cursor.valueBuffer("soloporalmacen"); 
	var soloDisponible = cursor.valueBuffer("solocondisponible"); 
	var codAlmacen = this.child("cbAlmacen").currentText;
	if(codAlmacen == "TODOS") {
		sys.disableObj(this, "fdbSoloPorAlmacen");	
		this.child("fdbSoloPorAlmacen").setValue(false);
		this.child("fdbSoloConDisponible").setValue(false);
		sys.disableObj(this, "fdbSoloConDisponible");
	}
	if(codOrden && codOrden != "") {
		sys.disableObj(this, "fdbCodPedidoProv");
		sys.disableObj(this, "fdbCodBobina");//#H1400
		sys.disableObj(this, "fdbSoloPorAlmacen");
		return;
	} else {
		sys.enableObj(this, "fdbCodPedidoProv");
		sys.enableObj(this, "fdbCodBobina");//#H1400
		if(codAlmacen != "TODOS") {
			sys.enableObj(this, "fdbSoloPorAlmacen");		
		}		
	}
	
	if(codPedido && codPedido != "") {
		sys.disableObj(this, "fdbCodOrden");
		sys.disableObj(this, "fdbCodBobina");// #H1400 
		sys.disableObj(this, "fdbSoloPorAlmacen");
		return;
	} else {
		sys.enableObj(this, "fdbCodOrden");
		sys.enableObj(this, "fdbCodBobina");//#H1400 
		if(codAlmacen != "TODOS") {
			sys.enableObj(this, "fdbSoloPorAlmacen");		
		}
	}
	//**************   #H1400 **********************
	if(codBobina && codBobina != "") {
		sys.disableObj(this, "fdbCodPedidoProv");
		sys.disableObj(this, "fdbCodOrden");
		sys.disableObj(this, "fdbSoloPorAlmacen");
		return;
	} else {
		sys.enableObj(this, "fdbCodPedidoProv");
		sys.enableObj(this, "fdbCodOrden");
		if(codAlmacen != "TODOS") {
			sys.enableObj(this, "fdbSoloPorAlmacen");		
		}
	}
	//**************   #H1400 **********************
	soloAlmacen = cursor.valueBuffer("soloporalmacen"); 
	if(soloAlmacen) {
		sys.enableObj(this, "fdbSoloConDisponible");
		sys.disableObj(this, "fdbCodPedidoProv");
		sys.disableObj(this, "fdbCodBobina");
		sys.disableObj(this, "fdbCodOrden");
	} else {
		this.child("fdbSoloConDisponible").setValue(false);
		sys.disableObj(this, "fdbSoloConDisponible");
		sys.enableObj(this, "fdbCodPedidoProv");
		sys.enableObj(this, "fdbCodBobina");
		sys.enableObj(this, "fdbCodOrden");
	}
}

function oficial_pbnDescontarTodo_clicked()
{
	var _i = this.iface;
		 
  	var nF = _i.tblLineas_.numRows();  	
    	for (var f = 0; f < nF; f++) {  
		_i.colSFAClicked(f);    	
  	}  

}

function oficial_tblLineas_valueChanged(f, c)
{
  var _i = this.iface;
  switch (c) {
    case _i.cADC_: {
      _i.calculaFinalPieza(f);
      break;
    }
    case _i.cAAM_: {
    	
      _i.calculaFinalPieza(f);
     
      break;
    }
  }
}

function oficial_calculaFinalPieza(f,limpiando)
{
	
	var _i = this.iface;
	var metrosEnPieza = parseFloat(_i.tblLineas_.text(f, _i.cMEP_));
	metrosEnPieza = isNaN(metrosEnPieza) ? 0 : metrosEnPieza;
	
	var aAumentar = parseFloat(_i.tblLineas_.text(f, _i.cAAM_));
	aAumentar = isNaN(aAumentar) ? 0 : aAumentar;
	
	var aDescontar =parseFloat(_i.tblLineas_.text(f, _i.cADC_))
	aDescontar = isNaN(aDescontar) ? 0 : aDescontar;

	var diferencia = aDescontar - aAumentar;

	if(!diferencia || diferencia == 0) {
		_i.tblLineas_.setText(f, _i.cEST_, "PTE");
	}	

	//**************   #H1400 **********************
	var estado = _i.tblLineas_.text(f, _i.cEST_);
	if(estado != "PTE") {
		return true;
	}
	if(!_i.compruebaStockPieza(f)) {
		_i.tblLineas_.setText(f, _i.cEST_, "NO POSIBLE");
		_i.coloreaFila(f);
		return true;
	}

	//**************   #H1400 **********************


		
	var finalPieza = metrosEnPieza + aAumentar - aDescontar;

	debug("antes de ponerlo a hecho");
	if(!limpiando && diferencia && diferencia != 0) {		
		_i.tblLineas_.setText(f, _i.cEST_, "HECHO");	
	} else {
		_i.tblLineas_.setText(f, _i.cEST_, "PTE");
	}

	finalPieza = AQUtil.roundFieldValue(finalPieza, "movistock", "cantidad"); 
	
	_i.tblLineas_.setText(f, _i.cFEP_, finalPieza);
	_i.coloreaFila(f);

}

function oficial_pbnLimpiar_clicked()
{
	var _i = this.iface;
		 
  	var nF = _i.tblLineas_.numRows();  	
  
  	for (var f = 0; f < nF; f++) {    		
		_i.tblLineas_.setText(f, _i.cAAM_, 0);
		_i.tblLineas_.setText(f, _i.cADC_, 0);		
		_i.tblLineas_.setText(f, _i.cEST_, "PTE"); // #H1400
		_i.coloreaFila(f);
		_i.calculaFinalPieza(f, true);    	
  	}  
}

function oficial_colSFAClicked(f)
{

	var _i = this.iface;
	var metrosEnPieza = parseFloat(_i.tblLineas_.text(f, _i.cMEP_));
	metrosEnPieza = isNaN(metrosEnPieza) ? 0 : metrosEnPieza;
	var aDescontar = metrosEnPieza;
	aDescontar = AQUtil.roundFieldValue(aDescontar, "movistock", "cantidad"); 
	_i.tblLineas_.setText(f, _i.cAAM_, 0);
	_i.tblLineas_.setText(f, _i.cADC_, aDescontar);
	_i.calculaFinalPieza(f);
	

}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var res;
	var cursor = this.cursor();
	if(_i.modo_ =="INSERTANDO") {
		_i.modo_ = ""; //pineboo 21-08-2019
		cursor.setValueBuffer("codalmacen",this.child("cbAlmacen").currentText);
		this.cursor().commitBuffer();
	  	var oParam = new Object;
	  	oParam.noPosible = false;
	  	oParam.errorMsg = sys.translate("Error al de bajar las piezas");
	  	f = new Function("oParam", "return formRecordem_bajapiezasmas.iface.crearLineasOrden(oParam)");
	  	if (!sys.runTransaction(f, oParam)) {
		 	return false;
	  	}
	  	if(oParam.noPosible) {
	  		res = MessageBox.information(sys.translate("Algunas piezas no se han dado de baja."), MessageBox.Ok, MessageBox.Cancel, MessageBox.NoButton);
	  	} else {
	  		res = MessageBox.information(sys.translate("Las piezas han sido dadas de baja correctamente"), MessageBox.Ok, MessageBox.Cancel, MessageBox.NoButton);
	  	}	  	
	  	if (res != MessageBox.Ok) {
		 	return false;
	  	}
	}  

  this.accept();
}

function oficial_crearLineasOrden(oParam)
{
	
	var _i = this.iface;
	var nF = _i.tblLineas_.numRows();
	var cursor = this.cursor();
	var idBaja = cursor.valueBuffer("idbaja");
	
	if (!AQUtil.sqlDelete("em_lineasbajapiezasmas", "idbaja = " + idBaja)) {	
		oParam.errorMsg += "\nError vaciando tabla";
		return false;
	}
	for (var f = 0; f < nF; f++) {   
		if(!_i.compruebaStockPieza(f)) {
			oParam.noPosible = true;		
		}
	} 	
	if(oParam.noPosible) {
		flfactppal.iface.ponMsgError(sys.translate("No se pudo modificar las marcadas en rojo (han cambiado de valor mientras tenia abierta la pantalla).\nRealice otra baja masiva adicional si lo cree necesario"),"info",this);
	}		
	for (var f = 0; f < nF; f++) { 
		if(!_i.insertaLinea(f)) {
		    return false;			      		
		}		
	}

	return true;
}

function oficial_insertaLinea(f)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idBaja = cursor.valueBuffer("idbaja");
	var tipoDoc = _i.tblLineas_.text(f,_i.cTDC_);
	var idLineaDoc = _i.tblLineas_.text(f,_i.cLIN_);
	var referencia = _i.tblLineas_.text(f,_i.cREF_);
	var descripcion = _i.tblLineas_.text(f,_i.cDES_);
	var codPieza = _i.tblLineas_.text(f,_i.cPIE_);
	var canPedida = _i.tblLineas_.text(f,_i.cCPE_);
	var canUsada = _i.tblLineas_.text(f,_i.cMUS_);
	var canDisponible = _i.tblLineas_.text(f,_i.cMEP_);
	var canStock = _i.tblLineas_.text(f,_i.cSFA_);
	var canaDescontar = _i.tblLineas_.text(f,_i.cADC_);
	var canAumentar = _i.tblLineas_.text(f,_i.cAAM_);
	var canFinal = _i.tblLineas_.text(f,_i.cFEP_);		
	var codAlmacen = _i.tblLineas_.text(f,_i.cALM_);
	var estado = _i.tblLineas_.text(f,_i.cEST_); //#H1400
	var idstock = _i.tblLineas_.text(f,_i.cIDST_); //#H1400
	
	var curLinBaja = new FLSqlCursor("em_lineasbajapiezasmas");
	curLinBaja.setModeAccess(curLinBaja.Insert);
  	curLinBaja.refreshBuffer(); 
  	curLinBaja.setValueBuffer("idbaja",idBaja);
  	curLinBaja.setValueBuffer("tipodoc",tipoDoc);
  	curLinBaja.setValueBuffer("idlineadoc",idLineaDoc);
  	curLinBaja.setValueBuffer("referencia",referencia);
  	curLinBaja.setValueBuffer("descripcion",descripcion);
  	curLinBaja.setValueBuffer("codpieza",codPieza);
  	curLinBaja.setValueBuffer("canpedida",canPedida);
  	curLinBaja.setValueBuffer("canusada",canUsada);
  	curLinBaja.setValueBuffer("candisponible",canDisponible);
  	curLinBaja.setValueBuffer("canstock",canStock);
  	curLinBaja.setValueBuffer("canadescontar",canaDescontar);
  	curLinBaja.setValueBuffer("canaumentar",canAumentar);
  	curLinBaja.setValueBuffer("canfinal",canFinal);  
  	curLinBaja.setValueBuffer("codalmacen",codAlmacen);
  	curLinBaja.setValueBuffer("estado",estado);  //#H1400 
  	curLinBaja.setValueBuffer("idstock",idstock);  //#H1400
  	if (!curLinBaja.commitBuffer()) {
      return false;
    }
	return true;

}

function oficial_cargaDatosCabecera()
{
	var cursor = this.cursor()
	var codAlmacen = cursor.valueBuffer("codalmacen");
	this.child("cbAlmacen").currentText = codAlmacen;	
	//this.child("cbAlmacen").setEnabled(false);
	
}

function oficial_cargaDatosLineas(idBaja, tipoDoc)
{
	var _i = this.iface;	
	var f =0;
	_i.tblLineas_.setNumRows(0);
	var q = new AQSqlQuery;	
	q.setSelect("tipodoc,idlineadoc,referencia,descripcion,codpieza,canpedida,canusada,candisponible,canstock,canadescontar,canaumentar,canfinal,codalmacen,estado,idstock");
	q.setFrom("em_lineasbajapiezasmas");
	var where = "idbaja = " + idBaja; 
	if(tipoDoc == "OE") {
		where += " ORDER BY referencia,codpieza ";
	} else {
		where += " ORDER BY idlineadoc,referencia,codpieza ";
	}
	q.setWhere(where); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		_i.tblLineas_.insertRows(f);
		_i.tblLineas_.setText(f, _i.cLIN_, q.value("idlineadoc"));
		_i.tblLineas_.setText(f, _i.cREF_, q.value("referencia"));
		_i.tblLineas_.setText(f, _i.cDES_, q.value("descripcion"));
		_i.tblLineas_.setText(f, _i.cPIE_, q.value("codpieza"));
		_i.tblLineas_.setText(f, _i.cCPE_, q.value("canpedida"));
		_i.tblLineas_.setText(f, _i.cMUS_, q.value("canusada"));
		_i.tblLineas_.setText(f, _i.cMEP_, q.value("candisponible"));
		_i.tblLineas_.setText(f, _i.cSFA_, q.value("canstock"));
		_i.tblLineas_.setText(f, _i.cADC_, q.value("canadescontar"));      
		_i.tblLineas_.setText(f, _i.cAAM_, q.value("canaumentar"));	
		_i.tblLineas_.setText(f, _i.cFEP_, q.value("canfinal"));  
		_i.tblLineas_.setText(f, _i.cTDC_, q.value("tipodoc"));
		_i.tblLineas_.setText(f, _i.cALM_, q.value("codalmacen"));
		_i.tblLineas_.setText(f, _i.cEST_, q.value("estado")); //#H1400
		_i.tblLineas_.setText(f, _i.cIDST_, q.value("idstock")); //#H1400
		f++;
	}	
	if(f == 0) {
		//no se ha cargado nunca por tanto 
		_i.modo_ = "INSERTANDO";
	} else {
		_i.modo_ = "MOSTRANDO";
	
	}

}

function oficial_habilitaCampos()
{
	var _i = this.iface;
	if(_i.modo_ == "INSERTANDO") {
		sys.enableObj(this, "tbnBuscar");
		sys.enableObj(this, "pbnDescontarTodo");
		sys.enableObj(this, "pbnLimpiar");
		sys.enableObj(this, "fdbFecha");
		sys.enableObj(this, "fdbHora");
		sys.enableObj(this, "fdbIdUsuario");
		sys.enableObj(this, "fdbCodPedidoProv");
		sys.enableObj(this, "fdbCodOrden");
		sys.enableObj(this, "fdbCodBobina"); //#H1400
		this.child("cbAlmacen").setEnabled(true);

	} else {
		
		sys.disableObj(this, "tbnBuscar");
		sys.disableObj(this, "pbnDescontarTodo");
		sys.disableObj(this, "pbnLimpiar");
		sys.disableObj(this, "fdbFecha");
		sys.disableObj(this, "fdbHora");
		sys.disableObj(this, "fdbIdUsuario");
		sys.disableObj(this, "fdbCodPedidoProv");
		sys.disableObj(this, "fdbCodOrden");
		sys.disableObj(this, "fdbCodBobina");//#H1400
		this.child("cbAlmacen").setEnabled(false);
		sys.disableObj(this, "fdbSoloConDisponible");
		sys.disableObj(this, "fdbSoloPorAlmacen");		
	} 
}

function oficial_compruebaBobina(codBobina)
{
	//devolvemos false si la el estado de la bobina es "PIEZAS ROLLADAS" y true en caso contrario
	if(AQUtil.sqlSelect("em_bobinas","estado","codbobina = '" + codBobina + "'") != "PIEZAS ROLLADAS") {
		return false;
	}
	return true;
}

function oficial_compruebaStockPieza(fila)
{
	var _i = this.iface;
	var canStock = _i.tblLineas_.text(fila,_i.cSFA_);
	var idstock = _i.tblLineas_.text(fila,_i.cIDST_); 
	var stockFisico = AQUtil.sqlSelect("stocks","cantidad","idstock = " + idstock);
	/*debug("\n\nfila: "+fila);
	debug("idStock: "+idstock);
	debug("canStock: "+canStock);
	debug("stockFisico: "+stockFisico);
	*/
	var aAumentar = parseFloat(_i.tblLineas_.text(fila, _i.cAAM_));
	aAumentar = isNaN(aAumentar) ? 0 : aAumentar;
	
	var aDescontar =parseFloat(_i.tblLineas_.text(fila, _i.cADC_))
	aDescontar = isNaN(aDescontar) ? 0 : aDescontar;

	if(parseFloat(canStock) != parseFloat(stockFisico) && (aAumentar != 0 || aDescontar != 0)) {
		//debug("entra y debe de poner no posible");
		_i.tblLineas_.setText(fila, _i.cEST_, "NO POSIBLE");
		_i.coloreaFila(fila);
		return false;
	}
	return true;
}

function oficial_pintaColorEstado()
{
	var _i = this.iface;
	var nF = _i.tblLineas_.numRows();  	
    	for (var f = 0; f < nF; f++) {  
		_i.coloreaFila(f);    	
  	}
}

function oficial_coloreaFila(f)
{
	var _i = this.iface;

	_i.tblLineas_.setText(f, _i.cLIN_, _i.tblLineas_.text(f, _i.cLIN_));
	_i.tblLineas_.setText(f, _i.cREF_, _i.tblLineas_.text(f, _i.cREF_));		  
	_i.tblLineas_.setText(f, _i.cDES_, _i.tblLineas_.text(f, _i.cDES_));
	_i.tblLineas_.setText(f, _i.cPIE_, _i.tblLineas_.text(f, _i.cPIE_));
	_i.tblLineas_.setText(f, _i.cCPE_, _i.tblLineas_.text(f, _i.cCPE_));
	_i.tblLineas_.setText(f, _i.cMUS_, _i.tblLineas_.text(f, _i.cMUS_));
	_i.tblLineas_.setText(f, _i.cMEP_, _i.tblLineas_.text(f, _i.cMEP_));
	_i.tblLineas_.setText(f, _i.cSFA_, _i.tblLineas_.text(f, _i.cSFA_));
	_i.tblLineas_.setText(f, _i.cADC_, _i.tblLineas_.text(f, _i.cADC_));      
	_i.tblLineas_.setText(f, _i.cAAM_, _i.tblLineas_.text(f, _i.cAAM_));		
	_i.tblLineas_.setText(f, _i.cFEP_, _i.tblLineas_.text(f, _i.cFEP_));  
	_i.tblLineas_.setText(f, _i.cTDC_, _i.tblLineas_.text(f, _i.cTDC_));
	_i.tblLineas_.setText(f, _i.cALM_, _i.tblLineas_.text(f, _i.cALM_));
	_i.tblLineas_.setText(f, _i.cEST_, _i.tblLineas_.text(f, _i.cEST_)); 
	_i.tblLineas_.setText(f, _i.cIDST_, _i.tblLineas_.text(f, _i.cIDST_));

	var estado = _i.tblLineas_.text(f,_i.cEST_);
	for (var c = 0; c < _i.tblLineas_.numCols(); c++) {
		if (estado == "PTE"){
			_i.tblLineas_.setCellBackgroundColor(f, c, _i.colBlanco_);			
		}else if( estado == "HECHO"){
			_i.tblLineas_.setCellBackgroundColor(f, c, _i.colVerde_);
		}else if(estado == "NO POSIBLE"){
			_i.tblLineas_.setCellBackgroundColor(f, c, _i.colRojo_)
		}
	}	
}

function oficial_cbAlmacen_activated()
{
	var _i = this.iface;
	_i.habilitaCodigos();
}
///// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
