
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function tbnVentasCredCom_clicked() {
		return this.ctx.euromoda_tbnVentasCredCom_clicked();
	}
	function obtenerParamInformeVCC() {
		return this.ctx.euromoda_obtenerParamInformeVCC();
	}
	function tbnFacInternacional_clicked() {
		return this.ctx.euromoda_tbnFacInternacional_clicked();
	}
	function obtenerParamInformeFI() {
		return this.ctx.euromoda_obtenerParamInformeFI();
	}
	function lanzar() {
		return this.ctx.euromoda_lanzar();
	}	
	function imprimirMembrete_clicked() {
		return this.ctx.euromoda_imprimirMembrete_clicked();
	}
	function tbnFacInternacionalMem_clicked() {
		return this.ctx.euromoda_tbnFacInternacionalMem_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	
	connect (this.child("tbnVentasCredCom"), "clicked()", _i, "tbnVentasCredCom_clicked()");
	connect (this.child("tbnFacInternacional"), "clicked()", _i, "tbnFacInternacional_clicked()");
	connect (this.child("tbnImprimirMembrete"), "clicked()", _i, "imprimirMembrete_clicked()");
	connect (this.child("tbnFacInternacionalMem"), "clicked()", _i, "tbnFacInternacionalMem_clicked()");
	
	if (cursor.action() == "i_resfacturascli") {
		if(this.child("tbnImprimirMembrete")) {
			this.child("tbnImprimirMembrete").close();
		}
		if(this.child("tbnFacInternacionalMem")) {
			this.child("tbnFacInternacionalMem").close();
		}
	}
}

function euromoda_tbnVentasCredCom_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  var pI = _i.obtenerParamInformeVCC();
  if (!pI) {
    return; 
  }

  flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

function euromoda_obtenerParamInformeVCC()
{
  var cursor = this.cursor();
  var oP = flfactinfo.iface.pub_dameParamInforme();
  oP.nombreInforme = "i_ventas_cred_com";
  oP.whereFijo = "i_facturascli.id = " + cursor.valueBuffer("id");
  oP.groupBy = "i_facturascli.d_facturascli_fecha, i_facturascli.h_facturascli_fecha, paises.codpais, paises.nombre, clientes.codcliente, clientes.nombre, clientes.seguro";
  return oP;
}

function euromoda_tbnFacInternacional_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  flfactinfo.iface.pub_ponerMembrete(false);
  var pI = _i.obtenerParamInformeFI();
  if (!pI) {
    return; 
  }

  flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

function euromoda_obtenerParamInformeFI()
{
  var cursor = this.cursor();
  var oP = flfactinfo.iface.pub_dameParamInforme();
  oP.nombreInforme = "i_facturascli_int";
  return oP;
}

function euromoda_lanzar()
{
	var _i = this.iface;
	flfactinfo.iface.pub_ponerMembrete(false);
	_i.__lanzar();	
}

function euromoda_imprimirMembrete_clicked()
{
	var _i = this.iface;
	var cursor= this.cursor();
	
	flfactinfo.iface.pub_ponerMembrete(true);
	
	var pI = this.iface.obtenerParamInforme();
	if (!pI) {
		return;
	}

	flfactinfo.iface.pub_lanzaInforme(cursor, pI);
	flfactinfo.iface.pub_ponerMembrete(false);
}

function euromoda_tbnFacInternacionalMem_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  flfactinfo.iface.pub_ponerMembrete(true);
  var pI = _i.obtenerParamInformeFI();
  if (!pI) {
    return; 
  }

  flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
