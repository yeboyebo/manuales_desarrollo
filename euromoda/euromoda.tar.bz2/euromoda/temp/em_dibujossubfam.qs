/***************************************************************************
                 em_dibujossubfam.qs  -  description
                             -------------------
    begin                : mar ago 16 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN:String):String { return this.ctx.interna_calculateField(fN); }
	function validateForm():Boolean {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var aTamanos_;
	function oficial( context ) { interna( context ); } 
	function tbnPonTamano_clicked() {
		return this.ctx.oficial_tbnPonTamano_clicked();
	}
	function cargaTamanos() {
		return this.ctx.oficial_cargaTamanos();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El valor de --stockfis-- se calcula autom�ticamente para cada art�culo como la suma de existencias del art�culo en todos los almacenes.
\end */
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			var cR = cursor.cursorRelation();
			if (cR && cR.table() == "em_dibujos") {
				sys.setObjText(this, "fdbDesDibujo", AQUtil.sqlSelect("em_dibujos", "descripcion", "coddibujoem = '" + cursor.valueBuffer("coddibujoem") + "'"));
			}
			break;
		}
	}
// 	this.child("tdbTamanosSubfam").cursor().setMainFilter("codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
	
	connect(this.child("tbnPonTamano"), "clicked()", _i, "tbnPonTamano_clicked");
}

function interna_calculateField(fN)
{
	return 0;
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnPonTamano_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  if (cursor.modeAccess() == cursor.Insert) {
    if (!this.child("tdbTamanosSubfam").cursor().commitBufferCursorRelation()) {
      return false;
    }
  }

  _i.aTamanos_ = false;
  if (!_i.cargaTamanos()) {
    return false;
  }

  var f = new FLFormSearchDB("em_seltamanossubfam");
	var c = f.cursor();
	c.setMainFilter("codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
  f.setMainWidget();
  f.exec();
  if (!f.accepted()) {
    return;
  }
  if (!_i.aTamanos_) {
    return;
  }
  var idDibujoSubfam = cursor.valueBuffer("iddibujosubfam");
  if (!AQSql.del("em_dibujostamsub", "iddibujosubfam = " + idDibujoSubfam)) {
    return false;
  }
  var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codDibujo = cursor.valueBuffer("coddibujoem");
  for (var i = 0; i < _i.aTamanos_.length; i++) {
		if (_i.aTamanos_[i] && !isNaN(_i.aTamanos_[i])) {
debug("_i.aTamanos_[i] = " + _i.aTamanos_[i]);
			if (!AQSql.insert("em_dibujostamsub", ["iddibujosubfam", "coddibujoem", "codsubfamilia", "codtamanoem"], [idDibujoSubfam, codDibujo, codSubfamilia, AQUtil.sqlSelect("em_tamanossubfam", "codtamanoem", "idtamanosubfam = " + _i.aTamanos_[i])])) {
				return false;
			}
debug("_i.aTamanos_[i] " + _i.aTamanos_[i] + " OK");
		}
  }
  this.child("tdbTamanosSubfam").refresh();
}

function oficial_cargaTamanos()
{
  var cursor = this.cursor();
  var _i = this.iface;

  var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var idDibujoSubfam = cursor.valueBuffer("iddibujosubfam");
  var q = new FLSqlQuery();
  q.setTablesList("em_dibujostamsub");
  q.setSelect("codtamanoem");
  q.setFrom("em_dibujostamsub");
  q.setWhere("iddibujosubfam = " + idDibujoSubfam);
  q.setForwardOnly(true);
  if (!q.exec()) {
    return false;
  }
  _i.aTamanos_ = [];
  var i = 0;
  while (q.next()) {
  	if (!AQUtil.sqlSelect("em_tamanossubfam", "idtamanosubfam", "codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + q.value("codtamanoem") + "'")) {
  		debug ("falla subfam  "  +  codSubfamilia + " + codtamanoem " + q.value("codtamanoem") );
  	}
    _i.aTamanos_[i++] = AQUtil.sqlSelect("em_tamanossubfam", "idtamanosubfam", "codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + q.value("codtamanoem") + "'");
    debug(" _i.aTamanos_[i++] = " +  q.value("codtamanoem") + " " +  _i.aTamanos_[i-1]);
  }
  return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
