/***************************************************************************
                 em_masterpantallas.qs  -  description
                             -------------------
    begin                : juev abril 6 2017
    copyright            : Por ahora (C) 2005 by InfoSiAL S.L.
    email                : lveb@telefonica.net
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  var lblPantallaActual;

  function oficial(context)
  {
    interna(context);
  }
  function actualizarPantallaActual()
  {
    return this.ctx.oficial_actualizarPantallaActual();
  }
  function cambiarPantalla()
  {
    return this.ctx.oficial_cambiarPantalla();
  }
  function tbnBorrarPLocal_clicked()
  {
    return this.ctx.oficial_tbnBorrarPLocal_clicked();
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
En el formulario maestro se muestra el punto de venta establecido como local que saldr� por defecto en las comandas y arqueos
El bot�n cambiar permite cambiar el punto de venta local
*/
function interna_init()
{
	var _i = this.iface;

  	_i.lblPantallaActual = this.child("lblPantallaActual");
  	connect(this.child("pbnCambiar"), "clicked()", _i, "cambiarPantalla()");
	connect(this.child("tbnBorrarPLocal"), "clicked()", _i, "tbnBorrarPLocal_clicked()");
	
    _i.actualizarPantallaActual();
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
/** \D
Cambia el punto de venta local por el punto de venta seleccionado en ese momento
*/
function oficial_cambiarPantalla()
{

	var _i = this.iface;
	var cursor = this.cursor();
    //saco el valor de la columna codpantalla del elemento seleccionado
    var valor = cursor.valueBuffer("codpantalla");
    AQUtil.writeSettingEntry("scripts/flprodppal/codPantalla", valor);

    _i.actualizarPantallaActual();

	/*if(formtpv_comandas.iface.masterComandasCargada_){
		formtpv_comandas.iface.pub_valoresLocales();
	}*/
}

function oficial_tbnBorrarPLocal_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
    AQUtil.writeSettingEntry("scripts/flprodppal/codPantalla", false);
    _i.actualizarPantallaActual();
	/*if(formtpv_comandas.iface.masterComandasCargada_){
		formtpv_comandas.iface.pub_valoresLocales();
	}*/
}

/** \D
Muestra el codigo y descripcion del punto de venta local
*/
function oficial_actualizarPantallaActual()
{
	var _i = this.iface;
	var t = sys.translate("Pantalla local no establecida.");

	//1. leer del registro el codigo de pantalla
	var valor = AQUtil.readSettingEntry("scripts/flprodppal/codPantalla");
	valor = valor == "false" ? false : valor;
	//2.hacer select para sacar la descripcion y mostrar codPantalla - descripcion
	if(valor) {
		var descripcion = AQUtil.sqlSelect("em_pantallas", "descripcion", "codpantalla = '" + valor + "'");	
		if (descripcion) {
			t = valor + " - " + descripcion;
		}
	}
	_i.lblPantallaActual.text = t;
 
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
