
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
  var longSubcuenta, bloqueoSubcuenta, ejercicioActual, posActualPuntoSubcuenta;
  var cursorLA_;
  function euromoda( context ) { prod ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function modoTexto() {
    return this.ctx.euromoda_modoTexto();
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function pbnInsertarPlantillaTexto_clicked() {
    return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
  }
  function validateForm() {
    return this.ctx.euromoda_validateForm();
  }
  function calculateField(fN) {
    return this.ctx.euromoda_calculateField(fN);
  }
  function dameFiltroReferencia() {
    return this.ctx.euromoda_dameFiltroReferencia();
  }
  function ledEmArticulo_returnPressed() {
    return this.ctx.euromoda_ledEmArticulo_returnPressed();
  }
	function pbnSelPiezas_clicked() {
		return this.ctx.euromoda_pbnSelPiezas_clicked();
	}
	function aceptarFormulario() {
  		return this.ctx.euromoda_aceptarFormulario();
  	}
  	function aceptaContinuaFormulario() {
  		return this.ctx.euromoda_aceptaContinuaFormulario();
  	}
  	function habilitarBotonesAceptar() {
  		return this.ctx.euromoda_habilitarBotonesAceptar();
  	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
	var codCliente;
	var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(cursor);
	if (!datosTP) {
		codCliente = false;
	} else {
		codCliente = datosTP["codcliente"];
	}
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",codCliente);

	
  switch (cursor.modeAccess()) {
  case cursor.Insert: {
      this.child("fdbReferencia").setFocus();
      break;
    }
  case cursor.Edit: {
      sys.disableObj(this, "fdbTipoConcepto");
			sys.disableObj(this, "fdbRefCliente");
      break;
    }
  }
  
  connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");
  _i.__init();
  formRecordlineaspedidoscli.iface.pub_habilitaTipoConcepto(this);
  _i.modoTexto();
  
  if (sys.isLoadedModule("flcontppal")) {
    _i.ejercicioActual = flfactppal.iface.pub_ejercicioActual();
    _i.longSubcuenta = AQUtil.sqlSelect("ejercicios", "longsubcuenta", "codejercicio = '" + _i.ejercicioActual + "'");
    _i.bloqueoSubcuenta = false;
    _i.posActualPuntoSubcuenta = -1;
    this.child("fdbIdSubcuenta").setFilter("codejercicio = '" + _i.ejercicioActual + "'");
  }
  try {
		AQS.setTabOrder(this.child("fdbReferencia").obj(), this.child("fdbCantidad").obj());
		AQS.setTabOrder(this.child("fdbCantidad").obj(), this.child("fdbPvpUnitario").obj());
	} catch (e) {}
	
	connect(this.child("ledEmArticulo"), "returnPressed()", _i, "ledEmArticulo_returnPressed");
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			this.child("ledEmArticulo").setFocus();
			break;
		}
  	}
	connect(this.child("pbnSelPiezas"), "clicked()", _i, "pbnSelPiezas_clicked");
	
	//Desconectamos el boton aceptar
	if(this.child("pushButtonAccept")){
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
		connect(this.child("pushButtonAccept"), "clicked()", _i, "aceptarFormulario");
	}

	if(this.child("pushButtonAcceptContinue")){
		disconnect(this.child("pushButtonAcceptContinue"), "clicked()", this.obj(), "acceptContinue()");
		connect(this.child("pushButtonAcceptContinue"), "clicked()", _i, "aceptaContinuaFormulario");

		_i.habilitarBotonesAceptar();
	}
	
}

function euromoda_bufferChanged(fN)
{
	
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "tipoconcepto": {
      _i.__bufferChanged(fN);
			_i.modoTexto();
      break;
    }
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
	var valor;
  switch (fN) {
		default: {
			valor = _i.__calculateField(fN);
		}
	}
	return valor;
}

function euromoda_modoTexto()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
  case "Texto": {
      this.child("fdbReferencia").setValue("");
      this.child("fdbCantidad").setValue(0);
      this.child("fdbPvpUnitario").setValue(0);
      this.child("fdbCodImpuesto").setValue("");
      this.child("groupBox7").enabled = false;
      this.child("groupBox8").enabled = false;
      this.child("groupBox9").enabled = false;
      this.child("groupBox10").enabled = false;
      this.child("tbwLinea").setTabEnabled("texto", true);
      this.child("tbwLinea").showPage("texto");
      this.child("fdbTexto").setFocus();
      break;
    }
  default: {
      this.child("groupBox7").enabled = true;
      this.child("groupBox8").enabled = true;
      this.child("groupBox9").enabled = true;
      this.child("groupBox10").enabled = true;
      this.child("tbwLinea").showPage("movimientos");
      this.child("tbwLinea").setTabEnabled("texto", false);
      this.child("fdbTexto").setValue("");
      break;
    }
  }
}

function euromoda_pbnInsertarPlantillaTexto_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbTexto").setValue(texto);
}

function euromoda_validateForm()
{
	var cursor = this.cursor();
	var _i = this.iface;

	var oParamLin = new Object;
	oParamLin.cursor = cursor;
	oParamLin.ignorarAvisos = false;
	oParamLin.forzarReg = false;
	oParamLin.ignorarCalculoInsert = false; 

	if (!_i.__validateForm()) {
		_i.habilitarBotonesAceptar();
		return false;
	}
	if (!flfacturac.iface.pub_validaIvaLinea(cursor)) {
		_i.habilitarBotonesAceptar();
		return false;
	}
	if(!formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin)) {
  		_i.habilitarBotonesAceptar();
		return false;
	}
	return true;
}

function euromoda_dameFiltroReferencia()
{
	var _i = this.iface;
// 	var f = _i.__dameFiltroReferencia();
	var f = "NOT debaja";
	return f;
}
function euromoda_ledEmArticulo_returnPressed()
{	
	formRecordlineaspedidoscli.iface.pub_commonLedEmArticulo_returnPressed(this);
}

function euromoda_pbnSelPiezas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	
	
	if (!this.child("tdbMoviStock").cursor().commitBufferCursorRelation()) {
		return false;
	}
		
	_i.cursorLA_ = cursor;	
	
	var codAlmacen;
	var curRel = cursor.cursorRelation();
	if (curRel && curRel.table() == "albaranescli") {
		codAlmacen = curRel.valueBuffer("codalmacen");
	} else {
		codAlmacen = AQUtil.sqlSelect("albaranescli", "codalmacen", "idalbaran = " + cursor.valueBuffer("idalbaran"));
	}
	var referencia = cursor.valueBuffer("referencia");
	if (!referencia) {
		sys.warnMsgBox(sys.translate("No hay ninguna referencia seleccionada"));
		return;
	}
	
	var f = new FLFormSearchDB("em_seleccionpiezas");
	var c = f.cursor();
	//c.setMainFilter("referencia = '" + referencia + "' and codalmacen = '"+ codAlmacen + "' and candisponible > 0");
	c.setMainFilter("referencia = '" + referencia + "' and candisponible > 0");
	f.setMainWidget();
	f.exec();	
	if(f.accepted()) {	
		if(!formem_asignacionpiezasoe.iface.totalesLineasAlbaran(cursor)) {
			return false;
		}
		this.child("tdbMoviStock").refresh();	
	}	
}

function euromoda_aceptarFormulario()
{
	var _i = this.iface;

	debug("euromoda_aceptarFormulario");
	this.child("pushButtonAccept").setDisabled(true);
	this.obj().accept();
}

function euromoda_aceptaContinuaFormulario()
{
	var _i = this.iface;

	debug("euromoda_aceptaContinuaFormulario");
	this.child("pushButtonAcceptContinue").setDisabled(true);
	this.obj().acceptContinue();
}

function euromoda_habilitarBotonesAceptar()
{
	this.child("pushButtonAccept").setDisabled(false);
	this.child("pushButtonAcceptContinue").setDisabled(false);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
    