/***************************************************************************
                 em_etiquetaspie.qs  -  description
                             -------------------
    begin                : jue feb 28 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
	function main() {
		this.ctx.interna_main();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblEtiquetas_;
	var CODLOTE_, REFERENCIA_, DESCRIPCION_, TAMANO_, COLOR_, COMPOSICION_, PARTIDA_, ALBARAN_, METROS_, CANTIDAD_,CODSERIE_;
	function oficial( context ) { interna( context ); }
	function construirTabla() {
		return this.ctx.oficial_construirTabla();
	}
	 function cargarTabla() {
		return this.ctx.oficial_cargarTabla();
	}
	 function borrarTabla() {
		return this.ctx.oficial_borrarTabla();
	}
	function imprimir() {
		return this.ctx.oficial_imprimir();
	}
	function obtenerWhere() {
		return this.ctx.oficial_obtenerWhere();
	}
  function imprimeEtiquetas(aEtiquetas, impresora) {
    return this.ctx.oficial_imprimeEtiquetas(aEtiquetas, impresora);
  }
  function insertaFila(f, q) {
    return this.ctx.oficial_insertaFila(f, q);
  }
  function tbnCargaTexto_clicked() {
    return this.ctx.oficial_tbnCargaTexto_clicked();
  }
  function ledCantidad_returnPressed() {
    return this.ctx.oficial_ledCantidad_returnPressed();
  }
  function bufferChanged(fN) {
    return this.ctx.oficial_bufferChanged(fN);
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

	
/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
	function pub_imprimeEtiquetas(aEtiquetas, impresora) {
		return this.imprimeEtiquetas(aEtiquetas, impresora);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	_i.tblEtiquetas_ = this.child("tblEtiquetas");
	
	connect(this.child("tbnBuscar"), "clicked()",_i, "cargarTabla()");
	connect(this.child("tbnBorrar"), "clicked()",_i, "borrarTabla()");
	connect(this.child("tbnImprimir"), "clicked()",_i, "imprimir()");
	connect(this.child("tbnCargaTexto"), "clicked()",_i, "tbnCargaTexto_clicked");
	connect(this.child("ledCantidad"), "returnPressed()",_i, "ledCantidad_returnPressed");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	
	
	if (this.child("fdbCantidad")) {
		this.child("fdbCantidad").close();
	}
	
	_i.construirTabla();
}

function interna_validateForm()
{
	var cursor = this.cursor();
	var _i = this.iface;
	
	return true;
}

function interna_main()
{
	var _i = this.iface;
	
	var f = new FLFormSearchDB("em_etiquetaspie");
	var cursor = f.cursor();

	cursor.select();
	if (!cursor.first()) {
		cursor.setModeAccess(cursor.Insert);
	} else {
		cursor.setModeAccess(cursor.Edit);
	}
	f.setMainWidget();
	cursor.refreshBuffer();
	var id = f.exec("idetiqueta");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_construirTabla()
{
	var cabecera = "";
	var _i = this.iface;
	var cursor = this.cursor();
	var c = 0;
	
	_i.CODLOTE_ = c++;
	cabecera += sys.translate( "C�digo") + "/";
	_i.REFERENCIA_ = c++;
	cabecera += sys.translate( "Referencia") + "/";
	_i.DESCRIPCION_  = c++;
	cabecera += sys.translate( "Descripci�n") + "/";
	_i.TAMANO_ = c++;
	cabecera += sys.translate( "Tama�o") + "/";
	_i.COLOR_ = c++;
	cabecera += sys.translate( "Color") + "/";
	_i.CODSERIE_ = c++;
	cabecera += sys.translate( "Serie") + "/";
	_i.COMPOSICION_ = c++;
	cabecera += sys.translate( "Composici�n") + "/";
	_i.PARTIDA_ = c++;
	cabecera += sys.translate( "Partida") + "/";
	_i.ALBARAN_ = c++;
	cabecera += sys.translate( "Albar�n") + "/";
	_i.METROS_ = c++;
	cabecera += sys.translate( "Metros") + "/";
	_i.CANTIDAD_ = c++;
	cabecera += sys.translate( "Cantidad") + "/";
  
  _i.tblEtiquetas_.setNumCols(c);
	
	_i.tblEtiquetas_.setColumnWidth(_i.CODLOTE_, 100);
	_i.tblEtiquetas_.setColumnWidth(_i.REFERENCIA_, 100);
	_i.tblEtiquetas_.setColumnWidth(_i.DESCRIPCION_, 400);
	_i.tblEtiquetas_.setColumnWidth(_i.TAMANO_, 60);
	_i.tblEtiquetas_.setColumnWidth(_i.COLOR_, 60);
	_i.tblEtiquetas_.setColumnWidth(_i.CODSERIE_, 60);
	_i.tblEtiquetas_.hideColumn(_i.COMPOSICION_);
	_i.tblEtiquetas_.hideColumn(_i.PARTIDA_);
	_i.tblEtiquetas_.hideColumn(_i.ALBARAN_);
	_i.tblEtiquetas_.setColumnWidth(_i.METROS_, 60);
	_i.tblEtiquetas_.setColumnWidth(_i.CANTIDAD_, 60);
	
	_i.tblEtiquetas_.setColumnReadOnly(_i.CODLOTE_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.REFERENCIA_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.DESCRIPCION_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.TAMANO_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.COLOR_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.CODSERIE_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.METROS_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.CANTIDAD_, false);

	_i.tblEtiquetas_.setColumnLabels("/", cabecera);
}

function oficial_cargarTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var where = _i.obtenerWhere();
	var q = new FLSqlQuery;
	q.setSelect("l.codlote, l.codpartida, l.codalbaranprov, l.candisponible, a.descripcion, a.codtamanoem, a.referencia, a.codcolorem, c.descripcion, em_disenos.codseriediseno");
	q.setFrom("lotesstock l INNER JOIN articulos a ON l.referencia = a.referencia LEFT OUTER JOIN em_composiciones c ON a.em_codcomposicion = c.em_codcomposicion LEFT OUTER JOIN em_dibujos ON a.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno");
	q.setWhere(where + " ORDER BY l.codlote, a.referencia, a.descripcion, a.codtamanoem");
	debug(q.sql());
	q.setForwardOnly(true);
	if (!q.exec()) {
		return;
	}
	
	if(q.size() > 100){
		var res = MessageBox.warning(sys.translate("La b�squeda que va a lanzar ha encontrado %1 registros.\n�Desea continuar?").arg(q.size()),MessageBox.Yes, MessageBox.No, MessageBox.NoButton,"AbanQ");
		if(res != MessageBox.Yes) {
			return;
		}
	}
	
	var cantidad = parseInt(this.child("ledCantidad").text);//cursor.valueBuffer("cantidad"));
	if (!cantidad && cantidad != 0) {
		cantidad = 1;
	}
	var f = 0;
	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Insertando selecci�n de art�culos"), q.size());
	
	while (q.next()) {
		AQUtil.setProgress(p++);
		_i.insertaFila(f, q);
		f++;
	}
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	
}

function oficial_insertaFila(f, q)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var cantidad = parseInt(this.child("ledCantidad").text); //cursor.valueBuffer("cantidad"));
	if (!cantidad && cantidad != 0) {
		cantidad = 1;
	}
	_i.tblEtiquetas_.insertRows(f, 1);
	_i.tblEtiquetas_.setText(f, _i.CODLOTE_, q.value("l.codlote"));
	_i.tblEtiquetas_.setText(f, _i.REFERENCIA_, q.value("a.referencia"));
	_i.tblEtiquetas_.setText(f, _i.DESCRIPCION_, q.value("a.descripcion"));
	_i.tblEtiquetas_.setText(f, _i.TAMANO_, q.value("a.codtamanoem"));
	_i.tblEtiquetas_.setText(f, _i.COLOR_, q.value("a.codcolorem"));
	_i.tblEtiquetas_.setText(f, _i.CODSERIE_, q.value("em_disenos.codseriediseno"));
	_i.tblEtiquetas_.setText(f, _i.COMPOSICION_, q.value("c.descripcion"));
	_i.tblEtiquetas_.setText(f, _i.PARTIDA_, q.value("l.codpartida"));
	_i.tblEtiquetas_.setText(f, _i.ALBARAN_, q.value("l.codalbaranprov"));
	_i.tblEtiquetas_.setText(f, _i.METROS_, q.value("l.candisponible"));
	_i.tblEtiquetas_.setText(f, _i.CANTIDAD_, cantidad);
}

function oficial_borrarTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	_i.tblEtiquetas_.removeRow(_i.tblEtiquetas_.currentRow());
// 	_i.tblEtiquetas_.clear();
}

function oficial_obtenerWhere()
{
	var cursor = this.cursor();
	var where = "1 = 1";
	
	var codLoteDesde = cursor.valueBuffer("codlotedesde");
	if (codLoteDesde && codLoteDesde != "") {
		where += " AND l.codlote >= '" + codLoteDesde + "'";
	}
	
	var codLoteHasta = cursor.valueBuffer("codlotehasta");
	if (codLoteHasta && codLoteHasta != "") {
		where += " AND l.codlote <= '" + codLoteHasta + "'";
	}
	return where;
}

function oficial_imprimir()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var aEtiquetas = [];

	for (var f = 0; f < _i.tblEtiquetas_.numRows(); f++) {
		var aE = new Object;
		aE["codlote"] = _i.tblEtiquetas_.text(f, _i.CODLOTE_);
		aE["referencia"] = _i.tblEtiquetas_.text(f, _i.REFERENCIA_);
		aE["descripcion"] = _i.tblEtiquetas_.text(f, _i.DESCRIPCION_);
		aE["tamano"] = _i.tblEtiquetas_.text(f, _i.TAMANO_);
		aE["color"] = _i.tblEtiquetas_.text(f, _i.COLOR_);
		var codseriediseno = _i.tblEtiquetas_.text(f, _i.CODSERIE_);
		if (codseriediseno && codseriediseno != ""){
			codseriediseno = "[" + codseriediseno + "]"
		}
		aE["codseriediseno"] = codseriediseno;
		aE["composicion"] = _i.tblEtiquetas_.text(f, _i.COMPOSICION_);
		aE["partida"] = _i.tblEtiquetas_.text(f, _i.PARTIDA_);
		aE["albaran"] = _i.tblEtiquetas_.text(f, _i.ALBARAN_);
		aE["metros"] = _i.tblEtiquetas_.text(f, _i.METROS_);
		aE["cantidad"] = _i.tblEtiquetas_.text(f, _i.CANTIDAD_);
		aEtiquetas.push(aE);
	}
	_i.imprimeEtiquetas(aEtiquetas);

	
	return true;
}

function oficial_imprimeEtiquetas(aEtiquetas, impresora)
{
	var _i = this.iface;

	if (!impresora) {
		impresora = AQUtil.sqlSelect("prodppal_general", "impresoraetipie", "1 = 1");
	}

	var copias, aE;
	var xmlKD = new FLDomDocument;
	xmlKD.setContent("<!DOCTYPE KUGAR_DATA><KugarData/>");
	var eRow:FLDomElement;

	for (var a = 0; a < aEtiquetas.length; a++) {
		aE = aEtiquetas[a];
		copias = aE.cantidad;
		if (copias == 0) {
			continue;
		}
		for (var i = 0; i < copias; i++) {
			eRow = xmlKD.createElement("Row");
			var cG = AQUtil.quickSqlSelect("em_colores", "codigogit", "codcolorem = '" + aE["color"] + "'");
			if (cG) {
				aE["color"] = cG + " - " + aE["color"];
			}
			//var linea2 = sys.translate("Ancho %1. Color %2. %3").arg(aE["tamano"]).arg(aE["color"]).arg(aE["composicion"]);
			var linea2 = "Ancho " + aE["tamano"] + ". Color " + aE["color"] + ". " + aE["composicion"];
			var codseriediseno = aE["codseriediseno"];
			if(codseriediseno && codseriediseno != "") {
				linea2 = linea2 + " - " + codseriediseno;
			}
			eRow.setAttribute("codlote", aE["codlote"]);
			eRow.setAttribute("articulo", aE["referencia"] + " " + aE["descripcion"]);
			eRow.setAttribute("linea2", linea2);
			eRow.setAttribute("metros", aE["metros"] + " Mts");
			eRow.setAttribute("albaran", sys.translate("Albar�n %1").arg(aE["albaran"]));
			eRow.setAttribute("partida", sys.translate("Partida %1").arg(aE["partida"]));
			eRow.setAttribute("codseriediseno",codseriediseno);
			eRow.setAttribute("level", 0);
			xmlKD.firstChild().appendChild(eRow);
		}
	}
debug(xmlKD.toString(4));

	var rptViewer = new FLReportViewer();
	rptViewer.setReportData(xmlKD);
	
	var rptViewer = new FLReportViewer();
	rptViewer.setReportTemplate("pr_i_eti_pieza");
	rptViewer.setReportData(xmlKD);
	rptViewer.renderReport();
	rptViewer.exec();
	
  return true;
}


function oficial_tbnCargaTexto_clicked()
{
  var _i = this.iface;
	var dialog = new Dialog;
	dialog.okButtonText = sys.translate("Aceptar");
	dialog.cancelButtonText = sys.translate("Cancelar");

	var gB = new GroupBox;
	gB.title = sys.translate("Pegue la lista de piezas separada por ;");
	dialog.add( gB );
	var teTabla = new TextEdit;
	gB.add( teTabla );

	if(!dialog.exec()) {
		return;
	}
	var texto = teTabla.text;
	var aRefs = texto.split(";");
	if (!aRefs || aRefs.length == 0) {
		return;
	}
	var nL = aRefs.length;
	nL--;
	if (nL < 1) {
		return;
	}
	var t = _i.tblEtiquetas_;
	var f = t.numRows()
	var q = new AQSqlQuery;
	q.setSelect("l.codlote, l.codpartida, l.codalbaranprov, l.candisponible, a.descripcion, a.codtamanoem, a.referencia, a.codcolorem, c.descripcion");
	q.setFrom("lotesstock l INNER JOIN articulos a ON l.referencia = a.referencia LEFT OUTER JOIN em_composiciones c ON a.em_codcomposicion = c.em_codcomposicion");
	
	for (var e = nL; e >= 0 ; e--) {
		q.setWhere("l.codlote = '" + aRefs[e] + "'");
		if (!(q.exec() && q.first())) {
			return false
		}
		_i.insertaFila(f, q)
		f++;
	}
}

function oficial_ledCantidad_returnPressed()
{
	this.child("tbnBuscar").animateClick();
	this.child("fdbCodLoteDesde").setFocus();
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	switch (fN) {
		case "codlotedesde": {
			sys.setObjText(this, "fdbCodLoteHasta", cursor.valueBuffer("codlotedesde"));
			break;
		}
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
