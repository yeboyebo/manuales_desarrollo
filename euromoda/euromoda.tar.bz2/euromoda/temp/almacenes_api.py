# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa

# almacenes = qsa.class_("almacenes")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */
class Oficial(Base):

    def get(self, params, username=None):

        mapa = self.get_mapa()

        obj = qsa.from_project("formAPI").get_resources('almacenes', params, mapa, username)

        return obj

    def get_mapa(self):
        return {
            'join': 'almacenes',
            'order': 'codalmacen',
            'map': {
                'codalmacen': {'field': 'almacenes.codalmacen', 'type': 'string'},
                'nombre': {'field': 'almacenes.nombre', 'type': 'string'}
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
