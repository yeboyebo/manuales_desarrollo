
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends anticiposProv {
	var bloqueoIdFiscal_, cPar;
  function euromoda( context ) { anticiposProv ( context ); }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function filtraDocumentos()
  {
    return this.ctx.euromoda_filtraDocumentos();
  }
  function colsSubcuentasProv()
  {
    return this.ctx.euromoda_colsSubcuentasProv();
  }
  function inhabilitaContabilidadOficial()
  {
    return this.ctx.euromoda_inhabilitaContabilidadOficial();
  }
  function filtraSubcuentasProv()
  {
    return this.ctx.euromoda_filtraSubcuentasProv();
  }
  function filtraPartidasProv()
  {
    return this.ctx.euromoda_filtraPartidasProv();
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function mostrarLibroMayor()
  {
    return this.ctx.euromoda_mostrarLibroMayor();
  }
  function dameWhereRecibosSaldo()
  {
    return this.ctx.euromoda_dameWhereRecibosSaldo();
  }
  function establecerSubcuenta() 
  {
    return this.ctx.euromoda_establecerSubcuenta();
  }
  function calculateField(fN)
  {
    return this.ctx.euromoda_calculateField(fN);
  }
  function validateForm()
  {
		return this.ctx.euromoda_validateForm();
	}
	function validaCIFEuromoda()
  {
		return this.ctx.euromoda_validaCIFEuromoda();
	}
	function compruebaSaldo()
  {
		return this.ctx.euromoda_compruebaSaldo();
	}
	function commonCalculateField(fN, cursor)
  {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
	function dameListaSubcuentas(codGrupoContableProd)
  {
		return this.ctx.euromoda_dameListaSubcuentas(codGrupoContableProd);
	}
	function cancelaAnticipoSaldo(aFilas)
  {
		return this.ctx.euromoda_cancelaAnticipoSaldo(aFilas);
	}
	function cargaOtrosSaldos(aDatos)
  {
		return this.ctx.euromoda_cargaOtrosSaldos(aDatos);
	}
	function cancelaReciboPartida(aFilas)
  {
		return this.ctx.euromoda_cancelaReciboPartida(aFilas);
	}
	function cancelaAnticipoPartida(aFilas)
  {
		return this.ctx.euromoda_cancelaAnticipoPartida(aFilas);
	}
	function cancelaPartidaPartida(aFilas)
  {
		return this.ctx.euromoda_cancelaPartidaPartida(aFilas);
	}
	function tbnEditaAR_clicked()
  {
		return this.ctx.euromoda_tbnEditaAR_clicked();
	}
	function coloresSaldo()
  {
		return this.ctx.euromoda_coloresSaldo();
	}
	function compensaRecibos(aFilas)
  {
		return this.ctx.euromoda_compensaRecibos(aFilas);
	}
	function compensaRecibosTR(curR1, curR2)
  {
		return this.ctx.euromoda_compensaRecibosTR(curR1, curR2);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_dameListaSubcuentas(codGrupoContableProd) {
		return this.dameListaSubcuentas(codGrupoContableProd);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
	
	_i.bloqueoIdFiscal_ = false;
	_i.colsSubcuentasProv();
	_i.filtraSubcuentasProv();
// 	_i.filtraSaldoPartidas();
	
	this.child("fdbDescTipoTercero").setDisabled(true);
	this.child("fdbDescSectorTercero").setDisabled(true);
	this.child("fdbDescCatTercero").setDisabled(true);
	this.child("fdbDescSubCatTercero").setDisabled(true);
	this.child("fdbDescEvalTercero").setDisabled(true);

  _i.__init();
  connect(this.child("chkRecibosPtes"), "clicked()", _i, "filtraDocumentos");
	_i.filtraDocumentos();
	_i.inhabilitaContabilidadOficial();
	_i.compruebaSaldo();


}

function euromoda_colsSubcuentasProv()
{
	var oC = ["codsubcuenta", "codejercicio", "descripcion"];
	this.child("tdbSubcuentas").setOrderCols(oC);
}

function euromoda_inhabilitaContabilidadOficial()
{
  var controles = ["fdbIdSubcuenta", "fdbDesSubcuenta", "fdbEjercicioSubcuenta", "fdbDebeSubcuenta", "fdbHaberSubcuenta", "fdbSaldoSubcuenta", "groupBox4_2_2", "groupBoxSubcuentas"];
  for (var i = 0; i < controles.length; i++) {
    sys.disableObj(this, controles[i]);
  }
}


function euromoda_filtraSubcuentasProv()
{
	var _i = this.iface;
	var filtro = "false";
	var cursor = this.cursor();
	var codSubcuenta = _i.calculateField("codsubcuenta");
	if (codSubcuenta) {
		filtro = "codsubcuenta = '" + codSubcuenta + "'";
	}
	var codEjercicio = AQUtil.sqlSelect("co_subcuentas", "codejercicio", "idsubcuenta = " + cursor.valueBuffer("idsubcuenta"));
	this.child("tdbSubcuentas").cursor().setMainFilter(filtro);
	this.child("tdbSubcuentas").refresh();
	_i.filtraPartidasProv();
}

function euromoda_filtraPartidasProv()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codEjercicio = AQUtil.sqlSelect("co_subcuentas", "codejercicio", "idsubcuenta = " + cursor.valueBuffer("idsubcuenta"));
	this.child("tdbPartidas").setFilter("codejercicio = '" + codEjercicio + "' AND codsubcuenta IN (" + _i.commonCalculateField("listasubcuentas", cursor) +  ")");
	this.child("tdbPartidas").refresh();
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) { 
	case "tipoidfiscal": {
		if (!_i.bloqueoIdFiscal_) {
			_i.bloqueoIdFiscal_ = true;
			if (cursor.valueBuffer("tipoidfiscal") == "NIF/IVA" || cursor.valueBuffer("tipoidfiscal") == "Otro") {
				cursor.setValueBuffer("codgrupocontableprov", _i.calculateField("codgrupocontableprov"));
			}
			_i.bloqueoIdFiscal_ = false;
		}
		break;
	}
	case "codgrupocontableprov": {
		_i.filtraSubcuentasProv();
		if (!_i.bloqueoIdFiscal_) {
			_i.bloqueoIdFiscal_ = true;
			if (cursor.valueBuffer("codgrupocontableprov") == "UE" || cursor.valueBuffer("codgrupocontableprov") == "INT") {
				cursor.setValueBuffer("tipoidfiscal", _i.calculateField("tipoidfiscal"));
			}
			_i.bloqueoIdFiscal_ = false;
		}
		sys.setObjText(this, "fdbCodSubcuenta", _i.calculateField("codsubcuenta"));
		break;
	}
	default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_mostrarLibroMayor()
{
	var util:FLUtil;
	var cursor= this.cursor();
	var codSubcuenta= this.child("tdbSubcuentas").cursor().valueBuffer("codsubcuenta");
	var codEjercicio= this.child("tdbSubcuentas").cursor().valueBuffer("codejercicio");
	if(!codSubcuenta || codSubcuenta == "" || !codEjercicio || codEjercicio == "") {
		MessageBox.warning(util.translate("scripts","Debe seleccionar una subcuenta por ejercicio"),MessageBox.Ok, MessageBox.NoButton,MessageBox.NoButton);
		return;
	}

	var curImprimir= new FLSqlCursor("co_i_mayor");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_co__subcuentas_codsubcuenta", codSubcuenta);
	curImprimir.setValueBuffer("h_co__subcuentas_codsubcuenta", codSubcuenta);
	curImprimir.setValueBuffer("i_co__partidas_codproveedor", cursor.valueBuffer("codproveedor"));
	curImprimir.setValueBuffer("i_co__subcuentas_codejercicio", codEjercicio);
	
	formco_i_mayor.iface.pub_ponDatosSubcuenta(curImprimir);

	flcontinfo.iface.pub_lanzarInforme(curImprimir, "co_i_mayor", "", "co_subcuentas.codsubcuenta, co_asientos.fecha, co_asientos.numero", "", "", curImprimir.valueBuffer("id"));
}


function euromoda_filtraDocumentos()
{
	var f = "";
	if (this.child("chkRecibosPtes").checked) {
		f = "estado IN ('Emitido', 'Devuelto', 'Remesado') AND importe != 0";
	}
	this.child("tdbRecibos").setFilter(f);
	this.child("tdbRecibos").refresh();
}

function euromoda_dameWhereRecibosSaldo()
{
	return "estado IN ('Emitido', 'Devuelto', 'Remesado') AND importe != 0";
}

function euromoda_establecerSubcuenta() 
{
	var _i = this.iface;
	_i.__establecerSubcuenta();

	_i.filtraPartidasProv();
	var sI = _i.calculateField("saldoinicial");
	sys.setObjText(this, "lblSaldoInicial", sys.translate("Saldo inicial %1").arg(sI));
}

function euromoda_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "saldoinicial": {
			var curSubcuenta = this.child("tdbSubcuentas").cursor();
			var subcuentas = _i.calculateField("listasubcuentas");
			var fechaInicio = AQUtil.sqlSelect("ejercicios", "fechainicio", "codejercicio = '" + curSubcuenta.valueBuffer("codejercicio") + "'");
			if (!fechaInicio) {
				valor = 0;
				break;
			}
			valor = AQUtil.sqlSelect("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento", "SUM(debe-haber)", "p.codsubcuenta IN (" + subcuentas + ") AND a.fecha < '" + fechaInicio + "' AND codproveedor = '" + cursor.valueBuffer("codproveedor") + "'", "co_partidas,co_asientos");
			valor = isNaN(valor) ? 0 : valor;
			valor = AQUtil.formatoMiles(AQUtil.roundFieldValue(valor, "co_partidas", "debe"));
			break;
		}
		case "tipoidfiscal": {
			switch (cursor.valueBuffer("codgrupocontableprov")) {
				case "UE": {
					valor = "NIF/IVA";
					break;
				}
				case "INT": {
					valor = "Otro";
					break;
				}
			}
			break;
		}
		case "codgrupocontableprov": {
			switch (cursor.valueBuffer("tipoidfiscal")) {
				case "NIF/IVA": {
					valor = "UE";
					break;
				}
				case "Otro": {
					valor = "INT";
					break;
				}
			}
			break;
		}
		case "codsubcuenta": {
			valor = _i.commonCalculateField("codsubcuenta", cursor);
			break;
		}
		default: {
			valor = _i.__calculateField(fN);
		}
	}
	return valor;
}

function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.validaCIFEuromoda()) {
		return false;
	}
	return true;
}

function euromoda_validaCIFEuromoda()
{
	var cursor = this.cursor();
	if ((cursor.valueBuffer("tipoidfiscal") == "NIF/IVA" && cursor.valueBuffer("codgrupocontableneg") != "UE") || (cursor.valueBuffer("tipoidfiscal") != "NIF/IVA" && cursor.valueBuffer("codgrupocontableneg") == "UE")) {
		MessageBox.warning(sys.translate("Si el tipo de identificador fiscal es NIF/IVA, el grupo contable de negocio debe ser UE y viceversa"), MessageBox.Ok, MessageBox.NoButton);
    return false;
	}
	if ((cursor.valueBuffer("tipoidfiscal") == "Otro" && cursor.valueBuffer("codgrupocontableneg") != "EXPORT") || (cursor.valueBuffer("tipoidfiscal") != "Otro" && cursor.valueBuffer("codgrupocontableneg") == "EXPORT")) {
		MessageBox.warning(sys.translate("Si el tipo de identificador fiscal es Otro, el grupo contable de negocio debe ser EXPORT y viceversa"), MessageBox.Ok, MessageBox.NoButton);
    return false;
	}
	return true;
}

function euromoda_compruebaSaldo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.modeAccess() != cursor.Edit) {
		return true;
	}
	var codSubcuenta = cursor.valueBuffer("codsubcuenta");
	if (!codSubcuenta || codSubcuenta == "") {
		sys.setObjText(this, "fdbCodSubcuenta", _i.calculateField("codsubcuenta"));
	}
	sys.setObjText(this, "fdbSaldoAnticipos", _i.calculateField("saldoanticipos"));
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "saldoanticipos": {
			valor = parseFloat(AQUtil.sqlSelect("co_partidas", "SUM(debe-haber)", "codsubcuenta IN (" + _i.commonCalculateField("listasubcuentas", cursor) + ") AND codproveedor = '" + cursor.valueBuffer("codproveedor") + "'"));
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
		case "codsubcuenta": {
			valor = AQUtil.sqlSelect("gruposcontablesprov", "codsubcuentaprov", "codgrupo = '" + cursor.valueBuffer("codgrupocontableprov") + "'");
			valor = valor ? valor : "";
			break;
		}
		case "listasubcuentas": {
			valor = _i.dameListaSubcuentas(cursor.valueBuffer("codgrupocontableprov"));
			break;
		}		
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function euromoda_dameListaSubcuentas(codGrupoContableProd)
{
	var _i = this.iface;
	var q = new FLSqlQuery;
	q.setSelect("codsubcuentaprov, codsubcuentaefectos, codsubcuentaefpago, codsubcuentafacpago");
	q.setFrom("gruposcontablesprov");
	q.setWhere("codgrupo = '" + codGrupoContableProd + "'");
	if (!q.exec()) {
		return false;
	}
	if (!q.first()) {
		return "'Not Found'";
	}
	var valor = "";
	valor += ("'" + q.value("codsubcuentaprov") + "'");
	valor += q.value("codsubcuentaefectos") != "" ? (", '" + q.value("codsubcuentaefectos") + "'") : "";
	valor += q.value("codsubcuentaefpago") != "" ? (", '" + q.value("codsubcuentaefpago") + "'") : "";
	valor += q.value("codsubcuentafacpago") != "" ? (", '" + q.value("codsubcuentafacpago") + "'") : "";
debug("lista = " + valor);
	return valor;
}


function euromoda_cancelaAnticipoSaldo(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var cursor = this.cursor();
	var codProveedor = cursor.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Pago")) {
      return false;
    }
  }
	
	
	var tipo1 = t.text(aFilas[0], _i.sIDT);
	var tipo2 = t.text(aFilas[1], _i.sIDT);
	if ((tipo1 == "ANTICIPO" && tipo2 == "RECIBO") || (tipo2 == "ANTICIPO" && tipo1 == "RECIBO")) {
		if (!_i.__cancelaAnticipoSaldo(aFilas)) {
			return false;
		}
	} else if (tipo1 == "RECIBO" && tipo2 == "RECIBO") {
		if (!_i.compensaRecibos(aFilas)) {
			return false;
		}
	} else if ((tipo1 == "PARTIDA" && tipo2 == "RECIBO") || (tipo2 == "PARTIDA" && tipo1 == "RECIBO")) {
		if (!_i.cancelaReciboPartida(aFilas)) {
			return false;
		}
	} else if ((tipo1 == "PARTIDA" && tipo2 == "ANTICIPO") || (tipo2 == "PARTIDA" && tipo1 == "ANTICIPO")) {
		if (!_i.cancelaAnticipoPartida(aFilas)) {
			return false;
		}
	} else if ((tipo1 == "PARTIDA" && tipo2 == "PARTIDA")) {
		if (!_i.cancelaPartidaPartida(aFilas)) {
			return false;
		}
	} else {
		MessageBox.warning(sys.translate("Combinaci�n de tipos de registro no implementada"));
	}
	_i.cargaTablaSaldo();
}

function euromoda_compensaRecibos(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	var curR1 = new FLSqlCursor("recibosprov");
	var curR2 = new FLSqlCursor("recibosprov");
	curR1.select("idrecibo = " + t.text(aFilas[0], _i.sIDD));
	curR2.select("idrecibo = " + t.text(aFilas[1], _i.sIDD));
	if (!curR1.first()) {
		MessageBox.warning(sys.translate("Error al localizar el recibo %1").arg(t.text(aFilas[0], _i.sIDD)), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	if (!curR2.first()) {
		MessageBox.warning(sys.translate("Error al localizar el recibo %1").arg(t.text(aFilas[1], _i.sIDD)), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (_i.compensaRecibosTR(curR1, curR2)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.critical(sys.translate("Error al compensar los recibos"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} catch (e) {
		curT.rollback();
		MessageBox.critical(sys.translate("Error al compensar los recibos: ") + e, MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	return true;
}

function euromoda_compensaRecibosTR(curR1, curR2)
{
	/// Control de que la divisi�n ir� bien
	var importeF1 = AQUtil.sqlSelect("recibosprov", "SUM(importe)", "idfactura = " + curR1.valueBuffer("idfactura"));
	importeF1 = isNaN(importeF1) ? 0 : AQUtil.roundFieldValue(importeF1, "recibosprov", "importe");
	var importeF2 = AQUtil.sqlSelect("recibosprov", "SUM(importe)", "idfactura = " + curR2.valueBuffer("idfactura"));
	importeF2 = isNaN(importeF2) ? 0 : AQUtil.roundFieldValue(importeF2, "recibosprov", "importe");
		
	curR1.setModeAccess(curR1.Edit);
	curR1.refreshBuffer();
	curR2.setModeAccess(curR2.Edit);
	curR2.refreshBuffer();

	if (curR1.valueBuffer("importe") != (curR2.valueBuffer("importe") * -1)) {
		var importe1 = curR1.valueBuffer("importe");
		var importe2 = curR2.valueBuffer("importe");
		var nuevoImporte;
		if (importe1 > importe2) {
			nuevoImporte = importe2 * -1;
			nuevoImporte = AQUtil.roundFieldValue(nuevoImporte, "recibosprov", "importe");
			curR1.setModeAccess(curR1.Edit);
			curR1.refreshBuffer();
			curR1.setValueBuffer("importe", nuevoImporte);
			if (!formRecordrecibosprov.iface.pub_divisionRecibo(curR1, importe1)) {
				return false;
			}
		} else {
			nuevoImporte = importe1 * -1;
			nuevoImporte = AQUtil.roundFieldValue(nuevoImporte, "recibosprov", "importe");
			curR2.setModeAccess(curR2.Edit);
			curR2.refreshBuffer();
			curR2.setValueBuffer("importe", nuevoImporte);
			if (!formRecordrecibosprov.iface.pub_divisionRecibo(curR2, importe2)) {
				return false;
			}
		}
	}
	curR1.setValueBuffer("estado", "Compensado");
	curR1.setValueBuffer("idrecibocomp", curR2.valueBuffer("idrecibo"));
	curR2.setValueBuffer("estado", "Compensado");
	curR2.setValueBuffer("idrecibocomp", curR1.valueBuffer("idrecibo"));
	if (!curR1.commitBuffer()) {
		return false;
	}
	if (!curR2.commitBuffer()) {
		return false;
	}
	
	/// Control de que la divisi�n ha ido bien
	var importeFinF1 = AQUtil.sqlSelect("recibosprov", "SUM(importe)", "idfactura = " + curR1.valueBuffer("idfactura"));
	importeFinF1 = isNaN(importeFinF1) ? 0 : AQUtil.roundFieldValue(importeFinF1, "recibosprov", "importe");
	var importeFinF2 = AQUtil.sqlSelect("recibosprov", "SUM(importe)", "idfactura = " + curR2.valueBuffer("idfactura"));
	importeFinF2 = isNaN(importeFinF2) ? 0 : AQUtil.roundFieldValue(importeFinF2, "recibosprov", "importe");
	if (importeF1 != importeFinF1 || importeF2 != importeFinF2) {
		debug(importeF1 + " != " + importeFinF1 + " O " + importeF2 + " != " + importeFinF2);
		return false;
	}
	return true;
}

function euromoda_cargaOtrosSaldos(aDatos)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codProveedor = cursor.valueBuffer("codproveedor");
	var listaSubcuentas = _i.calculateField("listasubcuentas");
	
	var qPartidas = new FLSqlQuery;
	qPartidas.setSelect("p.idpartida, a.fecha, a.numero, p.importependiente, p.importependientemig");
	qPartidas.setFrom("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento");
	qPartidas.setWhere("p.codproveedor = '" + codProveedor + "' AND p.importependiente <> 0 AND codsubcuenta IN (" + listaSubcuentas + ")");
	qPartidas.setForwardOnly(true)
	if (!qPartidas.exec()) {
		return false;
	}

	var i = aDatos.length;
	while (qPartidas.next()) {
		aDatos[i] = new Object;
		aDatos[i]["id"] = qPartidas.value("p.idpartida");
		aDatos[i]["tipo"] = "PARTIDA";
		aDatos[i]["destipo"] = sys.translate("Partida");
		aDatos[i]["fecha"] = qPartidas.value("a.fecha");
		aDatos[i]["vencimiento"] = "";
		aDatos[i]["estado"] = sys.translate("Pendiente");
		aDatos[i]["codigo"] = qPartidas.value("a.numero");
		aDatos[i]["importeinicial"] = qPartidas.value("p.importependientemig");
		aDatos[i]["importeinicial"] = isNaN(aDatos[i]["importeinicial"]) ? 0 : aDatos[i]["importeinicial"] * -1;
		aDatos[i]["importepte"] = qPartidas.value("p.importependiente");
		aDatos[i]["importepte"] = isNaN(aDatos[i]["importepte"]) ? 0 : aDatos[i]["importepte"] * -1;
		i++;
	}
	return true;
}

function euromoda_cancelaReciboPartida(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var curR = new FLSqlCursor("recibosprov");
	var curP = new FLSqlCursor("co_partidas");
	if (t.text(aFilas[0], _i.sIDT) == "RECIBO") {
		curR.select("idrecibo = " + t.text(aFilas[0], _i.sIDD));
		curP.select("idpartida = " + t.text(aFilas[1], _i.sIDD));
	} else {
		curP.select("idpartida = " + t.text(aFilas[0], _i.sIDD));
		curR.select("idrecibo = " + t.text(aFilas[1], _i.sIDD));
	}
	if (!curR.first()) {
		MessageBox.warning(sys.translate("Error al localizar el recibo"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	if (!curP.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (flfactteso.iface.pub_cancelaReciboProvPartidaTR(curR, curP)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.critical(sys.translate("Error al cancelar el recibo"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} catch (e) {
		curT.rollback();
		MessageBox.critical(sys.translate("Error al al cancelar el recibo: ") + e, MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	return true;
}

function euromoda_cancelaAnticipoPartida(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var curA = new FLSqlCursor("anticiposprov");
	var curP = new FLSqlCursor("co_partidas");
	if (t.text(aFilas[0], _i.sIDT) == "ANTICIPO") {
		curA.select("idanticipo = " + t.text(aFilas[0], _i.sIDD));
		curP.select("idpartida = " + t.text(aFilas[1], _i.sIDD));
	} else {
		curP.select("idpartida = " + t.text(aFilas[0], _i.sIDD));
		curA.select("idanticipo = " + t.text(aFilas[1], _i.sIDD));
	}
	if (!curA.first()) {
		MessageBox.warning(sys.translate("Error al localizar el anticipo"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	if (!curP.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (flfactteso.iface.pub_cancelaAnticipoProvPartidaTR(curA, curP)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.critical(sys.translate("Error al cancelar el anticipo"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} catch (e) {
		curT.rollback();
		MessageBox.critical(sys.translate("Error al al cancelar el anticipo: ") + e, MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	return true;
}

function euromoda_cancelaPartidaPartida(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var curP1 = new FLSqlCursor("co_partidas");
	var curP2 = new FLSqlCursor("co_partidas");
	curP1.select("idpartida = " + t.text(aFilas[0], _i.sIDD));
	curP2.select("idpartida = " + t.text(aFilas[1], _i.sIDD));
	if (!curP1.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida 1"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	if (!curP2.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida 2"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (flfactteso.iface.pub_cancelaPartidaPartidaTR(curP1, curP2)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.critical(sys.translate("Error al cancelar el anticipo"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} catch (e) {
		curT.rollback();
		MessageBox.critical(sys.translate("Error al al cancelar el anticipo: ") + e, MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	return true;
}

function euromoda_tbnEditaAR_clicked()
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	var f = t.currentRow();
	if (t.text(f, _i.sIDT) != "PARTIDA") {
		_i.__tbnEditaAR_clicked();
		return;
	}
	if (_i.curRA) {
		delete _i.curRA;
	}
	_i.curRA = new FLSqlCursor("co_partidas");
	_i.curRA.select("idpartida = " + t.text(f, _i.sIDD));
	if (!_i.curRA.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	disconnect(_i.curRA, "bufferCommited()", _i, "curRA_bufferCommited");
	connect(_i.curRA, "bufferCommited()", _i, "curRA_bufferCommited");
	_i.curRA.browseRecord();
}

function euromoda_coloresSaldo()
{
	var _i = this.iface;
	_i.__coloresSaldo();
	_i.cPar = new Color(255, 150, 130);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

