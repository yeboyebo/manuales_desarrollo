/***************************************************************************
                 em_sustcompocol.qs  -  description
                             -------------------
    begin                : mmie abr 11 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }	
	function validateForm() {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var aSubFam_, aColor_, aTamano_;
	function oficial( context ) { interna( context ); } 
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function calculaDescripcion(referencia) {
		return this.ctx.oficial_calculaDescripcion(referencia);
	}
	function validaCantidades() {
		return this.ctx.oficial_validaCantidades();
	}
	function actualizaPlantillas() {
		return this.ctx.oficial_actualizaPlantillas();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	
	var _i = this.iface;
	var cursor = this.cursor();	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	switch (cursor.modeAccess()) {
		case cursor.Insert: {			
			this.child("fdbDescripcionCol").setValue(AQUtil.sqlSelect("em_colecciones","descripcion","codcoleccionem = '" + cursor.valueBuffer("codcoleccionem") + "'"));				
			break;
		}		
	}
}

function interna_validateForm()
{
	var _i = this.iface;
	if(!_i.validaCantidades()) {
		return false;
	}

	if(!_i.actualizaPlantillas()) {
		return false;
	}

	return true;	
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
debug("oficial_bufferChanged " + fN);
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {	
		case "referenciasust": {
			 sys.setObjText(this, "fdbDescripcionSust", _i.calculaDescripcion(cursor.valueBuffer("referenciasust")));
			break;
		}
		case "referencianueva": {
 			sys.setObjText(this, "fdbDescripcionNueva", _i.calculaDescripcion(cursor.valueBuffer("referencianueva")));
			break;
		}    
		default: {
		}
	}
}

function oficial_calculaDescripcion(referencia)
{
	var _i = this.iface;
	

	var qArt = new AQSqlQuery;	
	qArt.setSelect("descripcion,codtamanoem,codcolorem");
	qArt.setFrom("articulos");
	qArt.setWhere("referencia = '" + referencia + "'");
	debug("qArt: "+qArt.sql());						
	if (!qArt.exec()){
		return;
	}  
	if(!qArt.first())
	{
		return false;
	}

	var descripcion  = qArt.value("descripcion"); 
	var codTamano = qArt.value("codtamanoem"); 
	var codColor = qArt.value("codcolorem"); 
	
	if(codTamano && codTamano != "") {
		descripcion += " " + codTamano;
	}

	if(codColor && codColor != "") {
		descripcion += " " + codColor;
	}
	return descripcion;
}

function oficial_validaCantidades()
{
	var cursor = this.cursor();
	var cantSust = cursor.valueBuffer("cantsust");
	var cantNueva = cursor.valueBuffer("cantnueva");

	if((!cantNueva || cantNueva == 0) && cantSust != 0)  {
		flfactppal.iface.ponMsgError(sys.translate("Debe especificar la nueva cantidad"),"warn",this);
		return false;
	}
	return true;
}

/*function oficial_actualizaPlantillas()
{
	var _i = this.iface;	
	var cursor = this.cursor();
	var codColeccion = cursor.valueBuffer("codcoleccionem");
	var referenciaSust = cursor.valueBuffer("referenciasust");
	var referenciaNueva = cursor.valueBuffer("referencianueva");
	var cantSust = cursor.valueBuffer("cantsust");
	var cantNueva = cursor.valueBuffer("cantnueva");
	var descNueva = cursor.valueBuffer("descripcionnueva");
	debug("codColeccion: "+codColeccion);
	debug("referenciaSust: "+referenciaSust);
	debug("referenciaNueva: "+referenciaNueva);
	debug("cantSust: "+cantSust);
	debug("cantNueva: "+cantNueva);
	debug("descNueva: "+descNueva);

	if(AQUtil.sqlSelect("em_plantillasprod","codcoleccionem","codcoleccionem = '" + codColeccion + "'")) {
		var res = flfactppal.iface.preguntaMsg(sys.translate("La colecci�n tiene plantillas propias, los cambios se van a aplicar a las plantillas de esta colecci�n.\n�Est� seguro?"),"info",this,MessageBox.Yes, MessageBox.No);  
  		if (res != MessageBox.Yes) {
			return false; 
  		}

  		var cambiaRef = false;
  		var cambiaCant = false;
  		var cantidadFijo;
  		var idLinea;
		var q = new AQSqlQuery;	
		q.setSelect("l.cantidad, l.idlinea");
		q.setFrom("em_lineasplantillaprod l");
		q.setWhere("l.codcoleccionplan = '" + codColeccion + "' and l.refcomponente = '" + referenciaSust + "' and l.tipo = 'Fijo'");	


		debug("\n\n query de lineas de plantilla: "+q.sql());
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			cantidadFijo = q.value("l.cantidad");
			idLinea = q.value("l.idlinea");

			debug("cantidadFijo: "+cantidadFijo);
			debug("idLinea: "+idLinea);

			if((isNaN(cantidadFijo)|| !cantidadFijo || cantidadFijo == "") && (isNaN(cantNueva) || !cantNueva || cantNueva == "")) {
				debug("se cambia la referencia, no la cantidad");
				cambiaRef = true;	
				cambiaCant = false;
			
			} else if ((isNaN(cantidadFijo) || !cantidadFijo || cantidadFijo == "") && (cantNueva && cantNueva != "")) {
				debug("cambiamos referencia y cantidad");
				cambiaRef = true;	
				cambiaCant = true;

		
			} else if ((cantidadFijo && cantidadFijo != "") && (isNaN(cantNueva) || !cantNueva || cantNueva == "")) {
				debug("aviso Debe especificar la nueva cantidad y no dejar continuar");
				flfactppal.iface.ponMsgError(sys.translate("Debe especificar la nueva cantidad"),"warn",this);
				return false;
			} else  {
				cambiaRef = true;
				debug("cambiareferencia");
				if(parseFloat(cantSust) == parseFloat(cantidadFijo)) {
					debug("Se cambia la referencia y la cantidad solo si ambas coinciden con los valores actuales");
					cambiaCant = true;
				}
			}	

			if(cambiaRef) {

				var qArt = new AQSqlQuery;	
				qArt.setSelect("codsubfamilia,codtamanoem,codcolorem,codunidad");
				qArt.setFrom("articulos");
				qArt.setWhere("referencia = '" + referenciaNueva + "'");
				debug("qArt: "+qArt.sql());						
				if (!qArt.exec()){
					return;
				}  
				if(!qArt.first())
				{
					return false;
				}
				var codSubfamilia = qArt.value("codsubfamilia");
				var codTamano = qArt.value("codtamanoem"); 

				var codColor = qArt.value("codcolorem"); 
				var codUnidad = qArt.value("codunidad");

				var setUpdate =  "refcomponente = '" + referenciaNueva  + "',desccomponente = '" + descNueva + "', codsubfamilia = '" + codSubfamilia + "', codtamanopanot = '" + codTamano + "',codtamanocont = '" + codTamano + "', codcolorem = '" + codColor + "', codunidad = '" + codUnidad + "'";

				if(cambiaCant) {
					setUpdate += ", cantidad = " + cantNueva;	
				}

				if(!AQUtil.execSql("UPDATE em_lineasplantillaprod SET " + setUpdate + " WHERE idlinea = " + idLinea)) {
 					return false;
 				}	
			}
		}
		cursor.setValueBuffer("aplicado",true);
	}
}*/

function oficial_actualizaPlantillas()
{
	var _i = this.iface;	
	var cursor = this.cursor();
	var codColeccion = cursor.valueBuffer("codcoleccionem");
	var referenciaSust = cursor.valueBuffer("referenciasust");
	var referenciaNueva = cursor.valueBuffer("referencianueva");
	var cantSust = cursor.valueBuffer("cantsust");
	var cantNueva = cursor.valueBuffer("cantnueva");
	var descNueva = cursor.valueBuffer("descripcionnueva");
	debug("codColeccion: "+codColeccion);
	debug("referenciaSust: "+referenciaSust);
	debug("referenciaNueva: "+referenciaNueva);
	debug("cantSust: "+cantSust);
	debug("cantNueva: "+cantNueva);
	debug("descNueva: "+descNueva);

	if(AQUtil.sqlSelect("em_plantillasprod","codcoleccionem","codcoleccionem = '" + codColeccion + "'")) {
		var res = flfactppal.iface.preguntaMsg(sys.translate("La colecci�n tiene plantillas propias, los cambios se van a aplicar a las plantillas de esta colecci�n.\n�Est� seguro?"),"info",this,MessageBox.Yes, MessageBox.No);  
  		if (res != MessageBox.Yes) {
			return false; 
  		}

  		var cambiaRef = false;
  		var cambiaCant = false;
  		var buscar = 0;
  		var cantidadFijo;
  		var idLinea;
  		var where = "l.codcoleccionplan = '" + codColeccion + "' and l.refcomponente = '" + referenciaSust + "' and l.tipo = 'Fijo'";	

		if(cantSust && cantSust != 0 && cantNueva && cantNueva !=0) {
			//busco plantillas donde la cantidad sea igual a la cantidad a sustituir y sustituyo cantidad y referencia
			cambiaRef = true;	
			cambiaCant = true;
			where += " and l.cantidad = " + cantSust ;

		} else if ((!cantSust || cantSust == 0) && cantNueva != 0) {
			// busco plantillas donde coincida la referencia sin mirar la cantidad y sustituyo cantidad y referencia
			cambiaRef = true;	
			cambiaCant = true;
			buscar = 2;			


		} else if ((!cantSust || cantSust == 0) && (!cantNueva || cantNueva == 0)) {
			// busco plantillas donde coincida la referencia sin mirar la cantidad y sustituyo la referencia
			cambiaRef = true;	
			cambiaCant = false;
			buscar = 3;

		}

		var q = new AQSqlQuery;	
		q.setSelect("l.cantidad, l.idlinea");
		q.setFrom("em_lineasplantillaprod l");
		q.setWhere(where);	
		debug("\n\n query de lineas de plantilla: "+q.sql());
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{			
			idLinea = q.value("l.idlinea");
			debug("cantidadFijo: "+cantidadFijo);
			debug("idLinea: "+idLinea);

			if(cambiaRef) {

				var qArt = new AQSqlQuery;	
				qArt.setSelect("codsubfamilia,codtamanoem,codcolorem,codunidad");
				qArt.setFrom("articulos");
				qArt.setWhere("referencia = '" + referenciaNueva + "'");
				debug("qArt: "+qArt.sql());						
				if (!qArt.exec()){
					return;
				}  
				if(!qArt.first())
				{
					return false;
				}
				var codSubfamilia = qArt.value("codsubfamilia");
				var codTamano = qArt.value("codtamanoem"); 

				var codColor = qArt.value("codcolorem"); 
				var codUnidad = qArt.value("codunidad");

				var setUpdate =  "refcomponente = '" + referenciaNueva  + "',desccomponente = '" + descNueva + "', codsubfamilia = '" + codSubfamilia + "', codtamanopanot = '" + codTamano + "',codtamanocont = '" + codTamano + "', codcolorem = '" + codColor + "', codunidad = '" + codUnidad + "'";

				if(cambiaCant) {
					setUpdate += ", cantidad = " + cantNueva;	
				}

				if(!AQUtil.execSql("UPDATE em_lineasplantillaprod SET " + setUpdate + " WHERE idlinea = " + idLinea)) {
 					return false;
 				}	
			}
 		}
 		cursor.setValueBuffer("aplicado",true);
 	}
 	return true;	
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////