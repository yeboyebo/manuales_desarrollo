# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa
import json

# pr_tareas = qsa.class_("pr_tareas")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */
class Oficial(Base):

    def get(self, params, username=None):

        mapa = self.get_mapa()
        obj = qsa.from_project("formAPI").get_resources('pr_tareas', params, mapa, username)

        return obj

    def terminarTarea(self, params, username=None):
        session = qsa.thread_session_new()
        session.begin()
        obj = qsa.from_project("formau_automata").iface.terminarTareaJson(params["idTarea"])
        session.commit()
        return obj


    def get_mapa(self):
        return {
            'join': 'pr_tareas',
            'order': 'idtarea',
            'map': {
                'idtarea': {'field': 'pr_tareas.idtarea', 'type': 'string'},
                'estado': {'field': 'pr_tareas.estado', 'type': 'string'},
                'descripcion': {'field': 'pr_tareas.descripcion', 'type': 'string'},
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
