
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends anticipos {
	function euromoda( context ) { anticipos ( context ); }
	function validarCuentaBancaria(cursor) {
		return this.ctx.euromoda_validarCuentaBancaria(cursor);
	}
	function init() {
		return this.ctx.euromoda_init();
	}
	function controlPartidaSaldo() {
		return this.ctx.euromoda_controlPartidaSaldo();
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
    function cambiarEstado() {
        return this.ctx.euromoda_cambiarEstado();
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_validarCuentaBancaria(cursor)
{
	debug("euromoda_validarCuentaBancaria " + cursor.valueBuffer("em_codpago"));
	var _i = this.iface;
	if (!_i.__validarCuentaBancaria(cursor)) {
		return false;
	}
	if (AQUtil.sqlSelect("em_formaspago", "domiciliado", "em_codpago = '" + cursor.valueBuffer("em_codpago") + "'")) {
		var codCuenta = cursor.valueBuffer("codcuenta");
		if (!codCuenta || codCuenta == "") {
			MessageBox.warning(sys.translate("Ha elegido una forma de pago domiciliado. Debe indicar la cuenta de domiciliaci�n del cliente"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
	}
	return true;
}

function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	_i.controlPartidaSaldo();
}

function euromoda_controlPartidaSaldo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idSaldoPartida = cursor.valueBuffer("em_idsaldopartida");
	if (idSaldoPartida != 0) {
		this.child("lblRemesado").text = "PARTIDA";


        if(this.child("pushButtonNext")) {        
          this.child("pushButtonNext").close();
        }

        if(this.child("pushButtonPrevious")) {            
          this.child("pushButtonPrevious").close();
        }

        if(this.child("pushButtonFirst")) {
          this.child("pushButtonFirst").close();            
        }

        if(this.child("pushButtonLast")) {
          this.child("pushButtonLast").close();            
        }

        if(this.child("pushButtonAcceptContinue")) {            
          this.child("pushButtonAcceptContinue").close();
        }

        if(this.child("pushButtonAccept")) {            
          this.child("pushButtonAccept").close();
        }

		this.child("fdbFechav").setDisabled(true);
		this.child("fdbImporte").setDisabled(true);
		this.child("fdbCodCuenta").editor().setDisabled(true);;
		this.child("coddir").editor().setDisabled(true);;
		this.child("fdbDescripcion").editor().setDisabled(true);
		this.child("fdbCtaEntidad").editor().setDisabled(true);
		this.child("fdbCtaAgencia").editor().setDisabled(true);
		this.child("fdbCuenta").editor().setDisabled(true);
		this.child("gbxPagDev").close();

		this.child("groupBoxAnt").close();
		
// 		var tdbAnt:Object = this.child("tdbAnticipo");
// 		tdbAnt.setReadOnly(true);
// 		tdbAnt.cursor().setMainFilter("idanticipo = " + idAnticipo);
// 		tdbAnt.refresh();
		
	} else {
		this.child("groupBoxPar").close();
		this.iface.__init();
	}
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var util= new FLUtil();
	var valor:String;
	switch (fN) {
		case "estado": {
			var idPartida = cursor.valueBuffer("em_idsaldopartida");
			if (idPartida && idPartida != 0) {
				valor = "Pagado";
			} else {
				valor = _i.__commonCalculateField(fN, cursor);
			}
			break;
		}
    default: {
			valor = _i.__commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function euromoda_cambiarEstado()
{
    var _i = this.iface;
    var cursor = this.cursor();
    var estado = cursor.valueBuffer("estado");
    if (estado == "Compensado") {
        const codReciboComp = AQUtil.sqlSelect("reciboscli", "codigo", "idrecibo = " + cursor.valueBuffer("idrecibocomp"))
        this.child("lblRemesado").text = "Compensado con\n" + codReciboComp;
        this.child("fdbFechav").setDisabled(true);
        this.child("fdbImporte").setDisabled(true);
        this.child("fdbCodCuenta").setDisabled(true);   
        this.child("tdbPagosDevolCli").setInsertOnly(true);
        if(this.child("pushButtonNext")) {
            this.child("pushButtonNext").close();
        }
        if(this.child("pushButtonNext")) {
            this.child("pushButtonPrevious").close();            
        }
        if(this.child("pushButtonNext")) {            
            this.child("pushButtonFirst").close();
        }
        if(this.child("pushButtonNext")) {
            this.child("pushButtonLast").close();            
        }
        this.child("gbxPagDev").enabled = false;//pineboo 21-08-2019
    } else {
        _i.__cambiarEstado();
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
