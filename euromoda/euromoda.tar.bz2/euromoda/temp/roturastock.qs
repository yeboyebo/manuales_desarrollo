
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var AFALTAS, DISPO, DISPOPTERX;
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function consultaBusqueda() {
		return this.ctx.euromoda_consultaBusqueda();
	}
	function construirWhere() {
		return this.ctx.euromoda_construirWhere();
	}
	function iniciarTabla() {
		return this.ctx.euromoda_iniciarTabla();
	}
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function incluirDatosExtraFila(fila, qryArticulos) {
		return this.ctx.euromoda_incluirDatosExtraFila(fila, qryArticulos);
	}
	function iniciarTabla() {
		return this.ctx.euromoda_iniciarTabla();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_consultaBusqueda()
{
	var _i = this.iface;
	
	var q = _i.__consultaBusqueda();
	q.setSelect("ap.codproveedor, p.nombre, a.referencia, a.descripcion, a.stockmin, a.stockmax, ap.plazo, s.reservada, s.cantidad, s.idstock, s.disponible, s.pterecibir, s.disponiblepterecibir, s.afaltas");
debug("consulta " + q.sql());
	return q;
}

function euromoda_construirWhere()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	w += " AND NOT a.fabricado"; /// Si se quita esto hay que ver el tema de la generaci�n autom�tica de lotes
	
	var w = _i.__construirWhere();
	var codDibujo = cursor.valueBuffer("coddibujoem");
	if (codDibujo) {
		w += " AND a.coddibestamp = " + codDibujo;
	}
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	if (codSubfamilia) {
		w += " AND a.codsubfamilia = '" + codSubfamilia + "'";
	}
	var codColeccion = cursor.valueBuffer("codcoleccionem");
	if (codColeccion) {
		w += " AND a.codcoleccionem = '" + codColeccion + "'";
	}
	var soloAFaltas = cursor.valueBuffer("soloafaltas");
	if (soloAFaltas) {
		w += " AND s.afaltas > 0";
	}
	return w;
}

function euromoda_init()
{
	var _i = this.iface;
	
	_i.__init();
	this.child("fdbCodSerie").close();
}

function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	switch (fN) {
		case "coddibujoem":
		case "codsubfamilia":
		case "soloafaltas":
		case "codcolecionem": {
				if (_i.estado == "Seleccionando") {
					_i.estado = "Buscando";
					_i.gestionEstado();
				}
				break;
			}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_incluirDatosExtraFila(fila, qryArticulos)
{
	var _i = this.iface;
	var tblArticulos = this.child("tblArticulos");
	tblArticulos.setText(fila, _i.AFALTAS, qryArticulos.value("s.afaltas"));
	tblArticulos.setText(fila, _i.DISPO, qryArticulos.value("s.disponible"));
	tblArticulos.setText(fila, _i.DISPOPTERX, qryArticulos.value("s.disponiblepterecibir"));
	return true;
}

function euromoda_iniciarTabla()
{
	var _i = this.iface;
	var tblArticulos = this.child("tblArticulos");
	
	var c = 0, sep = "*", cab = "";
	_i.INCLUIR = c++;
	cab += sys.translate("Incluir") + sep;
	_i.NUMPEDIDO = c++;
	cab += sys.translate("N�") + sep;
	_i.CODPROVEEDOR = c++;
	cab += sys.translate("C.P.") + sep;
	_i.NOMPROVEEDOR = c++;
	cab += sys.translate("Proveedor") + sep;
	_i.REFERENCIA = c++;
	cab += sys.translate("Ref.") + sep;
	_i.DESARTICULO = c++;
	cab += sys.translate("Art�culo") + sep;
	_i.FECHAPEDIDO = c++;
	cab += sys.translate("F.Pedido") + sep;
	_i.PLAZO = c++;
	cab += sys.translate("Plazo") + sep;
	_i.FECHAROTURA = c++;
	cab += sys.translate("F.Rotura") + sep;
	_i.STOCKACTUAL = c++;
	cab += sys.translate("Actual") + sep;
	_i.STOCKMIN = c++;
	cab += sys.translate("M�nimo") + sep;
	_i.STOCKMAX = c++;
	cab += sys.translate("M�ximo") + sep;
	_i.AFALTAS = c++;
	cab += sys.translate("A Faltas") + sep;
	_i.DISPO = c++;
	cab += sys.translate("Disponible") + sep;
	_i.DISPOPTERX = c++;
	cab += sys.translate("Disp.P.R.") + sep;
	_i.PEDIR = c++;
	cab += sys.translate("Pedir") + sep;
	_i.IDSTOCK = c++;
	cab += sys.translate("idStock") + sep;
	
	tblArticulos.setNumCols(c);
	tblArticulos.setColumnLabels(sep, cab);
	
	tblArticulos.setColumnWidth(_i.INCLUIR, 40);
	tblArticulos.setColumnWidth(_i.NUMPEDIDO, 40);
	tblArticulos.setColumnWidth(_i.CODPROVEEDOR, 60);
	tblArticulos.setColumnWidth(_i.NOMPROVEEDOR, 150);
	tblArticulos.setColumnWidth(_i.REFERENCIA, 80);
	tblArticulos.setColumnWidth(_i.DESARTICULO, 150);
	tblArticulos.setColumnWidth(_i.FECHAPEDIDO, 80);
	tblArticulos.hideColumn(_i.PLAZO);
	tblArticulos.hideColumn(_i.FECHAROTURA);
	tblArticulos.setColumnWidth(_i.STOCKACTUAL, 50);
	tblArticulos.setColumnWidth(_i.STOCKMIN, 50);
	tblArticulos.setColumnWidth(_i.STOCKMAX, 50);
	tblArticulos.setColumnWidth(_i.AFALTAS, 50);
	tblArticulos.setColumnWidth(_i.DISPO, 50);
	tblArticulos.setColumnWidth(_i.STOCKMAX, 50);
	tblArticulos.setColumnWidth(_i.DISPOPTERX, 50);
	tblArticulos.hideColumn(_i.IDSTOCK);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
