
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends numLineaProv
{
  function euromoda(context)
  {
    numLineaProv(context);
  }
  function dameColor(nombre)
  {
    return this.ctx.euromoda_dameColor(nombre);
  }
  function datosCtaCliente(codCliente, valoresDefecto)
  {
    return this.ctx.euromoda_datosCtaCliente(codCliente, valoresDefecto);
  }
  function datosCtaProveedor(codProveedor, valoresDefecto)
  {
    return this.ctx.euromoda_datosCtaProveedor(codProveedor, valoresDefecto);
  }
  function asociarFacturaLiq(idFactura, codLiquidacion)
  {
    return this.ctx.euromoda_asociarFacturaLiq(idFactura, codLiquidacion);
  }
  function obtenFiltroFacturas(codAgente, desde, hasta, codEjercicio)
  {
    return this.ctx.euromoda_obtenFiltroFacturas(codAgente, desde, hasta, codEjercicio);
  }
  function calcularLiquidacionAgente(where)
  {
    return this.ctx.euromoda_calcularLiquidacionAgente(where);
  }
  function beforeCommit_em_periodosaseguradora(curPeriodo)
  {
    return this.ctx.euromoda_beforeCommit_em_periodosaseguradora(curPeriodo);
  }
  function estableceGlobalInit()
  {
    return this.ctx.euromoda_estableceGlobalInit();
  }
  function beforeCommit_clientes(curCliente) {  
  	 return this.ctx.euromoda_beforeCommit_clientes(curCliente);	
  }
  function calcularCodCliente(curCliente) {
  	return this.ctx.euromoda_calcularCodCliente(curCliente);
  }
	function validaFormatoCod(codCliente) {
		return this.ctx.euromoda_validaFormatoCod(codCliente);
	}
	function extension(nE) {
		return this.ctx.euromoda_extension(nE);
	}
	function validaSubcuentasGIN(curGCIPN) {
		return this.ctx.euromoda_validaSubcuentasGIN(curGCIPN);
	}
	function validaSubcuentaREP(curGCIPN) {
		return this.ctx.euromoda_validaSubcuentaREP(curGCIPN);
	} 
	function validaSubcuentaSOP(curGCIPN) {
		return this.ctx.euromoda_validaSubcuentaSOP(curGCIPN);
	} 
	function validaSubcuentaREC(curGCIPN)  {
		return this.ctx.euromoda_validaSubcuentaREC(curGCIPN);	
	} 
	function validaSubcuentaREV(curGCIPN) {
		return this.ctx.euromoda_validaSubcuentaREV(curGCIPN);	
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_dameColor(nombre)
{
	var _i = this.iface;
	var color;
	switch (nombre) {
		case "tinta_verde": {
			color = "#006C00";
			break;
		}
		case "fondo_facturado": {
			color = _i.dameColor("fondo_violeta");
			break;
		}
		case "fondo_violeta": {
			color = "#AA7BA5";
			break;
		}
		case "fondo_rojo_sel": {
			color = "#640000";
			break;
		}
		case "fondo_cliente_bloqueado": {
			color = _i.dameColor("fondo_rojo");
			break;
		}
		case "fondo_cliente_bloqueado_sel": {
			color = _i.dameColor("fondo_rojo_sel");
			break;
		}
		case "fondo_azul": {
			color = "#8DD4D4";
			break;
		}
		case "fondo_azul_sel": {
			color = "#00557F";
			break;
		}
		case "fondo_verde": {
			color = "#80D380";
			break;
		}
		case "fondo_verde_sel": {
			color = "#004600";
			break;
		}
		case "fondo_gris": {
			color = "#EEEEEE";
			break;
		}
		case "fondo_gris_sel": {
			color = "#555555";
			break;
		}
		case "fondo_naranja": {
			color = "#FFBA2F";
			break;
		}
		case "fondo_defecto": {
			color = "#F1F1F1";
			break;

		}
		default:{
			color = _i.__dameColor(nombre);
		}
	}
	return color;
}

function euromoda_datosCtaCliente(codCliente, valoresDefecto)
{
  if (!codCliente || codCliente == "") {
    return flfacturac.iface.pub_datosCtaEspecial("CLIENT", valoresDefecto.codejercicio);
  }
  var ctaCliente = [];
  ctaCliente["codsubcuenta"] = "";
  ctaCliente["idsubcuenta"] = "";

  var codSubcuenta = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli g ON c.codgrupocontablecli = g.codgrupo", "g.codsubcuentacli", "c.codcliente = '" + codCliente + "'", "clientes,gruposcontablescli");
  if (!codSubcuenta) {
    MessageBox.warning(sys.translate("No hay ninguna subcuenta asociada al cliente %1").arg(codCliente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    ctaCliente.error = 1;
    return ctaCliente;
  }
  var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + valoresDefecto.codejercicio + "'");
  if (!idSubcuenta) {
    MessageBox.warning(sys.translate("No exista la subcuenta %1 en el ejercicio %2").arg(codSubcuenta).arg(valoresDefecto.codejercicio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
    ctaCliente.error = 1;
    return ctaCliente;
  }
  ctaCliente["codsubcuenta"] = codSubcuenta;
  ctaCliente["idsubcuenta"] = idSubcuenta;
  ctaCliente.error = 0;
  return ctaCliente;
}

function euromoda_datosCtaProveedor(codProveedor, valoresDefecto)
{
  if (!codProveedor || codProveedor == "") {
    return flfacturac.iface.pub_datosCtaEspecial("PROVEE", valoresDefecto.codejercicio);
  }
  var ctaProv = [];
  ctaProv["codsubcuenta"] = "";
  ctaProv["idsubcuenta"] = "";

	var codSubcuenta = AQUtil.sqlSelect("proveedores p INNER JOIN gruposcontablesprov g ON p.codgrupocontableprov = g.codgrupo", "g.codsubcuentaprov", "p.codproveedor = '" + codProveedor + "'", "proveedores,gruposcontablesprov");
  if (!codSubcuenta) {
    MessageBox.warning(sys.translate("No hay ninguna subcuenta asociada al proveedor %1").arg(codProveedor), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    ctaProv.error = 1;
    return ctaProv;
  }
  var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + valoresDefecto.codejercicio + "'");
  if (!idSubcuenta) {
    MessageBox.warning(sys.translate("No exista la subcuenta %1 en el ejercicio %2").arg(codSubcuenta).arg(valoresDefecto.codejercicio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
    ctaProv.error = 1;
    return ctaProv;
  }
  ctaProv["codsubcuenta"] = codSubcuenta;
  ctaProv["idsubcuenta"] = idSubcuenta;
  ctaProv.error = 0;
  return ctaProv;
}

function euromoda_asociarFacturaLiq(idFactura, codLiquidacion)
{
  var _i = this.iface;

  if (!_i.__asociarFacturaLiq(idFactura, codLiquidacion)) {
    return false;
  }
	var recalcularComision = _i.valorDefecto("em_reccomliq");
	if(!recalcularComision) {
		return true;
	}
  var curLF = new FLSqlCursor("lineasfacturascli");
  curLF.setActivatedCheckIntegrity(false);
  curLF.setActivatedCommitActions(false);
  curLF.select("idfactura = " + idFactura);
  while (curLF.next()) {
    curLF.setModeAccess(curLF.Edit);
    curLF.refreshBuffer();
    curLF.setValueBuffer("porcomision", formRecordlineaspedidoscli.iface.pub_commonCalculateField("porcomision", curLF));
    if (!curLF.commitBuffer()) {
      return false;
    }
  }
  return true;
}

function euromoda_obtenFiltroFacturas(codAgente, desde, hasta, codEjercicio)
{
  var filtro: String = "facturascli.idfactura IN (SELECT DISTINCT facturascli.idfactura FROM facturascli INNER JOIN lineasfacturascli ON facturascli.idfactura = lineasfacturascli.idfactura WHERE 1 = 1";
  if (codAgente && codAgente != "") {
    filtro += " AND facturascli.codagente = '" + codAgente + "'";
  }
  if (codEjercicio && codEjercicio != "") {
    filtro += " AND codejercicio = '" + codEjercicio + "'";
  }
  filtro += " AND (facturascli.codliquidacion = '' OR facturascli.codliquidacion IS NULL) AND facturascli.fecha >= '" + desde + "' AND facturascli.fecha <= '" + hasta + "')";
  return filtro;
}

function euromoda_calcularLiquidacionAgente(where)
{
  var qryFacturas = new FLSqlQuery();
  qryFacturas.setTablesList("facturascli,lineasfacturascli");
  qryFacturas.setSelect("pordtoesp, coddivisa, tasaconv, facturascli.porcomision, lineasfacturascli.porcomision, neto, facturascli.idfactura, lineasfacturascli.pvptotal");
  qryFacturas.setFrom("facturascli INNER JOIN lineasfacturascli ON facturascli.idfactura = lineasfacturascli.idfactura");
  qryFacturas.setWhere(where);
  if (!qryFacturas.exec()) {
    return false;
  }
  var total = 0;
  var comision = 0;
  var tasaconv = 0;
  var divisaEmpresa = AQUtil.sqlSelect("empresa", "coddivisa", "1=1");
  var idfactura = 0, porDtoEsp;
  var comisionFactura = false;
  while (qryFacturas.next()) {
    porDtoEsp = qryFacturas.value("pordtoesp");
    porDtoEsp = isNaN(porDtoEsp) ? 0 : porDtoEsp;
    if (!idfactura || idfactura != qryFacturas.value("facturascli.idfactura")) {
      idfactura = qryFacturas.value("facturascli.idfactura");
      if (parseFloat(qryFacturas.value("facturascli.porcomision"))) {
        comisionFactura = true;
        comision = parseFloat(qryFacturas.value("facturascli.porcomision")) * parseFloat(qryFacturas.value("neto")) / 100;
        tasaconv = parseFloat(qryFacturas.value("tasaconv"));
        if (qryFacturas.value("coddivisa") == divisaEmpresa) {
          total += comision;
        } else {
          total += comision * tasaconv;
        }
      } else {
        comisionFactura = false;
      }
    }
    if (!comisionFactura) {
      comision = parseFloat(qryFacturas.value("lineasfacturascli.porcomision")) * ((parseFloat(qryFacturas.value("lineasfacturascli.pvptotal")) * (100 - porDtoEsp)) / 100) / 100;
      tasaconv = parseFloat(qryFacturas.value("tasaconv"));
      if (qryFacturas.value("coddivisa") == divisaEmpresa) {
        total += comision;
      } else {
        total += comision * tasaconv ;
      }
    }
  }
  return total;
}

function euromoda_estableceGlobalInit()
{
	return true; /// No se establece para que funcione la sincronizaci�n de art�culos con la llamada desde scripts
}

function euromoda_beforeCommit_em_periodosaseguradora(curPeriodo)
{
	if (curPeriodo.modeAccess() == curPeriodo.Insert || curPeriodo.modeAccess() == curPeriodo.Edit) {
	
		var fdesde = curPeriodo.valueBuffer("fdesde").toString();
		var fhasta = curPeriodo.valueBuffer("fhasta").toString();
		
		if(!fhasta || fhasta == "") {
			fhasta = "2999-12-31T00:00:00";
		}
		
		var iniPeriodo = new Date(Date.parse(fdesde));
		var finPeriodo = new Date(Date.parse(fhasta));
		
		if(finPeriodo && finPeriodo != "" && iniPeriodo > finPeriodo) {
			sys.warnMsgBox(sys.translate("La fecha de inicio debe ser menor que la de fin."));
			return false;
		}
		
		var compFdesde = AQUtil.sqlSelect("em_periodosaseguradora", "id", "fdesde <= '" + iniPeriodo + "' AND (fhasta >= '" + iniPeriodo + "' OR fhasta is null)" + " AND id <> " + curPeriodo.valueBuffer("id"));
		
		var compFhasta = AQUtil.sqlSelect("em_periodosaseguradora", "id", "fdesde <= '" + finPeriodo + "' AND (fhasta >= '" + iniPeriodo + "' OR fhasta is null)" +	" AND id <> " + curPeriodo.valueBuffer("id"));
		
		if (compFdesde) {
			sys.warnMsgBox(sys.translate("La fecha de inicio del per�odo se superpone a un per�odo ya existente."));
			return false;
		}
		if (compFhasta) {
			sys.warnMsgBox(sys.translate("La fecha de fin del per�odo se superpone a un per�odo ya existente."));
			return false;
		}
	}

	return true;
}

function euromoda_beforeCommit_clientes(curCliente)
{
	var _i = this.iface;
	if(!_i.calcularCodCliente(curCliente)) {
		return false;
	}

	if(!_i.__beforeCommit_clientes(curCliente)) {
		return false;
	}	
	return true;
}

function euromoda_calcularCodCliente(curCliente)
{
	var _i = this.iface;
	var codCliente = curCliente.valueBuffer("codcliente");
	if (curCliente.modeAccess() != curCliente.Insert) {
		return true;
	}
	if(codCliente != "AUTO") {		
		if(!_i.validaFormatoCod(codCliente)) {
			return false;
		}		
	} else {
		
		var secuencia = _i.valorDefecto("secuenciacliente");
		var encontrado = false;
		secuencia++;
		while(!encontrado) {
			debug("secuencia: "+secuencia);
			codCliente = flfactppal.iface.pub_cerosIzquierda(secuencia,6);
			debug("codCliente: "+codCliente);
			if(AQUtil.sqlSelect("clientes","codcliente","codcliente = '" + codCliente + "'")	) {
				secuencia++;
			} else {
				encontrado = true;
			}		
		}		
		curCliente.setValueBuffer("codcliente",codCliente);
		AQUtil.sqlUpdate("factppal_general","secuenciacliente", secuencia,"id=1");	
	}

	return true;	
}

function euromoda_validaFormatoCod(codCliente)
{
	var validos = "1234567890";
	for (var i = 0; i < codCliente.length; i++) {
		if (validos.find(codCliente.charAt(i)) < 0) {	
			sys.warnMsgBox(sys.translate("El c�digo de cliente debe de contener �nicamente n�meros"));
			return false;
		}
	}
	
	return true;
}

function euromoda_extension(nE)
{
	var _i = this.iface;
	if (nE == "cont_nav") {
		return true;
	}
	return _i.__extension(nE);
}

function euromoda_validaSubcuentasGIN(curGCIPN)
{
	var codsubcuentaREP = curGCIPN.valueBuffer("codsubcuentarep");
	var codsubcuentaSOP = curGCIPN.valueBuffer("codsubcuentasop");
	var codsubcuentaREC = curGCIPN.valueBuffer("codsubcuentarec");
	var codsubcuentaREV = curGCIPN.valueBuffer("codsubcuentarev");

	if(codsubcuentaREP && codsubcuentaREP != "" && codsubcuentaSOP && codsubcuentaSOP != "" && codsubcuentaREP == codsubcuentaSOP) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta para IVA repercutido no puede ser igual a la subcuenta para para IVA soportado"),"warn",this);
	} else if(codsubcuentaREP && codsubcuentaREP != "" && codsubcuentaREC && codsubcuentaREC != "" && codsubcuentaREP == codsubcuentaREC) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta para IVA repercutido no puede ser igual a la subcuenta para recargo de equivalencia"),"warn",this);
	} else if(codsubcuentaREP && codsubcuentaREP != "" && codsubcuentaREV && codsubcuentaREV != "" && codsubcuentaREP == codsubcuentaREV) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta para IVA repercutido no puede ser igual a la subcuenta IVA de reversi�n"),"warn",this);
	} else if(codsubcuentaSOP && codsubcuentaSOP != "" && codsubcuentaREC && codsubcuentaREC != "" && codsubcuentaSOP == codsubcuentaREC) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta para IVA soportado no puede ser igual a la subcuenta para recargo de equivalencia"),"warn",this);
	} else if(codsubcuentaSOP && codsubcuentaSOP != "" && codsubcuentaREV && codsubcuentaREV != "" && codsubcuentaSOP == codsubcuentaREV) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta para IVA soportado no puede ser igual a la subcuenta para IVA de reversi�n"),"warn",this);
	} else if(codsubcuentaREC && codsubcuentaREC != "" && codsubcuentaREV && codsubcuentaREV != "" && codsubcuentaREC == codsubcuentaREV) {		
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta para recargo de equivalencia no puede ser igual a la subcuenta para IVA de reversi�n"),"warn",this);
	}
	return true;
}

function euromoda_validaSubcuentaREP(curGCIPN)
{
	
	var codsubcuentaREP = curGCIPN.valueBuffer("codsubcuentarep");
	
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentasop = '" + codsubcuentaREP + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA repercutido\nest� asignada como subcuenta para IVA Soportado en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarec = '" + codsubcuentaREP + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA repercutido\n est� asignada como subcuenta para Recargo de equivalencia en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarev = '" + codsubcuentaREP + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA repercutido\n est� asignada como subcuenta para IVA Reversi�n en otro registro."),"warn",this);
	}
	return true;
}

function euromoda_validaSubcuentaSOP(curGCIPN)
{
	
	var codsubcuentaSOP = curGCIPN.valueBuffer("codsubcuentasop");
	
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarep = '" + codsubcuentaSOP + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA Soportado\nest� asignada como subcuenta para IVA Repercutido en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarec = '" + codsubcuentaSOP + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA Soportado\nest� asignada como subcuenta para Recargo de equivalencia en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarev = '" + codsubcuentaSOP + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA Soportado\nest� asignada como subcuenta para IVA Reversi�n en otro registro."),"warn",this);
	}
	return true;	
}

function euromoda_validaSubcuentaREC(curGCIPN)
{
	
	var codsubcuentaREC = curGCIPN.valueBuffer("codsubcuentarec");
	
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentasop = '" + codsubcuentaREC + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para Recargo de equivalencia\nest� asignada como subcuenta para IVA Soportado en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarep = '" + codsubcuentaREC + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para Recargo de equivalencia\nest� asignada como subcuenta para IVA Repercutido en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarev = '" + codsubcuentaREC + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para Recargo de equivalencia\nest� asignada como subcuenta para IVA Reversi�n en otro registro."),"warn",this);
	}
	return true;	
}

function euromoda_validaSubcuentaREV(curGCIPN)
{
	
	var codsubcuentaREV = curGCIPN.valueBuffer("codsubcuentarev");

	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentasop = '" + codsubcuentaREV + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA Reversi�n\nest� asignada como subcuenta para IVA Soportado en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarec = '" + codsubcuentaREV + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA Reversi�n\nest� asignada como subcuenta para Recargo de equivalencia en otro registro."),"warn",this);
	}
	if(AQUtil.sqlSelect("gruposcontablesivaproneg","id","codsubcuentarep = '" + codsubcuentaREV + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("La subcuenta seleccionada para IVA Reversi�n\nest� asignada como subcuenta para IVA Repercutido en otro registro."),"warn",this);
	}
	return true;	
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
