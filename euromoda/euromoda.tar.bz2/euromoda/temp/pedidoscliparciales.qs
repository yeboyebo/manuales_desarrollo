
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var codAlmacenPpal_;
	var idAlbaran_ = false;
	function euromoda( context ) { oficial ( context ); }
	function maxCantidadAIncluir(curLinea) {
		return this.ctx.euromoda_maxCantidadAIncluir(curLinea);
	}
	function dameCantidadParcial(curLinea) {
		return this.ctx.euromoda_dameCantidadParcial(curLinea);
	}
	function lineaServida(curLinea) {
		return this.ctx.euromoda_lineaServida(curLinea);
	}
	function incluirLineaAlbaran(curLinea, canAlbaran) {
		return this.ctx.euromoda_incluirLineaAlbaran(curLinea, canAlbaran);
	}
	function calculaSiIncluirLinea(incluir, curLineas) {
		return this.ctx.euromoda_calculaSiIncluirLinea(incluir, curLineas);
	}
	function saltarLineaInclusion(curLineas) {
		return this.ctx.euromoda_saltarLineaInclusion(curLineas);
	}
	function ordenarCols() {
		return this.ctx.euromoda_ordenarCols();
	}
	function init() {
		return this.ctx.euromoda_init();
	}
	function formReady() {
		return this.ctx.euromoda_formReady();
	}
	function calcularTotales() {
		return this.ctx.euromoda_calcularTotales();
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function validaDropshipping() {
		return this.ctx.euromoda_validaDropshipping();
	}
	function filtrarLineas() {
		return this.ctx.euromoda_filtrarLineas();
	}
	function dameFiltroLineas() {
		return this.ctx.euromoda_dameFiltroLineas();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_maxCantidadAIncluir(curLinea)
{
debug("euromoda_maxCantidadAIncluir " + curLinea.valueBuffer("referencia"));
	var _i = this.iface;
	var cursor = this.cursor();
	var max = _i.__maxCantidadAIncluir(curLinea);
	if (cursor.action() != "em_pedidoscliparciales") {
		return max;
	}
	if (AQUtil.sqlSelect("articulos", "nostock", "referencia = '" + curLinea.valueBuffer("referencia") + "'")) {
		debug("euromoda_maxCantidadAIncluir1 " + max);
		return max;
	}
	var idLinea = curLinea.valueBuffer("idlinea");
	var maxL = formem_pedidosptes.iface.pub_dameMaximoLineaPedido(idLinea);
	maxL = maxL ? maxL : 0;
	max = max > maxL ? maxL : max;
	debug("euromoda_maxCantidadAIncluir2 " + max);
	return max;
}

function euromoda_dameCantidadParcial(curLinea)
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.action() != "em_pedidoscliparciales") {
		return _i.__dameCantidadParcial(curLinea);
	}
	var idLinea = curLinea.valueBuffer("idlinea");
	var max = _i.__maxCantidadAIncluir(curLinea);
	var cantidad = parseFloat(curLinea.valueBuffer("cantidad"));	
	var servida = parseFloat(curLinea.valueBuffer("totalenalbaran"));
	var maxL = cantidad - servida;
	max = max > maxL ? maxL : max;
	var referencia = curLinea.valueBuffer("referencia");
	var canDis = AQUtil.sqlSelect("stocks", "disponible", "referencia = '" + referencia + "' AND codalmacen = '" + _i.codAlmacenPpal_ + "'");
	canDis = isNaN(canDis) ? 0 : canDis;
	
/// Consultar con Jos� c�mo nos aseguramos de que si aumentamos la cantidad la tome de las reservas de otros pedidos del mismo cliente
// 	var maxOtrosPedCliente = AQUtil.sqlSelect("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN movistock ms ON lp.idlinea = ms.idlineapc", "SUM(reservaex)", "p.codcliente = '" + cursor.valueBuffer("codcliente") + "' AND NOT lp.cerrada AND lp.cantidad > lp.totalenalbaran AND lp.referencia = '" + curLinea.valueBuffer("referencia") + "' AND lp.idlinea <> " + idLinea, "pedidoscli");
// 	maxOtrosPedCliente = isNaN(maxOtrosPedCliente) ? 0 : maxOtrosPedCliente;
// 	
// 	var cantidad = Input.getNumber(sys.translate("Indique la cantidad (+%1 en disponible) (+%2 en otros pedidos cliente)").arg(canDis).arg(maxOtrosPedCliente), max, 2, 0);
	
	var cantidad = Input.getNumber(sys.translate("Indique la cantidad (+%1 en disponible)").arg(canDis), max, 2, 0);
	max += canDis;
// 	max += maxOtrosPedCliente;
	if (cantidad > max) {
		sys.warnMsgBox(sys.translate("La cantidad no puede ser superior a la m�xima cantidad albaranable + disponible (%1)").arg(max));
// 		sys.warnMsgBox(sys.translate("La cantidad no puede ser superior a la m�xima cantidad albaranable + disponible + reservada existencias en otros pedido de cliente (%1)").arg(max));
		return false;
	}
	return cantidad;
}

function euromoda_lineaServida(curLinea)
{
	var _i = this.iface;
	if (curLinea.valueBuffer("tipoconcepto") == "Texto") {
		return false;
	} else {
		return _i.__lineaServida(curLinea);
	}
}

function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	_i.codAlmacenPpal_ = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
	connect(this, "formReady()", _i, "formReady");
	connect(this.child("chkSoloPendientes"), "clicked()", _i, "filtrarLineas");
	if(_i.idAlbaran_ && _i.idAlbaran_ != "") {
		this.child("chkSoloPendientes").checked = true; 
	}
	_i.filtrarLineas();
}

function euromoda_formReady()
{
	this.child("fdbCodAgencia").setValue("");
	this.child("fdbBultos").setValue("");
}

function euromoda_incluirLineaAlbaran(curLinea, canAlbaran)
{
	var _i = this.iface;
	if (curLinea.valueBuffer("tipoconcepto") == "Texto") {
		return true;
	} else {
		return _i.__incluirLineaAlbaran(curLinea, canAlbaran);
	} 
}

function euromoda_calculaSiIncluirLinea(incluir, curLineas)
{
	var _i = this.iface;
	var canAlbaran = _i.maxCantidadAIncluir(curLineas);
	return (incluir && (curLineas.valueBuffer("tipoconcepto") == "Texto" || canAlbaran));
}

function euromoda_saltarLineaInclusion(curLineas)
{
	var _i = this.iface;
	var saltar = _i.__saltarLineaInclusion(curLineas);
	saltar = saltar && curLineas.valueBuffer("tipoconcepto") != "Texto";
	return saltar;
}

function euromoda_ordenarCols()
{
	var _i = this.iface;
	var lineas = ["referencia", "descripcion", "codtamanoem", "codcolorem", "cantidad", "totalenalbaran","cerrada", "incluiralbaran", "canalbaran"];
	_i.tdbLineasPedidosCli.setOrderCols(lineas);
}

function euromoda_calcularTotales()
{
	var cursor = this.cursor();
	cursor.setValueBuffer("netosindtoesp",formpedidoscli.iface.pub_commonCalculateField("netosindtoesp", cursor));
	cursor.setValueBuffer("dtoesp",formpedidoscli.iface.pub_commonCalculateField("dtoesp", cursor));
	
	
	this.iface.__calcularTotales();
}

function euromoda_validateForm()
{
	var _i = this.iface;
	/** No existe todav�a
	if (!_i.__validateForm()) {
		return false;
	}
	*/
	if (!_i.validaDropshipping()) {
		return false;
	}
	debug("\n\nvalida a true el validate form");
	return true;
}

function euromoda_validaDropshipping()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codD = cursor.valueBuffer("em_coddropshipping");
	if (!codD || codD == "") {
		return true;
	}
	if (AQUtil.sqlSelect("lineaspedidoscli", "idlinea", "idpedido = " + cursor.valueBuffer("idpedido") + " AND cantidad <> totalenalbaran + canalbaran")) {
		//sys.warnMsgBox(sys.translate("Est� albaranando un pedido de dropshipping, debe enviar todo el material solicitado en el pedido"));
		var res = flfactppal.iface.preguntaMsg(sys.translate("Est� albaranando un pedido de dropshipping, DEBER�A INTENTAR enviar todo el material solicitado en el pedido. El albar�n se emitir�.\n�Desea continuar?"),"warn",this,MessageBox.Yes, MessageBox.No);  
		if (res != MessageBox.Yes) {
		return false;
		}		
	}
	return true;
}

function euromoda_filtrarLineas()
{
	var _i = this.iface;
	
	var filtro = _i.dameFiltroLineas();
	if (filtro && filtro != "") {			
		filtro = "(" + filtro + ")";
	} else {
		filtro = "1=1";
	}
	debug("filtro " + filtro);
		
	this.child("tdbLineasPedidosCli").cursor().setMainFilter(filtro);
	this.child("tdbLineasPedidosCli").refresh();


}

function euromoda_dameFiltroLineas()
{
	var _i = this.iface;
	var filtro = "";
	if (this.child("chkSoloPendientes").checked) {
		filtro += "(cantidad-totalenalbaran>0)";
	}
	if(_i.idAlbaran_ && _i.idAlbaran_ != "") {
		if(filtro && filtro != "") {
			filtro += " OR ";
		} 

		filtro += "lineaspedidoscli.idpedido IN (SELECT idpedido FROM lineasalbaranescli WHERE idalbaran = " + _i.idAlbaran_ + ")";
	}
	return filtro;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
