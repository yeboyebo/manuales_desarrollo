/***************************************************************************
                 em_masterplantillasprod.qs  -  description
                             -------------------
    begin                : lun dic 4 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); }
	function copiarPlantilla_clicked() {
		return this.ctx.oficial_copiarPlantilla_clicked();
	}	
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El Al copiar un art�culo se copian tambi�n sus tarifas y sus precios por proveedor.
\end */
function interna_init()
{
	var _i = this.iface;	

	connect(this.child("toolButtonCopy"), "clicked()", _i, "copiarPlantilla_clicked()");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_copiarPlantilla_clicked()
{
 
  	var cursor = this.cursor();
	var f = new FLFormSearchDB("em_plantillasprodcopy");
	var curG = f.cursor();
	curG.setModeAccess(curG.Insert);
	curG.refreshBuffer();
	curG.setValueBuffer("codcoleccionem",cursor.valueBuffer("codcoleccionem"));
	curG.setValueBuffer("codsubfamilia",cursor.valueBuffer("codsubfamilia"));
	curG.setValueBuffer("codtamanoem",cursor.valueBuffer("codtamanoem"));
	curG.setValueBuffer("codcolorem",cursor.valueBuffer("codcolorem"));
	curG.setValueBuffer("idplantillaori",cursor.valueBuffer("idplantilla"));
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);

	f.setMainWidget();

	try {
		var id = f.exec("idplantilla");
		if (id) {
			curT.commit();			
			flfactppal.iface.ponMsgError(sys.translate("Plantilla creada correctamente."),"info",this);
		} else {
			flfactppal.iface.ponMsgError(sys.translate("Error al copiar la plantilla."),"warn",this);
			curT.rollback();

		}
	} catch(e) {
		curT.rollback();
		flfactppal.iface.ponMsgError(sys.translate("Error al copiar la plantilla."),"warn",this);
		return false;
	}
	if(this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();	
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////