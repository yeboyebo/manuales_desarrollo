
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {	
	var COL_FECHAVALOR;
	function euromoda( context ) { prod ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function ocultarCamposContabilidad() {
	   return this.ctx.euromoda_ocultarCamposContabilidad();
 	}	
 	function insertarLineaTabla(curPedidos) {
 		return this.ctx.euromoda_insertarLineaTabla(curPedidos);
 	} 	
 	function generarTabla() {
 		return this.ctx.euromoda_generarTabla();
 	}
 	function dameCabecera() {
 		return this.ctx.euromoda_dameCabecera();
 	}
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	cursor.setValueBuffer("em_optfechavalor","Agrupar por fecha valor");
}

function euromoda_ocultarCamposContabilidad()
{
	return true;
}

function euromoda_dameCabecera()
{
	var _i = this.iface;
	var cabecera = _i.__dameCabecera();
	cabecera = cabecera +"/Fecha valor";
	return cabecera;
}

function euromoda_generarTabla()
{
	
	var _i = this.iface;
	_i.__generarTabla();
	var numCols =_i.tblPedidos_.numCols();	
	_i.COL_FECHAVALOR = numCols;
	numCols = parseInt(numCols)+1;	
	_i.tblPedidos_.setNumCols(numCols);
	_i.tblPedidos_.setColumnLabels("/", _i.dameCabecera());
}

function euromoda_insertarLineaTabla(curPedidos)
{
	var _i = this.iface;
	var numLinea = _i.tblPedidos_.numRows();
	_i.__insertarLineaTabla(curPedidos);	
	var fechaValor = curPedidos.valueBuffer("fechavalor");
	if(fechaValor && fechaValor != "") {
		fechaValor = AQUtil.dateAMDtoDMA(fechaValor);
	}
	_i.tblPedidos_.setText(numLinea, _i.COL_FECHAVALOR, fechaValor);
}

//// EUROMODA /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
