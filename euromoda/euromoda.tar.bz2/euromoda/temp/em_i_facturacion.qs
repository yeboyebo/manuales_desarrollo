/***************************************************************************
                 em_i_facturacion.qs  -  description
                             -------------------
    begin                : mar feb 17 2014
    copyright            : (C) 2014 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 
/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  function oficial( context ) { interna( context ); } 
  function bufferChanged(fN:String) {
    return this.ctx.oficial_bufferChanged(fN);
  }
	function cargaAgentes() {
		this.ctx.oficial_cargaAgentes();
	}
	function guardaAgentes() {
		return this.ctx.oficial_guardaAgentes();
	}
	function chkAgentesSel_clicked() {
		return this.ctx.oficial_chkAgentesSel_clicked();
	}
	function cargaSeries() {
		this.ctx.oficial_cargaSeries();
	}
	function guardaSeries() {
		return this.ctx.oficial_guardaSeries();
	}
	function chkSeriesSel_clicked() {
		return this.ctx.oficial_chkSeriesSel_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
  function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  	var _i = this.iface;
  	var cursor = this.cursor()
  
  	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("chkAgentesSel"), "clicked()", _i, "chkAgentesSel_clicked");
	connect(this.child("chkSeriesSel"), "clicked()", _i, "chkSeriesSel_clicked");
	
	_i.cargaAgentes();
	_i.cargaSeries();
	_i.chkAgentesSel_clicked();
	_i.chkSeriesSel_clicked();
}

function interna_validateForm()
{
	var _i = this.iface;
  var cursor = this.cursor()
  
  if (!_i.guardaAgentes()) {
		MessageBox.warning(sys.translate("Error al guardar la lista de agentes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
  if (!_i.guardaSeries()) {
		MessageBox.warning(sys.translate("Error al guardar la lista de series"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_chkAgentesSel_clicked()
{
	var _i = this.iface;
	var filtro;
	if (this.child("chkAgentesSel").checked) {
		var aAgentes = this.child("tdbAgentes").primarysKeysChecked();
		filtro = "1 = 2";
		if (aAgentes) {
			filtro = "codagente IN ('" + aAgentes.join("', '") + "')";
		}
	} else {
		filtro = "";
	}
	this.child("tdbAgentes").setFilter(filtro);
	this.child("tdbAgentes").refresh();
}

function oficial_chkSeriesSel_clicked()
{
	var _i = this.iface;
	var filtro;
	if (this.child("chkSeriesSel").checked) {
		var aSeries = this.child("tdbSeries").primarysKeysChecked();
		filtro = "1 = 2";
		if (aSeries) {
			filtro = "codserie IN ('" + aSeries.join("', '") + "')";
		}
	} else {
		filtro = "";
	}
	this.child("tdbSeries").setFilter(filtro);
	this.child("tdbSeries").refresh();
}

function oficial_cargaAgentes()
{
	var _i = this.iface;
  var cursor = this.cursor()

	var listaAgentes = cursor.valueBuffer("listaagentes");
	if (!listaAgentes || listaAgentes == "") {
		return;
	}
	var aAgentes = listaAgentes.split(",");
	for (var a = 0; a < aAgentes.length; a++) {
		this.child("tdbAgentes").setPrimaryKeyChecked(aAgentes[a], true);
	}
}

function oficial_cargaSeries()
{
	var _i = this.iface;
  var cursor = this.cursor()

	var listaSeries = cursor.valueBuffer("listaseries");
	if (!listaSeries || listaSeries == "") {
		return;
	}
	var aSeries = listaSeries.split(",");
	for (var a = 0; a < aSeries.length; a++) {
		this.child("tdbSeries").setPrimaryKeyChecked(aSeries[a], true);
	}
}

function oficial_guardaAgentes()
{
	var _i = this.iface;
  var cursor = this.cursor()
  
  var aAgentes = this.child("tdbAgentes").primarysKeysChecked();
	if (aAgentes) {
		cursor.setValueBuffer("listaagentes", aAgentes.join(","));
	} else {
		cursor.setNull("listaagentes");
	}
	return true;
}

function oficial_guardaSeries()
{
	var _i = this.iface;
  var cursor = this.cursor()
  
  var aSeries = this.child("tdbSeries").primarysKeysChecked();
	if (aSeries) {
		cursor.setValueBuffer("listaseries", aSeries.join(","));
	} else {
		cursor.setNull("listaseries");
	}
	return true;
}

function oficial_bufferChanged(fN)
{
	var cursor = this.cursor(); 

	if(fN == "codintervalo") {
		if(cursor.valueBuffer("codintervalo")){
			intervalo = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalo"));
			cursor.setValueBuffer("d_v_fecha", intervalo.desde);
			cursor.setValueBuffer("h_v_fecha", intervalo.hasta);
		}
	} else if(fN == "coddibestamp") {
		cursor.setValueBuffer("dibujos", cursor.valueBuffer("coddibestamp"));
	}
  
}


/*function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "cstockmin": {
			if (cursor.valueBuffer("cstockmin") != "S�") {
				this.child("fdbStockMin").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "descatalogado": {
			if (cursor.valueBuffer("descatalogado") == "S�") {
				this.child("fdbFechaDes").setValue(cursor.valueBuffer("fecha"));
			} else {
				this.child("fdbFechaDes").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "debaja": {
			if (cursor.valueBuffer("debaja") == "S�") {
				this.child("fdbFechaBaja").setValue(cursor.valueBuffer("fecha"));
			} else {
				this.child("fdbFechaBaja").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "aliquidar": {
			if (cursor.valueBuffer("aliquidar") == "S�") {
				this.child("fdbFechaLiq").setValue(cursor.valueBuffer("fecha"));
			} else {
				this.child("fdbFechaLiq").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "coddibestamp":{
			cursor.setValueBuffer("dibujos", cursor.valueBuffer("coddibestamp"));
			break;
		}
		case "codsubfamiliac": {
			if(cursor.valueBuffer("codsubfamiliac") != "") {
				cursor.setValueBuffer("codfamiliac",_i.calculateField("codfamiliac"));	
			}			
			_i.habilitaChecks();
			break;
		}		
		case "cambiarcostes": 
		case "eliminarcostes": 
		case "eliminarmargenes": 
		case "em_tipocoste":
		case "em_tipomargen": {
			_i.habilitaCostes();
			break;
		}
		case "aumentarcoste": {
			_i.habilitaAumentoCoste();
			break;
		}
		case "disminuircoste": {
			_i.habilitaDisminuirCoste();
			break;
		}
		case "aumentarmargen":{
			_i.habilitaAumentoMargen();
			break;
		}
		case "disminuirmargen": {
			_i.habilitaDisminuirMargen();
			break;
		}
	}
  
}*/


//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
