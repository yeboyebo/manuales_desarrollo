
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
  var esTejidoCrudo_;
  function euromoda( context ) { prod ( context ); }
  function init() {
    return this.ctx.euromoda_init();
  }
  function validateForm() {
    return this.ctx.euromoda_validateForm();
  }
  function calculateField(fN) {
    return this.ctx.euromoda_calculateField(fN);
  }
  function habilitaPartida() {
    return this.ctx.euromoda_habilitaPartida();
  }
  function filtraPartida() {
    return this.ctx.euromoda_filtraPartida();
  }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function validaPartida() {
    return this.ctx.euromoda_validaPartida();
  }
  function ordenTabulacion() {
    return this.ctx.euromoda_ordenTabulacion();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
  var cursor = this.cursor();
  
  switch (cursor.modeAccess()) {
  case cursor.Insert: {
    _i.habilitaPartida();
    _i.esTejidoCrudo_ = false;
    _i.filtraPartida();
    break;
  }
  case cursor.Edit: {
      _i.esTejidoCrudo_ = _i.calculateField("estejidocrudo");
      this.child("fdbCodPartida").setDisabled(true);
      break;
    }
  }
  _i.ordenTabulacion();
	this.child("fdbReferencia").setFocus();
}

function euromoda_ordenTabulacion()
{
	return;//
	var controles = this.child("fdbReferencia").obj().enabled ? ["fdbReferencia", "fdbNombreDesArticulos", "fdbCodPartida", "fdbCantidad"] : ["fdbReferencia", "fdbNombreDesArticulos", "fdbCantidad"];
	for (var i = 0; i < controles.length - 1; i++) {
		if (this.child(controles[i]) && this.child(controles[i + 1])) {
			AQS.setTabOrder(this.child(controles[i]).obj(), this.child(controles[i + 1]).obj());
		}
	}
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
		case "estejidocrudo": {
      var referencia = cursor.valueBuffer("referencia");
			valor = flfactalma.iface.pub_esReferenciaXPartidas(referencia);
      break;
    }
    default: {
			valor = _i.__calculateField(fN);
			break;
		}
  }
  return valor;
}

function euromoda_habilitaPartida()
{
  var _i = this.iface;
  this.child("fdbCodPartida").setDisabled(!_i.esTejidoCrudo_); 
	_i.ordenTabulacion();
}

function euromoda_filtraPartida()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var codAlmaOrigen = cursor.cursorRelation().valueBuffer("codalmaorigen");
  this.child("fdbCodPartida").setFilter("referencia = '" + cursor.valueBuffer("referencia") + "' AND codalmacen = '" + codAlmaOrigen + "' AND estado = 'TERMINADO' AND NOT distribucionfin");
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
  case "referencia": {
      _i.__bufferChanged(fN);
      _i.esTejidoCrudo_ = _i.calculateField("estejidocrudo");
      _i.habilitaPartida();
      if (!_i.esTejidoCrudo_) {
        sys.setObjText(this, "fdbCodPartida", "");
      } else {
        _i.filtraPartida();
      }
      break;
    }
  default: {
      _i.__bufferChanged(fN);
    }
  }
}
  
function euromoda_validateForm()
{
  var _i = this.iface;
  /*
    if (!_i.__validateForm()) {
    return false;
    }
    */
  if (!_i.validaPartida()) {
    return false;
  }
  return true;
}

function euromoda_validaPartida()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codPartida = cursor.valueBuffer("codpartida");
	if(flfactalma.iface.pub_esPartidaXTramos(codPartida)) {
		sys.warnMsgBox(sys.translate("La partida %1 es una partida que contiene tramos y no se puede hacer la transferencia desde esta acci�n.\nDebe de realizar la transferencia desde 'Generar bobinas' en el �rea de estampaci�n").arg(codPartida));
		return false;
	}
	if (!_i.esTejidoCrudo_) {
		return true;
	}
	if (cursor.modeAccess() != cursor.Insert) {
		return true;
	}

	if (!codPartida || codPartida == "") {
		MessageBox.warning(sys.translate("Si el art�culo es de tejido en crudo debe establecer la partida origen"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	var referencia = cursor.valueBuffer("referencia");
	var codAlmaOrigen = cursor.cursorRelation().valueBuffer("codalmaorigen");
	if (!AQUtil.sqlSelect("lotesstock", "codlote", "codlote = '" + codPartida + "' AND estado = 'TERMINADO' AND codalmacen = '" + codAlmaOrigen + "' AND referencia = '" + referencia + "'")) {
		MessageBox.warning(sys.translate("La partida no es de la referencia %1, no pertenece al almac�n %2 o no est� en estado TERMINADO").arg(referencia).arg(codAlmaOrigen), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	var codPartida = cursor.valueBuffer("codpartida");
	var pteDist = AQUtil.sqlSelect("lotesstock", "mptedist", "codlote = '" + codPartida + "'");
	pteDist = isNaN(pteDist) ? 0 : pteDist;
	pteDist = AQUtil.roundFieldValue(pteDist, "lotesstock", "mptedist");

	var cantidad = cursor.valueBuffer("cantidad");
	if (cantidad > pteDist) {
		MessageBox.warning(sys.translate("La cantidad es mayor que el total pendiente de distribuir de la partida %1").arg(codPartida), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	return true;
}  
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
