
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
class euromoda extends oficial {
	var codAlmacenPpal_;
	var idAlbaran_ = false;
	var curLineaPed_;
	var curReserva_;
	var curTS_;

	//var refReserva_;
    function euromoda( context ) { oficial ( context ); }
    function init() {
    	return this.ctx.euromoda_init();
    }
    function maxCantidadAIncluir(curLinea) {
		return this.ctx.euromoda_maxCantidadAIncluir(curLinea);
	}
    function tbnBuscarAgencia_clicked() {
    	return this.ctx.euromoda_tbnBuscarAgencia_clicked();
    }
    function dameSelect() {
    	return this.ctx.euromoda_dameSelect();
    }
    function colorCelda(f, c) {
    	return this.ctx.euromoda_colorCelda(f, c);
    }
	function anchoColumnasTabla()  {
		return this.ctx.euromoda_anchoColumnasTabla();
	}
	function dameCantidadParcial(curLinea) {
		return this.ctx.euromoda_dameCantidadParcial(curLinea);
	}
	function lineaServida(fila) {
		return this.ctx.euromoda_lineaServida(fila);
	}
	function formReady() {
		return this.ctx.euromoda_formReady();
	}
	function generarAlbaran() {
		return this.ctx.euromoda_generarAlbaran();
	}
	function regenerarLineasAlbaran(idAlbaran) {
		return this.ctx.euromoda_regenerarLineasAlbaran(idAlbaran);
	}
	function validaDropshipping() {
		return this.ctx.euromoda_validaDropshipping();
	}
	function filtrarLineas() {
		return this.ctx.euromoda_filtrarLineas();
	}
	function dameFiltroLineas() {
		return this.ctx.euromoda_dameFiltroLineas();
	}
	function dameFrom() {
		return this.ctx.euromoda_dameFrom();
	}
	function incluirFila(fila) {
		return this.ctx.euromoda_incluirFila(fila);
	}
	function pbnIncluirParcial_clicked() {
		return this.ctx.euromoda_pbnIncluirParcial_clicked();
	}
	function incluirFilaParcial(fila) {
		return this.ctx.euromoda_incluirFilaParcial(fila);
	}
	function habilitarColumnas() {
		return this.ctx.euromoda_habilitarColumnas();
	}
	function incluirLineaAlbaran(fila, cantPorAlbaranar) {
		return this.ctx.euromoda_incluirLineaAlbaran(fila, cantPorAlbaranar);
	}
	function limpiaLineas(idPedido) {
		return this.ctx.euromoda_limpiaLineas(idPedido);
	}
	function conectarEventosTabla() {
		return this.ctx.euromoda_conectarEventosTabla();
	}	
	function accionLineaPedido(accion) {
		return this.ctx.euromoda_accionLineaPedido(accion);
	}	
	function refrescarLinea() {
		return this.ctx.euromoda_refrescarLinea();
	}
	function refrescarTabla() {
		return this.ctx.euromoda_refrescarTabla();
	}
	function toolButtomInsert_clicked() {
		return this.ctx.euromoda_toolButtomInsert_clicked();
	}
	function toolButtonEdit_clicked() {
		return this.ctx.euromoda_toolButtonEdit_clicked();	
	}
	function toolButtonDelete_clicked() {
		return this.ctx.euromoda_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.euromoda_toolButtonZoom_clicked();
	}
	function tbnTraspasoStock_clicked() {
    	return this.ctx.euromoda_tbnTraspasoStock_clicked();
	}
	function tbnReservas_clicked() {
    	return this.ctx.euromoda_tbnReservas_clicked();
  	}
  	function actualizaCantidadLineas() {
  		return this.ctx.euromoda_actualizaCantidadLineas();
  	}
  	function dameCabecera() {
  		return this.ctx.euromoda_dameCabecera();
  	}
  	function estoyEditandoAlbaran() {
  		return this.ctx.euromoda_estoyEditandoAlbaran();
  	}
  	function dameWhere() {
  		return this.ctx.euromoda_dameWhere();
  	}
  	function guardaCamposPedido() {
  		return this.ctx.euromoda_guardaCamposPedido();
  	}
  	function actualizaCabeceraAlbaran() {
  		return this.ctx.euromoda_actualizaCabeceraAlbaran();
  	}
	function leAgencia_lostFocus() {
		return this.ctx.euromoda_leAgencia_lostFocus();
	}
	function leBultos_lostFocus() {
		return this.ctx.euromoda_leBultos_lostFocus();
	}
	function lePesoBruto_lostFocus() {
		return this.ctx.euromoda_lePesoBruto_lostFocus();
	}
	function leVolumen_lostFocus() {
		return this.ctx.euromoda_leVolumen_lostFocus();
	}
	function cargaCamposPedido(idAlbaran) {
		return this.ctx.euromoda_cargaCamposPedido(idAlbaran);
	}
	function abrirCerrarLinea() {
		return this.ctx.euromoda_abrirCerrarLinea();
	}
	function totalizaPedido(idPedido) {
		return this.ctx.euromoda_totalizaPedido(idPedido);
	}
	function totalizaPedidoLinea(idPedido) {
		return this.ctx.euromoda_totalizaPedidoLinea(idPedido);
	}
	function totalesPedido(idPedido) {
		return this.ctx.euromoda_totalesPedido(idPedido);
	}
	function pbnExcluir_clicked() {
		return this.ctx.euromoda_pbnExcluir_clicked();
	}
	function pbnExcluirTodos_clicked() {
		return this.ctx.euromoda_pbnExcluirTodos_clicked();
	}
	function pbnIncluirTodos_clicked() {
		return this.ctx.euromoda_pbnIncluirTodos_clicked();
	}
	function pbnIncluir_clicked() {
		return this.ctx.euromoda_pbnIncluir_clicked();
	}
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idPedido = cursor.valueBuffer("idpedido");
	if (idPedido) {
		_i.limpiaLineas(idPedido);
	}
	_i.__init();
	connect(this.child("tbnBuscarAgencia"), "clicked()", _i, "tbnBuscarAgencia_clicked");	
	_i.codAlmacenPpal_ = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
	connect(this, "formReady()", _i, "formReady");
	connect(this.child("chkSoloPendientes"), "clicked()", _i, "filtrarLineas");
	connect(this.child("pbnIncluirParcial"), "clicked()", _i, "pbnIncluirParcial_clicked");

	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");

	connect(this.child("tbnTraspasoStock"), "clicked()", _i, "tbnTraspasoStock_clicked");
	connect(this.child("tbnReservas"), "clicked()", _i, "tbnReservas_clicked()");

	connect(this.child("leAgencia"), "lostFocus()", _i, "leAgencia_lostFocus");
	connect(this.child("leBultos"), "lostFocus()", _i, "leBultos_lostFocus");	
	connect(this.child("lePesoBruto"), "lostFocus()", _i, "lePesoBruto_lostFocus");	
	connect(this.child("leVolumen"), "lostFocus()", _i, "leVolumen_lostFocus");
	if(_i.idAlbaran_ && _i.idAlbaran_ != "") {
		this.child("chkSoloPendientes").checked = true; 
	}

	_i.cargaCamposPedido(_i.idAlbaran_);
	
	_i.curReserva_ = new FLSqlCursor("stocks");
	_i.curReserva_.setAction("em_reservasstock");
	_i.filtrarLineas();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	} else {
		this.child("lblEstado").close();
	}

}

function euromoda_maxCantidadAIncluir(fila)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var max = _i.__maxCantidadAIncluir(fila);

	if(_i.estoyEditandoAlbaran()) { 
		var cantAlbActual = parseFloat(_i.tblLineasPedido_.cellValue(fila, "lineasalbaranescli.cantidad"));
		if(!cantAlbActual || cantAlbActual == "") {
			cantAlbActual = 0;
		}
		max = max + cantAlbActual;
	}

	if (cursor.action() != "em_pedidoscliparciales") {
		return max;
	}
	var referencia = _i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.referencia");
	if (AQUtil.sqlSelect("articulos", "nostock", "referencia = '" + referencia + "'")) {
		return max;
	}
	var idLinea = _i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.idlinea");
	var maxL = formem_pedidosptes.iface.pub_dameMaximoLineaPedido(idLinea);
	maxL = maxL ? maxL : 0;
	max = max > maxL ? maxL : max;
	return max;
}

function euromoda_pbnIncluirParcial_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	
	var filaActual = _i.tblLineasPedido_.table().currentRow();
	
	if(_i.tblLineasPedido_.cellValue(filaActual, "lineaspedidoscli.cerrada")){
		sys.infoMsgBox(sys.translate("La fila seleccionada est� cerrada.\n�brala para poder servir la cantidad pendiente."));
		return;
	}

	if (_i.lineaServida(filaActual)) {
		formUI.ponMsgWarn(sys.translate("La l�nea seleccionada ya est� servida."));
		return false;
	}
	
	if(!_i.incluirFilaParcial(filaActual)){
		formUI.ponMsgWarn(sys.translate("Se ha producido un error.\nCierre el formulario y realice el proceso de nuevo."));
		return false		
	}
	_i.tblLineasPedido_.refreshCurrentRow();
	
}

function euromoda_dameCantidadParcial(fila)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var cantidad = parseFloat(_i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.cantidad"));	
	var servida = parseFloat(_i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.totalenalbaran"));
	if (cursor.action() != "em_pedidoscliparciales") {

		var cantidadParcial = 0;

		if(_i.estoyEditandoAlbaran()) {
			var cantAlbActual = parseFloat(_i.tblLineasPedido_.cellValue(fila, "lineasalbaranescli.cantidad"));
			if(!cantAlbActual || cantAlbActual == "") {
				cantAlbActual = 0;
			}
			cantidadParcial = cantidad - servida + cantAlbActual;
		} else {
			cantidadParcial = cantidad -servida;			
		}

		return Input.getNumber(sys.translate("Indique la cantidad"), cantidadParcial, 2, 0);
	}
	var idLinea = _i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.idlinea");
	var max = _i.__maxCantidadAIncluir(fila);

	var maxL = cantidad - servida;
	max = max > maxL ? maxL : max;
	var referencia = _i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.referencia");
	var canDis = AQUtil.sqlSelect("stocks", "disponible", "referencia = '" + referencia + "' AND codalmacen = '" + _i.codAlmacenPpal_ + "'");
	canDis = isNaN(canDis) ? 0 : canDis;	

	
	var cantidad = Input.getNumber(sys.translate("Indique la cantidad (+%1 en disponible)").arg(canDis), max, 2, 0);
	max += canDis;
	if (cantidad > max) {
		sys.warnMsgBox(sys.translate("La cantidad no puede ser superior a la m�xima cantidad albaranable + disponible (%1)").arg(max));
		return false;
	}
	return cantidad;
}

function euromoda_formReady()
{
	/*debug("entra en el formReadyu");
	this.child("leAgencia").text = "";
	this.child("leDescAgencia").text = "";
	this.child("leBultos").text = "";*/
}

function euromoda_tbnBuscarAgencia_clicked()
{
	var _i = this.iface;	

	var filtro = "esagenciat";
	var f = new FLFormSearchDB("proveedores");	
	f.setMainWidget();
	f.cursor().setMainFilter(filtro);
	var codProveedor = f.exec("codproveedor");
	if (codProveedor) {		
		this.child("leAgencia").text = codProveedor;
		var nombreAgencia = AQUtil.sqlSelect("proveedores","nombre","codproveedor = '" + codProveedor + "'");
		if(!nombreAgencia) {
			nombreAgencia = "";
		}
		this.child("leDescAgencia").text = nombreAgencia;	
	}
}

function euromoda_dameSelect()
{
	var _i = this.iface;

	//debug("euromoda_dameselect");
	//debug("idalbaran: "+_i.idAlbaran_);

	var select = "";
	if(_i.estoyEditandoAlbaran()) {
		select = "lineaspedidoscli.idlinea, lineaspedidoscli.idpedido, lineaspedidoscli.referencia, lineaspedidoscli.descripcion, lineaspedidoscli.codtamanoem, lineaspedidoscli.codcolorem, lineaspedidoscli.cantidad, lineaspedidoscli.totalenalbaran, lineasalbaranescli.cantidad, lineaspedidoscli.cerrada, lineaspedidoscli.incluiralbaran, lineaspedidoscli.canalbaran, lineaspedidoscli.pvptotal, lineaspedidoscli.numlinea,lineaspedidoscli.codimpuesto, lineaspedidoscli.iva,  lineaspedidoscli.dtolineal,lineaspedidoscli.dtopor,lineaspedidoscli.recargo, lineaspedidoscli.irpf, lineaspedidoscli.porcomision, lineaspedidoscli.pvpunitario, lineaspedidoscli.pvpsindto,lineaspedidoscli.tipoconcepto";	
	} else {
		select = "lineaspedidoscli.idlinea, lineaspedidoscli.idpedido, lineaspedidoscli.referencia, lineaspedidoscli.descripcion, lineaspedidoscli.codtamanoem, lineaspedidoscli.codcolorem, lineaspedidoscli.cantidad, lineaspedidoscli.totalenalbaran, lineaspedidoscli.cerrada, lineaspedidoscli.incluiralbaran, lineaspedidoscli.canalbaran, lineaspedidoscli.pvptotal, lineaspedidoscli.numlinea,lineaspedidoscli.codimpuesto, lineaspedidoscli.iva,  lineaspedidoscli.dtolineal,lineaspedidoscli.dtopor,lineaspedidoscli.recargo, lineaspedidoscli.irpf, lineaspedidoscli.porcomision, lineaspedidoscli.pvpunitario, lineaspedidoscli.pvpsindto,lineaspedidoscli.tipoconcepto";
	}

	return select;
}

function euromoda_colorCelda(f, c)
{
	var _i = this.iface;
	var nombreCol = _i.tblLineasPedido_.nombreCol(c);
	if(nombreCol == "lineaspedidoscli.incluiralbaran") {
		var incluir = _i.tblLineasPedido_.cellValue(f, "lineaspedidoscli.incluiralbaran");
		if(!incluir) {
			return  new Color(flfactppal.iface.pub_dameColor("fondo_rojo"));
		} else {
			return  new Color(flfactppal.iface.pub_dameColor("fondo_verde"));
		}
	}  else if (nombreCol == "lineaspedidoscli.canalbaran"){
		var cantAlbaran = parseFloat(_i.desFormatoMiles(_i.tblLineasPedido_.cellValue(f, "lineaspedidoscli.canalbaran")));
		var cantidad = parseFloat(_i.desFormatoMiles(_i.tblLineasPedido_.cellValue(f, "lineaspedidoscli.cantidad")));
		var cantTotalEnAlbaran = parseFloat(_i.desFormatoMiles(_i.tblLineasPedido_.cellValue(f, "lineaspedidoscli.totalenalbaran")));
		if (cantidad < 0) {
			cantAlbaran = cantAlbaran * -1;
			cantidad = cantidad * -1;
			cantTotalEnAlbaran = cantTotalEnAlbaran * -1;
		}
		var cerrada = _i.tblLineasPedido_.cellValue(f, "lineaspedidoscli.cerrada");
		if (cerrada) {
			return new Color(flfactppal.iface.pub_dameColor("fondo_gris"));
		}
		if (cantAlbaran == 0 && _i.tblLineasPedido_.cellValue(f, "lineaspedidoscli.tipoconcepto") != "Texto") {
			return  new Color(flfactppal.iface.pub_dameColor("fondo_blanco"));
		} else if (cantAlbaran < 0) {
			return  new Color(flfactppal.iface.pub_dameColor("fondo_rojo"));
		} else{
			var cantPorAlbaranar = cantidad - cantTotalEnAlbaran;
			if (cantAlbaran > cantPorAlbaranar) {
				return  new Color(flfactppal.iface.pub_dameColor("fondo_naranja"));
			} else if(cantAlbaran < cantPorAlbaranar) {				
				return  new Color(flfactppal.iface.pub_dameColor("fondo_amarillo"));
			} else{
				return  new Color(flfactppal.iface.pub_dameColor("fondo_verde"));
			}
		}
	} else {
		return _i.__colorCelda(f, c);
	}		
}

function euromoda_anchoColumnasTabla() 
{
	var _i = this.iface;
	_i.__anchoColumnasTabla();
	_i.tblLineasPedido_.setColumnWidth("lineaspedidoscli.referencia", 100);	
	_i.tblLineasPedido_.setColumnWidth("lineaspedidoscli.descripcion", 500);
	_i.tblLineasPedido_.setColumnWidth("lineaspedidoscli.codtamanoem", 100);
	_i.tblLineasPedido_.setColumnWidth("lineaspedidoscli.codcolorem", 100);
	_i.tblLineasPedido_.setColumnWidth("lineaspedidoscli.incluiralbaran", 70);
	_i.tblLineasPedido_.setColumnWidth("lineaspedidoscli.canalbaran", 100);
}

function euromoda_generarAlbaran()
{
	var _i = this.iface;
	var cursor = this.cursor();	

	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}

	if (!_i.validaDropshipping()) {
		return false;
	}

	if(_i.estoyEditandoAlbaran()) {

		if(!_i.actualizaCabeceraAlbaran()) {
			return false;
		}

		var idAlbaran = _i.regenerarLineasAlbaran(_i.idAlbaran_);
			
		if(idAlbaran && idAlbaran != 0){
			if (!AQUtil.execSql("UPDATE lineaspedidoscli SET canalbaran = 0, incluiralbaran = false WHERE idpedido = " + cursor.valueBuffer("idpedido"))) {
				return false;
			}		
			formpedidoscli.iface.idAlbaranC_ = idAlbaran;
			this.accept();
		}	
	} else {
		if(!_i.guardaCamposPedido()) {
			return false;
		}
		_i.__generarAlbaran();	
	}
	
	return true;
}

function euromoda_regenerarLineasAlbaran(idAlbaran)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var fPC_ = formpedidoscli.iface;

	if (!AQUtil.sqlDelete("lineasalbaranescli", "idalbaran = " + idAlbaran)) {
		debug("regenerarLineasAlbaran 2");
		return false;
	}
	var where = "idpedido = " + cursor.valueBuffer("idpedido");

	var qryPedidos:FLSqlQuery = new FLSqlQuery();
	qryPedidos.setTablesList("pedidoscli");
	qryPedidos.setSelect("idpedido");
	qryPedidos.setFrom("pedidoscli");
	qryPedidos.setWhere(where);

	if (!qryPedidos.exec()) {
		debug("regenerarLineasAlbaran 3");
		return false;
	}
	var idPedido = 0;
	while (qryPedidos.next()) {
		idPedido = qryPedidos.value("idpedido");
		if (!fPC_.copiaLineasParcial(idPedido, idAlbaran)) {
			debug("regenerarLineasAlbaran 4");
			return false;
		}
	}
	if (!fPC_.curAlbaran) {
		fPC_.curAlbaran = new FLSqlCursor("albaranescli");
	}
	fPC_.curAlbaran.select("idalbaran = " + idAlbaran);
	if (fPC_.curAlbaran.first()) {
		fPC_.curAlbaran.setModeAccess(fPC_.curAlbaran.Edit);
		fPC_.curAlbaran.refreshBuffer();
		
		if (!fPC_.totalesAlbaran()) {
			debug("regenerarLineasAlbaran 5");
			return false;
		}
		
		if (!fPC_.curAlbaran.commitBuffer()) {
			debug("regenerarLineasAlbaran 6");
			return false;
		}
	}
	debug("regenerarLineasAlbaran 7");
	return idAlbaran;
}




function euromoda_validaDropshipping()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codD = cursor.valueBuffer("em_coddropshipping");	
	if (!codD || codD == "") {
		return true;
	}
	if (AQUtil.sqlSelect("lineaspedidoscli", "idlinea", "idpedido = " + cursor.valueBuffer("idpedido") + " AND cantidad <> totalenalbaran + canalbaran")) {
		var res = flfactppal.iface.preguntaMsg(sys.translate("Est� albaranando un pedido de dropshipping, DEBER�A INTENTAR enviar todo el material solicitado en el pedido. El albar�n se emitir�.\n�Desea continuar?"),"warn",this,MessageBox.Yes, MessageBox.No);  
		if (res != MessageBox.Yes) {
			return false;
		}		
	}
	return true;
}

function euromoda_filtrarLineas()
{
	var _i = this.iface;
	
	var filtro = _i.dameFiltroLineas();
	debug("filtro: "+filtro);
	if (filtro && filtro != "") {			
		filtro = "(" + filtro + ")";
	} else {
		filtro = "1=2";
	}
	_i.tblLineasPedido_.setFilter(filtro );	
	_i.tblLineasPedido_.refresh();
	AQUtil.destroyProgressDialog();
}

function euromoda_dameFiltroLineas()
{
	var _i = this.iface;
	var filtro = _i.dameWhere();
	var filtroCDB = "";

	if(_i.idAlbaran_ && _i.idAlbaran_ != "") {
		if(_i.idAlbaran_ == -1) {
			if (this.child("chkSoloPendientes").checked) {
				filtroCDB += "((lineaspedidoscli.cantidad-lineaspedidoscli.totalenalbaran>0))";
			}
			//filtroCDB += ")";	
		} else {
			filtroCDB += "(lineaspedidoscli.idlinea IN (SELECT idlineapedido FROM lineasalbaranescli WHERE idalbaran = " + _i.idAlbaran_ + ")";
			if (this.child("chkSoloPendientes").checked) {
				filtroCDB += " OR (lineaspedidoscli.cantidad-lineaspedidoscli.totalenalbaran>0)";
			}
			filtroCDB += ")";		
		}

	} else {
		if (this.child("chkSoloPendientes").checked) {
			if(filtro && filtro != "") {
				filtro += " AND ";
			} 
			filtro += "(lineaspedidoscli.cantidad-lineaspedidoscli.totalenalbaran>0)";
		}	
	}

	if(filtroCDB && filtroCDB != "") {
		filtro = filtro + " AND " + filtroCDB;	
	}
	return filtro;
}

function euromoda_dameFrom()
{
	var _i = this.iface;
	var from = _i.__dameFrom();
	from += " INNER JOIN pedidoscli ON lineaspedidoscli.idpedido = pedidoscli.idpedido";
	if(_i.estoyEditandoAlbaran()) {
		from += " LEFT OUTER JOIN lineasalbaranescli ON lineaspedidoscli.idlinea = lineasalbaranescli.idlineapedido AND lineasalbaranescli.idalbaran = " + _i.idAlbaran_;
	}
	debug("from: "+from);
	return from;
}

function euromoda_incluirFila(fila)
{
	var _i = this.iface;

	/*if (_i.lineaServida(fila)) {
		formUI.ponMsgWarn(sys.translate("La l�nea seleccionada ya est� servida."));
		return true;
	}*/
	if(!_i.__incluirFila(fila)) {
		return false;
	}
	return true;
}	

function euromoda_lineaServida(fila)
{
	var _i = this.iface;
	if (_i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.tipoconcepto") == "Texto") {
		return false;
	} else {
		var cantidad = parseFloat(_i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.cantidad"));	
		var servida = parseFloat(_i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.totalenalbaran"));
		return (cantidad == servida);
	}
}

function euromoda_incluirFilaParcial(fila)
{
	var _i = this.iface;
	if(!_i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.cerrada")){
		var idLinea = _i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.idlinea");	
		var cantPorAlbaranar = _i.dameCantidadParcial(fila);
		if (!cantPorAlbaranar) {
			return false;
		}
		var incluirAlbaran = _i.incluirLineaAlbaran(fila, cantPorAlbaranar);
		if (!AQUtil.execSql("UPDATE lineaspedidoscli SET canalbaran = " + cantPorAlbaranar + ", incluiralbaran = " + incluirAlbaran + " WHERE idlinea = " + idLinea)) {
			return false;
		}
	}
	
	return true;
}

function euromoda_habilitarColumnas()
{
	var _i = this.iface;	
	_i.tblLineasPedido_.setReadOnly(true);	
}

function euromoda_incluirLineaAlbaran(fila, cantPorAlbaranar)
{
	var _i = this.iface;
	if (_i.tblLineasPedido_.cellValue(fila, "lineaspedidoscli.tipoconcepto") == "Texto") {
		return true;
	}
	if(cantPorAlbaranar && cantPorAlbaranar != 0) {
		incluirAlbaran = true;
	} else {
		incluirAlbaran = false;
	}
	return incluirAlbaran;

}

function euromoda_limpiaLineas(idPedido)
{

	if (!AQUtil.execSql("UPDATE lineaspedidoscli SET incluiralbaran = false, canalbaran = 0 WHERE idpedido = " + idPedido)) {
		return false;
	}
	return true;
}

function euromoda_conectarEventosTabla()
{
	var _i = this.iface;
	_i.__conectarEventosTabla();	
	_i.tblLineasPedido_.setDoubleClickedFunction("formpedidoscliparciales.iface.toolButtonEdit_clicked");

}
function euromoda_accionLineaPedido(accion)
{
	var _i = this.iface;

	var filaActual = _i.tblLineasPedido_.table().currentRow();
	var idLineaPedido = _i.tblLineasPedido_.dameCursor().valueBuffer("idlinea");
	var idPedido = _i.tblLineasPedido_.dameCursor().valueBuffer("idpedido");
	if(!idLineaPedido || idLineaPedido == "") {		
		return false;
	}
	if(_i.curLineaPed_) {
		_i.curLineaPed_ = false;	
	}
	_i.curLineaPed_ = new FLSqlCursor("lineaspedidoscli");	

	if(accion == "insert") {
		//connect(_i.curLineaPed_, "bufferCommited()", _i, "refrescarTabla");	
		connect(_i.curLineaPed_, "bufferCommited()", _i, "totalizaPedido");	
		_i.curLineaPed_.insertRecord();	
		_i.curLineaPed_.setValueBuffer("idpedido",idPedido);
		
	} else{		
		_i.curLineaPed_.select("idlinea = " + idLineaPedido);		
		if(!_i.curLineaPed_.first()) {
			return false;
		}
		if(accion == "del"){			

			_i.curLineaPed_.setModeAccess(_i.curLineaPed_.Del);
 			_i.curLineaPed_.refreshBuffer(); 
 			if(!_i.curLineaPed_.commitBuffer()) {
 				return false;
 			}
 			//_i.refrescarTabla();
 			_i.totalizaPedido(idPedido); //ver como hacerlo
		} else {
			//connect(_i.curLineaPed_, "bufferCommited()", _i, "refrescarLinea");	

			if(accion == "browse") {
				_i.curLineaPed_.browseRecord();
			} else {			
				connect(_i.curLineaPed_, "bufferCommited()", _i, "totalizaPedidoLinea");	
				_i.curLineaPed_.editRecord();				
			}
		}

	} 
}
function euromoda_totalizaPedido(idPedido)
{
	var _i = this.iface;
	if (!_i.totalesPedido(idPedido)) {
		return false;
	}
	_i.refrescarTabla();		
}

function euromoda_totalizaPedidoLinea(idPedido)
{
	var _i = this.iface;
	if (!i_.totalesPedido(idPedido)) {
		return false;
	}
	_i.refrescarLinea();		
}
function euromoda_totalesPedido(idPedido)
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(!idPedido || idPedido == "") {
		idPedido = _i.tblLineasPedido_.dameCursor().valueBuffer("idpedido");
	} 	
	var fPC_ = formpresupuestoscli.iface;
	if (!fPC_.curPedido) {
		fPC_.curPedido = new FLSqlCursor("pedidoscli");
	}
	fPC_.curPedido.select("idpedido = " + idPedido);
	if (fPC_.curPedido.first()) {
		fPC_.curPedido.setModeAccess(fPC_.curPedido.Edit);
		fPC_.curPedido.refreshBuffer();		
		if (!fPC_.totalesPedido()) {
			return false;
		}		
		if (!fPC_.curPedido.commitBuffer()) {			
			return false;
		}
	}
	this.child("fdbNeto").setValue(fPC_.curPedido.valueBuffer("neto"));
	this.child("fdbTotalIrpf").setValue(fPC_.curPedido.valueBuffer("totalirpf"));
	this.child("fdbTotalIva").setValue(fPC_.curPedido.valueBuffer("totaliva"));
	this.child("fdbTotalRecargo").setValue(fPC_.curPedido.valueBuffer("totalrecargo"));
	this.child("fdbTotal").setValue(fPC_.curPedido.valueBuffer("total"));
	return true;
}

function euromoda_refrescarLinea()
{
	var _i = this.iface;
	_i.tblLineasPedido_.refreshCurrentRow();	
}

function euromoda_refrescarTabla()
{
	var _i = this.iface;
	_i.tblLineasPedido_.refresh();	
}

function euromoda_toolButtomInsert_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	_i.accionLineaPedido("insert");			
}
	
function euromoda_toolButtonEdit_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	_i.accionLineaPedido("edit");
}

function euromoda_toolButtonDelete_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	_i.accionLineaPedido("del");
}
	
function euromoda_toolButtonZoom_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	_i.accionLineaPedido("browse");
	
}

function euromoda_tbnTraspasoStock_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	if (_i.curTS_) {
		_i.curTS_ = undefined;
	}
	_i.curTS_ = new FLSqlCursor("em_traspasosstock");
	//connect(_i.curTS_, "bufferCommited()", _i, "curTS_bufferCommited");
	_i.curTS_.insertRecord();
}

function euromoda_tbnReservas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}

	//_i.refrescarLineas();
	var codAlmacen = "1";
	
	var refReserva = _i.tblLineasPedido_.dameCursor().valueBuffer("referencia");
	formem_pedidosptes.iface.refReserva_ = refReserva;
	_i.curReserva_.select("referencia = '" + refReserva + "' AND codalmacen = '" + codAlmacen + "'")
	if (!_i.curReserva_.first()) {
		MessageBox.warning(sys.translate("No hay un registro de stock para la referencia y almac�n indicados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return;
	}
	//connect(_i.curReserva_, "bufferCommited()", formem_pedidosptes.iface, "actualizarPorReferencia");
	connect(_i.curReserva_, "bufferCommited()", _i, "actualizaCantidadLineas");
	_i.curReserva_.editRecord();
	
}

function euromoda_actualizaCantidadLineas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codigo = cursor.valueBuffer("codigo");
	if(!formem_pedidosptes.iface.actualizarPorReferencia()) {
		return false;
	}
	if (!formem_pedidosptes.iface.cargaMaximosLineaPedido(codigo)) {
		return false;
	}
}


function euromoda_dameCabecera()
{
	var _i = this.iface;
	var aCabecera = [];
	//aCabecera.push("idlinea");
	//aCabecera.push("idpedido");
	aCabecera.push("Referencia");
	aCabecera.push("Descripci�n");
	aCabecera.push("Tama�o");
	aCabecera.push("Color");
	aCabecera.push("Cant.Pedido");
	aCabecera.push("Servida");
	if(_i.estoyEditandoAlbaran()) {
		aCabecera.push("Cant.Alb.Actual");
	}	
	aCabecera.push("Cerrada");
	aCabecera.push("Incluir");
	aCabecera.push("En albar�n");
	aCabecera.push("Total");
	aCabecera.push("N.L.");
	aCabecera.push("I.V.A.");
	aCabecera.push("%I.V.A.");
	aCabecera.push("Dto.Lineal");
	aCabecera.push("%Descuento");
	aCabecera.push("%R.Equivalencia");
	aCabecera.push("% IRPF");
	aCabecera.push("% Comisi�n");
	aCabecera.push("Precio Unidad");
	aCabecera.push("Importe");
	aCabecera.push("Tipo");

	return aCabecera;
}

function euromoda_estoyEditandoAlbaran()
{	
	var _i = this.iface;
	var ret = false;
	if(_i.idAlbaran_ && _i.idAlbaran_ != "" && _i.idAlbaran_ != -1) {
		ret = true;
	}
	return ret;
}

function euromoda_dameWhere()
{
	var _i = this.iface;
	var where = _i.__dameWhere();

	/*if(_i.estoyEditandoAlbaran()) {
		where = where + " AND lineasalbaranescli.idalbaran = " + _i.idAlbaran_ ;
	}	*/
	return where;
}

function euromoda_guardaCamposPedido()
{

	var cursor = this.cursor();
	var idPedido = cursor.valueBuffer("idpedido"); 	
	var codAgencia = this.child("leAgencia").text;
	if(!codAgencia || codAgencia == "") {
		codAgencia = "";
	} else {
		if(!AQUtil.sqlSelect("proveedores","codproveedor","codproveedor = '" + codAgencia + "'")) {
			formUI.ponMsgWarn(sys.translate("La agencia %1 no existe, no se generar� ning�n albar�n.").arg(codAgencia));
			return false;
		}
	}
	var bultos = this.child("leBultos").text;
	if(!bultos || bultos == "") {
		bultos = 0;
	}
	if(isNaN(bultos)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo bultos debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}

	var pesoBruto = this.child("lePesoBruto").text;
	if(!pesoBruto || pesoBruto == "") {
		pesoBruto = 0;
	}
	if(isNaN(pesoBruto)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo peso bruto debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}
	var volumen = this.child("leVolumen").text;
	if(!volumen || volumen == "") {
		volumen = 0;
	}
	if(isNaN(volumen)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo volumen debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}
	var desBultos = this.child("leClaseM").text;
	if(!desBultos || desBultos == "") {
		desBultos = "";
	}
	var observaciones = this.child("txtObsTrans").text;
	if(!observaciones || observaciones == "") {
		observaciones = "";
	}

	if(codAgencia && codAgencia != "") {
		cursor.setValueBuffer("codagencia",codAgencia);
	} else {
		cursor.setNull("codagencia");
	}
	cursor.setValueBuffer("bultos",bultos);
	cursor.setValueBuffer("pesobruto",pesoBruto);
	cursor.setValueBuffer("volumen",volumen);
	cursor.setValueBuffer("desbultos",desBultos);
	cursor.setValueBuffer("obstransporte",observaciones);

	return true;

}

function euromoda_actualizaCabeceraAlbaran()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idPedido = cursor.valueBuffer("idpedido"); 	
	var codAgencia = this.child("leAgencia").text;
	if(!codAgencia || codAgencia == "") {
		codAgencia = "";
	} else {
		if(!AQUtil.sqlSelect("proveedores","codproveedor","codproveedor = '" + codAgencia + "'")) {
			formUI.ponMsgWarn(sys.translate("La agencia %1 no existe, no se generar� ning�n albar�n.").arg(codAgencia));
			return false;
		}
	}
	var bultos = this.child("leBultos").text;
	if(!bultos || bultos == "") {
		bultos = 0;
	}
	if(isNaN(bultos)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo bultos debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}

	var pesoBruto = this.child("lePesoBruto").text;
	if(!pesoBruto || pesoBruto == "") {
		pesoBruto = 0;
	}
	if(isNaN(pesoBruto)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo peso bruto debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}
	var volumen = this.child("leVolumen").text;
	if(!volumen || volumen == "") {
		volumen = 0;
	}
	if(isNaN(volumen)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo volumen debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}
	var desBultos = this.child("leClaseM").text;
	if(!desBultos || desBultos == "") {
		desBultos = "";
	}
	var observaciones = this.child("txtObsTrans").text;
	if(!observaciones || observaciones == "") {
		observaciones = "";
	}

	if (!AQUtil.execSql("UPDATE albaranescli SET codagencia = '" + codAgencia + "', bultos = " + bultos + ", pesobruto = " + pesoBruto + ", volumen = " + volumen + ", desbultos = '" + desBultos + "', obstransporte = '" + observaciones + "'   WHERE idalbaran = " + _i.idAlbaran_)) {
		return false;
	}
	return true;
}


function euromoda_leAgencia_lostFocus()
{
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}	
	var codAgencia = this.child("leAgencia").text;
	if(!codAgencia || codAgencia == "") {
		this.child("leDescAgencia").text = "";
	} else {
		if(!AQUtil.sqlSelect("proveedores","codproveedor","codproveedor = '" + codAgencia + "'")) {
			formUI.ponMsgWarn(sys.translate("La agencia %1 no existe, por favor indique un valor correcto.").arg(codAgencia));
			this.child("leAgencia").text = "";
			this.child("leAgencia").setFocus();
			return false;
		}
		this.child("leDescAgencia").text = AQUtil.sqlSelect("proveedores","nombre","codproveedor = '" + codAgencia + "'");

	}
	return true;
}

function euromoda_leBultos_lostFocus()
{
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}	
	var bultos = this.child("leBultos").text;
	if(!bultos || bultos == "") {
		bultos = 0;
	}
	if(isNaN(bultos)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo bultos debe de ser num�rico, por favor indique un valor correcto.").arg(bultos));
		this.child("leBultos").text = "";
		this.child("leBultos").setFocus();
		return false;
	}
	return true;
}

function euromoda_lePesoBruto_lostFocus()
{
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}	
	var pesoBruto = this.child("lePesoBruto").text;
	if(!pesoBruto || pesoBruto == "") {
		bultos = 0;
	}
	if(isNaN(pesoBruto)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo peso bruto debe de ser num�rico, por favor indique un valor correcto.").arg(pesoBruto));
		this.child("lePesoBruto").text = "";
		this.child("lePesoBruto").setFocus();
		return false;
	}
	return true;
}

function euromoda_leVolumen_lostFocus()
{
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}	
	var volumen = this.child("leVolumen").text;
	if(!volumen || volumen == "") {
		volumen = 0;
	}
	if(isNaN(volumen)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo volumen debe de ser num�rico, por favor indique un valor correcto.").arg(volumen));
		this.child("leVolumen").text = "";
		this.child("leVolumen").setFocus();
		return false;
	}
	return true;
}

function euromoda_cargaCamposPedido()
{
	var _i = this.iface;
	var cursor = this.cursor();


	var codAgencia = "";
	var bultos = "";
	var pesoBruto = "";
	var volumen = "";
	var desBultos = "";
	var observaciones = ""; 

	if(!_i.estoyEditandoAlbaran()) {

		codAgencia = cursor.valueBuffer("codagencia");
		bultos = cursor.valueBuffer("bultos");
		pesoBruto = cursor.valueBuffer("pesobruto");
		volumen = cursor.valueBuffer("volumen");
		desBultos = cursor.valueBuffer("desbultos");
		observaciones = cursor.valueBuffer("obstransporte"); 
		
	} else {
		var q = new AQSqlQuery;	
		q.setSelect("codagencia,bultos,pesobruto,volumen,desbultos,obstransporte");
		q.setFrom("albaranescli");
		q.setWhere("idalbaran = " + _i.idAlbaran_); 	
		if (!q.exec()){
			return;
		}  
		if(q.first())
		{
			codAgencia = q.value("codagencia");
			bultos = q.value("bultos");
			pesoBruto = q.value("pesobruto");
			volumen = q.value("volumen");
			desBultos = q.value("desbultos");
			observaciones = q.value("obstransporte"); 
		}
	}
	if(!bultos) {
		bultos = "";
	}
	if(!pesoBruto) {
		pesoBruto = "";
	}
	if(!volumen) {
		volumen = "";
	}
	if(!observaciones) {
		observaciones = "";
	}

	this.child("leAgencia").text = codAgencia;
	if(codAgencia && codAgencia != "") {
		this.child("leDescAgencia").text = AQUtil.sqlSelect("proveedores","nombre","codproveedor = '" + codAgencia + "'");
	}
	this.child("leBultos").text = bultos;
	this.child("lePesoBruto").text = pesoBruto;
	this.child("leVolumen").text = volumen;
	this.child("leClaseM").text = desBultos;
	this.child("txtObsTrans").text = observaciones;
}

function euromoda_abrirCerrarLinea()
{
	var _i = this.iface;
	var curPedido = this.cursor();	


	if(curPedido.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}

	var idLinea = _i.tblLineasPedido_.columnValue("lineaspedidoscli.idlinea");
	if(!idLinea) {
		sys.warnMsgBox(sys.translate("No hay ning�n registro seleccionado"));
		return;
	}
	var curLinea = new FLSqlCursor("lineaspedidoscli");
	curLinea.select("idlinea = " + idLinea);
	if (!curLinea.first()) {
		return false;
	}
	curLinea.setModeAccess(curLinea.Edit);
	curLinea.refreshBuffer();

	var cerrar = true;
	var res:Number;
	if(AQUtil.sqlSelect("lineaspedidoscli","cerrada","idlinea = " + idLinea + " AND cerrada")) {
		cerrar = false;
		res = formUI.preguntaMsg(sys.translate("La linea seleccionada est� cerrada.\n�Seguro que desea abrirla?"), "info", this, MessageBox.Yes, MessageBox.No);
	}
	else {
		if(curLinea.valueBuffer("cantidad") == curLinea.valueBuffer("totalenalbaran")) {
			sys.warnMsgBox(sys.translate("La l�nea ya ha sido servida completamente."));
			return;
		}
		res = formUI.preguntaMsg(sys.translate("Se va a cerrar la l�nea y no podr� terminar de servirse.\n�Desea continuar?"), "info", this, MessageBox.Yes, MessageBox.No);
	}
	if(res != MessageBox.Yes){
		return;
	}

	curLinea.setValueBuffer("cerrada", cerrar);
	//curLinea.setValueBuffer("canalbaran", 0);
	//curLinea.setValueBuffer("incluiralbaran", false);
	if (!_i.datosAbrirCerrarLinea(curLinea)) {
		return false;
	}
	if (!curLinea.commitBuffer()) {
		return false;
	}
	
	var idPedido = curPedido.valueBuffer("idpedido"); 
	if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
		return;
	}
	_i.tblLineasPedido_.refreshCurrentRow()
}

function euromoda_pbnExcluir_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	
	_i.__pbnExcluir_clicked();
}

function euromoda_pbnExcluirTodos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	
	_i.__pbnExcluirTodos_clicked();
}

function euromoda_pbnIncluirTodos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	
	_i.__pbnIncluirTodos_clicked();
}

function euromoda_pbnIncluir_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaran")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaran")) {
			return false;
		}
	}
	
	_i.__pbnIncluir_clicked();
	
}

//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
