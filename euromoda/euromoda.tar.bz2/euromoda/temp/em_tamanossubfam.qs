/***************************************************************************
                 em_tamanossubfam.qs  -  description
                             -------------------
    begin                : jue mar 14 2019
    copyright            : (C) 2019 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { 
		return this.ctx.interna_init(); 
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblLogCostes_;
	var actualizaHerencia_;
    function oficial( context ) { interna( context ); } 
	function cargaDatosLogCostes() {
		return this.ctx.oficial_cargaDatosLogCostes();
	}
	function dameTablaLogCostes() {
		return this.ctx.oficial_dameTablaLogCostes();
	}
	function pbnActualizarMargenes_clicked() {
		return this.ctx.oficial_pbnActualizarMargenes_clicked();
	}
	function actualizarMargenes(cursor) {
		return this.ctx.oficial_actualizarMargenes(cursor);
	}
	function actualizaHerenciaMargenArt(cursor, hoy) {
		return this.ctx.oficial_actualizaHerenciaMargenArt(cursor, hoy);
	}
	function actualizaMargenesArticulosHer(cursor, hoy) {
		return this.ctx.oficial_actualizaMargenesArticulosHer(cursor, hoy);
	}
	function pbnActualizarCostes_clicked() {
		return this.ctx.oficial_pbnActualizarCostes_clicked();
	}	
	function actualizarCostes(cursor) {
		return this.ctx.oficial_actualizarCostes(cursor);
	}
	function actualizaHerenciaCosteArt(cursor, hoy) {
		return this.ctx.oficial_actualizaHerenciaCosteArt(cursor, hoy);
	}
	function actualizaCostesArticulosHer(cursor, hoy) {
		return this.ctx.oficial_actualizaCostesArticulosHer(cursor, hoy);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	connect(this.child("pbnActualizarMargenes"), "clicked()", _i, "pbnActualizarMargenes_clicked");
	connect(this.child("pbnActualizarCostes"), "clicked()", _i, "pbnActualizarCostes_clicked");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	_i.tblLogCostes_ = undefined;	
	formRecordarticulos.iface.habilitaCamposCostesProd(this, cursor);
	_i.cargaDatosLogCostes();
	_i.actualizaHerencia_ = false;
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
	return true;
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(fN =="em_margenprod" || fN == "em_observmargenprod") {
		var d = new Date;
		this.child("fdbEmFechaMargenProd").setValue(d.toString());
		this.child("fdbHoraMargenProd").setValue(d.toString().right(8));
		this.child("fdbEmIdUsuarioMargenProd").setValue(sys.nameUser());					
	} else if(fN =="em_costeprod" || fN == "em_observcosteprod") {
		var d = new Date;
		this.child("fdbEmFechaCosteProd").setValue(d.toString());
		this.child("fdbHoraCosteProd").setValue(d.toString().right(8));
		this.child("fdbEmIdUsuarioCosteProd").setValue(sys.nameUser());
	}
}
function oficial_cargaDatosLogCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var obj = _i.dameTablaLogCostes();	
	var miTabla = obj.miTabla;
	var q = new FLSqlQuery;
	q.setSelect(formRecordarticulos.iface.dameSelectLogCostes(cursor));		
	q.setFrom("v_logcostesmargenes");
	q.setWhere(formRecordarticulos.iface.dameWhereLogCostes(cursor));
	q.setOrderBy("v_logcostesmargenes.fechahis DESC, v_logcostesmargenes.horahis DESC");		
	miTabla.setQuery(q);	

	formRecordarticulos.iface.ponTamanosLogCostes(miTabla);

	miTabla.setReadOnly(true);	
	miTabla.refresh();
	
	return true;	
}


function oficial_dameTablaLogCostes()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblLogCostes_ ? true : false;
	obj.tabla = this.child("mte_tblExt_LogCostes");
	obj.gb = this.child("mte_gbExt_LogCostes");

	if (!obj.creado) {
		_i.tblLogCostes_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblLogCostes_.checkColumnEnabled(false);
		_i.tblLogCostes_.setAliasCheckColumn("Sel.");
		_i.tblLogCostes_.setSearchEnabled(true);
		_i.tblLogCostes_.setOrderDesc(true);
		//_i.tblLogCostes_.setDoubleClickedFunction("formem_reservasop.iface.abrirOP");
	}
	
	obj.miTabla = _i.tblLogCostes_;

	return obj;
}

function oficial_pbnActualizarMargenes_clicked()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	_i.actualizaHerencia_ = true;
	flfactalma.iface.oMargenes_ = new Object();
	flfactalma.iface.oMargenes_["em_margenprod"] = cursor.valueBuffer("em_margenprod");
	flfactalma.iface.oMargenes_["em_observmargenprod"] = cursor.valueBuffer("em_observmargenprod");

	cursor.commitBuffer();

	if(!_i.actualizarMargenes(cursor)) {
		return false;
	}
	_i.tblLogCostes_.refresh();
	flfactalma.iface.oMargenes_ = false;

}

function oficial_actualizarMargenes(cursor)
{
	var _i = this.iface;
	var hoy = new Date();	
	flfactalma.iface.controlDatosModCosteProd(cursor);		
	var activarMargenHer = cursor.valueBuffer("em_activarmargenher");	
	if(activarMargenHer) {
		if(!_i.actualizaHerenciaMargenArt(cursor, hoy)) {
			return false;
		}
	}
	if(!_i.actualizaMargenesArticulosHer(cursor, hoy)) {
		return false;
	}	
	return true;

}

/*function oficial_actualizaHerenciaMargenArt(cursor, hoy)
{
	var _i = this.iface;	
	var hora = hoy.toString().right(8);
	var idUsuario = sys.nameUser();	
	var margenProd = cursor.valueBuffer("em_margenprod");
	var fechaMargenProd = cursor.valueBuffer("em_fechamargenprod");
	var horaMargenProd = cursor.valueBuffer("em_horamargenprod").toString().right(8);
	var idUsuarioMargenProd = cursor.valueBuffer("em_idusuariomargenprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");
	var origenMargen;
	var where = "";	

	if(cursor.table() == "em_tamanossubfam") {

		var codSubfamilia = cursor.valueBuffer("codsubfamilia");
		var codTamano = cursor.valueBuffer("codtamanoem");

		origenMargen = "'tama�os por subfamilia'";
		where = "p.idplantilla IS NULL AND a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "' AND a.em_margenprod = " + margenProd + " AND a.em_tipomargen = 'Manual'";

		if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',CASE a.em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE a.em_origencoste END," + origenMargen + ",a.em_margenprod,a.em_fechamargenprod,a.em_horamargenprod, a.em_idusuariomargenprod, a.em_observmargenprod,a.referencia,a.em_fechacosteprod,a.em_horacosteprod, a.em_costeprod, a.em_idusuariocosteprod, a.em_observcosteprod, a.em_tipocoste, 'Heredado' FROM articulos a LEFT OUTER JOIN em_plantillasprod p ON a.codcoleccionem = p.codcoleccionem AND a.codsubfamilia = p.codsubfamilia AND a.codtamanoem = p.codtamanoem AND a.codcolorem = p.codcolorem AND p.em_margenprod IS NOT NULL WHERE " + where )) {
			return false;
		}

		if(!AQUtil.execSql("UPDATE articulos SET em_tipomargen = 'Heredado', em_origenmargen = " + origenMargen + " FROM articulos a LEFT OUTER JOIN em_plantillasprod p ON a.codcoleccionem = p.codcoleccionem AND a.codsubfamilia = p.codsubfamilia AND a.codtamanoem = p.codtamanoem AND a.codcolorem = p.codcolorem AND p.em_margenprod IS NOT NULL WHERE articulos.referencia = a.referencia AND " + where)) {
		}

	} else {
		if(cursor.table() == "em_plantillasprod") {
			
			var codSubfamilia = cursor.valueBuffer("codsubfamilia");
			var codTamano = cursor.valueBuffer("codtamanoem");
			var codColeccion = cursor.valueBuffer("codcoleccionem");
			var codColor = cursor.valueBuffer("codcolorem");

			origenMargen = "'plantilla'";
			where = "codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "' and codcoleccionem = '" + codColeccion + "' AND codcolorem = '" + codColor + "' AND em_margenprod = " + margenProd + " AND em_tipomargen = 'Manual'";
		} else if(cursor.table() == "subfamilias") {
			var codSubfamilia = cursor.valueBuffer("codsubfamilia");
			origenMargen = "'subfamilia'";
			where = "codsubfamilia = '" + codSubfamilia + "' AND em_margenprod = " + margenProd + " AND em_tipomargen = 'Manual'";
		

		} else if(cursor.table() == "familias") {
			var codFamilia = cursor.valueBuffer("codfamilia");
			origenMargen = "'familia'";
			where = "codfamilia = '" + codFamilia + "' AND em_margenprod = " + margenProd + " AND em_tipomargen = 'Manual'";
		}

		if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',CASE em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE em_origencoste END," + origenMargen + ",em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, 'Heredado' FROM articulos WHERE " + where )) {
			return false;
		}

		if(!AQUtil.execSql("UPDATE articulos SET em_tipomargen = 'Heredado', em_origenmargen = " + origenMargen + " WHERE " + where)) {
			return false;
		}
	}
	return true;

}*/

function oficial_actualizaHerenciaMargenArt(cursor, hoy)
{
	var _i = this.iface;	
	var hora = hoy.toString().right(8);
	var idUsuario = sys.nameUser();	
	var margenProd = cursor.valueBuffer("em_margenprod");
	var fechaMargenProd = cursor.valueBuffer("em_fechamargenprod");
	var horaMargenProd = cursor.valueBuffer("em_horamargenprod").toString().right(8);
	var idUsuarioMargenProd = cursor.valueBuffer("em_idusuariomargenprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");
	var origenMargen;
	var where = "articulos.em_tipomargen = 'Manual' AND articulos.em_margenprod = " + margenProd;	

	if(cursor.table() == "em_plantillasprod") {

		var codSubfamilia = cursor.valueBuffer("codsubfamilia");
		var codTamano = cursor.valueBuffer("codtamanoem");
		var codColeccion = cursor.valueBuffer("codcoleccionem");
		var codColor = cursor.valueBuffer("codcolorem");
		origenMargen = "'plantilla'";
		var origenMargenAlt = "'plantilla alternativa'";	
					
		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND articulos.codcolorem = '" + codColor + "' AND ((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = " + origenMargen + ") OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen = " + origenMargenAlt + "))";
		
	} else if(cursor.table() == "em_tamanossubfam") {

		var codSubfamilia = cursor.valueBuffer("codsubfamilia");
		var codTamano = cursor.valueBuffer("codtamanoem");
		origenMargen = "'tama�os por subfamilia'";

		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND ori.origenmargen = " + origenMargen + "";

	} else if(cursor.table() == "subfamilias") {
		var codSubfamilia = cursor.valueBuffer("codsubfamilia");
		origenMargen = "'subfamilia'";
		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND ori.origenmargen = " + origenMargen + "";
	
 
	} else if(cursor.table() == "familias") {
		var codFamilia = cursor.valueBuffer("codfamilia");
		origenMargen = "'familia'";
		where += " AND articulos.codfamilia = '" + codFamilia + "' AND ori.origenmargen = " + origenMargen + "";
	}

	if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',CASE articulos.em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origencoste END,ori.origenmargen, articulos.em_margenprod,articulos.em_fechamargenprod,articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod,articulos.referencia, articulos.em_fechacosteprod, articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, articulos.em_tipocoste, 'Heredado' FROM articulos INNER JOIN v_origenherenciaman ori ON articulos.referencia = ori.referencia WHERE " + where)) {
		return false;
	}

	if(!AQUtil.execSql("UPDATE articulos SET em_tipomargen = 'Heredado', em_origenmargen = ori.origenmargen FROM v_origenherenciaman ori  WHERE articulos.referencia = ori.referencia AND " + where)) {
		return false;
	}
	
	return true;

}

function oficial_actualizaMargenesArticulosHer(cursor, hoy)
{
	
	var _i = this.iface;

	var hora = hoy.toString().right(8);
	var idUsuario = sys.nameUser();
	
	
	var margenProd = cursor.valueBuffer("em_margenprod");
	var fechaMargenProd = "'" + cursor.valueBuffer("em_fechamargenprod") + "'";
	var horaMargenProd = "'" + cursor.valueBuffer("em_horamargenprod").toString().right(8) + "'";
	var idUsuarioMargenProd = cursor.valueBuffer("em_idusuariomargenprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");
	var origenMargen;
	
	var oParam = new Object;
	oParam["fechahis"] = hoy;
	oParam["horahis"] = hora;
	oParam["usuariohis"] = sys.nameUser();		
	oParam["em_actmargenes"] = true;



	if(cursor.isNull("em_margenprod")) {
		margenProd = null;
	}
	if(cursor.isNull("em_fechamargenprod")) {
		fechaMargenProd = null;
	}
	if(cursor.isNull("em_horamargenprod")) {
		horaMargenProd = null;
	}
	if(!obsMargenProd || obsMargenProd == "" ||  cursor.isNull("em_observmargenprod")) {
		obsMargenProd = "";
	}


	var where = "articulos.em_tipomargen = 'Heredado'";	

	var aCampos = ["em_margenprod","em_fechamargenprod","em_horamargenprod","em_idusuariomargenprod","em_observmargenprod","em_activarmargenher","em_fechacosteprod","em_horacosteprod","em_costeprod","em_idusuariocosteprod","em_observcosteprod","em_actcostes","em_activarcostesher"];

	if(cursor.table() == "em_plantillasprod") {
		var codSubfamilia = cursor.valueBuffer("codsubfamilia");
		var codTamano = cursor.valueBuffer("codtamanoem");
		var codColeccion = cursor.valueBuffer("codcoleccionem");
		var codColor = cursor.valueBuffer("codcolorem");
		origenMargen = "'plantilla'";
		var origenMargenAlt = "'plantilla alternativa'";	

		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND articulos.codcolorem = '" + codColor + "' AND ((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = " + origenMargen + ") OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen = " + origenMargenAlt + "))";

		aCampos.push("idplantilla");
		oParam["gridasociado"] = "plantillas";	
		
	} else if(cursor.table() == "em_tamanossubfam") {
		var codSubfamilia = cursor.valueBuffer("codsubfamilia");
		var codTamano = cursor.valueBuffer("codtamanoem");

		origenMargen = "'tama�os por subfamilia'";
		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND ori.origenmargen = " + origenMargen + "";

		aCampos.push("codsubfamilia");
		aCampos.push("codtamanoem");
		oParam["gridasociado"] = "tama�os por subfamilia";

	} else if(cursor.table() == "subfamilias") {
		var codSubfamilia = cursor.valueBuffer("codsubfamilia");		
		origenMargen = "'subfamilia'";
		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND ori.origenmargen = " + origenMargen + "";
	
		aCampos.push("codsubfamilia");
		oParam["gridasociado"] = "subfamilias";	

	} else if(cursor.table() == "familias") {
		var codFamilia = cursor.valueBuffer("codfamilia");		
		origenMargen = "'familia'";
		where += " AND articulos.codfamilia = '" + codFamilia + "' AND ori.origenmargen = " + origenMargen + "";
	
		aCampos.push("codfamilia");
		oParam["gridasociado"] = "familias";	
	}

	if(margenProd && margenProd != "") {
		where += " AND (articulos.em_margenprod <> " + margenProd + " OR articulos.em_margenprod IS NULL)";
	}
	//debug("\n\n***********ORIGEN MARGEN *********: "+origenMargen);

	//debug("\n\nlogarticulos: SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "', CASE articulos.em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origencoste END,ori.origenmargen," + margenProd + "," + fechaMargenProd + "," + horaMargenProd + ", '" + idUsuarioMargenProd + "', '" + obsMargenProd + "',articulos.referencia,articulos.em_fechacosteprod,articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, articulos.em_tipocoste, 'Heredado' FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia WHERE " + where);

	//debug("\n\b�nupdate articulos: UPDATE articulos SET em_origenmargen = ori.origenmargen, em_margenprod = " + margenProd + ", em_fechamargenprod = " + fechaMargenProd + ", em_horamargenprod = " + horaMargenProd + ", em_idusuariomargenprod = '" + idUsuarioMargenProd + "', em_observmargenprod = '" + obsMargenProd + "' FROM v_origencostemargen ori  WHERE articulos.referencia = ori.referencia AND " + where);

	if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "', CASE articulos.em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origencoste END,ori.origenmargen," + margenProd + "," + fechaMargenProd + "," + horaMargenProd + ", '" + idUsuarioMargenProd + "', '" + obsMargenProd + "',articulos.referencia,articulos.em_fechacosteprod,articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, articulos.em_tipocoste, 'Heredado' FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia WHERE " + where)) {
		return false;
	}

	if(!AQUtil.execSql("UPDATE articulos SET em_origenmargen = ori.origenmargen, em_margenprod = " + margenProd + ", em_fechamargenprod = " + fechaMargenProd + ", em_horamargenprod = " + horaMargenProd + ", em_idusuariomargenprod = '" + idUsuarioMargenProd + "', em_observmargenprod = '" + obsMargenProd + "' FROM v_origencostemargen ori  WHERE articulos.referencia = ori.referencia AND " + where)) {
		return false;
	}

	for(var i=0;i<aCampos.length;i++) {
		if(cursor.isNull(aCampos[i])) {
			oParam[aCampos[i]] = "NULL";	
		} else {
			oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);	
		}
		
	}
	if(!formRecordarticulos.iface.insertaRegistroLog(oParam)) {
		return false;
	}	
	return true;
}


function oficial_pbnActualizarCostes_clicked()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	_i.actualizaHerencia_ = true;
	flfactalma.iface.oCostes_ = new Object();
	flfactalma.iface.oCostes_["em_costeprod"] = cursor.valueBuffer("em_costeprod");
	flfactalma.iface.oCostes_["em_observcosteprod"] = cursor.valueBuffer("em_observcosteprod");
	
	cursor.commitBuffer();
	if(!_i.actualizarCostes(cursor)) {
		return false;
	}

	_i.tblLogCostes_.refresh();
	flfactalma.iface.oCostes_ = false;
	return true;
}

function oficial_actualizarCostes(cursor)
{
	var _i = this.iface;
	var hoy = new Date();
	flfactalma.iface.controlDatosModCosteProd(cursor);	

	var activarCosteHer = cursor.valueBuffer("em_activarcostesher");
	if(activarCosteHer) {
		if(!_i.actualizaHerenciaCosteArt(cursor, hoy)) {
			return false;
		}
	}
	if(!_i.actualizaCostesArticulosHer(cursor, hoy)) {
		return false;
	}
	return true;

}

function oficial_actualizaHerenciaCosteArt(cursor, hoy)
{
	var _i = this.iface;
	
	var hora = hoy.toString().right(8);
	var idUsuario = sys.nameUser();
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	
	var costeProd = cursor.valueBuffer("em_costeprod");
	var fechaCosteProd = cursor.valueBuffer("em_fechacosteprod");
	var horaCosteProd = cursor.valueBuffer("em_horacosteprod").toString().right(8);
	var idUsuarioCosteProd = cursor.valueBuffer("em_idusuariocosteprod");
	var obsCosteProd = cursor.valueBuffer("em_observcosteprod");
	var origenCoste;	
	var where = "articulos.em_tipocoste = 'Manual' AND articulos.em_costeprod = " + costeProd;	

	if(cursor.table() == "em_plantillasprod") {
		var codTamano = cursor.valueBuffer("codtamanoem");
		var codColeccion = cursor.valueBuffer("codcoleccionem");
		var codColor = cursor.valueBuffer("codcolorem");
		origenCoste = "'plantilla'";
		var origenCosteAlt = "'plantilla alternativa'";	

		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND articulos.codcolorem = '" + codColor + "' AND ((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = " + origenCoste + ") OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste = " + origenCosteAlt + "))";

		
	} else if(cursor.table() == "em_tamanossubfam") {
		var codTamano = cursor.valueBuffer("codtamanoem");
		origenCoste = "'tama�os por subfamilia'";		
		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND ori.origencoste = " + origenCoste + "";	

	
	} else if(cursor.table() == "subfamilias") {
		origenCoste = "'subfamilia'";
		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND ori.origencoste = " + origenCoste + "";			

	}

	if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',ori.origencoste,CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END,articulos.em_margenprod,articulos.em_fechamargenprod,articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod, articulos.referencia, articulos.em_fechacosteprod, articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, 'Heredado', articulos.em_tipomargen FROM articulos INNER JOIN v_origenherenciaman ori ON articulos.referencia = ori.referencia WHERE " + where)) {
		return false;
	}

	if(!AQUtil.execSql("UPDATE articulos SET em_tipocoste = 'Heredado', em_origencoste = ori.origencoste FROM v_origenherenciaman ori  WHERE articulos.referencia = ori.referencia AND " + where)) {	
		return false;
	}

	return true;
}

function oficial_actualizaCostesArticulosHer(cursor, hoy)
{
	var _i = this.iface;

	var hora = hoy.toString().right(8);
	var idUsuario = sys.nameUser();
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	
	var costeProd = cursor.valueBuffer("em_costeprod");
	var fechaCosteProd = "'" + cursor.valueBuffer("em_fechacosteprod") + "'";
	var horaCosteProd = "'" + cursor.valueBuffer("em_horacosteprod").toString().right(8) + "'";
	var idUsuarioCosteProd = cursor.valueBuffer("em_idusuariocosteprod");
	var obsCosteProd = cursor.valueBuffer("em_observcosteprod");
	var origenCoste;
	
	var oParam = new Object;
	oParam["fechahis"] = hoy;
	oParam["horahis"] = hora;
	oParam["usuariohis"] = sys.nameUser();		
	oParam["em_actcostes"] = true;


	if(cursor.isNull("em_costeprod")) {
		costeProd = null;
	}
	if(cursor.isNull("em_horacosteprod")) {
		fechaCosteProd = null;
	}
	if(cursor.isNull("em_horacosteprod")) {
		horaCosteProd = null;
	}
	if(!obsCosteProd || obsCosteProd == "" ||  cursor.isNull("em_observcosteprod")) {
		obsCosteProd = "";
	}

	var aCampos = ["em_margenprod","em_fechamargenprod","em_horamargenprod","em_idusuariomargenprod","em_observmargenprod","em_activarmargenher","em_fechacosteprod","em_horacosteprod","em_costeprod","em_idusuariocosteprod","em_observcosteprod","em_actmargenes","em_activarcostesher"];


	var where = "articulos.em_tipocoste = 'Heredado'";	
	if(cursor.table() == "em_plantillasprod") {
		
		var codTamano = cursor.valueBuffer("codtamanoem");		
		var codColeccion = cursor.valueBuffer("codcoleccionem");
		var codColor = cursor.valueBuffer("codcolorem");
		origenCoste = "'plantilla'";
		var origenCosteAlt = "'plantilla alternativa'";

		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND articulos.codcolorem = '" + codColor + "' AND ((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = " + origenCoste + ") OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste = " + origenCosteAlt + "))";
	
		aCampos.push("idplantilla");
		oParam["gridasociado"] = "plantillas";
		
	} else if(cursor.table() == "em_tamanossubfam") {
		var codTamano = cursor.valueBuffer("codtamanoem");
		origenCoste = "'tama�os por subfamilia'";

		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND ori.origencoste = " + origenCoste + "";

		aCampos.push("codsubfamilia");
		aCampos.push("codtamanoem");
		oParam["gridasociado"] = "tama�os por subfamilia";


	} else if(cursor.table() == "subfamilias") {		
	
		origenCoste = "'subfamilia'";
		where += " AND articulos.codsubfamilia = '" + codSubfamilia + "' AND ori.origencoste = " + origenCoste + "";		

		aCampos.push("codsubfamilia");
		oParam["gridasociado"] = "subfamilias";
	}

	if(costeProd && costeProd != "") {
		where += " AND (articulos.em_costeprod <> " + costeProd + " OR articulos.em_costeprod IS NULL)";
	}



	//debug("\n\n***********ORIGEN COSTE *********: "+origenCoste);


	//debug("origencoste referencia 80187: "+AQUtil.sqlSelect("v_origencostemargen","origencoste","referencia = '80187'"));

	//debug("\n\nlogarticulos: SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "', ori.origencoste,CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END,articulos.em_margenprod,articulos.em_fechamargenprod, articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod, articulos.referencia," + fechaCosteProd + ", " + horaCosteProd + ", " + costeProd + ",'" + idUsuarioCosteProd + "','" + obsCosteProd + "', 'Heredado', articulos.em_tipomargen FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia WHERE " + where);

	


	if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "', ori.origencoste,CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END,articulos.em_margenprod,articulos.em_fechamargenprod, articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod, articulos.referencia," + fechaCosteProd + ", " + horaCosteProd + ", " + costeProd + ",'" + idUsuarioCosteProd + "','" + obsCosteProd + "', 'Heredado', articulos.em_tipomargen FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia WHERE " + where)) {
			return false;
	}	

	//debug("\n\b�nupdate articulos: UPDATE articulos SET em_origencoste = ori.origencoste, em_costeprod = " + costeProd + ", em_fechacosteprod = " + fechaCosteProd + ", em_horacosteprod = " + horaCosteProd + ", em_idusuariocosteprod = '" + idUsuarioCosteProd + "', em_observcosteprod = '" + obsCosteProd + "' FROM v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where);

	if(!AQUtil.execSql("UPDATE articulos SET em_origencoste = ori.origencoste, em_costeprod = " + costeProd + ", em_fechacosteprod = " + fechaCosteProd + ", em_horacosteprod = " + horaCosteProd + ", em_idusuariocosteprod = '" + idUsuarioCosteProd + "', em_observcosteprod = '" + obsCosteProd + "' FROM v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where)) {
			return false;
	}	

	for(var i=0;i<aCampos.length;i++) {
		if(cursor.isNull(aCampos[i])) {
			oParam[aCampos[i]] = "NULL";	
		} else {
			oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);	
		}
	}
	if(!formRecordarticulos.iface.insertaRegistroLog(oParam)) {
		return false;
	}	
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////