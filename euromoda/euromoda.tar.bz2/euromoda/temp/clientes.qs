
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends personaFisica {
	var bloqueoIdFiscal_, cPar;
  function euromoda( context ) { personaFisica ( context ); }
  function tbnBuscarClienteFac_clicked()
  {
    return this.ctx.euromoda_tbnBuscarClienteFac_clicked();
  }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function filtraSaldoPartidas()
  {
    return this.ctx.euromoda_filtraSaldoPartidas();
  }
  function filtraTransportistas()
  {
    return this.ctx.euromoda_filtraTransportistas();
  }
  function filtraDocumentos()
  {
    return this.ctx.euromoda_filtraDocumentos();
  }
  function inhabilitaContabilidadOficial()
  {
    return this.ctx.euromoda_inhabilitaContabilidadOficial();
  }
  function iniciaTablaDtos()
  {
    return this.ctx.euromoda_iniciaTablaDtos();
  }
  function habilitaComisiones()
  {
    return this.ctx.euromoda_habilitaComisiones();
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function filtraPrecios()
  {
    return this.ctx.euromoda_filtraPrecios();
  }
  function filtraSubcuentasCli()
  {
    return this.ctx.euromoda_filtraSubcuentasCli();
  }
  function filtraPartidasCli()
  {
    return this.ctx.euromoda_filtraPartidasCli();
  }
  function colsSubcuentasCli()
  {
    return this.ctx.euromoda_colsSubcuentasCli();
  }
  function mostrarLibroMayor()
  {
    return this.ctx.euromoda_mostrarLibroMayor();
  }
  function dameWhereRecibosSaldo()
  {
    return this.ctx.euromoda_dameWhereRecibosSaldo();
  }
  function dameFilasSeleccionSaldo()
  {
    return this.ctx.euromoda_dameFilasSeleccionSaldo();
  }
  function cancelaAnticipoSaldo(aFilas, aTipos)
  {
    return this.ctx.euromoda_cancelaAnticipoSaldo(aFilas, aTipos);
  }
//   function compensaRecibos(aFilas)
//   {
//     return this.ctx.euromoda_compensaRecibos(aFilas);
//   }
//   function compensaRecibosTR(curR1, curR2)
//   {
//     return this.ctx.euromoda_compensaRecibosTR(curR1, curR2);
//   }
  function establecerSubcuenta() 
  {
    return this.ctx.euromoda_establecerSubcuenta();
  }
  function calculateField(fN)
  {
    return this.ctx.euromoda_calculateField(fN);
  }
  function validateForm()
  {
		return this.ctx.euromoda_validateForm();
	}
	function validaCIFEuromoda()
  {
		return this.ctx.euromoda_validaCIFEuromoda();
	}
	function commonCalculateField(fN, cursor)
  {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
	function compruebaSaldo()
  {
		return this.ctx.euromoda_compruebaSaldo();
	}
	function dameListaSubcuentas(codGrupoContableCli)
  {
		return this.ctx.euromoda_dameListaSubcuentas(codGrupoContableCli);
	}
	function cargaOtrosSaldos(aDatos)
  {
    return this.ctx.euromoda_cargaOtrosSaldos(aDatos);
  }
  function cancelaReciboPartida(aFilas)
  {
    return this.ctx.euromoda_cancelaReciboPartida(aFilas);
  }
  function cancelaAnticipoPartida(aFilas)
  {
    return this.ctx.euromoda_cancelaAnticipoPartida(aFilas);
  }
  function cancelaPartidaPartida(aFilas)
  {
    return this.ctx.euromoda_cancelaPartidaPartida(aFilas);
  }
  function tbnEditaAR_clicked()
  {
    return this.ctx.euromoda_tbnEditaAR_clicked();
  }
  function coloresSaldo()
  {
    return this.ctx.euromoda_coloresSaldo();
  }
  function dameTiposFila(aFilas) {
		return this.ctx.euromoda_dameTiposFila(aFilas);
	}
  function tbnQuitarGrupo_clicked()
  {
    return this.ctx.euromoda_tbnQuitarGrupo_clicked();
  }
  function filtroRecibos()
  {
		return this.ctx.euromoda_filtroRecibos();
  }
  function habilitarPorDeposito() {
   	return this.ctx.euromoda_habilitarPorDeposito();
  }
  function filtraHistorico() {
		return this.ctx.euromoda_filtraHistorico();
  }
  function ordenColumnasHis() {
		return this.ctx.euromoda_ordenColumnasHis();
  }
  function filtraHistoricoInit() {
		return this.ctx.euromoda_filtraHistoricoInit();
  }
  function tdbEmArticulosCliHis_bufferCommited() {
		return this.ctx.euromoda_tdbEmArticulosCliHis_bufferCommited();	
  }
  function controlFichaCostes() {
  	return this.ctx.euromoda_controlFichaCostes();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_dameListaSubcuentas(codGrupoContableCli) {
		return this.dameListaSubcuentas(codGrupoContableCli);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  
  
	_i.bloqueoIdFiscal_ = false;
	_i.colsSubcuentasCli();
	_i.filtraSubcuentasCli();
	_i.filtraSaldoPartidas();
	
  _i.__init();
  connect(this.child("tbnBuscarClienteFac"), "clicked()", _i, "tbnBuscarClienteFac_clicked");
	connect(this.child("tbnQuitarGrupo"), "clicked()", _i, "tbnQuitarGrupo_clicked" );
	_i.filtraTransportistas();
  _i.filtraPrecios();
  _i.inhabilitaContabilidadOficial()
  _i.iniciaTablaDtos();
  _i.habilitaComisiones();
	_i.compruebaSaldo();
	connect(this.child("tdbEmArticulosCli").cursor(), "newBuffer()", _i, "filtraHistorico()");
	_i.filtraHistoricoInit();
	_i.ordenColumnasHis();
	connect(this.child("tdbEmArticulosCliHis").cursor(), "bufferCommited()", _i, "tdbEmArticulosCliHis_bufferCommited");
	_i.controlFichaCostes();
}

function euromoda_filtraSaldoPartidas()
{
// 	this.child("tdbSaldoPartidas").setFilter();
	this.child("tdbSaldoPartidas").refresh();
}

function euromoda_tbwCliente_currentChanged(nombre)
{
	var cursor= this.cursor();
	var util= new FLUtil();
	
	switch (nombre) {
		case "contabilidad": {
			var codEjercicioActual = flfactppal.iface.pub_ejercicioActual();
			var qrySubcuentasCli= new FLSqlQuery;
			with (qrySubcuentasCli) {
				setTablesList("co_subcuentascli");
				setSelect("codejercicio");
				setFrom("co_subcuentascli");
				setWhere("codcliente = '" + cursor.valueBuffer("codcliente") + "' ORDER BY codejercicio");
				setForwardOnly(true);
			}
			if (!qrySubcuentasCli.exec())
				return false;
			var fila= -1;
			while (qrySubcuentasCli.next()) {
				fila++;
				if (qrySubcuentasCli.value("codejercicio") == codEjercicioActual) {
					break;
				}
			}
			if (fila > -1) {
				this.child("tdbSubcuentas").setCurrentRow(fila);
			}
			break;
		}
	}
}

function euromoda_colsSubcuentasCli()
{
	var oC = ["codsubcuenta", "codejercicio", "descripcion"];
	this.child("tdbSubcuentas").setOrderCols(oC);
}

function euromoda_filtraSubcuentasCli()
{
	var _i = this.iface;
	var filtro = "false";
	var cursor = this.cursor();
	var codSubcuenta = _i.calculateField("codsubcuenta");
	if (codSubcuenta) {
		filtro = "codsubcuenta = '" + codSubcuenta + "'";
	}
	this.child("tdbSubcuentas").cursor().setMainFilter(filtro);
	this.child("tdbSubcuentas").refresh();
	_i.filtraPartidasCli();
}

function euromoda_filtraPartidasCli()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var listaSubcuentas = _i.commonCalculateField("listasubcuentas", cursor);
	
	var codEjercicio = AQUtil.sqlSelect("co_subcuentas", "codejercicio", "idsubcuenta = " + cursor.valueBuffer("idsubcuenta"));
	this.child("tdbPartidas").setFilter("codejercicio = '" + codEjercicio + "' AND codsubcuenta IN (" + listaSubcuentas +  ")");
	this.child("tdbPartidas").refresh();
}

function euromoda_habilitaComisiones()
{
  var cursor = this.cursor();
  this.child("fdbPorComision").setDisabled(!cursor.valueBuffer("comisionfija"));
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) { 
  case "comisionfija": {
      _i.habilitaComisiones();
      if (!cursor.valueBuffer("comisionfija")) {
        sys.setObjText(this, "fdbPorComision", "");
      }
      break;
    }
	case "tipoidfiscal": {
		if (!_i.bloqueoIdFiscal_) {
			_i.bloqueoIdFiscal_ = true;
			if (cursor.valueBuffer("tipoidfiscal") == "NIF/IVA" || cursor.valueBuffer("tipoidfiscal") == "Otro") {
				cursor.setValueBuffer("codgrupocontablecli", _i.calculateField("codgrupocontablecli"));
			}
			_i.bloqueoIdFiscal_ = false;
		}
		break;
	}
	case "codgrupocontablecli": {
		_i.filtraSubcuentasCli();
		if (!_i.bloqueoIdFiscal_) {
			_i.bloqueoIdFiscal_ = true;
			if (cursor.valueBuffer("codgrupocontablecli") == "UE" || cursor.valueBuffer("codgrupocontablecli") == "INT") {
				cursor.setValueBuffer("tipoidfiscal", _i.calculateField("tipoidfiscal"));
			}
			_i.bloqueoIdFiscal_ = false;
		}
		sys.setObjText(this, "fdbCodSubcuenta", _i.calculateField("codsubcuenta"));
		break;
	}
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_iniciaTablaDtos()
{
	//this.child("tdbDescuentos").cursor().setMainFilter("tipoventa = 'Cliente'");
	var aC = ["referencia", "articulo", "dtopor", "desde", "hasta", "activo", "sumar"];
	this.child("tdbDescuentos").setOrderCols(aC);
	this.child("fdbPorDtoEsp").close();
}

function euromoda_tbnBuscarClienteFac_clicked()
{
  var f = new FLFormSearchDB("clientes");
  f.setMainWidget();
  var codCliente = f.exec("codcliente");
  if (codCliente) {
    sys.setObjText(this, "fdbCodClienteFac", codCliente);
  }
}

function euromoda_filtraTransportistas()
{
	this.child("fdbCodTransportista").setFilter("esagenciat");
}

function euromoda_filtraPrecios()
{
	this.child("tdbPreciosClientes").cursor().setMainFilter("tipoventa = 'Cliente'");
}

function euromoda_filtraDocumentos()
{
	var f = "";
	if (this.child("chkRecibosPtes").checked) {
		f = "estado IN ('Emitido', 'Devuelto', 'Remesado') AND importe != 0";
	}
	this.child("tdbRecibos").setFilter(f);
	this.child("tdbRecibos").refresh();
}

function euromoda_inhabilitaContabilidadOficial()
{
  var controles = ["fdbIdSubcuenta", "fdbDesSubcuenta", "fdbEjercicioSubcuenta", "fdbDebeSubcuenta", "fdbHaberSubcuenta", "fdbSaldoSubcuenta", "groupBox4_2_2", "groupBoxSubcuentas"];
  for (var i = 0; i < controles.length; i++) {
    sys.disableObj(this, controles[i]);
  }
}

function euromoda_mostrarLibroMayor()
{
	var util:FLUtil;
	var cursor= this.cursor();
	var codSubcuenta= this.child("tdbSubcuentas").cursor().valueBuffer("codsubcuenta");
	var codEjercicio= this.child("tdbSubcuentas").cursor().valueBuffer("codejercicio");
	if(!codSubcuenta || codSubcuenta == "" || !codEjercicio || codEjercicio == "") {
		MessageBox.warning(util.translate("scripts","Debe seleccionar una subcuenta por ejercicio"),MessageBox.Ok, MessageBox.NoButton,MessageBox.NoButton);
		return;
	}

	var curImprimir= new FLSqlCursor("co_i_mayor");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_co__subcuentas_codsubcuenta", codSubcuenta);
	curImprimir.setValueBuffer("h_co__subcuentas_codsubcuenta", codSubcuenta);
	curImprimir.setValueBuffer("i_co__partidas_codcliente", cursor.valueBuffer("codcliente"));
	curImprimir.setValueBuffer("i_co__subcuentas_codejercicio", codEjercicio);
	
	formco_i_mayor.iface.pub_ponDatosSubcuenta(curImprimir);

	flcontinfo.iface.pub_lanzarInforme(curImprimir, "co_i_mayor", "", "co_subcuentas.codsubcuenta, co_asientos.fecha, co_asientos.numero", "", "", curImprimir.valueBuffer("id"));
}

function euromoda_dameWhereRecibosSaldo()
{
	return "estado IN ('Emitido', 'Devuelto', 'Remesado') AND importe != 0";
}

function euromoda_dameFilasSeleccionSaldo()
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var aFilas = _i.__dameFilasSeleccionSaldo();
	if (!aFilas) {
		return false;
	}
	for (var i = 0; i < aFilas.length; i++) {
		if (t.text(aFilas[i], _i.sIDT) == "RECIBO" && t.text(aFilas[i], _i.sEST) == "Remesado") {
			MessageBox.warning(sys.translate("No puede usar recibos remesados en una cancelaci�n"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	}
	return aFilas;
}

function euromoda_cancelaAnticipoSaldo(aFilas, aTipos)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	if (aTipos["recibos"] > 0 && aTipos["anticipos"] == 0 && aTipos["partidas"] == 0) {
		if (!_i.agrupaRecibos(aFilas, aTipos)) {
			debug("1");
			return false;
		}
	} else if (aTipos["recibos"] == 1 && aTipos["anticipos"] == 1 && aTipos["partidas"] == 0) {
		if (!_i.cancelaRecibosAnticipo(aFilas, aTipos)) {
			debug("2");
			return false;
		}
	} else if (aTipos["recibos"] == 1 && aTipos["anticipos"] == 0 && aTipos["partidas"] == 1) {
		if (!_i.cancelaReciboPartida(aFilas)) {
			debug("3");
			return false;
		}
	} else if (aTipos["recibos"] == 0 && aTipos["anticipos"] == 1 && aTipos["partidas"] == 1) {
		if (!_i.cancelaAnticipoPartida(aFilas)) {
			debug("4");
			return false;
		}
	} else if (aTipos["recibos"] == 0 && aTipos["anticipos"] == 0 && aTipos["partidas"] == 2) {
		if (!_i.cancelaPartidaPartida(aFilas)) {
			debug("5");
			return false;
		}
	} else {
		MessageBox.warning(sys.translate("La combinaci�n de anticipos y recibos seleccionada no es v�lida"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	_i.cargaTablaSaldo();
	
// 	var tipo1 = t.text(aFilas[0], _i.sIDT);
// 	var tipo2 = t.text(aFilas[1], _i.sIDT);
// debug("tipo1 " + tipo1);
// debug("tipo2 " + tipo2);
// 	if ((tipo1 == "ANTICIPO" && tipo2 == "RECIBO") || (tipo2 == "ANTICIPO" && tipo1 == "RECIBO")) {
// 		if (!_i.__cancelaAnticipoSaldo(aFilas)) {
// 			return false;
// 		}
// 	} else if (tipo1 == "RECIBO" && tipo2 == "RECIBO") {
// 		if (!_i.compensaRecibos(aFilas)) {
// 			return false;
// 		}
// 	} else if ((tipo1 == "PARTIDA" && tipo2 == "RECIBO") || (tipo2 == "PARTIDA" && tipo1 == "RECIBO")) {
// 		if (!_i.cancelaReciboPartida(aFilas)) {
// 			return false;
// 		}
// 	} else if ((tipo1 == "PARTIDA" && tipo2 == "ANTICIPO") || (tipo2 == "PARTIDA" && tipo1 == "ANTICIPO")) {
// 		if (!_i.cancelaAnticipoPartida(aFilas)) {
// 			return false;
// 		}
// 	} else if ((tipo1 == "PARTIDA" && tipo2 == "PARTIDA")) {
// 		if (!_i.cancelaPartidaPartida(aFilas)) {
// 			return false;
// 		}
// 	} else {
// 		MessageBox.warning(sys.translate("Combinaci�n de tipos de registro no implementada"));
// 	}
	_i.cargaTablaSaldo();
}

// function euromoda_compensaRecibos(aFilas)
// {
// 	var _i = this.iface;
// 	var t = _i.tblSaldo_;
// 	var curR1 = new FLSqlCursor("reciboscli");
// 	var curR2 = new FLSqlCursor("reciboscli");
// 	curR1.select("idrecibo = " + t.text(aFilas[0], _i.sIDD));
// 	curR2.select("idrecibo = " + t.text(aFilas[1], _i.sIDD));
// 	if (!curR1.first()) {
// 		MessageBox.warning(sys.translate("Error al localizar el recibo %1").arg(t.text(aFilas[0], _i.sIDD)), MessageBox.Ok, MessageBox.NoButton);
// 		return false;
// 	}
// 	if (!curR2.first()) {
// 		MessageBox.warning(sys.translate("Error al localizar el recibo %1").arg(t.text(aFilas[1], _i.sIDD)), MessageBox.Ok, MessageBox.NoButton);
// 		return false;
// 	}
// 	
// 	var curT = new FLSqlCursor("empresa");
// 	curT.transaction(false);
// 	try {
// 		if (_i.compensaRecibosTR(curR1, curR2)) {
// 			curT.commit();
// 		} else {
// 			curT.rollback();
// 			MessageBox.critical(sys.translate("Error al compensar los recibos"), MessageBox.Ok, MessageBox.NoButton);
// 			return false;
// 		}
// 	} catch (e) {
// 		curT.rollback();
// 		MessageBox.critical(sys.translate("Error al compensar los recibos: ") + e, MessageBox.Ok, MessageBox.NoButton);
// 		return false;
// 	}
// 	return true;
// }

// function euromoda_compensaRecibosTR(curR1, curR2)
// {
// 	/// Control de que la divisi�n ir� bien
// 	var importeF1 = AQUtil.sqlSelect("reciboscli", "SUM(importe)", "idfactura = " + curR1.valueBuffer("idfactura"));
// 	importeF1 = isNaN(importeF1) ? 0 : AQUtil.roundFieldValue(importeF1, "reciboscli", "importe");
// 	var importeF2 = AQUtil.sqlSelect("reciboscli", "SUM(importe)", "idfactura = " + curR2.valueBuffer("idfactura"));
// 	importeF2 = isNaN(importeF2) ? 0 : AQUtil.roundFieldValue(importeF2, "reciboscli", "importe");
// 		
// 	curR1.setModeAccess(curR1.Edit);
// 	curR1.refreshBuffer();
// 	curR2.setModeAccess(curR2.Edit);
// 	curR2.refreshBuffer();
// 
// 	if (curR1.valueBuffer("importe") != (curR2.valueBuffer("importe") * -1)) {
// 		var importe1 = curR1.valueBuffer("importe");
// 		var importe2 = curR2.valueBuffer("importe");
// 		var nuevoImporte;
// 		if (importe1 > importe2) {
// 			nuevoImporte = importe2 * -1;
// 			nuevoImporte = AQUtil.roundFieldValue(nuevoImporte, "reciboscli", "importe");
// 			curR1.setModeAccess(curR1.Edit);
// 			curR1.refreshBuffer();
// 			curR1.setValueBuffer("importe", nuevoImporte);
// 			curR1.setValueBuffer("importesingd", nuevoImporte - curR1.valueBuffer("gastodevol")); /// Ext. gasto_devol_cli
// 			if (!formRecordreciboscli.iface.pub_divisionRecibo(curR1, importe1)) {
// 				return false;
// 			}
// 		} else {
// 			nuevoImporte = importe1 * -1;
// 			nuevoImporte = AQUtil.roundFieldValue(nuevoImporte, "reciboscli", "importe");
// 			curR2.setModeAccess(curR2.Edit);
// 			curR2.refreshBuffer();
// 			curR2.setValueBuffer("importe", nuevoImporte);
// 			curR2.setValueBuffer("importesingd", nuevoImporte - curR2.valueBuffer("gastodevol")); /// Ext. gasto_devol_cli
// 			if (!formRecordreciboscli.iface.pub_divisionRecibo(curR2, importe2)) {
// 				return false;
// 			}
// 		}
// 	}
// 	curR1.setValueBuffer("estado", "Compensado");
// 	curR1.setValueBuffer("idrecibocomp", curR2.valueBuffer("idrecibo"));
// 	curR2.setValueBuffer("estado", "Compensado");
// 	curR2.setValueBuffer("idrecibocomp", curR1.valueBuffer("idrecibo"));
// 	if (!curR1.commitBuffer()) {
// 		return false;
// 	}
// 	if (!curR2.commitBuffer()) {
// 		return false;
// 	}
// 	
// 	/// Control de que la divisi�n ha ido bien
// 	var importeFinF1 = AQUtil.sqlSelect("reciboscli", "SUM(importe)", "idfactura = " + curR1.valueBuffer("idfactura"));
// 	importeFinF1 = isNaN(importeFinF1) ? 0 : AQUtil.roundFieldValue(importeFinF1, "reciboscli", "importe");
// 	var importeFinF2 = AQUtil.sqlSelect("reciboscli", "SUM(importe)", "idfactura = " + curR2.valueBuffer("idfactura"));
// 	importeFinF2 = isNaN(importeFinF2) ? 0 : AQUtil.roundFieldValue(importeFinF2, "reciboscli", "importe");
// 	if (importeF1 != importeFinF1 || importeF2 != importeFinF2) {
// 		debug(importeF1 + " != " + importeFinF1 + " O " + importeF2 + " != " + importeFinF2);
// 		return false;
// 	}
// 	return true;
// }

function euromoda_establecerSubcuenta() 
{
	var _i = this.iface;
	_i.__establecerSubcuenta();

	_i.filtraPartidasCli();
	var sI = _i.calculateField("saldoinicial");
	sys.setObjText(this, "lblSaldoInicial", sys.translate("Saldo inicial %1").arg(sI));
}

function euromoda_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "saldoinicial": {
			var curSubcuenta = this.child("tdbSubcuentas").cursor();
			var subcuentas = _i.calculateField("listasubcuentas");
			var fechaInicio = AQUtil.sqlSelect("ejercicios", "fechainicio", "codejercicio = '" + curSubcuenta.valueBuffer("codejercicio") + "'");
			if (!fechaInicio) {
				valor = 0;
				break;
			}
			valor = AQUtil.sqlSelect("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento", "SUM(debe-haber)", "p.codsubcuenta IN (" + subcuentas + ") AND a.fecha < '" + fechaInicio + "' AND codcliente = '" + cursor.valueBuffer("codcliente") + "'", "co_partidas,co_asientos");
			valor = isNaN(valor) ? 0 : valor;
			valor = AQUtil.formatoMiles(AQUtil.roundFieldValue(valor, "co_partidas", "debe"));
			break;
		}
		case "tipoidfiscal": {
			switch (cursor.valueBuffer("codgrupocontablecli")) {
				case "UE": {
					valor = "NIF/IVA";
					break;
				}
				case "INT": {
					valor = "Otro";
					break;
				}
			}
			break;
		}
		case "codgrupocontablecli": {
			switch (cursor.valueBuffer("tipoidfiscal")) {
				case "NIF/IVA": {
					valor = "UE";
					break;
				}
				case "Otro": {
					valor = "INT";
					break;
				}
			}
			break;
		}
		case "codsubcuenta": {
			valor = _i.commonCalculateField("codsubcuenta", cursor);
			break;
		}
		default: {
			valor = _i.__calculateField(fN);
		}
	}
	return valor;
}

function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.validaCIFEuromoda()) {
		return false;
	}
	return true;
}

function euromoda_validaCIFEuromoda()
{
	var cursor = this.cursor();
	if ((cursor.valueBuffer("tipoidfiscal") == "NIF/IVA" && cursor.valueBuffer("codgrupocontableneg") != "UE") || (cursor.valueBuffer("tipoidfiscal") != "NIF/IVA" && cursor.valueBuffer("codgrupocontableneg") == "UE")) {
		MessageBox.warning(sys.translate("Si el tipo de identificador fiscal es NIF/IVA, el grupo contable de negocio debe ser UE y viceversa"), MessageBox.Ok, MessageBox.NoButton);
    return false;
	}
	if ((cursor.valueBuffer("tipoidfiscal") == "Otro" && cursor.valueBuffer("codgrupocontableneg") != "EXPORT") || (cursor.valueBuffer("tipoidfiscal") != "Otro" && cursor.valueBuffer("codgrupocontableneg") == "EXPORT")) {
		MessageBox.warning(sys.translate("Si el tipo de identificador fiscal es Otro, el grupo contable de negocio debe ser EXPORT y viceversa"), MessageBox.Ok, MessageBox.NoButton);
    return false;
	}
	return true;
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "saldoanticipos": {
			valor = parseFloat(AQUtil.sqlSelect("co_partidas", "SUM(debe-haber)", "codsubcuenta IN (" + _i.commonCalculateField("listasubcuentas", cursor) + ") AND codcliente = '" + cursor.valueBuffer("codcliente") + "'"));
			valor = isNaN(valor) ? 0 : valor;

			valor = AQUtil.roundFieldValue(valor, "co_subcuentas", "saldo"); //15-11-2021
			break;
		}
		case "codsubcuenta": {
			valor = AQUtil.sqlSelect("gruposcontablescli", "codsubcuentacli", "codgrupo = '" + cursor.valueBuffer("codgrupocontablecli") + "'");
			valor = valor ? valor : "";
			break;
		}
		case "listasubcuentas": {
			valor = _i.dameListaSubcuentas(cursor.valueBuffer("codgrupocontablecli"));
			break;
		}
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function euromoda_dameListaSubcuentas(codGrupoContableCli)
{
	var _i = this.iface;
	var q = new FLSqlQuery;
	q.setSelect("codsubcuentacli, codsubcuentaefectos, codsubcuentaefdesc, codsubcuentaefcobro, codsubcuentaefimp, codsubcuentafaccobro, codsubcuentafacdesc, codsubcuentafacimp");
	q.setFrom("gruposcontablescli");
	q.setWhere("codgrupo = '" + codGrupoContableCli + "'");
	if (!q.exec()) {
		return false;
	}
	if (!q.first()) {
		return "'Not Found'";
	}
	var valor = "";
	valor += ("'" + q.value("codsubcuentacli") + "'");
	valor += q.value("codsubcuentaefectos") != "" ? (", '" + q.value("codsubcuentaefectos") + "'") : "";
	valor += q.value("codsubcuentaefdesc") != "" ? (", '" + q.value("codsubcuentaefdesc") + "'") : "";
	valor += q.value("codsubcuentaefcobro") != "" ? (", '" + q.value("codsubcuentaefcobro") + "'") : "";
	valor += q.value("codsubcuentaefimp") != "" ? (", '" + q.value("codsubcuentaefimp") + "'") : "";
	valor += q.value("codsubcuentafaccobro") != "" ? (", '" + q.value("codsubcuentafaccobro") + "'") : "";
	valor += q.value("codsubcuentafacdesc") != "" ? (", '" + q.value("codsubcuentafacdesc") + "'") : "";
	valor += q.value("codsubcuentafacimp") != "" ? (", '" + q.value("codsubcuentafacimp") + "'") : "";
debug("lista = " + valor);
	return valor;
}

function euromoda_compruebaSaldo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.modeAccess() != cursor.Edit) {
		return true;
	}
	var codSubcuenta = cursor.valueBuffer("codsubcuenta");
	if (!codSubcuenta || codSubcuenta == "") {
		sys.setObjText(this, "fdbCodSubcuenta", _i.calculateField("codsubcuenta"));
	}
	sys.setObjText(this, "fdbSaldoAnticipos", _i.calculateField("saldoanticipos"));
}

function euromoda_cargaOtrosSaldos(aDatos)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codCliente = cursor.valueBuffer("codcliente");
	var listaSubcuentas = _i.calculateField("listasubcuentas");
	
	var qPartidas = new FLSqlQuery;
	qPartidas.setSelect("p.idpartida, a.fecha, a.numero, p.importependiente, p.importependientemig");
	qPartidas.setFrom("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento");
	qPartidas.setWhere("p.codcliente = '" + codCliente + "' AND p.importependiente <> 0 AND codsubcuenta IN (" + listaSubcuentas + ")");
	qPartidas.setForwardOnly(true)
	if (!qPartidas.exec()) {
		return false;
	}
debug("partidas " + qPartidas.sql());

	var i = aDatos.length;
	while (qPartidas.next()) {
		aDatos[i] = new Object;
		aDatos[i]["id"] = qPartidas.value("p.idpartida");
		aDatos[i]["tipo"] = "PARTIDA";
		aDatos[i]["destipo"] = sys.translate("Partida");
		aDatos[i]["fecha"] = qPartidas.value("a.fecha");
		aDatos[i]["vencimiento"] = "";
		aDatos[i]["estado"] = sys.translate("Pendiente");
		aDatos[i]["codigo"] = qPartidas.value("a.numero");
		aDatos[i]["importeinicial"] = qPartidas.value("p.importependientemig");
		aDatos[i]["importepte"] = qPartidas.value("p.importependiente");
		i++;
	}
	return true;
}

function euromoda_cancelaReciboPartida(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var curR = new FLSqlCursor("reciboscli");
	var curP = new FLSqlCursor("co_partidas");
	if (t.text(aFilas[0], _i.sIDT) == "RECIBO") {
		curR.select("idrecibo = " + t.text(aFilas[0], _i.sIDD));
		curP.select("idpartida = " + t.text(aFilas[1], _i.sIDD));
	} else {
		curP.select("idpartida = " + t.text(aFilas[0], _i.sIDD));
		curR.select("idrecibo = " + t.text(aFilas[1], _i.sIDD));
	}
	if (!curR.first()) {
		MessageBox.warning(sys.translate("Error al localizar el recibo"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	if (!curP.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (flfactteso.iface.pub_cancelaReciboPartidaTR(curR, curP)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.critical(sys.translate("Error al cancelar el recibo"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} catch (e) {
		curT.rollback();
		MessageBox.critical(sys.translate("Error al al cancelar el recibo: ") + e, MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	return true;
}

function euromoda_cancelaAnticipoPartida(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var curA = new FLSqlCursor("anticiposcli");
	var curP = new FLSqlCursor("co_partidas");
	if (t.text(aFilas[0], _i.sIDT) == "ANTICIPO") {
		curA.select("idanticipo = " + t.text(aFilas[0], _i.sIDD));
		curP.select("idpartida = " + t.text(aFilas[1], _i.sIDD));
	} else {
		curP.select("idpartida = " + t.text(aFilas[0], _i.sIDD));
		curA.select("idanticipo = " + t.text(aFilas[1], _i.sIDD));
	}
	if (!curA.first()) {
		MessageBox.warning(sys.translate("Error al localizar el anticipo"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	if (!curP.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (flfactteso.iface.pub_cancelaAnticipoPartidaTR(curA, curP)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.critical(sys.translate("Error al cancelar el anticipo"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} catch (e) {
		curT.rollback();
		MessageBox.critical(sys.translate("Error al al cancelar el anticipo: ") + e, MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	return true;
}

function euromoda_cancelaPartidaPartida(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	
	var curP1 = new FLSqlCursor("co_partidas");
	var curP2 = new FLSqlCursor("co_partidas");
	curP1.select("idpartida = " + t.text(aFilas[0], _i.sIDD));
	curP2.select("idpartida = " + t.text(aFilas[1], _i.sIDD));
	if (!curP1.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida 1"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	if (!curP2.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida 2"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (flfactteso.iface.pub_cancelaPartidaPartidaTR(curP1, curP2)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.critical(sys.translate("Error al cancelar el anticipo"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} catch (e) {
		curT.rollback();
		MessageBox.critical(sys.translate("Error al al cancelar el anticipo: ") + e, MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	return true;
}

function euromoda_tbnEditaAR_clicked()
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	var f = t.currentRow();
	if (t.text(f, _i.sIDT) != "PARTIDA") {
		_i.__tbnEditaAR_clicked();
		return;
	}
	if (_i.curRA) {
		delete _i.curRA;
	}
	_i.curRA = new FLSqlCursor("co_partidas");
	_i.curRA.select("idpartida = " + t.text(f, _i.sIDD));
	if (!_i.curRA.first()) {
		MessageBox.warning(sys.translate("Error al localizar la partida"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	disconnect(_i.curRA, "bufferCommited()", _i, "curRA_bufferCommited");
	connect(_i.curRA, "bufferCommited()", _i, "curRA_bufferCommited");
	_i.curRA.browseRecord();
}

function euromoda_coloresSaldo()
{
	var _i = this.iface;
	_i.__coloresSaldo();
	_i.cPar = new Color(255, 150, 130);
}

function euromoda_dameTiposFila(aFilas)
{
	var _i = this.iface;
	var t = _i.tblSaldo_;
	var aT = new Object;
	aT["recibos"] = 0;
	aT["anticipos"] = 0;
	aT["partidas"] = 0;
	aT["listarec"] = [];
	aT["listaant"] = [];
	aT["listapar"] = [];
	for (var i = 0; i < aFilas.length; i++) {
		switch (t.text(aFilas[i], _i.sIDT)) {
			case "RECIBO": {
				aT["recibos"]++;
				aT["listarec"].push(t.text(aFilas[i], _i.sIDD));
				break;
			}
			case "ANTICIPO": {
				aT["anticipos"]++;
				aT["listaant"].push(t.text(aFilas[i], _i.sIDD));
				break;
			}
			case "PARTIDA": {
				aT["partidas"]++;
				aT["listapar"].push(t.text(aFilas[i], _i.sIDD));
				break;
			}
		}
	}
	return aT;
}


function euromoda_tbnQuitarGrupo_clicked()
{	
	var _i = this.iface;
	var cursor = this.cursor();
	
	var t = _i.tblSaldo_;
	var f = t.currentRow();
	var codigoRecibo = t.text(f, _i.sDOC);
	var inicialesCodigo = codigoRecibo.left(3);
	
	if(!((t.text(f, _i.sIDT) == "RECIBO") && (inicialesCodigo == "GRC"))) {
		MessageBox.warning(sys.translate("S�lo puede eliminar grupos de recibos"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	
	var estado = t.text(f, _i.sEST);
	if (estado != "Emitido") {
		MessageBox.warning(sys.translate("S�lo puede eliminar grupos de recibos en estado Emitido"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	
	var res = MessageBox.information(sys.translate("Va a deshacer la agrupaci�n de recibos %1.\n�Desea continuar?").arg(codigoRecibo), MessageBox.Ok, MessageBox.Cancel);
	if (res != MessageBox.Ok){
		return false;
	}
	
	var codigoRecibo = t.text(f, _i.sDOC);
	var idRecibo = AQUtil.sqlSelect("reciboscli", "idrecibo", "codigo = '" + codigoRecibo + "'");
	if(!idRecibo){
		return false;
	}
	var oParam = new Object;
	oParam.idGrupo = idRecibo;
	
	oParam.errorMsg = sys.translate("Error al eliminar el grupo de recibos");
	var f = new Function("oParam", "return flfactteso.iface.pub_quitaGrupoRecibosCli(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	
	MessageBox.information(sys.translate("Se ha eliminado el grupo de recibos %1").arg(codigoRecibo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	
	_i.cargaTablaSaldo();
}
function euromoda_filtroRecibos()
{
	var _i = this.iface;
	var filtro = _i.__filtroRecibos();
	if (this.child("chkRecibosPtes").checked) {
		filtro = filtro + " AND importe != 0";
	}
	return filtro;

}
function euromoda_habilitarPorDeposito()
{
	var _i = this.iface;
	_i.__habilitarPorDeposito();
	var cursor = this.cursor();

	if (cursor.valueBuffer("deposito")) {		
		sys.enableObj(this, "fdbEmCodAlmaCliente");
		sys.enableObj(this, "fdbEmCentroCliente");
	} else {		
		sys.setObjText(this, "fdbEmCodAlmaCliente", "");
		sys.setObjText(this, "fdbEmCentroCliente", "");
		sys.disableObj(this, "fdbEmCodAlmaCliente");
		sys.disableObj(this, "fdbEmCentroCliente");

	}
}
function euromoda_filtraHistoricoInit()
{
	var _i = this.iface;
	var filtro = false;
	var codCliente = this.cursor().valueBuffer("codcliente");
	var idArticuloCli = AQUtil.sqlSelect("em_articuloscli", "id", "codcliente='" + codCliente + "' order by referencia");
	if (idArticuloCli) {
		filtro = "idarticuloscli = " + idArticuloCli ;
	}	
	this.child("tdbEmArticulosCliHis").cursor().setMainFilter(filtro);
	this.child("tdbEmArticulosCliHis").refresh();	

}
function euromoda_filtraHistorico()
{
	var _i = this.iface;
	var filtro = "false";
	var cursorArtCli = this.child("tdbEmArticulosCli").cursor();
	var idArticuloCli = cursorArtCli.valueBuffer("id");
	
	if (idArticuloCli) {
		filtro = "idarticuloscli = " + idArticuloCli ;
	}	
	this.child("tdbEmArticulosCliHis").cursor().setMainFilter(filtro);
	this.child("tdbEmArticulosCliHis").refresh();	
	
}
function euromoda_ordenColumnasHis()
{
	var _i = this.iface;
	var t = this.child("tdbEmArticulosCliHis");
	var listaCampos = ["fechavalidez", "pvpbase", "dtopor", "pvpdto", "pvpsiniva", "dtoemoda", "pvpeuromoda"];
	this.child("tdbEmArticulosCliHis").setOrderCols(listaCampos);
	this.child("tdbEmArticulosCliHis").switchSortOrder(0);
	
}
function euromoda_tdbEmArticulosCliHis_bufferCommited()
{
	this.child("tdbEmArticulosCli").refresh();

}

function euromoda_controlFichaCostes()
{
	var _i = this.iface;	
	var usuario = sys.nameUser();
	var cambiarMargen = false;
	var q = new AQSqlQuery;	
	q.setSelect("em_cambiarmargenesprod");
	q.setFrom("usuarios");
	q.setWhere("idusuario = '" + usuario + "'");	
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		cambiarMargen = q.value("em_cambiarmargenesprod");				
	}
	if(!cambiarMargen) {
		this.child("tbwCliente").setTabEnabled("em_costesprod", false);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
