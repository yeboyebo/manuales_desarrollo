
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
	var cCAN,cPRE,cPORDTO,cPORCOMF,cPRET,cIMPT,cDTOC,cCOMC;
  function euromoda(context)
  {
    oficial(context);
  }
  function actualizaTotalComision() {
		return this.ctx.euromoda_actualizaTotalComision();
	}
	function init() {
		return this.ctx.euromoda_init();
	}
	function cargaTabla() {
		return this.ctx.euromoda_cargaTabla();
	}
	function damePrecioTarifa(fila) {
		return this.ctx.euromoda_damePrecioTarifa(fila);
	}
	function dameImporteTarifa(fila) {
		return this.ctx.euromoda_dameImporteTarifa(fila);
	}
	function dameDescuentoCalculado(fila) {
		return this.ctx.euromoda_dameDescuentoCalculado(fila);
	}
	function dameComisionCalculado(fila) {
		return this.ctx.euromoda_dameComisionCalculado(fila);
	}
	function colores(fila) {
		return this.ctx.euromoda_colores(fila);
	}
	function tblLineas_clicked(f, c) {
		return this.ctx.euromoda_tblLineas_clicked(f, c);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_actualizaTotalComision()
{
	var cursor = this.cursor();
	var porDtoEsp = cursor.valueBuffer("pordtoesp");
	porDtoEsp = isNaN(porDtoEsp) ? 0 : porDtoEsp;
	var _i = this.iface;
	var nF = _i.tblLineas_.numRows();
	var neto, porComision, total = 0;
	for (var f = 0; f < nF; f++) {
		porComision = _i.tblLineas_.text(f, _i.cPOR);
		if (isNaN(porComision)) {
			return;
		}
		neto = _i.tblLineas_.text(f, _i.cIMP);
		total += (porComision * (neto * (100 - porDtoEsp) / 100) / 100);
	}
	total = AQUtil.roundFieldValue(total, "facturascli", "total");
	this.child("lblComision").text = total;
}

function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	this.child("fdbPorDtoEsp").setDisabled(true);
	connect(_i.tblLineas_, "doubleClicked(int, int)", _i, "tblLineas_clicked");	
}

function euromoda_cargaTabla()
{
	var cursor = this.cursor();
	var _i = this.iface;
	var c = 0, cols = "", s = "*";
	_i.cIDL = c++;
	cols += sys.translate("Id.L�nea");

	_i.cREF = c++;
	cols += s;
	cols += sys.translate("Referencia");

	_i.cDES = c++;
	cols += s;
	cols += sys.translate("Descripci�n");

	_i.cCAN = c++;
	cols += s;
	cols += sys.translate("Cantidad");

	_i.cPRE = c++;
	cols += s;
	cols += sys.translate("Precio/Ud.Fact.");

	_i.cIMP = c++;
	cols += s;
	cols += sys.translate("Importe Fact.");

	_i.cPORDTO = c++;
	cols += s;
	cols += sys.translate("%Dto. Fact.");

	_i.cPORCOMF = c++;
	cols += s;
	cols += sys.translate("%Com. Fact.");	

	_i.cPRET = c++;
	cols += s;
	cols += sys.translate("Precio tarifa");

	_i.cIMPT = c++;
	cols += s;
	cols += sys.translate("Importe tarifa");

	_i.cDTOC = c++;
	cols += s;
	cols += sys.translate("%Dto. Calc.");

	_i.cCOMC = c++;
	cols += s;
	cols += sys.translate("%Com. Calc.");

	_i.cPOR = c++;
	cols += s;
	cols += sys.translate("%Com. A aplicar.");

	_i.tblLineas_.setNumCols(c);
	_i.tblLineas_.setColumnLabels(s, cols);
	_i.tblLineas_.hideColumn(_i.cIDL);
	_i.tblLineas_.setColumnReadOnly(_i.cREF, true);
	_i.tblLineas_.setColumnReadOnly(_i.cDES, true);
	_i.tblLineas_.setColumnReadOnly(_i.cCAN, true);
	_i.tblLineas_.setColumnReadOnly(_i.cPRE, true);
	_i.tblLineas_.setColumnReadOnly(_i.cIMP, true);

	_i.tblLineas_.setColumnReadOnly(_i.cPORDTO, true);
	_i.tblLineas_.setColumnReadOnly(_i.cPORCOMF, true);
	_i.tblLineas_.setColumnReadOnly(_i.cPRET, true);
	_i.tblLineas_.setColumnReadOnly(_i.cIMPT, true);
	_i.tblLineas_.setColumnReadOnly(_i.cDTOC, true);
	_i.tblLineas_.setColumnReadOnly(_i.cCOMC, true);


	_i.tblLineas_.setColumnWidth(_i.cDES, 350);


	var q = new FLSqlQuery();
	q.setSelect("idlinea, referencia, descripcion,cantidad, pvpunitario, pvptotal, dtopor, porcomision");
	if (cursor.table() == "facturascli") {
		q.setFrom("lineasfacturascli");
		q.setWhere("idfactura = " + cursor.valueBuffer("idfactura") + " ORDER BY referencia");
	} else {
		q.setFrom("lineasalbaranescli");
		q.setWhere("idalbaran = " + cursor.valueBuffer("idalbaran") + " ORDER BY referencia");
	}
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	var f = 0;
	var fila = 0;
	while (q.next()) {
		
		_i.tblLineas_.insertRows(f);

		_i.colores(fila);

		_i.tblLineas_.setText(f, _i.cIDL, q.value("idlinea"));
		_i.tblLineas_.setText(f, _i.cREF, q.value("referencia"));
		_i.tblLineas_.setText(f, _i.cDES, q.value("descripcion"));
		_i.tblLineas_.setText(f, _i.cCAN, AQUtil.roundFieldValue(q.value("cantidad"), "lineasfacturascli", "cantidad"));
		_i.tblLineas_.setText(f, _i.cPRE, AQUtil.roundFieldValue(q.value("pvpunitario"), "lineasfacturascli", "pvpunitario"));
		_i.tblLineas_.setText(f, _i.cIMP, AQUtil.roundFieldValue(q.value("pvptotal"), "lineasfacturascli", "pvptotal"));
		_i.tblLineas_.setText(f, _i.cPORDTO, AQUtil.roundFieldValue(q.value("dtopor"), "lineasfacturascli", "dtopor"));
		_i.tblLineas_.setText(f, _i.cPORCOMF, AQUtil.roundFieldValue(q.value("porcomision"), "lineasfacturascli", "porcomision"));		
		_i.tblLineas_.setText(f, _i.cPRET,  AQUtil.roundFieldValue(_i.damePrecioTarifa(f), "lineasfacturascli", "pvpunitario"));
		_i.tblLineas_.setText(f, _i.cIMPT, AQUtil.roundFieldValue(_i.dameImporteTarifa(f), "lineasfacturascli", "pvptotal"));
		_i.tblLineas_.setText(f, _i.cDTOC, AQUtil.roundFieldValue(_i.dameDescuentoCalculado(f), "lineasfacturascli", "dtopor"));
		_i.tblLineas_.setText(f, _i.cCOMC, AQUtil.roundFieldValue(_i.dameComisionCalculado(f), "lineasfacturascli", "porcomision"));
		_i.tblLineas_.setText(f, _i.cPOR, AQUtil.roundFieldValue(q.value("porcomision"), "lineasfacturascli", "porcomision"));
		fila++;

	}
}

function euromoda_damePrecioTarifa(fila)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var referencia = _i.tblLineas_.text(fila, _i.cREF);
	var codCliente = cursor.valueBuffer("codcliente");
	var hoy = new Date();
	var fecha = hoy.toString();
	var valor = formRecordlineaspedidoscli.iface.pub_damePrecioArticulo(referencia, codCliente, fecha);

	return valor;
}

function euromoda_dameImporteTarifa(fila)
{
	var _i = this.iface;
	var cantidad = parseFloat(_i.tblLineas_.text(fila, _i.cCAN));
	var precioTarifa = parseFloat(_i.tblLineas_.text(fila, _i.cPRET));
	var valor = cantidad*precioTarifa;
	return valor; 
}

function euromoda_dameDescuentoCalculado(fila)
{
	var _i = this.iface;
	var importeTarifa = parseFloat(_i.tblLineas_.text(fila, _i.cIMPT));
	var importeFactura = parseFloat(_i.tblLineas_.text(fila, _i.cIMP)); 
	var negativos = false;

	if(importeTarifa <0 && importeFactura <0) {
		negativos = true;
	}

	if(!importeTarifa || importeTarifa == 0) {		
		valor = 0;
	} else if((importeTarifa < importeFactura && !negativos) || (Math.abs(importeTarifa) < Math.abs(importeFactura) && negativos)) {
		valor = 0;
	} else {		
		valor = ((importeTarifa - importeFactura) / importeTarifa) * 100;
	}
	
	return valor;

}

function euromoda_dameComisionCalculado(fila)
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var valor = 0;
	var oDatosComision = new Object;
	oDatosComision.referencia = _i.tblLineas_.text(fila, _i.cREF);
	oDatosComision.dtoPor = parseFloat(_i.tblLineas_.text(fila, _i.cDTOC));
	oDatosComision.codAgente = cursor.valueBuffer("codagente");
	oDatosComision.codCliente = cursor.valueBuffer("codcliente");
	var valor = formRecordlineaspedidoscli.iface.pub_damePorComision(oDatosComision);
	return valor;
}

function euromoda_colores(fila)
{
	var _i = this.iface;
	_i.tblLineas_.setCellBackgroundColor(fila, _i.cCAN,  new Color(flfactppal.iface.dameColor("fondo_azul")));
	_i.tblLineas_.setCellBackgroundColor(fila, _i.cPRE,  new Color(flfactppal.iface.dameColor("fondo_azul")));
	_i.tblLineas_.setCellBackgroundColor(fila, _i.cIMP,  new Color(flfactppal.iface.dameColor("fondo_azul")));
	_i.tblLineas_.setCellBackgroundColor(fila, _i.cPORDTO,  new Color(flfactppal.iface.dameColor("fondo_azul")));
	_i.tblLineas_.setCellBackgroundColor(fila, _i.cPORCOMF,  new Color(flfactppal.iface.dameColor("fondo_azul_claro")));
	_i.tblLineas_.setCellBackgroundColor(fila, _i.cPOR,  new Color(flfactppal.iface.dameColor("fondo_amarillo")));
}

function euromoda_tblLineas_clicked(f, c)
{
	
	var _i = this.iface;
	if(c == _i.cPORCOMF) {
		_i.tblLineas_.setText(f, _i.cPOR, _i.tblLineas_.text(f, _i.cPORCOMF));
	} else if(c == _i.cCOMC) {
		_i.tblLineas_.setText(f, _i.cPOR, _i.tblLineas_.text(f, _i.cCOMC));
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
