
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function datosCuboJofesa(curJ, qJ) {
		return this.ctx.euromoda_datosCuboJofesa(curJ, qJ);
	}
	function datosCuboNecPed(curNP, qNP) {
		return this.ctx.euromoda_datosCuboNecPed(curNP, qNP);
	}
	function datosCuboVicente(curJ, qJ) {
		return this.ctx.euromoda_datosCuboVicente(curJ, qJ);
	}
	function cargarCubo() {
		return this.ctx.euromoda_cargarCubo();
	}
	function nombreCubo(idCubo) {
		return this.ctx.euromoda_nombreCubo(idCubo);
	}
	function cargaCuboJofesa() {
		return this.ctx.euromoda_cargaCuboJofesa();
	}
	function cargaCuboVicente() {
		return this.ctx.euromoda_cargaCuboVicente();
	}
	function cargaCuboNecPed() {
		return this.ctx.euromoda_cargaCuboNecPed();
	}
	function informarArrayCubos(aCubos) {
		return this.ctx.euromoda_informarArrayCubos(aCubos);
	}
	function dameFiltroNivel(aNivel) {
		return this.ctx.euromoda_dameFiltroNivel(aNivel);
	}
	function sincronizarNivel(aNivel) {
		return this.ctx.euromoda_sincronizarNivel(aNivel);
	}
	function exportarTablaCuboExcel(oParam) {
		return this.ctx.euromoda_exportarTablaCuboExcel(oParam);
	}
}
//// EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////
function euromoda_informarArrayCubos(aCubos)
{
	var _i = this.iface;
	aCubos[aCubos.length] = "in_h_jofesa";
	aCubos[aCubos.length] = "in_h_necped";
	aCubos[aCubos.length] = "in_h_vicente";
	return true;
}

function euromoda_nombreCubo(idCubo)
{
	var nombre;
	switch (idCubo) {
		case "in_h_jofesa": {
			nombre = sys.translate("Cubo entrada Jofesa");
			break;
		}
		case "in_h_vicente": {
			nombre = sys.translate("Cubo de Vicente");
			break;
		}
		case "in_h_necped": {
			nombre = sys.translate("Cubo necesidades de pedidos");
			break;
		}
	}
	return nombre;
}

function euromoda_cargarCubo()
{
	var _i = this.iface;
	switch (_i.cubo_) {
		case "in_h_jofesa": {
			if (!_i.cargaCuboJofesa()) {
				return false;
			}
			break;
		}
		case "in_h_vicente": {
			if (!_i.cargaCuboVicente()) {
				return false;
			}
			break;
		}
		case "in_h_necped": {
			if (!_i.cargaCuboNecPed()) {
				return false;
			}
			break;
		}
		default: {
			return false;
		}
	}
	return true;
}

function euromoda_cargaCuboJofesa()
{
	var _i = this.iface;
	var _fD = fldireinne.iface;
	var curJ;
	
	var tablaCubo = "in_h_jofesa";
	if (_i.conexionBI_) {
		curJ = new FLSqlCursor(tablaCubo, _i.conexionBI_);
	} else {
		curJ = new FLSqlCursor(tablaCubo);
	}
	curJ.setActivatedCheckIntegrity(false);
	curJ.setActivatedCommitActions(false);

	var ejercicios = "";
	curJ.setForwardOnly(true);
	if(!AQUtil.execSql("DELETE FROM " + tablaCubo, _i.conexionBI_ ? _i.conexionBI_ : undefined)) {
		_fD.pub_appendTextToLogFile(_i.nombreLog_, "No se pudo borrar el cubo anterior");
		return false;
	}

	var qJ;
	if (_i.conexion_) {
		qJ = new FLSqlQuery("", _i.conexion_);
	} else {
		qJ = new FLSqlQuery();
	}
	qJ.setSelect("op.codorden, ls.codlote, ls.referencia, a.codfamilia, a.codsubfamilia, op.codpedidocli");
	qJ.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion INNER JOIN articulos a ON ls.referencia = a.referencia");
	qJ.setWhere("op.estado <> 'TERMINADA'");
	if (!qJ.exec()) {
		return false;
	}	
	
	if(_i.silent_) {
		_fD.pub_creaPDSilent(qJ.size());
		_fD.pub_appendTextToLogFile(_i.nombreLog_, "Creando cubo");
	}
	else {
		AQUtil.createProgressDialog(sys.translate("Creando cubo"), qJ.size());
	}
	
	var paso = 0;
	while (qJ.next()) {
		if(!_i.datosCuboJofesa(curJ, qJ)) {
			_fD.pub_appendTextToLogFile(_i.nombreLog_, "Error al insertar los datos en el cubo in_h_jofesa");
			AQUtil.destroyProgressDialog();
			return false;
		}

		if(_i.silent_)
			_fD.pub_setProgressPDSilent(paso++);
		else
		AQUtil.setProgress(paso++);
	}
	
	if (!_i.cargarDimensiones(ejercicios)) {
		return false;
	}

	AQUtil.destroyProgressDialog();

	return true;
}

function euromoda_cargaCuboVicente()
{
	var _i = this.iface;
	var _fD = fldireinne.iface;
	var curJ;
	
	var tablaCubo = "in_h_vicente";
	if (_i.conexionBI_) {
		curJ = new FLSqlCursor(tablaCubo, _i.conexionBI_);
	} else {
		curJ = new FLSqlCursor(tablaCubo);
	}
	curJ.setActivatedCheckIntegrity(false);
	curJ.setActivatedCommitActions(false);

	var ejercicios = "";
	curJ.setForwardOnly(true);
	if(!AQUtil.execSql("DELETE FROM " + tablaCubo, _i.conexionBI_ ? _i.conexionBI_ : undefined)) {
		_fD.pub_appendTextToLogFile(_i.nombreLog_, "No se pudo borrar el cubo anterior");
		return false;
	}

	var qJ;
	if (_i.conexion_) {
		qJ = new FLSqlQuery("", _i.conexion_);
	} else {
		qJ = new FLSqlQuery();
	}
	qJ.setSelect("op.codorden, op.estado, op.emobservaciones, op.codconfeccionista, op.nombreconfeccionista, ls.codlote, ls.referencia, a.panotcont, a.coddibestamp, a.codfamilia, f.descripcion, a.codsubfamilia, sf.descripcion, d.descripcion");
	qJ.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion INNER JOIN articulos a ON ls.referencia = a.referencia LEFT OUTER JOIN familias f ON a.codfamilia = f.codfamilia LEFT OUTER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia LEFT OUTER JOIN em_dibujos d ON a.coddibestamp = d.coddibujoem");
	qJ.setWhere("op.estado <> 'TERMINADA'");
	if (!qJ.exec()) {
		return false;
	}	
	
	if(_i.silent_) {
		_fD.pub_creaPDSilent(qJ.size());
		_fD.pub_appendTextToLogFile(_i.nombreLog_, "Creando cubo");
	}
	else {
		AQUtil.createProgressDialog(sys.translate("Creando cubo"), qJ.size());
	}
	
	var paso = 0;
	while (qJ.next()) {
		if(!_i.datosCuboVicente(curJ, qJ)) {
			_fD.pub_appendTextToLogFile(_i.nombreLog_, "Error al insertar los datos en el cubo in_h_vicente");
			AQUtil.destroyProgressDialog();
			return false;
		}

		if(_i.silent_)
			_fD.pub_setProgressPDSilent(paso++);
		else
		AQUtil.setProgress(paso++);
	}
	if (!AQUtil.execSql("UPDATE in_h_vicente SET cd_anverso = 'Anverso: ' || refanverso || ' - ' || desanverso, cd_reverso = 'Reverso: ' || refreverso || ' - ' || desreverso, cd_familia = 'Familia: ' || codfamilia || ' - ' || desfamilia, cd_subfamilia = 'Subfamilia: ' || codsubfamilia || ' - ' || dessubfamilia, dc_anverso = 'Anverso: ' || desanverso || ' - ' || refanverso, dc_reverso = 'Reverso: ' || desreverso || ' - ' || refreverso, dc_familia = 'Familia: ' || desfamilia || ' - ' || codfamilia, dc_subfamilia = 'Subfamilia: ' || dessubfamilia || ' - ' || codsubfamilia;")) {
		return false;
	}
	if (!AQUtil.execSql("UPDATE in_h_vicente SET codorden_f = codorden, codlote_f = codlote, refetieuromoda_f = refetieuromoda, refetiespecial_f = refetiespecial, refetirollo_f = refetirollo, refetiotra_f = refetiotra, refanverso_f = refanverso, desanverso_f = desanverso, refreverso_f = refreverso, desreverso_f = desreverso, refproducto_f = refproducto, desproducto_f = desproducto, codfamilia_f = codfamilia, desfamilia_f = desfamilia, codsubfamilia_f = codsubfamilia, dessubfamilia_f = dessubfamilia, codpedido_f = codpedido, panotcont_f = panotcont, coddibujo_f = coddibujo, desdibujo_f = desdibujo, estadoorden_f = estadoorden, obsorden_f = obsorden, codconfeccion_f = codconfeccion, nombreconfeccion_f = nombreconfeccion, anchoanverso_f = anchoanverso, altoanverso_f = altoanverso, tacoanverso_f = tacoanverso, tacoreverso_f = tacoreverso, tacobies_f = tacobies, tacoanversocojin_f = tacoanversocojin, tacoreversocojin_f = tacoreversocojin, codsubfamanverso_f = codsubfamanverso, dessubfamanverso_f = dessubfamanverso, codcliente_f = codcliente, nombrecliente_f = nombrecliente, fechadoc_f = fechadoc, fechacliente_f = fechacliente, fechaservicio_f = fechaservicio, fechacorte_f = fechacorte, fechaenvioconf_f = fechaenvioconf, cd_anverso_f = cd_anverso, cd_reverso_f = cd_reverso, cd_familia_f = cd_familia, cd_subfamilia_f = cd_subfamilia, dc_anverso_f = dc_anverso, dc_reverso_f = dc_reverso, dc_familia_f = dc_familia, dc_subfamilia_f = dc_subfamilia, tacos_f = tacos, fase_f = fase;")) {
		return false;
	}
	/*
	if (!_i.cargarDimensiones(ejercicios)) {
		return false;
	}
	*/
	AQUtil.destroyProgressDialog();

	return true;
}

function euromoda_cargaCuboNecPed()
{
	var _i = this.iface;
	var _fD = fldireinne.iface;
	var curNP;
	
	var tablaCubo = "in_h_necped";
	if (_i.conexionBI_) {
		curNP = new FLSqlCursor(tablaCubo, _i.conexionBI_);
	} else {
		curNP = new FLSqlCursor(tablaCubo);
	}
	curNP.setActivatedCheckIntegrity(false);
	curNP.setActivatedCommitActions(false);

	var ejercicios = "";
	curNP.setForwardOnly(true);
	if(!AQUtil.execSql("DELETE FROM " + tablaCubo, _i.conexionBI_ ? _i.conexionBI_ : undefined)) {
		_fD.pub_appendTextToLogFile(_i.nombreLog_, "No se pudo borrar el cubo anterior");
		return false;
	}

	//var qNP = (_i.conexion_) ? new FLSqlQuery("", _i.conexion_) : qNP = new FLSqlQuery(); 29-08-2019 pineboo
	var qNP;
	if(_i.conexion_) {
		qNP = new FLSqlQuery("", _i.conexion_);
	} else {
		qNP = new FLSqlQuery();
	}
	
	qNP.setSelect("p.codcliente, p.codigo, lp.referencia, p.fecha, co.referencia, ap.codfamilia, ap.codsubfamilia, ac.codfamilia, ac.codsubfamilia, SUM(co.cantidad*-1), SUM(co.reservaex), SUM(co.reservapr), SUM(co.reservaaf)");
	qNP.setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN movistock ms ON lp.idlinea = ms.idlineapc INNER JOIN movistock co ON ms.idmovimiento = co.idmovproducto INNER JOIN articulos ap ON lp.referencia = ap.referencia INNER JOIN articulos ac ON co.referencia = ac.referencia");
	qNP.setWhere("p.servido <> 'S�' GROUP BY p.codcliente, p.codigo, lp.referencia, p.fecha, co.referencia, ap.codfamilia, ap.codsubfamilia, ac.codfamilia, ac.codsubfamilia");
	if (!qNP.exec()) {
		return false;
	}	
	
	if(_i.silent_) {
		_fD.pub_creaPDSilent(qNP.size());
		_fD.pub_appendTextToLogFile(_i.nombreLog_, "Creando cubo");
	}
	else {
		AQUtil.createProgressDialog(sys.translate("Creando cubo"), qNP.size());
	}
	
	var paso = 0;
	while (qNP.next()) {
		if(!_i.datosCuboNecPed(curNP, qNP)) {
			_fD.pub_appendTextToLogFile(_i.nombreLog_, "Error al insertar los datos en el cubo in_h_necped");
			AQUtil.destroyProgressDialog();
			return false;
		}

		if(_i.silent_)
			_fD.pub_setProgressPDSilent(paso++);
		else
		AQUtil.setProgress(paso++);
	}
	
	if (!_i.cargarDimensiones(ejercicios)) {
		return false;
	}

	AQUtil.destroyProgressDialog();

	return true;
}

function euromoda_datosCuboJofesa(curJ, qJ)
{
	var _i = this.iface;
	
	var campos = "m_metrosanverso,m_metrosreverso,d_codorden,d_codlote,d_refetiquetaprod,d_refanverso,d_refreverso,d_refproducto,d_codfamilia,d_codsubfamilia,d_codpedido";
	var codLote = qJ.value("ls.codlote");
	var refProducto = qJ.value("ls.referencia");
	var codFamilia = qJ.value("a.codfamilia");
	var codSubfamilia = qJ.value("a.codsubfamilia");
	var codPedido = qJ.value("op.codpedidocli");
	if (_i.conexion_) {
		qAnverso = new FLSqlQuery("", _i.conexion_);
	} else {
		qAnverso = new FLSqlQuery();
	}
	qAnverso.setSelect("SUM(ms.cantidad), ms.referencia, ac.componormal");
	qAnverso.setFrom("movistock ms INNER JOIN articuloscomp ac ON ms.idarticulocomp  = ac.id AND ac.componormal IN ('ANVERSO', 'ANVERSO COJIN', 'REVERSO', 'REVERSO COJIN')");
	qAnverso.setWhere("ms.codloteprod = '" + codLote + "' GROUP BY ac.componormal, ms.referencia ORDER BY ac.componormal");
	if (!qAnverso.exec()) {
		return false;
	}
	debug(qAnverso.sql());
	var refAnverso = "", refReverso = "", refAnversoC = "", refReversoC = "";
	var metrosAnverso, metrosReverso, metrosAnversoC, metrosReversoC;
	while (qAnverso.next()) {
		switch (qAnverso.value("ac.componormal")) {
			case "ANVERSO": {
				refAnverso = qAnverso.value("ms.referencia");
				metrosAnverso = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosAnverso = AQUtil.roundFieldValue(metrosAnverso, "in_h_jofesa", "m_metrosreverso");
				break;
			}
			case "REVERSO": {
				refReverso = qAnverso.value("ms.referencia");
				metrosReverso = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosReverso = AQUtil.roundFieldValue(metrosReverso, "in_h_jofesa", "m_metrosreverso");
				break;
			}
			case "ANVERSO COJIN": {
				refAnversoC = qAnverso.value("ms.referencia");
				metrosAnversoC = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosAnversoC = AQUtil.roundFieldValue(metrosAnversoC, "in_h_jofesa", "m_metrosreverso");
				break;
			}
			case "REVERSO COJIN": {
				refReversoC = qAnverso.value("ms.referencia");
				metrosReversoC = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosReversoC = AQUtil.roundFieldValue(metrosReversoC, "in_h_jofesa", "m_metrosreverso");
				break;
			}
		}
	}
	if (refAnverso != "" && refReverso != "") {
		var valores = metrosAnverso.toString() + ", " + metrosReverso.toString() + ", '" + qJ.value("op.codorden") + "', '" + qJ.value("ls.codlote") + "', NULL, '" + refAnverso + "', '" + refReverso + "', '" + refProducto + "', '" + codFamilia + "', '" + codSubfamilia + "', '" + codPedido + "'";
		var sql = "INSERT INTO in_h_jofesa (" + campos + ") VALUES (" + valores + ")";
		debug("SQL = " + sql);
		if(!AQUtil.execSql(sql,_i.conexionBI_ ? _i.conexionBI_ : "default")) {
			return false;
		}
	}
	if (refAnversoC != "" && refReversoC != "") {
		var valores = metrosAnversoC.toString() + ", " + metrosReversoC.toString() + ", '" + qJ.value("op.codorden") + "', '" + qJ.value("ls.codlote") + "', NULL, '" + refAnversoC + "', '" + refReversoC + "', '" + refProducto + "', '" + codFamilia + "', '" + codSubfamilia + "', '" + codPedido + "'";
		var sql = "INSERT INTO in_h_jofesa (" + campos + ") VALUES (" + valores + ")";
		debug("SQL = " + sql);
		if(!AQUtil.execSql(sql,_i.conexionBI_ ? _i.conexionBI_ : "default")) {
			return false;
		}
	}

	return true;
}

function euromoda_datosCuboVicente(curJ, qJ)
{
	var _i = this.iface;
	

	var codLote = qJ.value("ls.codlote");
	var codOrden = qJ.value("op.codorden");
	var refProducto = qJ.value("ls.referencia");
	var codFamilia = qJ.value("a.codfamilia");
	var codSubfamilia = qJ.value("a.codsubfamilia");
	
	var qEti = new AQSqlQuery;
	qEti.setSelect("ac.refcomponente, a.descripcion, a.codsubfamilia");
	qEti.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia");
	qEti.setWhere("ac.refcompuesto = '" + refProducto + "' AND ac.desccomponente LIKE '%ETIQUETA TEXT%' AND (a.codfamilia = '8' OR a.codsubfamilia IN ('56', '57', '58'))");
	if (!qEti.exec()) {
		return false;
	}
	var etiEuromoda = [], etiRollo = [], etiEspecial = [], etiOtra = [];
	while (qEti.next()) {
		switch (qEti.value("a.codsubfamilia")) {
			case "56": {
				etiEuromoda.push(qEti.value("ac.refcomponente"));
				break;
			}
			case "57": {
				etiEspecial.push(qEti.value("ac.refcomponente"));
				break;
			}
			case "58": {
				etiRollo.push(qEti.value("ac.refcomponente"));
				break;
			}
			default: {
				etiOtra.push(qEti.value("ac.refcomponente"));
			}
		}
	}
	var qPed = new AQSqlQuery;
	qPed.setSelect("p.codigo, p.nombrecliente, p.codcliente, p.fecha, p.fechasalida, p.fechaservicio");
	qPed.setFrom("em_reservaslotepedido r INNER JOIN lineaspedidoscli lp ON r.idlineapc = lp.idlinea INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido");
	qPed.setWhere("r.codlote = '" + codLote + "' ORDER BY p.fechaservicio");
	if (!qPed.exec()) {
		return false;
	}
	var codPedido = "", codCliente = "", nombreCliente = "", fechaDoc = "", fechaCliente = "", fechaServicio = "";
	if (qPed.first()) {
		codPedido = qPed.value("p.codigo");
		codCliente = qPed.value("p.codcliente");
		nombreCliente = qPed.value("p.nombrecliente");
		fechaDoc = qPed.value("p.fecha");
		fechaCliente = qPed.value("p.fechasalida");
		fechaServicio = qPed.value("p.fechaservicio");
	}

	qAnverso = new FLSqlQuery();
	qAnverso.setSelect("SUM(ms.cantidad), ms.referencia, a.descripcion, ac.componormal, ac.ancho, ac.alto, ac.componente, a.codsubfamilia, sf.descripcion, t.tamancho,ac.piezasancho");
	qAnverso.setFrom("movistock ms INNER JOIN articuloscomp ac ON ms.idarticulocomp  = ac.id AND ac.componormal IN ('ANVERSO', 'ANVERSO COJIN', 'REVERSO', 'REVERSO COJIN', 'BIES') INNER JOIN articulos a ON ms.referencia = a.referencia LEFT OUTER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia LEFT OUTER JOIN em_tamanos t ON a.codtamanoem = t.codtamanoem");
	qAnverso.setWhere("ms.codloteprod = '" + codLote + "' GROUP BY ms.referencia, a.descripcion, ac.componormal, ac.componente, ac.ancho, ac.alto, a.codsubfamilia, sf.descripcion, t.tamancho, ac.piezasancho ORDER BY ac.componormal");
	if (!qAnverso.exec()) {
		return false;
	}
	debug(qAnverso.sql());
	while (qAnverso.next()) {
		var refAnverso = "", refReverso = "", refAnversoC = "", refReversoC = "";
		var tacoAnverso = "NULL", anchoAnverso = "NULL", altoAnverso = "NULL", codSubfamAnverso = "", desSubfamAnverso = "";
		var tacoAnversoC = "NULL", anchoAnversoC = "NULL", altoAnversoC = "NULL", codSubfamAnversoC = "", desSubfamAnversoC = "";
		var tacoReverso = "NULL";
		var tacoReversoC = "NULL";
		var tacoBies = "NULL";
		var desAnverso = "", desReverso = "", desAnversoC = "", desReversoC = "";
		var metrosAnverso = false, metrosReverso = false, metrosAnversoC = false, metrosReversoC = false, metrosBies = false, cantidadMetros = false;
		var tacos = qAnverso.value("ac.piezasancho") && qAnverso.value("ac.piezasancho") != "" ? qAnverso.value("ac.piezasancho") : "NULL";
		switch (qAnverso.value("ac.componormal")) {
			case "ANVERSO": {
				refAnverso = qAnverso.value("ms.referencia");
				desAnverso = qAnverso.value("a.descripcion");
				metrosAnverso = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosAnverso = AQUtil.roundFieldValue(metrosAnverso, "in_h_vicente", "metrosreverso");
				cantidadMetros = metrosAnverso;

				tacoAnverso = qAnverso.value("ac.ancho") && qAnverso.value("ac.ancho") != "" ? qAnverso.value("ac.ancho") : "NULL";
				altoAnverso = qAnverso.value("ac.alto") && qAnverso.value("ac.alto") != "" ? qAnverso.value("ac.alto") : "NULL";
				anchoAnverso = qAnverso.value("t.tamancho") && qAnverso.value("t.tamancho") != "" ? qAnverso.value("t.tamancho") : "NULL";
				codSubfamAnverso = qAnverso.value("a.codsubfamilia");
				desSubfamAnverso = sys.toUnicode(qAnverso.value("sf.descripcion"), "ISO-8859-15");
				break;
			}
			case "REVERSO": {
				refReverso = qAnverso.value("ms.referencia");
				desReverso = qAnverso.value("a.descripcion");
				metrosReverso = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosReverso = AQUtil.roundFieldValue(metrosReverso, "in_h_vicente", "metrosreverso");
				cantidadMetros = metrosReverso;
				
				tacoReverso = qAnverso.value("ac.ancho") && qAnverso.value("ac.ancho") != "" ? qAnverso.value("ac.ancho") : "NULL";
				break;
			}
			case "ANVERSO COJIN": {
				refAnversoC = qAnverso.value("ms.referencia");
				desAnversoC = qAnverso.value("a.descripcion");
				metrosAnversoC = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosAnversoC = AQUtil.roundFieldValue(metrosAnversoC, "in_h_vicente", "metrosreverso");
				cantidadMetros = metrosAnversoC;

				tacoAnversoC = qAnverso.value("ac.ancho") && qAnverso.value("ac.ancho") != "" ? qAnverso.value("ac.ancho") : "NULL";
				altoAnversoC = qAnverso.value("ac.alto") && qAnverso.value("ac.alto") != "" ? qAnverso.value("ac.alto") : "NULL";
				anchoAnversoC = qAnverso.value("t.tamancho") && qAnverso.value("t.tamancho") != "" ? qAnverso.value("t.tamancho") : "NULL";
				codSubfamAnversoC = qAnverso.value("a.codsubfamilia");
				desSubfamAnversoC = sys.toUnicode(qAnverso.value("sf.descripcion"), "ISO-8859-15");
				break;
			}
			case "REVERSO COJIN": {
				refReversoC = qAnverso.value("ms.referencia");
				desReversoC = qAnverso.value("a.descripcion");
				metrosReversoC = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosReversoC = AQUtil.roundFieldValue(metrosReversoC, "in_h_vicente", "metrosreverso");
				cantidadMetros = metrosReversoC;
				
				tacoReversoC = qAnverso.value("ac.ancho") && qAnverso.value("ac.ancho") != "" ? qAnverso.value("ac.ancho") : "NULL";
				break;
			}
			case "BIES": {
				metrosBies = qAnverso.value("SUM(ms.cantidad)") * -1;
				metrosBies = AQUtil.roundFieldValue(metrosBies, "in_h_vicente", "metrosbies");
				cantidadMetros = metrosBies;
				
				tacoBies = qAnverso.value("ac.ancho") && qAnverso.value("ac.ancho") != "" ? qAnverso.value("ac.ancho") : "NULL";
				break;
			}
		}
		
		var campos = [], valores = [];
		campos.push("codorden");
		valores.push("'" + qJ.value("op.codorden") + "'");

		campos.push("estadoorden");
		valores.push("'" + qJ.value("op.estado") + "'");
		
		campos.push("obsorden");
		valores.push("'" + qJ.value("op.emobservaciones") + "'");

		codConfec = qJ.value("op.codconfeccionista");
		campos.push("codconfeccion");
		valores.push("'" + codConfec + "'");

		campos.push("nombreconfeccion");
		valores.push("'" + sys.toUnicode(qJ.value("op.nombreconfeccionista"), "ISO-8859-15") + "'");
		
		campos.push("codlote");
		valores.push("'" + qJ.value("ls.codlote") + "'");

		campos.push("refetieuromoda");
		valores.push("'" + etiEuromoda.join(",") + "'");

		campos.push("refetirollo");
		valores.push("'" + etiRollo.join(",") + "'");
		
		campos.push("refetiespecial");
		valores.push("'" + etiEspecial.join(",") + "'");

		campos.push("refetiotra");
		valores.push("'" + etiOtra.join(",") + "'");

		campos.push("panotcont");
		valores.push("'" + qJ.value("a.panotcont") + "'");

		campos.push("coddibujo");
		valores.push("'" + qJ.value("a.coddibestamp") + "'");

		campos.push("desdibujo");
		valores.push("'" + sys.toUnicode(qJ.value("d.descripcion"), "ISO-8859-15") + "'");

		campos.push("codfamilia");
		valores.push("'" + codFamilia + "'");

		campos.push("desfamilia");
		valores.push("'" + sys.toUnicode(qJ.value("f.descripcion"), "ISO-8859-15") + "'");

		campos.push("codsubfamilia");
		valores.push("'" + codSubfamilia + "'");

		campos.push("dessubfamilia");
		valores.push("'" + sys.toUnicode(qJ.value("sf.descripcion"), "ISO-8859-15") + "'");

		campos.push("refproducto");
		valores.push("'" + refProducto + "'");

		campos.push("desproducto");
		valores.push("'" + sys.toUnicode(qJ.value("a.descripcion"), "ISO-8859-15") + "'");

		campos.push("tacos");
		valores.push(tacos);

		var fase = AQUtil.sqlSelect("pr_tareas", "descripcion", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '"+qJ.value("op.codorden")+"' and estado = 'PTE' order by idtarea desc");
		campos.push("fase");
		valores.push("'"+fase+"'");

		campos.push("codpedido");
		valores.push("'" + codPedido + "'");

		campos.push("codcliente");
		valores.push("'" + codCliente + "'");

		campos.push("nombrecliente");
		valores.push("'" + nombreCliente + "'");

		campos.push("fechadoc");
		valores.push((fechaDoc != "") ? ("'" + fechaDoc.toString().left(10) + "'") : "NULL");

		campos.push("fechacliente");
		valores.push((fechaCliente != "") ? ("'" + fechaCliente.toString().left(10) + "'") : "NULL");
		
		campos.push("fechaservicio");
		valores.push((fechaServicio != "") ? ("'" + fechaServicio.toString().left(10) + "'") : "NULL");

		var fechaCorte = AQUtil.sqlSelect("pr_tareas", "diafin", "idobjeto = '" + codOrden + "' AND idtipotarea IN ('ACE', 'ACO', 'CO', 'J1')");
		fechaCorte = fechaCorte ? fechaCorte : "";
		campos.push("fechacorte");
		valores.push((fechaCorte != "") ? ("'" + fechaCorte.toString().left(10) + "'") : "NULL");

		campos.push("fechaenvioconf");
		var fechaEnvioConf = "";
		if (codConfec && codConfec != "") {
			fechaEnvioConf = AQUtil.sqlSelect("pedidosprov", "MIN(fecha)", "codordenprod = '" + codOrden + "' AND codproveedor = '" + codConfec + "'");
			fechaEnvioConf = fechaEnvioConf ? fechaEnvioConf : "";
		}
		valores.push((fechaEnvioConf != "") ? ("'" + fechaEnvioConf.toString().left(10) + "'") : "NULL");


		campos.push("componormal");
		valores.push("'" + sys.toUnicode(qAnverso.value("ac.componormal"), "ISO-8859-15") + "'");
			
		campos.push("componente");
		valores.push("'" + sys.toUnicode(qAnverso.value("ac.componente"), "ISO-8859-15") + "'");
		
		campos.push("cantidadmetros");
		valores.push(cantidadMetros ? cantidadMetros.toString() : "NULL");

		if ((refAnverso && refAnverso != "")  || (refReverso && refReverso != "")) {
			var camposP = [], valoresP = [];
			camposP.push("metrosanverso");
			valoresP.push(metrosAnverso ? metrosAnverso.toString() : "NULL");
			
			camposP.push("refanverso");
			valoresP.push("'" + refAnverso + "'");
			
			camposP.push("desanverso");
			valoresP.push("'" + sys.toUnicode(desAnverso, "ISO-8859-15") + "'");
			
			camposP.push("metrosreverso");
			valoresP.push(metrosReverso ? metrosReverso.toString() : "NULL");
			
			camposP.push("refreverso");
			valoresP.push("'" + refReverso + "'");
			
			camposP.push("desreverso");
			valoresP.push("'" + sys.toUnicode(desReverso, "ISO-8859-15") + "'");

			camposP.push("tacoanverso");
			valoresP.push(tacoAnverso);
			
			camposP.push("tacoreverso");
			valoresP.push(tacoReverso);
			
			camposP.push("altoanverso");
			valoresP.push(altoAnverso);
			
			camposP.push("anchoanverso");
			valoresP.push(anchoAnverso);
			
			camposP.push("codsubfamanverso");
			valoresP.push("'" + codSubfamAnverso + "'");
			
			camposP.push("dessubfamanverso");
			valoresP.push("'" + desSubfamAnverso + "'");
			
	/*		
			var valores = metrosAnverso.toString() + ", " + metrosReverso.toString() + ", '" + qJ.value("op.codorden") + "', '" + qJ.value("ls.codlote") + "', NULL, '" + refAnverso + "', '" + desAnverso + "', '" + refReverso + "', '" + desReverso + "', '" + "', '" + codFamilia + "', '" + qJ.value("f.descripcion") + "', '" + codSubfamilia + "', '" + qJ.value("sf.descripcion") + "', '" + codPedido + "'";
			*/
			var sql = "INSERT INTO in_h_vicente (" + campos.join(", ") +  ", " + camposP.join(", ") + ") VALUES (" + valores.join(", ") + ", " + valoresP.join(", ") + ")";
			debug("SQL = " + sql);
			if(!AQUtil.execSql(sql,_i.conexionBI_ ? _i.conexionBI_ : "default")) {
				return false;
			}
		}
		if (metrosBies && !isNaN(metrosBies)) {
			debug("metrosBies " + metrosBies);
			var camposB = [], valoresB = [];
			camposB.push("metrosbies");
			valoresB.push(metrosBies ? metrosBies.toString() : "NULL");
			
			camposB.push("tacobies");
			valoresB.push(tacoBies);
			
			var sql = "INSERT INTO in_h_vicente (" + campos.join(", ") +  ", " + camposB.join(", ") + ") VALUES (" + valores.join(", ") + ", " + valoresB.join(", ") + ")";
			debug("SQL = " + sql);
			if(!AQUtil.execSql(sql,_i.conexionBI_ ? _i.conexionBI_ : "default")) {
				return false;
			}	
		}
		debug("refAnversoC = '" + refAnversoC + "'")
		debug("refReversoC = '" + refReversoC + "'")
		if ((refAnversoC && refAnversoC != "") || (refReversoC && refReversoC != "")) {
			debug("entra");
			var camposC = [], valoresC = [];
			camposC.push("metrosanverso");
			valoresC.push(metrosAnversoC ? metrosAnversoC.toString() : "NULL");
			
			camposC.push("refanverso");
			valoresC.push("'" + refAnversoC + "'");
			
			camposC.push("desanverso");
			valoresC.push("'" + sys.toUnicode(desAnversoC, "ISO-8859-15") + "'");
			
			camposC.push("metrosreverso");
			valoresC.push(metrosReversoC ? metrosReversoC.toString() : "NULL");
			
			camposC.push("refreverso");
			valoresC.push("'" + refReversoC + "'");
			
			camposC.push("desreverso");
			valoresC.push("'" + sys.toUnicode(desReversoC, "ISO-8859-15") + "'");

			//camposC.push("tacoanverso");
			//valoresC.push(tacoAnversoC);
			
			camposC.push("tacoanversocojin");
			valoresC.push(tacoAnversoC);
			
			camposC.push("tacoreversocojin");
			valoresC.push(tacoReversoC);
			
			camposC.push("altoanverso");
			valoresC.push(altoAnversoC);
			
			camposC.push("anchoanverso");
			valoresC.push(anchoAnversoC);
			
			camposC.push("codsubfamanverso");
			valoresC.push("'" + codSubfamAnversoC + "'");
			
			camposC.push("dessubfamanverso");
			valoresC.push("'" + desSubfamAnversoC + "'");
	/*
			var valores = metrosAnversoC.toString() + ", " + metrosReversoC.toString() + ", '" + qJ.value("op.codorden") + "', '" + qJ.value("ls.codlote") + "', NULL, '" + refAnversoC + "', '" + desAnversoC + "', '" + refReversoC + "', '" + desReversoC + "', '" + "', '" + codFamilia + "', '" + qJ.value("f.descripcion") + "', '" + codSubfamilia + "', '" + qJ.value("sf.descripcion") + "', '" + codPedido + "'";*/
			var sql = "INSERT INTO in_h_vicente (" + campos.join(", ") +  ", " + camposC.join(", ") + ") VALUES (" + valores.join(", ") + ", " + valoresC.join(", ") + ")";
			debug("SQL = " + sql);
			if(!AQUtil.execSql(sql,_i.conexionBI_ ? _i.conexionBI_ : "default")) {
				return false;
			}
		}
	}

	return true;
}

function euromoda_datosCuboNecPed(curNP, qNP)
{
	var _i = this.iface;
	
	var campos = "m_cantidad, m_reservaex, m_reservapr, m_reservaaf, d_codcliente, d_codpedido, d_refproducto, d_refcomponente, d_codfamprod, d_codsubfamprod,  d_codfamcomp, d_codsubfamcomp, d_fecha";

	var valores = qNP.value("SUM(co.cantidad*-1)").toString();
	valores += ", " + qNP.value("SUM(co.reservaex)").toString();
	valores += ", " + qNP.value("SUM(co.reservapr)").toString();
	valores += ", " + qNP.value("SUM(co.reservaaf)").toString();
	valores += ", '" + qNP.value("p.codcliente") + "'";
	valores += ", '" + qNP.value("p.codigo") + "'";
	valores += ", '" + qNP.value("lp.referencia") + "'";
	valores += ", '" + qNP.value("co.referencia") + "'";
	valores += ", '" + qNP.value("ap.codfamilia") + "'";
	valores += ", '" + qNP.value("ap.codsubfamilia") + "'";
	valores += ", '" + qNP.value("ac.codfamilia") + "'";
	valores += ", '" + qNP.value("ac.codsubfamilia") + "'";
	valores += ", '" + qNP.value("p.fecha") + "'";

	var sql = "INSERT INTO in_h_necped (" + campos + ") VALUES (" + valores + ")";
	debug("SQL = " + sql);
	if (_i.conexionBI_) {
		if(!AQUtil.execSql(sql,_i.conexionBI_)) {
			return false;
		}
	} else {
		if(!AQUtil.execSql(sql)) {
			return false;
		}
	}
	
	return true;
}

function euromoda_sincronizarNivel(aNivel) // Usa una funci�n de filtro espec�fica por nivel
{
	var _i = this.iface;
	var _fD = fldireinne.iface;
	
	var eNivel= aNivel["element"];
	switch (eNivel.attribute("levelType")) {
		case "TimeDays": {
			_i.cargarDimensionDia();
			break;
		}
		case "TimeTerms": {
			_i.cargarDimensionTrimestre();
			break;
		}
		case "TimeMonths": {
			_i.cargarDimensionMesAnno();
			break;
		}
		case "TimeYears": {
			break;
		}
		case "TimeWeeks": {
			_i.cargarDimensionSemana();
			break;
		}
		default: {
			var tablaFuente= eNivel.attribute("sourceTable");
			if (!tablaFuente || tablaFuente == "" || tablaFuente == "none") {
				return true;
			}
			var uniqueMembers= (eNivel.attribute("uniqueMembers") == "true");
			var tablaNivel= eNivel.attribute("table");
			var campoClave= eNivel.attribute("column");
			var curNivel;
			if (_i.conexionBI_) {
				curNivel = new FLSqlCursor(tablaNivel, _i.conexionBI_);
			} else {
				curNivel = new FLSqlCursor(tablaNivel);
			}
			curNivel.setActivatedCheckIntegrity(false);
			curNivel.setForwardOnly(true);
			curNivel.select("1 = 1 AND 1 = 1 ORDER BY " + campoClave);

			var arrayCampos= AQUtil.nombreCampos(tablaNivel);
			var cuenta= parseInt(arrayCampos[0]);
			arrayCampos.shift();
			var iUltimoCampo= arrayCampos.length - 1;
			while (arrayCampos[iUltimoCampo].endsWith("check_column")) {
				arrayCampos.pop();
				iUltimoCampo--;
			}
			var listaCampos= arrayCampos.join(", ");

			var qryFuente= (_i.conexion_ ? new FLSqlQuery("", _i.conexion_) : new FLSqlQuery());
			qryFuente.setTablesList(tablaFuente);
			qryFuente.setSelect(listaCampos);
			qryFuente.setFrom(tablaFuente);
			/** NUEVO */
			var filtro = _i.dameFiltroNivel(aNivel);
			if (uniqueMembers) {
				qryFuente.setWhere(filtro + " ORDER BY " + campoClave);
			} else {
				qryFuente.setWhere(filtro + " AND " + listaCampos + " IS NOT NULL GROUP BY " + listaCampos + " ORDER BY " + campoClave);
			}
			/** FIN NUEVO */
			qryFuente.setForwardOnly(true);
			if (!qryFuente.exec()) {
				return false;
			}

			var totalReg= qryFuente.size();
			var regPaso= Math.round(totalReg / 100);
			var progreso= 0, progreso100= 0;
			var valor;
			
			var claveD, claveF, valoresD, valoresF;
			var hayDestino= curNivel.first();
			var hayFuente= qryFuente.first();
// 			debug("Nombre nivel " + aNivel["nombre"]);
// 			debug("totalReg " + totalReg);
			if(_i.silent_) {
				_fD.pub_creaPDSilent(totalReg);
				_fD.pub_pushTextToLogFile(_i.nombreLog_, "Sincronizando nivel " + aNivel["nombre"]);
			}
			else {
				AQUtil.createProgressDialog(sys.translate("Sincronizando nivel " + aNivel["nombre"]), totalReg);
			}
	
			while (hayDestino || hayFuente) {
				valoresD = "";
				valoresF = "";
// debug("hayDestino " + hayDestino);
// debug("hayFuente " + hayFuente);
				if (progreso % regPaso == 0) {
					if(_i.silent_) {
						_fD.pub_setProgressPDSilent(++progreso100);
					}
					else {
						AQUtil.setProgress(++progreso100);
					}
				}
				if (hayDestino && hayFuente) {
					claveD = curNivel.valueBuffer(campoClave);
					claveF = qryFuente.value(campoClave);
					if (claveD == claveF) {
						for (var i= 0; i < arrayCampos.length; i++) {
							if(valoresD == "")
								valoresD += ",";
							if(valoresF == "")
								valoresF += ",";
							valoresD += curNivel.valueBuffer(arrayCampos[i]);
							valoresF += qryFuente.value(arrayCampos[i]);
						}
						if(valoresD != valoresF) {
							curNivel.setModeAccess(curNivel.Edit);
							curNivel.refreshBuffer();
							for (var i= 0; i < arrayCampos.length; i++) {
								if(arrayCampos[i] == campoClave) continue;
								
								var tipoCampo = curNivel.fieldType(arrayCampos[i]);

								var valor = "";
								if(tipoCampo == 3 || tipoCampo == 4)
									valor = _i.formateaCadena(qryFuente.value(arrayCampos[i]));
								else
									valor = qryFuente.value(arrayCampos[i]);
								
								curNivel.setValueBuffer(arrayCampos[i],valor);
							}
							if (!curNivel.commitBuffer()) {
								AQUtil.destroyProgressDialog();
								return false;
							}
						}
						hayFuente = qryFuente.next();
						progreso++;
						hayDestino = curNivel.next();
					} else if (claveF > claveD) {
						curNivel.setModeAccess(curNivel.Del);
						curNivel.refreshBuffer();
						if (!curNivel.commitBuffer()) {
							AQUtil.destroyProgressDialog();
							return false;
						}
						hayDestino = curNivel.next();
					} else {
//debug("1. Insertando Art " + arrayCampos[0]);

						var campos = "";
						var valores = "";
						for (var i= 0; i < arrayCampos.length; i++) {
							
							var tipoCampo = curNivel.fieldType(arrayCampos[i]);
	
							if(campos != "")
								campos += ",";
							campos += arrayCampos[i];
							
							if(tipoCampo == 3 || tipoCampo == 4)
								valor = _i.formateaCadena(qryFuente.value(arrayCampos[i]));
							else
								valor = qryFuente.value(arrayCampos[i]);
		// debug(arrayCampos[i] + " = " + valor);
		
		// El valor por defecto 'N' realemente ya no es necesario ya que todas las tablas de dimensiones admiten nulos pero lo dejamos porque es posible que en alguna extensi�n no sea as�.
// 							if (valor == "") {
// 								valor = "N";
// 							}
							
							if(valores != "")
								valores += ",";
							
							if(tipoCampo == 3 || tipoCampo == 4)
								valores += "'" + valor + "'";
							else
								valores += valor;
						}

						if (_i.conexionBI_) {
							if(!AQUtil.execSql("INSERT INTO " + tablaNivel + " (" + campos + ") values (" + valores + ")",_i.conexionBI_)) {
								AQUtil.destroyProgressDialog();
								return false;
							}
						}
						else {
							if(!AQUtil.execSql("INSERT INTO " + tablaNivel + " (" + campos + ") values (" + valores + ")")) {
								AQUtil.destroyProgressDialog();
								return false;
							}
						}
						
						hayFuente = qryFuente.next();
						progreso++;
					}
				} else if (!hayFuente) {
					curNivel.setModeAccess(curNivel.Del);
					curNivel.refreshBuffer();
					if (!curNivel.commitBuffer()) {
						AQUtil.destroyProgressDialog();
						return false;
					}
					hayDestino = curNivel.next();
				} else {
//debug("2. Insertando Art " + arrayCampos[0]);

					var campos = "";
					var valores = "";
					for (var i= 0; i < arrayCampos.length; i++) {
						
						var tipoCampo = curNivel.fieldType(arrayCampos[i]);
						
						if(tipoCampo == 3 || tipoCampo == 4)
							valor = _i.formateaCadena(qryFuente.value(arrayCampos[i]));
						else
							valor = qryFuente.value(arrayCampos[i]);
						//debug("campo " + arrayCampos[i] + "    tipo " + tipoCampo);
							
						if(campos != "")
							campos += ",";
						campos += arrayCampos[i];

// 						if (valor == "") {
// 							valor = "N";
// 						}
						
						if(valores != "")
							valores += ",";
						if(tipoCampo == 3 || tipoCampo == 4)
							valores += "'" + valor + "'";
						else
							valores += valor;
					}
					
					if (_i.conexionBI_) {
						if(!AQUtil.execSql("INSERT INTO " + tablaNivel + " (" + campos + ") values (" + valores + ")",_i.conexionBI_)) {
							AQUtil.destroyProgressDialog();
							return false;
						}
					}
					else {
						if(!AQUtil.execSql("INSERT INTO " + tablaNivel + " (" + campos + ") values (" + valores + ")")) {
							AQUtil.destroyProgressDialog();
							return false;
						}
					}
					hayFuente = qryFuente.next();
					progreso++;
				}
			}
			break;
		}
	}

	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_dameFiltroNivel(aNivel)
{
	var _i = this.iface;
	var _fD = fldireinne.iface;
	
	var f = "1 = 1";
	
	var eNivel= aNivel["element"];
	switch (eNivel.attribute("table")) {
	case "in_dimordenjfs": {
			f = "pr_ordenesproduccion.codorden IN (SELECT d_codorden FROM in_h_jofesa GROUP BY d_codorden)";
			break;
		}
	case "in_dimlotejfs": {
			f = "lotesstock.codlote IN (SELECT d_codlote FROM in_h_jofesa GROUP BY d_codlote)";
			break;
		}
	case "in_dimanversojfs": {
			f = "articulos.referencia IN (SELECT d_refanverso FROM in_h_jofesa GROUP BY d_refanverso)";
			break;
		}
	case "in_dimreversojfs": {
			f = "articulos.referencia IN (SELECT d_refreverso FROM in_h_jofesa GROUP BY d_refreverso)";
			break;
		}
	case "in_dimsubfamiliajfs": {
			f = "subfamilias.codsubfamilia IN (SELECT d_codsubfamilia FROM in_h_jofesa GROUP BY d_codsubfamilia)";
			break;
		}
	case "in_dimfamiliajfs": {
			f = "familias.codfamilia IN (SELECT d_codfamilia FROM in_h_jofesa GROUP BY d_codfamilia)";
			break;
		}
	case "in_dimpedidojfs": {
			f = "pedidoscli.codigo IN (SELECT d_codpedido FROM in_h_jofesa GROUP BY d_codpedido)";
			break;
		}
	case "in_dimproductojfs": {
			f = "articulos.referencia IN (SELECT d_refproducto FROM in_h_jofesa GROUP BY d_refproducto)";
			break;
		}
	case "in_dimetiquetaprodjfs": {
			f = "articulos.referencia IN (SELECT d_refetiquetaprod FROM in_h_jofesa GROUP BY d_refetiquetaprod)";
			break;
		}
	case "in_dimnpcliente": {
			f = "clientes.codcliente IN (SELECT d_codcliente FROM in_h_necped GROUP BY d_codcliente)";
			break;
		}
	case "in_dimnppedido": {
			f = "pedidoscli.codigo IN (SELECT d_codpedido FROM in_h_necped GROUP BY d_codpedido)";
			break;
		}
	case "in_dimnpproducto": {
			f = "articulos.referencia IN (SELECT d_refproducto FROM in_h_necped GROUP BY d_refproducto)";
			break;
		}
	case "in_dimnpcomponente": {
			f = "articulos.referencia IN (SELECT d_refcomponente FROM in_h_necped GROUP BY d_refcomponente)";
			break;
		}
	case "in_dimnpfamproducto": {
			f = "familias.codfamilia IN (SELECT d_codfamprod FROM in_h_necped GROUP BY d_codfamprod)";
			break;
		}
	case "in_dimnpsubfamproducto": {
			f = "subfamilias.codsubfamilia IN (SELECT d_codsubfamprod FROM in_h_necped GROUP BY d_codsubfamprod)";
			break;
		}
	case "in_dimnpfamcomponente": {
			f = "familias.codfamilia IN (SELECT d_codfamcomp FROM in_h_necped GROUP BY d_codfamcomp)";
			break;
		}
	case "in_dimnpsubfamcomponente": {
			f = "subfamilias.codsubfamilia IN (SELECT d_codsubfamcomp FROM in_h_necped GROUP BY d_codsubfamcomp)";
			break;
		}
	}
	return f;
}

function euromoda_exportarTablaCuboExcel(oParam) // Exporta la tabla tal cual
{
	var _i = this.iface;

	if(oParam.tabla == undefined){
		sys.warnMsgBox(sys.translate("No se ha podido crear el archivo excel porque no hay tabla."));
		return;
	}
	if(oParam.nombreFichero == ""){
		sys.warnMsgBox(sys.translate("No se ha podido crear el archivo excel porque falta el nombre del fichero."));
		return;
	}

	var totalRegistros = oParam.tabla.numRows();

	// Estilos para poner a las celdas
  var titleCellStyle = new AQOdsStyle(AQS.ODS_ALIGN_CENTER |
                                  AQS.ODS_TEXT_BOLD);
  var italic = new AQOdsStyle(AQS.ODS_TEXT_ITALIC);
  var tSep = new AQOdsStyle(AQS.ODS_BORDER_TOP);
  var bSep = new AQOdsStyle(AQS.ODS_BORDER_BOTTOM);
  var rSep = new AQOdsStyle(AQS.ODS_BORDER_RIGHT);
  var lSep = new AQOdsStyle(AQS.ODS_BORDER_LEFT);
  var lAlig = new AQOdsStyle(AQS.ODS_ALIGN_LEFT);
  var rAlig = new AQOdsStyle(AQS.ODS_ALIGN_RIGHT);
  var none = new AQOdsStyle(AQS.ODS_NONE);

	AQUtil.createProgressDialog(sys.translate("Creando fichero ..."), totalRegistros);

	// Creaci�n del archivo ods.
	var odsGen = new AQOdsGenerator;
  var spreadsheet = new AQOdsSpreadSheet(odsGen);
  var sheet = new AQOdsSheet(spreadsheet, oParam.nombreFichero);

	//Cabecera del fichero
	if(oParam.titulo != ""){
		var row= new AQOdsRow(sheet);
		row.opIn(titleCellStyle).opIn(oParam.titulo,oParam.tabla.numCols());
		row.close();
	}

	// Para dejar varias filas de separaci�n entre la cabecera y la tabla con los datos.
	for (var i = 0; i < 2; i++){
		var row= new AQOdsRow(sheet);
		row.close();
	}

	// Cabecera para las columnas.
  var row = new AQOdsRow(sheet);
  row.addBgColor(new AQOdsColor(225,223,223)); // color de fondo para toda la fila
  //row.addFgColor(new AQOdsColor(0xff0000));
	if(oParam.nombreColumnas && oParam.nombreColumnas.length > 0){
		var maxCol = oParam.nombreColumnas.length > oParam.tabla.numCols() ? oParam.tabla.numCols() : oParam.nombreColumnas.length;
		for(var col = 0; col < maxCol; col++){
			row.opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn(bSep).opIn(oParam.nombreColumnas[col]); // opIn(string, colSpan, rowSpan)
		}
	}
  row.close();

	// Una fila en el archivo para cada fila del array.
  for (var f = 0; f < totalRegistros; f++){
		AQUtil.setProgress(f);
    var row2 = new AQOdsRow(sheet);

		if ( f % 2 == 0){
			row2.addBgColor(new AQOdsColor(255,255,255));
		}
		else{
			row2.addBgColor(new AQOdsColor(228,228,228));
		}

		var col = 0;
		var texto;
		if( f == (totalRegistros - 1)){ // Para dibujar la l��nea de abajo de la ��ltima fila de celdas.
			texto = oParam.tabla.text(f, col);
			if (texto == "") {
				texto = " ";
			}
			row2.opIn(rSep).opIn(bSep).opIn(lAlig).opIn(texto);
			for(col = 1; col < oParam.tabla.numCols() ; col++){
				texto = oParam.tabla.text(f, col);
				if (texto == "") {
					texto = " ";
				}
				texto = texto.replace(".", "");
				texto = texto.replace(",", ".");
				if (!isNaN(texto)) {
					texto = parseFloat(texto);
				}

				row2.opIn(rSep).opIn(bSep).opIn(lAlig).opIn(texto);
			}
		}
    else{
			texto = oParam.tabla.text(f, col);
			if (texto == "") {
				texto = " ";
			}
			row2.opIn(rSep).opIn(lAlig).opIn(texto);
			for(col = 1; col < oParam.tabla.numCols(); col++){
				texto = oParam.tabla.text(f, col);
				if (texto == "") {
					texto = " ";
				}
				texto = texto.replace(".", "");
				texto = texto.replace(",", ".");
				if (!isNaN(texto)) {
					texto = parseFloat(texto);
				}
				row2.opIn(rSep).opIn(lAlig).opIn(texto);
			}
		}
    row2.close();
  }

	AQUtil.destroyProgressDialog();

  sheet.close();
  spreadsheet.close();

	//Nombre del archivo.
  var odsFileName = "";
	if(oParam.path == "home"){
		odsFileName = Dir.home + "/" + oParam.nombreFichero +".ods";
	}
	else{
		var dirDestino = FileDialog.getExistingDirectory("", "Directorio de archivos");
		if (!dirDestino) {
			sys.warnMsgBox(sys.translate("No existe el directorio seleccionado."));
		}
		odsFileName =  dirDestino + "/" + oParam.nombreFichero +".ods";
	}
  odsFileName = Dir.cleanDirPath(odsFileName);
  odsFileName = Dir.convertSeparators(odsFileName);
	// Funci�n que crea "f��sicamente" el archivo con la configuraci�n y datos introducidos anteriormente.
  odsGen.generateOds(odsFileName);
	sys.infoMsgBox(sys.translate("Fichero generado en %1").arg(odsFileName));
	// Abrir archivo.
  sys.openUrl("file://" + odsFileName);
}
//// EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
