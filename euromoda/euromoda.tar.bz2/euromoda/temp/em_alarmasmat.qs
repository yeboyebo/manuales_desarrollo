/***************************************************************************
                 em_alarmasmat.qs  -  description
                             -------------------
    begin                : mie jun 4 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	
	var usuarioActual_;
	var oColorLinea_, codAsigConfAnt_;
	function oficial( context ) { interna( context ); }
	function dameColorLinea(fN, fV, cursor, sel, fT) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, sel, fT);
	}
	function tbnCambiarUsuario_clicked() {
		return this.ctx.oficial_tbnCambiarUsuario_clicked();
	}
	function desactivaBuscar() {
		return this.ctx.oficial_desactivaBuscar();
	}
	function muestraUsuarioActual() {
		return this.ctx.oficial_muestraUsuarioActual();
	}
  function filtra() {
    return this.ctx.oficial_filtra();
  }
  function filtraPtes() {
    return this.ctx.oficial_filtraPtes();
  }
  function dameFiltroPtes() {
    return this.ctx.oficial_dameFiltroPtes();
  }
  function dameFiltroFin() {
    return this.ctx.oficial_dameFiltroFin();
  }
  function tdbAlarmasPtes_recordChoosed() {
    return this.ctx.oficial_tdbAlarmasPtes_recordChoosed();
  }
  function tdbAlarmasFin_recordChoosed() {
    return this.ctx.oficial_tdbAlarmasFin_recordChoosed();
  }
  function tbnIgnorar_clicked() {
    return this.ctx.oficial_tbnIgnorar_clicked();
  }
  function tbnAutoentrada_clicked() {
    return this.ctx.oficial_tbnAutoentrada_clicked();
  }
  function tbnPedido_clicked() {
    return this.ctx.oficial_tbnPedido_clicked();
  }
  function ignorarAlarma(oParam) {
    return this.ctx.oficial_ignorarAlarma(oParam);
  }
  function autoentradaAlarma(oParam) {
    return this.ctx.oficial_autoentradaAlarma(oParam);
  }
  function tbnDocPte_clicked() {
    return this.ctx.oficial_tbnDocPte_clicked();
  }
  function tbnDocFin_clicked() {
    return this.ctx.oficial_tbnDocFin_clicked();
  }
  function verDoc(cursor) {
    return this.ctx.oficial_verDoc(cursor);
  }
  function tbnOrdenCronPtes_toggled(on) {
    return this.ctx.oficial_tbnOrdenCronPtes_toggled(on);
  }
  function tbnOrdenCronFin_toggled(on) {
    return this.ctx.oficial_tbnOrdenCronFin_toggled(on);
  }
  function tbnEmailPedido_clicked() {
		return this.ctx.oficial_tbnEmailPedido_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_cortaLote(oParam) {
		return this.cortaLote(oParam);
	}
	function pub_tbnEmailPedido_clicked() {
		return this.tbnEmailPedido_clicked();
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  /*if (sys.nameBD() == "abanq_creaciones") {
    sys.warnMsgBox(sys.translate("Funconalidad s�lo disponible en pruebas"));
    this.close();
    return;
  }
	*/
	var _i = this.iface;

	connect(this.child("tbnCambiarUsuario"), "clicked()", _i, "tbnCambiarUsuario_clicked");
	connect(this.child("tbnIgnorar"), "clicked()", _i, "tbnIgnorar_clicked");
	connect(this.child("tbnAutoentrada"), "clicked()", _i, "tbnAutoentrada_clicked");
	connect(this.child("tbnPedido"), "clicked()", _i, "tbnPedido_clicked");
	connect(this.child("tdbAlarmasPtes").cursor(), "recordChoosed()", _i, "tdbAlarmasPtes_recordChoosed");
	connect(this.child("tdbAlarmasFin").cursor(), "recordChoosed()", _i, "tdbAlarmasFin_recordChoosed");
	connect(this.child("tbnPtePedido"), "clicked()", _i, "filtraPtes");
	connect(this.child("tbnPteRx"), "clicked()", _i, "filtraPtes");
	connect(this.child("tbnBuscaRef"), "clicked()", _i, "filtraPtes");
	connect(this.child("ledReferencia"), "textChanged(QString)", _i, "desactivaBuscar");
	connect(this.child("tbnDocPte"), "clicked()", _i, "tbnDocPte_clicked");
	connect(this.child("tbnDocFin"), "clicked()", _i, "tbnDocFin_clicked");
	connect(this.child("tbnEmailPedido"), "clicked()", _i, "tbnEmailPedido_clicked");
	
	connect(this.child("tbnOrdenCronPtes"), "toggled(bool)", _i, "tbnOrdenCronPtes_toggled");
	connect(this.child("tbnOrdenCronFin"), "toggled(bool)", _i, "tbnOrdenCronFin_toggled");
  
	_i.tbnOrdenCronPtes_toggled(false);
	_i.tbnOrdenCronFin_toggled(false);
  _i.filtra();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_desactivaBuscar()
{
	var _i = this.iface;
	if (this.child("tbnBuscaRef").on) {
		this.child("tbnBuscaRef").on = false;
		_i.filtraPtes();
	}
}

function oficial_dameColorLinea(fN, fV, cursor, sel, fT)
{
	debug("oficial_dameColorLinea");
  var _i = this.iface;
  var codAsigConf = cursor.valueBuffer("codasigconf");
  if (!sel && codAsigConf == _i.codAsigConfAnt_) {
    return _i.oColorLinea_;
  }
  if (!sel) {
    _i.codAsigConfAnt_ = codAsigConf;
	} else {
    _i.codAsigConfAnt_ = -1;
	}
	var color = "";
  if (cursor.valueBuffer("estado") == "Enviada") {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_azul_sel" : "fondo_azul");
  } else {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_gris_sel" : "fondo_gris");
  }
  if (color != "") {
    _i.oColorLinea_ = [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
    return _i.oColorLinea_;
  } else
    _i.codAsigConfAnt_ = -1;
}

function oficial_tbnCambiarUsuario_clicked()
{
	var _i = this.iface;
	
	var f = new FLFormSearchDB("pr_bustrabajador");
	var curU = f.cursor();
	
	f.setMainWidget();
	var idUsuario = f.exec("idtrabajador");

	if (!idUsuario) {
		return;
	}
	_i.usuarioActual_ = idUsuario;
	_i.muestraUsuarioActual();
}

function oficial_muestraUsuarioActual()
{
	var _i = this.iface;
	var usuario;
	if (_i.usuarioActual_) {
		var n = AQUtil.sqlSelect("pr_trabajadores", "nombre", "idtrabajador = '" + _i.usuarioActual_ + "'");
		usuario = n + " (" + _i.usuarioActual_ + ")";
	} else {
		usuario = sys.translate("Usuario actual no establecido");
	}
	sys.setObjText(this, "lblUsuario", usuario);
}

function oficial_filtra()
{
  var _i  = this.iface;
  
	_i.filtraPtes();
	
	var fF = _i.dameFiltroFin();
  this.child("tdbAlarmasFin").cursor().setMainFilter(fF);
  this.child("tdbAlarmasFin").refresh();
}

function oficial_filtraPtes()
{
	var _i  = this.iface;
  var fP = _i.dameFiltroPtes();
  this.child("tdbAlarmasPtes").cursor().setMainFilter(fP);
  this.child("tdbAlarmasPtes").refresh();
}

function oficial_dameFiltroPtes()
{
  var f = "NOT fin";
	
	if (this.child("tbnPtePedido").on && !this.child("tbnPteRx").on) {
		f += " AND tipogestion = 'Pendiente'";
	} else if (!this.child("tbnPtePedido").on && this.child("tbnPteRx").on) {
		f += " AND tipogestion = 'Pedido'";
	}
	var referencia = this.child("ledReferencia").text;
	if (this.child("tbnBuscaRef").on && referencia != "") {
		f += " AND referencia = '" + referencia + "'";
	}
  return f;
}

function oficial_dameFiltroFin()
{
  var f = "fin";
  return f;
}

function oficial_tdbAlarmasPtes_recordChoosed()
{
  var _i = this.iface;
  var cursor = this.child("tdbAlarmasPtes").cursor();
  
  var idUsuario = _i.usuarioActual_;
  if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
  }
	
}

function oficial_tdbAlarmasFin_recordChoosed()
{
	var _i = this.iface;
  var cursor = this.child("tdbAlarmasFin").cursor();
}

function oficial_tbnIgnorar_clicked()
{
	var _i = this.iface;
  var cursor = this.child("tdbAlarmasPtes").cursor();
  
	var tipoGestion = cursor.valueBuffer("tipogestion");
	if (tipoGestion != "Pendiente") {
		if (tipoGestion == "Pedido") {
			var res = MessageBox.warning(sys.translate("La alarma tiene un pedido asociado. �Est� seguro de querer eliminarla?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
			if (res != MessageBox.Yes) {
				return false;
			}
		} else {
			sys.warnMsgBox(sys.translate("El tipo de gesti�n debe ser Pendiente"));
			return;
		}
	}
	
	var res = MessageBox.warning(sys.translate("Va a ignorar la alarma seleccionada. �Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		return;
	}
	
	var oParam = new Object;
  oParam.errorMsg = sys.translate("Error al ignorar la alarma seleccionada");
	oParam.curAlarma = cursor;
  var f = new Function("oParam", "return formem_alarmasmat.iface.ignorarAlarma(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  this.child("tdbAlarmasPtes").refresh();
  this.child("tdbAlarmasFin").refresh();
}

function oficial_tbnOrdenCronPtes_toggled(on)
{
	var tdbLC = this.child("tdbAlarmasPtes");
	var dtbLC = this.mainWidget().child("tdbAlarmasPtes").tableRecords();
	if (on) {
		tdbLC.autoSortColumn = true;
		var hHeader = dtbLC.horizontalHeader();
		hHeader.setClickEnabled(true);
	} else {
		tdbLC.autoSortColumn = false;
		var hHeader = dtbLC.horizontalHeader();
		hHeader.setClickEnabled(false);
		hHeader.setSortIndicator(-1, AQS.Ascending);
		dtbLC.setSort(["fecha DESC", "hora DESC"]);
	}
	dtbLC.refresh(AQS.RefreshData);
}

function oficial_tbnOrdenCronFin_toggled(on)
{
	var tdbLC = this.child("tdbAlarmasFin");
	var dtbLC = this.mainWidget().child("tdbAlarmasFin").tableRecords();
	if (on) {
		tdbLC.autoSortColumn = true;
		var hHeader = dtbLC.horizontalHeader();
		hHeader.setClickEnabled(true);
	} else {
		tdbLC.autoSortColumn = false;
		var hHeader = dtbLC.horizontalHeader();
		hHeader.setClickEnabled(false);
		hHeader.setSortIndicator(-1, AQS.Ascending);
		dtbLC.setSort(["fechafin DESC", "horafin DESC"]);
	}
	dtbLC.refresh(AQS.RefreshData);
}

function oficial_tbnAutoentrada_clicked()
{
	var _i = this.iface;
  var cursor = this.child("tdbAlarmasPtes").cursor();
  
	var tipoGestion = cursor.valueBuffer("tipogestion");
	if (tipoGestion != "Pendiente") {
		sys.warnMsgBox(sys.translate("El tipo de gesti�n debe ser Pendiente"));
		return;
	}
	
	var res = MessageBox.warning(sys.translate("Va a generar una autoentrada de material para la alarma pendiente seleccionada. �Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		return;
	}
	
	var oParam = new Object;
  oParam.errorMsg = sys.translate("Error al generar la autoentrada para la alarma seleccionada");
	oParam.curAlarma = cursor;
  var f = new Function("oParam", "return formem_alarmasmat.iface.autoentradaAlarma(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  this.child("tdbAlarmasPtes").refresh();
  this.child("tdbAlarmasFin").refresh();
}

function oficial_autoentradaAlarma(oParam)
{
	var _i = this.iface;
	var curAlarma = oParam.curAlarma;
  
  var hoy = new Date;
  var fecha = hoy.toString();
  
	var codProveedor = flfactppal.iface.pub_valorDefectoEmpresa("codprovinternolam");
  if (!codProveedor) {
    sys.warnMsgBox(sys.translate("Error al obtener proveedor interno de l�minas"));
    return false;
  }
  var nombreProv = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'");
  var codAlmacen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
  if (!codAlmacen) {
    sys.warnMsgBox(sys.translate("Error al obtener el almac�n por defecto de la empresa"));
    return false;
  }
  var codEjercicio = flfactppal.iface.pub_ejercicioActual();
  var datosDoc = flfacturac.iface.pub_datosDocFacturacion(fecha, codEjercicio, "albaranesprov");
  if (!datosDoc.ok) {
    return false;
  }
  if (datosDoc.modificaciones) {
    codEjercicio = datosDoc.codEjercicio;
    fecha = datosDoc.fecha;
  }
  var curA = new FLSqlCursor("albaranesprov");
  curA.setModeAccess(curA.Insert);
  curA.refreshBuffer();
  curA.setValueBuffer("fecha", fecha);
	curA.setValueBuffer("hora", hoy.toString().left(8));
  curA.setValueBuffer("nombre", nombreProv);
  curA.setValueBuffer("cifnif", AQUtil.sqlSelect("proveedores", "cifnif", "codproveedor = '" + codProveedor + "'"));
  curA.setValueBuffer("codproveedor", codProveedor);
  curA.setValueBuffer("coddivisa", flfactppal.iface.pub_valorDefectoEmpresa("coddivisa"));
  curA.setValueBuffer("codpago", AQUtil.sqlSelect("proveedores", "codpago", "codproveedor = '" + codProveedor + "'"));
  curA.setValueBuffer("codalmacen", codAlmacen);
  curA.setValueBuffer("tasaconv", 1);
  curA.setValueBuffer("codejercicio", codEjercicio);
	curA.setValueBuffer("codgrupoivaneg", AQUtil.sqlSelect("proveedores", "codgrupoivaneg", "codproveedor = '" + codProveedor + "'"));
  curA.setValueBuffer("codserie", AQUtil.sqlSelect("proveedores", "codserie", "codproveedor = '" + codProveedor + "'"));
  var idAlbaran = curA.valueBuffer("idalbaran");
  if (!curA.commitBuffer()) {
    return false;
  }
  var referencia = curAlarma.valueBuffer("referencia");
	var cantidad = curAlarma.valueBuffer("canpendiente");
  var curLinea = new FLSqlCursor("lineasalbaranesprov");
  
	curLinea.setModeAccess(curLinea.Insert);
	curLinea.refreshBuffer();
	curLinea.setValueBuffer("idalbaran", idAlbaran);
	curLinea.setValueBuffer("referencia", referencia);
	curLinea.setValueBuffer("descripcion", formRecordlineaspedidosprov.iface.pub_commonCalculateField("desarticulo", curLinea));
	curLinea.setValueBuffer("codtamanoem", AQUtil.sqlSelect("articulos", "codtamanoem", "referencia = '" + referencia + "'"));
	curLinea.setValueBuffer("codcolorem", AQUtil.sqlSelect("articulos", "codcolorem", "referencia = '" + referencia + "'"));
	curLinea.setValueBuffer("cantidad", cantidad);
	curLinea.setValueBuffer("pvpunitario", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpunitario", curLinea));
	curLinea.setValueBuffer("codimpuesto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("codimpuesto", curLinea));
	curLinea.setValueBuffer("iva", formRecordlineaspedidosprov.iface.pub_commonCalculateField("iva", curLinea));
	curLinea.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLinea));
	curLinea.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLinea));
	curLinea.setValueBuffer("numlinea",formRecordlineaspedidosprov.iface.pub_commonCalculateField("numlinea", curLinea));
	
	if (!curLinea.commitBuffer()) {
		return false;
	}
  
  curA.select("idalbaran = " + idAlbaran);
  if (!curA.first()) {
    return false;
  }
  with (curA) {
    setModeAccess(curA.Edit);
    refreshBuffer();
    setValueBuffer("netosindtoesp", formalbaranesprov.iface.pub_commonCalculateField("netosindtoesp", this));
    setValueBuffer("dtoesp", formalbaranesprov.iface.pub_commonCalculateField("dtoesp", this));
    setValueBuffer("neto", formalbaranesprov.iface.pub_commonCalculateField("neto", this));
    setValueBuffer("totaliva", formalbaranesprov.iface.pub_commonCalculateField("totaliva", this));
    setValueBuffer("totalirpf", formalbaranesprov.iface.pub_commonCalculateField("totalirpf", this));
    setValueBuffer("totalrecargo", formalbaranesprov.iface.pub_commonCalculateField("totalrecargo", this));
    setValueBuffer("total", formalbaranesprov.iface.pub_commonCalculateField("total", this));
    setValueBuffer("totaleuros", formalbaranesprov.iface.pub_commonCalculateField("totaleuros", this));
  }
  var codAlbaran = curA.valueBuffer("codigo");
  if (!curA.commitBuffer()) {
    return false;
  }
  
  
  if (!AQSql.update("em_alarmasmat", ["fin", "fechafin", "horafin", "tipogestion", "documento", "idalbaran", "codproveedor", "nombreproveedor", "canservida", "canpendiente"], [true, hoy.toString().left(10), hoy.toString().right(8), "Autoentrada", codAlbaran, idAlbaran, codProveedor, nombreProv, cantidad, 0], "idalarma = " + curAlarma.valueBuffer("idalarma"))) {
		return false;
	}
	
  return true;
}

function oficial_ignorarAlarma(oParam)
{
	var curA = oParam.curAlarma;
	var ahora = new Date;
	if (!AQSql.update("em_alarmasmat", ["fin", "fechafin", "horafin", "tipogestion"], [true, ahora.toString().left(10), ahora.toString().right(8), "Ignorada"], "idalarma = " + curA.valueBuffer("idalarma"))) {
		return false;
	}
	return true;
}

function oficial_tbnPedido_clicked()
{
  var _i = this.iface;
  var cursor = this.child("tdbAlarmasPtes").cursor();
  
  var tipoGestion = cursor.valueBuffer("tipogestion");
	if (tipoGestion != "Pendiente") {
		sys.warnMsgBox(sys.translate("El tipo de gesti�n debe ser Pendiente"));
		return;
	}
	
	var idUsuario = _i.usuarioActual_;
  if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
  }
  
  var codProveedor = flfactppal.iface.pub_valorDefectoEmpresa("codprovinternolam");
	
  var f = new FLFormSearchDB("em_pedidoalarmasmat");
  var curPAM = f.cursor();
  
  var sesion = flfactalma.iface.pub_dameSesion();
  curPAM.select("sesion = '" + sesion + "'");
  if (curPAM.first()) {
    curPAM.setModeAccess(curPAM.Edit);
  } else {
    curPAM.setModeAccess(curPAM.Insert);
  }
  curPAM.refreshBuffer();
  curPAM.setValueBuffer("sesion", sesion);
  curPAM.setValueBuffer("idusuario", idUsuario);
  curPAM.setValueBuffer("codproveedor", codProveedor);
	curPAM.setValueBuffer("nombreproveedor", AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'"));
	
  
  f.setMainWidget();
  idUsuario= f.exec("idusuario");
  if (!idUsuario) {
    return;
  }
  if (!curPAM.commitBuffer()) {
    return;
  }
}

function oficial_tbnEmailPedido_clicked()
{
	var oParam = new Object;
	var cursor = this.child("tdbAlarmasPtes").cursor();
	
	if (cursor.valueBuffer("tipogestion") != "Pedido") {
		sys.warnMsgBox(sys.translate("El tipo de gesti�n no es Pedido"));
		return false;
	}
	oParam.codPedido = cursor.valueBuffer("documento");
	if (!oParam.codPedido || oParam.codPedido == "") {
		sys.warnMsgBox(sys.translate("La alarma seleccionada no tiene pedido asociado"));
		return false;
	}
	var qA = new AQSqlQuery;
	qA.setSelect("idalarma")
	qA.setFrom("em_alarmasmat");
	qA.setWhere("tipogestion = 'Pedido' AND documento = '" + oParam.codPedido + "'");
	if (!qA.exec()) {
		return false;
	}
	var _pA = formem_pedidoalarmasmat.iface;
	_pA.listaAlarmas_ = "";
	while (qA.next()) {
		_pA.listaAlarmas_ += _pA.listaAlarmas_ != "" ? ", " : "";
		_pA.listaAlarmas_ += qA.value("idalarma");
	}
	if (_pA.listaAlarmas_ == "") {
		return false;
	}
  oParam.codProveedor = cursor.valueBuffer("codproveedor");
	oParam.nombreProv = cursor.valueBuffer("nombreproveedor");
	
	if (!formem_pedidoalarmasmat.iface.pub_enviaPedidoEmail(oParam)) {
		return false;
	}
	this.child("tdbAlarmasPtes").refresh();
  return true;
}

function oficial_tbnDocPte_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbAlarmasPtes").cursor();
	_i.verDoc(cursor);
}

function oficial_tbnDocFin_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbAlarmasFin").cursor();
	_i.verDoc(cursor);
}

function oficial_verDoc(cursor)
{
	var idPedido = cursor.valueBuffer("idpedido");
	var idAlbaran = cursor.valueBuffer("idalbaran");
	if (idPedido) {
		var curPedido = new FLSqlCursor("pedidosprov");
		curPedido.select("idpedido = " + idPedido);
		if (!curPedido.first()) {
			sys.warnMsgBox(sys.translate("No se ha encontrado el pedido"));
		}
		curPedido.browseRecord();
	} else if (idAlbaran) {
		var curAlbaran = new FLSqlCursor("albaranesprov");
		curAlbaran.select("idalbaran = " + idAlbaran);
		if (!curAlbaran.first()) {
			sys.warnMsgBox(sys.translate("No se ha encontrado el albar�n"));
		}
		curAlbaran.browseRecord();
	} else {
		sys.warnMsgBox(sys.translate("No hay documentos que mostrar"));
	}
}


//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////