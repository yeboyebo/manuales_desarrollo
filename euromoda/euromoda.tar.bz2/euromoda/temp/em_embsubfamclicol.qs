/***************************************************************************
                 em_embsubfamclicol.qs  -  description
                             -------------------
    begin                : mie abr 18 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }	
	function validateForm() {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var aSubFam_, aColor_, aTamano_;
	function oficial( context ) { interna( context ); } 
	function validaUnidades(cursor)  {
		return this.ctx.oficial_validaUnidades(cursor);
	}
	function validaCliCol(cursor)  {
		return this.ctx.oficial_validaCliCol(cursor);
	}
	function validaRepetidos(cursor)  {
		return this.ctx.oficial_validaRepetidos(cursor);
	}
	function filtraTamanos() {
		return this.ctx.oficial_filtraTamanos();
	}
	function validaTamano() {
		return this.ctx.oficial_validaTamano();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{	
	var _i = this.iface;
	var cursor = this.cursor();	
	_i.filtraTamanos();
	
}

function interna_validateForm()
{
	var _i = this.iface;	
	var cursor = this.cursor();

	if(!_i.validaTamano()) {
		return false;
	}

	if(!_i.validaUnidades(cursor)) {
		return false;
	}

	if(!_i.validaCliCol(cursor)) {
		return false;
	}

	if(!_i.validaRepetidos(cursor)) {
		return false;
	}

	return true;
}	
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_validaUnidades(cursor) 
{
	var unidades = cursor.valueBuffer("em_unidadesemb");
	if(!unidades || unidades <=0) {
		flfactppal.iface.ponMsgError(sys.translate("Debe indicar un valor mayor que cero para Unidades por embalaje"),"warn",this);
		return false;
	}
	return true;
}

function oficial_validaCliCol(cursor)
{
	var codCliente = cursor.valueBuffer("codcliente");	
	var codColeccion = cursor.valueBuffer("codcoleccionem");
	if((!codCliente || codCliente == "") && (!codColeccion || codColeccion == "")) {
		flfactppal.iface.ponMsgError(sys.translate("Debe indicar un valor para Cliente y/o Colecci�n"),"warn",this);
		return false;
	}
	return true;
}

function oficial_validaRepetidos(cursor) 
{
	var id = cursor.valueBuffer("idembsubfamclicol");
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codTamano = cursor.valueBuffer("codtamanoem"); 
	var codCliente = cursor.valueBuffer("codcliente");
	var codColeccion = cursor.valueBuffer("codcoleccionem");
	var msg = "Ya existe un registro para familia " + codSubfamilia + ", tama�o " + codTamano;
	var where = "idembsubfamclicol <> " + id + " AND codsubfamilia = '" + codSubfamilia + "' and codtamanoem = '" + codTamano + "'";

	if(codCliente && codCliente != "") {
		where += " and codcliente = '" + codCliente + "'";
		msg += ", cliente " + codCliente;
	} else {
		where += " and (codcliente is null or codcliente = '')";
		msg += ", cliente vac�o"
	}
	if(codColeccion && codColeccion != "") {
		where += " and codcoleccionem = '" + codColeccion + "'";
		msg +=" y colecci�n " + codColeccion;
	} else { 
 		where += " and (codcoleccionem is null or codcoleccionem = '')";
 		msg +=" y colecci�n vac�a."
	}	

	if(AQUtil.sqlSelect("em_embsubfamclicol","codsubfamilia",where)) {
		flfactppal.iface.ponMsgError(sys.translate(msg),"warn",this);
		return false;		
	}	
	return true;

}

function oficial_filtraTamanos()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var filtro = "";
	if(codSubfamilia && codSubfamilia != "") {
		filtro = "codtamanoem IN (SELECT codtamanoem FROM em_tamanossubfam WHERE codsubfamilia = '" + codSubfamilia + "')";
	}
	
	this.child("fdbCodTamanoEm").setFilter(filtro);
}

function oficial_validaTamano()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codTamano = cursor.valueBuffer("codtamanoem");
	var codSubfamilia = cursor.valueBuffer("codsubfamilia"); 
	if(codTamano && codTamano != "") {
		if(!AQUtil.sqlSelect("em_tamanossubfam","codtamanoem","codsubfamilia = '" + codSubfamilia + "' and codtamanoem = '" + codTamano + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("El tama�o %1 no pertenece a la subfamilia %2").arg(codTamano).arg(codSubfamilia),"warn",this);
			return false;
		}
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////