
/** @class_declaration euromoda*/
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends frasImport {
  function euromoda( context ) { frasImport ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function habilitaPorSerie() {
    return this.ctx.euromoda_habilitaPorSerie();
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function calcularTotales() {
    return this.ctx.euromoda_calcularTotales();
  }
  function actualizarLineasIva(curFactura) {
		return this.ctx.euromoda_actualizarLineasIva(curFactura);
	}
	function dameFiltroFacturasImport() {
		return this.ctx.euromoda_dameFiltroFacturasImport();
	}
	function crearLinea_clicked() {
		return this.ctx.euromoda_crearLinea_clicked();
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function controlBloqueo() {
		return this.ctx.euromoda_controlBloqueo();
	}
	function habilitaPorAutomatica() {
		return this.ctx.euromoda_habilitaPorAutomatica();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
  case "codproveedor": {
		_i.__bufferChanged(fN);
		sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
		if (!flfacturac.iface.pub_controlBloqueoProveedor(cursor.valueBuffer("codproveedor"), "Todo")) {
			sys.AQTimer.singleShot(0, formRecordfacturasprov.reject)
		}
		break;
	}
  case "deabono":{
		_i.__bufferChanged(fN);
		sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
    break;
	}
	case "fechavalor": {
		sys.setObjText(this, "fdbFechaOperacion", _i.calculateField("fechaoperacion"));
		sys.setObjText(this, "fdbFechaExpedicion", _i.calculateField("fechaexpedicion"));
		break;
	}
  	case "fechaexpedicion": {
		cursor.setValueBuffer("periodo", _i.calculateField("periodo"));
		sys.setObjText(this, "fdbFechaEjercicio", _i.calculateField("ejercicio"));
		break;
	}
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
  _i.habilitaPorSerie();
}

function euromoda_habilitaPorSerie()
{
  var cursor = this.cursor();
  if (cursor.modeAccess() == cursor.Edit) {
    this.child("fdbCodProveedor").setDisabled(true);
    this.child("fdbDeAbono").setDisabled(true);
  } else {
    this.child("fdbCodProveedor").setDisabled(false);
    this.child("fdbDeAbono").setDisabled(false);
  }
}

function euromoda_calcularTotales()
{
    var _i = this.iface;
  _i.__calcularTotales();
  _i.habilitaPorSerie();
}

function euromoda_actualizarLineasIva(curFactura)
{
	
	var idFactura;
	try {
		idFactura = curFactura.valueBuffer("idfactura");
	} catch (e) {
		// Antes se recib�a s�lo idFactura
		MessageBox.critical(sys.translate("Hay un problema con la actualizaci�n de su personalizaci�n.\nPor favor, p�ngase en contacto con InfoSiAL para solucionarlo"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}

	var porDto = 0;
	if(flfactppal.iface.pub_extension("dto_especial")){
	 	porDto = parseFloat(curFactura.valueBuffer("pordtoesp"));
		porDto = isNaN(porDto) ? 0 : porDto;
	}

	var netoExacto = curFactura.valueBuffer("neto");
	netoExacto = AQUtil.roundFieldValue(netoExacto, "facturasprov", "neto");

	//var lineasSinIVA = AQUtil.sqlSelect("lineasfacturasprov", "SUM(pvptotal)", "idfactura = " + idFactura + " AND (iva IS NULL OR (codimpuesto = 'NO SUJETO' AND iva = 0) OR codimpuesto IN ('TOTAL', 'TOTALBI'))");
	var lineasSinIVA = AQUtil.sqlSelect("lineasfacturasprov", "SUM(pvptotal)", "idfactura = " + idFactura + " AND (iva IS NULL OR codimpuesto IN ('TOTAL', 'TOTALBI'))");
	lineasSinIVA = (isNaN(lineasSinIVA) ? 0 : lineasSinIVA);
	netoExacto -= lineasSinIVA;
	netoExacto = AQUtil.roundFieldValue(netoExacto, "facturasprov", "neto");


	var ivaExacto, reExacto;
	if (porDto == 0) {
		ivaExacto = curFactura.valueBuffer("totaliva");
		reExacto = curFactura.valueBuffer("totalrecargo");
	} else {
		ivaExacto = AQUtil.sqlSelect("lineasfacturasprov", "SUM((pvptotal * iva * (100 - " + porDto + ")) / 100 / 100)", "idfactura = " + idFactura);
		reExacto = AQUtil.sqlSelect("lineasfacturasprov", "SUM((pvptotal * recargo * (100 - " + porDto + ")) / 100 / 100)", "idfactura = " + idFactura);
	}

	if (!AQUtil.sqlDelete("lineasivafactprov", "idfactura = " + idFactura)) {
		return false;
	}

	var codImpuestoAnt = "", codImpuesto = "";
	var iva, recargo;
	var totalNeto = 0, totalIva = 0, totalRecargo = 0, totalLinea = 0;
	var acumNeto = 0, acumIva = 0, acumRecargo = 0;

	var curLineaIva = new FLSqlCursor("lineasivafactprov");
	var qryLineasFactura = new FLSqlQuery;
	with (qryLineasFactura) {
		setTablesList("lineasfacturasprov");
		setSelect("codimpuesto, iva, recargo, pvptotal");
		setFrom("lineasfacturasprov");
		//setWhere("idfactura = " + idFactura + " AND pvptotal <> 0 AND iva IS NOT NULL AND codimpuesto NOT IN ('NO SUJETO', 'TOTAL', 'TOTALBI') ORDER BY codimpuesto");
		setWhere("idfactura = " + idFactura + " AND pvptotal <> 0 AND iva IS NOT NULL AND codimpuesto NOT IN ('TOTAL', 'TOTALBI') ORDER BY iva");
		setForwardOnly(true);
	}
	if (!qryLineasFactura.exec()) {
		return false;
	}

	while (qryLineasFactura.next()) {
		codImpuesto = qryLineasFactura.value("codimpuesto");
		if (codImpuestoAnt != "" && codImpuestoAnt != codImpuesto) {
			totalNeto = (totalNeto * (100 - porDto)) / 100;
			totalNeto = AQUtil.roundFieldValue(totalNeto, "lineasivafactprov", "neto");
			totalIva = AQUtil.roundFieldValue((iva * totalNeto) / 100, "lineasivafactprov", "totaliva");
			totalRecargo = AQUtil.roundFieldValue((recargo * totalNeto) / 100, "lineasivafactprov", "totalrecargo");
			totalLinea = parseFloat(totalNeto) + parseFloat(totalIva) + parseFloat(totalRecargo);
			totalLinea = AQUtil.roundFieldValue(totalLinea, "lineasivafactprov", "totallinea");

			acumNeto += parseFloat(totalNeto);
			acumIva += parseFloat(totalIva);
			acumRecargo += parseFloat(totalRecargo);

			curLineaIva.setModeAccess(curLineaIva.Insert);
			curLineaIva.refreshBuffer();
			curLineaIva.setValueBuffer("idfactura", idFactura);
			curLineaIva.setValueBuffer("codimpuesto", codImpuestoAnt);
			curLineaIva.setValueBuffer("iva", iva);
			curLineaIva.setValueBuffer("recargo", recargo);
			curLineaIva.setValueBuffer("neto", totalNeto);
			curLineaIva.setValueBuffer("totaliva", totalIva);
			curLineaIva.setValueBuffer("totalrecargo", totalRecargo);
			curLineaIva.setValueBuffer("totallinea", totalLinea);

			if (!curLineaIva.commitBuffer()) {
				return false;
			}
			totalNeto = 0;
		}
		codImpuestoAnt = codImpuesto;
		iva = parseFloat(qryLineasFactura.value("iva"));
		recargo = parseFloat(qryLineasFactura.value("recargo"));
		if (isNaN(recargo)) {
			recargo = 0;
		}
		totalNeto += parseFloat(qryLineasFactura.value("pvptotal"));
	}
	if (totalNeto != 0) {
		totalNeto = AQUtil.roundFieldValue(netoExacto - acumNeto, "lineasivafactprov", "neto");
		totalIva = AQUtil.roundFieldValue(ivaExacto - acumIva, "lineasivafactprov", "totaliva");
		totalRecargo = AQUtil.roundFieldValue(reExacto - acumRecargo, "lineasivafactprov", "totalrecargo");
		totalLinea = parseFloat(totalNeto) + parseFloat(totalIva) + parseFloat(totalRecargo);
		totalLinea = AQUtil.roundFieldValue(totalLinea, "lineasivafactprov", "totallinea");


		curLineaIva.setModeAccess(curLineaIva.Insert);
		curLineaIva.refreshBuffer();
		curLineaIva.setValueBuffer("idfactura", idFactura);
		curLineaIva.setValueBuffer("codimpuesto", codImpuestoAnt);
		curLineaIva.setValueBuffer("iva", iva);
		curLineaIva.setValueBuffer("recargo", recargo);
		curLineaIva.setValueBuffer("neto", totalNeto);
		curLineaIva.setValueBuffer("totaliva", totalIva);
		curLineaIva.setValueBuffer("totalrecargo", totalRecargo);
		curLineaIva.setValueBuffer("totallinea", totalLinea);

		if (!curLineaIva.commitBuffer()) {
			return false;
		}
	}
	return true;
}

function euromoda_dameFiltroFacturasImport()
{
	var _i = this.iface;
	var filtro = _i.__dameFiltroFacturasImport();
	if (filtro != "") {
		filtro += " AND ";
	}
	filtro += "codproveedor IN (SELECT codproveedor FROM proveedores WHERE codgrupocontableneg = 'EXPORT')";
	return filtro;
}

function euromoda_crearLinea_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.isNull("idfacturaimport")) {
		var res = MessageBox.warning(sys.translate("No ha indicado la factura de importaci�n asociada.\n�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return;
		}
	}
	_i.__crearLinea_clicked();
}

function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.controlBloqueo()) {
		return false;
	}
	return true;
}

function euromoda_controlBloqueo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codProveedor = cursor.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
      return false;
    }
  }
	return true;
}

function euromoda_habilitaPorAutomatica()
{
	return true;
}

//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
