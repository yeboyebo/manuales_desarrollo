
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod
{
  var COL_ORDEN, COL_TAMANO, COL_COLOR, COL_LARGO, COL_ANCHO, COL_ALTO, COL_PANCHO, COL_FACTOR, COL_COMPONENTE, COL_RESERVAR;
  var codFamTCrudo_, codFamTEstampado_;
  var curLineaFT_;
  var oResGFT_;
  var curS_;
  var pK_;
  var referenciaVM_;
  var tblLogCostes_;
  var pulsaHeredar_;
  var curUbiAlt_;
  function euromoda(context)
  {
    prod(context);
  }
  function init()
  { 
    return this.ctx.euromoda_init();
  }
  function tbnCalculaDescripcion_clicked()
  { 
    return this.ctx.euromoda_tbnCalculaDescripcion_clicked();
  }
  function ordenaColsStock()
  { 
    return this.ctx.euromoda_ordenaColsStock();
  }
  function tbnColeccionPpal_clicked()
  { 
    return this.ctx.euromoda_tbnColeccionPpal_clicked();
  }
  function formatoTablaFT()
  { 
    return this.ctx.euromoda_formatoTablaFT();
  }
  function iniciarControles()
  {
    return this.ctx.euromoda_iniciarControles();
  }
  function crearArbolComponentes()
  {
    return this.ctx.euromoda_crearArbolComponentes();
  }
  function crearArbolCompuestos()
  {
    return this.ctx.euromoda_crearArbolCompuestos();
  }
  function anadirComponente()
  {
    return this.ctx.euromoda_anadirComponente();
  }
  function establecerColumnas()
  {
    return this.ctx.euromoda_establecerColumnas();
  }
  function calcularDatosNodoComponente(referencia, idOpcionArticulo)
  {
    return this.ctx.euromoda_calcularDatosNodoComponente(referencia, idOpcionArticulo);
  }
  function establecerDatosNodo(nodo, datos)
  {
    return this.ctx.euromoda_establecerDatosNodo(nodo, datos);
  }
  function establecerOpcionNodo(nodo, datos)
  {
    return this.ctx.euromoda_establecerOpcionNodo(nodo, datos);
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function calculateField(fN)
  {
    return this.ctx.euromoda_calculateField(fN);
  }
  function establecerFiltroDibujos()
  {
    return this.ctx.euromoda_establecerFiltroDibujos();
  }
  function establecerFiltroSubfamilia()
  {
    return this.ctx.euromoda_establecerFiltroSubfamilia();
  }
  function establecerFiltroTamano()
  {
    return this.ctx.euromoda_establecerFiltroTamano();
  }
  function establecerFiltroColores()
  {
    return this.ctx.euromoda_establecerFiltroColores();
  }
  function validateForm()
  {
    return this.ctx.euromoda_validateForm();
  }
  function validarDibujos()
  {
    return this.ctx.euromoda_validarDibujos();
  }
  function validarEmbalaje()
  {
    return this.ctx.euromoda_validarEmbalaje();
  }
  function validarColor()
  {
    return this.ctx.euromoda_validarColor();
  }
  function validarTamano()
  {
    return this.ctx.euromoda_validarTamano();
  }
  function controlHabilitacion(miForm, miControl, habilitado)
  {
    return this.ctx.euromoda_controlHabilitacion(miForm, miControl, habilitado);
  }
  function ponDatosModificacion()
  {
    return this.ctx.euromoda_ponDatosModificacion();
  }
  function refrescarNodos()
  {
    return this.ctx.euromoda_refrescarNodos();
  }
  function tbnImportarFT_clicked()
  {
    return this.ctx.euromoda_tbnImportarFT_clicked();
  }
  function habilitarPorFamilia()
  {
    return this.ctx.euromoda_habilitarPorFamilia();
  }
	function validarTareaProduccion():Boolean {
		return this.ctx.euromoda_validarTareaProduccion();
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
	/*function aplicarPlantillaTamanosFT(refProducto) {
		return this.ctx.euromoda_aplicarPlantillaTamanosFT(refProducto);
	}*/
	function tbnStockComponente_clicked() {
		return this.ctx.euromoda_tbnStockComponente_clicked();
	}
	function calculaDescripcion(cursor) {
		return this.ctx.euromoda_calculaDescripcion(cursor);
	}
	function genCodBar(fN) {
		return this.ctx.euromoda_genCodBar(fN);
	}
	function validaPanotCont() {
		return this.ctx.euromoda_validaPanotCont();
	}
	function tdbFichaTecnica_bufferCommited() {
		return this.ctx.euromoda_tdbFichaTecnica_bufferCommited();
	}
	function calculaFactoresFT(cursor, ignorar) {
		return this.ctx.euromoda_calculaFactoresFT(cursor, ignorar);
	}
	function tbnTest1_clicked() {
		return this.ctx.euromoda_tbnTest1_clicked();
	}
	function tbnTest2_clicked() {
		return this.ctx.euromoda_tbnTest2_clicked();
	}
	function prendasAMetros(referencia, p) {
		return this.ctx.euromoda_prendasAMetros(referencia, p);
	}
	function metrosAPrendas(referencia, m) {
		return this.ctx.euromoda_metrosAPrendas(referencia, m);
	}
	function importarFT(refProducto, refOrigen) {
		return this.ctx.euromoda_importarFT(refProducto, refOrigen);
	}
	function tbnGenerarFT_clicked() {
		return this.ctx.euromoda_tbnGenerarFT_clicked();
	}
	function generarFT(cursor) {
		return this.ctx.euromoda_generarFT(cursor);
	}
	function dameTipoProceso(cursor) {
		return this.ctx.euromoda_dameTipoProceso(cursor);
	}
	function compruebaFT(cursor) {
		return this.ctx.euromoda_compruebaFT(cursor);
	}
	function borrarFT(referencia) {
		return this.ctx.euromoda_borrarFT(referencia);
	}
	function generadorFTV1(cursor) {
		return this.ctx.euromoda_generadorFTV1(cursor);
	}
	function copiaLinea(cursor,curLinea,esColPlan, coleccion) {
		return this.ctx.euromoda_copiaLinea(cursor,curLinea,esColPlan,coleccion);
	}
	function copiaCampoLinea(nombreCampo, curLinea, campoInformado, cursor) {
		return this.ctx.euromoda_copiaCampoLinea(nombreCampo, curLinea, campoInformado, cursor);
	}
	function buscaRefCandidatas(curLinea, cursor) {
		return this.ctx.euromoda_buscaRefCandidatas(curLinea, cursor);
	}
	function pbnEnRevision_clicked() {
		return this.ctx.euromoda_pbnEnRevision_clicked();
	}
	function pbnEnProduccion_clicked() {
		return this.ctx.euromoda_pbnEnProduccion_clicked();
	}
	function ponEnRevision(cursor) {
		return this.ctx.euromoda_ponEnRevision(cursor);
	}
	function ponEnProduccion(cursor) {
		return this.ctx.euromoda_ponEnProduccion(cursor);
	}
	function buscarPlantilla(oParamBP) {
		return this.ctx.euromoda_buscarPlantilla(oParamBP);
	}
	function dameRefCandidataCoord(codSubfamilia,dibujoCoord,codTamanio,colorCoord) {
		return this.ctx.euromoda_dameRefCandidataCoord(codSubfamilia,dibujoCoord,codTamanio,colorCoord);
	}	
	function dameRefCandidata(codTamanio, curLinea, cursor) {
		return this.ctx.euromoda_dameRefCandidata(codTamanio, curLinea, cursor);
	}
	function elegirTamaRefCan(codDibujoPR, curLinea) {
		return this.ctx.euromoda_elegirTamaRefCan(codDibujoPR, curLinea);
	}
	function filtrarPorCoincidencias(q, oParamFiltro) {
		return this.ctx.euromoda_filtrarPorCoincidencias(q, oParamFiltro);
	}
	function establecerValorFamilia() {
		return this.ctx.euromoda_establecerValorFamilia();
	}
	function ordenaColsValMercado() {
		return this.ctx.euromoda_ordenaColsValMercado();
	}
	function toolButtonInsertEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonInsertEmValMercado_clicked()
	}
	function toolButtonEditEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonEditEmValMercado_clicked()
	}
	function toolButtonDeleteEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonDeleteEmValMercado_clicked();
	}
	function toolButtonZoomEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonZoomEmValMercado_clicked();
	}
	function curS_bufferCommited() {
		return this.ctx.euromoda_curS_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tdbEmValoresMercado_recordChoosed() {
		return this.ctx.euromoda_tdbEmValoresMercado_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function formReady() {
		return this.ctx.euromoda_formReady();
	}
	function habilitaCamposCostesProd(miForm, cursor) {
		return this.ctx.euromoda_habilitaCamposCostesProd(miForm, cursor);
	}
	function cargaDatosLogCostes() {
		return this.ctx.euromoda_cargaDatosLogCostes();
	}
	function dameTablaLogCostes() {
		return this.ctx.euromoda_dameTablaLogCostes();
	}
	function dameSelectLogCostes(cursor) {
		return this.ctx.euromoda_dameSelectLogCostes(cursor);
	}
	function dameWhereLogCostes(cursor) {
		return this.ctx.euromoda_dameWhereLogCostes(cursor);
	}
	function ponTamanosLogCostes(miTabla) {
		return this.ctx.euromoda_ponTamanosLogCostes(miTabla);
	}
	function pbnHeredarCoste_clicked() {
		return this.ctx.euromoda_pbnHeredarCoste_clicked();
	}	
	function heredarCosteProd(cursor, silent, ponLog) {
		return this.ctx.euromoda_heredarCosteProd(cursor,silent, ponLog);
	}
	function dameCosteProd(cursor, silent) {
		return this.ctx.euromoda_dameCosteProd(cursor, silent);
	}
	function pbnHeredarMargen_clicked() {
		return this.ctx.euromoda_pbnHeredarMargen_clicked();
	}	
	function heredarMargenProd(cursor,silent, ponLog) {
		return this.ctx.euromoda_heredarMargenProd(cursor,silent, ponLog);
	}
	function dameMargenProd(cursor, silent) {
		return this.ctx.euromoda_dameMargenProd(cursor, silent);
	}
	function insertaRegistroLog(oParam) {
		return this.ctx.euromoda_insertaRegistroLog(oParam);
	}
	function compruebaUltimoLog(oParam) {
		return this.ctx.euromoda_compruebaUltimoLog(oParam);
	}
	function ponDatosLogCostes(gridAsociado, cursor) {
		return this.ctx.euromoda_ponDatosLogCostes(gridAsociado, cursor);
	}
	function tbwArticulo_currentChanged(tab) {
		return this.ctx.euromoda_tbwArticulo_currentChanged(tab);
	}
	function heredarCosteMargenProd(cursor, silent) {
		return this.ctx.euromoda_heredarCosteMargenProd(cursor, silent);
	}
	function columnasCompras() {
		return this.ctx.euromoda_columnasCompras();
	}
	function tdbEmUbicaciones_recordChoosed() {
		return this.ctx.euromoda_tdbEmUbicaciones_recordChoosed();
	}
	function toolButtonInsertUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonInsertUbiAlt_clicked();
	}
	function toolButtonEditUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonEditUbiAlt_clicked();
	}
	function toolButtonDeleteUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonDeleteUbiAlt_clicked();
	}
	function toolButtonZoomUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonZoomUbiAlt_clicked();
	}
	function accionCursorExternoUbiAlt(accion) {
		return this.ctx.euromoda_accionCursorExternoUbiAlt(accion);
	}
	function curUbiAlt_bufferCommited() {
		return this.ctx.euromoda_curUbiAlt_bufferCommited();
	}
	function refrescaTablaUbiAlt() {
		return this.ctx.euromoda_refrescaTablaUbiAlt();
	}
	function tbnUbicacionActual_clicked() { 
    	return this.ctx.euromoda_tbnUbicacionActual_clicked();
  	}

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
  function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
}
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	_i.__init();
	_i.pulsaHeredar_ = false;
	connect(this.child("tbnImportarFT"), "clicked()", _i, "tbnImportarFT_clicked");
	if (this.child("tbnColeccionPpal")) {
		connect(this.child("tbnColeccionPpal"), "clicked()", _i, "tbnColeccionPpal_clicked");
	}
	if (this.child("tbnUbicacionActual")) {
		connect(this.child("tbnUbicacionActual"), "clicked()", _i, "tbnUbicacionActual_clicked");
	}
	connect(this.child("tbnStockComponente"), "clicked()", _i, "tbnStockComponente_clicked");	
	connect(this.child("tbnCalculaDescripcion"), "clicked()", _i, "tbnCalculaDescripcion_clicked");	
	connect(this.child("tdbFichaTecnica").cursor(), "bufferCommited()", _i, "tdbFichaTecnica_bufferCommited");	

	_i.iniciarControles();
	_i.formatoTablaFT();
		
	if (cursor.action() == "em_fichatecnica" || cursor.action() == "em_fichatecnicaedit" || cursor.action() == "") {
		this.child("tbwArticulo").showPage("tbpComposicion");
	}
	if (cursor.action() != "em_fichatecnica" && cursor.action() != "") {
		connect(this.child("tbnTest1"), "clicked()", _i, "tbnTest1_clicked");
		connect(this.child("tbnTest2"), "clicked()", _i, "tbnTest2_clicked");
		connect(this.child("toolButtonInsertEmValMercado"), "clicked()", _i, "toolButtonInsertEmValMercado_clicked");
		connect(this.child("toolButtonEditEmValMercado"), "clicked()", _i, "toolButtonEditEmValMercado_clicked");
		connect(this.child("toolButtonDeleteEmValMercado"), "clicked()", _i, "toolButtonDeleteEmValMercado_clicked");
		connect(this.child("toolButtonZoomEmValMercado"), "clicked()", _i, "toolButtonZoomEmValMercado_clicked");	
		connect(this.child("tdbEmValoresMercado").cursor(), "recordChoosed()", _i, "tdbEmValoresMercado_recordChoosed");
		if(cursor.valueBuffer("em_controlvalmercado")){
			this.child("tbwArticulo").setTabEnabled("em_valoresmercadoprin", true);
			sys.runObjMethod(this, "tdbEmValoresMercado", "setOnlyTable", true);
		} else {
			this.child("tbwArticulo").setTabEnabled("em_valoresmercadoprin", false);
		}
		_i.ordenaColsValMercado();

		if(this.child("toolButtonInsertUbiAlt")) {
			connect(this.child("toolButtonInsertUbiAlt"), "clicked()", _i, "toolButtonInsertUbiAlt_clicked");	
		}
		
		if(this.child("toolButtonEditUbiAlt")) {
			connect(this.child("toolButtonEditUbiAlt"), "clicked()", _i, "toolButtonEditUbiAlt_clicked");	
		}
		
		if(this.child("toolButtonDeleteUbiAlt")) {
			connect(this.child("toolButtonDeleteUbiAlt"), "clicked()", _i, "toolButtonDeleteUbiAlt_clicked");	
		}
		
		if(this.child("toolButtonZoomUbiAlt")) {
			connect(this.child("toolButtonZoomUbiAlt"), "clicked()", _i, "toolButtonZoomUbiAlt_clicked");	
		}
		if(this.child("tdbEmUbicaciones")) {
			connect(this.child("tdbEmUbicaciones").cursor(), "recordChoosed()", _i, "tdbEmUbicaciones_recordChoosed");		
		}
		


	}

	connect(this.child("tbnGenerarFT"), "clicked()", _i, "tbnGenerarFT_clicked");
	connect(this.child("pbnEnRevision"), "clicked()", _i, "pbnEnRevision_clicked");
	connect(this.child("pbnEnProduccion"), "clicked()", _i, "pbnEnProduccion_clicked");	

	_i.ordenaColsStock();	
	_i.habilitaCamposCostesProd(this, cursor);

	if(this.child("pbnHeredarCoste")) {
		connect(this.child("pbnHeredarCoste"), "clicked()", _i, "pbnHeredarCoste_clicked");	
	}
	if(this.child("pbnHeredarMargen")) {
		connect(this.child("pbnHeredarMargen"), "clicked()", _i, "pbnHeredarMargen_clicked");		
	}

	connect(this.child("tbwArticulo"), "currentChanged(QString)", _i, "tbwArticulo_currentChanged()");
	_i.tblLogCostes_ = undefined;
	_i.cargaDatosLogCostes();
		
}

function euromoda_tdbFichaTecnica_bufferCommited()
{
	
	var _i = this.iface;
  	var cursor = this.cursor();

  	_i.calculaFactoresFT(cursor, true);
}	

function euromoda_calculaFactoresFT(cursor, ignorar)
{
  	var _i = this.iface;
  	
  	var q = new FLSqlQuery;
  	q.setSelect("largo, piezasancho");
  	q.setFrom("articuloscomp");
  	q.setWhere("refcompuesto = '" + cursor.valueBuffer("referencia") + "' AND componormal IN ('ANVERSO', 'ANVERSO COJIN') ORDER BY componormal");
  	if (!q.exec()) {
  		return false;
  	}
  	if (!q.first()) {
  		cursor.setValueBuffer("em_prendasxancho", 0);
  		cursor.setValueBuffer("em_cmsxprenda", 0);
  		if (!ignorar) {
  			sys.warnMsgBox(sys.translate("No puede realizarse la conversi�n cantidad - metros para el producto %1. Revise su ficha t�cnica").arg(cursor.valueBuffer("referencia")));
  			return false;
  		}
  		return true;
  	}
  	var pxa = q.value("piezasancho");
  	if (!pxa || pxa == 0) {
  		pxa = 1;
  	}
  	cursor.setValueBuffer("em_prendasxancho", pxa);
  	cursor.setValueBuffer("em_cmsxprenda", q.value("largo"));

  	return true;
}

function euromoda_tbnTest1_clicked()
{
	var _i = this.iface;
  	var cursor = this.cursor();

  	var p = Input.getNumber("Prendas");
	if (!p) {
		return;
	}
	sys.infoMsgBox("Metros " + _i.prendasAMetros(cursor.valueBuffer("referencia"), p))
}

function euromoda_tbnTest2_clicked()
{
	var _i = this.iface;
  	var cursor = this.cursor();

  	var m = Input.getNumber("Metros");
	if (!m) {
		return;
	}
	sys.infoMsgBox("Prendas " + _i.metrosAPrendas(cursor.valueBuffer("referencia"), m))
}

/*El c�lculo de conversi�n de cantidad a metros es el siguiente:
Metros = (Cantidad / PrendasXAncho redondeado hacia arriba) x Longitud por prenda
*/
function euromoda_prendasAMetros(referencia, p)
{
	var q = new FLSqlQuery;
  	q.setSelect("em_prendasxancho, em_cmsxprenda");
  	q.setFrom("articulos");
  	q.setWhere("referencia = '" + referencia + "'");
  	if (!q.exec()) {
  		return false;
  	}
  	if (!q.first()) {
  		return false;
  	}
  	var pxa = parseFloat(q.value("em_prendasxancho"));
  	if (!pxa || pxa == 0) {
  		return false;
  	}
  	var cmxp = parseFloat(q.value("em_cmsxprenda"));
  	var m = (Math.ceil(p / pxa) * cmxp) / 100;
  	return m;
}

/*Cantidad = (Metros / Longitud por prenda redondeado hacia abajo) x PrendasXAncho.*/
function euromoda_metrosAPrendas(referencia, m)
{
	var q = new FLSqlQuery;
  	q.setSelect("em_prendasxancho, em_cmsxprenda");
  	q.setFrom("articulos");
  	q.setWhere("referencia = '" + referencia + "'");
  	if (!q.exec()) {
  		return false;
  	}
  	if (!q.first()) {
  		return false;
  	}
  	var pxa = parseFloat(q.value("em_prendasxancho"));
  	var cmxp = parseFloat(q.value("em_cmsxprenda"));
  	if (!cmxp) {
  		return false;
  	}  
  	var p = (Math.floor((m * 100) / cmxp) * pxa);
  	return p;
}

function euromoda_tbnCalculaDescripcion_clicked()
{
	var _i = this.iface;
  	var cursor = this.cursor();
  	sys.setObjText(this, "fdbDescripcion", _i.calculaDescripcion(cursor));
}

function euromoda_ordenaColsStock()
{
	if (!this.child("tdbStocks")) {
		return;
	}
	var oC = ["codalmacen", "nombre", "cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir", "disponiblepterecibir", "afaltas", "prevision", "stockmin", "necesidad"];
	
	var oCAncho = ["cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir", "disponiblepterecibir", "afaltas", "prevision", "codalmacen", "referencia", "coddibestamp", "stockmin", "stockmax", "necesidad"];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tdbStocks").setColumnWidth(oCAncho[c], 80);
	}
	this.child("tdbStocks").setOrderCols(oC);
}

function euromoda_tbnColeccionPpal_clicked()
{
	var cursor = this.cursor();
	var curCol = this.child("tdbColeccionesArt").cursor();
	var idCol = curCol.valueBuffer("idcoleccionart");
	if (!idCol) {
		return;
	}
	var codColeccionEM = curCol.valueBuffer("codcoleccionem");
	if (!AQSql.update("em_coleccionesart", ["principal"], [false], "referencia = '" + cursor.valueBuffer("referencia") + "'")) {
		return false;
	}
	if (!AQSql.update("em_coleccionesart", ["principal"], [true], "idcoleccionart = " + idCol)) {
		return false;
	}
	this.child("tdbColeccionesArt").refresh();
	sys.setObjText(this, "fdbCodColeccionEM", codColeccionEM);
}

function euromoda_formatoTablaFT()
{
	var t = this.child("tdbFichaTecnica");
	var campos = ["orden", "refcomponente", "cantidad", "largo", "ancho", "alto", "piezasancho", "factor", "reservar", "codunidad", "idseccion"];
	for (var i = 0; i < campos.length; i++) {
		this.child("tdbFichaTecnica").setColumnWidth(campos[i], 60);
	}
}

function euromoda_tbnImportarFT_clicked()
{
  var cursor = this.cursor();
  var _i = this.iface;
  
  if (cursor.modeAccess() == cursor.Insert) {
    if (!this.child("tdbArticulosProv").cursor().commitBufferCursorRelation()) {
      return false;
    }
  }
   var refOrigen = cursor.valueBuffer("referencia");
 
  var f = new FLFormSearchDB("em_sel1articulo");
  var curProductos = f.cursor();
  curProductos.setModeAccess(curProductos.Insert);
  curProductos.refreshBuffer();
//  curProductos.setMainFilter("em_tipoarticulo = 'Producto'");
  f.setMainWidget();
  var refProducto = f.exec("referencia");
  if (!refProducto) {
    return;
  }
  var qDes = new AQSqlQuery;
	qDes.setSelect("ac.refcomponente, a.descripcion");
	qDes.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia");
	qDes.setWhere("ac.refcompuesto = '" + refProducto + "' AND (descatalogado OR debaja)");
	if (!qDes.exec()) {
		return false;
	}
	if (qDes.size() > 0) {
		var l = "";
		while (qDes.next()) {
			l += "\n" + qDes.value("ac.refcomponente") + " - " + qDes.value("a.descripcion");
		}
		var res = MessageBox.warning(sys.translate("Los siguientes materiales est�n descatalogados o de baja:%1\n�Desea continuar?").arg(l), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res !=  MessageBox.Yes) {
			return false;
		}
	}
  var curT = new FLSqlCursor("empresa");
  curT.transaction(false);
  try {
    //if (formarticulos.iface.pub_copiarTablaArticulosComp(refProducto, refOrigen, true)) {
  	if (_i.importarFT(refProducto, refOrigen)) {
      curT.commit();
    } else {
      curT.rollback();
      MessageBox.warning(sys.translate("Error al importar la ficha t�cnica del producto %1").arg(refOrigen), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  } catch (e) {
    curT.rollback();
    MessageBox.warning(sys.translate("Error al importar la ficha t�cnica del producto %1: ").arg(refOrigen) + e , MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  sys.setObjText(this, "fdbTipoFabricado", true);
	sys.setObjText(this, "fdbIdTipoProceso", AQUtil.sqlSelect("articulos", "idtipoproceso", "referencia = '" + refProducto + "'"));
	//_i.aplicarPlantillaTamanosFT(refProducto);
	this.child("tdbFichaTecnica").refresh();
}

/*function euromoda_aplicarPlantillaTamanosFT(refProducto)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var idPlantilla = AQUtil.sqlSelect("em_plantillasprod", "idplantilla", "codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "' AND codtamanoem = '" + cursor.valueBuffer("codtamanoem") + "' AND variante = 'DEFAULT'");
	if (!idPlantilla) {
		sys.warnMsgBox(sys.translate("No existe una plantilla para la subfamilia y tama�o del art�culo actual.\nDebe modificar los tama�os del producto copiado de forma manual"));
		return true;
	}
	
	var sCampos = "cantidad, largo, ancho, alto, piezasancho, factor";
	var aCampos = sCampos.split(", ");
	var curAC = new FLSqlCursor("articuloscomp");
	curAC.select("refcompuesto = '" + cursor.valueBuffer("referencia") + "' AND em_codcomponente IS NOT NULL");
	var qryLP = new AQSqlQuery;
	qryLP.setSelect(sCampos);
	qryLP.setFrom("em_lineasplantillaprod");
	var msgLista = [];
	while (curAC.next()) {
		qryLP.setWhere("idplantilla = " + idPlantilla + " AND emcodcomponente = " + curAC.valueBuffer("em_codcomponente"));
		if (qryLP.exec() && qryLP.first()) {
			curAC.setModeAccess(curAC.Edit);
			curAC.refreshBuffer();
			for (var c = 0; c < aCampos.length; c++) {
				curAC.setValueBuffer(aCampos[c], qryLP.value(aCampos[c]));
			}
			if (!curAC.commitBuffer()) {
				return false;
			}
		} else {
			msgLista.push(curAC.valueBuffer("em_codcomponente") + ". " + curAC.valueBuffer("componente"));
		}
	}
	if (msgLista.length > 0) {
		var sLista = "\n" + msgLista.join("\n") + "\n";
		sys.warnMsgBox(sys.translate("No se ha encontrado valores de tama�o en la plantilla para los siguientes componentes:%1Debe modificar sus tama�os de forma manual").arg(sLista));
		return true;
	}
	return true;
}*/

function euromoda_establecerFiltroDibujos()
{
  var cursor = this.cursor();
  var codSubfamilia = cursor.valueBuffer("codsubfamilia");
  this.child("fdbCodDibEstamp").setFilter("coddibujoem IN (SELECT coddibujoem FROM em_dibujossubfam WHERE codsubfamilia = '" + codSubfamilia + "')");
  //this.child("fdbCodDibEstamp").setFilter("tipo = 'Estampado' AND coddibujoem IN (SELECT coddibujoem FROM em_dibujossubfam WHERE codsubfamilia = '" + codSubfamilia + "')");
  //this.child("fdbCodDibJacquard").setFilter("tipo = 'Jacquard' AND coddibujoem IN (SELECT coddibujoem FROM em_dibujossubfam WHERE codsubfamilia = '" + codSubfamilia + "')");
}

function euromoda_establecerFiltroSubfamilia() 
{
  var cursor = this.cursor();
	var filtro = "";
	var codDibujo = cursor.valueBuffer("coddibestamp");
	var codFamilia = cursor.valueBuffer("codfamilia");
	if (codFamilia) {
		filtro = "codfamilia = '" + codFamilia + "'";
	}

	if (codDibujo) {
		filtro += filtro != "" ? " AND " : "";
		filtro += ("codsubfamilia IN (SELECT codsubfamilia FROM em_dibujossubfam WHERE coddibujoem = " + codDibujo + ")");
	}

	if(this.child("fdbCodSubfamilia")){	
		this.child("fdbCodSubfamilia").setFilter(filtro);
	}
}

function euromoda_establecerFiltroTamano()
{
  var cursor = this.cursor();
  var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codDibujo = cursor.valueBuffer("coddibestamp");
	var filtro;
	if (codSubfamilia && codDibujo) {
		filtro = "codtamanoem IN (SELECT codtamanoem FROM em_dibujostamsub WHERE codsubfamilia = '" + codSubfamilia + "' AND coddibujoem = " + codDibujo + ")";
	} else if (codSubfamilia) {
		filtro = "codtamanoem IN (SELECT codtamanoem FROM em_tamanossubfam WHERE codsubfamilia = '" + codSubfamilia + "')";
	} else {
		filtro = "";
	}
	this.child("fdbCodTamanoEm").setFilter(filtro);
}

function euromoda_establecerFiltroColores()
{
  var cursor = this.cursor();
  var codDibujo = cursor.valueBuffer("coddibestamp");
  this.child("fdbCodColorEM").setFilter("codcolorem IN (SELECT codcolorem FROM em_dibujoscolor WHERE coddibujoem = '" + codDibujo + "')");
}

function euromoda_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.validarDibujos()) {
		return false;
	}
	if (!_i.validarTamano()) {
		return false;
	}
	if (!_i.validarEmbalaje()) {
		return false;
	}
	if (!_i.validarColor()) {
		return false;
	}
	if (!_i.ponDatosModificacion()) {
		return false;
	}
	if(!_i.validaPanotCont()) {
		return false;
	}
	if(!flfactalma.iface.controlDatosModCosteProd(cursor)) {
		return false;
	}
	var gridAsociado = "articulos";
	if (cursor.modeAccess() == cursor.Insert) {
		if (flfactalma.iface.hayCambioMargenProd(cursor) || flfactalma.iface.hayCambioCosteProd(cursor)) {				
			cursor.commitBuffer();
			cursor.setModeAccess(cursor.Edit);	
			cursor.refreshBuffer();
			gridAsociado = "articulosNew";
		}
	} 
	if(!_i.ponDatosLogCostes(gridAsociado, cursor)) {
		return false;
	}
	return true;
}

function euromoda_ponDatosModificacion()
{
  var _i = this.iface;
  var cursor = this.cursor();
  if (!cursor.isModifiedBuffer()) {
    return true;
  }
  var hoy = new Date;
  this.child("fdbFechaMod").setValue(hoy);
  this.child("fdbIdUsuarioMod").setValue(sys.nameUser());

  return true;
}

function euromoda_validarTamano()
{
  var cursor = this.cursor();
  var codSubfamilia = cursor.valueBuffer("codsubfamilia");
  var codTamano = cursor.valueBuffer("codtamanoem");
  if (codTamano && codTamano != "") {
    if (!AQUtil.sqlSelect("em_tamanossubfam", "idtamanosubfam", "codtamanoem = '" + codTamano + "' AND codsubfamilia = '" + codSubfamilia + "'")) {
      MessageBox.warning(sys.translate("El tama�o indicado no est� asociado a la subfamilia %1").arg(codSubfamilia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }
  return true;
}

function euromoda_validarEmbalaje()
{
	var _i = this.iface;
  var cursor = this.cursor();
	if (cursor.isNull("em_codtipoemb") && cursor.isNull("unidadesemb")) {
		return true;
	}
  var codEmbalaje = cursor.valueBuffer("em_codtipoemb");
	var unidadesEmb = cursor.valueBuffer("unidadesemb");
  if ((codEmbalaje && codEmbalaje != "" && (cursor.isNull("unidadesemb") || unidadesEmb == 0)) || (unidadesEmb && unidadesEmb != "" && unidadesEmb != 0 && cursor.isNull("em_codtipoemb")))  {
    sys.warnMsgBox(sys.translate("Si establece el tipo de embalaje debe indicar las unidades por embalaje y viceversa"));
		return false;
  }
  return true;
}

function euromoda_validarColor()
{
  var cursor = this.cursor();
  var codDibujo = cursor.valueBuffer("coddibestamp");
	if (!codDibujo) {
		return true;
	}
  var codColor = cursor.valueBuffer("codcolorem");
  if (codColor && codColor != "") {
    if (!AQUtil.sqlSelect("em_dibujoscolor", "iddibujocolor", "codcolorem = '" + codColor + "' AND coddibujoem = '" + codDibujo + "'")) {
      MessageBox.warning(sys.translate("El tipo de color seleccionado no est� asociado al dibujo %1").arg(codDibujo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }
  return true;
}

function euromoda_validarDibujos()
{
  var cursor = this.cursor();
  var codSubfamilia = cursor.valueBuffer("codsubfamilia");
  var codDibujoE = cursor.valueBuffer("coddibestamp");
  //var codDibujoJ = cursor.valueBuffer("coddibjacquard");
  if (codDibujoE && codDibujoE != "") {
    if (!AQUtil.sqlSelect("em_dibujos", "coddibujoem", "coddibujoem = '" + codDibujoE + "' AND coddibujoem IN (SELECT coddibujoem FROM em_dibujossubfam WHERE codsubfamilia = '" + codSubfamilia + "')")) {
      MessageBox.warning(sys.translate("El dibujo no est� asociado a la subfamilia %1").arg(codSubfamilia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }
  /*
  if (codDibujoE && codDibujoE != "") {
    if (!AQUtil.sqlSelect("em_dibujos", "coddibujoem", "coddibujoem = '" + codDibujoE + "' AND tipo = 'Estampado' AND coddibujoem IN (SELECT coddibujoem FROM em_dibujossubfam WHERE codsubfamilia = '" + codSubfamilia + "')")) {
      MessageBox.warning(sys.translate("El dibujo estampado no est� asociado a la subfamilia %1 o no es del tipo correcto").arg(codSubfamilia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }
  if (codDibujoJ && codDibujoJ != "") {
    if (!AQUtil.sqlSelect("em_dibujos", "coddibujoem", "coddibujoem = '" + codDibujoE + "' AND tipo = 'Jacquard' AND coddibujoem IN (SELECT coddibujoem FROM em_dibujossubfam WHERE codsubfamilia = '" + codSubfamilia + "')")) {
      MessageBox.warning(sys.translate("El dibujo jacquard no est� asociado a la subfamilia %1 o no es del tipo correcto").arg(codSubfamilia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }
  */
  return true;
}

function euromoda_iniciarControles()
{

  this.child("gbxAplicableA").close();
  this.child("tbnSiguienteOpcion").close();
  this.child("pbnCalcularPvpComponentes").close();

  var _i = this.iface;
  //_i.establecerFiltroDibujos();
  	_i.establecerValorFamilia();
	_i.establecerFiltroSubfamilia();
  _i.establecerFiltroTamano();
	_i.establecerFiltroColores();

  var cursor = this.cursor();
  switch (cursor.modeAccess()) {
    case cursor.Insert: {
      this.child("fdbIdUsuarioAlta").setValue(sys.nameUser());
      sys.setObjText(this, "fdbCodUnidad", _i.calculateField("codunidad"));
      break;
    }
    case cursor.Edit: {
      _i.controlHabilitacion(this, "fdbTipoArticulo", false);
      this.child("fdbTipoArticulo").setDisabled(true);
      break;
    }
  }
  
  //_i.codFamTCrudo_ = flfactalma.iface.pub_valorDefectoAlmacen("codfamiliacrudo");
  //_i.codFamTEstampado_ = flfactalma.iface.pub_valorDefectoAlmacen("codfamiliaestampado");
  _i.habilitarPorFamilia()
}

function euromoda_establecerColumnas()
{
  var i = 0;
	this.iface.COL_REFERENCIA = i++;
  this.iface.COL_ORDEN = i++;
  this.iface.COL_DESCRIPCION = i++;
  this.iface.COL_CANTIDAD = i++;
  this.iface.COL_TAMANO = i++;
  this.iface.COL_COLOR = i++;
  this.iface.COL_LARGO = i++;
  this.iface.COL_ANCHO = i++;
  this.iface.COL_ALTO = i++;
  this.iface.COL_PANCHO = i++;
  this.iface.COL_FACTOR = i++;
  this.iface.COL_COMPONENTE = i++;
  this.iface.COL_RESERVAR = i++;
}

function euromoda_crearArbolCompuestos()
{
}

function euromoda_crearArbolComponentes()
{
	return;
  var util: FLUtil;

	this.iface.lvwComponentes.setColumnText(0, util.translate("scripts", "Referencia"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Num."));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Descripci�n"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Cantidad"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Tama�o"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Color"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Largo"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Ancho"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Alto"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "P/Ancho"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Factor"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Componente"));
  this.iface.lvwComponentes.addColumn(util.translate("scripts", "Reservar"));

  var referencia = this.child("fdbReferencia").value(); 

  this.iface.lvwComponentes.clear();
  var raiz = new FLListViewItem(this.iface.lvwComponentes);
  var datosNodo = new Array();
  datosNodo["cantidad"] = "";
  datosNodo["descripcion"] = this.child("fdbDescripcion").value();
  datosNodo["codigo"] = referencia;
  datosNodo["unidad"] = this.child("fdbCodUnidad").value();
  datosNodo["id"] = 0;
  datosNodo["tipo"] = "componente";

  datosNodo["orden"] = "";
  datosNodo["largo"] = "";
	datosNodo["ancho"] = "";
  datosNodo["alto"] = "";
  datosNodo["factor"] = "";
  datosNodo["piezasancho"] = "";
  datosNodo["reservar"] = "";
  datosNodo["codcomponente"] = "";
  datosNodo["tamano"] = "";
  datosNodo["color"] = "";

  datosNodo["imagen"] = util.sqlSelect("familias", "imagen", "codfamilia = '" + this.child("fdbCodFamilia").value() + "'");
  this.iface.establecerDatosNodo(raiz, datosNodo);
  raiz.setExpandable(false);
  this.iface.componenteSeleccionado = raiz;
  this.iface.raizComponente = raiz;
  this.iface.pintarNodo(raiz, "componente");
  raiz.setOpen(true);
}

function euromoda_anadirComponente()
{
  var util: FLUtil;

  var referencia = this.child("fdbReferencia").value();

  this.iface.lvwComponentes.clear();
  var raiz = new FLListViewItem(this.iface.lvwComponentes);
  var datosNodo = new Array();
  datosNodo["cantidad"] = "";
  datosNodo["descripcion"] = this.child("fdbDescripcion").value();
  datosNodo["codigo"] = referencia;
  datosNodo["unidad"] = this.child("fdbCodUnidad").value();
  datosNodo["id"] = 0;
  datosNodo["tipo"] = "componente";

  datosNodo["orden"] = "";
	datosNodo["largo"] = "";
  datosNodo["ancho"] = "";
  datosNodo["alto"] = "";
  datosNodo["factor"] = "";
  datosNodo["piezasancho"] = "";
  datosNodo["reservar"] = "";
  datosNodo["codcomponente"] = "";
  datosNodo["tamano"] = "";
  datosNodo["color"] = "";

  datosNodo["imagen"] = util.sqlSelect("familias", "imagen", "codfamilia = '" + this.child("fdbCodFamilia").value() + "'");
  this.iface.establecerDatosNodo(raiz, datosNodo);
  raiz.setExpandable(false);
  this.iface.componenteSeleccionado = raiz;
  this.iface.raizComponente = raiz;
  this.iface.pintarNodo(raiz, "componente");
  raiz.setOpen(true);
}

function euromoda_calcularDatosNodoComponente(referencia, idOpcionArticulo)
{
  var util: FLUtil;
  var datosNodo = new Array;

  var q = new FLSqlQuery();
  q.setTablesList("articuloscomp");
  q.setSelect("ac.id, ac.orden, ac.refcomponente, ac.desccomponente, ac.cantidad, ac.codunidad, ac.largo, ac.ancho, ac.alto, ac.factor, ac.piezasancho, ac.reservar, ac.em_codcomponente, a.codcolorem, t.descripcion");
  q.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia LEFT OUTER JOIN em_tamanos t ON a.codtamanoem = t.codtamanoem");
  q.setWhere("refcompuesto = '" + referencia + "' ORDER BY ac.orden");
  q.setForwardOnly(true);


  if (!q.exec())
    return false;

  var i = 0;
  while (q.next()) {
    datosNodo[i] = new Array;
    datosNodo[i]["id"] = q.value("ac.id");
    datosNodo[i]["tipo"] = "componente";
    datosNodo[i]["codigo"] = this.iface.codigoComponente(q.value("ac.id"), q.value("ac.refcomponente"));
    datosNodo[i]["descripcion"] = q.value("ac.desccomponente");
		datosNodo[i]["orden"] = q.value("ac.orden");
    datosNodo[i]["cantidad"] = q.value("ac.cantidad");
    datosNodo[i]["unidad"] = q.value("ac.codunidad");
    datosNodo[i]["largo"] = q.value("ac.largo");
    datosNodo[i]["ancho"] = q.value("ac.ancho");
    datosNodo[i]["alto"] = q.value("ac.alto");
    datosNodo[i]["factor"] = q.value("ac.factor");
    datosNodo[i]["piezasancho"] = q.value("ac.piezasancho");
    datosNodo[i]["reservar"] = q.value("ac.reservar");
    datosNodo[i]["codcomponente"] = q.value("ac.em_codcomponente");
    datosNodo[i]["tamano"] = q.value("a.destamano");
    datosNodo[i]["color"] = q.value("a.codcolorem");
    datosNodo[i]["imagen"] = this.iface.imagenComponente(q.value("id"), q.value("ac.refcomponente"));
    i += 1;
  }
  return datosNodo;
}

function euromoda_establecerOpcionNodo(nodo, datos)
{
	if (!nodo) {
		return;
	}
  return this.iface.__establecerOpcionNodo(nodo, datos);
}

function euromoda_establecerDatosNodo(nodo, datos)
{
	if (!nodo) {
		return;
	}
  if (datos["tipo"] != "componente") {
    return this.iface.__establecerDatosNodo(nodo, datos);
  }

  var util: FLUtil;
  if (datos["codigo"] && datos["codigo"] != "") {
    nodo.setText(this.iface.COL_REFERENCIA, datos["codigo"]);
    nodo.setPixmap(this.iface.COL_REFERENCIA, datos["imagen"]);
  }
  
  if (datos["orden"] && datos["orden"] != "") {
    nodo.setText(this.iface.COL_ORDEN, datos["orden"]);
  }

  if (datos["descripcion"] && datos["descripcion"] != "")
    nodo.setText(this.iface.COL_DESCRIPCION, datos["descripcion"]);

  if (datos["cantidad"] && datos["cantidad"] != "")
    nodo.setText(this.iface.COL_CANTIDAD, datos["cantidad"]);

  if (datos["ancho"] && datos["ancho"] != "")
    nodo.setText(this.iface.COL_ANCHO, datos["ancho"]);

  if (datos["largo"] && datos["largo"] != "")
    nodo.setText(this.iface.COL_LARGO, datos["largo"]);

  if (datos["alto"] && datos["alto"] != "")
    nodo.setText(this.iface.COL_ALTO, datos["alto"]);

  if (datos["factor"] && datos["factor"] != "")
    nodo.setText(this.iface.COL_FACTOR, datos["factor"]);

  if (datos["piezasancho"] && datos["piezasancho"] != "")
    nodo.setText(this.iface.COL_PANCHO, datos["piezasancho"]);

  if (datos["tamano"] && datos["tamano"] != "")
    nodo.setText(this.iface.COL_TAMANO, datos["tamano"]);

  if (datos["color"] && datos["color"] != "")
    nodo.setText(this.iface.COL_COLOR, datos["color"]);

  if (datos["reservar"] && datos["reservar"] != "")
    nodo.setText(this.iface.COL_RESERVAR, datos["reservar"] ? sys.translate("S�") : sys.translate("No"));

  if (datos["codcomponente"] && datos["codcomponente"] != "")
    nodo.setText(this.iface.COL_COMPONENTE, datos["codcomponente"]);

  if (datos["id"] && datos["id"] != "")
    nodo.setKey(datos["id"]);
}

function euromoda_bufferChanged(fN)
{

  	var _i = this.iface;
  	var cursor = this.cursor();

  	if(fN == "codsubfamilia") {
		if(!this.child("fdbCodSubfamilia")) {				
			return true;
		}	       
		cursor.setValueBuffer("em_tipoarticulo", _i.calculateField("em_tipoarticulo"));
		sys.setObjText(this, "fdbDescripcion", _i.calculateField("descripcion"));
		// sys.setObjText(this, "fdbCodTipoEmb", _i.calculateField("em_codtipoemb"));
		_i.establecerFiltroTamano();
		//       _i.establecerFiltroDibujos();
		_i.__bufferChanged(fN);
    }else if(fN == "codtamanoem"){
		// sys.setObjText(this, "fdbCodTipoEmb", _i.calculateField("em_codtipoemb"));

	}else if(fN == "coddibestamp"){
        sys.setObjText(this, "fdbDescripcion", _i.calculateField("descripcion"));
     
        sys.setObjText(this, "fdbPanotCont", _i.calculateField("panotcont"));
		_i.establecerFiltroColores();
		_i.establecerFiltroSubfamilia();
		_i.establecerFiltroTamano();		
	}else if(fN == "descatalogado"){
		this.child("fdbIdUsuarioDes").setValue(_i.calculateField("idusuariodes"));
		this.child("fdbFechaDes").setValue(_i.calculateField("fechades"));
		
	}else if(fN == "debaja"){
		this.child("fdbIdUsuarioBaja").setValue(_i.calculateField("idusuariobaja"));
		this.child("fdbFechaBaja").setValue(_i.calculateField("fechabaja"));
	}else if(fN == "codfamilia"){
		/*if (flfactalma.iface.pub_esFamiliaCrudo(cursor.valueBuffer("codfamilia")) || flfactalma.iface.pub_esFamiliaEstampado(cursor.valueBuffer("codfamilia"))) {
		  cursor.setValueBuffer("tipostock", "Lotes");
		}*/ 
		if(!this.child("fdbCodFamilia")) {
			return true;
		}
		_i.establecerFiltroSubfamilia();
		_i.habilitarPorFamilia();
		sys.setObjText(this, "fdbCodUnidad", _i.calculateField("codunidad")); //05-06-2018
		cursor.setValueBuffer("tipostock", _i.calculateField("tipostock"));
		sys.setObjText(this, "fdbImpuesto", _i.calculateField("codimpuesto"));
		sys.setObjText(this, "fdbCodGrupoContablePro", _i.calculateField("codgrupocontablepro"));
		sys.setObjText(this, "fdbCodGrupoContableExi", _i.calculateField("codgrupocontableexi"));
		sys.setObjText(this, "fdbDescripcion", _i.calculateField("descripcion"));
		
	}else if(fN == "em_tipoarticulo"){
        sys.setObjText(this, "fdbCodUnidad", _i.calculateField("codunidad"));
		sys.setObjText(this, "fdbSeCompra", _i.calculateField("secompra"));		
	}else if(fN == "fabricado"){
		if (cursor.valueBuffer("fabricado")) {
			cursor.setValueBuffer("tipostock", "Lotes");
			this.child("fdbDiasProdEnvio").setDisabled(false);
			this.child("fdbIdTipoProceso").setDisabled(false);
		} else {
			/*this.child("fdbDiasProdEnvio").setValue(0);
			this.child("fdbIdTipoProceso").setValue("");
			this.child("fdbDiasProdEnvio").setDisabled(true);
			this.child("fdbIdTipoProceso").setDisabled(true);*/
		}		
	}else if(fN == "em_controlvalmercado"){
		if(cursor.valueBuffer("em_controlvalmercado")){				
	  		this.child("tbwArticulo").setTabEnabled("em_valoresmercadoprin", true);
	  		sys.runObjMethod(this, "tdbEmValoresMercado", "setOnlyTable", true);
	  	}else {
	  		this.child("tbwArticulo").setTabEnabled("em_valoresmercadoprin", false);
	  	}		
	}else if(fN == "em_tipocoste"){

		_i.habilitaCamposCostesProd(this, cursor);
		_i.pulsaHeredar_ = false;
		
	}else if(fN == "em_tipomargen"){
		_i.habilitaCamposCostesProd(this, cursor);
		_i.pulsaHeredar_ = false;
		
	}else {
	     _i.__bufferChanged(fN)		
	}
}

function euromoda_habilitarPorFamilia()
{
  var _i = this.iface;
  var cursor = this.cursor();
  if (cursor.valueBuffer("codfamilia") == _i.codFamTCrudo_ || cursor.valueBuffer("codfamilia") == _i.codFamTEstampado_) {
    sys.disableObj(this, "fdbTipoStock");
  } else {
		if (this.child("fdbTipoStock")) 
			this.child("fdbTipoStock").setDisabled(false);
  }
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	if(fN == "descripcion") {
		if (cursor.modeAccess() != cursor.Insert) {
			valor = cursor.valueBuffer("descripcion");
		} else {
			valor = _i.calculaDescripcion(cursor)
		}
    }else if(fN == "codunidad"){
  		var codFamilia = cursor.valueBuffer("codfamilia");
  		if(codFamilia && codFamilia != "") {
  			valor = AQUtil.sqlSelect("familias","codunidad","codfamilia = '" + codFamilia + "'");		  			
  		}
  		if(!valor || valor == "") {
  			if(cursor.valueBuffer("em_tipoarticulo") == "M.Prima") {	      	
	        	valor = "M1";	        
	        }else {
		        valor = "Un";	        	
	        }		       			
  		}	 
    	
    }else if(fN == "em_tipoarticulo"){
	    valor = AQUtil.sqlSelect("subfamilias", "em_tipoarticulo", "codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
    }else if(fN == "idusuariodes"){
	    valor = cursor.valueBuffer("descatalogado") ? sys.nameUser() : "";    	
    }else if(fN == "fechades"){
	    valor = cursor.valueBuffer("descatalogado") ? new Date : "NULL";    	
    }else if(fN == "idusuariobaja"){
	    valor = cursor.valueBuffer("debaja") ? sys.nameUser() : "";    	
    }else if(fN == "fechabaja"){
	    valor = cursor.valueBuffer("debaja") ? new Date : "NULL";    	
    }else if(fN == "em_codtipoemb"){
		valor = AQUtil.sqlSelect("em_tamanossubfam", "em_codtipoemb", "codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "' AND codtamanoem = '" + cursor.valueBuffer("codtamanoem") + "'");
		valor = valor ? valor : "";    	
    }else if(fN == "codimpuesto"){
		valor = AQUtil.sqlSelect("familias", "codimpuesto", "codfamilia = '" + cursor.valueBuffer("codfamilia") + "'");
		valor = valor ? valor : "";    	
    }else if(fN == "codgrupocontablepro"){
		valor = AQUtil.sqlSelect("familias", "codgrupocontablepro", "codfamilia = '" + cursor.valueBuffer("codfamilia") + "'");
		valor = valor ? valor : "";   	
    }else if(fN == "codgrupocontableexi") {
		valor = AQUtil.sqlSelect("familias", "codgrupocontableexi", "codfamilia = '" + cursor.valueBuffer("codfamilia") + "'");
		valor = valor ? valor : "";    	
    }else if(fN == "secompra"){
		valor = (cursor.valueBuffer("em_tipoarticulo") == "M.Prima");    	
    }else if(fN == "tipostock"){
		var codSubfamilia = cursor.valueBuffer("codsubfamilia");
		var codFamilia = cursor.valueBuffer("codfamilia");
		if (flfactalma.iface.pub_esSubfamiliaCrudo(codSubfamilia) || flfactalma.iface.pub_esSubfamiliaEstampado(codSubfamilia)) {
			valor = "Lotes";
		} else if (flfactalma.iface.pub_esFamiliaCrudo(codFamilia) || flfactalma.iface.pub_esFamiliaEstampado(codFamilia)) {
			valor = "Lotes";
		} else if (cursor.valueBuffer("fabricado")) {
			valor = "Lotes";
		} else {
			valor = "Granel";
		}    	
    }else if(fN == "panotcont"){
    	valor = AQUtil.sqlSelect("em_dibujos", "panotcont", "coddibujoem = '" + cursor.valueBuffer("coddibestamp") + "'");
    }else if(fN == "em_fechaultventa"){
    	valor = AQUtil.sqlSelect("lineasalbaranescli la INNER JOIN albaranescli a ON la.idalbaran = a.idalbaran", "a.fecha", "la.referencia = '" + cursor.valueBuffer("referencia") + "' AND la.pvpunitario > 0 AND la.cantidad > 0 ORDER BY a.fecha DESC, a.idalbaran DESC", "lineasalbaranescli,albaranescli");
    }else if(fN == "em_fechaultcompra"){
    	valor = AQUtil.sqlSelect("lineasalbaranesprov la INNER JOIN albaranesprov a ON la.idalbaran = a.idalbaran", "a.fecha", "la.referencia = '" + cursor.valueBuffer("referencia") + "' AND la.pvpunitario > 0 AND la.cantidad > 0 ORDER BY a.fecha DESC, a.idalbaran DESC", "lineasalbaranesprov,albaranesprov");
    }else{
    	valor = _i.__commonCalculateField(fN, cursor);
    }

	return valor;
}

function euromoda_calculaDescripcion(cursor)
{
	var _i = this.iface;
	var valor;
	
	var desDibujo = AQUtil.sqlSelect("em_dibujos", "descripcion", "coddibujoem = '" + cursor.valueBuffer("coddibestamp") + "'");
	desDibujo = desDibujo ? desDibujo : "";
	var desSubfamilia = AQUtil.sqlSelect("subfamilias", "descripcion", "codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
	desSubfamilia = desSubfamilia ? desSubfamilia : "";
	var codFamilia = cursor.valueBuffer("codfamilia");
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	if (flfactalma.iface.pub_esSubfamiliaEstampado(codSubfamilia)) {
		valor = desDibujo + " " + desSubfamilia;
	} else if (flfactalma.iface.pub_esFamiliaEstampado(codFamilia)) {
		valor = desDibujo + " " + desSubfamilia;
	} else {
		valor = desSubfamilia + " " + desDibujo;
	}
	return valor;
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
		case "descripcion":
		case "codunidad":
	    case "em_tipoarticulo":
	    case "idusuariodes":
	    case "fechades":
	    case "idusuariobaja":
	    case "fechabaja":
	    case "em_codtipoemb":
	    case "codimpuesto":
		case "codgrupocontablepro":
		case "codgrupocontableexi":
		case "secompra":
		case "panotcont": 
		case "em_fechaultventa":
		case "em_fechaultcompra": {
			valor = _i.commonCalculateField(fN, cursor);
			break;
		}
		default: {
      valor = _i.__calculateField(fN)
    }
  }
	return valor;
}

function euromoda_controlHabilitacion(miForm, miControl, habilitado)
{
  var c = miForm.child(miControl);
  if (!c || c == undefined) {
    return;
  } 
}

function euromoda_refrescarNodos()
{
  var _i = this.iface;
  this.child("fdbIdUsuarioFichaT").setValue(sys.nameUser());
  this.child("fdbFechaFichaT").setValue(new Date);
  _i.__refrescarNodos();
}


function euromoda_validarTareaProduccion():Boolean
{
	return true;
}

function euromoda_tbnStockComponente_clicked()
{
	var codAlmacen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
	var curS = new FLSqlCursor("stocks");
	var curAC = this.child("tdbFichaTecnica").cursor();
	var refComponente = curAC.valueBuffer("refcomponente");
	curS.select("referencia = '" + refComponente + "' AND codalmacen = '" + codAlmacen + "'");
	if (curS.first()) {
		curS.editRecord();
	} else {
		sys.warnMsgBox(sys.translate("No hay stock registrado para el art�culo %1 en el almac�n %2").arg(refComponente).arg(codAlmacen));
	}
}

function euromoda_genCodBar(fN)
{
	return;
}
function euromoda_validaPanotCont()
{
	var cursor = this.cursor();
	if (cursor.valueBuffer("panotcont") == " ") {
		cursor.setNull("panotcont");
	}
	return true;
}

function euromoda_importarFT(refProducto, refOrigen)
{
	if (!formarticulos.iface.pub_copiarTablaArticulosComp(refProducto, refOrigen, true)) {
	
		return false;
	}

	if(!formarticulos.iface.copiarTablaAcabadosArt(refProducto, refOrigen)) {
		
		return false;
	}
	return true;
}

function euromoda_tbnGenerarFT_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(!_i.generarFT(cursor)) {
		return false;
	} 
	this.child("tdbFichaTecnica").refresh();	
	return true;

}

function euromoda_generarFT(cursor)
{
	var usuario = sys.nameUser();
	var hoy = new Date();
	var _i = this.iface;
	if(!_i.compruebaFT(cursor)) {
		return false;
	}	
	_i.oResGFT_ = new Object;
	_i.oResGFT_.resultado = "";
	_i.oResGFT_.listaMotivos= [];
	var oParamGenFT = _i.generadorFTV1(cursor);
	cursor.setValueBuffer("em_situaciongenft","EN REVISI�N");	

	var resultado = oParamGenFT.resultado;
	var listaMotivos = "";

	for(var i=0; i<oParamGenFT.listaMotivos.length; i++) {
		if(i==0) {
			listaMotivos = oParamGenFT.listaMotivos[i];			
		} else {
			listaMotivos += "\n" + oParamGenFT.listaMotivos[i]; 			
		}
				
	}
	if(!listaMotivos || listaMotivos == "") {
		listaMotivos = "TODOS ENCONTRADOS";
	} else {
		resultado = "REVISAR";
	}
	cursor.setValueBuffer("em_resultadogenft",resultado);
	cursor.setValueBuffer("em_motivogenft",listaMotivos)
	cursor.setValueBuffer("idtipoproceso",_i.dameTipoProceso(cursor));
	cursor.setValueBuffer("idusuariofichat",usuario);
	cursor.setValueBuffer("fechafichat",hoy);
	_i.calculaFactoresFT(cursor, true);
	return true;
}

function euromoda_dameTipoProceso(cursor)
{
	var _i = this.iface;
	var idTipoProceso = AQUtil.sqlSelect("subfamilias","idtipoproceso","codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
	if(!idTipoProceso) {
		idTipoProceso = "";
	}
	return idTipoProceso;
}

function euromoda_compruebaFT(cursor)
{
	var _i = this.iface;
	
	var existeFT = AQUtil.sqlSelect("articuloscomp","count(*)","refcompuesto = '" + cursor.valueBuffer("referencia") + "'");
	
	if(existeFT && existeFT>0) {
		var res = flfactppal.iface.preguntaMsg(sys.translate("La ficha t�cnica de la referencia %1 tiene informaci�n �desea borrar estos datos y continuar?").arg(cursor.valueBuffer("referencia")),"info",this,MessageBox.Yes, MessageBox.No);  
  		if (res != MessageBox.Yes) {
			return false;
  		}
  		if(!_i.borrarFT(cursor.valueBuffer("referencia"))) {
  			return false;
  		}
	}
	return true;
}

function euromoda_borrarFT(referencia)
{
	var _i = this.iface;
	if(!AQUtil.sqlDelete("articuloscomp","refcompuesto = '" + referencia + "'")) {
		return false;
	}
	return true;
} 

function euromoda_generadorFTV1(cursor)
{
	
	var _i = this.iface;
	var esColPlan = false;
	
	_i.oResGFT_.resultado = "OK";
	_i.oResGFT_.listaMotivos= [];


	var coleccion = cursor.valueBuffer("codcoleccionem");
	var coleccionBPL = coleccion;
	var coleccionPlan = AQUtil.sqlSelect("em_colecciones","codcoleccionplan","codcoleccionem = '" + coleccion + "'");
	if(coleccionPlan && coleccionPlan != "") {
		coleccionBPL = coleccionPlan;	
		//en este caso entra en juego el #EUR #H1139 #P0027 Mejora al proceso de generaci�n de ficha t�cnica v01
		//buscamos si el componente fijo a crear tiene un componente sustitutivo en la tabla Sustituci�n de componentes fijos de la colecci�n del producto a crear
		esColPlan = true;
	}

	var oParamBP = new Object;
	oParamBP.coleccionBPL = coleccionBPL
	oParamBP.subFamilia = cursor.valueBuffer("codsubfamilia");
	oParamBP.tamanio = cursor.valueBuffer("codtamanoem");
	oParamBP.color = cursor.valueBuffer("codcolorem");

	var idPlantilla = _i.buscarPlantilla(oParamBP);
	
	if(idPlantilla.toString() == "Err:0") {
		_i.oResGFT_.resultado = "REVISAR";
		_i.oResGFT_.listaMotivos = ["No se han encontrado plantillas para el producto"];
		return _i.oResGFT_;
	} else if(idPlantilla.toString().left(4) == "Err:") {
		_i.oResGFT_.resultado = "REVISAR";
		_i.oResGFT_.listaMotivos= ["Hay " + idPlantilla.right(idPlantilla.length-4) + " plantillas para elegir con la misma colecci�n, subfamilia, tama�o y color"];	
		return _i.oResGFT_;
	} else {

		var numLineas = AQUtil.sqlSelect("em_lineasplantillaprod","count(*)", "idplantilla = " + idPlantilla);
		if(!numLineas || numLineas == 0) {
			_i.oResGFT_.resultado = "REVISAR";
			_i.oResGFT_.listaMotivos= ["No se han encontrado l�neas en la plantilla encontrada para el producto"];
			return _i.oResGFT_;
		} 
	}

	
	var curLinea = new FLSqlCursor("em_lineasplantillaprod");
	curLinea.select("idplantilla = " + idPlantilla + " ORDER BY orden");
	while (curLinea.next()) {
		curLinea.setModeAccess(curLinea.Browse);
		curLinea.refreshBuffer();
		if (!_i.copiaLinea(cursor,curLinea,esColPlan,coleccion)) {
			return _i.oResGFT_;
		}
	}
	return _i.oResGFT_;
}

function euromoda_copiaLinea(cursor,curLinea, esColPlan, coleccion)
{
	var _i = this.iface;	
  	if (!_i.curLineaFT_) {
    	_i.curLineaFT_ = new FLSqlCursor("articuloscomp");
  	}
  	_i.curLineaFT_.setModeAccess(_i.curLineaFT_.Insert);
  	_i.curLineaFT_.refreshBuffer(); 

  	var aCamposLinea = AQUtil.nombreCampos("articuloscomp");
  	var totalCampos = aCamposLinea[0];

  	var campoInformado = [];
  	for (var i = 1; i <= totalCampos; i++) {
    	campoInformado[aCamposLinea[i]] = false;
  	}

  	if(curLinea.valueBuffer("tipo") == "Variable") {		
  		campoInformado["refcomponente"] = true;
  		campoInformado["desccomponente"] = true;
  		campoInformado["codtamanoem"] = true;

		_i.buscaRefCandidatas(curLinea, cursor);

		var codTamanio = _i.oResGFT_.codTamanio;			
		var refComponente = _i.oResGFT_.refCandidata;
		var desComponente = "";
		var color = "";	
		var codDibujoBus = curLinea.valueBuffer("dibujo");
		
		if(refComponente && refComponente != "") {

			var q = new AQSqlQuery;	
			q.setSelect("descripcion, codcolorem");
			q.setFrom("articulos");
			q.setWhere("referencia = '" + refComponente + "'");						
			if (!q.exec()){
				return;
			}  
			if(q.first())
			{
				descComponente = q.value("descripcion");
				color = q.value("codcolorem");		
			}				
			//descComponente = AQUtil.sqlSelect("articulos","descripcion","referencia = '" + refComponente + "'");
			_i.curLineaFT_.setValueBuffer("refcomponente",refComponente); 
			_i.curLineaFT_.setValueBuffer("desccomponente",descComponente); 
			if(codDibujoBus == "Coordinado") {							
				_i.curLineaFT_.setValueBuffer("codcolorem",color);
				campoInformado["codcolorem"] = true;
			}
			
		} else {
			_i.curLineaFT_.setNull("refcomponente");
			_i.curLineaFT_.setNull("desccomponente");
		}

		if(codTamanio && codTamanio != "") {
			_i.curLineaFT_.setValueBuffer("codtamanoem",codTamanio); 
		} else {
			_i.curLineaFT_.setNull("codtamanoem");
		}		
		
	} else {
		
		if(esColPlan) {
			var cambiaRef = false;
			var cambiaCant = false;

			var refCompoFijo = curLinea.valueBuffer("refcomponente");
			var cantidadFijo = curLinea.valueBuffer("cantidad"); 
			var codColeccionEM = curLinea.valueBuffer("codcoleccionplan"); 
			var codSubfamiliaPlan = curLinea.valueBuffer("codsufamiliaplan"); 
			var codTamanoPlan = curLinea.valueBuffer("codtamanoplan"); 
			var codColorPlan = curLinea.valueBuffer("codcolorplan");  

			var cantSust;
			var cantNueva;
			var referenciaNueva;
			var descripcionNueva; 


			var q = new AQSqlQuery;	

			q.setSelect("sust.referencianueva,sust.cantsust,sust.cantnueva,sust.descripcionnueva");
			q.setFrom("em_sustcompocol sust INNER JOIN  em_colecciones col ON col.codcoleccionem = sust.codcoleccionem");
			q.setWhere("sust.referenciasust = '" + refCompoFijo + "' and col.codcoleccionplan = '" + codColeccionEM + "' and sust.codcoleccionem = '" + coleccion + "' and sust.cantsust = " + cantidadFijo + " and sust.cantnueva <> 0");

			
			if (!q.exec()){
				return;
			}  
			if(q.first())
			{
				cantSust = q.value("sust.cantsust");
				cantNueva = q.value("sust.cantnueva");
				referenciaNueva = q.value("sust.referencianueva");
				descripcionNueva = q.value("sust.descripcionnueva"); 


				cambiaRef = true;	
				cambiaCant = true;

			} else {
				var q2 = new AQSqlQuery;	
				q2.setSelect("sust.referencianueva,sust.cantsust,sust.cantnueva,sust.descripcionnueva");
				q2.setFrom("em_sustcompocol sust INNER JOIN  em_colecciones col ON col.codcoleccionem = sust.codcoleccionem");
				q2.setWhere("sust.referenciasust = '" + refCompoFijo + "' and col.codcoleccionplan = '" + codColeccionEM + "' and sust.codcoleccionem = '" + coleccion + "' and (sust.cantsust is null or sust.cantsust = 0) and sust.cantnueva <> 0");
				
				if (!q2.exec()){
					return;
				}  
				if(q2.first())
				{
					cantSust = q2.value("sust.cantsust");
					cantNueva = q2.value("sust.cantnueva");
					referenciaNueva = q2.value("sust.referencianueva");
					descripcionNueva = q2.value("sust.descripcionnueva"); 
					cambiaRef = true;	
					cambiaCant = true;

				
				} else {

					var q3 = new AQSqlQuery;	
					q3.setSelect("sust.referencianueva,sust.cantsust,sust.cantnueva,sust.descripcionnueva");
					q3.setFrom("em_sustcompocol sust INNER JOIN  em_colecciones col ON col.codcoleccionem = sust.codcoleccionem");
					q3.setWhere("sust.referenciasust = '" + refCompoFijo + "' and col.codcoleccionplan = '" + codColeccionEM + "' and sust.codcoleccionem = '" + coleccion + "' and (sust.cantsust is null or sust.cantsust = 0) and (sust.cantnueva is null or sust.cantnueva = 0)");
				
					if (!q3.exec()){
						return;
					}  
					if(q3.first())
					{
						cantSust = q3.value("sust.cantsust");
						cantNueva = q3.value("sust.cantnueva");
						referenciaNueva = q3.value("sust.referencianueva");
						descripcionNueva = q3.value("sust.descripcionnueva"); 
						cambiaRef = true;	
						cambiaCant = false;
					}
				}
			}
			if(cambiaRef) {
				campoInformado["refcomponente"] = true;
  				campoInformado["desccomponente"] = true;	
  				campoInformado["codsubfamilia"] = true;
  				campoInformado["codtamanoem"] = true;	
  				campoInformado["codcolorem"] = true;
  				campoInformado["codunidad"] = true;	

  				var qArt = new AQSqlQuery;	
				qArt.setSelect("codsubfamilia,codtamanoem,codcolorem,codunidad");
				qArt.setFrom("articulos");
				qArt.setWhere("referencia = '" + referenciaNueva + "'");
									
				if (!qArt.exec()){
					return;
				}  
				if(!qArt.first())
				{
					return false;
				}
				var codSubfamilia = qArt.value("codsubfamilia");
				var codTamano = qArt.value("codtamanoem"); 
				var codColor = qArt.value("codcolorem"); 
				var codUnidad = qArt.value("codunidad");

  				_i.curLineaFT_.setValueBuffer("refcomponente",referenciaNueva); 
				_i.curLineaFT_.setValueBuffer("desccomponente",descripcionNueva);                                                        
				_i.curLineaFT_.setValueBuffer("codsubfamilia",codSubfamilia);
				_i.curLineaFT_.setValueBuffer("codtamanoem",codTamano); 
				_i.curLineaFT_.setValueBuffer("codcolorem",codColor); 
				_i.curLineaFT_.setValueBuffer("codunidad",codUnidad); 	

			}
			if(cambiaCant) {
				campoInformado["cantidad"] = true;
				_i.curLineaFT_.setValueBuffer("cantidad",parseFloat(cantNueva));
			}					
		} else {

			_i.curLineaFT_.setValueBuffer("refcomponente",curLinea.valueBuffer("refcomponente")); 
			_i.curLineaFT_.setValueBuffer("desccomponente",curLinea.valueBuffer("desccomponente")); 
			_i.curLineaFT_.setValueBuffer("cantidad",curLinea.valueBuffer("cantidad"));
		}
	}
	
  	for (var i = 1; i <= totalCampos; i++) {
    	if (!_i.copiaCampoLinea(aCamposLinea[i], curLinea, campoInformado, cursor)) {
      		return false;
    	}
  	}

	if (!_i.curLineaFT_.commitBuffer()) {
		return false;
	}

	return _i.curLineaFT_.valueBuffer("id");
}	

function euromoda_copiaCampoLinea(nombreCampo, curLinea, campoInformado, cursor)
{
	var valor;
	var _i = this.iface;
	var referencia = cursor.valueBuffer("referencia");
	if (campoInformado[nombreCampo]) {
		return true;
	}
	var nulo = false;

	switch (nombreCampo) {		
		case "id": 		
		case "idtipoopcionart":
		case "idopcionarticulo":
		case "idtipotareapro":
		case "diasantelacion":
		case "codfamiliacomponente":
		case "idgit":
		case "ftenlft": {
			return true;
			break;
		}
		case "refcompuesto": {
			valor = referencia;
			break;
		}
		case "refcomponente": {
			if(curLinea.valueBuffer("tipo") == "Fijo") {
				valor = curLinea.valueBuffer(nombreCampo);
			}
			break;
		}
		case "desccomponente": {
			if(curLinea.valueBuffer("tipo") == "Fijo") {
				valor = curLinea.valueBuffer(nombreCampo);
			}
			break;
		}
		case "codcolorem": {
			if(curLinea.valueBuffer("tipo") == "Fijo" || (curLinea.valueBuffer("tipo") == "Variable" && curLinea.valueBuffer("dibujo") != "Coordinado")) {
				valor = curLinea.valueBuffer(nombreCampo);
			} 			
			break;
		}
		case "codtamanoem": {
			if(curLinea.valueBuffer("tipo") == "Fijo") {
				valor = curLinea.valueBuffer("codtamanocont");
			} 
			break;
		}
		case "em_codcomponente": {
			if(curLinea.isNull("emcodcomponente")) {
				nulo = true;
			} else {
				valor = curLinea.valueBuffer("emcodcomponente");	
			}	
			break;		
		}
		default: {
			if (curLinea.isNull(nombreCampo)) {
				nulo = true;
			} else {
				valor = curLinea.valueBuffer(nombreCampo);
			}
		}
	}
	if (nulo) {
		_i.curLineaFT_.setNull(nombreCampo);
	} else {		
		_i.curLineaFT_.setValueBuffer(nombreCampo, valor);
	}
	campoInformado[nombreCampo] = true;

	return true;
}

function euromoda_pbnEnRevision_clicked()
{	
	var _i = this.iface;
	var cursor = this.cursor();
	_i.ponEnRevision(cursor);
	cursor.setValueBuffer("tipostock",formRecordarticulos.iface.commonCalculateField("tipostock", cursor));	
}

function euromoda_pbnEnProduccion_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.ponEnProduccion(cursor);	
	cursor.setValueBuffer("tipostock",formRecordarticulos.iface.commonCalculateField("tipostock", cursor));	
}

function euromoda_ponEnRevision(cursor)
{
	cursor.setValueBuffer("fabricado",false);
	cursor.setValueBuffer("em_situaciongenft","EN REVISI�N");    		
}

function euromoda_ponEnProduccion(cursor)
{
	var _i = this.iface;
	/*Al marcar EN PRODUCCION (est� en varias pantallas):
                si est� informado FT.Proceso
                               habilita la FT (check) y marca "en produccion"
                si FT.PROCESO no est� informado,
                               vamos a la subfamilia de la prenda,
                               si est� informado
                                               lo asigna a la FT
                                               habilita la FT (check) y marca "en produccion"
                                si proceso alli no est� informado
                                               emite aviso: la subfamilia XXX no tiene proceso de produccion informado
                                               deshabilita la FT (check)
                                               marca la FT. EN REVISION*/


    var idTipoProceso = cursor.valueBuffer("idtipoproceso");
    if(idTipoProceso && idTipoProceso != "") {
    	cursor.setValueBuffer("fabricado",true);
    	cursor.setValueBuffer("em_situaciongenft","EN PRODUCCI�N");
    } else {
    	var idTipoProceso = _i.dameTipoProceso(cursor);
    	if(idTipoProceso && idTipoProceso != "") {
    		cursor.setValueBuffer("idtipoproceso",idTipoProceso);
    		cursor.setValueBuffer("fabricado",true);
    		cursor.setValueBuffer("em_situaciongenft","EN PRODUCCI�N");
    	} else {
    		flfactppal.iface.ponMsgError(sys.translate("La subfamilia %1 no tiene proceso de producci�n informado").arg(cursor.valueBuffer("codsubfamilia")),"warn",this);
    		cursor.setValueBuffer("fabricado",false);
    		cursor.setValueBuffer("em_situaciongenft","EN REVISI�N");
    	}
    }                                           
	
}

/*function euromoda_buscarPlantilla(oParamBP)
{
	var _i = this.iface;
	var retorno = "";
	var coleccion = oParamBP.coleccion;
	var coleccionBPL = coleccion;
	var coleccionPlan = AQUtil.sqlSelect("em_colecciones","codcoleccionplan","codcoleccionem = '" + coleccion + "'");
	if(coleccionPlan && coleccionPlan != "") {
		coleccionBPL = coleccionPlan;	
		//en este caso entra en juego el #EUR #H1139 #P0027 Mejora al proceso de generaci�n de ficha t�cnica v01
		//buscamos si el componente fijo a crear tiene un componente sustitutivo en la tabla Sustituci�n de componentes fijos de la colecci�n del producto a crear
	}

	var idPlantilla = AQUtil.sqlSelect("em_plantillasprod","count(*)","codcoleccionem = '" + coleccionBPL + "' AND codsubfamilia = '" + oParamBP.subFamilia + "' AND codtamanoem = '" + oParamBP.tamanio + "' AND codcolorem = '" + oParamBP.color + "'");


	var q = new AQSqlQuery;	
	q.setSelect("idplantilla");
	q.setFrom("em_plantillasprod");
	q.setWhere("codcoleccionem = '" + coleccionBPL + "' AND codsubfamilia = '" + oParamBP.subFamilia + "' AND codtamanoem = '" + oParamBP.tamanio + "' AND codcolorem = '" + oParamBP.color + "'");
	if (!q.exec()){
		return;
	}  
	var numReg = q.size();

	if(!numReg || numReg == 0) {
		retorno = "Err:0";
	} else if(numReg >1) {
		retorno = "Err:"+numReg;
	} else {
		if(q.first()) {
			retorno = q.value("idplantilla");	
		}
		
	}

	return retorno;
}*/

function euromoda_buscarPlantilla(oParamBP)
{
	var _i = this.iface;
	var retorno = "";
	var idPlantilla = AQUtil.sqlSelect("em_plantillasprod","count(*)","codcoleccionem = '" + oParamBP.coleccionBPL + "' AND codsubfamilia = '" + oParamBP.subFamilia + "' AND codtamanoem = '" + oParamBP.tamanio + "' AND codcolorem = '" + oParamBP.color + "'");


	var q = new AQSqlQuery;	
	q.setSelect("idplantilla");
	q.setFrom("em_plantillasprod");
	q.setWhere("codcoleccionem = '" + oParamBP.coleccionBPL + "' AND codsubfamilia = '" + oParamBP.subFamilia + "' AND codtamanoem = '" + oParamBP.tamanio + "' AND codcolorem = '" + oParamBP.color + "'");
	if (!q.exec()){
		return;
	}  
	var numReg = q.size();

	if(!numReg || numReg == 0) {
		retorno = "Err:0";
	} else if(numReg >1) {
		retorno = "Err:"+numReg;
	} else {
		if(q.first()) {
			retorno = q.value("idplantilla");	
		}
		
	}

	return retorno;
}

function euromoda_buscaRefCandidatas(curLinea, cursor)
{
	var _i = this.iface;

	_i.oResGFT_.refCandidata = "";
	_i.oResGFT_.codTamanio = "";
	var codDibujoPR = cursor.valueBuffer("coddibestamp");
	var codDibujoBus = curLinea.valueBuffer("dibujo");
	var orden = curLinea.valueBuffer("orden");
	if(codDibujoBus == "Principal") {
		var codTamanio = _i.elegirTamaRefCan(codDibujoPR, curLinea);
		if(!codTamanio) {	
			_i.oResGFT_.resultado = "REVISAR";
			_i.oResGFT_.listaMotivos.push("El dibujo " + codDibujoPR + " no tiene informado si es pano o continuo y no es posible elegir el tama�o adecuado en la linea " + curLinea.valueBuffer("orden") + " de la plantilla");	
		} else {
			_i.oResGFT_.codTamanio = codTamanio; 
			var refCandidata = _i.dameRefCandidata(codTamanio,curLinea, cursor);
			if(refCandidata.toString() == "Err:0") {
				_i.oResGFT_.resultado = "REVISAR";
				_i.oResGFT_.listaMotivos.push("No se ha encontrado referencia candidata para la l�nea " + orden + " de la plantilla");
				
			} else if(refCandidata.toString().left(4) == "Err:") {
				_i.oResGFT_.resultado = "REVISAR";
				_i.oResGFT_.listaMotivos.push("Hay " + refCandidata.right(refCandidata.length-4) + " referencias candidatas para seleccionar con la misma colecci�n, subfamilia, tama�o y color para la l�nea " + orden);	
				
			} else {
				if(refCandidata && refCandidata != "") {
					_i.oResGFT_.resultado = "OK";	
					_i.oResGFT_.refCandidata = refCandidata;
				}				
			}
		}
	} else if (codDibujoBus == "Coordinado") {

		//Si el Dibujo para la b�squeda de la l�nea de plantilla es Coordinado, buscamos el Dibujo y Color coordinado en la tabla Coordinados por dibujo para el dibujo de la prenda con los siguientes criterios:

		var codcolorPR = cursor.valueBuffer("codcolorem");
		var coleccionPR = cursor.valueBuffer("codcoleccionem");
		var codFamiliaPR = cursor.valueBuffer("codfamilia");
		var codSubfamiliaPR = cursor.valueBuffer("codsubfamilia");
		var codTamanoPR = cursor.valueBuffer("codtamanoem");
		var compoNormalLPL = curLinea.valueBuffer("componormal");

		var q = new AQSqlQuery;	
		//q.setSelect("codcoord, colorcoord");
		q.setSelect("codcoord, colorcoord,coddibujoem,colordib,codcoleccion,codfamilia,codsubfamilia,componormal,codtamanoem");
		q.setFrom("em_coordinados");
		q.setWhere("coddibujoem = '" + codDibujoPR + "' AND (colordib = '" + codcolorPR + "' OR colordib IS NULL) AND (codcoleccion = '" + coleccionPR + "' OR codcoleccion IS NULL) AND (codfamilia = '" + codFamiliaPR + "' OR codfamilia IS NULL) AND (codsubfamilia = '" + codSubfamiliaPR + "' OR codsubfamilia IS NULL) AND (componormal = '" + compoNormalLPL + "' OR componormal IS NULL) AND (codtamanoem = '" + codTamanoPR + "' OR codtamanoem IS NULL)");		
		
		if (!q.exec()){
			return;
		}  
		var numReg = q.size();
		if(numReg == 0) {
			_i.oResGFT_.resultado = "REVISAR";
			//preguntar a Antonio el final del mensaje
			_i.oResGFT_.listaMotivos.push("No se han encontrado coordinados en la l�nea " + orden + " de la plantilla para el dibujo '" + codDibujoPR + "', Color '" + codcolorPR + "',  C.Normalizado '" + compoNormalLPL + "', Tama�o '" + codTamanoPR + "', Colecci�n '" + coleccionPR + "', Familia '" + codFamiliaPR + "', Subfamilia '" + codSubfamiliaPR + "'");	
			_i.oResGFT_.listaMotivos.push("No se ha encontrado referencia candidata para la l�nea " + orden + " de la plantilla");
					
		} else if (numReg>1) {
			var oParamFiltro = new Object;
			oParamFiltro.codDibujoPR = codDibujoPR;
			oParamFiltro.codcolorPR =  codcolorPR;
			oParamFiltro.coleccionPR =  coleccionPR;
			oParamFiltro.codFamiliaPR =  codFamiliaPR;
			oParamFiltro.codSubfamiliaPR =  codSubfamiliaPR;
			oParamFiltro.codTamanoPR =  codTamanoPR;
			oParamFiltro.compoNormalLPL =  compoNormalLPL;

			var aCoordinados = _i.filtrarPorCoincidencias(q, oParamFiltro);

			if(aCoordinados.length == 1) {

				var dibujoCoord = aCoordinados[0].codCoord;
				var colorCoord = aCoordinados[0].colorCoord;				
				var codTamanio = _i.elegirTamaRefCan(dibujoCoord, curLinea);
				if(!codTamanio) {	
					_i.oResGFT_.resultado = "REVISAR";
					_i.oResGFT_.listaMotivos.push("El dibujo coordinado " + dibujoCoord + " no tiene informado si es panot o continuo y no es posible elegir el tama�o adecuado en la l�nea " + curLinea.valueBuffer("orden") + " de la plantilla");						
				} else {
					_i.oResGFT_.codTamanio = codTamanio; 
					var refCandidata = _i.dameRefCandidataCoord(curLinea.valueBuffer("codsubfamilia"),dibujoCoord,codTamanio,colorCoord);
					if(refCandidata.toString() == "Err:0") {
						_i.oResGFT_.resultado = "REVISAR";
						_i.oResGFT_.listaMotivos.push("No se ha encontrado referencia candidata para la l�nea " + orden + " de la plantilla");
				
					} else if(refCandidata.toString().left(4) == "Err:") {
						_i.oResGFT_.situacion = "REVISAR";
						_i.oResGFT_.listaMotivos.push("Hay " + refCandidata.right(refCandidata.length-4) + " referencias candidatas para seleccionar con la misma subfamilia,dibujo coordinado, tama�o y color coordinado");					
					} else {
						if(refCandidata && refCandidata != "") {
							_i.oResGFT_.resultado = "OK";	
							_i.oResGFT_.refCandidata = refCandidata; 
						}				
					}
				}

			} else {
				_i.oResGFT_.resultado = "REVISAR";
				_i.oResGFT_.listaMotivos.push("Hay " + aCoordinados.length + " dibujos coordinados para l�nea " + orden + " de la plantilla para Dibujo '" + codDibujoPR +"', Color '" + codcolorPR +"', C.Normalizado '" + compoNormalLPL + "', Tama�o '" +codTamanoPR + "', Colecci�n '" + coleccionPR + "', Familia '" + codFamiliaPR + "', Subfamilia '" + codSubfamiliaPR + "'");	
				_i.oResGFT_.listaMotivos.push("No se ha encontrado referencia candidata para la l�nea " + orden + " de la plantilla");
			}

		} else {

			if(q.first()) {
				var dibujoCoord = q.value("codcoord");
				var colorCoord = q.value("colorcoord");				
				var codTamanio = _i.elegirTamaRefCan(dibujoCoord, curLinea);

				if(!codTamanio) {	
					_i.oResGFT_.resultado = "REVISAR";
					_i.oResGFT_.listaMotivos.push("El dibujo coordinado " + dibujoCoord + " no tiene informado si es panot o continuo y no es posible elegir el tama�o adecuado en la l�nea " + curLinea.valueBuffer("orden") + " de la plantilla");						
				} else {
					_i.oResGFT_.codTamanio = codTamanio; 
					var refCandidata = _i.dameRefCandidataCoord(curLinea.valueBuffer("codsubfamilia"),dibujoCoord,codTamanio,colorCoord);
					if(refCandidata.toString() == "Err:0") {
						_i.oResGFT_.resultado = "REVISAR";
						_i.oResGFT_.listaMotivos.push("No se ha encontrado referencia candidata para la l�nea " + orden + " de la plantilla");
				
					} else if(refCandidata.toString().left(4) == "Err:") {
						_i.oResGFT_.situacion = "REVISAR";
						_i.oResGFT_.listaMotivos.push("Hay " + refCandidata.right(refCandidata.length-4) + " referencias candidatas para seleccionar con la misma subfamilia,dibujo coordinado, tama�o y color coordinado");					
					} else {
						if(refCandidata && refCandidata != "") {
							_i.oResGFT_.resultado = "OK";	
							_i.oResGFT_.refCandidata = refCandidata; 
						}				
					}
				}
			}

		}
	}
	return _i.oResGFT_;

}

function euromoda_elegirTamaRefCan(codDibujoPR, curLinea)
{
	var _i = this.iface;
	var ret = false;
	var panotCont = AQUtil.sqlSelect("em_dibujos","panotcont","coddibujoem = '" + codDibujoPR + "'");
	if(panotCont == "Continuo") {
		ret = curLinea.valueBuffer("codtamanocont");
	} else if(panotCont == "Panot") {
		ret = curLinea.valueBuffer("codtamanopanot");
	}
	return ret;
}

function euromoda_dameRefCandidata(codTamanio, curLinea, cursor)
{
	var _i = this.iface;
	var coleccionPR = cursor.valueBuffer("codcoleccionem");
	var subfamiliaLPL = curLinea.valueBuffer("codsubfamilia");
	var codDibujoPR = cursor.valueBuffer("coddibestamp");
	var codColorLPL = curLinea.valueBuffer("codcolorem");	
	var retorno = "Err:0";
	var q = new AQSqlQuery;	
	q.setSelect("referencia");
	q.setFrom("articulos");
	q.setWhere("codcoleccionem = '" + coleccionPR + "' and codsubfamilia = '" + subfamiliaLPL + "' and coddibestamp = '" + codDibujoPR + "' and codtamanoem = '" + codTamanio + "' and codcolorem = '" + codColorLPL + "' and not debaja ");	
	
	if (!q.exec()){
		return;
	}  
	var numReg = q.size();
	if(!numReg || numReg == 0) {
		retorno = "Err:0";

		var q2 = new AQSqlQuery;	
		q2.setSelect("referencia");
		q2.setFrom("articulos");
		q2.setWhere("codsubfamilia = '" + subfamiliaLPL + "' and coddibestamp = '" + codDibujoPR + "' and codtamanoem = '" + codTamanio + "' and codcolorem = '" + codColorLPL + "' and not debaja");	
		
		if (!q2.exec()){
			return;
		}  
		numReg = q2.size();
		if(!numReg || numReg == 0) {
			retorno = "Err:0";
		} else if(numReg >1) {
			retorno = "Err:"+numReg;
		} else {
			if(q2.first()) {
				retorno = q2.value("referencia");	
			}
		
		}
	} else if(numReg >1) {
		retorno = "Err:"+numReg;
	} else {
		if(q.first()) {
			retorno = q.value("referencia");	
		}
		
	}

	return retorno;

}

function euromoda_dameRefCandidataCoord(codSubfamilia,dibujoCoord,codTamanio,colorCoord)
{
	var _i = this.iface;

	var retorno = "Err:0";
	var q = new AQSqlQuery;	
	q.setSelect("referencia");
	q.setFrom("articulos");
	q.setWhere("codsubfamilia = '" + codSubfamilia + "' and coddibestamp = '" + dibujoCoord + "' and codtamanoem = '" + codTamanio + "' and codcolorem = '" + colorCoord + "' and not debaja");	

	if (!q.exec()){
		return;
	}  
	numReg = q.size();
	if(!numReg || numReg == 0) {
		retorno = "Err:0";
	} else if(numReg >1) {
		retorno = "Err:"+numReg;
	} else {
		if(q.first()) {
			retorno = q.value("referencia");	
		}	
	}
	return retorno;

}

function euromoda_filtrarPorCoincidencias(q, oParamFiltro)
{
	var aCoordinados = [];

	var codDibujoPR = oParamFiltro.codDibujoPR;
	var codcolorPR = oParamFiltro.codcolorPR;
	var coleccionPR = oParamFiltro.coleccionPR;
	var codFamiliaPR = oParamFiltro.codFamiliaPR;
	var codSubfamiliaPR = oParamFiltro.codSubfamiliaPR;
	var codTamanoPR = oParamFiltro.codTamanoPR;
	var compoNormalLPL = oParamFiltro.compoNormalLPL;
	var p = 0;
	var cont;
	var maximo = 0;
	var metidos = 0;
	while(q.next()) {		

		cont = 0;

		var oCoord = new Object;
		oCoord.codCoord = q.value("codcoord");
		oCoord.colorCoord = q.value("colorcoord");

		if(codDibujoPR == q.value("coddibujoem")) {
			cont++;
		}
		if(codcolorPR == q.value("colordib")) {
			cont++;
		}
		if(coleccionPR == q.value("codcoleccion")) {
			cont++;
		}
		if(codFamiliaPR == q.value("codfamilia")) {
			cont++;
		}
		if(codSubfamiliaPR == q.value("codsubfamilia")) {
			cont++;
		}
		if(compoNormalLPL == q.value("componormal")) {
			cont++;
		}
		if(codTamanoPR == q.value("codtamanoem")) {
			cont++;
		}	
		if(cont>maximo) {
						
			delete aCoordinados;	
			aCoordinados = [];	
			
			oCoord.coincidencias = cont;
			aCoordinados.push(oCoord);	
			maximo = cont;		
		} else if(cont == maximo) {			
			oCoord.coincidencias = cont;
			aCoordinados.push(oCoord);				
		}  	
		p++;
	}
	return aCoordinados;

}


function euromoda_establecerValorFamilia() 
{
  	var cursor = this.cursor();	
	var codSubFamilia = cursor.valueBuffer("codsubfamilia");

	var codFamilia;
	if (codSubFamilia && codSubFamilia != "") {
		codFamilia = AQUtil.sqlSelect("subfamilias", "codfamilia", "codsubfamilia = '" + codSubFamilia + "'");
		if(!codFamilia || codFamilia == ""){
			codFamilia = ""; //pineboo 21-08-2019
		}
		
		if(this.child("fdbCodFamilia")){	
			if(cursor.valueBuffer("codfamilia") != codFamilia) {				
				this.child("fdbCodFamilia").setValue(codFamilia);
				cursor.setValueBuffer("codfamilia",codFamilia);
				if (cursor.modeAccess() == cursor.Edit) {
					cursor.commitBuffer();
	  				cursor.setModeAccess(cursor.Edit);	
	  				cursor.refreshBuffer();
				}
			}
			this.child("fdbCodFamilia").setDisabled(true);
		}
	}
	
}

function euromoda_ordenarFilasValorMercado()
{
	if (!this.child("tdbEmValoresMercado")) {
		return;
	}
	var oC = ["em_fechavalmercado"];	
	
	this.child("tdbEmValoresMercado").setOrderCols(oC);
}

function euromoda_ordenaColsValMercado()
{
	
    var tdbLC = this.child("tdbEmValoresMercado");
    var dtbLC = this.mainWidget().child("tdbEmValoresMercado").tableRecords();    
	var hHeader = dtbLC.horizontalHeader();	hHeader.setClickEnabled(false);
	hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbLC.setSort(["v_valoresmercado.referencia ASC", "v_valoresmercado.em_fechavalmercado ASC"]); 	
    dtbLC.refresh(AQS.RefreshData);   
    this.child("tdbEmValoresMercado").refresh();
}

function euromoda_tdbEmValoresMercado_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEditEmValMercado_clicked();
	
}
function euromoda_toolButtonInsertEmValMercado_clicked()
{
	var _i = this.iface;

	_i.accionCursorExterno("insert");
}

function euromoda_toolButtonEditEmValMercado_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbEmValoresMercado").cursor();
	var referencia = cursor.valueBuffer("referencia");
	if(!referencia || referencia == "") {
		flfactppal.iface.ponMsgError(sys.translate("No hay ning�n registro seleccionado."),"warn",this);
		return false;
	}
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDeleteEmValMercado_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoomEmValMercado_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}
function euromoda_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.child("tdbEmValoresMercado").cursor();
	
	if (_i.curS_) {
		disconnect(_i.curS_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curS_, "commited()", _i, "curS_bufferCommited");
		_i.curS_ = undefined;
	}
	
	_i.curS_ = new FLSqlCursor("em_valoresmercado");
	_i.curS_.setAction("em_valoresmercado");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curS_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curS_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			_i.referenciaVM_ = this.cursor().valueBuffer("referencia");
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");
			this.child("tdbFichaTecnica").cursor().commitBufferCursorRelation();			

			_i.curS_.insertRecord();
			_i.referenciaVM_ = false;
			this.child("tdbEmValoresMercado").refresh();
			break;
		}
		case "edit": {
			connect(_i.curS_, "commited()", _i, "refrescaTabla");
			_i.curS_.editRecord();
			break;
		}
		case "del": {
			//eliminar registro pero de la tabla em_valoresmercado	

			var res = flfactppal.iface.preguntaMsg(sys.translate("El registro activo ser� borrado. �Est� seguro?"),"info",this,MessageBox.Yes, MessageBox.No);  
  			if (res != MessageBox.Yes) {
				return false;
  			}	
			_i.curS_.setModeAccess(_i.curS_.Del);
  			_i.curS_.refreshBuffer();
			if (!_i.curS_.commitBuffer()) {
				return false;
			}			
			this.child("tdbEmValoresMercado").refresh();
			break;
		}
		case "browse": {	
			_i.curS_.browseRecord();
			break;
		}
	}
}
function euromoda_curS_bufferCommited()
{
	
	var _i = this.iface;
	var cursor = this.child("tdbEmValoresMercado").cursor();
	this.child("tdbFichaTecnica").cursor().commitBufferCursorRelation();
	this.child("tdbEmValoresMercado").refresh();
	var dtbLC = this.mainWidget().child("tdbEmValoresMercado").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);
	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);
	/*var pos = cursor.atFromBinarySearch("id", _i.pK_, asc);
	cursor.seek(pos);
	cursor.refresh()*/
}
function euromoda_refrescaTabla()
{
	var _i = this.iface;
	this.child("tdbEmValoresMercado").refresh();
}

function euromoda_formReady()
{
	var _i = this.iface;
	_i.__formReady();
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		
		//_i.bufferChanged("codsubfamilia");
		//_i.bufferChanged("codfamilia");
	}
}

function euromoda_habilitaCamposCostesProd(miForm, cursor)
{
	var _i = this.iface;
	var usuario = sys.nameUser();
	var cambiarMargen = false;
	var cambiarCostes = false;
	var q = new AQSqlQuery;	
	q.setSelect("em_cambiarmargenesprod,em_cambiarcostesprod");
	q.setFrom("usuarios");
	q.setWhere("idusuario = '" + usuario + "'");	
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		cambiarMargen = q.value("em_cambiarmargenesprod");
		cambiarCostes = q.value("em_cambiarcostesprod");		
	}	
	if(miForm.child("fdbEmCosteProd")) {
		
		if(cambiarCostes) {
			
			if(miForm.child("fdbEmTipoCosteProd")) {
				
				miForm.child("fdbEmTipoCosteProd").setDisabled(false);	
				if(cursor.valueBuffer("em_tipocoste") == "Heredado"){				
				    miForm.child("fdbEmCosteProd").setDisabled(true);
				}else {
				    miForm.child("fdbEmCosteProd").setDisabled(false);
				}
			    } else {
				miForm.child("fdbEmCosteProd").setDisabled(false);
				
			    }
			if(miForm.child("pbnHeredarCoste")) {
			
				miForm.child("pbnHeredarCoste").setDisabled(false);		
			}
			miForm.child("fdbEmObservCosteProd").setDisabled(false);
		  	if(miForm.child("chkActivarCostes")) {
		  		miForm.child("chkActivarCostes").setDisabled(false);
		  	}
		  	if(miForm.child("pbnActualizarCostes")) {
		  		miForm.child("pbnActualizarCostes").setDisabled(false);
		  	}

		} else {
			if(miForm.child("fdbEmTipoCosteProd")) {
				
				miForm.child("fdbEmTipoCosteProd").setDisabled(true);
			}
			if(miForm.child("pbnHeredarCoste")) {
				
				miForm.child("pbnHeredarCoste").setDisabled(true);	
			}			
			miForm.child("fdbEmCosteProd").setDisabled(true);
			miForm.child("fdbEmObservCosteProd").setDisabled(true);
			if(miForm.child("pbnActualizarCostes")) {
		  		miForm.child("pbnActualizarCostes").setDisabled(true);
		  	}
			if(miForm.child("chkActivarCostes")) {
		  		miForm.child("chkActivarCostes").setDisabled(true);
		  	}
		}
	}

	if(miForm.child("fdbEmMargenProd")) {	   
		if(cambiarMargen) {
			if(miForm.child("fdbEmTipoMargen")) {
				miForm.child("fdbEmTipoMargen").setDisabled(false);	
				if(cursor.valueBuffer("em_tipomargen") == "Heredado"){				
				    miForm.child("fdbEmMargenProd").setDisabled(true);
				}else {
				    miForm.child("fdbEmMargenProd").setDisabled(false);
				}
			    } else {
				 miForm.child("fdbEmMargenProd").setDisabled(false);
			    }
		
			if(miForm.child("pbnHeredarMargen")) {
				miForm.child("pbnHeredarMargen").setDisabled(false);
			}
			miForm.child("fdbEmObservMargenProd").setDisabled(false);
			

		  	if(miForm.child("pbnActualizarMargenes")) {
		  		miForm.child("pbnActualizarMargenes").setDisabled(false);
		  	}
		  	if(miForm.child("chkActivarMargenes")) {
		  		miForm.child("chkActivarMargenes").setDisabled(false);
		  	}
		} else {
			if(miForm.child("fdbEmTipoMargen")) {
				miForm.child("fdbEmTipoMargen").setDisabled(true);
			}
		 	if(miForm.child("pbnHeredarMargen")) {
				miForm.child("pbnHeredarMargen").setDisabled(true);
			}
			miForm.child("fdbEmMargenProd").setDisabled(true);
			miForm.child("fdbEmObservMargenProd").setDisabled(true);
			if(miForm.child("pbnActualizarMargenes")) {
		  		miForm.child("pbnActualizarMargenes").setDisabled(true);
		  	}
		  	if(miForm.child("chkActivarMargenes")) {
		  		miForm.child("chkActivarMargenes").setDisabled(true);
		  	}
		}
	}

}

function euromoda_cargaDatosLogCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var obj = _i.dameTablaLogCostes();	
	var miTabla = obj.miTabla;
	var q = new FLSqlQuery;
	q.setSelect(_i.dameSelectLogCostes(cursor));		
	q.setFrom("v_logcostesmargenes");
	q.setWhere(_i.dameWhereLogCostes(cursor));
	q.setOrderBy("v_logcostesmargenes.fechahis DESC, v_logcostesmargenes.horahis DESC");		
	miTabla.setQuery(q);	

	_i.ponTamanosLogCostes(miTabla);
	miTabla.setColumnWidth("v_logcostesmargenes.em_observcosteprod", 200);
	miTabla.setColumnWidth("v_logcostesmargenes.em_observmargenprod", 200);

	miTabla.setReadOnly(true);	
	miTabla.refresh();
	
	return true;	
}

function euromoda_dameTablaLogCostes()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblLogCostes_ ? true : false;
	obj.tabla = this.child("mte_tblExt_LogCostes");
	obj.gb = this.child("mte_gbExt_LogCostes");

	if (!obj.creado) {
		_i.tblLogCostes_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblLogCostes_.checkColumnEnabled(false);
		_i.tblLogCostes_.setAliasCheckColumn("Sel.");
		_i.tblLogCostes_.setSearchEnabled(true);
		_i.tblLogCostes_.setOrderDesc(true);
		//_i.tblLogCostes_.setDoubleClickedFunction("formem_reservasop.iface.abrirOP");
	}
	
	obj.miTabla = _i.tblLogCostes_;

	return obj;
}

function euromoda_dameSelectLogCostes(cursor)
{
	var _i = this.iface;
	var sSelect = "";
	if(cursor.table() == "articulos") {
		sSelect = "v_logcostesmargenes.fechahis, v_logcostesmargenes.horahis, v_logcostesmargenes.usuariohis, v_logcostesmargenes.em_fechacosteprod, v_logcostesmargenes.em_horacosteprod,v_logcostesmargenes.em_costeprod,v_logcostesmargenes.em_idusuariocosteprod, v_logcostesmargenes.em_observcosteprod, v_logcostesmargenes.em_margenprod, v_logcostesmargenes.em_fechamargenprod, v_logcostesmargenes.em_horamargenprod, v_logcostesmargenes.em_idusuariomargenprod , v_logcostesmargenes.em_observmargenprod,v_logcostesmargenes.em_tipocoste, v_logcostesmargenes.em_origencoste, v_logcostesmargenes.em_tipomargen, v_logcostesmargenes.em_origenmargen";

	} else if(cursor.table() == "em_tamanossubfam") {		
		sSelect = "v_logcostesmargenes.fechahis,v_logcostesmargenes.horahis,v_logcostesmargenes.usuariohis,v_logcostesmargenes.em_fechacosteprod,v_logcostesmargenes.em_horacosteprod,v_logcostesmargenes.em_costeprod,v_logcostesmargenes.em_idusuariocosteprod,v_logcostesmargenes.em_observcosteprod,v_logcostesmargenes.em_margenprod,v_logcostesmargenes.em_fechamargenprod,v_logcostesmargenes.em_horamargenprod,v_logcostesmargenes.em_idusuariomargenprod,v_logcostesmargenes.em_observmargenprod,v_logcostesmargenes.em_actcostes,v_logcostesmargenes.em_activarcostesher,v_logcostesmargenes.em_actmargenes, v_logcostesmargenes.em_activarmargenher";

	} else if(cursor.table() == "em_plantillasprod") {
		sSelect = "v_logcostesmargenes.fechahis,v_logcostesmargenes.horahis,v_logcostesmargenes.usuariohis,v_logcostesmargenes.em_fechacosteprod,v_logcostesmargenes.em_horacosteprod,v_logcostesmargenes.em_costeprod,v_logcostesmargenes.em_idusuariocosteprod,v_logcostesmargenes.em_observcosteprod,v_logcostesmargenes.em_margenprod,v_logcostesmargenes.em_fechamargenprod,v_logcostesmargenes.em_horamargenprod,v_logcostesmargenes.em_idusuariomargenprod,v_logcostesmargenes.em_observmargenprod,v_logcostesmargenes.em_actcostes,v_logcostesmargenes.em_activarcostesher,v_logcostesmargenes.em_actmargenes, v_logcostesmargenes.em_activarmargenher";	
		
	} else if(cursor.table() == "subfamilias") {
		sSelect = "v_logcostesmargenes.fechahis,v_logcostesmargenes.horahis,v_logcostesmargenes.usuariohis,v_logcostesmargenes.em_fechacosteprod,v_logcostesmargenes.em_horacosteprod,v_logcostesmargenes.em_costeprod,v_logcostesmargenes.em_idusuariocosteprod,v_logcostesmargenes.em_observcosteprod,v_logcostesmargenes.em_margenprod,v_logcostesmargenes.em_fechamargenprod,v_logcostesmargenes.em_horamargenprod,v_logcostesmargenes.em_idusuariomargenprod,v_logcostesmargenes.em_observmargenprod,v_logcostesmargenes.em_actcostes,v_logcostesmargenes.em_activarcostesher,v_logcostesmargenes.em_actmargenes, v_logcostesmargenes.em_activarmargenher";

	} else if(cursor.table() == "familias") {
		sSelect = "v_logcostesmargenes.fechahis,v_logcostesmargenes.horahis,v_logcostesmargenes.usuariohis,v_logcostesmargenes.em_margenprod,v_logcostesmargenes.em_fechamargenprod,v_logcostesmargenes.em_horamargenprod,v_logcostesmargenes.em_idusuariomargenprod,v_logcostesmargenes.em_observmargenprod,v_logcostesmargenes.em_actmargenes, v_logcostesmargenes.em_activarmargenher";
	}

	return sSelect;
}

function euromoda_dameWhereLogCostes(cursor)
{
	var _i = this.iface;
	var sWhere = "";

	if(cursor.table() == "articulos") {
		sWhere = "v_logcostesmargenes.referencia = '" + cursor.valueBuffer("referencia") + "' and v_logcostesmargenes.gridasociado = 'articulos'";
	} else if(cursor.table() == "em_tamanossubfam") {		
		sWhere = "v_logcostesmargenes.codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "' AND v_logcostesmargenes.codtamanoem = '" + cursor.valueBuffer("codtamanoem") + "' and v_logcostesmargenes.gridasociado = 'tama�os por subfamilia'";
	} else if(cursor.table() == "em_plantillasprod") {
		sWhere = "v_logcostesmargenes.idplantilla = " + cursor.valueBuffer("idplantilla") + " AND v_logcostesmargenes.gridasociado = 'plantillas'";
		
	} else if(cursor.table() == "subfamilias") {
		sWhere = "v_logcostesmargenes.codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "' and v_logcostesmargenes.gridasociado = 'subfamilias'";

	} else if(cursor.table() == "familias") {
		sWhere = "v_logcostesmargenes.codfamilia = '" + cursor.valueBuffer("codfamilia") + "' and v_logcostesmargenes.gridasociado = 'familias'";
	}

	return sWhere;
}

function euromoda_ponTamanosLogCostes(miTabla)
{

	miTabla.setColumnWidth("v_logcostesmargenes.fechahis", 80);
	miTabla.setColumnWidth("v_logcostesmargenes.horahis", 70);
	miTabla.setColumnWidth("v_logcostesmargenes.usuariohis", 80);
	miTabla.setColumnWidth("v_logcostesmargenes.em_fechacosteprod", 80);
	miTabla.setColumnWidth("v_logcostesmargenes.em_horacosteprod", 70);
	miTabla.setColumnWidth("v_logcostesmargenes.em_costeprod", 95);
	miTabla.setColumnWidth("v_logcostesmargenes.em_idusuariocosteprod", 80);
	miTabla.setColumnWidth("v_logcostesmargenes.em_observcosteprod", 265);
	miTabla.setColumnWidth("v_logcostesmargenes.em_margenprod", 100);
	miTabla.setColumnWidth("v_logcostesmargenes.em_fechamargenprod", 90);
	miTabla.setColumnWidth("v_logcostesmargenes.em_horamargenprod", 85);
	miTabla.setColumnWidth("v_logcostesmargenes.em_idusuariomargenprod", 80);
	miTabla.setColumnWidth("v_logcostesmargenes.em_observmargenprod", 265);
	miTabla.setColumnWidth("v_logcostesmargenes.em_tipocoste", 80);
	miTabla.setColumnWidth("v_logcostesmargenes.em_origencoste", 140);
	miTabla.setColumnWidth("v_logcostesmargenes.em_tipomargen", 80);	
	miTabla.setColumnWidth("v_logcostesmargenes.em_origenmargen", 140);	
	miTabla.setColumnWidth("v_logcostesmargenes.em_actmargenes", 90);
	miTabla.setColumnWidth("v_logcostesmargenes.em_activarmargenher", 95);
	miTabla.setColumnWidth("v_logcostesmargenes.em_actcostes", 100);
	miTabla.setColumnWidth("v_logcostesmargenes.em_activarcostesher", 105);
	miTabla.setColumnWidth("v_logcostesmargenes.codsubfamilia", 100);
}

function euromoda_pbnHeredarCoste_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.pulsaHeredar_ = true;
	if (cursor.modeAccess() == cursor.Insert) {
		cursor.commitBuffer();
		cursor.setModeAccess(cursor.Edit);	
		cursor.refreshBuffer();
	}
	if(!_i.heredarCosteProd(cursor,false, true)) {
		return false;
	} 
	_i.tblLogCostes_.refresh();	
	_i.pulsaHeredar_ = true;
	return true;

}

function euromoda_heredarCosteProd(cursor,silent, ponLog)
{
	var _i = this.iface;
	var usuario = sys.nameUser();
	var hoy = new Date();
	var hora = hoy.toString().right(8);

	
	var oCostes = _i.dameCosteProd(cursor, silent);	
	if(!oCostes) {
		return true;
	}
	
	if("coste" in oCostes && oCostes["coste"]) {
		var coste = oCostes["coste"];
		coste = AQUtil.roundFieldValue(coste, "articulos", "em_costeprod");
		if(!silent) {
			formUI.ponMsgBox(sys.translate("Coste actualizado de valor %1 a %2").arg(AQUtil.formatoMiles(AQUtil.roundFieldValue(cursor.valueBuffer("em_costeprod"), "articulos","em_costeprod"))).arg(AQUtil.formatoMiles(coste)),"info");
		}

		cursor.setValueBuffer("em_costeprod",coste);
		cursor.setValueBuffer("em_fechacosteprod",oCostes["fechaCoste"]);
		cursor.setValueBuffer("em_horacosteprod",oCostes["horaCoste"].toString().right(8));
		cursor.setValueBuffer("em_idusuariocosteprod",oCostes["idUsuarioCoste"]);
		cursor.setValueBuffer("em_observcosteprod",oCostes["observCoste"]);
		cursor.setValueBuffer("em_origencoste",oCostes["origenCoste"]);

		var aCampos = ["em_margenprod","em_fechamargenprod","em_horamargenprod","em_idusuariomargenprod","em_observmargenprod","referencia","em_tipomargen"];

		var oParam = new Object;
		oParam["gridasociado"] = "articulos";
		oParam["fechahis"] = hoy;
		oParam["horahis"] = hora;
		oParam["usuariohis"] = sys.nameUser();
		oParam["em_costeprod"] = coste;
		oParam["em_fechacosteprod"] = oCostes["fechaCoste"];
		oParam["em_horacosteprod"] = oCostes["horaCoste"].toString().right(8);
		oParam["em_idusuariocosteprod"] = oCostes["idUsuarioCoste"];
		oParam["em_observcosteprod"] = oCostes["observCoste"];		
		oParam["em_origencoste"] = oCostes["origenCoste"];		
		oParam["em_tipocoste"] = "Heredado";	

		if(cursor.valueBuffer("em_tipomargen") == "Manual") {
			oParam["em_origenmargen"] = "articulo";
		} else {
			oParam["em_origenmargen"] = cursor.valueBuffer("em_origenmargen");
		}

		for(var i=0;i<aCampos.length;i++) {
			if(cursor.isNull(aCampos[i])) {
				oParam[aCampos[i]] = "NULL";	
			} else {
				oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);	
			}
		}
		if(ponLog) {
			if(!_i.insertaRegistroLog(oParam)) {
				return false;
			}			
		}

		cursor.setValueBuffer("em_tipocoste","Heredado");
	}
	return true;
}

function euromoda_dameCosteProd(cursor,silent)
{
	var _i = this.iface;
	var oCostes = new Object;
	oCostes["coste"] = false;
	
	//1. miraramos en plantilla de producto por coleccion-subfmailia-el tama�o-el color
	var codColeccionEM = cursor.valueBuffer("codcoleccionem");
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codTamanoEM = cursor.valueBuffer("codtamanoem");
	var codColorEM = cursor.valueBuffer("codcolorem");
	
	var q = new AQSqlQuery;	
	q.setSelect("em_costeprod, em_fechacosteprod, em_horacosteprod, em_idusuariocosteprod, em_observcosteprod");
	q.setFrom("em_plantillasprod");
	q.setWhere("codcoleccionem = '" + codColeccionEM + "' AND codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND codcolorem = '" + codColorEM + "' AND em_costeprod IS NOT NULL");	
	//debug("q1: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.size() > 1) {
		if(!silent) {			
			formUI.ponMsgBox("No se puede heredar de la plantilla, hay varios costes candidatos para la colecci�n/subfamilia/tama�o/color","warn");	
		}
				
		return false;
	} else if (q.size() == 1) {
		if(!q.first()) {
			return false;
		}
		
		oCostes["coste"] = q.value("em_costeprod");
		oCostes["fechaCoste"] = q.value("em_fechacosteprod"); 
		oCostes["horaCoste"] = q.value("em_horacosteprod");
		oCostes["idUsuarioCoste"] = q.value("em_idusuariocosteprod");
		oCostes["observCoste"] = q.value("em_observcosteprod");
		oCostes["origenCoste"] = "plantilla";
		
	} else {

		//20-06-2019
		

		//VOY POR AQUI


		/* 

		SELECT referencia,codfamilia,codsubfamilia,codtamanoem,codcoleccionem,codcoleccion_alternativa,origencoste,costeorigen,costearticulo,origenmargen,margenorigen,margenarticulo FROM v_origencostemargen where codsubfamilia = '366J' order by codcoleccionem;


		 NO ALTERNATIVA
		select codcoleccionem,codsubfamilia,codtamanoem,codcolorem from articulos where referencia = '210397';
		select p.em_costeprod, p.em_fechacosteprod, p.em_horacosteprod, p.em_idusuariocosteprod, p.em_observcosteprod from em_plantillasprod p where codcoleccionem = '569' AND codsubfamilia = '366J' AND codtamanoem = 'F.N. 90' AND codcolorem = 'UNICO' AND em_costeprod IS NOT NULL;

		ALTERNATIVA
		select codcoleccionem,codsubfamilia,codtamanoem,codcolorem from articulos where referencia = '210405'; ALTERNATIVA
		select p.em_costeprod, p.em_fechacosteprod, p.em_horacosteprod, p.em_idusuariocosteprod, p.em_observcosteprod from em_plantillasprod p where codcoleccionem = '570' AND codsubfamilia = '366J' AND codtamanoem = 'F.N. 90' AND codcolorem = 'UNICO' AND em_costeprod IS NOT NULL;

		select p.em_costeprod, p.em_fechacosteprod, p.em_horacosteprod, p.em_idusuariocosteprod, p.em_observcosteprod from em_plantillasprod p INNER JOIN em_colecciones c ON p.codcoleccionem = c.codcoleccionplan where c.codcoleccionem = '570' AND p.codsubfamilia = '366J' AND p.codtamanoem = 'F.N. 90' AND p.codcolorem = 'UNICO' AND p.em_costeprod IS NOT NULL;

		*/

		//1b miramos por plantilla alternativa
		var qPlanAlt = new AQSqlQuery;	
		qPlanAlt.setSelect("p.em_costeprod, p.em_fechacosteprod, p.em_horacosteprod, p.em_idusuariocosteprod, p.em_observcosteprod");
		qPlanAlt.setFrom("em_plantillasprod p INNER JOIN em_colecciones c ON p.codcoleccionem = c.codcoleccionplan");
		qPlanAlt.setWhere("c.codcoleccionem = '" + codColeccionEM + "' AND p.codsubfamilia = '" + codSubfamilia + "' AND p.codtamanoem = '" + codTamanoEM + "' AND p.codcolorem = '" + codColorEM + "' AND p.em_costeprod IS NOT NULL");	
		//debug("qPlanAlt: "+qPlanAlt.sql());
		if (!qPlanAlt.exec()){
			return;
		}  
		if(qPlanAlt.size() > 1) {
			if(!silent) {				
				formUI.ponMsgBox("No se puede heredar de la plantilla, hay varios costes candidatos para la colecci�n/subfamilia/tama�o/color","warn");	
			}
					
			return false;
		} else if (qPlanAlt.size() == 1) {
			if(!qPlanAlt.first()) {
				return false;
			}			
			oCostes["coste"] = qPlanAlt.value("p.em_costeprod");
			oCostes["fechaCoste"] = qPlanAlt.value("p.em_fechacosteprod"); 
			oCostes["horaCoste"] = qPlanAlt.value("p.em_horacosteprod");
			oCostes["idUsuarioCoste"] = qPlanAlt.value("p.em_idusuariocosteprod");
			oCostes["observCoste"] = qPlanAlt.value("p.em_observcosteprod");
			oCostes["origenCoste"] = "plantilla alternativa";
			
		} else {

			//2. miramos por subfamilia/tama�o		
			var qTamSub = new AQSqlQuery;	
			qTamSub.setSelect("em_costeprod,em_fechacosteprod, em_horacosteprod, em_idusuariocosteprod, em_observcosteprod");
			qTamSub.setFrom("em_tamanossubfam");
			qTamSub.setWhere("codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND em_costeprod IS NOT NULL");		
			if (!qTamSub.exec()){
				return;
			}  
			if(qTamSub.size() > 1) {
				if(!silent) {				
					formUI.ponMsgBox("No se puede heredar, hay varios costes candidatos para la subfamilia/tama�o","warn");	
				}					
				return false;
			} else if (qTamSub.size() == 1) {
				if(!qTamSub.first()) {
					return false;
				}			
				oCostes["coste"] = qTamSub.value("em_costeprod");
				oCostes["fechaCoste"] = qTamSub.value("em_fechacosteprod"); 
				oCostes["horaCoste"] = qTamSub.value("em_horacosteprod");		
				oCostes["idUsuarioCoste"] = qTamSub.value("em_idusuariocosteprod");
				oCostes["observCoste"] = qTamSub.value("em_observcosteprod");
				oCostes["origenCoste"] = "tama�os por subfamilia";
			} else {
				//11-06-2019 H1809
				var qSubFam = new AQSqlQuery;	
				qSubFam.setSelect("em_costeprod,em_fechacosteprod, em_horacosteprod, em_idusuariocosteprod, em_observcosteprod");
				qSubFam.setFrom("subfamilias");
				qSubFam.setWhere("codsubfamilia = '" + codSubfamilia +"' AND em_costeprod IS NOT NULL");		
				if (!qSubFam.exec()){
					return;
				}  
				if(qSubFam.size() > 1) {
					if(!silent) {				
						formUI.ponMsgBox("No se puede heredar, hay varios costes candidatos para la subfamilia","warn");	
					}					
					return false;
				} else if (qSubFam.size() == 1) {
					if(!qSubFam.first()) {
						return false;
					}			
					oCostes["coste"] = qSubFam.value("em_costeprod");
					oCostes["fechaCoste"] = qSubFam.value("em_fechacosteprod"); 
					oCostes["horaCoste"] = qSubFam.value("em_horacosteprod");		
					oCostes["idUsuarioCoste"] = qSubFam.value("em_idusuariocosteprod");
					oCostes["observCoste"] = qSubFam.value("em_observcosteprod");
					oCostes["origenCoste"] = "subfamilia";
				} else {
					if(!silent) {				
						formUI.ponMsgBox("No se ha encontrado el coste","warn");	
					}						
					return false;
				}
			}
		}
	} 	
	return oCostes;
}

/*function euromoda_heredarCosteProd(cursor,silent)
{
	var usuario = sys.nameUser();
	var hoy = new Date();
	var hora = hoy.toString().right(8);
	var _i = this.iface;
	var coste = false;
	var fechaCoste = "";
	var horaCoste = "";
	var idUsuarioCoste = "";
	var observCoste = "";
	//1. miraramos en plantilla de producto por coleccion-subfmailia-el tama�o-el color
	var codColeccionEM = cursor.valueBuffer("codcoleccionem");
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codTamanoEM = cursor.valueBuffer("codtamanoem");
	var codColorEM = cursor.valueBuffer("codcolorem");
	var origenCoste = "";
	var q = new AQSqlQuery;	
	q.setSelect("em_costeprod, em_fechacosteprod, em_horacosteprod, em_idusuariocosteprod, em_observcosteprod");
	q.setFrom("em_plantillasprod");
	q.setWhere("codcoleccionem = '" + codColeccionEM + "' AND codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND codcolorem = '" + codColorEM + "' AND em_costeprod IS NOT NULL");	
	//debug("q1: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.size() > 1) {
		if(!silent) {
			formUI.ponMsgBox("No se puede heredar de la plantilla, hay varios costes candidatos para la colecci�n/subfamilia/tama�o/color","warn");	
		}		
		return false;
	} else if (q.size() == 1) {
		if(!q.first()) {
			return false;
		}
	
		coste = q.value("em_costeprod");
		fechaCoste = q.value("em_fechacosteprod"); 
		horaCoste = q.value("em_horacosteprod");
		idUsuarioCoste = q.value("em_idusuariocosteprod");
		observCoste = q.value("em_observcosteprod");
		origenCoste = "plantilla";
	} else {
		//2. miramos por subfamilia/tama�o
		
		var qTamSub = new AQSqlQuery;	
		qTamSub.setSelect("em_costeprod,em_fechacosteprod, em_horacosteprod, em_idusuariocosteprod, em_observcosteprod");
		qTamSub.setFrom("em_tamanossubfam");
		qTamSub.setWhere("codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND em_costeprod IS NOT NULL");
		debug("qTamSub: "+qTamSub.sql());
		if (!qTamSub.exec()){
			return;
		}  
		if(qTamSub.size() > 1) {
			if(!silent) {
				formUI.ponMsgBox("No se puede heredar, hay varios costes candidatos para la subfamilia/tama�o","warn");	
			}			
			return false;
		} else if (qTamSub.size() == 1) {
			if(!qTamSub.first()) {
				return false;
			}			
			coste = qTamSub.value("em_costeprod");
			fechaCoste = qTamSub.value("em_fechacosteprod"); 
			horaCoste = qTamSub.value("em_horacosteprod");		
			idUsuarioCoste = qTamSub.value("em_idusuariocosteprod");
			observCoste = qTamSub.value("em_observcosteprod");
			origenCoste = "tama�os por subfamilia";
		} else {
			if(!silent) {
				formUI.ponMsgBox("No se ha encontrado el coste","warn");	
			}			
			return true;
		}
	} 

	if(coste) {
		coste = AQUtil.roundFieldValue(coste, "articulos", "em_costeprod");
		if(!silent) {
			formUI.ponMsgBox(sys.translate("Coste actualizado de valor %1 a %2").arg(AQUtil.formatoMiles(AQUtil.roundFieldValue(cursor.valueBuffer("em_costeprod"), "articulos","em_costeprod"))).arg(AQUtil.formatoMiles(coste)),"info");
		}

		cursor.setValueBuffer("em_costeprod",coste);
		cursor.setValueBuffer("em_fechacosteprod",fechaCoste);
		cursor.setValueBuffer("em_horacosteprod",horaCoste.toString().right(8));
		cursor.setValueBuffer("em_idusuariocosteprod",idUsuarioCoste);
		cursor.setValueBuffer("em_observcosteprod",observCoste);
		cursor.setValueBuffer("em_origencoste",origenCoste);

		var aCampos = ["em_margenprod","em_fechamargenprod","em_horamargenprod","em_idusuariomargenprod","em_observmargenprod","referencia","em_tipomargen"];

		var oParam = new Object;
		oParam["gridasociado"] = "articulos";
		oParam["fechahis"] = hoy;
		oParam["horahis"] = hora;
		oParam["usuariohis"] = sys.nameUser();
		oParam["em_costeprod"] = coste;
		oParam["em_fechacosteprod"] = fechaCoste;
		oParam["em_horacosteprod"] = horaCoste.toString().right(8);
		oParam["em_idusuariocosteprod"] = idUsuarioCoste;
		oParam["em_observcosteprod"] = observCoste;		
		oParam["em_origencoste"] = origenCoste;		
		oParam["em_tipocoste"] = "Heredado";	

		if(cursor.valueBuffer("em_tipomargen") == "Manual") {
			oParam["em_origenmargen"] = "articulo";
		} else {
			oParam["em_origenmargen"] = cursor.valueBuffer("em_origenmargen");
		}

		for(var i=0;i<aCampos.length;i++) {
			oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);
		}

		if(!_i.insertaRegistroLog(oParam)) {
			return false;
		}
		cursor.setValueBuffer("em_tipocoste","Heredado");
	}
	return true;
}*/

function euromoda_pbnHeredarMargen_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.pulsaHeredar_ = true;
	if (cursor.modeAccess() == cursor.Insert) {
		cursor.commitBuffer();
		cursor.setModeAccess(cursor.Edit);	
		cursor.refreshBuffer();
	}
	if(!_i.heredarMargenProd(cursor,false, true)) {
		return false;
	} 
	_i.tblLogCostes_.refresh();	
	_i.pulsaHeredar_ = true;
	return true;

}

function euromoda_heredarMargenProd(cursor,silent, ponLog)
{
	
	var _i = this.iface;
	var usuario = sys.nameUser();
	var hoy = new Date();
	var hora = hoy.toString().right(8);

	var oMargen = _i.dameMargenProd(cursor, silent);
	if(!oMargen) {
		return true;
	}
	if("margen" in oMargen && oMargen["margen"]) {
		var margen = oMargen["margen"];
		margen = AQUtil.roundFieldValue(margen, "articulos", "em_margenprod");
		if(!silent) {
			formUI.ponMsgBox(sys.translate("Margen actualizado de valor %1 a %2").arg(AQUtil.formatoMiles(AQUtil.roundFieldValue(cursor.valueBuffer("em_margenprod"), "articulos","em_margenprod"))).arg(AQUtil.formatoMiles(margen)),"info");		
		}

		cursor.setValueBuffer("em_margenprod",oMargen["margen"]);
		cursor.setValueBuffer("em_fechamargenprod",oMargen["fechaMargen"]);
		cursor.setValueBuffer("em_horamargenprod",oMargen["horaMargen"].toString().right(8));
		cursor.setValueBuffer("em_idusuariomargenprod",oMargen["idUsuarioMargen"]);
		cursor.setValueBuffer("em_observmargenprod",oMargen["observMargen"]);
		cursor.setValueBuffer("em_origenmargen",oMargen["origenMargen"]);		
		var aCampos = ["em_costeprod","em_fechacosteprod","em_horacosteprod","em_idusuariocosteprod","em_observcosteprod","referencia","em_tipocoste"];

		var oParam = new Object;
		oParam["gridasociado"] = "articulos";
		oParam["fechahis"] = hoy;
		oParam["horahis"] = hora;
		oParam["usuariohis"] = sys.nameUser();
		oParam["em_margenprod"] = oMargen["margen"];
		oParam["em_fechamargenprod"] = oMargen["fechaMargen"];
		oParam["em_horamargenprod"] = oMargen["horaMargen"].toString().right(8);
		oParam["em_idusuariomargenprod"] = oMargen["idUsuarioMargen"];
		oParam["em_observmargenprod"] = oMargen["observMargen"];			
		oParam["em_origenmargen"] = oMargen["origenMargen"];
		oParam["em_tipomargen"] = "Heredado";

		if(cursor.valueBuffer("em_tipocoste") == "Manual") {
			oParam["em_origencoste"] = "articulo";
		} else {
			oParam["em_origencoste"] = cursor.valueBuffer("em_origencoste");
		}

		for(var i=0;i<aCampos.length;i++) {
			if(cursor.isNull(aCampos[i])) {
				oParam[aCampos[i]] = "NULL";	
			} else {
				oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);	
			}
			
		}
		if(ponLog) {
			if(!_i.insertaRegistroLog(oParam)) {
				return false;
			}			
		}

		cursor.setValueBuffer("em_tipomargen","Heredado");
	}
	return true;
}

function euromoda_dameMargenProd(cursor,silent)
{
	var _i = this.iface;

	var oMargen = new Object;
	oMargen["margen"] = false;
	
	var codColeccionEM = cursor.valueBuffer("codcoleccionem");
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codTamanoEM = cursor.valueBuffer("codtamanoem");
	var codColorEM = cursor.valueBuffer("codcolorem");
	var codFamilia = cursor.valueBuffer("codfamilia"); 	
	
	
	//1. miraramos en plantilla de producto por coleccion-subfmailia-el tama�o-el color


	var q = new AQSqlQuery;	
	q.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
	q.setFrom("em_plantillasprod");
	q.setWhere("codcoleccionem = '" + codColeccionEM + "' AND codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND codcolorem = '" + codColorEM + "' AND em_margenprod IS NOT NULL");	
	//debug("q1: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.size() > 1) {	
		if(!silent) {
			formUI.ponMsgBox("No se puede heredar de la plantilla, hay varios m�rgenes candidatos para la colecci�n/subfamilia/tama�o/color","warn");
		}		
		return false;
	} else if (q.first()) {		
		oMargen["margen"] = q.value("em_margenprod");
		oMargen["fechaMargen"] = q.value("em_fechamargenprod"); 
		oMargen["horaMargen"] = q.value("em_horamargenprod");
		oMargen["idUsuarioMargen"] = q.value("em_idusuariomargenprod");
		oMargen["observMargen"] = q.value("em_observmargenprod");
		oMargen["origenMargen"] = "plantilla";
	} else {

		//1B. Plantilla alternativa
		var qPlanAlt = new AQSqlQuery;	
		qPlanAlt.setSelect("p.em_margenprod, p.em_fechamargenprod, p.em_horamargenprod, p.em_idusuariomargenprod, p.em_observmargenprod");
		qPlanAlt.setFrom("em_plantillasprod p INNER JOIN em_colecciones c ON p.codcoleccionem = c.codcoleccionplan");
		qPlanAlt.setWhere("c.codcoleccionem = '" + codColeccionEM + "' AND p.codsubfamilia = '" + codSubfamilia + "' AND p.codtamanoem = '" + codTamanoEM + "' AND p.codcolorem = '" + codColorEM + "' AND p.em_margenprod IS NOT NULL");	
		//debug("qPlanAlt: "+qPlanAlt.sql());
		if (!qPlanAlt.exec()){
			return;
		}  
		if(qPlanAlt.size() > 1) {
			if(!silent) {				
				formUI.ponMsgBox("No se puede heredar de la plantilla, hay varios costes candidatos para la colecci�n/subfamilia/tama�o/color","warn");	
			}
					
			return false;
		} else if (qPlanAlt.size() == 1) {
			if(!qPlanAlt.first()) {
				return false;
			}			
			oMargen["margen"] = qPlanAlt.value("p.em_margenprod");
			oMargen["fechaMargen"] = qPlanAlt.value("p.em_fechamargenprod"); 
			oMargen["horaMargen"] = qPlanAlt.value("p.em_horamargenprod");
			oMargen["idUsuarioMargen"] = qPlanAlt.value("p.em_idusuariomargenprod");
			oMargen["observMargen"] = qPlanAlt.value("p.em_observmargenprod");
			oMargen["origenMargen"] = "plantilla alternativa";		
			
		} else {

			//2. miramos por subfamilia/tama�o		
			var qTamSub = new AQSqlQuery;	
			qTamSub.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
			qTamSub.setFrom("em_tamanossubfam");
			qTamSub.setWhere("codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND em_margenprod IS NOT NULL");
			//debug("qTamSub: "+qTamSub.sql());
			if (!qTamSub.exec()){
				return;
			}  
			if(qTamSub.size() > 1) {		
				if(!silent) {	
					formUI.ponMsgBox("No se puede heredar, hay varios m�rgenes candidatos para la subfamilia/tama�o","warn");
				}
				return false;
			} else if (qTamSub.first()) {			
				oMargen["margen"] = qTamSub.value("em_margenprod");
				oMargen["fechaMargen"] = qTamSub.value("em_fechamargenprod"); 
				oMargen["horaMargen"] = qTamSub.value("em_horamargenprod");
				oMargen["idUsuarioMargen"] = qTamSub.value("em_idusuariomargenprod");
				oMargen["observMargen"] = qTamSub.value("em_observmargenprod");
				oMargen["origenMargen"] = "tama�os por subfamilia";
			} else {
				//3.Miramos por subfamilia			
				var qSub = new AQSqlQuery;	
				qSub.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
				qSub.setFrom("subfamilias");
				qSub.setWhere("codsubfamilia = '" + codSubfamilia +"' AND em_margenprod IS NOT NULL");
				//debug("qSub: "+qSub.sql());
				if (!qSub.exec()){
					return;
				}  
				if(qSub.first()) {					
					oMargen["margen"] = qSub.value("em_margenprod");
					oMargen["fechaMargen"] = qSub.value("em_fechamargenprod"); 
					oMargen["horaMargen"] = qSub.value("em_horamargenprod");
					oMargen["idUsuarioMargen"] = qSub.value("em_idusuariomargenprod");
					oMargen["observMargen"] = qSub.value("em_observmargenprod");
					oMargen["origenMargen"] = "subfamilia";

				} else {
					//4. Miramos por familia
					var qFam = new AQSqlQuery;	
					qFam.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
					qFam.setFrom("familias");
					qFam.setWhere("codfamilia = '" + codFamilia +"' AND em_margenprod IS NOT NULL");
					//debug("qFam: "+qFam.sql());
					if (!qFam.exec()){
						return;
					}  
					if(qFam.first()) {						
						oMargen["margen"] = qFam.value("em_margenprod");
						oMargen["fechaMargen"] = qFam.value("em_fechamargenprod"); 
						oMargen["horaMargen"] = qFam.value("em_horamargenprod");
						oMargen["idUsuarioMargen"] = qFam.value("em_idusuariomargenprod");
						oMargen["observMargen"] = qFam.value("em_observmargenprod");
						oMargen["origenMargen"] = "familia";

					} else {	
						if(!silent) {			
							formUI.ponMsgBox("No se ha encontrado el margen","warn");
						}
						return false;
					}
				}
			}
		}
	} 
	return oMargen;	

}


/*function euromoda_heredarMargenProd(cursor,alta)
{
	var usuario = sys.nameUser();
	var hoy = new Date();
	var hora = hoy.toString().right(8);
	var _i = this.iface;
	var margen = false;
	var fechaMargen = "";
	var horaMargen = "";
	var idUsuarioMargen = "";
	var observMargen = "";
	var origenMargen = "";
	//1. miraramos en plantilla de producto por coleccion-subfmailia-el tama�o-el color
	var codColeccionEM = cursor.valueBuffer("codcoleccionem");
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codTamanoEM = cursor.valueBuffer("codtamanoem");
	var codColorEM = cursor.valueBuffer("codcolorem");
	var codFamilia = cursor.valueBuffer("codfamilia"); 

	var q = new AQSqlQuery;	
	q.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
	q.setFrom("em_plantillasprod");
	q.setWhere("codcoleccionem = '" + codColeccionEM + "' AND codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND codcolorem = '" + codColorEM + "' AND em_margenprod IS NOT NULL");	
	//debug("q1: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.size() > 1) {	
		formUI.ponMsgBox("No se puede heredar de la plantilla, hay varios m�rgenes candidatos para la colecci�n/subfamilia/tama�o/color","warn");
		return false;
	} else if (q.first()) {		
		margen = q.value("em_margenprod");
		fechaMargen = q.value("em_fechamargenprod"); 
		horaMargen = q.value("em_horamargenprod");
		idUsuarioMargen = q.value("em_idusuariomargenprod");
		observMargen = q.value("em_observmargenprod");
		origenMargen = "plantilla";
	} else {
		//2. miramos por subfamilia/tama�o		
		var qTamSub = new AQSqlQuery;	
		qTamSub.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
		qTamSub.setFrom("em_tamanossubfam");
		qTamSub.setWhere("codsubfamilia = '" + codSubfamilia +"' AND codtamanoem = '" + codTamanoEM + "' AND em_margenprod IS NOT NULL");
		//debug("qTamSub: "+qTamSub.sql());
		if (!qTamSub.exec()){
			return;
		}  
		if(qTamSub.size() > 1) {			
			formUI.ponMsgBox("No se puede heredar, hay varios m�rgenes candidatos para la subfamilia/tama�o","warn");
			return false;
		} else if (qTamSub.first()) {			
			margen = qTamSub.value("em_margenprod");
			fechaMargen = qTamSub.value("em_fechamargenprod"); 
			horaMargen = qTamSub.value("em_horamargenprod");
			idUsuarioMargen = qTamSub.value("em_idusuariomargenprod");
			observMargen = qTamSub.value("em_observmargenprod");
			origenMargen = "tama�os por subfamilia";
		} else {
			//3.Miramos por subfamilia			
			var qSub = new AQSqlQuery;	
			qSub.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
			qSub.setFrom("subfamilias");
			qSub.setWhere("codsubfamilia = '" + codSubfamilia +"' AND em_margenprod IS NOT NULL");
			//debug("qSub: "+qSub.sql());
			if (!qSub.exec()){
				return;
			}  
			if(qSub.first()) {					
				margen = qSub.value("em_margenprod");
				fechaMargen = qSub.value("em_fechamargenprod"); 
				horaMargen = qSub.value("em_horamargenprod");
				idUsuarioMargen = qSub.value("em_idusuariomargenprod");
				observMargen = qSub.value("em_observmargenprod");
				origenMargen = "subfamilia";

			} else {
				//4. Miramos por familia
				var qFam = new AQSqlQuery;	
				qFam.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod, em_idusuariomargenprod, em_observmargenprod");
				qFam.setFrom("familias");
				qFam.setWhere("codfamilia = '" + codFamilia +"' AND em_margenprod IS NOT NULL");
				//debug("qFam: "+qFam.sql());
				if (!qFam.exec()){
					return;
				}  
				if(qFam.first()) {						
					margen = qFam.value("em_margenprod");
					fechaMargen = qFam.value("em_fechamargenprod"); 
					horaMargen = qFam.value("em_horamargenprod");
					idUsuarioMargen = qFam.value("em_idusuariomargenprod");
					observMargen = qFam.value("em_observmargenprod");
					origenMargen = "familia";

				} else {				
					formUI.ponMsgBox("No se ha encontrado el margen","warn");
					return true;
				}
			}
		}
	} 	
	if(margen) {
		margen = AQUtil.roundFieldValue(margen, "articulos", "em_margenprod");
		if(!alta) {
			formUI.ponMsgBox(sys.translate("Margen actualizado de valor %1 a %2").arg(AQUtil.formatoMiles(AQUtil.roundFieldValue(cursor.valueBuffer("em_margenprod"), "articulos","em_margenprod"))).arg(AQUtil.formatoMiles(margen)),"info");		
		}

		cursor.setValueBuffer("em_margenprod",margen);
		cursor.setValueBuffer("em_fechamargenprod",fechaMargen);
		cursor.setValueBuffer("em_horamargenprod",horaMargen.toString().right(8));
		cursor.setValueBuffer("em_idusuariomargenprod",idUsuarioMargen);
		cursor.setValueBuffer("em_observmargenprod",observMargen);
		cursor.setValueBuffer("em_origenmargen",origenMargen);		
		var aCampos = ["em_costeprod","em_fechacosteprod","em_horacosteprod","em_idusuariocosteprod","em_observcosteprod","referencia","em_tipocoste"];

		var oParam = new Object;
		oParam["gridasociado"] = "articulos";
		oParam["fechahis"] = hoy;
		oParam["horahis"] = hora;
		oParam["usuariohis"] = sys.nameUser();
		oParam["em_margenprod"] = margen;
		oParam["em_fechamargenprod"] = fechaMargen;
		oParam["em_horamargenprod"] = horaMargen.toString().right(8);
		oParam["em_idusuariomargenprod"] = idUsuarioMargen;
		oParam["em_observmargenprod"] = observMargen;			
		oParam["em_origenmargen"] = origenMargen;
		oParam["em_tipomargen"] = "Heredado";

		if(cursor.valueBuffer("em_tipocoste") == "Manual") {
			oParam["em_origencoste"] = "articulo";
		} else {
			oParam["em_origencoste"] = cursor.valueBuffer("em_origencoste");
		}

		for(var i=0;i<aCampos.length;i++) {
			oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);
		}

		if(!_i.insertaRegistroLog(oParam)) {
			return false;
		}
		cursor.setValueBuffer("em_tipomargen","Heredado");
	}
	return true;
}*/


function euromoda_insertaRegistroLog(oParam)
{
	//debug("\n\neuromoda_insertaRegistroLog 1");
	var _i = this.iface;	

	var gridAsociado = oParam["gridasociado"];

	if((gridAsociado == "plantillas" && formRecordem_plantillasprod.iface.actualizaHerencia_) || (gridAsociado == "tama�os por subfamilia" && formRecordem_tamanossubfam.iface.actualizaHerencia_) || (gridAsociado == "subfamilias" && formRecordsubfamilias.iface.actualizaHerencia_) || (gridAsociado == "familias" && formRecordfamilias.iface.actualizaHerencia_)) {
		//debug("euromoda_insertaRegistroLog 2");
		
		
	} else {
		//debug("\n\neuromoda_insertaRegistroLog 3");
		if(!_i.compruebaUltimoLog(oParam)) {	
			//debug("\n\neuromoda_insertaRegistroLog 4");	
			return true;
		}		
	}


	var aCamposGen = ["gridasociado","fechahis","horahis","usuariohis","em_margenprod","em_fechamargenprod","em_horamargenprod","em_idusuariomargenprod","em_observmargenprod"];

	
	if(gridAsociado == "articulos") {	
		//debug("\n\neuromoda_insertaRegistroLog 5");
		aCamposGen.push("referencia");
		aCamposGen.push("em_fechacosteprod");
		aCamposGen.push("em_horacosteprod");
		aCamposGen.push("em_costeprod");
		aCamposGen.push("em_idusuariocosteprod");
		aCamposGen.push("em_observcosteprod");
		aCamposGen.push("em_tipocoste");
		aCamposGen.push("em_origencoste");
		aCamposGen.push("em_tipomargen");
		aCamposGen.push("em_origenmargen");

	} else if(gridAsociado == "plantillas") {
		//debug("\n\neuromoda_insertaRegistroLog 6");
		aCamposGen.push("idplantilla");		
		aCamposGen.push("em_fechacosteprod");
		aCamposGen.push("em_horacosteprod");
		aCamposGen.push("em_costeprod");
		aCamposGen.push("em_idusuariocosteprod");
		aCamposGen.push("em_observcosteprod");
		aCamposGen.push("em_actcostes");
		aCamposGen.push("em_activarcostesher");	
		aCamposGen.push("em_actmargenes");
		aCamposGen.push("em_activarmargenher");	
	} else if(gridAsociado == "tama�os por subfamilia") {	
		//debug("\n\neuromoda_insertaRegistroLog 7");	
		aCamposGen.push("codsubfamilia");
		aCamposGen.push("codtamanoem");
		aCamposGen.push("em_fechacosteprod");
		aCamposGen.push("em_horacosteprod");
		aCamposGen.push("em_costeprod");
		aCamposGen.push("em_idusuariocosteprod");
		aCamposGen.push("em_observcosteprod");
		aCamposGen.push("em_actcostes");
		aCamposGen.push("em_activarcostesher");	
		aCamposGen.push("em_actmargenes");
		aCamposGen.push("em_activarmargenher");	
	} else if(gridAsociado == "subfamilias") {
		//debug("\n\neuromoda_insertaRegistroLog 8");
		aCamposGen.push("codsubfamilia");
		aCamposGen.push("em_fechacosteprod");
		aCamposGen.push("em_horacosteprod");
		aCamposGen.push("em_costeprod");
		aCamposGen.push("em_idusuariocosteprod");
		aCamposGen.push("em_observcosteprod");
		aCamposGen.push("em_actcostes");
		aCamposGen.push("em_activarcostesher");	
		aCamposGen.push("em_actmargenes");
		aCamposGen.push("em_activarmargenher");	

	} else if(gridAsociado == "familias") {
		//debug("\n\neuromoda_insertaRegistroLog 9");
		aCamposGen.push("codfamilia");
		aCamposGen.push("em_actmargenes");
		aCamposGen.push("em_activarmargenher");		
	}

	var campo;
	var valor;
	var curLog = new FLSqlCursor("em_logcostesmargenes");
	curLog.setActivatedCheckIntegrity(false);
	curLog.setActivatedCommitActions(false);
	curLog.setModeAccess(curLog.Insert);
  	curLog.refreshBuffer();    
	for(var i =0; i<aCamposGen.length;i++) {
		campo = aCamposGen[i];
		valor = oParam[campo];
		if(valor == "NULL") {
			curLog.setNull(campo);
		} else {
			curLog.setValueBuffer(campo,valor);
		}
	}
	if(!curLog.commitBuffer()) {	
		return false;
	}
	return true;
}

function euromoda_compruebaUltimoLog(oParam)
{	
	//debug("compruebaUltimoLog 1");
	var _i = this.iface;
	var margen = oParam["em_margenprod"];	
	var fechaMargen = oParam["em_fechamargenprod"];	
	var horaMargen = oParam["em_horamargenprod"];
	

	if(fechaMargen == "NULL") {
		fechaMargen = "";
	}	
	if(horaMargen == "NULL") {
		horaMargen = "";
	} else {
		horaMargen = horaMargen.toString().right(8);
		if (horaMargen == "00:00:00") {
			horaMargen = "";
		}
	}	
	var where = "";	
	//debug("compruebaUltimoLog 2");
	if(oParam["gridasociado"] == "articulos" || oParam["gridasociado"] == "tama�os por subfamilia" || oParam["gridasociado"] == "plantillas" || oParam["gridasociado"] == "subfamilias") {
		//debug("compruebaUltimoLog 3");
		var coste = oParam["em_costeprod"];
		var fechaCoste = oParam["em_fechacosteprod"];
		var horaCoste = oParam["em_horacosteprod"];
	
		if(fechaCoste == "NULL") {
			fechaCoste = "";
		}

		if(horaCoste == "NULL") {
			horaCoste = "";
		} else {
			horaCoste = horaCoste.toString().right(8);
			if (horaCoste == "00:00:00") {
				horaCoste = "";
			}
		}
		//debug("compruebaUltimoLog 4");
		if(oParam["gridasociado"] == "articulos") {
			where = "gridasociado = '" + oParam["gridasociado"] + "' AND referencia = '" + oParam["referencia"] + "' ORDER BY fechahis DESC, horahis DESC ";
			//debug("compruebaUltimoLog 5");
		} else if(oParam["gridasociado"] == "tama�os por subfamilia"){
			where = "gridasociado = '" + oParam["gridasociado"] + "' AND codsubfamilia = '" + oParam["codsubfamilia"] + "' AND codtamanoem = '" + oParam["codtamanoem"] + "' ORDER BY fechahis DESC, horahis DESC ";
			//debug("compruebaUltimoLog 6");
		} else if (oParam["gridasociado"] == "plantillas"){
			//debug("compruebaUltimoLog 7");
			where = "gridasociado = '" + oParam["gridasociado"] + "' AND idplantilla = " + oParam["idplantilla"] + " ORDER BY fechahis DESC, horahis DESC ";
		} else if (oParam["gridasociado"] == "subfamilias") {
			//debug("compruebaUltimoLog 8");
			where = "gridasociado = '" + oParam["gridasociado"] + "' AND codsubfamilia = '" + oParam["codsubfamilia"] + "' ORDER BY fechahis DESC, horahis DESC ";
		}
		
		
		var q = new AQSqlQuery;	
		q.setSelect("em_costeprod,em_fechacosteprod,em_horacosteprod,em_margenprod, em_fechamargenprod, em_horamargenprod,em_actmargenes, em_activarmargenher, em_actcostes,em_activarcostesher");
		q.setFrom("em_logcostesmargenes");
		q.setWhere(where);
		if (!q.exec()){			
			return;
		}
/*		debug("compruebaUltimoLog 6");
		debug("q: "+q.sql());*/
		if(!q.first()) {	
			//debug("devuelve true");		
			return true;
		}  	

		var costeLog = q.value("em_costeprod");
		var fechaCosteLog = q.value("em_fechacosteprod");
		var horaCosteLog = q.value("em_horacosteprod").toString().right(8);

		if(!fechaCosteLog || fechaCosteLog == "") {
			fechaCosteLog = "";
		}

		if(!horaCosteLog || horaCosteLog == "" || horaCosteLog == "00:00:00") {
			horaCosteLog = "";
		}


		var margenLog = q.value("em_margenprod");
		var fechaMargenLog = q.value("em_fechamargenprod");
		var horaMargenLog = q.value("em_horamargenprod").toString().right(8);
		

		if(!fechaMargenLog || fechaMargenLog == "") {
			fechaMargenLog = "";
		}

		if(!horaMargenLog || horaMargenLog == "" || horaMargenLog == "00:00:00") {
			horaMargenLog = "";
		}
		if(oParam["gridasociado"] != "articulos") {
			//debug("compruebaUltimoLog 9");
			var actMargenes = oParam["em_actmargenes"];
			var actMargenesLog = q.value("em_actmargenes");

			var actMargenHer = oParam["em_activarmargenher"];
			var actMargenHerLog = q.value("em_activarmargenher");

			var actCostes = oParam["em_actcostes"];
			var actCostesLog = q.value("em_actcostes");

			var actCostesHer = oParam["em_activarcostesher"];
			var actCostesHerLog = q.value("em_activarcostesher");


			if(actMargenes && !actMargenesLog) {
				//debug("compruebaUltimoLog 10");
				return true;
			}

			if(actMargenes && actMargenHer && !actMargenHerLog) {
				//debug("compruebaUltimoLog 11");
				return true;
			}


			if(actCostes && !actCostesLog) {
				//debug("compruebaUltimoLog 12");
				return true;
			}

			if(actCostes && actCostesHer && !actCostesHerLog) {
				//debug("compruebaUltimoLog 13");
				return true;
			}
		}		

		if(parseFloat(costeLog) == parseFloat(coste) && fechaCosteLog == fechaCoste && horaCosteLog == horaCoste && parseFloat(margenLog) == parseFloat(margen) && fechaMargenLog == fechaMargen && horaMargenLog == horaMargen) {
			//debug("compruebaUltimoLog 14");
			return false;
		}
	} else if(oParam["gridasociado"] == "familias") {
		
		where = "gridasociado = '" + oParam["gridasociado"] + "' AND codfamilia = '" + oParam["codfamilia"] + "' ORDER BY fechahis DESC, horahis DESC ";
		

		var q = new AQSqlQuery;	
		q.setSelect("em_margenprod, em_fechamargenprod, em_horamargenprod,em_actmargenes,em_activarmargenher");
		q.setFrom("em_logcostesmargenes");
		q.setWhere(where);
		if (!q.exec()){
			return;
		}
		if(!q.first()) {
			return true;
		} 	

	
		var margenLog = q.value("em_margenprod");
		var fechaMargenLog = q.value("em_fechamargenprod");
		var horaMargenLog = q.value("em_horamargenprod").toString().right(8);
		

		if(!fechaMargenLog || fechaMargenLog == "") {
			fechaMargenLog = "";
		}

		if(!horaMargenLog || horaMargenLog == "" || horaMargenLog == "00:00:00") {
			horaMargenLog = "";
		}

		var actMargenes = oParam["em_actmargenes"];
		var actMargenesLog = q.value("em_actmargenes");

		var actMargenHer = oParam["em_activarmargenher"];
		var actMargenHerLog = q.value("em_activarmargenher");
		if(actMargenes && !actMargenesLog) {
			return true;
		}

		if(actMargenes && actMargenHer && !actMargenHerLog) {
			return true;
		}

		if(parseFloat(margenLog) == parseFloat(margen) && fechaMargenLog == fechaMargen && horaMargenLog == horaMargen) {
			return false;
		}
	}


	return true;

}

function euromoda_ponDatosLogCostes(gridAsociado, cursor)
{
	//debug("euromoda_ponDatosLogCostes 1");
	var _i = this.iface;	

	var hoy = new Date();
	var hora = hoy.toString().right(8);

	var aCampos = [];
	var oParam = new Object;
	
	var aCampos = ["em_margenprod","em_fechamargenprod","em_horamargenprod","em_idusuariomargenprod","em_observmargenprod"];

	oParam["fechahis"] = hoy;
	oParam["horahis"] = hora;
	oParam["usuariohis"] = sys.nameUser();	
	oParam["gridasociado"] = gridAsociado;	
	if(gridAsociado == "articulos" || gridAsociado =="articulosNew") {
		//debug("euromoda_ponDatosLogCostes 2");	
		aCampos.push("referencia");
		aCampos.push("em_fechacosteprod");
		aCampos.push("em_horacosteprod");
		aCampos.push("em_costeprod");
		aCampos.push("em_idusuariocosteprod");
		aCampos.push("em_observcosteprod");
		aCampos.push("em_tipocoste");		
		aCampos.push("em_tipomargen");	

		if(cursor.valueBuffer("em_tipocoste") == "Manual") {
			oParam["em_origencoste"] = "articulo";
		} else {
			oParam["em_origencoste"] = cursor.valueBuffer("em_origencoste");
		}

		if(cursor.valueBuffer("em_tipomargen") == "Manual") {
			oParam["em_origenmargen"] = "articulo";
		} else {
			oParam["em_origenmargen"] = cursor.valueBuffer("em_origenmargen");
		}
			
		//oParam["em_origencoste"] = "articulo";		
		//oParam["em_origenmargen"] = "articulo";

		if(gridAsociado == "articulos") {			
			if ((!flfactalma.iface.hayCambioMargenProd(cursor) && !flfactalma.iface.hayCambioCosteProd(cursor)) || _i.pulsaHeredar_) {	
				return true;
			}	
		}
		oParam["gridasociado"] = "articulos";

	} else if(gridAsociado == "plantillas") {
		//debug("euromoda_ponDatosLogCostes 3");
		aCampos.push("idplantilla");

		aCampos.push("em_fechacosteprod");
		aCampos.push("em_horacosteprod");
		aCampos.push("em_costeprod");
		aCampos.push("em_idusuariocosteprod");
		aCampos.push("em_observcosteprod");	

		aCampos.push("em_activarcostesher");		
		aCampos.push("em_activarmargenher");

		oParam["em_actcostes"] = false;
		oParam["em_actmargenes"] = false;

		if (!flfactalma.iface.hayCambioMargenProd(cursor) && !flfactalma.iface.hayCambioCosteProd(cursor)) {	
			return true;
		}	

	} else if(gridAsociado == "tama�os por subfamilia") {
		//debug("euromoda_ponDatosLogCostes 4");
		aCampos.push("codsubfamilia");
		aCampos.push("codtamanoem");

		aCampos.push("em_fechacosteprod");
		aCampos.push("em_horacosteprod");
		aCampos.push("em_costeprod");
		aCampos.push("em_idusuariocosteprod");
		aCampos.push("em_observcosteprod");	

		aCampos.push("em_activarcostesher");		
		aCampos.push("em_activarmargenher");	

		oParam["em_actcostes"] = false;
		oParam["em_actmargenes"] = false;

		if (!flfactalma.iface.hayCambioMargenProd(cursor) && !flfactalma.iface.hayCambioCosteProd(cursor)) {	
			return true;
		}

	} else if(gridAsociado == "subfamilias") {
		//debug("euromoda_ponDatosLogCostes 5");
		aCampos.push("codsubfamilia");

		aCampos.push("em_fechacosteprod");
		aCampos.push("em_horacosteprod");
		aCampos.push("em_costeprod");
		aCampos.push("em_idusuariocosteprod");
		aCampos.push("em_observcosteprod");

		aCampos.push("em_activarcostesher");
		aCampos.push("em_activarmargenher");

		oParam["em_actcostes"] = false;
		oParam["em_actmargenes"] = false;

		if (!flfactalma.iface.hayCambioMargenProd(cursor) && !flfactalma.iface.hayCambioCosteProd(cursor)) {
			//debug("euromoda_ponDatosLogCostes 6");
			return true;
		}
		//debug("euromoda_ponDatosLogCostes 7");
	} else if(gridAsociado == "familias") {
		aCampos.push("codfamilia");
		//aCampos.push("em_actmargenes");
		aCampos.push("em_activarmargenher");
		oParam["em_actmargenes"] = false;
		if (!flfactalma.iface.hayCambioMargenProd(cursor)) {	
			return true;
		}

	}

	for(var i = 0; i<aCampos.length;i++) {

		if(cursor.isNull(aCampos[i])) {
			oParam[aCampos[i]] = "NULL";	
		} else {
			oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);
		}		
	}
	if(!_i.insertaRegistroLog(oParam)) {		
		return false;
	}	
	return true;
}

function euromoda_tbwArticulo_currentChanged(nombre) 
{
	var _i = this.iface;
	if (nombre == "costesinv") {
		//_i.cargaDatosLogCostes();
	}
}

function euromoda_heredarCosteMargenProd(cursor, silent)
{
	var _i = this.iface;
	var usuario = sys.nameUser();
	var hoy = new Date();
	var hora = hoy.toString().right(8);
	var hayCostes = false;
	var hayMargenes = false;

	var costeActual = cursor.valueBuffer("em_costeprod");
	var costeMargen = cursor.valueBuffer("em_margenprod");
	var coste;
	var margen;
	
	var oCostes = _i.dameCosteProd(cursor, silent);		
	var oMargen = _i.dameMargenProd(cursor, silent);
	

	var oParam = new Object;
	oParam["gridasociado"] = "articulos";
	oParam["fechahis"] = hoy;
	oParam["horahis"] = hora;
	oParam["usuariohis"] = sys.nameUser();
	

	if(oCostes && "coste" in oCostes && oCostes["coste"]) {
		coste = oCostes["coste"];
		coste = AQUtil.roundFieldValue(coste, "articulos", "em_costeprod");		

		cursor.setValueBuffer("em_costeprod",coste);
		cursor.setValueBuffer("em_fechacosteprod",oCostes["fechaCoste"]);
		cursor.setValueBuffer("em_horacosteprod",oCostes["horaCoste"].toString().right(8));
		cursor.setValueBuffer("em_idusuariocosteprod",oCostes["idUsuarioCoste"]);
		cursor.setValueBuffer("em_observcosteprod",oCostes["observCoste"]);
		cursor.setValueBuffer("em_origencoste",oCostes["origenCoste"]);

		hayCostes = true;

	}
	if(oMargen && "margen" in oMargen && oMargen["margen"]) {
		margen = oMargen["margen"];
		margen = AQUtil.roundFieldValue(margen, "articulos", "em_margenprod");

		cursor.setValueBuffer("em_margenprod", margen);
		cursor.setValueBuffer("em_fechamargenprod",oMargen["fechaMargen"]);
		cursor.setValueBuffer("em_horamargenprod",oMargen["horaMargen"].toString().right(8));
		cursor.setValueBuffer("em_idusuariomargenprod",oMargen["idUsuarioMargen"]);
		cursor.setValueBuffer("em_observmargenprod",oMargen["observMargen"]);
		cursor.setValueBuffer("em_origenmargen",oMargen["origenMargen"]);		

		hayMargenes = true;

	}

	if(hayCostes && hayMargenes) {
		oParam["em_costeprod"] = coste;
		oParam["em_fechacosteprod"] = oCostes["fechaCoste"];
		oParam["em_horacosteprod"] = oCostes["horaCoste"].toString().right(8);
		oParam["em_idusuariocosteprod"] = oCostes["idUsuarioCoste"];
		oParam["em_observcosteprod"] = oCostes["observCoste"];		
		oParam["em_origencoste"] = oCostes["origenCoste"];		
		oParam["em_tipocoste"] = "Heredado";	
		if(cursor.valueBuffer("em_tipomargen") == "Manual") {
			oParam["em_origenmargen"] = "articulo";
		} else {
			oParam["em_origenmargen"] = cursor.valueBuffer("em_origenmargen");
		}
		oParam["em_margenprod"] = oMargen["margen"];
		oParam["em_fechamargenprod"] = oMargen["fechaMargen"];
		oParam["em_horamargenprod"] = oMargen["horaMargen"].toString().right(8);
		oParam["em_idusuariomargenprod"] = oMargen["idUsuarioMargen"];
		oParam["em_observmargenprod"] = oMargen["observMargen"];			
		oParam["em_origenmargen"] = oMargen["origenMargen"];
		oParam["em_tipomargen"] = "Heredado";
		oParam["referencia"] = cursor.valueBuffer("referencia");

		if(!_i.insertaRegistroLog(oParam)) {
			return false;
		}	
		cursor.setValueBuffer("em_tipocoste","Heredado");
		cursor.setValueBuffer("em_tipomargen","Heredado");

	} else if(hayCostes) {

		var aCampos = ["em_margenprod","em_fechamargenprod","em_horamargenprod","em_idusuariomargenprod","em_observmargenprod","referencia","em_tipomargen"];

		oParam["em_costeprod"] = coste;
		oParam["em_fechacosteprod"] = oCostes["fechaCoste"];
		oParam["em_horacosteprod"] = oCostes["horaCoste"].toString().right(8);
		oParam["em_idusuariocosteprod"] = oCostes["idUsuarioCoste"];
		oParam["em_observcosteprod"] = oCostes["observCoste"];		
		oParam["em_origencoste"] = oCostes["origenCoste"];		
		oParam["em_tipocoste"] = "Heredado";	

		if(cursor.valueBuffer("em_tipomargen") == "Manual") {
			oParam["em_origenmargen"] = "articulo";
		} else {
			oParam["em_origenmargen"] = cursor.valueBuffer("em_origenmargen");
		}

		for(var i=0;i<aCampos.length;i++) {
			if(cursor.isNull(aCampos[i])) {
				oParam[aCampos[i]] = "NULL";	
			} else {
				oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);	
			}
		}		
		if(!_i.insertaRegistroLog(oParam)) {
			return false;
		}
		cursor.setValueBuffer("em_tipocoste","Heredado");


	} else if(hayMargenes) {

		var aCampos = ["em_costeprod","em_fechacosteprod","em_horacosteprod","em_idusuariocosteprod","em_observcosteprod","referencia","em_tipocoste"];

		oParam["em_margenprod"] = margen
		oParam["em_fechamargenprod"] = oMargen["fechaMargen"];
		oParam["em_horamargenprod"] = oMargen["horaMargen"].toString().right(8);
		oParam["em_idusuariomargenprod"] = oMargen["idUsuarioMargen"];
		oParam["em_observmargenprod"] = oMargen["observMargen"];			
		oParam["em_origenmargen"] = oMargen["origenMargen"];
		oParam["em_tipomargen"] = "Heredado";

		if(cursor.valueBuffer("em_tipocoste") == "Manual") {
			oParam["em_origencoste"] = "articulo";
		} else {
			oParam["em_origencoste"] = cursor.valueBuffer("em_origencoste");
		}
		for(var i=0;i<aCampos.length;i++) {
			if(cursor.isNull(aCampos[i])) {
				oParam[aCampos[i]] = "NULL";	
			} else {
				oParam[aCampos[i]] = cursor.valueBuffer(aCampos[i]);	
			}			
		}		
		if(!_i.insertaRegistroLog(oParam)) {
			return false;
		}	
		cursor.setValueBuffer("em_tipomargen","Heredado");
	}
	return true;

}

function euromoda_columnasCompras()
{
	return ["fecha", "codigo", "codproveedor", "nombre", "pvpunitario", "cantidad", "pvpsindto", "pvptotal"];
}

function euromoda_tdbEmUbicaciones_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEditUbiAlt_clicked();
}


function euromoda_toolButtonInsertUbiAlt_clicked()
{
	var _i = this.iface;
	_i.accionCursorExternoUbiAlt("insert");
}

function euromoda_toolButtonEditUbiAlt_clicked()
{
	var _i = this.iface;
	_i.accionCursorExternoUbiAlt("edit");
}

function euromoda_toolButtonDeleteUbiAlt_clicked()
{
	var _i = this.iface;

	var res = flfactppal.iface.preguntaMsg(sys.translate("El registro activo ser� borrado �Desea continuar?"),"info",this,MessageBox.Yes, MessageBox.No);  
	if (res != MessageBox.Yes) {
		return;
	}
	_i.accionCursorExternoUbiAlt("del");
}

function euromoda_toolButtonZoomUbiAlt_clicked()
{
	var _i = this.iface;
	_i.accionCursorExternoUbiAlt("browse");
}

function euromoda_accionCursorExternoUbiAlt(accion)
{
	debug("euromoda_accionCursorExternoUbiAlt");
	var _i = this.iface;
	var cursor = this.cursor();
	var curTabla = this.child("tdbEmUbicaciones").cursor();
	if (_i.curUbiAlt_) {
		disconnect(_i.curUbiAlt_, "commited()", _i, "refrescaTablaUbiAlt");
		disconnect(_i.curUbiAlt_, "commited()", _i, "curUbiAlt_bufferCommited");
		_i.curUbiAlt_ = undefined;
	}
	
	_i.curUbiAlt_ = new FLSqlCursor("em_articulosxubicacion");
	//_i.curUbiAlt_.setAction("em_articulosxubicacion");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {			
			debug("curTabla.primaryKey(): "+curTabla.primaryKey());
			debug("******" +curTabla.valueBuffer(curTabla.primaryKey()));
			_i.curUbiAlt_.select(curTabla.primaryKey() + " = " + curTabla.valueBuffer(curTabla.primaryKey()));
			if (!_i.curUbiAlt_.first()) {
				debug("no lo encuentra");
				return false;
			}
		}
	}	
	switch (accion) {
		case "insert": {
			formRecordem_articulosxubicacion.iface.referencia_ = cursor.valueBuffer("referencia");
			connect(_i.curUbiAlt_, "commited()", _i, "curUbiAlt_bufferCommited");
			_i.curUbiAlt_.insertRecord();
			_i.curUbiAlt_.setValueBuffer("referencia",cursor.valueBuffer("referencia"));
			break;
		}
		case "edit": {
			connect(_i.curUbiAlt_, "commited()", _i, "curUbiAlt_bufferCommited");			
			_i.curUbiAlt_.editRecord();				
			break;
		}
		case "del": {
			
			_i.curUbiAlt_.setModeAccess(_i.curUbiAlt_.Del);
 			_i.curUbiAlt_.refreshBuffer(); 
 			if(!_i.curUbiAlt_.commitBuffer()) {
 				return false;
 			}
 			_i.refrescaTablaUbiAlt();
			break;
		}
		case "browse": {	
			_i.curUbiAlt_.browseRecord();
			break;
		}
	}
}

function euromoda_curUbiAlt_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	this.child("tdbEmUbicaciones").refresh();
	var dtbLC = this.mainWidget().child("tdbEmUbicaciones").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);	
	var pos = cursor.atFromBinarySearch("id", _i.pK_, asc);	
	cursor.seek(pos);
	cursor.refresh()
}

function euromoda_refrescaTablaUbiAlt()
{
	var _i = this.iface;
	var cursor = this.cursor();
	this.child("tdbEmUbicaciones").refresh();
}

function euromoda_tbnUbicacionActual_clicked()
{
	var cursor = this.cursor();
	var curUbi = this.child("tdbEmUbicaciones").cursor();
	var idUbi = curUbi.valueBuffer("id");
	if (!idUbi) {
		return;
	}
	var codUbicacionAct = curUbi.valueBuffer("em_ubialternativa");
	if (!AQSql.update("em_articulosxubicacion", ["actual"], [false], "referencia = '" + cursor.valueBuffer("referencia") + "'")) {
		return false;
	}
	if (!AQSql.update("em_articulosxubicacion", ["actual"], [true], "id= " + idUbi)) {
		return false;
	}
	this.child("tdbEmUbicaciones").refresh();
	sys.setObjText(this, "fdbEmUbiActual", codUbicacionAct);
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
