
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function tbnVencimiento_clicked() {
		return this.ctx.euromoda_tbnVencimiento_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	connect(this.child("tbnVencimiento"), "clicked()", _i, "tbnVencimiento_clicked");
	}

function euromoda_tbnVencimiento_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var curR = this.child("tdbRecibos").cursor();
	var idRecibo = curR.valueBuffer("idrecibo");
	if (!idRecibo) {
		return;
	}
	var dialog = new Dialog;
	dialog.okButtonText = sys.translate("Aceptar");
	dialog.cancelButtonText = sys.translate("Cancelar");

	var dedFecha = new DateEdit;
	dedFecha.label = sys.translate("Fecha de vencimineto");
	dedFecha.date = new Date;
	dialog.add(dedFecha);
	if ( !dialog.exec() ) {
		return false;
	}	
	var fecha = dedFecha.date;
	if (!AQSql.update("reciboscli", ["fechav"], [fecha], "idrecibo = " + idRecibo)) {
		return false;
	}
	this.child("tdbRecibos").refresh();
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
