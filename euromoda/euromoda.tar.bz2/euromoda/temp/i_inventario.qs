
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function habilitarPorEmTipo() {
		return this.ctx.euromoda_habilitarPorEmTipo();
	}
	function tbnLimpiarFiltro_clicked() {
		return this.ctx.euromoda_tbnLimpiarFiltro_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();

	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");

	_i.habilitarPorEmTipo();
}

function euromoda_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	formem_filtrosarticulos.iface.pub_limpiarFiltro(this);
	this.child("fdbNecesidad").setValue("Todos");
}

function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();

	switch(fN){
		case "emtipo": {
			_i.habilitarPorEmTipo();
			break;
		}
		case "coddibestamp":{
			cursor.setValueBuffer("dibujos", cursor.valueBuffer("coddibestamp"));
			break;
		}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_habilitarPorEmTipo()
{
	var _i = this.iface;
	var cursor = this.cursor();

	switch (cursor.valueBuffer("emtipo")) {
		case "Informe necesidades confecci�n":  {
			this.child("fdbEmDesdeCan").setDisabled(false);
			this.child("fdbEmHastaCan").setDisabled(false);
			sys.disableObj(this, "fdbActual");
			sys.disableObj(this, "fdbAFecha");
			sys.disableObj(this, "fdbIncluirSinStock");
			this.child("fdbAgrupacion").setDisabled(true);
			this.child("fdbAgrupacion").setValue("No agrupar");
			this.child("fdbNecesidad").setDisabled(true);
			this.child("fdbNecesidad").setValue("Todos");
			this.child("fdbDescatalogado").setDisabled(true);
			this.child("fdbDescatalogado").setValue("Todos");
			this.child("fdbDeBaja").setDisabled(true);
			this.child("fdbDeBaja").setValue("Todos");
			this.child("fdbaLiquidar").setDisabled(true);
			this.child("fdbaLiquidar").setValue("Todos");
			this.child("fdbEmOcultar0").setDisabled(true);
			this.child("fdbEmOcultar0").setValue(false);
			break;
		}
		case "Informe necesidades": {
			this.child("fdbEmDesdeCan").setValue("");
			this.child("fdbEmHastaCan").setValue("");
			this.child("fdbEmDesdeCan").setDisabled(true);
			this.child("fdbEmHastaCan").setDisabled(true);
			sys.disableObj(this, "fdbActual");
			sys.disableObj(this, "fdbAFecha");
			sys.disableObj(this, "fdbIncluirSinStock");
			this.child("fdbAgrupacion").setDisabled(false);
			this.child("fdbNecesidad").setDisabled(false);
			this.child("fdbDescatalogado").setDisabled(false);
			this.child("fdbDeBaja").setDisabled(false);
			this.child("fdbaLiquidar").setDisabled(false);
			this.child("fdbEmOcultar0").setDisabled(false);
			break;
		}
		case "Inventario valorado": {
			this.child("fdbEmDesdeCan").setValue("");
			this.child("fdbEmHastaCan").setValue("");
			this.child("fdbEmDesdeCan").setDisabled(true);
			this.child("fdbEmHastaCan").setDisabled(true);
			sys.enableObj(this, "fdbActual");
			this.child("fdbActual").setValue(true);
			sys.disableObj(this, "fdbAFecha");
			sys.enableObj(this, "fdbIncluirSinStock");
			this.child("fdbAgrupacion").setDisabled(false);
			this.child("fdbNecesidad").setDisabled(true);
			this.child("fdbNecesidad").setValue("Todos");
			this.child("fdbDescatalogado").setDisabled(false);
			this.child("fdbDeBaja").setDisabled(false);
			this.child("fdbaLiquidar").setDisabled(false);
			this.child("fdbEmOcultar0").setDisabled(true);
			this.child("fdbEmOcultar0").setValue(false);
			break;
		}
		default: {
			this.child("fdbEmDesdeCan").setValue("");
			this.child("fdbEmHastaCan").setValue("");
			this.child("fdbEmDesdeCan").setDisabled(true);
			this.child("fdbEmHastaCan").setDisabled(true);
			sys.enableObj(this, "fdbActual");
			sys.disableObj(this, "fdbAFecha");
			sys.enableObj(this, "fdbIncluirSinStock");
			this.child("fdbAgrupacion").setDisabled(true);
			this.child("fdbAgrupacion").setValue("No agrupar");
			this.child("fdbNecesidad").setDisabled(true);
			this.child("fdbNecesidad").setValue("Todos");
			this.child("fdbDescatalogado").setDisabled(true);
			this.child("fdbDescatalogado").setValue("Todos");
			this.child("fdbDeBaja").setDisabled(true);
			this.child("fdbDeBaja").setValue("Todos");
			this.child("fdbaLiquidar").setDisabled(true);
			this.child("fdbaLiquidar").setValue("Todos");
			this.child("fdbEmOcultar0").setDisabled(true);
			this.child("fdbEmOcultar0").setValue(false);
			break;
		}
	}
}

//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////