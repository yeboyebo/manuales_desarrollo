/***************************************************************************
                 em_cambiocompolant.qs  -  description
                             -------------------
    begin                : lun abr 17 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function calculateField(fN) {
		return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	
	var ordenFT_;
	function oficial( context ) { interna( context ); } 
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function pbnAplicar_clicked() {
		return this.ctx.oficial_pbnAplicar_clicked();
	}
	function cambiaComponente(oParam) {
		return this.ctx.oficial_cambiaComponente(oParam);
	}
	function iniciaFiltros() {
		return this.ctx.oficial_iniciaFiltros();
	}
	function pbnBuscar_clicked() {
		return this.ctx.oficial_pbnBuscar_clicked();
	}
	/*function tbnLimpiarFiltro_clicked() {
		return this.ctx.oficial_tbnLimpiarFiltro_clicked();
	}*/
	function pbnPlantilla_clicked() {
		return this.ctx.oficial_pbnPlantilla_clicked();
	}
	function controlAccion() {
		return this.ctx.oficial_controlAccion();
	}
	function filtroCompenentePrev() {
		return this.ctx.oficial_filtroCompenentePrev();
	}
	function filtroCompenenteNuevo() {
		return this.ctx.oficial_filtroCompenenteNuevo();
	}
	function aniadeComponente(oParam) {
		return this.ctx.oficial_aniadeComponente(oParam);
	}
	function quitaComponente(oParam) {
		return this.ctx.oficial_quitaComponente(oParam);
	}
	function filtroOrden() {
		return this.ctx.oficial_filtroOrden();
	}
	function tdbPlantillas_recordChoosed() {
		return this.ctx.oficial_tdbPlantillas_recordChoosed();
	}
	function dameFiltro(cursor) {
		return this.ctx.oficial_dameFiltro(cursor);
	}
	function dimeOrdenCompoNuevo() {
		return this.ctx.oficial_dimeOrdenCompoNuevo();
	}
	function dameDescCompoNuevo(idLinea) {
		return this.ctx.oficial_dameDescCompoNuevo(idLinea);
	}
	function dameFiltrolinea(q) {
		return this.ctx.oficial_dameFiltrolinea(q);
	}
	function datosLineasPlantilla(curLineaPlantilla,curOrigen) {
		return this.ctx.oficial_datosLineasPlantilla(curLineaPlantilla,curOrigen);
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	connect(this.child("pbnAplicar"), "clicked()", _i, "pbnAplicar_clicked");
	connect(this.child("pbnBuscar"), "clicked()", _i, "pbnBuscar_clicked");
	//connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("pbnPlantilla"), "clicked()", _i, "pbnPlantilla_clicked");
	connect(this.child("tdbPlantillas").cursor(), "recordChoosed()", _i, "tdbPlantillas_recordChoosed");
	
	//sys.disableObj(this, "fdbRefComponente");
	_i.iniciaFiltros();
	_i.controlAccion();
}

function interna_calculateField(fN)
{

	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "matftec": {
			var refCompuesto = cursor.valueBuffer("refftec");
			var orden = cursor.valueBuffer("ordenftec");
			if(refCompuesto && refCompuesto != "" && orden) {
				valor = AQUtil.sqlSelect("articuloscomp","refcomponente","refcompuesto = '" + refCompuesto + "' and orden = " + orden);
				if(!valor) {
					valor = "";
				}
			} else {
				valor = "";
			} 
			
			break;
		}		
		default: {
			valor = 0;
		}
	}
	return valor;
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_pbnAplicar_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();		
	var accion = cursor.valueBuffer("accion"); 

	switch (accion) {
		case "A�adir": {
			//var filtroA = this.child("tdbPlantillas").cursor().mainFilter();
			var tama = this.child("tdbPlantillas").cursor().size();
			if (tama == 0) {
				sys.warnMsgBox(sys.translate("Debe realizar una b�squeda antes de realizar el cambio"));
				return false;
			}

			var idPlantillaNueva = cursor.valueBuffer("idplantillanueva");
 			if(!idPlantillaNueva || idPlantillaNueva =="") {
				sys.warnMsgBox(sys.translate("El campo 'Plantilla de referencia nueva' es obligatorio."));
				return false;
			}

			var idLineaNueva = cursor.valueBuffer("idlineanueva");
 			if(!idLineaNueva || idLineaNueva =="") {
				sys.warnMsgBox(sys.translate("El campo 'Componente de referencia nuevo' es obligatorio."));
				return false;
			}
			
			var orden = cursor.valueBuffer("ordennuevo");
 			if(!orden || orden =="") {
				sys.warnMsgBox(sys.translate("El campo 'Posici�n componente nuevo' es un campo obligatorio."));
				return false;
			}
			
			var oParam = new Object;		
			oParam.errorMsg = sys.translate("Error al a�adir el componente");
			oParam.numCambios = 0;
			oParam.idPlantilla  = idPlantillaNueva;
			oParam.idLineaNueva = idLineaNueva;
			oParam.orden = orden;
			var f = new Function("oParam", "return formRecordem_cambiocompoplant.iface.aniadeComponente(oParam)");
			if (!sys.runTransaction(f, oParam)) {
				return false;
			}
			flfactppal.iface.ponMsgError(sys.translate("Se ha a�adido el componente %1 a %2 plantillas.").arg(cursor.valueBuffer("desclineanueva")).arg(oParam.numCambios),"info",this);	
			break;
		}

		case "Cambiar": {

			var tama = this.child("tdbPlantillas").cursor().size();
			if (tama == 0) {
				sys.warnMsgBox(sys.translate("Debe realizar una b�squeda antes de realizar el cambio"));
				return false;
			}

			var idPlantillaPrevia = cursor.valueBuffer("idplantillaprevia");
 			if(!idPlantillaPrevia || idPlantillaPrevia =="") {
				sys.warnMsgBox(sys.translate("El campo 'Plantilla de referencia previa' es obligatorio."));
				return false;
			}

			var idLineaPrevia = cursor.valueBuffer("idlineaprevia");
 			if(!idLineaPrevia || idLineaPrevia =="") {
				sys.warnMsgBox(sys.translate("El campo 'Componente de referencia previa' es obligatorio."));
				return false;
			}

			var idPlantillaNueva = cursor.valueBuffer("idplantillanueva");
 			if(!idPlantillaNueva || idPlantillaNueva =="") {
				sys.warnMsgBox(sys.translate("El campo 'Plantilla de referencia nueva' es obligatorio."));
				return false;
			}

			var idLineaNueva = cursor.valueBuffer("idlineanueva");
 			if(!idLineaNueva || idLineaNueva =="") {
				sys.warnMsgBox(sys.translate("El campo 'Componente de referencia nuevo' es obligatorio."));
				return false;
			}

			var filtroA = this.child("tdbPlantillas").cursor().mainFilter();
			if (filtroA == "") {
				sys.warnMsgBox(sys.translate("Debe buscar los art�culos antes de realizar el cambio"));
				return false;
			}

			var oParam = new Object;
			oParam.idPlantillaPrevia  = idPlantillaPrevia;
			oParam.idLineaPrevia = idLineaPrevia;
			oParam.idPlantillaNueva  = idPlantillaNueva;
			oParam.idLineaNueva = idLineaNueva;
			oParam.errorMsg = sys.translate("Error al cambiar el componente");
			oParam.numCambios = 0;
			var f = new Function("oParam", "return formRecordem_cambiocompoplant.iface.cambiaComponente(oParam)");
			if (!sys.runTransaction(f, oParam)) {
				return false;
			}
			flfactppal.iface.ponMsgError(sys.translate("Se han cambiado %1 plantillas.").arg(oParam.numCambios),"info",this);	
			

			break;
		}

		case "Quitar": {
			var tama = this.child("tdbPlantillas").cursor().size();
			if (tama == 0) {
				sys.warnMsgBox(sys.translate("Debe realizar una b�squeda antes de realizar el cambio"));
				return false;
			}

			var idPlantillaPrevia = cursor.valueBuffer("idplantillaprevia");
 			if(!idPlantillaPrevia || idPlantillaPrevia =="") {
				sys.warnMsgBox(sys.translate("El campo 'Plantilla de referencia previa' es obligatorio."));
				return false;
			}

			var idLineaPrevia = cursor.valueBuffer("idlineaprevia");
 			if(!idLineaPrevia || idLineaPrevia =="") {
				sys.warnMsgBox(sys.translate("El campo 'Componente de referencia previo' es obligatorio."));
				return false;
			}
			var oParam = new Object;						
			oParam.errorMsg = sys.translate("Error al quitar el componente");
			oParam.numCambios = 0;
			oParam.idPlantillaPrevia  = idPlantillaPrevia;
			oParam.idLineaPrevia = idLineaPrevia;
			var f = new Function("oParam", "return formRecordem_cambiocompoplant.iface.quitaComponente(oParam)");
			if (!sys.runTransaction(f, oParam)) {
				return false;
			}
			flfactppal.iface.ponMsgError(sys.translate("Se ha quitado el componente %1 a %2 plantillas.").arg(cursor.valueBuffer("desclineaprevia")).arg(oParam.numCambios),"info",this);			
		
			break;
		}
	
	}


}

function oficial_cambiaComponente(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var cambios = 0;
	var idPlantillaPrevia = oParam.idPlantillaPrevia;
	var idLineaPrevia = oParam.idLineaPrevia;

	var idPlantillaNueva = oParam.idPlantillaNueva;
	var idLineaNueva = oParam.idLineaNueva;


	var filtroA = this.child("tdbPlantillas").cursor().mainFilter();	


	var curNuevo = new FLSqlCursor("em_lineasplantillaprod");
	curNuevo.select("idplantilla = " + idPlantillaNueva + " and idlinea = " + idLineaNueva);
	if(!curNuevo.first()) {
		return false;
	}
	curNuevo.setModeAccess(curNuevo.Browse);
	curNuevo.refreshBuffer();


	var q = new AQSqlQuery;	
	q.setSelect("tipo,dibujo,emcodcomponente,componormal,refcomponente,codtamanocont,codtamanopanot,codcolorem,codsubfamilia");
	q.setFrom("em_lineasplantillaprod");
	q.setWhere("idlinea = " + idLineaPrevia); 			
	if (!q.exec()){
		return;
	} 	
	var p = 0;	
	if(q.first())
	{
		
		var filtroL = _i.dameFiltrolinea(q);
		
		var qPlan = new AQSqlQuery;	
		qPlan.setSelect("idplantilla");
		qPlan.setFrom("em_plantillasprod");
		qPlan.setWhere(filtroA); 			
		if (!qPlan.exec()){
			return;
		}  		
		AQUtil.createProgressDialog(sys.translate("Quitando componente a plantillas..."), qPlan.size());
		
		while(qPlan.next())
		{
			
			var idPlantilla = qPlan.value("idplantilla");			
			AQUtil.setProgress(++p);
			var curLineaPlantilla = new FLSqlCursor("em_lineasplantillaprod");
			curLineaPlantilla.setActivatedCommitActions(false);
			curLineaPlantilla.setActivatedCheckIntegrity(false);		
			curLineaPlantilla.select("idplantilla = " + idPlantilla +  " AND " + filtroL);
			
			while(curLineaPlantilla.next())
			{							
				curLineaPlantilla.setModeAccess(curLineaPlantilla.Edit);
				curLineaPlantilla.refreshBuffer();						  
				_i.datosLineasPlantilla(curLineaPlantilla,curNuevo);

				if (!curLineaPlantilla.commitBuffer()) {
					AQUtil.destroyProgressDialog();
					oParam.errorMsg = sys.translate("scripts", "Error al cambiar el componente %1 de la plantilla %2").arg(curLineaPlantilla.valueBuffer("idlinea")).arg(qPlan.value("idplantilla"));
					return false;
				}	
				cambios++;		
	  		}	
  		}
	}
	AQUtil.destroyProgressDialog();
	oParam.numCambios = cambios;
	return true;
}

function oficial_iniciaFiltros()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtroTabla = "";
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbIdUsuario", sys.nameUser());			
			filtroTabla = "1=2";
			break;
		}
		case cursor.Edit: {
			filtroTabla = _i.dameFiltro(cursor);
			break;
		}
	}	
	this.child("tdbPlantillas").cursor().setMainFilter(filtroTabla);
	this.child("tdbPlantillas").refresh();
}

function oficial_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  
	switch (fN) {
		case "idlineanueva": {
			this.child("fdbDesCompoNuevo").setValue(_i.dameDescCompoNuevo(cursor.valueBuffer("idlineanueva")));
			this.child("fdbOrdenNuevo").setValue(_i.dimeOrdenCompoNuevo());			
			break;
		}
		case "idlineaprevia": {
			this.child("fdbDesCompoPrevio").setValue(_i.dameDescCompoNuevo(cursor.valueBuffer("idlineaprevia")));			
			break;
		}
		case "accion": {
			_i.controlAccion();
			break;
		}
		case "idplantillaprevia": {					
			//_i.filtroCompenentePrev();
			break;
		}
		case "idplantillanueva": {					
			//_i.filtroCompenenteNuevo();
			break;
		}
		case "matftec": {
			//sys.setObjText(this, "fdbCompFtec", _i.calculateField("matftec"));
			break;
		}
		case "ordenftec": {
			sys.setObjText(this, "fdbMatFtec", _i.calculateField("matftec"));
			break;
		}
  }
}

function oficial_pbnBuscar_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var f = _i.dameFiltro(cursor);
	this.child("tdbPlantillas").cursor().setMainFilter(f);
	this.child("tdbPlantillas").refresh();
}

/*function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	formem_filtrosarticulos.iface.pub_limpiarFiltro(this);
	cursor.setValueBuffer("refcomponente", cursor.valueBuffer("refprevio"));
}*/

function oficial_pbnPlantilla_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbPlantillas").cursor();
	
	var idPlantilla = cursor.valueBuffer("idplantilla");
	if(!idPlantilla) {
		sys.warnMsgBox(sys.translate("Debe de seleccionar una plantilla"));
		return false;
	}

	var f = new FLFormSearchDB("em_plantillasprodedit");
	var curPlantillas = f.cursor();	
	curPlantillas.select("idplantilla = '" + idPlantilla + "'");
	if (!curPlantillas.first()) {
		return;
	}
	curPlantillas.setModeAccess(curPlantillas.Edit);
	curPlantillas.refreshBuffer();
	f.setMainWidget();	
	f.exec();

	/*	sys.setObjText(this, "fdbRefFtec", referencia);
		if(_i.ordenFT_) {
			sys.setObjText(this, "fdbOrdenFtec", _i.ordenFT_);
		}*/



	

}

function oficial_controlAccion()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var accion = cursor.valueBuffer("accion");
	if(accion == "A�adir") {	
		this.child("gbxPrevio").close();
		this.child("gbxNuevo").show();	
		sys.enableObj(this, "fdbOrdenNuevo");
		
		//_i.filtroOrden();
		//_i.filtroCompenente();	
		
	} else if (accion == "Cambiar"){
		this.child("gbxPrevio").show();
		this.child("gbxNuevo").show();
		sys.disableObj(this, "fdbOrdenNuevo");
	} else {
		this.child("gbxPrevio").show();
		this.child("gbxNuevo").close();
	}
}

function oficial_filtroOrden()
{
	var cursor = this.cursor();
	var refCompuesto = cursor.valueBuffer("refftec");
	var filtro = "";
	if(refCompuesto && refCompuesto != "") {
		filtro = "refcompuesto = '" + refCompuesto + "'";
	}
	debug("filtro: "+filtro);
	this.child("fdbOrdenFtec").setFilter(filtro);
}

function oficial_filtroCompenentePrev()
{
	var cursor = this.cursor();
	var idPlantilla = cursor.valueBuffer("idplantillaprevia");
	var filtro = "";
	if(idPlantilla && idPlantilla != "") {
		filtro = "em_codcomponente IN (SELECT emcodcomponente FROM em_lineasplantillaprod WHERE idplantilla = " + idPlantilla + ")";
	}
	debug("filtro: "+filtro);
	this.child("fdbCodCompoPrevio").setFilter(filtro);
}

function oficial_filtroCompenenteNuevo()
{
	var cursor = this.cursor();
	var idPlantilla = cursor.valueBuffer("idplantillanueva");
	var filtro = "";
	if(idPlantilla && idPlantilla != "") {
		filtro = "em_codcomponente IN (SELECT emcodcomponente FROM em_lineasplantillaprod WHERE idplantilla = " + idPlantilla + ")";
	}
	debug("filtro: "+filtro);
	this.child("fdbCodCompoNuevo").setFilter(filtro);
}

function oficial_aniadeComponente(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var idPlantillaO = 	oParam.idPlantilla;
	var idLineaO = oParam.idLineaNueva;
	var ordenO = oParam.orden;

	var filtroA = this.child("tdbPlantillas").cursor().mainFilter();	
	debug("filtroA: "+filtroA);

	var curOrigen = new FLSqlCursor("em_lineasplantillaprod");
	curOrigen.select("idplantilla = " + idPlantillaO + " and idlinea = " + idLineaO);
	if(!curOrigen.first()) {
		return false;
	}
	curOrigen.setModeAccess(curOrigen.Browse);
	curOrigen.refreshBuffer();
	
	
	var q = new AQSqlQuery;	
	q.setSelect("idplantilla,codcoleccionem, nombre, codsubfamilia, codtamanoem, codcolorem");
	q.setFrom("em_plantillasprod");
	q.setWhere(filtroA + " and idplantilla <> " + idPlantillaO); 			
	if (!q.exec()){
		return;
	}  
	debug("q: "+q.sql());
	AQUtil.createProgressDialog(sys.translate("A�adiendo componente a plantillas..."), q.size());
	var p = 0;	
	while(q.next())
	{
		AQUtil.setProgress(++p);
		var idPlantilla = q.value("idplantilla");
		var filtroL = "";
		var qFL = new AQSqlQuery;	
		qFL.setSelect("tipo,dibujo,emcodcomponente,componormal,refcomponente,codtamanocont,codtamanopanot,codcolorem,codsubfamilia");
		qFL.setFrom("em_lineasplantillaprod");
		qFL.setWhere("idlinea = " + idLineaO); 			
		if (!qFL.exec()){
			return;
		}  
		debug("qFL: "+qFL.sql());
	
		var p = 0;	
		if(qFL.first())
		{		
			filtroL = _i.dameFiltrolinea(qFL);
		}	
	
		debug("filtroL para ver si repetido: "+filtroL);
		var curLineaPlantilla = new FLSqlCursor("em_lineasplantillaprod");
		curLineaPlantilla.setActivatedCommitActions(false);
		curLineaPlantilla.setActivatedCheckIntegrity(false);		
		
		curLineaPlantilla.select("idplantilla = " + idPlantilla + " AND " + filtroL);
		if(curLineaPlantilla.first()) {
			var res = MessageBox.information(sys.translate("Existe ya el componente %1 en la plantilla %2 �Desea a�adirlo?").arg(cursor.valueBuffer("desclineanueva")).arg(idPlantilla), MessageBox.Yes, MessageBox.No)
			if (res != MessageBox.Yes) {
				continue;
			}			
			
		}

		
		var ordenInf = AQUtil.sqlSelect("em_lineasplantillaprod","orden","idplantilla = " + idPlantilla + " and orden <= " + ordenO + " order by orden desc");
		debug("\n\nordenInf: "+ordenInf);
		if(!ordenInf) {
			ordenInf = 0;
		} 
		var ordenSig = AQUtil.sqlSelect("em_lineasplantillaprod","orden","idplantilla = " + idPlantilla + " and orden > " + ordenInf + " order by orden asc"); 
		debug("ordenSig: "+ordenSig);
		if(!ordenSig) {
			ordenSig = 100;
		}

		var orden = (parseInt(ordenInf) + parseInt(ordenSig))/2;
		debug("orden: "+orden);
		if(!orden) {
			orden = 100;
		}

		curLineaPlantilla.setModeAccess(curLineaPlantilla.Insert);
		curLineaPlantilla.refreshBuffer();
		curLineaPlantilla.setValueBuffer("idplantilla",q.value("idplantilla"));      
		curLineaPlantilla.setValueBuffer("orden",orden);            
		curLineaPlantilla.setValueBuffer("codcoleccionplan",q.value("codcoleccionem"));
		curLineaPlantilla.setValueBuffer("nombreplan",q.value("nombre"));
		curLineaPlantilla.setValueBuffer("codsubfamiliaplan",q.value("codsubfamilia"));      
		curLineaPlantilla.setValueBuffer("codtamanoplan",q.value("codtamanoem")); 
		curLineaPlantilla.setValueBuffer("codcolorplan",q.value("codcolorem"));  	  

		_i.datosLineasPlantilla(curLineaPlantilla,curOrigen);	
		
		if (!curLineaPlantilla.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			oParam.errorMsg = sys.translate("scripts", "Error al a�adir el componente %1 a la plantilla %2").arg(curOrigen.valueBuffer("desclineanueva")).arg(idPlantilla);
			return false;
		}			
  			
	}
	AQUtil.destroyProgressDialog();
	oParam.numCambios = p;
	return true;
}

function oficial_quitaComponente(oParam)
{

	var _i = this.iface;
	var cursor = this.cursor();

	var idPlantillaPrevia = oParam.idPlantillaPrevia;
	var idLineaPrevia = oParam.idLineaPrevia;
	var filtroA = this.child("tdbPlantillas").cursor().mainFilter();		

	var q = new AQSqlQuery;	
	q.setSelect("tipo,dibujo,emcodcomponente,componormal,refcomponente,codtamanocont,codtamanopanot,codcolorem,codsubfamilia");
	q.setFrom("em_lineasplantillaprod");
	q.setWhere("idlinea = " + idLineaPrevia); 			
	if (!q.exec()){
		return;
	} 	
	var p = 0;	
	if(q.first())
	{
		
		var filtroL = _i.dameFiltrolinea(q);
		
		var qPlan = new AQSqlQuery;	
		qPlan.setSelect("idplantilla");
		qPlan.setFrom("em_plantillasprod");
		qPlan.setWhere(filtroA); 			
		if (!qPlan.exec()){
			return;
		}  		
		AQUtil.createProgressDialog(sys.translate("Quitando componente a plantillas..."), qPlan.size());
		
		while(qPlan.next())
		{
			
			var idPlantilla = qPlan.value("idplantilla");			
			AQUtil.setProgress(++p);
			var curLineas = new FLSqlCursor("em_lineasplantillaprod");
			curLineas.setActivatedCommitActions(false);
			curLineas.setActivatedCheckIntegrity(false);		
			curLineas.select("idplantilla = " + idPlantilla +  " AND " + filtroL);
			
			while(curLineas.next())
			{
							
				curLineas.setModeAccess(curLineas.Del);
				curLineas.refreshBuffer();			
				if (!curLineas.commitBuffer()) {
					AQUtil.destroyProgressDialog();
					oParam.errorMsg = sys.translate("scripts", "Error al quitar el componente %1 a la plantilla %2").arg(curLineas.valueBuffer("idlinea")).arg(qPlan.value("idplantilla"));
					return false;
				}			
	  		}	
  		}
	}
	AQUtil.destroyProgressDialog();
	oParam.numCambios = p;
	return true;
}

function oficial_tdbPlantillas_recordChoosed()
{
	var _i = this.iface;
	var curArticulo = this.child("tdbPlantillas").cursor();
	var cursor = this.cursor();
   curArticulo.commitBufferCursorRelation();
   curArticulo.editRecord();  
}

function oficial_dameFiltro(cursor)
{
	var _i = this.iface;
	var filtro = "";
	var filtroComponente = "";

	var codColeccionPlan = cursor.valueBuffer("codcoleccionplan");
	var codSubfamiliaPlan = cursor.valueBuffer("codsubfamiliaplan");
	var codTamanoPlan = cursor.valueBuffer("codtamanoPlan");
	var codColorPlan = cursor.valueBuffer("codcolorPlan");

	if(codColeccionPlan && codColeccionPlan != "") {
		filtro += filtro == "" ? "" : " AND ";
		filtro += "em_plantillasprod.codcoleccionem = '" + codColeccionPlan + "'";
	}

	if(codSubfamiliaPlan && codSubfamiliaPlan != "") {
		filtro += filtro == "" ? "" : " AND ";
		filtro += "em_plantillasprod.codsubfamilia = '" + codSubfamiliaPlan + "'";
	}

	if(codTamanoPlan && codTamanoPlan != "") {
		filtro += filtro == "" ? "" : " AND ";
		filtro += "em_plantillasprod.codtamanoem = '" + codTamanoPlan + "'";
	}

	if(codColorPlan && codColorPlan != "") {
		filtro += filtro == "" ? "" : " AND ";
		filtro += "em_plantillasprod.codcolorem = '" + codColorPlan + "'";
	}

	var tipo = cursor.valueBuffer("tipo");
	var dibujo = cursor.valueBuffer("dibujo");
	var emcodcomponente = cursor.valueBuffer("emcodcomponente");
	var componormal = cursor.valueBuffer("componormal");
	var refcomponente = cursor.valueBuffer("refcomponente");
	var codtamanocont = cursor.valueBuffer("codtamanocont");
	var codtamanopanot = cursor.valueBuffer("codtamanopanot");
	var codcolorem = cursor.valueBuffer("codcolorem");
	var codsubfamilia = cursor.valueBuffer("codsubfamilia");
	var idseccion = cursor.valueBuffer("idseccion");                       
                                                                             
                                                         
	if(tipo && tipo != "Todos") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "tipo = '" + tipo + "'";
	}

	if(dibujo && dibujo != "Todos") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "dibujo = '" + dibujo + "'";
	}

	if(emcodcomponente && emcodcomponente != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "emcodcomponente = " + emcodcomponente;
	}

	if(componormal && componormal != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "componormal = '" + componormal + "'";
	}

	if(refcomponente && refcomponente != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "refcomponente = '" + refcomponente + "'";
	}

	if(codtamanocont && codtamanocont != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "codtamanocont = '" + codtamanocont + "'";
	}

	if(codtamanopanot && codtamanopanot != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "codtamanopanot = '" + codtamanopanot + "'";
	}

	if(codcolorem && codcolorem != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "codcolorem = '" + codcolorem + "'";
	}

	if(codsubfamilia && codsubfamilia != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "codsubfamilia = '" + codsubfamilia + "'";
	}

	if(idseccion && idseccion != "") {
		filtroComponente += filtroComponente == "" ? "" : " AND ";
		filtroComponente += "idseccion = '" + idseccion + "'";
	}
	debug("\n\nfiltro plantilla: "+filtro);
	if(filtroComponente && filtroComponente != "") {
		filtro += filtro == "" ? "" : " AND ";
		filtro += "em_plantillasprod.idplantilla IN (SELECT idplantilla FROM em_lineasplantillaprod  WHERE " + filtroComponente + ")";	
	}

	if(filtro == "") {
		filtro = "1 = 1";
	}

	debug("\n\filtroComponente: "+filtroComponente);

	debug("\n\nfiltroTotal: "+filtro);
	
	return filtro;

}

function oficial_dimeOrdenCompoNuevo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idPlantilla = cursor.valueBuffer("idplantillanueva");
	var idLineaNueva = cursor.valueBuffer("idlineanueva");

	debug("idPlantilla: "+idPlantilla);
	debug("codCompoNuevo: "+idLineaNueva);

	var orden = AQUtil.sqlSelect("em_lineasplantillaprod","orden","idplantilla = " + idPlantilla + " and idlinea = " + idLineaNueva);

	debug("orden: "+orden);
	return orden;

}

function oficial_dameDescCompoNuevo(idLinea)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var desc;
	

	var q = new AQSqlQuery;	
	q.setSelect("tipo,dibujo,emcodcomponente,componente,componormal,refcomponente,desccomponente,codtamanocont,codtamanopanot,codcolorem,codsubfamilia");
	q.setFrom("em_lineasplantillaprod");
	q.setWhere("idlinea = " + idLinea); 	
	debug("q: "+ q.sql());			
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{
		desc = "Tipo: "+q.value("tipo") + " Dibujo: " + q.value("dibujo") + " C.Compon.: " + q.value("emcodcomponente") + " C.Normal.: " + q.value("componormal") + " Material: " + q.value("refcomponente") + " Tama Cont: " + q.value("codtamanocont") + " Tama Panot: " + q.value("codtamanopanot") + " Color: " + q.value("codcolorem") + " Subfam: " + q.value("codsubfamilia")
	}	

	return desc;

}

function oficial_dameFiltrolinea(q)
{
	var filtro = "";

	var tipo = q.value("tipo");
	var dibujo = q.value("dibujo");
	var emCodComponente = q.value("emcodcomponente");
	var compoNormal = q.value("componormal");
	var refComponente = q.value("refcomponente");
	var codTamanoCont = q.value("codtamanocont");
	var codTamanoPanot = q.value("codtamanopanot");
	var codColorEm = q.value("codcolorem");
	var codSubfamilia = q.value("codsubfamilia");

	if(tipo && tipo != "") {
		filtro += "tipo = '" + tipo + "'";
	} else {
		filtro += "tipo is null";
	}

	if(dibujo && dibujo != "") {
		filtro += " AND dibujo = '" + dibujo + "'";
	} else {
		filtro += " AND dibujo is null";
	}

	if(emCodComponente && emCodComponente != "") {
		filtro += " AND emcodcomponente = " + emCodComponente;
	} else {
		filtro += " AND emcodcomponente is null";
	}
	
	if(compoNormal && compoNormal != "") {
		filtro += " AND componormal = '" + compoNormal + "'";
	} else {
		filtro += " AND componormal is null";
	}
	
	if(refComponente && refComponente != "") {
		filtro += " AND refcomponente = '" + refComponente + "'";
	} else {
		filtro += " AND refcomponente is null";
	}
	
	if(codTamanoCont && codTamanoCont != "") {
		filtro += " AND codtamanocont = '" + codTamanoCont + "'";
	} else {
		filtro += " AND codtamanocont is null";
	}
	
	if(codTamanoPanot && codTamanoPanot != "") {
		filtro += " AND codtamanopanot = '" + codTamanoPanot + "'";
	} else {
		filtro += " AND codtamanopanot is null";
	}
	
	if(codColorEm && codColorEm != "") {
		filtro += " AND codcolorem = '" + codColorEm + "'";
	} else {
		filtro += " AND codcolorem is null";
	}
	
	if(codSubfamilia && codSubfamilia != "") {
		filtro += " AND codsubfamilia = '" + codSubfamilia + "'";
	} else {
		filtro += " AND codsubfamilia is null";
	}
	return filtro;
}


function oficial_datosLineasPlantilla(curLineaPlantilla,curOrigen)
{
	var _i = this.iface;

	if(curOrigen.valueBuffer("alto") && curOrigen.valueBuffer("alto")!="") {
		curLineaPlantilla.setValueBuffer("alto",curOrigen.valueBuffer("alto"));			
	} else {
		curLineaPlantilla.setNull("alto");               
	}

	if(curOrigen.valueBuffer("cantidad") && curOrigen.valueBuffer("cantidad") != "") {
		curLineaPlantilla.setValueBuffer("cantidad",curOrigen.valueBuffer("cantidad")); 	         
	} else {
		curLineaPlantilla.setNull("cantidad");			
	}

	if(curOrigen.valueBuffer("codtamanocont") && curOrigen.valueBuffer("codtamanocont") != "") {
		curLineaPlantilla.setValueBuffer("codtamanocont",curOrigen.valueBuffer("codtamanocont"));          
	} else {	
		curLineaPlantilla.setNull("codtamanocont");			
	}

	if(curOrigen.valueBuffer("codunidad") && curOrigen.valueBuffer("codunidad") != "") {
		curLineaPlantilla.setValueBuffer("codunidad",curOrigen.valueBuffer("codunidad"));			
	} else {	
		curLineaPlantilla.setNull("codunidad");              
	}

	if(curOrigen.valueBuffer("componormal") && curOrigen.valueBuffer("componormal") != "") {
		curLineaPlantilla.setValueBuffer("componormal",curOrigen.valueBuffer("componormal"));			
	} else {		
		curLineaPlantilla.setNull("componormal");   
	}

	if(curOrigen.valueBuffer("emcodcomponente") && curOrigen.valueBuffer("emcodcomponente") != "") {
		curLineaPlantilla.setValueBuffer("emcodcomponente",curOrigen.valueBuffer("emcodcomponente"));			
	} else {
		curLineaPlantilla.setNull("emcodcomponente");    	           	
	}        

	if(curOrigen.valueBuffer("piezasancho") && curOrigen.valueBuffer("piezasancho") != "") {
		curLineaPlantilla.setValueBuffer("piezasancho",curOrigen.valueBuffer("piezasancho"));            			
	} else {		
		curLineaPlantilla.setNull("piezasancho");
	}
	
	if(curOrigen.valueBuffer("tipo") && curOrigen.valueBuffer("tipo") != "") {
		curLineaPlantilla.setValueBuffer("tipo",curOrigen.valueBuffer("tipo"));    
	} else {		
		curLineaPlantilla.setNull("tipo");			
	}

	if(curOrigen.valueBuffer("ancho") && curOrigen.valueBuffer("ancho") != "") {
		curLineaPlantilla.setValueBuffer("ancho",curOrigen.valueBuffer("ancho")); 	       
		
	} else {		
		curLineaPlantilla.setNull("ancho");
	}

	if(curOrigen.valueBuffer("codsubfamilia") && curOrigen.valueBuffer("codsubfamilia") != "") {
		curLineaPlantilla.setValueBuffer("codsubfamilia",curOrigen.valueBuffer("codsubfamilia"));          			
	} else {		
		curLineaPlantilla.setNull("codsubfamilia");
	}

	if(curOrigen.valueBuffer("codtamanopanot") && curOrigen.valueBuffer("codtamanopanot") != "") {
		curLineaPlantilla.setValueBuffer("codtamanopanot",curOrigen.valueBuffer("codtamanopanot")); 
		
	} else {		
		curLineaPlantilla.setNull("codtamanopanot");        
	}

	if(curOrigen.valueBuffer("componente") && curOrigen.valueBuffer("componente") != "") {
		curLineaPlantilla.setValueBuffer("componente",curOrigen.valueBuffer("componente")); 			
	} else {		
		curLineaPlantilla.setNull("componente");            
	}

	if(curOrigen.valueBuffer("desccomponente") && curOrigen.valueBuffer("desccomponente") != "") {
		curLineaPlantilla.setValueBuffer("desccomponente",curOrigen.valueBuffer("desccomponente"));
		
	} else {		
		curLineaPlantilla.setNull("desccomponente");         
	}

	if(curOrigen.valueBuffer("factor") && curOrigen.valueBuffer("factor") != "") {
		curLineaPlantilla.setValueBuffer("factor",curOrigen.valueBuffer("factor"));
		
	} else {		
		curLineaPlantilla.setNull("factor");                 
	}
	if(curOrigen.valueBuffer("idseccion") && curOrigen.valueBuffer("idseccion") != "") {
		curLineaPlantilla.setValueBuffer("idseccion",curOrigen.valueBuffer("idseccion"));			
	} else {		
		curLineaPlantilla.setNull("idseccion");
	}
	if(curOrigen.valueBuffer("observaciones") && curOrigen.valueBuffer("observaciones") != "") {
		curLineaPlantilla.setValueBuffer("observaciones",curOrigen.valueBuffer("observaciones"));
		
	} else {
		curLineaPlantilla.setNull("observaciones");          
	}
	if(curOrigen.valueBuffer("refcomponente") && curOrigen.valueBuffer("refcomponente") != "") {
		curLineaPlantilla.setValueBuffer("refcomponente",curOrigen.valueBuffer("refcomponente"));
		
	} else {		
		curLineaPlantilla.setNull("refcomponente");    
	}
	if(curOrigen.valueBuffer("anchopiezatej") && curOrigen.valueBuffer("anchopiezatej") != "") {
		curLineaPlantilla.setValueBuffer("anchopiezatej",curOrigen.valueBuffer("anchopiezatej"));
		
	} else {		
		curLineaPlantilla.setNull("anchopiezatej");          
	}
	if(curOrigen.valueBuffer("codcolorem") && curOrigen.valueBuffer("codcolorem") != "") {
		curLineaPlantilla.setValueBuffer("codcolorem",curOrigen.valueBuffer("codcolorem"));
		
	} else {		
		curLineaPlantilla.setNull("codcolorem");          
	}

	if(curOrigen.valueBuffer("componenteorigen") && curOrigen.valueBuffer("componenteorigen") != "") {
		curLineaPlantilla.setValueBuffer("componenteorigen",curOrigen.valueBuffer("componenteorigen"));       			
	} else {		
		curLineaPlantilla.setNull("componenteorigen");
	}	

	if(curOrigen.valueBuffer("dibujo") && curOrigen.valueBuffer("dibujo")!= "") {
		curLineaPlantilla.setValueBuffer("dibujo",curOrigen.valueBuffer("dibujo"));  	                
		
	} else {
		curLineaPlantilla.setNull("dibujo");
	}
	if(curOrigen.valueBuffer("largo") && curOrigen.valueBuffer("largo") != "") {
		curLineaPlantilla.setValueBuffer("largo",curOrigen.valueBuffer("largo")); 	            
	} else {
		curLineaPlantilla.setNull("largo");					
	}
	
	curLineaPlantilla.setValueBuffer("reservar",curOrigen.valueBuffer("reservar"));			
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////

