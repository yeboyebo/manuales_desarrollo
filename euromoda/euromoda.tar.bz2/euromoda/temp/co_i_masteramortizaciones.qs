
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
class euromoda extends oficial {
    function euromoda( context ) { oficial ( context ); }
    function calculaCampo(nodo, campo) {
    	return this.ctx.euromoda_calculaCampo(nodo, campo);
    }
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA  /////////////////////////////////////////////////
function euromoda_calculaCampo(nodo, campo)
{
	var _i = this.iface;
	var valor;
	var cursor = this.cursor();
	var codEjercicio = cursor.valueBuffer("codejercicio");
	var codAmortizacion = nodo.attributeValue("co_amortizaciones.codamortizacion");
	
	switch (campo) {
		case "costeInicio": {
				switch (codAmortizacion) {
				case "000327": {
						valor =  5600;
						break;
				}
				case "000353": {
						valor = 594;
						break;
				}
				default: {
					valor =  _i.__calculaCampo(nodo, campo);
				}
				}
				break;
		}
		case "adicion": {
				switch (codAmortizacion) {
				case "000378": {
						valor = 44275.74;
						break;
				}
				case "000377": {
						valor = 6404.56;
						break;
				}
				default: {
					valor =  _i.__calculaCampo(nodo, campo);
				}
				}
				break;
		}
		default: {
			valor =  _i.__calculaCampo(nodo, campo);
		}
	}
	return valor;
}
//// EUROMODA  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
