/***************************************************************************
                 em_mastertransstock.qs  -  description
                             -------------------
    begin                : mar oct 18 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN) { return this.ctx.interna_calculateField(fN); }
	function validateForm() {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var codOrdenAsig_;
	function oficial( context ) { interna( context ); } 
	function establecerOrden()
	{
		return this.ctx.oficial_establecerOrden();
	}
	function filtra()
	{
		return this.ctx.oficial_filtra();
	}
// 	function tbnAltaInventario_clicked()
// 	{
// 		return this.ctx.oficial_tbnAltaInventario_clicked();
// 	}
	function filtraLineas()
	{
		return this.ctx.oficial_filtraLineas();
	}
	function imprimir()
	{
		return this.ctx.oficial_imprimir();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El valor de --stockfis-- se calcula autom�ticamente para cada art�culo como la suma de existencias del art�culo en todos los almacenes.
\end */
function interna_init()
{
	var _i = this.iface;
	if (!_i.establecerOrden()) {
		this.close();
	}
	this.child("tdbLineasTransStock").setReadOnly(true);
	
	connect(this.child("toolButtonPrint"), "clicked()", _i, "imprimir");
// 	connect(this.child("tbnAltaInventario"), "clicked()", _i, "tbnAltaInventario_clicked");
	connect(this.child("tdbTransStock"), "currentChanged()", _i, "filtraLineas()");
  connect(this.child("chkTodos"), "clicked()", _i, "filtraLineas()");
  
	/// Por ahora no se hace con esto
	if (this.child("tbnAltaInventario")) {
		this.child("tbnAltaInventario").close();
	}
	_i.filtra();
	_i.filtraLineas()
	
	this.child("tdbTransStock").refresh();
	debug("tama�o " + this.child("tdbTransStock").cursor().size());
	if (this.child("tdbTransStock").cursor().size() == 0) {
// 		this.child("tbnAltaInventario").animateClick();
	}
}

function interna_calculateField(fN)
{
	return 0;
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
// function oficial_tbnAltaInventario_clicked()
// {
// 	var cursor = this.cursor();
// 	var _i = this.iface;
// 	
// 	var f = new FLFormSearchDB("em_transconfec");
// 	var curG = f.cursor();
// 	curG.setModeAccess(curG.Insert);
// 	curG.refreshBuffer();
// 	curG.setValueBuffer("codalmaorigen", flfactppal.iface.valorDefectoEmpresa("codalmacen"));
// 	var codAlmaConfec = AQUtil.sqlSelect("pr_ordenesproduccion op INNER JOIN proveedores p ON op.codconfeccionista = p.codproveedor", "p.codalmacen", "op.codorden = '" + _i.codOrdenAsig_ + "'", "pr_ordenesproduccion,proveedores");
// 	if (!codAlmaConfec) {
// 		MessageBox.warning(sys.translate("La orden %1 no tiene asociado un confeccionista o el confeccionista no tiene almac�n asociado").arg(_i.codOrdenAsig_), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 		return false;
// 	}
// 	curG.setValueBuffer("codalmadestino", codAlmaConfec);
// 	curG.setValueBuffer("codordenprod", _i.codOrdenAsig_);
// 
// 	var curT = new FLSqlCursor("empresa");
// 	curT.transaction(false);
// 	
// 	f.setMainWidget();
// 	
// 	try {
// 		var id = f.exec("idtrans");//f.exec("id")
// 		if (id) {
// 			curT.commit();
// 		} else {
// 			curT.rollback();
// 		}
// 	} catch(e) {
// 		curT.rollback();
// 		MessageBox.critical(sys.translate("Error al generar la transferencia de stock:\n") + e, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 		return false;
// 	}
// 	this.child("tdbTransStock").refresh();
// }

function oficial_filtra()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtro;
	if (cursor.action() == "em_transstock") {
		filtro = "codordenprod = '" + _i.codOrdenAsig_ + "'";
	} else {
		filtro = "codasigconf = '" + _i.codOrdenAsig_ + "'";
	}
	this.child("tdbTransStock").cursor().setMainFilter(filtro);
}

function oficial_establecerOrden()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.action() == "em_transstock") {
		_i.codOrdenAsig_ = formem_materialesconf.iface.pub_ordenActual();
		if (!_i.codOrdenAsig_) {
			sys.warnMsgBox(sys.translate("scripts", "Error al obtener la orden actual"));
			return false;
		}
		this.child("gbxTrans").title = sys.translate("Transferencias asociadas a la orden %1").arg(_i.codOrdenAsig_);
	} else {
		_i.codOrdenAsig_ = formem_asignacionesconf.iface.pub_asignacionActual();
		if (!_i.codOrdenAsig_) {
			sys.warnMsgBox(sys.translate("scripts", "Error al obtener la orden asignaci�n"));
			return false;
		}
		this.child("gbxTrans").title = sys.translate("Transferencias asociadas a la asignaci�n %1").arg(_i.codOrdenAsig_);
	}
	
	return true;
}

function oficial_filtraLineas()
{
  var _i = this.iface;
  var cursor = this.cursor();
	var filtro;
	if (cursor.action() == "em_transstock") {
		filtro = "idtrans IN (select idtrans from transstock WHERE codordenprod = '" + _i.codOrdenAsig_ + "')";
	} else {
		filtro = "idtrans IN (select idtrans from transstock WHERE codasigconf = '" + _i.codOrdenAsig_ + "')";
	}
  if (!this.child("chkTodos").checked) {
    var curTrans = this.child("tdbTransStock").cursor();
    var idTrans = curTrans.valueBuffer("idtrans");
    if (idTrans && curTrans.size() > 0) {
      filtro = "idtrans = " + idTrans;
    }
  }
  this.child("tdbLineasTransStock").setFilter(filtro);
  this.child("tdbLineasTransStock").refresh();
}

function oficial_imprimir()
{
debug("oficial_imprimir");
	var _i = this.iface;
	var cursor = this.child("tdbTransStock").cursor();
debug("oficial_imprimir 1");
	var idTrans = cursor.valueBuffer("idtrans");
	var oParam = formtransstock.iface.pub_dameParamInforme(idTrans, cursor);
	if (!oParam) {
		return;
	}
debug("oficial_imprimir 2");
	var curImprimir = new FLSqlCursor("i_transstock");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("i_transstock_idtrans", cursor.valueBuffer("idtrans"));
debug("oficial_imprimir 3");
	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
debug("oficial_imprimir OK");
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
