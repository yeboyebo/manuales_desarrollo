
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function ejecutar(oParam) {
		return this.ctx.euromoda_ejecutar(oParam);
	}
	function terminarTarea(param) {
		return this.ctx.euromoda_terminarTarea(param);
	}
    function terminarTareaJson(idTarea) {
        return this.ctx.euromoda_terminarTareaJson(idTarea);
    }
	function regularizarLote(param) {
		return this.ctx.euromoda_regularizarLote(param);
	}
    function regularizarLoteJson(params) {
        return this.ctx.euromoda_regularizarLoteJson(params);
    }
	function iniciarTablaLlamadas() {
		return this.ctx.euromoda_iniciarTablaLlamadas();
	}
	function cortaPieza(param) {
		return this.ctx.euromoda_cortaPieza(param);
	}
    function cortaPiezaJson(params) {
        return this.ctx.euromoda_cortaPiezaJson(params)
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_iniciarTablaLlamadas()
{
 	if(!AQUtil.sqlDelete("au_llamadas","procesada = false"))
		return false;
	
	return true;
}

function euromoda_ejecutar(oParam)
{
	var _i = this.iface;
	
	var curLlamada = oParam.curLlamada;
	var f = curLlamada.valueBuffer("funcion");
	var param = curLlamada.valueBuffer("param");
	
	var res = [];
	res["codigo"] = -1;
	res["result"] = sys.translate("La funci�n no %1 est� definida").arg(f);
	switch (f) {
		case "terminarTarea": {
			res = _i.terminarTarea(param);
			break;
		}
		case "cortaPieza": {
			res = _i.cortaPieza(param);
			break;
		}
		case "regularizarLote": {
			res = _i.regularizarLote(param);
			break;
		}
		default: {
			res = _i.__ejecutar(oParam);
		}
	}
	oParam.res = res;
	return res;
}

function euromoda_regularizarLote(param)
{
	var _i = this.iface;
	
	var res = new Object;
	res["codigo"] = 0;
	res["error"] = "";
	res["result"] = "";
	
	var xP = new FLDomDocument;
	var xR = new FLDomDocument;
	if (!xP.setContent(param)) {
		return false;
	}
	xR.setContent("<Response/>");
	var eP = xP.firstChild().toElement();
	var eR = xR.firstChild().toElement();

	var codLote = eP.attribute("codLote");
	var cantNueva = eP.attribute("cantNueva");

    var response = new Object;
    var params = new Object;
    params["cantNueva"] = cantNueva;
    params["codLote"] = codLote;

	if (!codLote || codLote == "") {
		res["codigo"] = -1;
		eR.setAttribute("desc", sys.translate("No ha indicado el c�digo de pieza"));
	} 
	else {
		if(cantNueva == "") {
			res["codigo"] = -1;
			eR.setAttribute("desc", sys.translate("Debe indicar la cantidad nueva"));
		}
		else {
            response = _i.regularizarLoteJson(params);
            eR.setAttribute("desc", response["msg"]);
		}
	}
	
	res["result"] = xR.toString(4);
	
	flfactppal.iface.pub_appendTextToLogFile(_i.nombreLog_, eR.attribute("desc"));
	
	debug("RL OK");
	return res;
}

function euromoda_regularizarLoteJson(params) {
    var _i = this.iface;
    var res = new Object;
    var codLote = params["codLote"];
    var cantNueva = params["cantNueva"];
    if (formRecordlotesstock.iface.regularizarLote(codLote,cantNueva)) {
        res["codigo"] = 0;
        res["msg"] = sys.translate("Pieza %1 regularizada correctamente").arg(codLote);
    } else {
        res["codigo"] = -1;
        res["msg"] = sys.translate("Error al regularizar la pieza %1").arg(codLote);
    }
    debug("RL JSON  OK");

	return res;
}

function euromoda_terminarTarea(param)
{
	var _i = this.iface;
	
	var res = new Object;
	res["codigo"] = 0;
	res["error"] = "";
	res["result"] = "";
	
	var xP = new FLDomDocument;
	var xR = new FLDomDocument;
	if (!xP.setContent(param)) {
debug("Falla param " + param);
	res["codigo"] = -1;
	res["error"] = "";
	res["result"] = "<Response desc = \"Fallo\" />";
		return res;
	}
	xR.setContent("<Response/>");
	var eP = xP.firstChild().toElement();
	var eR = xR.firstChild().toElement();
	
	var idTarea = eP.attribute("idTarea");

	if (!idTarea || idTarea == "") {
		res["codigo"] = -1;
		eR.setAttribute("desc", sys.translate("No ha indicado el c�digo de tarea"));
	} else {
        var resTarea = _i.terminarTareaJson(idTarea);
		debug("resTarea " + resTarea);
		switch (resTarea) {
			case true: {
				res["codigo"] = 0;
				eR.setAttribute("desc", sys.translate("Tarea %1 completada correctamente").arg(idTarea));
				break;
			}
			case -1: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("La tarea es de un tipo (distribuci�n a confecciones) no permitido"));
				break;
			}
			case -2: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("La tarea ya ha sido realizada"));
				break;
			}
			case -3: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("La tarea precedente no se ha finalizado"));
				break;
			}
			default: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("Error al iniciar la tarea %1").arg(idTarea));
				break;
			}
		}
	}
	res["result"] = xR.toString(4);
	
	flfactppal.iface.pub_appendTextToLogFile(_i.nombreLog_, eR.attribute("desc"));
	
	debug("TT OK");
	return res;
}

function euromoda_terminarTareaJson(idTarea) {
    var _i = this.iface;
    debug("___________")
    debug(idTarea)
    var resTarea = flcolaproc.iface.iniciaTareaTrEm(idTarea, false);
    return resTarea;
}

function euromoda_cortaPieza(param)
{
	var _i = this.iface;
	
	var res = new Object;
	res["codigo"] = 0;
	res["error"] = "";
	res["result"] = "";
	
	var xP = new FLDomDocument;
	var xR = new FLDomDocument;
	if (!xP.setContent(param)) {
debug("Falla param " + param);
	res["codigo"] = -1;
	res["error"] = "";
	res["result"] = "<Response desc = \"Fallo\" />";
		return res;
	}
	xR.setContent("<Response/>");
	var eP = xP.firstChild().toElement();
	var eR = xR.firstChild().toElement();
	
	var codLote = eP.attribute("codLote");
	if (!codLote || codLote == "") {
		res["codigo"] = -1;
		eR.setAttribute("desc", sys.translate("No ha indicado el c�digo de pieza"));
		res["result"] = xR.toString(4);
		return res;
	}
	var cantidad = eP.attribute("cantidad");
	cantidad = isNaN(cantidad) ? 0 : cantidad;
	if (!cantidad) {
		res["codigo"] = -1;
		eR.setAttribute("desc", sys.translate("No ha indicado la cantidad"));
		res["result"] = xR.toString(4);
		return res;
	}
    var response = new Object;
    var params = new Object;
    params["cantidad"] = cantidad;
    params["codLote"] = codLote;
    response = _i.cortaPiezaJson(params);
    if (response["codigo"] != 0) {
        res["codigo"] = response["codigo"];
        eR.setAttribute("desc", response["msg"]);
		res["result"] = xR.toString(4);
		return res;
	}
    eR.setAttribute("disponible", response["nuevoDisponible"]);
		
/*			
			
            $ordenSQL = "insert into movistock
(referencia,estado,cantidad,fechareal,horareal,idstock,codlote,reservaex,reservapr,reservaaf,em_merma,reservamanual,concepto,enreserva)
values
('".$row["referencia"]."','HECHO',".$corte.",'".$fecha.",','".$hora."',".$idStock.",'".$codLote."',0,0,0,false,false,'Consumos
por pistola de pieza ".$codLote."',0)";
            $result = $__BD->db_query($ordenSQL);

            if(!$result) {
                $objResponse->script('alert("Error: No se pudo cortar
la pieza: ");');
                return $objResponse;
            }

    ///////////////////// ACTUALIZANDO CANTIDADES LOTE
//////////////////////////////////
            $canUsada = (float) $__BD->db_valor("select SUM(cantidad)
from movistock where codlote = '".$codLote."' AND estado = 'HECHO' AND
cantidad < 0");

            if (!$canUsada)
                $canUsada = 0;
            $canUsada = $canUsada * -1;

            $canTotal = (float) $__BD->db_valor("select cantotal from
lotesstock where codlote = '".$codLote."'");
            if (!$canTotal)
                $canTotal = 0;

            $canReservada = (float) $__BD->db_valor("select
canreservada from lotesstock where codlote = '".$codLote."'");
            if (!$canReservada)
                $canReservada = 0;

            $canDisp = $canTotal - $canUsada - $canReservada;

            if(!$canDisp)
                $canDisp = 0;

            $ordenSQL = "update lotesstock set (canusada,candisponible)
= (".$canUsada.",".$canDisp.") WHERE codlote = '".$codLote."'";
            $result = $__BD->db_query($ordenSQL);
            if(!$result) {
                $objResponse->script('alert("Error: No se pudo cortar
la pieza");');
                return $objResponse;
            }


    ///////////////////// ACTUALIZANDO CANTIDADES STOCK
//////////////////////////////////
//             $cantUltReg = (float)$__BD->db_valor("select cantidadfin
from lineasregstocks where idstock = ".$idStock."  ORDER BY fecha DESC,
hora DESC");
//             if (!$cantUltReg)
//                 $cantUltReg = 0;
//
//             $whereStock = "idstock = ".$idStock." AND estado = 'HECHO'";
//             $fUltReg = $__BD->db_valor("select fechaultreg from
stocks where idstock = ".$idStock);
//             if($fUltReg) {
//                 $hUltReg = (string) $__BD->db_valor("select
horaultreg from stocks where idstock = ".$idStock);
//                 $whereStock .= " AND ((fechareal > '".$fUltReg."') OR
(fechareal = '".$fUltReg."' AND horareal > '".substr($hUltReg, -8)."'))";
//             }
//
//             $canMov = (float) $__BD->db_valor("select SUM(cantidad)
from movistock where ".$whereStock);
//
//             $cantidad = $cantUltReg + $canMov;

            $cantidad = (float) $__BD->db_valor("select
SUM(cantotal-canusada) from lotesstock where codalmacen = '1' and
referencia = '".$row["referencia"]."'");
            if (!$cantidad)
                $cantidad = 0;

            $reservada = (float) $__BD->db_valor("select reservada from
stocks where idstock = ".$idStock);
            if (!$reservada)
                $reservada = 0;
            $disponible = $cantidad - $reservada;

            $ordenSQL = "update stocks set (cantidad,disponible) =
(".$cantidad.",".$disponible.") WHERE idstock = '".$idStock."'";
            $result = $__BD->db_query($ordenSQL);
            if(!$result) {
                $objResponse->script('alert("Error: No se pudo cortar
la pieza");');
                return $objResponse;
            }


    ///////////////////// ACTUALIZANDO VALORES WEB
///$cantidad///////////////////////////////
$objResponse->script('document.consultaPieza.longitud.value="'.$canDisp.'";');
$objResponse->script('document.consultaPieza.corte.value="";');
            return $objResponse;
        }
		
		}
			
		
		
		var resTarea = flcolaproc.iface.iniciaTareaTrEm(idTarea);
		debug("resTarea " + resTarea);
		switch (resTarea) {
			case true: {
				res["codigo"] = 0;
				eR.setAttribute("desc", sys.translate("Tarea %1 completada correctamente").arg(idTarea));
				break;
			}
			case -1: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("La tarea es de un tipo (distribuci�n a confecciones) no permitido"));
				break;
			}
			case -2: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("La tarea ya ha sido realizada"));
				break;
			}
			case -3: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("La tarea precedente no se ha finalizado"));
				break;
			}
			default: {
				res["codigo"] = -1;
				eR.setAttribute("desc", sys.translate("Error al iniciar la tarea %1").arg(idTarea));
				break;
			}
		}
	}
	*/
	res["result"] = xR.toString(4);
	
	flfactppal.iface.pub_appendTextToLogFile(_i.nombreLog_, eR.attribute("desc"));
    return res;

}

function euromoda_cortaPiezaJson(params) {
    debug("entramos");
    var codLote = params["codLote"];
    var cantidad = parseFloat(params["cantidad"]);
    debug("pasamos");
    debug(cantidad)
    var res = new Object;
    var qLote = new AQSqlQuery;
    qLote.setSelect("referencia, candisponible, codlote");
    qLote.setFrom("lotesstock");
    qLote.setWhere("codlote = '" + codLote + "'");
    if (!qLote.exec()) {
        res["codigo"] = -1;
        res["msg"] = sys.translate("Error al consultar la pieza %1").arg(codLote);
        return res;
    }
    if (!qLote.first()) {
        var l = codLote.length;
        var codPiezaGit = false;;
        if (l == 12) {
            codPiezaGit = codLote.mid(0, 6);
        } else if (l == 13) {
            codPiezaGit = codLote.mid(1, 6);
        }
        if (codPiezaGit) {
            qLote.setWhere("codigogit = '" + codPiezaGit + "'");
            if (!qLote.exec()) {
                res["codigo"] = -1;
                res["msg"] = sys.translate("Error al consultar la pieza por c�digo GIT %1").arg(codPiezaGit);
                return res;
            }
            if (!qLote.first()) {
                res["codigo"] = -1;
                res["msg"] = sys.translate("Error al localizar la pieza por c�digo GIT %1").arg(codPiezaGit);
                return res;
            }
        }
        codLote = qLote.value("codlote");
    }
    if (cantidad > parseFloat(qLote.value("candisponible"))) {
        res["codigo"] = -1;
        res["msg"] = sys.translate("El corte no puede ser mayor que la longitud disponible (%1)").arg(qLote.value("candisponible"));
        return res;
    }
    var codAlmacen = AQUtil.sqlSelect("lotesstock", "codalmacen", "codlote = '" + codLote + "'");
    debug("codAlmacen " + codAlmacen);
    codAlmacen = !codAlmacen || codAlmacen == "" ? "1" : codAlmacen;
    debug("codAlmacen " + codAlmacen);
    var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + qLote.value("referencia") + "' AND codalmacen = '" + codAlmacen + "'");
    if (!idStock) {
        res["codigo"] = -1;
        res["msg"] = sys.translate("Error: Stock no encontrado");
        return res;
    }
    var hoy = new Date;
    var fecha = hoy.toString().left(10);
    var hora = hoy.toString().right(8);
    
    cantidad  = cantidad * -1;
    
    var curMS = new FLSqlCursor("movistock");
    curMS.setActivatedCheckIntegrity(false);
    curMS.setModeAccess(curMS.Insert);
    curMS.refreshBuffer();
    curMS.setValueBuffer("referencia", qLote.value("referencia"));
    curMS.setValueBuffer("estado", "HECHO");
    curMS.setValueBuffer("cantidad", cantidad);
    curMS.setValueBuffer("fechareal", fecha);
    curMS.setValueBuffer("horareal", hora);
    curMS.setValueBuffer("idstock", idStock);
    curMS.setValueBuffer("codlote", codLote);
    curMS.setValueBuffer("reservaex", 0);
    curMS.setValueBuffer("reservapr", 0);
    curMS.setValueBuffer("reservaaf", 0);
    curMS.setValueBuffer("em_merma", false);
    curMS.setValueBuffer("reservamanual", false);
    curMS.setValueBuffer("concepto", sys.translate("Consumos por pistola de pieza %1").arg(codLote));
    curMS.setValueBuffer("enreserva", 0);
    if (!curMS.commitBuffer()) {
        res["codigo"] = -1;
        res["msg"] = sys.translate("Error:  No se pudo cortar la pieza");
        return res;
    }
    var nuevoDisponible = AQUtil.sqlSelect("lotesstock", "candisponible", "codlote = '" + codLote + "'");
    res["codigo"] = 0
    res["nuevoDisponible"] = nuevoDisponible;
	
	debug("TT OK");
	return res;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
