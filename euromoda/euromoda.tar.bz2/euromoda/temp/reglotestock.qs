
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function validaFamilia() {
		return this.ctx.euromoda_validaFamilia();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	switch (cursor.modeAccess()) {
  		case cursor.Insert: {
      	sys.setObjText(this, "fdbEmIdUsuario", sys.nameUser());
      	sys.setObjText(this, "fdbCodAlmacen",AQUtil.sqlSelect("lotesstock", "codalmacen", "codlote = '" + cursor.valueBuffer("codlote") + "'"));
      break;
    }
  }
	
}

function euromoda_validateForm()
{
	var _i = this.iface;
// 	if (!_i.__validateForm()) {
// 		return false;
// 	}
	if (!_i.validaFamilia()) {
		return false;
	}
	return true;
}

function euromoda_validaFamilia()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
// 	var codFamilia = AQUtil.sqlSelect("lotesstock l  INNER JOIN articulos a ON l.referencia = a.referencia", "a.codfamilia", "l.codlote = '" + cursor.valueBuffer("codlote") + "'", "lotesstock,articulos");
// 	if (!flfactalma.iface.pub_esFamiliaEstampado(codFamilia)) {
// 		MessageBox.warning(sys.translate("scripts", "S�lo es posible regularizr piezas de tejido estampado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 		return false;
// 	}
	return true;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
