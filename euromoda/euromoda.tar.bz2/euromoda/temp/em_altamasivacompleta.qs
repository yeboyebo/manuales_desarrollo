/***************************************************************************
                 em_altamasivacompleta.qs  -  description
                             -------------------
    begin                : jue oct 22 2009
    copyright            : (C) 2009 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { 
		return this.ctx.interna_init(); 
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
	function calculateCounter(curAM) {
		return this.ctx.interna_calculateCounter(curAM);
	}
	function preloadMainFilter() {	
		return this.ctx.interna_preloadMainFilter();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {

	var SEL, DISENO, DIBUJO, DESCRIPCION, TIPO_DIBUJO, PROV_ESTAMPACION, PANOT_CONT, MARGEN_EST, LISO;
	var colorSel, colorNoSel, colorTrue, colorFalse;
	var tDisenos_;
	var aColores_;
	var modificado_;
	var preguntado_;
	var saltarRepetidos_;
	var cxTx_;
	var tblDibujos_;
	var curDibujo_;
	var objConfig_;
	var tblCostes_;
	var curArticulo_;
	var curPlantilla_;
    function oficial( context ) { interna( context ); } 
    function colores()
    {
    	return this.ctx.oficial_colores();
    }
    /*function iniciarTabla()
    {
    	return this.ctx.oficial_iniciarTabla();
    }*/
    function informarTabla()
    {
    	return this.ctx.oficial_informarTabla();
    }
    function pintarFila(idDibujo)
    {
    	return this.ctx.oficial_pintarFila(idDibujo);
    }
    function tDisenos_clicked(f, c)
    {
    	return this.ctx.oficial_tDisenos_clicked(f, c);
    }
    function colSelClicked(f)
	{
		return this.ctx.oficial_colSelClicked(f);
	}
	function guardarListaDibujosDisenos() {
		return this.ctx.oficial_guardarListaDibujosDisenos();
	}
	function marcarSeleccionados()
	{
		return oficial_marcarSeleccionados();
	}
	function obtenerListaDibujos() 
	{
		return this.ctx.oficial_obtenerListaDibujos();
	}
	function obtenerListaDisenos() 
	{
		return this.ctx.oficial_obtenerListaDisenos();
	}
	function muestraDatosDiseno()
	{
		return this.ctx.oficial_muestraDatosDiseno();
	}
	function cargaImagen(imagen)
	{
		return this.ctx.oficial_cargaImagen(imagen);
	}
	function editarDibujo()
	{
		return this.ctx.oficial_editarDibujo();
	}
	function commitDibujos() {
		return this.ctx.oficial_commitDibujos();
	}
	function agregarSTC_clicked()
	{
		return this.ctx.oficial_agregarSTC_clicked();
	}
	function tbnPonColores_clicked()
	{
		return this.ctx.oficial_tbnPonColores_clicked();
	}
	function cargaColores()
	{
		return this.ctx.oficial_cargaColores();
	}
	function tdbAltaMasivaSubfamilia_bufferCommited()
	{
		return this.ctx.oficial_tdbAltaMasivaSubfamilia_bufferCommited();
	}
	function cargaTamanos()
	{
		return this.ctx.oficial_cargaTamanos();
	}
	function conectar()
	{
		return this.ctx.oficial_conectar();
	}
	function filtraTamanos()
	{
		return this.ctx.oficial_filtraTamanos();
	}
	function tdbTamanosSubfam_primaryKeyToggled(idTS, sel)
	{
		return this.ctx.oficial_tdbTamanosSubfam_primaryKeyToggled(idTS, sel);
	}
	function dibujosSeleccionados() 
	{
		return this.ctx.oficial_dibujosSeleccionados();
	}
	function calculaDibujos()
	{
		return this.ctx.oficial_calculaDibujos();
	}
	function crearDibujoSubfam(codDibujo, codSubfamilia)
	{
		return this.ctx.oficial_crearDibujoSubfam(codDibujo, codSubfamilia);
	}
	function crearDibujoTamSubfam(codDibujo, codSubfamilia, codTamano)
	{
		return this.ctx.oficial_crearDibujoTamSubfam(codDibujo, codSubfamilia, codTamano);
	}
	function crearDibujoColor(codDibujo, codColor)
	{
		return this.ctx.oficial_crearDibujoColor(codDibujo, codColor);
	}
	function crearSubtablasDibujos(aLAMC)
	{
		return this.ctx.oficial_crearSubtablasDibujos(aLAMC);
	}
	function creaAltas()
	{
		return this.ctx.oficial_creaAltas();
	}
	function seleccionarTodo()
	{
		return this.ctx.oficial_seleccionarTodo();
	}
	function seleccionarNuevos()
	{
  		return this.ctx.oficial_seleccionarNuevos();
	}
	function deseleccionarTodo()
	{
		return this.ctx.oficial_deseleccionarTodo();
	}
	function filtraArticulos()
	{
		return this.ctx.oficial_filtraArticulos();
	}
	function ordenTablaArticulos()
	{
		return this.ctx.oficial_ordenTablaArticulos();
	}
	function habilitarPorEstado()
	{
		return this.ctx.oficial_habilitarPorEstado();
	}
	function generarDibujos_clicked()
	{
		return this.ctx.oficial_generarDibujos_clicked();
	}
	function crearDibujo(codDiseno)
	{
		return this.ctx.oficial_crearDibujo(codDiseno);
	}
	function datosDibujo(curDib,codDiseno)
	{
		return this.ctx.oficial_datosDibujo(curDib,codDiseno);
	}
	function inicializarValores()
	{
		return this.ctx.oficial_inicializarValores();
	}
	function seleccionarTodoArt() {
		return this.ctx.oficial_seleccionarTodoArt();
	}
	function deseleccionarTodoArt() {
		return this.ctx.oficial_deseleccionarTodoArt();
	}
	function tbnGenerarFT_clicked() {
		return this.ctx.oficial_tbnGenerarFT_clicked();
	}
	function pbnEnRevision_clicked() {
		return this.ctx.oficial_pbnEnRevision_clicked();
	}
	function pbnEnProduccion_clicked() {
		return this.ctx.oficial_pbnEnProduccion_clicked();
	}
	function liberaUsuario() {
		return this.ctx.oficial_liberaUsuario();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function pushButtonCancel_clicked(){
    	return this.ctx.oficial_pushButtonCancel_clicked();
  	}
  	function abreCxTx() {
		return this.ctx.oficial_abreCxTx();
	}
	function dameTablaDibujos()
	{
		return this.ctx.oficial_dameTablaDibujos();
	}	
	function cargaDatosDibujos() {
		return this.ctx.oficial_cargaDatosDibujos();
	}
	function selectedFunction(pk,sel) {
		return this.ctx.oficial_selectedFunction(pk,sel);
	}
	function creaSubtablaDibujos() {
		return this.ctx.oficial_creaSubtablaDibujos();
	}
	function borrarTabla() {
		return this.ctx.oficial_borrarTabla();
	}
	function subirOrden() {
		return this.ctx.oficial_subirOrden();
	}
	function bajarOrden() {
		return this.ctx.oficial_bajarOrden();
	}
	function intercambiarOrden(cursor, row1, direccion) {
		return this.ctx.oficial_intercambiarOrden(cursor, row1, direccion);
	}
	function reordenar() {
		return this.ctx.oficial_reordenar();
	}
	function pbnAgregarPlantilla_clicked() {
		return this.ctx.oficial_pbnAgregarPlantilla_clicked();
	}
	function pbnBorrarPlantilla_clicked() {
		return this.ctx.oficial_pbnBorrarPlantilla_clicked();
	}
	function altaPlantillaAltaMasivaCompleta(curPA) {
		return this.ctx.oficial_altaPlantillaAltaMasivaCompleta(curPA);
	}
	function altaDatosPlantilla(curPA) {
		return this.ctx.oficial_altaDatosPlantilla(curPA);
	}
	function bajaDatosPlantilla(curPA) {
		return this.ctx.oficial_bajaDatosPlantilla(curPA);
	}
	function construirObjetoConfiguracion(curPA) {
		return this.ctx.oficial_construirObjetoConfiguracion(curPA);
	}
	function hayDibujosPanotContSeleccionados(tipo, codAlta) {
		return this.ctx.oficial_hayDibujosPanotContSeleccionados(tipo, codAlta);
	}
	function insertarEnObjetoSTC(codColorem,codSubfamilia,codTamanoC,codTamanoP) {
		return this.ctx.oficial_insertarEnObjetoSTC(codColorem,codSubfamilia,codTamanoC,codTamanoP);
	}
	function crearAltaMasivaTamSub(codAlta, codSubfamilia, codTam) {
		return this.ctx.oficial_crearAltaMasivaTamSub(codAlta, codSubfamilia, codTam);
	}
	function crearAltaMasivaSubFam(codAlta, codSubfamilia) {
		return this.ctx.oficial_crearAltaMasivaSubFam(codAlta, codSubfamilia);
	}
	function crearAltaMasivaColor(codAlta, codColor) {
		return this.ctx.oficial_crearAltaMasivaColor(codAlta, codColor);
	}
	function bajaPlantillaAltaMasivaCompleta(curPA) {
		return this.ctx.oficial_bajaPlantillaAltaMasivaCompleta(curPA);
	}
	function cierraMultiChecks() {
		return this.ctx.oficial_cierraMultiChecks();
	}
	function aplicarQuitarPlantillas() {
		return this.ctx.oficial_aplicarQuitarPlantillas();
	}
	function hayPlantillas() {
		return this.ctx.oficial_hayPlantillas();
	}
	function cargaDatosCostes() {
		return this.ctx.oficial_cargaDatosCostes();
	}
	function dameTablaCostes() {
		return this.ctx.oficial_dameTablaCostes();
	}
  	function pbnTodosCostes_clicked() {
  		return this.ctx.oficial_pbnTodosCostes_clicked();
  	}
	function pbnNingunoCostes_clicked() {
  		return this.ctx.oficial_pbnNingunoCostes_clicked();
  	}
	function tbnEmRegenerarCostes_clicked() {
  		return this.ctx.oficial_tbnEmRegenerarCostes_clicked();
  	}
	function tbnEmCargarCostes_clicked() {
  		return this.ctx.oficial_tbnEmCargarCostes_clicked();
  	}
	function pbnEditarTama_clicked() {
  		return this.ctx.oficial_pbnEditarTama_clicked();
  	}
	function pbnEditarPlantilla_clicked() {
  		return this.ctx.oficial_pbnEditarPlantilla_clicked();
  	}
  	function editarArticulo() {
  		return this.ctx.oficial_editarArticulo();
  	}
  	function refrescaTabla() {
  		return this.ctx.oficial_refrescaTabla();
  	}
  	function tbwArticulo_currentChanged(nombreTab) {
  		return this.ctx.oficial_tbwArticulo_currentChanged(nombreTab);
  	}
    function toolButtonInsertSF_clicked() {
        return this.ctx.oficial_toolButtonInsertSF_clicked();
    }
    function toolButtonEditSF_clicked() {
        return this.ctx.oficial_toolButtonEditSF_clicked();
    }
    function toolButtonZoomSF_clicked() {
        return this.ctx.oficial_toolButtonZoomSF_clicked();
    }
    
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	
	if (!_i.abreCxTx()) {
		return false;
	}
  	_i.curArticulo_ = new FLSqlCursor("articulos");
	connect(_i.curArticulo_, "commited()", _i, "refrescaTabla");

	
  	cursor.setAskForCancelChanges(false);

	//_i.tDisenos_ = this.child("tblDisenosDibujos");
	
	this.child("lnEditDibujante").setDisabled("true");
	this.child("lnEditProcesoEstampacion").setDisabled("true");
	this.child("lnEditSentido").setDisabled("true");
	this.child("txtObservaciones").setDisabled("true");

	//connect(_i.tDisenos_, "clicked(int, int)", _i, "tDisenos_clicked");
	connect(this.child("pbnAgregar"), "clicked()", _i, "informarTabla");
	connect(this.child("pbnBorrar"), "clicked()", _i, "borrarTabla");
	
	connect(this.child("pbnAgregarSCT"), "clicked()", _i, "agregarSTC_clicked");

	connect(this.child("tbnPonColores"), "clicked()", _i, "tbnPonColores_clicked");
	connect(this.child("tdbAltaMasivaSubfamilia").cursor(), "bufferCommited()", _i, "tdbAltaMasivaSubfamilia_bufferCommited");
	connect(this.child("tdbTamanosSubfam"), "primaryKeyToggled(QVariant, bool)", _i, "tdbTamanosSubfam_primaryKeyToggled");
	connect(this, "formReady()", _i, "conectar");
	connect(this.child("pbnCrear"),"clicked()", _i, "creaAltas()");
  	connect(this.child("pbnSeleccionar"), "clicked()", _i, "seleccionarTodo");
	connect(this.child("pbnSelNuevos"), "clicked()", _i, "seleccionarNuevos");
	connect(this.child("pbnGenerarDibujos"), "clicked()", _i, "generarDibujos_clicked")
	connect(this.child("tbnSubir"),"clicked()", _i, "subirOrden");
	connect(this.child("tbnBajar"),"clicked()", _i, "bajarOrden");
	connect(this.child("tbnReordenar"),"clicked()", _i, "reordenar");

    connect(this.child("toolButtonInsertSF"),"clicked()", _i, "toolButtonInsertSF_clicked");
    connect(this.child("toolButtonEditSF"),"clicked()", _i, "toolButtonEditSF_clicked");
    connect(this.child("toolButtonZoomSF"),"clicked()", _i, "toolButtonZoomSF_clicked");   


	connect(this.child("pbnTodosCostes"),"clicked()", _i, "pbnTodosCostes_clicked");
	connect(this.child("pbnNingunoCostes"),"clicked()", _i, "pbnNingunoCostes_clicked");
	connect(this.child("tbnEmRegenerarCostes"),"clicked()", _i, "tbnEmRegenerarCostes_clicked");
	connect(this.child("tbnEmCargarCostes"),"clicked()", _i, "tbnEmCargarCostes_clicked");
	connect(this.child("pbnEditarTama"),"clicked()", _i, "pbnEditarTama_clicked");
	connect(this.child("pbnEditarPlantilla"),"clicked()", _i, "pbnEditarPlantilla_clicked");

	//this.child("tdbArticulos").cursor().setAction("em_fichatecnica");

	connect(this.child("pbnDeseleccionar"), "clicked()", _i, "deseleccionarTodo");

	//this.child("tbwDibujos").setTabEnabled("Plantilla", false);

	var cols = ["codsubfamilia", "dessubfamilia"];
	this.child("tdbAltaMasivaSubfamilia").setOrderCols(cols);
	this.child("tdbTamanosSubfam").setColumnWidth("orden", 1);
	this.child("tdbAltaMasivaSubfamilia").setReadOnly(false);

	this.child("tdbAltaMasivaSubfamilia").setColumnWidth("codsubfamilia",50);

	_i.tblDibujos_ = false;

	_i.curDibujo_ = new FLSqlCursor("em_dibujos");

	connect(this.child("pbnSeleccionarArt"), "clicked()", _i, "seleccionarTodoArt");
	
	connect(this.child("pbnDeseleccionarArt"), "clicked()", _i, "deseleccionarTodoArt");

	connect(this.child("tbnGenerarFT"), "clicked()", _i, "tbnGenerarFT_clicked");

	connect(this.child("pbnEnRevision"), "clicked()", _i, "pbnEnRevision_clicked");
	connect(this.child("pbnEnProduccion"), "clicked()", _i, "pbnEnProduccion_clicked");

	if(this.child("pushButtonAccept")) {
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
		connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	}

	connect(this.child("pbnAgregarPlantilla"), "clicked()", _i, "pbnAgregarPlantilla_clicked");
	connect(this.child("pbnBorrarPlantilla"), "clicked()", _i, "pbnBorrarPlantilla_clicked");
	
	disconnect(this.child("pushButtonCancel"), "clicked()", this.obj(), "reject()");
	connect(this.child("pushButtonCancel"), "clicked()", _i, "pushButtonCancel_clicked");

	connect(this.child("pbnAplicarPlantillas"),"clicked()",_i,"aplicarQuitarPlantillas()");
	connect(this.child("tdbPlantillas").cursor(), "bufferCommited()", _i, "habilitarPorEstado()");

	var tdbLineasAltaMasiva = this.child("tdbLineasAltaMasivaCompleta");
	var dtbLineasAM = this.mainWidget().child("tdbLineasAltaMasivaCompleta").tableRecords();
	dtbLineasAM.setSort(["idlinea ASC"]);
	dtbLineasAM.refresh(AQS.RefreshData);

	_i.colores();

	_i.cargaDatosDibujos();

	_i.marcarSeleccionados();
	
	_i.muestraDatosDiseno();
	
	_i.ordenTablaArticulos();
	_i.filtraArticulos();
	_i.habilitarPorEstado();



	if(cursor.modeAccess() == cursor.Insert) {
		this.child("tdbArticulos").cursor().setAction("em_fichatecnica");
		_i.inicializarValores();
	}
	_i.tblCostes_ = false;

	connect(this.child("tabWidget5"), "currentChanged(QString)", _i, "tbwArticulo_currentChanged()");
	_i.cargaDatosCostes();

}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var hoy = new Date();
	var ahora = hoy.toString().right(8);

	if(cursor.modeAccess() == cursor.Insert) {
		cursor.setValueBuffer("usuarioalta", sys.nameUser());
		cursor.setValueBuffer("fechaalta", hoy);
		cursor.setValueBuffer("horaalta", ahora);
	}
	else {
		if(cursor.modeAccess() == cursor.Edit) {
			cursor.setValueBuffer("usuariomod", sys.nameUser());
			cursor.setValueBuffer("fechamod", hoy);
			cursor.setValueBuffer("horamod", ahora);
		}
	}
	
	_i.guardarListaDibujosDisenos();

	_i.muestraDatosDiseno();

  	return true;
}

function interna_calculateCounter(curAM)
{
	var prefijo = "";
	var ultimaAlta = AQUtil.sqlSelect("em_secuenciasaltamas","valor","1=1");

	if(!ultimaAlta) {
		var idUltima = AQUtil.sqlSelect("em_altamasivacompleta", "codigo", "1=1 ORDER BY codigo DESC");

		if (idUltima) {
			ultimaAlta = parseFloat(idUltima.right(8));
		} else {
			ultimaAlta = 0;
		}

		ultimaAlta += 1;
		AQUtil.sqlInsert("em_secuenciasaltamas","valor",ultimaAlta);
	} else {
		ultimaAlta += 1;
		AQUtil.sqlUpdate("em_secuenciasaltamas","valor",ultimaAlta,"1=1");
	}

	var id = flfacturac.iface.pub_cerosIzquierda((ultimaAlta).toString(), 8);

	return id;
}

function interna_preloadMainFilter()
{
	var _i = this.iface;
		
	
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_colores()
{
	var _i = this.iface;

	_i.colorNoSel = new Color("grey");
	_i.colorSel = new Color("green");
	_i.colorTrue = /*new Color("green");*/new Color(112, 182, 117);
    _i.colorFalse = /*new Color("red");*/new Color(200, 100, 150);
}

/*function oficial_iniciarTabla()
{
	var _i = this.iface;

	var labels = [];
	var c = 0;

	_i.SEL = c++;
	_i.DISENO = c++;
	_i.DIBUJO = c++;
	_i.DESCRIPCION = c++;
	_i.TIPO_DIBUJO = c++;
	_i.PROV_ESTAMPACION = c++;
	_i.PANOT_CONT = c++;
	_i.MARGEN_EST = c++;
	_i.LISO = c++;

	labels[_i.SEL] = "Sel.";
	labels[_i.DISENO] = "Dise�o";
	labels[_i.DIBUJO] = "Dibujo";
	labels[_i.DESCRIPCION] = "Descripci�on";
	labels[_i.TIPO_DIBUJO] = "Tipo";
	labels[_i.PROV_ESTAMPACION] = "Prov.Estampaci�n";
	labels[_i.PANOT_CONT] = "P/C";
	labels[_i.MARGEN_EST] = "Margen Est. (cm)";
	labels[_i.LISO] = "Liso";

	
  	_i.tDisenos_.setNumCols(c);
	_i.tDisenos_.setColumnWidth(_i.SEL, 35);
	_i.tDisenos_.setColumnWidth(_i.DISENO, 50);
	_i.tDisenos_.setColumnWidth(_i.DIBUJO, 50);
	_i.tDisenos_.setColumnWidth(_i.DESCRIPCION, 170);
	_i.tDisenos_.setColumnWidth(_i.TIPO_DIBUJO, 70);
	_i.tDisenos_.setColumnWidth(_i.PROV_ESTAMPACION, 100);
	_i.tDisenos_.setColumnWidth(_i.PANOT_CONT, 60);
	_i.tDisenos_.setColumnWidth(_i.MARGEN_EST, 50);
	_i.tDisenos_.setColumnWidth(_i.LISO, 40);
	

  	_i.tDisenos_.setColumnReadOnly(_i.SEL, true);
  	_i.tDisenos_.setColumnReadOnly(_i.DISENO, true);
  	_i.tDisenos_.setColumnReadOnly(_i.DIBUJO, true);
  	_i.tDisenos_.setColumnReadOnly(_i.DESCRIPCION, true);
  	_i.tDisenos_.setColumnReadOnly(_i.TIPO_DIBUJO, true);
  	_i.tDisenos_.setColumnReadOnly(_i.PROV_ESTAMPACION, true);
  	_i.tDisenos_.setColumnReadOnly(_i.PANOT_CONT, true);
  	_i.tDisenos_.setColumnReadOnly(_i.MARGEN_EST, true);
  	_i.tDisenos_.setColumnReadOnly(_i.LISO, true);
 
	_i.tDisenos_.setColumnLabels("*", labels.join("*"));
}*/

function oficial_pintarFila(idDibujo)
{
	var _i = this.iface;
	
	for(var f = 0;f < _i.tDisenos_.numRows();f++) {
		if(idDibujo == _i.tDisenos_.text(f, _i.DIBUJO)) {

			var q = new FLSqlQuery();
			q.setSelect("s.coddiseno, b.coddibujoem, s.descripcion, b.descripcion, b.tipo, b.codproveedor, b.panotcont, b.em_margenest, b.liso");
			q.setFrom("em_disenos s left outer join em_dibujos b on s.coddiseno = b.coddiseno");  
			q.setWhere("b.coddibujoem = " + idDibujo);
			if (!q.exec()) {
		    	return false;
		    }

		    if(!q.first()) {
		    	return false;
		    }

		    var descripcion = "";
		    var margen = "";

		    if(q.value("b.descripcion") && q.value("b.descripcion") != "") {
				descripcion = q.value("b.descripcion");
			}
			else {
				descripcion = q.value("s.descripcion");
			}

			var margen = q.value("b.em_margenest");
			if(!margen || margen == 0)
				margen = "";

			_i.tDisenos_.setText(f, _i.DISENO, q.value("s.coddiseno"));
		  	_i.tDisenos_.setText(f, _i.DESCRIPCION, descripcion);
		  	_i.tDisenos_.setText(f, _i.TIPO_DIBUJO, q.value("b.tipo"));
		  	_i.tDisenos_.setText(f, _i.PROV_ESTAMPACION, q.value("b.codproveedor"));
		  	_i.tDisenos_.setText(f, _i.PANOT_CONT, q.value("b.panotcont"));
		  	_i.tDisenos_.setText(f, _i.MARGEN_EST, margen);
		  	_i.tDisenos_.setText(f, _i.LISO, q.value("b.liso"));

		  	if(q.value("b.liso") == true) {
		  		_i.tDisenos_.setCellBackgroundColor(f, _i.LISO, _i.colorTrue);
		  	}
		  	else {
		  		_i.tDisenos_.setCellBackgroundColor(f, _i.LISO, _i.colorFalse);
		  	}
		}
	}

	return true;
}

function oficial_informarTabla()
{

	var _i = this.iface;

	_i.creaSubtablaDibujos();
	_i.cargaDatosDibujos();

	/*for(var f = 0;f < _i.tDisenos_.numRows();f++) {
		_i.tDisenos_.removeRow(f);
	}
	_i.tDisenos_.clear();

	var listaDibujos = _i.obtenerListaDibujos();
	var listaDisenos = _i.obtenerListaDisenos();

	var q = new FLSqlQuery();
	q.setSelect("s.coddiseno, b.coddibujoem, s.descripcion, b.descripcion, b.tipo, b.codproveedor, b.panotcont, b.em_margenest, b.liso");
	q.setFrom("em_disenos s left outer join em_dibujos b on s.coddiseno = b.coddiseno");  

	var where = "";

	if(listaDibujos && listaDibujos != "") {
		where = "b.coddibujoem in (" + listaDibujos + ")";
	}2017

	if(listaDisenos && listaDisenos != "") {
		if(where && where != "") {
			where += " OR "
		}
		where += "s.coddiseno in (" + listaDisenos + ")";
	}

	if(!where || where == "") {
		where = "1=2";
	}

	q.setWhere(where + " order by s.coddiseno, b.coddibujoem");
		
	//debug(q.sql());
    if (!q.exec()) {
    	return false;
    }

    var f = 0;
    var descripcion = "";
    while(q.next()) {
		_i.tDisenos_.insertRows(f);
		_i.tDisenos_.setText(f, _i.SEL, "");
		_i.tDisenos_.setCellBackgroundColor(f, _i.SEL, _i.colorNoSel);

		if(q.value("b.descripcion") && q.value("b.descripcion") != "") {
			descripcion = q.value("b.descripcion");
		}
		else {
			descripcion = q.value("s.descripcion");
		}

		var dibujo = q.value("b.coddibujoem");
		if(!dibujo || dibujo == 0)
			dibujo = "";

		var margen = q.value("b.em_margenest");
		if(!margen || margen == 0)
			margen = "";

		_i.tDisenos_.setText(f, _i.DISENO, q.value("s.coddiseno"));
	  	_i.tDisenos_.setText(f, _i.DIBUJO, dibujo);
	  	_i.tDisenos_.setText(f, _i.DESCRIPCION, descripcion);
	  	_i.tDisenos_.setText(f, _i.TIPO_DIBUJO, q.value("b.tipo"));
	  	_i.tDisenos_.setText(f, _i.PROV_ESTAMPACION, q.value("b.codproveedor"));
	  	_i.tDisenos_.setText(f, _i.PANOT_CONT, q.value("b.panotcont"));
	  	_i.tDisenos_.setText(f, _i.MARGEN_EST, margen);
	  	_i.tDisenos_.setText(f, _i.LISO, q.value("b.liso"));

	  	if(q.value("b.liso") == true) {
	  		_i.tDisenos_.setCellBackgroundColor(f, _i.LISO, _i.colorTrue);
	  	}
	  	else {
	  		_i.tDisenos_.setCellBackgroundColor(f, _i.LISO, _i.colorFalse);
	  	}
	  	f++;
    }*/
	return true;
}

function oficial_tDisenos_clicked(f, c)
{
	var _i = this.iface;
	switch (c) {
		case _i.SEL: {
			_i.colSelClicked(f);
			break;
		}

		default: {
			_i.muestraDatosDiseno();
			break;
		}
	}
	
	if(_i.tblDibujos_.isCheckColumnLocked()) {
		this.child("tbnSubir").setDisabled(true);
		this.child("tbnBajar").setDisabled(true);
	}
	else {
		var id = _i.tblDibujos_.cellValue(f, "em_disenosaltamasivacompleta.id");
	
		var aDibujos = _i.tblDibujos_.primarysKeysChecked();
		var listaSel = aDibujos.toString();

		if(listaSel.find(id,0) == -1) {
			this.child("tbnSubir").setDisabled(true);
			this.child("tbnBajar").setDisabled(true);
		}
		else {
			this.child("tbnSubir").setDisabled(false);
			this.child("tbnBajar").setDisabled(false);
		}
	}

}

function oficial_colSelClicked(f)
{
  var _i = this.iface;
  var cursor = this.cursor();

  if(cursor.valueBuffer("estado") != "CARGA_DIBUJOS") {
  	return true;
  }

  var c = _i.SEL;
  if (_i.tDisenos_.text(f, c) == "") {
    _i.tDisenos_.setText(f, c, "X");
    _i.tDisenos_.setCellBackgroundColor(f, c, _i.colorSel);
  } else {
    _i.tDisenos_.setText(f, c, "");
    _i.tDisenos_.setCellBackgroundColor(f, c, _i.colorNoSel);
  }

  return true;
}

function oficial_marcarSeleccionados()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var listaSel = cursor.valueBuffer("listaseleccionados");
	
	var aSel = listaSel.split(",");

	for(var d = 0;d < aSel.length;d++) {
		if(aSel[d] && aSel[d] != "") {
			_i.tblDibujos_.setPrimaryKeyChecked(aSel[d], true, true);
		}
	}
	
	_i.tblDibujos_.refresh();

	return true;
}

function oficial_guardarListaDibujosDisenos()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var aDibujos = _i.tblDibujos_.primarysKeysChecked();

	var listaSel = aDibujos.toString();

	if(listaSel.endsWith(",")) {
		listaSel = listaSel.left(listaSel.length-1);
	}

	cursor.setValueBuffer("listaseleccionados",listaSel);

	return listaSel;
}

function oficial_obtenerListaDibujos()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var listaDibujos = formRecordem_altamasiva.iface.formateaStringFiltro(cursor.valueBuffer("listadibujos"));

	var dibujosComa = [];
	var dibujosGuion = [];

	var listaIds = "";

	if (listaDibujos && listaDibujos != "") {
		dibujosComa = listaDibujos.split(",");
		for(var i=0;i<dibujosComa.length;i++) {
			dibujosGuion = dibujosComa[i].split("-");
			if(dibujosGuion && dibujosGuion.length > 1) {
				var ultimoDibujo = dibujosGuion[1];
				var dibujoActual = dibujosGuion[0];
				while(dibujoActual <= ultimoDibujo) {
					if(listaIds && listaIds != "") {
						listaIds += ",";
					}
					listaIds += dibujoActual;
					dibujoActual++;
				}
			}
			else {
				if(listaIds && listaIds != "") {
					listaIds += ",";
				}
				listaIds += dibujosComa[i];
			}
		}
	}

	return listaIds;
}

function oficial_obtenerListaDisenos()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var listaDisenos = formRecordem_altamasiva.iface.formateaStringFiltro(cursor.valueBuffer("listadisenos"));

	var disenosComa = [];
	var disenosGuion = [];

	var listaIds = "";

	if (listaDisenos && listaDisenos != "") {
		disenosComa = listaDisenos.split(",");
		for(var i=0;i<disenosComa.length;i++) {
			disenosGuion = disenosComa[i].split("-");
			if(disenosGuion && disenosGuion.length > 1) {
				var ultimoDiseno = disenosGuion[1];
				var disenoActual = disenosGuion[0];
				while(disenoActual <= ultimoDiseno) {
					if(listaIds && listaIds != "") {
						listaIds += ",";
					}
					listaIds += disenoActual;
					disenoActual++;
				}
			}
			else {
				if(listaIds && listaIds != "") {
					listaIds += ",";
				}
				listaIds += disenosComa[i];
			}
		}
	}

	return listaIds;
}

function oficial_editarDibujo()
{
	var _i = this.iface;
	
	//var codDiseno = _i.tblDibujos_.dameCursor().valueBuffer("coddiseno");
	var row = _i.tblDibujos_.fActual_;
	var idDibujo = _i.tblDibujos_.cellValue(row, "em_dibujos.coddibujoem");
	/*if(!codDiseno || codDiseno == "") {
		return;
	}*/
	//var idDibujo = AQUtil.sqlSelect("em_dibujos","coddibujoem","coddiseno = '" + codDiseno + "'")
	if(!idDibujo) {
		sys.warnMsgBox(sys.translate("El registro seleccionado no contiene ning�n dibujo"));
		return false;
	}

	
	_i.curDibujo_.select("coddibujoem = " + idDibujo);
	if(!_i.curDibujo_.first()) {
		return;
	}

	disconnect(_i.curDibujo_, "bufferCommited()", _i, "commitDibujos");
	connect(_i.curDibujo_, "bufferCommited()", _i, "commitDibujos");	

	if(this.cursor().valueBuffer("estado") != "CARGA_DIBUJOS") {
		_i.curDibujo_.browseRecord();
	}
	else {
		_i.curDibujo_.editRecord();
	}
	

	/*var f = new FLFormSearchDB("em_editdibujos");
	var cursor = f.cursor();
	//cursor.setAction("em_editdibujos");
	cursor.select("coddibujoem = " + idDibujo);	
	if(!cursor.first()) {
		sys.warnMsgBox(sys.translate("No se encontr� el dibujo " + idDibujo));
		return false;
	}
	
	if(this.cursor().valueBuffer("estado") != "CARGA_DIBUJOS") {
		cursor.setModeAccess(cursor.Browse);	
	}
	else {
		cursor.setModeAccess(cursor.Edit);

	}

	f.setMainWidget();
	//Este filtro lo pongo porque recien creado el dibujo no le aplica el filro que lleva el formulario.
	f.child("tdbDibujosColor").setFilter("coddibujoem = " + idDibujo);
	f.child("tdbDibujosColor").refresh();
	
	f.child("tdbCoordinados").setFilter("coddibujoem = " + idDibujo);
	f.child("tdbCoordinados").refresh();
	//cursor.setAction("em_editdibujos");
	cursor.refreshBuffer();
	cursor.transaction(false);	
	

	f.exec("coddibujoem");
	var	acpt = f.accepted();
	if (!acpt) {
		cursor.rollback();
	} else {
		if (cursor.commitBuffer()) {
			cursor.commit();
			_i.cargaDatosDibujos();
		}
	}

	_i.tblDibujos_.currentChanged(row,"em_disenosaltamasivacompleta.orden");
	*/
	return true;
}

function oficial_commitDibujos()
{
	var _i = this.iface;

	var row = _i.tblDibujos_.fActual_;
	var idSel = _i.tblDibujos_.cellValue(row, "em_disenosaltamasivacompleta.id");
	var codDibujo = _i.tblDibujos_.cellValue(row, "em_dibujos.coddibujoem");



	var codDisenoGrid = _i.tblDibujos_.cellValue(row, "em_disenosaltamasivacompleta.coddiseno");

	
	var codDisenoTabla = AQUtil.sqlSelect("em_dibujos","coddiseno","coddibujoem = " + codDibujo);
	

	if(codDisenoGrid != codDisenoTabla) {
		AQUtil.sqlUpdate("em_disenosaltamasivacompleta","coddiseno",codDisenoTabla,"id = " + idSel);
	}

	var descGrid = _i.tblDibujos_.cellValue(row, "em_disenosaltamasivacompleta.descripcion");
	var descTabla = AQUtil.sqlSelect("em_dibujos","descripcion","coddibujoem = " + codDibujo);
	if(descGrid != descTabla) {
		AQUtil.sqlUpdate("em_disenosaltamasivacompleta","descripcion",descTabla,"id = " + idSel);
	}

	_i.cargaDatosDibujos();

	_i.tblDibujos_.currentChanged(row,"em_disenosaltamasivacompleta.orden");
}

function oficial_muestraDatosDiseno()
{
	var _i = this.iface;

	this.child("lnEditDibujante").text = "";
	this.child("lnEditProcesoEstampacion").text = "";
	this.child("lnEditSentido").text = "";
	this.child("txtObservaciones").text = "";
	_i.cargaImagen("vacia");

	var idDiseno = _i.tblDibujos_.dameCursor().valueBuffer("coddiseno");//_i.tDisenos_.text(f, _i.DISENO);
	if(!idDiseno) {
		return false;
	}

	var codDibujante = AQUtil.sqlSelect("em_disenos","coddibujante","coddiseno = "  + idDiseno);
	if(codDibujante && codDibujante != "") {
		var dibujante = codDibujante + " - " + AQUtil.sqlSelect("em_dibujantes","descripcion","coddibujante = '" + codDibujante + "'");
		this.child("lnEditDibujante").text = dibujante;
	}

	this.child("lnEditProcesoEstampacion").text = AQUtil.sqlSelect("em_disenos","codprocesoestamp","coddiseno = "  + idDiseno);
	this.child("lnEditSentido").text = AQUtil.sqlSelect("em_disenos","codsentido","coddiseno = "  + idDiseno);
	this.child("txtObservaciones").text = AQUtil.sqlSelect("em_disenos","observaciones","coddiseno = "  + idDiseno);

	_i.cargaImagen(AQUtil.sqlSelect("em_disenos","urlbajaresolucion","coddiseno = "  + idDiseno));

	return true;
}

function oficial_cargaImagen(imagen)
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(!imagen || imagen == "")
		return;

	var i = new QImage;
	i.load(imagen);
	var s = this.child("lblImagen").size;
	var i2 = i.scale(s, AQS.ScaleMin);
	var p = new QPixmap;
	p.convertFromImage(i2);
	this.child("lblImagen").pixmap = p;
}

function oficial_agregarSTC_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAlta = cursor.valueBuffer("codigo");
	if(!codAlta || codAlta == "")
		return;


	if(this.child("pbnAgregarSCT").on == true) {
		cursor.setValueBuffer("estado","STC_GENERADO");

		var aSel = _i.tblDibujos_.primarysKeysChecked();
		var seleccionados = aSel.toString();
		if(seleccionados == "" || !seleccionados) {
			return;
		}

		if(AQUtil.sqlSelect("em_disenosaltamasivacompleta","id","coddibujoem is null and codalta = '" + codAlta + "' and id in (" + seleccionados + ")")) {
			var res = MessageBox.warning(sys.translate("Ha seleccionado algunos dise�os sin dibujo asociado. Estos dise�os ser�n ignorados. �Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
			if (res != MessageBox.Yes) {
				return false;
			}
		}

		_i.calculaDibujos();
	}
	else {
		cursor.setValueBuffer("estado","CARGA_DIBUJOS");
	}

	_i.habilitarPorEstado();

	return true;
}

function oficial_tbnPonColores_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbAltaMasivaColor").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}

	_i.aColores_ = false;
	if (!_i.cargaColores()) {
		return false;
	}

	var f = new FLFormSearchDB("em_selcoloresdibujoaltamasiva");
	var c = f.cursor();
	
	f.setMainWidget();
	f.exec();
	if (!f.accepted()) {
		return;
	}
	if (!_i.aColores_) {
		return;
	}

	var codAlta = cursor.valueBuffer("codigo");
	var filtro = "codalta = '" + codAlta + "'";
	
	if (!AQSql.del("em_altamasivacolor", filtro)) {
		return false;
	}
	//   var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	// 	var codDibujo = cursor.valueBuffer("coddibujoem");
	for (var i = 0; i < _i.aColores_.length; i++) {
		//if(listaDibujos && listaDibujos != "") {
		//	var aDibujos = listaDibujos.split(",");
		//	for(var d = 0;d<aDibujos.length;d++) {
				if (!AQSql.insert("em_altamasivacolor", ["codalta", "codcolorem"], [codAlta, _i.aColores_[i]])) {
					return false;
				}
			//}
		//}
	}

	this.child("tdbAltaMasivaColor").refresh();
}

function oficial_cargaColores()
{
	var cursor = this.cursor();
	var _i = this.iface;

	var codAlta = cursor.valueBuffer("codigo");
	var filtro = "codalta = '" + codAlta + "'";

	var q = new FLSqlQuery();
	q.setTablesList("em_altamasivacolor");
	q.setSelect("codcolorem");
	q.setFrom("em_altamasivacolor");
	q.setWhere(filtro);
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}

	_i.aColores_ = [];
	var i = 0;
	while (q.next()) {
		_i.aColores_[i++] = q.value("codcolorem");
	}

	return true;
}

function oficial_tdbAltaMasivaSubfamilia_bufferCommited()
{
	var _i = this.iface;

    this.child("tdbAltaMasivaSubfamilia").cursor().refresh();
    this.child("tdbAltaMasivaSubfamilia").refresh();
	_i.cargaTamanos();
}

function oficial_cargaTamanos()
{
	var _i = this.iface;
	
	var tT = this.child("tdbTamanosSubfam");
	var tS = this.child("tdbAltaMasivaSubfamilia");
	var curS = tS.cursor();
	var idaltasubfam = curS.valueBuffer("idaltasubfam");
	if (!idaltasubfam) {
		return;
	}
	var codSubfamilia = curS.valueBuffer("codsubfamilia");

	var q = new AQSqlQuery;
	q.setSelect("codtamanoem");
	q.setFrom("em_altamasivatamsub");
	q.setWhere("idaltasubfam = " + idaltasubfam);

	if (!q.exec()) {
		return;
	}
	
	var idTS;
	while (q.next()) {
		idTS = AQUtil.sqlSelect("em_tamanossubfam", "idtamanosubfam", "codtamanoem = '" + q.value("codtamanoem") + "' AND codsubfamilia = '" + codSubfamilia + "'");
		if (idTS) {
			tT.setPrimaryKeyChecked(idTS, true);
		}
	}

	tT.refresh();
}

function oficial_conectar()
{
	var _i = this.iface;
	connect(this.child("tdbAltaMasivaSubfamilia").cursor(), "newBuffer()", _i, "filtraTamanos()");
	_i.filtraTamanos();
}

function oficial_filtraTamanos()
{
	var _i = this.iface;
	
	var tT = this.child("tdbTamanosSubfam");
	var tS = this.child("tdbAltaMasivaSubfamilia");
	tT.clearChecked();
	
	var filtro = "1 = 2";
	var curS = tS.cursor();

	var codSubfamilia = curS.valueBuffer("codsubfamilia");
	if (codSubfamilia) {
		filtro = "codsubfamilia = '" + codSubfamilia + "'";
	}
	else {
		filtro = "1=2";
	}

	tT.cursor().setMainFilter(filtro);
	tT.refresh();
	_i.cargaTamanos();
}

function oficial_tdbTamanosSubfam_primaryKeyToggled(idTS, sel)
{
	var _i = this.iface;
	
	if (!idTS || idTS == false) {
		return;
	}
	
	var tS = this.child("tdbAltaMasivaSubfamilia");
	var curS = tS.cursor();
	var cursor = this.cursor();
	
	var codSubfamilia = curS.valueBuffer("codsubfamilia");
	var codTamano = AQUtil.sqlSelect("em_tamanossubfam", "codtamanoem", "idtamanosubfam = " + idTS);
	
	var codAlta = cursor.valueBuffer("codigo");

	var filtro = "codalta = '" + codAlta + "'";
	

	var idaltasubfam = curS.valueBuffer("idaltasubfam");

	if (sel) {
		//var aDibujos = listaDibujos.split(",");
		//for(var d=0;d<aDibujos.length;d++) {
			if (AQUtil.sqlSelect("em_altamasivatamsub", "idaltatamsub", "codalta = '" + codAlta + "' AND codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "'")) {
				return true;
			}
			var curDTS = new FLSqlCursor("em_altamasivatamsub");
			curDTS.setModeAccess(curDTS.Insert);
			curDTS.refreshBuffer();
			curDTS.setValueBuffer("codalta", codAlta);
			curDTS.setValueBuffer("codsubfamilia", codSubfamilia);
			curDTS.setValueBuffer("codtamanoem", codTamano);
			curDTS.setValueBuffer("idaltasubfam", idaltasubfam);
			if (!curDTS.commitBuffer()) {
				return false;
			}
		//}
	} else {
		if (!AQSql.del("em_altamasivatamsub", filtro + " AND codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "'")) {
			return false;
		}
	}
}

function oficial_dibujosSeleccionados()
{
	var _i = this.iface;

	var aDibujos = [];
	
	var aSel = _i.tblDibujos_.primarysKeysChecked();

	var listaDibujos = "";

	var ids = aSel.toString();
	
	if(!ids || ids == "") {
		return "";
	}

	var q = new FLSqlQuery();
	q.setSelect("coddibujoem");
	q.setFrom("em_disenosaltamasivacompleta");
	q.setWhere("id in (" + ids + ") order by orden");
	if(!q.exec())
		return false;
	while(q.next()) {
		if(!q.value("coddibujoem") || q.value("coddibujoem") == "")
			continue;

		if(listaDibujos != "") {
			listaDibujos += ",";
		}
	
		listaDibujos += q.value("coddibujoem");
	}

	/*for(var i = 0;i < aSel.length;i++) {
		if(aSel[i] && aSel[i] != "") {
			var codDibujo = AQUtil.sqlSelect("em_disenosaltamasivacompleta","coddibujoem","id = " + aSel[i]);
			
			if(codDibujo && codDibujo != "") {
				if(listaDibujos && listaDibujos != "") {
					listaDibujos += ",";
				}
				listaDibujos += codDibujo;
			}
		}
	}*/

	return listaDibujos;
}

function oficial_crearSubtablasDibujos(aLAMC)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var qLAMC = new FLSqlQuery;
	qLAMC.setSelect("coddibujoem,codsubfamilia,codcolorem,codtamanoem");
	qLAMC.setFrom("em_lineasaltamasivacompleta");
	qLAMC.setWhere("idlinea in (" + aLAMC.toString() + ") order by coddibujoem,coddiseno,descdibujo,subfamiliaem,codtamanoem,codcolorem,codsubfamilia");
	if (!qLAMC.exec()) {
		return false;
	}

	while(qLAMC.next()) {
		if(!_i.crearDibujoSubfam(qLAMC.value("coddibujoem"),qLAMC.value("codsubfamilia"))) {
				return false;
		}
		if(!_i.crearDibujoTamSubfam(qLAMC.value("coddibujoem"),qLAMC.value("codsubfamilia"),qLAMC.value("codtamanoem"))) {
			return false;
		}
		if(!_i.crearDibujoColor(qLAMC.value("coddibujoem"),qLAMC.value("codcolorem"))) {
			return false;
		}
	}

	/*var codAltaMasiva = cursor.valueBuffer("codigo");
	if(!codAltaMasiva || codAltaMasiva == "") {
		return false;
	}

	var qC = new FLSqlQuery;
	qC.setSelect("codcolorem");
	qC.setFrom("em_altamasivacolor");
	qC.setWhere("codalta = '" + codAltaMasiva + "'");
	if (!qC.exec()) {
		return false;
	}
	
	var qSF = new FLSqlQuery;
	qSF.setSelect("codsubfamilia");
	qSF.setFrom("em_altamasivasubfam");
	qSF.setWhere("codalta = '" + codAltaMasiva + "'");
	if (!qSF.exec()) {
		return false;
	}

	var qTSF = new FLSqlQuery;
	qTSF.setSelect("codtamanoem");
	qTSF.setFrom("em_altamasivatamsub");
	

	var qLAMC = new FLSqlQuery;
	qLAMC.setSelect("coddibujoem,codsubfamilia,codcolorem,codtamanoem");
	qLAMC.setFrom("em_lineasaltamasivacompleta");
	qLAMC.setWhere("idlinea in (" + aLAMC.toString() + ")");
	if (!qLAMC.exec()) {
		return false;
	}

	while(qLAMC.next()) {
		while (qSF.next()) {
			if(!_i.crearDibujoSubfam(qLAMC.value("coddibujoem"),qLAMC.value("codsubfamilia"))) {
				return false;
			}

			qTSF.setWhere("codalta = '" + codAltaMasiva + "' and codsubfamilia = '" + qLAMC.value("codsubfamilia") + "'");
			if (!qTSF.exec()) {
				return false;
			}

			while (qTSF.next()) {
				if(!_i.crearDibujoTamSubfam(qLAMC.value("coddibujoem"),qSF.value("codsubfamilia"),qTSF.value("codtamanoem"))) {
					return false;
				}
			}
		}
		
		while (qC.next()) {
			if(!_i.crearDibujoColor(qLAMC.value("coddibujoem"),qC.value("codcolorem"))) {
				return false;
			}
		}
	}*/

	return true;
}

function oficial_crearDibujoColor(codDibujo, codColor)
{
	var _i = this.iface;

	if(AQUtil.sqlSelect("em_dibujoscolor","coddibujoem","coddibujoem = '" + codDibujo + "' and codcolorem = '" + codColor + "'")) {
		return true;
	}

	var cur = new FLSqlCursor("em_dibujoscolor");
	cur.setModeAccess(cur.Insert);
	cur.refreshBuffer();
	cur.setValueBuffer("coddibujoem", codDibujo);
	cur.setValueBuffer("codcolorem", codColor);
	if(!cur.commitBuffer()) {
		return false;
	}

	/*if(!AQUtil.sqlInsert("em_dibujoscolor","coddibujoem,codcolorem",codDibujo + "," + codColor)) {
		return false;
	}*/

	return true;	
}

function oficial_crearDibujoSubfam(codDibujo, codSubfamilia)
{
	var _i = this.iface;

	if(AQUtil.sqlSelect("em_dibujossubfam","coddibujoem","coddibujoem = '" + codDibujo + "' and codsubfamilia = '" + codSubfamilia + "'")) {
		return true;
	}

	var descDibujo = AQUtil.sqlSelect("em_dibujos","descripcion","coddibujoem = '" + codDibujo + "'");
	var descSubfamilia = AQUtil.sqlSelect("subfamilias","descripcion","codsubfamilia = '" + codSubfamilia + "'");

	var cur = new FLSqlCursor("em_dibujossubfam");
	cur.setModeAccess(cur.Insert);
	cur.refreshBuffer();
	cur.setValueBuffer("coddibujoem", codDibujo);
	cur.setValueBuffer("desdibujo", descDibujo);
	cur.setValueBuffer("codsubfamilia", codSubfamilia);
	cur.setValueBuffer("dessubfamilia", descSubfamilia);
	if(!cur.commitBuffer()) {
		return false;
	}

	/*if(!AQUtil.sqlInsert("em_dibujossubfam","coddibujoem,desdibujo,codsubfamilia,dessubfamilia",codDibujo + "," + descDibujo + "," + codSubfamilia + "," + descSubfamilia)) {
		return false;
	}*/

	return true;	
}

function oficial_crearDibujoTamSubfam(codDibujo, codSubfamilia, codTamano)
{
	var _i = this.iface;

	if(AQUtil.sqlSelect("em_dibujostamsub","coddibujoem","coddibujoem = '" + codDibujo + "' and codsubfamilia = '" + codSubfamilia + "' and codtamanoem = '" + codTamano + "'")) {
		return true;
	}
	var iddibujosubfam = AQUtil.sqlSelect("em_dibujossubfam","iddibujosubfam","coddibujoem = '" + codDibujo + "' and codsubfamilia = '" + codSubfamilia + "'");
	if(!iddibujosubfam) {
		return false;
	}
	

	var curDibTS = new FLSqlCursor("em_dibujostamsub");
	curDibTS.setModeAccess(curDibTS.Insert);
	curDibTS.refreshBuffer();
	curDibTS.setValueBuffer("iddibujosubfam", iddibujosubfam);
	curDibTS.setValueBuffer("coddibujoem", codDibujo);
	curDibTS.setValueBuffer("codsubfamilia", codSubfamilia);
	curDibTS.setValueBuffer("codtamanoem", codTamano);
	if(!curDibTS.commitBuffer()) {
		return false;
	}

	return true;	
}

function oficial_calculaDibujos()
{
  var _i = this.iface;
  var cursor = this.cursor();

  if(!cursor.valueBuffer("codcoleccionem") || cursor.valueBuffer("codcoleccionem") == "") {
  		sys.warnMsgBox(sys.translate("Debe establecer antes la colecci�n"));
  		cursor.setValueBuffer("estado", "CARGA_DIBUJOS");
        _i.habilitarPorEstado();
		return false;
  }

  _i.guardarListaDibujosDisenos();

  _i.modificado_ = true;
  var cursor = this.cursor();
  
  var codAlta = cursor.valueBuffer("codigo");
  var aDibujos = _i.dibujosSeleccionados().split(",");

  if (!aDibujos || aDibujos.length == 0) {
    MessageBox.information(sys.translate("No hay registros seleccionados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }

  // Simula un commit sobre el registro altamasiva en el que se crean las lineas.
  if (cursor.modeAccess() == cursor.Insert) {
    if (!this.child("tdbLineasAltaMasivaCompleta").cursor().commitBufferCursorRelation()) {

    	cursor.setValueBuffer("estado", "CARGA_DIBUJOS");
      _i.habilitarPorEstado();
      return false;
    }
  }
  
  if (!AQSql.del("em_lineasaltamasivacompleta", "codalta = '" + cursor.valueBuffer("codigo") + "'")) {
    return false;
  }
  
  var curLAM = new FLSqlCursor("em_lineasaltamasivacompleta");
  var q = new FLSqlQuery;

  //q.setSelect("c.descripcion,c.codcolorem,s.descripcion, t.descripcion, dts.codsubfamilia, dts.codtamanoem, s.codfamilia, s.em_tipoarticulo, d.descripcion, d.coddiseno");
  //q.setFrom("em_dibujos d INNER JOIN em_dibujoscolor dc ON d.coddibujoem = dc.coddibujoem INNER JOIN em_colores c ON c.codcolorem = dc.codcolorem INNER JOIN em_altamasivatamsub dts ON d.coddibujoem = dts.coddibujoem INNER JOIN subfamilias s ON s.codsubfamilia = dts.codsubfamilia INNER JOIN em_tamanos t ON t.codtamanoem = dts.codtamanoem INNER JOIN em_tamanossubfam ts ON (dts.codsubfamilia = ts.codsubfamilia AND dts.codtamanoem = ts.codtamanoem)");

   q.setSelect("c.descripcion,c.codcolorem,s.descripcion, t.descripcion, dts.codsubfamilia, dts.codtamanoem, s.codfamilia, s.em_tipoarticulo, d.descripcion, d.coddiseno");
  q.setFrom("em_dibujos d, em_altamasivacolor dc INNER JOIN em_colores c ON c.codcolorem = dc.codcolorem, em_altamasivatamsub dts INNER JOIN subfamilias s ON s.codsubfamilia = dts.codsubfamilia INNER JOIN em_tamanos t ON t.codtamanoem = dts.codtamanoem INNER JOIN em_tamanossubfam ts ON (dts.codsubfamilia = ts.codsubfamilia AND dts.codtamanoem = ts.codtamanoem)");

  var whereFijo = "dc.codalta = '" + codAlta + "' AND dts.codalta = '" + codAlta + "'";

  AQUtil.createProgressDialog(sys.translate("Calculando colores y tama�os..."), aDibujos.length);
  var p = 0;
  var dibujosSinColores = "";
  for(var i=0;i<aDibujos.length;i++) {
  	AQUtil.setProgress(p++);

	  q.setWhere(whereFijo + " and d.coddibujoem = '" + aDibujos[i] + "' ORDER BY dts.codsubfamilia, c.codcolorem, ts.orden");
	  
	  //debug("CONSULTA: " + q.sql());
	 
	  q.setForwardOnly(true);
	  if (!q.exec()) {
	    return false;
	  }
	  var codSubFamiliaPrev = false, codTamanoPrev = false;
		var codSubFamilia, codTamano, ref, codColor;
	  if (q.size() > 0) {
	    
	    while (q.next()) {
			codSubfamilia = q.value("dts.codsubfamilia");
			codTamano = q.value("dts.codtamanoem");
			codColor = q.value("c.codcolorem");

			codSubfamiliaPrev = codSubfamilia;
			codTamanoPrev = codTamano;
			
			ref = AQUtil.sqlSelect("articulos", "referencia", "codcolorem " + (codColor == "" ? " IS NULL" : ("= '" + codColor + "'")) + " AND codtamanoem = '" + codTamano + "' AND codsubfamilia = '" + codSubfamilia + "' AND coddibestamp = '" + aDibujos[i] + "'");
			//if (ref && soloNuevos) {
			//	continue;
			//}
	      
	        curLAM.setModeAccess(curLAM.Insert);
	        curLAM.refreshBuffer();
	        
	        curLAM.setValueBuffer("codalta", cursor.valueBuffer("codigo"));
			if (codColor != "") {
				curLAM.setValueBuffer("codcolorem", codColor);
			}

			if(q.value("d.coddiseno") && q.value("d.coddiseno") != 0) {
				curLAM.setValueBuffer("coddiseno", q.value("d.coddiseno"));
			}
			
			curLAM.setValueBuffer("coddibujoem", aDibujos[i]);
			curLAM.setValueBuffer("descdibujo", q.value("d.descripcion"));
	        curLAM.setValueBuffer("subfamiliaem", q.value("s.descripcion"));
	        curLAM.setValueBuffer("codtamanoem", codTamano);
	        curLAM.setValueBuffer("codsubfamilia", codSubfamilia);
	        if (ref) {
	          curLAM.setValueBuffer("referencia", ref);
	        }
	        
	        if (!curLAM.commitBuffer()) {
	          sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	          return false;
	        }
	    }
	    sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	    this.child("tdbLineasAltaMasivaCompleta").refresh();
	   // _i.habilitarBoton();
	  } else {
	  	if(dibujosSinColores && dibujosSinColores != "") {
	  		dibujosSinColores += ",";
	  	}
	  	dibujosSinColores += aDibujos[i];
	    	continue;
	  }
	}

	if(dibujosSinColores && dibujosSinColores != "") {
		MessageBox.information(sys.translate("No hay relaci�n de colores y tama�os para los dibujos:\n" + dibujosSinColores), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	}
}

function oficial_creaAltas()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(!cursor.valueBuffer("codcoleccionem") || cursor.valueBuffer("codcoleccionem") == "") {
		sys.warnMsgBox(sys.translate("Debe establecer antes la colecci�n"));
		return false;
	}
	_i.modificado_ = true;
	_i.preguntado_ = false;
	_i.saltarRepetidos_ = false;

	var progress = 0;
	var seleccionados = this.child("tdbLineasAltaMasivaCompleta").primarysKeysChecked();
	var lineas = seleccionados.toString();
	if(!lineas || lineas == "") {
		return false;

	}

	if(!_i.crearSubtablasDibujos(seleccionados)) {
		return false;
	}

	var qLD = new FLSqlQuery;
	qLD.setSelect("coddibujoem");
	qLD.setFrom("em_lineasaltamasivacompleta");
	qLD.setWhere("idlinea in (" + lineas + ") and codalta = '" + cursor.valueBuffer("codigo") + "' order by idlinea");

	if (!qLD.exec()) {
		return false;
	}
	
	AQUtil.createProgressDialog(AQUtil.translate("scripts", "Creando articulos nuevos..."), seleccionados.length);

	var tipoArticulo, combinacion;
	var creados = 0;
	var oParam = new Object;
	oParam.identificador = "codaltamasiva";
	oParam.clave = cursor.valueBuffer("codigo");
	oParam.coleccion = cursor.valueBuffer("codcoleccionem");
	var f = new Function("oParam", "return formRecordem_altamasiva.iface.creaArticulo(oParam)");
	var fT, codSubfamilia;

    var curTabla = new FLSqlCursor("em_lineasaltamasivacompleta");
	AQUtil.setProgress(0);

	var qLAMC = new FLSqlQuery;
	qLAMC.setSelect("l.idlinea");
	qLAMC.setFrom("em_lineasaltamasivacompleta l inner join em_tamanossubfam t on t.codtamanoem = l.codtamanoem and t.codsubfamilia = l.codSubfamilia");

	var dibujoAnt = "";
 	while(qLD.next()) {
 		

 		if(dibujoAnt != "" && dibujoAnt == qLD.value("coddibujoem")) {
 			continue;
 		}
 		dibujoAnt = qLD.value("coddibujoem");

		qLAMC.setWhere("l.idlinea in (" + lineas + ") and codalta = '" + cursor.valueBuffer("codigo") + "' and l.coddibujoem = " + qLD.value("coddibujoem") + " order by l.codsubfamilia,l.codcolorem,t.orden");


	    for (var p = 0; p < 2; p++) { /// 2 pasadas, la primera crea componentes, la segunda productos
	    	
	    	if (!qLAMC.exec()) {
				return false;
			}
	    	while(qLAMC.next()) {
	    
				curTabla.select("idLinea = '" + qLAMC.value("l.idlinea") + "'");
				curTabla.first();
				curTabla.setModeAccess(curTabla.Edit);
				curTabla.refreshBuffer();
				codSubfamilia = curTabla.valueBuffer("codsubfamilia");
				fT = AQUtil.sqlSelect("subfamilias sf INNER JOIN familias f ON sf.codfamilia = f.codfamilia", "f.fichatecnica", "sf.codsubfamilia = '" + codSubfamilia + "'", "familias");

				

				if ((fT && p == 0) || (!fT && p == 1)) {
					
					//debug("***** " + curTabla.valueBuffer("coddibujoem") + " - " + codSubfamilia + " - " + curTabla.valueBuffer("codcolorem") + " - " + curTabla.valueBuffer("codtamanoem"));
					continue;
				}

				

				combinacion = AQUtil.sqlSelect("subfamilias", "descripcion", "codsubfamilia = '" + codSubfamilia  + "'") + " - " + curTabla.valueBuffer("codtamanoem") + " - " + curTabla.valueBuffer("codcolorem");

				var refRepetida = AQUtil.sqlSelect("articulos", "referencia", "codsubfamilia = '" + codSubfamilia + "' AND codcolorem = '" + curTabla.valueBuffer("codcolorem") + "' AND codtamanoem = '" + curTabla.valueBuffer("codtamanoem") + "' AND coddibestamp = " + curTabla.valueBuffer("coddibujoem"));

	    		//debug("select referencia from articulos where codsubfamilia = '" + codSubfamilia + "' AND codcolorem = '" + curTabla.valueBuffer("codtamanoem") + "' AND codtamanoem = '" + curTabla.valueBuffer("codtamanoem") + "' AND coddibestamp = " + curTabla.valueBuffer("coddibujoem"));

				if(refRepetida) {
					if(!_i.preguntado_) {
						_i.preguntado_ = true;
			        	var res = MessageBox.warning(sys.translate("Ha seleccionado combinaciones con referencias existentes\n�desea generar duplicados de estos art�culos?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
						if (res != MessageBox.Yes) {
							_i.saltarRepetidos_ = true;
							continue;
						}
		    	    }

		    	    if(_i.saltarRepetidos_) {
						continue;
					}
		    	}

	        	AQUtil.setLabelText((p == 0) ? sys.translate("Creando componente %1").arg(combinacion) : sys.translate("Creando producto %1").arg(combinacion))
	            AQUtil.setProgress(progress++);
	        	oParam.errorMsg = sys.translate("Error al crear el art�culo para la combinaci�n %1").arg(combinacion);
	        	oParam.curTabla = curTabla;
	        	if (!sys.runTransaction(f, oParam)) {
	          		var res = MessageBox.warning(sys.translate("La creaci�n del art�culo %1 ha fallado.\n�Desea continuar?").arg(combinacion), MessageBox.Yes, MessageBox.No);
	          		if (res != MessageBox.Yes) {
	            		return false;
	          		}
	          		continue;
	        	}
				creados++;
				this.child("tdbLineasAltaMasivaCompleta").setPrimaryKeyChecked(qLAMC.value("l.idlinea"), false);
				this.child("tdbLineasAltaMasivaCompleta").refresh();
	      	}
	   	}
	}

    sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
    
    this.child("tdbLineasAltaMasivaCompleta").refresh();
    MessageBox.information(sys.translate("Han sido creados %1 art�culos satisfactoriamente.").arg(creados), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    //_i.deseleccionarTodo();
	/*} else {
		MessageBox.warning(sys.translate("Debe seleccionar alguna linea para crear el art�culo correspondiente."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	}*/
	_i.filtraArticulos();

	cursor.setValueBuffer("estado","ARTICULOS_GENERADOS");
	_i.habilitarPorEstado();
}

function oficial_seleccionarTodo()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  var curLAM = new FLSqlCursor("em_lineasaltamasivacompleta");
  curLAM.select("codalta = '" + cursor.valueBuffer("codigo") + "'");
  while (curLAM.next()) {
    this.child("tdbLineasAltaMasivaCompleta").setPrimaryKeyChecked(curLAM.valueBuffer("idlinea"), true);
  }
  this.child("tdbLineasAltaMasivaCompleta").refresh();
}

function oficial_seleccionarNuevos()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  var curLAM = new FLSqlCursor("em_lineasaltamasivacompleta");
  curLAM.select("codalta = '" + cursor.valueBuffer("codigo") + "' AND referencia is NULL");
  while (curLAM.next()) {
    this.child("tdbLineasAltaMasivaCompleta").setPrimaryKeyChecked(curLAM.valueBuffer("idlinea"), true);
  }
  this.child("tdbLineasAltaMasivaCompleta").refresh();
}

function oficial_deseleccionarTodo()
{
  this.child("tdbLineasAltaMasivaCompleta").clearChecked();
  this.child("tdbLineasAltaMasivaCompleta").refresh();
}

function oficial_filtraArticulos()
{
  this.child("tdbArticulos").refresh();
}

function oficial_ordenTablaArticulos()
{
	var c = ["referencia", "descripcion", "codtamanoem", "codcolorem", "fabricado", "em_situaciongenft","em_resultadogenft","em_motivogenft"];
	this.child("tdbArticulos").setOrderCols(c);
}

function oficial_habilitarPorEstado()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var estado = cursor.valueBuffer("estado");

	switch(estado) {
		case "CARGA_DIBUJOS": {
			this.child("pbnCrear").enabled = false;
			// seccion carga dibujos
			this.child("pbnAgregar").enabled = true;
			this.child("pbnBorrar").enabled = true;

			this.child("pbnGenerarDibujos").enabled = true;
			this.child("fdbDisenos").setDisabled(false);
			this.child("fdbDibujos").setDisabled(false);
			_i.tblDibujos_.checkColumnLocked(false);
			this.child("tbnSubir").setDisabled(false);
	        this.child("tbnBajar").setDisabled(false);
	        this.child("tbnReordenar").setDisabled(false);
			//this.child("tbnSelTodos").enabled = true;
			//this.child("tbnDeselTodos").enabled = true;
			//this.child("tblDisenosDibujos").enabled = true;

			//seccion stc
			this.child("tdbAltaMasivaSubfamilia").enabled = true;
			this.child("tdbTamanosSubfam").enabled = true;
			this.child("tdbAltaMasivaColor").enabled = false;
			this.child("pbnAgregarSCT").on = false;

			//Plantilla
			this.child("fdbIdPlantilla").setDisabled(false);
			this.child("fdbNombrePlantilla").setDisabled(false);
			
						
			if (_i.hayPlantillas()) {
				this.child("pbnAplicarPlantillas").setDisabled(false);	
				
				if (this.child("pbnAplicarPlantillas").on) {
					this.child("pbnAgregarSCT").enabled = true;
					this.child("pbnAgregarPlantilla").setDisabled(true);
					this.child("pbnBorrarPlantilla").setDisabled(true);
					this.child("toolButtonInsertFT").setDisabled(true);
					this.child("toolButtonDeleteFT").setDisabled(true);
					this.child("tdbPlantillas").setDisabled(true);

					this.child("pbnAgregar").enabled = false;
					this.child("pbnBorrar").enabled = false;
					this.child("pbnGenerarDibujos").enabled = false;
					this.child("fdbDisenos").setDisabled(true);
					this.child("fdbDibujos").setDisabled(true);
					_i.tblDibujos_.checkColumnLocked(true);
					this.child("tbnSubir").setDisabled(true);
					this.child("tbnBajar").setDisabled(true);
					this.child("tbnReordenar").setDisabled(true);

				} else {
					this.child("pbnAgregarSCT").enabled = false;
					this.child("pbnAgregarPlantilla").setDisabled(false);
					this.child("pbnBorrarPlantilla").setDisabled(false);
					this.child("toolButtonInsertFT").setDisabled(false);
					this.child("toolButtonDeleteFT").setDisabled(false);
					this.child("tdbPlantillas").setDisabled(false);

					this.child("pbnAgregar").enabled = true;
					this.child("pbnBorrar").enabled = true;
					this.child("pbnGenerarDibujos").enabled = true;
					this.child("fdbDisenos").setDisabled(false);
					this.child("fdbDibujos").setDisabled(false);
					_i.tblDibujos_.checkColumnLocked(false);
					this.child("tbnSubir").setDisabled(false);
					this.child("tbnBajar").setDisabled(false);
					this.child("tbnReordenar").setDisabled(false);
				}
			}
			else {
				this.child("pbnAgregarSCT").enabled = true;
				this.child("pbnAplicarPlantillas").setDisabled(true);
				this.child("pbnAgregarPlantilla").setDisabled(false);
				this.child("pbnBorrarPlantilla").setDisabled(false);
				this.child("toolButtonInsertFT").setDisabled(false);
				this.child("toolButtonDeleteFT").setDisabled(false);
				this.child("tdbPlantillas").setDisabled(false);
			}
			

			break;
		}
		case "STC_GENERADO": {
			// seccion carga dibujos
			this.child("pbnAgregar").enabled = false;
			this.child("pbnBorrar").enabled = false;
			this.child("pbnGenerarDibujos").enabled = false;
			this.child("fdbDisenos").setDisabled(true);
			this.child("fdbDibujos").setDisabled(true);
			_i.tblDibujos_.checkColumnLocked(true);
			this.child("tbnSubir").setDisabled(true);
			this.child("tbnBajar").setDisabled(true);
			this.child("tbnReordenar").setDisabled(true);
			//this.child("tbnSelTodos").enabled = false;
			//this.child("tbnDeselTodos").enabled = false;
			//this.child("tblDisenosDibujos").enabled = false;
			//

			//seccion stc
			this.child("tdbAltaMasivaSubfamilia").enabled = false;
			this.child("tdbTamanosSubfam").enabled = false;
			this.child("tdbAltaMasivaColor").enabled = false;
			this.child("pbnAgregarSCT").on = true;
			//

			this.child("pbnCrear").enabled = true;


			//Plantilla
			this.child("fdbIdPlantilla").setDisabled(true);
			this.child("fdbNombrePlantilla").setDisabled(true);
			this.child("pbnAgregarPlantilla").setDisabled(true);
			this.child("pbnBorrarPlantilla").setDisabled(true);
			this.child("toolButtonInsertFT").setDisabled(true);
			this.child("toolButtonDeleteFT").setDisabled(true);
			this.child("tdbPlantillas").setDisabled(true);
			this.child("pbnAplicarPlantillas").setDisabled(true);

			break;
		}
		case "ARTICULOS_GENERADOS": {
			this.child("pbnCrear").enabled = false;
			this.child("fdbFecha").enabled = false;
			this.child("fdbCodColeccion").enabled = false;
			this.child("fdbDesColeccion").enabled = false;

			// seccion carga dibujos
			this.child("pbnAgregar").enabled = false;
			this.child("pbnBorrar").enabled = false;
			this.child("pbnGenerarDibujos").enabled = false;
			_i.tblDibujos_.checkColumnLocked(true);
			this.child("tbnSubir").setDisabled(true);
			this.child("tbnBajar").setDisabled(true);
			this.child("tbnReordenar").setDisabled(true);
			this.child("fdbDisenos").setDisabled(true);
			this.child("fdbDibujos").setDisabled(true);
			//this.child("tbnSelTodos").enabled = false;
			//this.child("tbnDeselTodos").enabled = false;
			//this.child("tblDisenosDibujos").enabled = false;
			//

			this.child("gbxFamilias").enabled = false;

			//Plantilla
			this.child("fdbIdPlantilla").setDisabled(true);
			this.child("fdbNombrePlantilla").setDisabled(true);
			this.child("pbnAgregarPlantilla").setDisabled(true);
			this.child("pbnBorrarPlantilla").setDisabled(true);
			this.child("toolButtonInsertFT").setDisabled(true);
			this.child("toolButtonDeleteFT").setDisabled(true);
			this.child("tdbPlantillas").setDisabled(true);
			this.child("pbnAplicarPlantillas").setDisabled(true);

			break;
		}

	}
	return true;
}

function oficial_generarDibujos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	

	//var listaSel = "";
	var idDibujo;
	var codDiseno;

	var aSel = _i.tblDibujos_.primarysKeysChecked();
	AQUtil.createProgressDialog(sys.translate("Generando dibujos..."), aSel.length);

	for(var f = 0;f < aSel.length;f++) {
		AQUtil.setProgress(f);
			codDiseno = AQUtil.sqlSelect("em_disenosaltamasivacompleta","coddiseno","id = " + aSel[f])
			if(!codDiseno) {
				continue;
			}

			idDibujo =AQUtil.sqlSelect("em_disenosaltamasivacompleta","coddibujoem","id = " + aSel[f])
			if(!idDibujo || idDibujo == 0) {
				idDibujo = _i.crearDibujo(codDiseno);
				if(!idDibujo || idDibujo == 0) {
					sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
					return false;
				}
			}

			if(!AQUtil.sqlUpdate("em_disenosaltamasivacompleta","coddibujoem",idDibujo,"id = " + aSel[f]))
				return false;

			/*if(listaSel && listaSel != "") {
				listaSel += ",";
			}
			listaSel += idDibujo + "-" + codDiseno;*/
		
	}
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);

	//var listaSel = _i.guardarListaDibujosDisenos();
	//_i.informarTabla();
	_i.cargaDatosDibujos();
	_i.marcarSeleccionados();

	MessageBox.information(sys.translate("Dibujos generados correctamente"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	return true;
}

function oficial_crearDibujo(codDiseno)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var curDib = new FLSqlCursor("em_dibujos");
	curDib.setModeAccess(curDib.Insert);
	curDib.refreshBuffer();

	var codDibujo = formRecordem_dibujos.iface.calculateCounter();
	
	curDib.setValueBuffer("coddibujoem",codDibujo);

	if(!_i.datosDibujo(curDib,codDiseno)) {
		return false;
	}

	if(!curDib.commitBuffer()) {
		return false;
	}

	return codDibujo;
}

function oficial_datosDibujo(curDib,codDiseno)
{
	var _i = this.iface;
	var cursor = this.cursor();
   
	curDib.setValueBuffer("coddiseno",codDiseno);
	curDib.setValueBuffer("descripcion",AQUtil.sqlSelect("em_disenos","descripcion","coddiseno = " + codDiseno));

	var tipo = "Estampado";
	if(AQUtil.sqlSelect("em_disenos","codtipodibujo","coddiseno = " + codDiseno) == "JQ") {
		tipo = "Jaquard";
	}
	curDib.setValueBuffer("tipo",tipo);

	var procEstamp = AQUtil.sqlSelect("em_disenos","codprocesoestamp","coddiseno = " + codDiseno);
	var panotCont = "";
	switch(procEstamp) {
		case "rotativo": {
			panotCont = "Continuo";
			break;
		}
		case "plana": {
			panotCont = "Panot";
			break;
		}
	}
	curDib.setValueBuffer("panotcont",panotCont);

	curDib.setValueBuffer("em_margenest",5);
	curDib.setValueBuffer("liso",false);

	return true;
}

function oficial_inicializarValores()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var hoy = new Date();
	var ahora = hoy.toString().right(8);

	cursor.setValueBuffer("descripcion","-");
	cursor.setValueBuffer("usuarioalta", sys.nameUser());
	cursor.setValueBuffer("fechaalta", hoy);
	cursor.setValueBuffer("horaalta", ahora);

	if(!this.child("tdbAltaMasivaColor").cursor().commitBufferCursorRelation()) {
		return false;
	}

	var codAlta = cursor.valueBuffer("codigo");
	if(codAlta && codAlta != "") {
		if (!AQSql.insert("em_altamasivacolor", ["codalta", "codcolorem"], [codAlta, "UNICO"])) {
			return false;
		}
	}

	this.child("tdbAltaMasivaColor").refresh();
	return true;
}

function oficial_seleccionarTodoArt()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var curART = new FLSqlCursor("articulos");
	curART.select("codaltamasiva = '" + cursor.valueBuffer("codigo") + "' and em_tipoarticulo = 'Producto'");
	while (curART.next()) {
		this.child("tdbArticulos").setPrimaryKeyChecked(curART.valueBuffer("referencia"), true);
	}
	this.child("tdbArticulos").refresh();
}

function oficial_deseleccionarTodoArt()
{
  this.child("tdbArticulos").clearChecked();
  this.child("tdbArticulos").refresh();
}

function oficial_tbnGenerarFT_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var seleccionados = this.child("tdbArticulos").primarysKeysChecked();

	if(!seleccionados || seleccionados == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No ha seleccionado ning�n producto"),"warn",this);		
		return false;
	}

	var curArt = new FLSqlCursor("articulos");

	for (var i = 0; i < seleccionados.length; i++) {
		curArt.select("referencia = '" + seleccionados[i] + "'");
		curArt.first();
		curArt.setModeAccess(curArt.Edit);
		curArt.refreshBuffer();

		if(!formRecordarticulos.iface.generarFT(curArt)) {
			continue;
		}	 

		if(!curArt.commitBuffer()) {
			return false;
		}       

		this.child("tdbArticulos").refresh();
	}
	
	return true;
}

function oficial_pbnEnRevision_clicked()
{	
	var _i = this.iface;
	var cursor = this.cursor();

	var seleccionados = this.child("tdbArticulos").primarysKeysChecked();

	if(!seleccionados || seleccionados == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No ha seleccionado ning�n producto"),"warn",this);		
		return false;
	}

	var curArt = new FLSqlCursor("articulos");

	for (var i = 0; i < seleccionados.length; i++) {
		curArt.select("referencia = '" + seleccionados[i] + "'");
		curArt.first();
		curArt.setModeAccess(curArt.Edit);
		curArt.refreshBuffer();

		formRecordarticulos.iface.ponEnRevision(curArt);	
		curArt.setValueBuffer("tipostock",formRecordarticulos.iface.commonCalculateField("tipostock", curArt));	
		if(!curArt.commitBuffer()) {
			return false;
		}       

		this.child("tdbArticulos").refresh();
	}
	
	return true;
}

function oficial_pbnEnProduccion_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var seleccionados = this.child("tdbArticulos").primarysKeysChecked();

	if(!seleccionados || seleccionados == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No ha seleccionado ning�n producto"),"warn",this);		
		return false;
	}

	var curArt = new FLSqlCursor("articulos");

	for (var i = 0; i < seleccionados.length; i++) {
		curArt.select("referencia = '" + seleccionados[i] + "'");
		curArt.first();
		curArt.setModeAccess(curArt.Edit);
		curArt.refreshBuffer();

		formRecordarticulos.iface.ponEnProduccion(curArt);
		curArt.setValueBuffer("tipostock",formRecordarticulos.iface.commonCalculateField("tipostock", curArt));		
		if(!curArt.commitBuffer()) {
			return false;
		}       

		this.child("tdbArticulos").refresh();
	}
	
	return true;
}
function oficial_liberaUsuario()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var usuario = sys.nameUser();
	var codAlta = cursor.valueBuffer("codigo");
	var usuarioCon = AQUtil.sqlSelect("em_ctrlusualtamasivacom","idusuario","1=1", "em_ctrlusualtamasivacom", _i.cxTx_);
	if (usuarioCon && usuarioCon == usuario) { 
		//if (!AQUtil.sqlDelete("em_ctrlusualtamasivacom", "codaltamasiva = '" + codAlta + "'",_i.cxTx_)) {
		if (!AQUtil.sqlDelete("em_ctrlusualtamasivacom", "1=1",_i.cxTx_)) {
			return false;
		}		
	}
	return true;
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if(!_i.liberaUsuario()) {
		sys.errorMsgBox(sys.translate("Error al liberar usuario."));
	}
	_i.cierraMultiChecks();
	
	this.accept();
}

function oficial_pushButtonCancel_clicked()
{
	var _i = this.iface;

	var res = MessageBox.warning(sys.translate("Todos los cambios efectuados se cancelar�n. �Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		return;
	}

	if(!_i.liberaUsuario()) {
		sys.errorMsgBox(sys.translate("Error al liberar usuario."));
	}

	_i.cierraMultiChecks();
	sys.AQTimer.singleShot(0, formRecordem_altamasivacompleta.reject);
}

function oficial_abreCxTx()
{
	var _i = this.iface;
	
	if (!_i.cxTx_) {
		_i.cxTx_ = "CxTx";
	}
	var dbTx= AQSql.database(_i.cxTx_);
	
	if (_i.cxTx_ && dbTx.connectionName() == _i.cxTx_ ) {
		/// Porque aunque se deje abierta a los 15min de inactividad TCP muere y no se detecta que se haya roto la conexi�n
		if (!sys.removeDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error en la desconexi�n."), "info");
			return false;
		}
		dbTx = AQSql.database(_i.cxTx_);
	}
	if (dbTx.connectionName() != _i.cxTx_ || !dbTx.isOpen()) {
		if (!sys.addDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error al establecer la conexi�n de comprobaci�n de transacciones."), "warn");
			return false;
		}
	}
	return true;
}

function oficial_dameTablaDibujos()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblDibujos_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Dibujos");
	obj.gb = this.child("mte_gbExt_Dibujos");

	if (!obj.creado) {
		_i.tblDibujos_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblDibujos_.checkColumnEnabled(true);
		_i.tblDibujos_.setAliasCheckColumn("Sel.");
		_i.tblDibujos_.setSearchEnabled(false);

		_i.tblDibujos_.setDoubleClickedFunction("formRecordem_altamasivacompleta.iface.editarDibujo");
		_i.tblDibujos_.setSelectedFunction("formRecordem_altamasivacompleta.iface.selectedFunction");
		_i.tblDibujos_.setCurrentChangedFunction("formRecordem_altamasivacompleta.iface.tDisenos_clicked");
	}

	obj.miTabla = _i.tblDibujos_;

	return obj;
}

function oficial_selectedFunction(pk,sel)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codAlta = cursor.valueBuffer("codigo");

	if(!codAlta) {
		return;
	}

	if(sel) {
		var aDibujos = _i.tblDibujos_.primarysKeysChecked();

		var listaSel = aDibujos.toString();

		if(listaSel.endsWith(",")) {
			listaSel = listaSel.left(listaSel.length-1);
		}

	//	debug("select max(orden) from em_disenosaltamasivacompleta where id IN (" + listaSel + ") and id <> " + pk);

		var orden = 1;
		if(listaSel && listaSel != "" && aDibujos.length > 1) {
			orden = AQUtil.sqlSelect("em_disenosaltamasivacompleta","max(orden)","id IN (" + listaSel + ") and id <> " + pk);

			
			if(!orden) {
				orden = 1;
			}
			else {
				orden++;
			}
		}

		if(!AQUtil.sqlUpdate("em_disenosaltamasivacompleta","orden",orden,"id = " + pk))
			return false;


		/*var maxOrden = AQUtil.sqlSelect("em_disenosaltamasivacompleta","max(orden)","codalta = '" + codAlta + "'");
		
		var ordenWhere;

		while(orden < maxOrden) {
			ordenWhere = orden;
			orden++;

			if(!AQUtil.sqlUpdate("em_disenosaltamasivacompleta","orden",orden,"orden = " + ordenWhere)) {
				return false;
			}
		}*/

		_i.tblDibujos_.refresh();
	}
}

function oficial_cargaDatosDibujos()
{
	var _i = this.iface;

	var obj = _i.dameTablaDibujos();

	var cursor = this.cursor();
	var codAlta = cursor.valueBuffer("codigo");

	if(!codAlta) {
		return obj;
	}

	var miTabla = obj.miTabla;


	var q = new FLSqlQuery;
	q.setSelect("em_disenosaltamasivacompleta.id, em_disenosaltamasivacompleta.orden, em_disenosaltamasivacompleta.codalta, em_disenosaltamasivacompleta.coddiseno, em_dibujos.coddibujoem, em_disenosaltamasivacompleta.descripcion, em_dibujos.tipo, em_dibujos.codproveedor, em_dibujos.panotcont, em_dibujos.em_margenest, em_dibujos.liso");
	q.setFrom("em_disenosaltamasivacompleta LEFT OUTER JOIN em_disenos ON em_disenosaltamasivacompleta.coddiseno = em_disenos.coddiseno LEFT OUTER JOIN em_dibujos ON em_disenosaltamasivacompleta.coddibujoem = em_dibujos.coddibujoem");
	q.setWhere("em_disenosaltamasivacompleta.codalta = '" + codAlta + "'");
	q.setOrderBy("em_disenosaltamasivacompleta.orden");


	miTabla.setQuery(q);

	/*
	var tamanios = _i.dameTamaniosHistorico(tab);
	for(var i = 0; i < tamanios.length; i++) {
		miTabla.setColumnWidth(tamanios[i][0], tamanios[i][1]);
	}

	var hidden = _i.dameCamposOcultosHistorico(tab);
	for(var i = 0; i < hidden.length; i++) {
		miTabla.hideColumn(hidden[i]);
	}

	var showed = _i.dameCamposVisiblesHistorico(tab);
	for(var i = 0; i < showed.length; i++) {
		miTabla.showColumn(showed[i]);
	}

	var cabecera = _i.dameCabeceraHistorico(tab);
	miTabla.setColumnLabels("*", cabecera.join("*"));

	miTabla.setLimit(_i.dameLimit());
	*/


	miTabla.setReadOnly(true);
	miTabla.refresh();

	return true;	
}

function oficial_borrarTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();

	
	var codAlta = cursor.valueBuffer("codigo");
	if(!codAlta) {
		return false;
	}

	if(!AQUtil.sqlDelete("em_disenosaltamasivacompleta", "codalta = '" + codAlta + "'")) {
		return false;
	}

	this.child("fdbDisenos").setValue("");
	this.child("fdbDibujos").setValue("");
	this.child("fdbDisenosB").setValue("");
	this.child("fdbDibujosB").setValue("");

	_i.cargaDatosDibujos();
}

function oficial_creaSubtablaDibujos()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbLineasAltaMasivaCompleta").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}

	var codAlta = cursor.valueBuffer("codigo");
	if(!codAlta) {
		return false;
	}

	/*if(!AQUtil.sqlDelete("em_disenosaltamasivacompleta", "codalta = '" + codAlta + "'")) {
		return false;
	}*/

	var listaDibujos = _i.obtenerListaDibujos();
	var listaDisenos = _i.obtenerListaDisenos();

	var disenosActual = cursor.valueBuffer("disenos");
	if(!disenosActual || disenosActual == "unidefined")
		disenosActual = "";

	if(disenosActual.find(cursor.valueBuffer("listadisenos"),0) == -1) {
		if(disenosActual || disenosActual != "")
			disenosActual += ", ";

		disenosActual += cursor.valueBuffer("listadisenos");
	}
	cursor.setValueBuffer("disenos",disenosActual);

	var dibujosActual = cursor.valueBuffer("dibujos");
	if(!dibujosActual || dibujosActual == "unidefined")
		dibujosActual = "";
	
	if(dibujosActual.find(cursor.valueBuffer("listadibujos"),0) == -1) {
		if(dibujosActual || dibujosActual != "")
			dibujosActual += ", ";
		dibujosActual += cursor.valueBuffer("listadibujos");
	}

	cursor.setValueBuffer("dibujos",dibujosActual);

	var aDibujos = listaDibujos.split(",");
	var aDisenos = listaDisenos.split(",");

	var q = new FLSqlQuery;
	q.setSelect("coddiseno");
	q.setFrom("em_dibujos");

	var curDA = new FLSqlCursor("em_disenosaltamasivacompleta");

	var orden = parseInt(AQUtil.sqlSelect("em_disenosaltamasivacompleta","max(orden)","codalta = '" + codAlta + "'"));
	if(orden) {
		orden++;
	}
	else {
		orden = 1;
	}


	for(var i=0;i<aDisenos.length;i++) {

		if(aDisenos[i] && aDisenos[i] != "") {
			if(!AQUtil.sqlSelect("em_disenos","coddiseno","coddiseno = '" + aDisenos[i] + "'")) {
					continue;
			}

			//var codDibujo = AQUtil.sqlSelect("em_dibujos","coddibujoem","coddiseno = '" + aDisenos[i] + "'");
			var qD = new FLSqlQuery;
			qD.setSelect("coddibujoem");
			qD.setFrom("em_dibujos");
			qD.setWhere("coddiseno = '" + aDisenos[i] + "'");
			if(!qD.exec()) {
				continue;
			}
			
			if(qD.size() == 0) {
				if(AQUtil.sqlSelect("em_disenosaltamasivacompleta","id","codalta = '" + codAlta + "' and coddiseno = '" + aDisenos[i] + "'")) {
					continue;
				}
				
				while(parseInt(AQUtil.sqlSelect("em_disenosaltamasivacompleta","orden","codalta = '" + codAlta + "' and orden = " + orden)) && parseInt(AQUtil.sqlSelect("em_disenosaltamasivacompleta","orden","codalta = '" + codAlta + "'")) != 0) {
					orden++;
				}

				curDA.setModeAccess(curDA.Insert);
				curDA.refreshBuffer();
				curDA.setValueBuffer("codAlta",codAlta);
				curDA.setValueBuffer("orden",orden++);
				curDA.setValueBuffer("coddiseno",aDisenos[i]);
				curDA.setValueBuffer("descripcion",AQUtil.sqlSelect("em_disenos","descripcion","coddiseno = " + aDisenos[i]));

				if(!curDA.commitBuffer()) {
					return false;
				}
			}
			else{
				while(qD.next()) {
					var codDibujo = qD.value("coddibujoem");

					if(codDibujo && codDibujo != "") {
						if(AQUtil.sqlSelect("em_disenosaltamasivacompleta","id","codalta = '" + codAlta + "' and coddiseno = '" + aDisenos[i] + "' and coddibujoem = " + codDibujo)) {
							continue;
						}
					}
					else {
						if(AQUtil.sqlSelect("em_disenosaltamasivacompleta","id","codalta = '" + codAlta + "' and coddiseno = '" + aDisenos[i] + "'")) {
							continue;
						}
					}

					while(parseInt(AQUtil.sqlSelect("em_disenosaltamasivacompleta","orden","codalta = '" + codAlta + "' and orden = " + orden)) && parseInt(AQUtil.sqlSelect("em_disenosaltamasivacompleta","orden","codalta = '" + codAlta + "'")) != 0) {
						orden++;
					}

					curDA.setModeAccess(curDA.Insert);
					curDA.refreshBuffer();
					curDA.setValueBuffer("codAlta",codAlta);
					curDA.setValueBuffer("orden",orden++);
					curDA.setValueBuffer("coddiseno",aDisenos[i]);
					curDA.setValueBuffer("descripcion",AQUtil.sqlSelect("em_disenos","descripcion","coddiseno = " + aDisenos[i]));

					if(codDibujo && codDibujo != "") {
						curDA.setValueBuffer("coddibujoem",codDibujo);
						curDA.setValueBuffer("descripcion",AQUtil.sqlSelect("em_dibujos","descripcion","coddibujoem = " + codDibujo));
					}
					else {
						curDA.setValueBuffer("descripcion",AQUtil.sqlSelect("em_disenos","descripcion","coddiseno = " + aDisenos[i]));
					}

					if(!curDA.commitBuffer()) {
						return false;
					}
				}
			}
		}
	}

	var codDiseno = "";
	for(var i=0;i<aDibujos.length;i++) {
		if(aDibujos[i] && aDibujos[i] != "") {
			q.setWhere("coddibujoem = '" + aDibujos[i] + "'");
			if(!q.exec()) {
				continue;
			}
			
			while(q.next()) {
				codDiseno = q.value("coddiseno");
				if(codDiseno == 0) {
					codDiseno = "";

					if(AQUtil.sqlSelect("em_disenosaltamasivacompleta","id","codalta = '" + codAlta + "' and coddiseno is null and coddibujoem = " + aDibujos[i])) {
						continue;
					}
				}
				else {
					if(AQUtil.sqlSelect("em_disenosaltamasivacompleta","id","codalta = '" + codAlta + "' and coddiseno = '" + codDiseno + "' and coddibujoem = " + aDibujos[i])) {
						continue;
					}
				}

				curDA.setModeAccess(curDA.Insert);
				curDA.refreshBuffer();
				curDA.setValueBuffer("codalta",codAlta);
				curDA.setValueBuffer("orden",orden++);
				if(codDiseno != "") {
					curDA.setValueBuffer("coddiseno",codDiseno);
				}

				curDA.setValueBuffer("coddibujoem",aDibujos[i]);
				curDA.setValueBuffer("descripcion",AQUtil.sqlSelect("em_dibujos","descripcion","coddibujoem = " + aDibujos[i]));

				if(!curDA.commitBuffer()) {
					return false;
				}
			}
		}
	}
	
	return true;
}

function oficial_subirOrden()
{
	var _i = this.iface;

	var cursor = _i.tblDibujos_.dameCursor();
	
	var row = _i.tblDibujos_.fActual_;
	
	

	if (!_i.intercambiarOrden(cursor, row, -1)) {
		return false;
	}

	_i.tblDibujos_.refresh();
	_i.tblDibujos_.currentChanged(row-1,"em_disenosaltamasivacompleta.orden");

	return true;
}

function oficial_bajarOrden()
{
		var _i = this.iface;

	var cursor = _i.tblDibujos_.dameCursor();
	
	var row = _i.tblDibujos_.fActual_;
	
	

	if (!_i.intercambiarOrden(cursor, row, 1)) {
		return false;
	}

	_i.tblDibujos_.refresh();
	_i.tblDibujos_.currentChanged(row+1,"em_disenosaltamasivacompleta.orden");

	return true;
}

function oficial_intercambiarOrden(cursor, row1, direccion)
{
	var _i = this.iface;
	var tablaLineas = cursor.table();

	var row2 = row1+direccion;

	var id1 = _i.tblDibujos_.cellValue(row1, "em_disenosaltamasivacompleta.id");
	var id2 = _i.tblDibujos_.cellValue(row2, "em_disenosaltamasivacompleta.id");
	
	if(!id1 || !id2) {
		return;
	}

	var aDibujos = _i.tblDibujos_.primarysKeysChecked();
	var listaSel = aDibujos.toString();
	if(listaSel.find(id1,0) == -1) {
		sys.warnMsgBox(sys.translate("S�lo puede ordenar registros seleccionados"));
		return;
	}

	var orden1 = AQUtil.sqlSelect(tablaLineas, "orden","id = " + id1);
	var orden2 = AQUtil.sqlSelect(tablaLineas, "orden","id = " + id2);

	if (!orden1 || !orden2) {
		return false;
	}

	var cur1 = new FLSqlCursor(tablaLineas);
	cur1.select("id = " + id1);
	if (!cur1.first()) {
		return false;
	}
	cur1.setModeAccess(cur1.Edit);
	cur1.refreshBuffer();
	cur1.setValueBuffer("orden", orden2);
	if(!cur1.commitBuffer()) {
		return false;
	}

	var cur2 = new FLSqlCursor(tablaLineas);
	cur2.select("id = " + id2);
	if (!cur2.first()) {
		return false;
	}
	cur2.setModeAccess(cur2.Edit);
	cur2.refreshBuffer();
	cur2.setValueBuffer("orden", orden1);
	if(!cur2.commitBuffer()) {
		return false;
	}


	return true;
}

function oficial_reordenar()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codAlta = cursor.valueBuffer("codigo");
	if(!codAlta) {
		return;
	}

	var aDibujos = _i.tblDibujos_.primarysKeysChecked();

	var listaSel = aDibujos.toString();

	if(listaSel.endsWith(",")) {
		listaSel = listaSel.left(listaSel.length-1);
	}

	if(!listaSel || listaSel == "") {
		return;
	}

	var q = new FLSqlQuery();
	q.setSelect("id");
	q.setFrom("em_disenosaltamasivacompleta");  
	q.setWhere("codalta = '" + codAlta + "' and id not in (" + listaSel + ") order by orden");

	if (!q.exec()) {
    	return false;
    }

    var orden = AQUtil.sqlSelect("em_disenosaltamasivacompleta","max(orden)","id in (" + listaSel + ")");

    var cur = new FLSqlCursor("em_disenosaltamasivacompleta");

    while(q.next()) {
    	orden++;
    	cur.select("id = " + q.value("id"));
    	if(!cur.first()) {
    		return false;
    	}
    	cur.setModeAccess(cur.Edit);
    	cur.refreshBuffer();
    	cur.setValueBuffer("orden", orden);
    	if(!cur.commitBuffer()) {
    		return false;
    	}
    }


    _i.tblDibujos_.refresh();
	return true;
}

function oficial_pbnAgregarPlantilla_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var plantilla = cursor.valueBuffer("idplantilla");
	if(!plantilla) {
		return;
	}

	

	if(AQUtil.sqlSelect("em_plantillasaltamasivacompleta","idplantillaaltas","idplantilla = " + plantilla + " and codalta = '" + cursor.valueBuffer("codigo") + "'")) {
		sys.warnMsgBox(sys.translate("La plantilla ya est� asociada"));
		return false;
	}

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbAltaMasivaColor").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}

	var curPA = new FLSqlCursor("em_plantillasaltamasivacompleta");
	curPA.setModeAccess(curPA.Insert);
	curPA.refreshBuffer();

	curPA.setValueBuffer("idplantilla",plantilla);
	curPA.setValueBuffer("codalta",cursor.valueBuffer("codigo"));
	curPA.setValueBuffer("nombre",cursor.valueBuffer("nombreplantilla"));

	/*if(!_i.altaPlantillaAltaMasivaCompleta(curPA)) {
		return false;
	}*/

	if(!curPA.commitBuffer()) {
		sys.warnMsgBox(sys.translate("Hubo un error al agregar la plantilla"));
		return false;
	}

	

	this.child("tdbPlantillas").refresh();

	_i.habilitarPorEstado();

	return true;
}

function oficial_pbnBorrarPlantilla_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var plantilla = cursor.valueBuffer("idplantilla");
	if(!plantilla) {
		return;
	}

	var curPA = new FLSqlCursor("em_plantillasaltamasivacompleta");
	curPA.select("idplantilla = " + plantilla + " and codalta = '" + cursor.valueBuffer("codigo") + "'");
	if(!curPA.first()) {
		sys.warnMsgBox(sys.translate("La plantilla no est� asociada"));
		return false;
	}

	curPA.setModeAccess(curPA.Browse);
	curPA.refreshBuffer();



	curPA.setModeAccess(curPA.Del);
	curPA.refreshBuffer();

	if(!curPA.commitBuffer()) {
		sys.warnMsgBox(sys.translate("Hubo un error al borrar la plantilla"));
		return false;
	}

	

	this.child("tdbPlantillas").refresh();

	_i.habilitarPorEstado();

	return true;
}


function oficial_altaPlantillaAltaMasivaCompleta(curPA)
{
	var _i = this.iface;

	if(!_i.construirObjetoConfiguracion(curPA)) {
		sys.warnMsgBox(sys.translate("Hubo un error al agregar la plantilla"));
		return false;
	}
	
	if(!_i.altaDatosPlantilla(curPA)) {
		sys.warnMsgBox(sys.translate("Hubo un error al agregar la plantilla"));
		return false;
	}

	return true;
}

function oficial_altaDatosPlantilla(curPA)
{
	var _i = this.iface;

	var idPlantilla = curPA.valueBuffer("idplantilla");
	if(!idPlantilla) {
		return false;
	}

	var codAlta = curPA.valueBuffer("codalta");
	if(!codAlta || codAlta == "") {
		return false;
	}

	var configuracion = curPA.valueBuffer("configuracion");
	if(!configuracion || configuracion == "") {
		return false;
	}

	var objConfig = flfactppal.iface.stringToJson(configuracion);

	for(codColor in objConfig["colores"]) {
		if(!_i.crearAltaMasivaColor(codAlta, codColor)) {
			return false;
		}
	}

	var hayPanot = _i.hayDibujosPanotContSeleccionados("Panot", codAlta);
	var hayContinuo = _i.hayDibujosPanotContSeleccionados("Continuo", codAlta);

	for (subfam in objConfig["subfamilias"]) {
		if(!_i.crearAltaMasivaSubFam(codAlta, subfam)) {
			return false;
		}

		if(hayPanot) {
			for(tam in objConfig["subfamilias"][subfam]["panot"]) {
				if(!_i.crearAltaMasivaTamSub(codAlta, subfam, tam)) {
					return false;
				}
			}
		}
		if(hayContinuo) {
			for(tam in objConfig["subfamilias"][subfam]["continuo"]) {
				if(!_i.crearAltaMasivaTamSub(codAlta, subfam, tam)) {
					return false;
				}
			}
		}
	}
	
	this.child("tdbAltaMasivaColor").refresh();
	this.child("tdbAltaMasivaSubfamilia").refresh();

	return true;
}

function oficial_hayDibujosPanotContSeleccionados(tipo, codAlta)
{
	var _i = this.iface;

	
	var aSel = _i.tblDibujos_.primarysKeysChecked();
	var seleccionados = aSel.toString();
	if(seleccionados == "" || !seleccionados) {
		
		return false;
	}



	if(AQUtil.sqlSelect("em_disenosaltamasivacompleta a INNER JOIN em_dibujos d ON a.coddibujoem = d.coddibujoem","d.coddibujoem","d.panotcont = '" + tipo + "' and a.id in (" + seleccionados + ") AND a.codalta = '" + codAlta + "'","em_disenosaltamasivacompleta,em_dibujos")) {
		
		return true;
	}


	
	return false;
}

function oficial_construirObjetoConfiguracion(curPA)
{
	var _i = this.iface;

	var idPlantilla = curPA.valueBuffer("idplantilla");
	if(!idPlantilla) {
		
		return false;
	}

	var codAlta = curPA.valueBuffer("codalta");
	if(!codAlta || codAlta == "") {
		
		return false;
	}

	_i.objConfig_ = [];
	_i.objConfig_["subfamilias"] = [];
	_i.objConfig_["colores"] = [];


	//// Cabecera ////////////////
	var codSubfamilia = AQUtil.sqlSelect("em_plantillasprod","codsubfamilia","idplantilla = " + idPlantilla);
	var codTamanoem = AQUtil.sqlSelect("em_plantillasprod","codtamanoem","idplantilla = " + idPlantilla);
	var codColorem = AQUtil.sqlSelect("em_plantillasprod","codcolorem","idplantilla = " + idPlantilla);

	if(!_i.insertarEnObjetoSTC(codColorem,codSubfamilia,codTamanoem,codTamanoem)) {
		return false;
	}
	//////////////////////////////

	//// Componentes ////////////////
	var qLP = new FLSqlQuery();
	qLP.setSelect("codsubfamilia,codcolorem,codtamanocont,codtamanopanot");
	qLP.setFrom("em_lineasplantillaprod");
	qLP.setWhere("idplantilla = " + idPlantilla + " and tipo = 'Variable' and dibujo = 'Principal'");
	if (!qLP.exec()) {
    	return false;
    }

    while(qLP.next()) {
    	if(!_i.insertarEnObjetoSTC(qLP.value("codcolorem"),qLP.value("codsubfamilia"),qLP.value("codtamanocont"),qLP.value("codtamanopanot"))) {
			return false;
		}
    }
	//////////////////////////////	
    var jsonString = "{\"colores\": {";
    for(color in _i.objConfig_["colores"]) {
    	 jsonString += "\"" + color + "\":\"\",";
    }

    jsonString = jsonString.left(jsonString.length-1) + "},";

    jsonString += "\"subfamilias\": {";
    for (codSubfamilia in _i.objConfig_["subfamilias"]) {
    	jsonString += "\"" + codSubfamilia + "\": {";

    	jsonString += "\"continuo\": {";
    	for(tamano in _i.objConfig_["subfamilias"][codSubfamilia]["continuo"]) {
    		jsonString += "\"" + tamano + "\":\"\",";
    	}
    	jsonString = jsonString.left(jsonString.length-1) + "},";

    	jsonString += "\"panot\": {";
    	for(tamano in _i.objConfig_["subfamilias"][codSubfamilia]["panot"]) {
    		jsonString += "\"" + tamano + "\":\"\",";
    	}
    	jsonString = jsonString.left(jsonString.length-1) + "}},";
    }

    jsonString = jsonString.left(jsonString.length-1) + "}}";


    curPA.setValueBuffer("configuracion",jsonString);
	if(!curPA.commitBuffer())
		return false;

	curPA.select("idplantilla = " + idPlantilla + " and codalta = '" + codAlta + "'");
	if(!curPA.first()) {
		return false;
	}

	curPA.setModeAccess(curPA.Edit);
	curPA.refreshBuffer();


	return true;
}

function oficial_insertarEnObjetoSTC(codColorem,codSubfamilia,codTamanoC,codTamanoP)
{
	var _i = this.iface;	

	if(codSubfamilia) {
		if(!(codSubfamilia in _i.objConfig_["subfamilias"])) {
			_i.objConfig_["subfamilias"][codSubfamilia] = [];
			_i.objConfig_["subfamilias"][codSubfamilia]["continuo"] = [];
			_i.objConfig_["subfamilias"][codSubfamilia]["panot"] = [];
		}

		
		if(codTamanoC) {
			if(!(codTamanoC in _i.objConfig_["subfamilias"][codSubfamilia])) {
				_i.objConfig_["subfamilias"][codSubfamilia]["continuo"][codTamanoC] = "";		
			}
		}

		if(codTamanoP) {
			if(!(codTamanoP in _i.objConfig_["subfamilias"][codSubfamilia])) {
				_i.objConfig_["subfamilias"][codSubfamilia]["panot"][codTamanoP] = "";		
			}
		}
	}
	if(codColorem) {
		if(!(codColorem in _i.objConfig_["colores"])) {
			_i.objConfig_["colores"][codColorem] = "";		
		}		
	}

	return true;
}

function oficial_crearAltaMasivaSubFam(codAlta, codSubfamilia)
{
	var _i = this.iface;

	if(AQUtil.sqlSelect("em_altamasivasubfam","idaltasubfam","codalta = '" + codAlta + "' and codsubfamilia = '" + codSubfamilia + "'")) {
		return true;
	}

	var desalta = AQUtil.sqlSelect("em_altamasivacompleta","descripcion","codigo = '" + codAlta + "'");
	var descSubfamilia = AQUtil.sqlSelect("subfamilias","descripcion","codsubfamilia = '" + codSubfamilia + "'");

	var cur = new FLSqlCursor("em_altamasivasubfam");
	cur.setModeAccess(cur.Insert);
	cur.refreshBuffer();
	cur.setValueBuffer("codalta", codAlta);
	cur.setValueBuffer("desalta", desalta);
	cur.setValueBuffer("codsubfamilia", codSubfamilia);
	cur.setValueBuffer("dessubfamilia", descSubfamilia);
	if(!cur.commitBuffer()) {
		return false;
	}

	return true;	
}

function oficial_crearAltaMasivaTamSub(codAlta, codSubfamilia, codTam)
{
	var _i = this.iface;

	if(AQUtil.sqlSelect("em_altamasivatamsub","idaltatamsub","codalta = '" + codAlta + "' and codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTam + "'")) {
		return true;
	}

	var desalta = AQUtil.sqlSelect("em_altamasivacompleta","descripcion","codigo = '" + codAlta + "'");
	var idAltaSubFam = AQUtil.sqlSelect("em_altamasivasubfam","idaltasubfam","codalta = '" + codAlta + "' and codsubfamilia = '" + codSubfamilia + "'");
	if(!idAltaSubFam) {
		return false;
	}

	var cur = new FLSqlCursor("em_altamasivatamsub");
	cur.setModeAccess(cur.Insert);
	cur.refreshBuffer();
	cur.setValueBuffer("codalta", codAlta);
	cur.setValueBuffer("desalta", desalta);
	cur.setValueBuffer("idaltasubfam", idAltaSubFam);
	cur.setValueBuffer("codsubfamilia", codSubfamilia);
	cur.setValueBuffer("codtamanoem", codTam);
	if(!cur.commitBuffer()) {
		return false;
	}

	return true;
}

function oficial_crearAltaMasivaColor(codAlta, codColor)
{
	var _i = this.iface;

	if(AQUtil.sqlSelect("em_altamasivacolor","idaltacolor","codalta = '" + codAlta + "' and codcolorem = '" + codColor + "'")) {
		return true;
	}

	var desalta = AQUtil.sqlSelect("em_altamasivacompleta","descripcion","codigo = '" + codAlta + "'");
	
	var cur = new FLSqlCursor("em_altamasivacolor");
	cur.setModeAccess(cur.Insert);
	cur.refreshBuffer();
	cur.setValueBuffer("codalta", codAlta);
	cur.setValueBuffer("desalta", desalta);
	cur.setValueBuffer("codcolorem", codColor);
	if(!cur.commitBuffer()) {
		return false;
	}

	return true;	
}

function oficial_bajaPlantillaAltaMasivaCompleta(curPA)
{
	var _i = this.iface;

	if(!_i.bajaDatosPlantilla(curPA)) {
		sys.warnMsgBox(sys.translate("Hubo un error al borrar la plantilla"));
		return false;
	}

	/*var q = new FLSqlQuery();
	q.setSelect("idplantillaaltas");
	q.setFrom("em_plantillasaltamasivacompleta");  
	q.setWhere("codalta = '" + curPA.valueBuffer("codalta") + "' and idplantilla <> " + curPA.valueBuffer("idplantilla"));
	if (!q.exec()) {
    	return false;
    }

    var cur = new FLSqlCursor("em_plantillasaltamasivacompleta");
    while(q.next()) {
    	cur.select("idplantillaaltas = " + q.value("idplantillaaltas"));
		cur.first();
		cur.setModeAccess(cur.Edit);
		cur.refreshBuffer();

    	if(!_i.altaDatosPlantilla(cur)) {
			sys.warnMsgBox(sys.translate("Hubo un error al agregar la plantilla"));
			return false;
		}
    }*/

	return true;
}

function oficial_bajaDatosPlantilla(curPA)
{
	var _i = this.iface;

	var idPlantilla = curPA.valueBuffer("idplantilla");
	if(!idPlantilla) {
	
		return false;
	}

	var codAlta = curPA.valueBuffer("codalta");
	if(!codAlta || codAlta == "") {
		
		return false;
	}

	var configuracion = curPA.valueBuffer("configuracion");
	if(!configuracion || configuracion == "") {
	
		return false;
	}

	var objConfig = flfactppal.iface.stringToJson(configuracion);

	for(codColor in objConfig["colores"]) {
		//if(codColor == "UNICO") Esto no est� especificado pero es posible que lo pida
		//	continue;

		if(!AQUtil.sqlDelete("em_altamasivacolor","codalta = '" + codAlta + "' and codcolorem = '" + codColor + "'")) {debug("false 4");
			return false;
		}
	}

	var hayPanot = _i.hayDibujosPanotContSeleccionados("Panot", codAlta);
	var hayContinuo = _i.hayDibujosPanotContSeleccionados("Continuo", codAlta);

	for (subfam in objConfig["subfamilias"]) {
		if(hayPanot) {
			for(tam in objConfig["subfamilias"][subfam]["panot"]) {
				if(!AQUtil.sqlDelete("em_altamasivatamsub","codalta = '" + codAlta + "' and codsubfamilia = '" + subfam + "' AND codtamanoem = '" + tam + "'")) {
					
					return false;
				}
			}
		}

		if(hayContinuo) {
			for(tam in objConfig["subfamilias"][subfam]["continuo"]) {
				if(!AQUtil.sqlDelete("em_altamasivatamsub","codalta = '" + codAlta + "' and codsubfamilia = '" + subfam + "' AND codtamanoem = '" + tam + "'")) {
					
					return false;
				}
			}
		}

		if(!AQUtil.sqlSelect("em_altamasivatamsub","idaltatamsub","codalta = '" + codAlta + "' and codsubfamilia = '" + subfam + "'")) {
			if(!AQUtil.sqlDelete("em_altamasivasubfam","codalta = '" + codAlta + "' and codsubfamilia = '" + subfam + "'")) {
				
				return false;
			}		
		}
	}
	
	this.child("tdbAltaMasivaColor").refresh();
	this.child("tdbAltaMasivaSubfamilia").refresh();
	_i.filtraTamanos();
	
	return true;
}

function oficial_cierraMultiChecks()
{
	var _i = this.iface;	

	this.child("tdbLineasAltaMasivaCompleta").setCheckColumnEnabled(false);
	this.child("tdbArticulos").setCheckColumnEnabled(false);
	this.child("tdbTamanosSubfam").setCheckColumnEnabled(false);

	this.child("tdbLineasAltaMasivaCompleta").refresh(true, true);
	this.child("tdbArticulos").refresh(true, true);
	this.child("tdbTamanosSubfam").refresh(true, true);
}

function oficial_aplicarQuitarPlantillas()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAlta = cursor.valueBuffer("codigo");
	if(!codAlta || codAlta == "") {
		return false;
	}

	

	var q = new FLSqlQuery();
	q.setSelect("idplantillaaltas");
	q.setFrom("em_plantillasaltamasivacompleta");  
	q.setWhere("codalta = '" + codAlta + "'");
	if (!q.exec()) {
    	return false;
    }

    var curPA = new FLSqlCursor("em_plantillasaltamasivacompleta");

	if(this.child("pbnAplicarPlantillas").on) {
		var aSel = _i.tblDibujos_.primarysKeysChecked();
		if(!aSel || aSel.length == 0) {
			sys.warnMsgBox(sys.translate("Debe seleccionar dibujos previamente"));
			this.child("pbnAplicarPlantillas").on = false;
			return false;
		}
		
	    while(q.next()) {

	    	if(!AQUtil.sqlDelete("em_altamasivacolor","codalta = '" + codAlta + "' and codcolorem = 'UNICO'")) {debug("false 4");
				return false;
			}

	    	curPA.select("idplantillaaltas = " + q.value("idplantillaaltas"));
			curPA.first();
			curPA.setModeAccess(curPA.Edit);
			curPA.refreshBuffer();

	    	if(!_i.altaPlantillaAltaMasivaCompleta(curPA)) {
				sys.warnMsgBox(sys.translate("Hubo un error al agregar la plantilla"));
				return false;
			}
	    }
	}
	else {
		 while(q.next()) {
	    	curPA.select("idplantillaaltas = " + q.value("idplantillaaltas"));
			curPA.first();
			curPA.setModeAccess(curPA.Edit);
			curPA.refreshBuffer();

	    	if(!_i.bajaPlantillaAltaMasivaCompleta(curPA)) {
				//sys.warnMsgBox(sys.translate("Hubo un error al agregar la plantilla"));
				return false;
			}
	    }

	    if (!AQSql.insert("em_altamasivacolor", ["codalta", "codcolorem"], [codAlta, "UNICO"])) {
			return false;
		}
		this.child("tdbAltaMasivaColor").refresh();
	}

	_i.habilitarPorEstado();
}

function oficial_hayPlantillas()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAlta = cursor.valueBuffer("codigo");
	if(!codAlta || codAlta == "") {
		return false;
	}

	if(AQUtil.sqlSelect("em_plantillasaltamasivacompleta","idplantillaaltas","codalta = '" + codAlta + "'")) {
		return true;
	}

	return false;
}

function oficial_cargaDatosCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var obj = _i.dameTablaCostes();	
	var miTabla = obj.miTabla;
	
	var q = new FLSqlQuery;
	q.setSelect("v_articuloslog.referencia, v_articuloslog.descripcion, v_articuloslog.codtamanoem, v_articuloslog.codcolorem, v_articuloslog.codfamilia, v_articuloslog.codsubfamilia, v_articuloslog.em_costeprod, v_articuloslog.em_margenprod, v_articuloslog.em_origencoste, v_articuloslog.em_origenmargen");		
	q.setFrom("v_articuloslog");
	q.setWhere("v_articuloslog.codaltamasiva = '" + cursor.valueBuffer("codigo") + "'");
	q.setOrderBy("v_articuloslog.referencia");		
	miTabla.setQuery(q);	
	
	miTabla.setColumnWidth("v_articuloslog.referencia", 80);
	miTabla.setColumnWidth("v_articuloslog.descripcion", 450);
	miTabla.setColumnWidth("v_articuloslog.codtamanoem", 120);
	miTabla.setColumnWidth("v_articuloslog.codcolorem", 120);
	miTabla.setColumnWidth("v_articuloslog.codfamilia", 80);
	miTabla.setColumnWidth("v_articuloslog.codsubfamilia", 80);
	miTabla.setColumnWidth("v_articuloslog.em_costeprod", 120);
	miTabla.setColumnWidth("v_articuloslog.em_margenprod", 120);
	miTabla.setColumnWidth("v_articuloslog.em_origencoste", 140);
	miTabla.setColumnWidth("v_articuloslog.em_origenmargen", 140);
	

	miTabla.setReadOnly(true);	
	miTabla.refresh();

	return true;	
}

function oficial_dameTablaCostes()
{
	var _i = this.iface;
	
	var obj = {};
	obj.creado = _i.tblCostes_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Costes");
	obj.gb = this.child("mte_gbExt_Costes");
	
	if (!obj.creado) {		
		_i.tblCostes_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);		
		_i.tblCostes_.checkColumnEnabled(true);		
		_i.tblCostes_.setAliasCheckColumn("Seleccionar");	
		_i.tblCostes_.setSearchEnabled(true);	
		_i.tblCostes_.tbnSelAll_.close();
      	_i.tblCostes_.tbnSelNot_.close();	
		_i.tblCostes_.setDoubleClickedFunction("formRecordem_altamasivacompleta.iface.editarArticulo");
	}
	
	obj.miTabla = _i.tblCostes_;

	return obj;
}

function oficial_pbnTodosCostes_clicked() 
{
	var _i = this.iface;
	_i.tblCostes_.checkAll();
  		
}

function oficial_pbnNingunoCostes_clicked() 
{
	var _i = this.iface;
  	_i.tblCostes_.clearChecked(false);
}
	
function oficial_tbnEmRegenerarCostes_clicked() 
{
	var _i = this.iface;
	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length == 0) {
		formUI.ponMsgBox("Primero marque 1 o varios art�culos a recargar los costes/m�rgenes","warn");
		return false;
	} 
	var cursorArticulos = new FLSqlCursor("articulos");
	for(var i=0; i<aSel.length;i++) {		
		cursorArticulos.select("referencia = '" + aSel[i] + "'");
		if (!cursorArticulos.first()) {
			return false;
		}
		cursorArticulos.setModeAccess(cursorArticulos.Edit);
		cursorArticulos.refreshBuffer();
		/*if(!formRecordarticulos.iface.heredarCosteProd(cursorArticulos, true, false)) {
			return false;
		}
		if(!formRecordarticulos.iface.heredarMargenProd(cursorArticulos, true,true)) {
			return false;
		}*/
		if(!formRecordarticulos.iface.heredarCosteMargenProd(cursorArticulos, true)) {
			return false;
		}	
		if (!cursorArticulos.commitBuffer()) {		
			return false;
		}
	}
	_i.tblCostes_.refresh();
	return true;
}
	
function oficial_tbnEmCargarCostes_clicked() 
{
  	var _i = this.iface;
	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length == 0) {
		formUI.ponMsgBox("Primero marque 1 o varios art�culos a recargar los costes/m�rgenes","warn");
		return false;
	} 
	var cursorArticulos = new FLSqlCursor("articulos");
	var heredarCoste;
	var heredarMargen;
	for(var i=0; i<aSel.length;i++) {		
		cursorArticulos.select("referencia = '" + aSel[i] + "'");
		if (!cursorArticulos.first()) {
			return false;
		}
		cursorArticulos.setModeAccess(cursorArticulos.Edit);
		cursorArticulos.refreshBuffer();
		heredarCoste = false;
		heredarCoste = false;

		/*if(!cursorArticulos.valueBuffer("em_costeprod") || cursorArticulos.isNull("em_costeprod")) {
			if(!formRecordarticulos.iface.heredarCosteProd(cursorArticulos, true, true)) {
				return false;
			}			
		}
		if(!cursorArticulos.valueBuffer("em_margenprod") || cursorArticulos.isNull("em_margenprod")) {
			if(!formRecordarticulos.iface.heredarMargenProd(cursorArticulos, true, true)) {
				return false;
			}
		}*/
		if(!cursorArticulos.valueBuffer("em_costeprod") || cursorArticulos.isNull("em_costeprod")) {
			heredarCoste = true;
		}
		if(!cursorArticulos.valueBuffer("em_margenprod") || cursorArticulos.isNull("em_margenprod")) {
			heredarMargen = true;
		}
		

		if(heredarCoste && heredarMargen) {
			if(!formRecordarticulos.iface.heredarCosteMargenProd(cursorArticulos, true)) {
				return false;
			}	
		} else if(heredarCoste) {
			if(!formRecordarticulos.iface.heredarCosteProd(cursorArticulos, true, true)) {
				return false;
			}

		} else if(heredarMargen) {
			if(!formRecordarticulos.iface.heredarMargenProd(cursorArticulos, true, true)) {
				return false;
			}
		}
		
		if (!cursorArticulos.commitBuffer()) {		
			return false;
		}
	}
	_i.tblCostes_.refresh();
	return true;
}
	
function oficial_pbnEditarTama_clicked() 
{
	var _i = this.iface;
	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length != 1) {
		formUI.ponMsgBox("Primero marque un solo art�culo y luego use este bot�n","warn");
		return false;
	} 
	var referencia = aSel[0];

	var q = new AQSqlQuery;	
	q.setSelect("codtamanoem,codsubfamilia");
	q.setFrom("articulos");
	q.setWhere("referencia = '" + referencia + "'");	
	if (!q.exec()){
		return;
	}  
	if(!q.first())
	{
		return false;			
	}	

	var codTamano = q.value("codtamanoem");
	var codSubfamilia = q.value("codsubfamilia");

	var curTama = new FLSqlCursor("em_tamanossubfam");
	curTama.select("codtamanoem = '" + codTamano + "' and codsubfamilia = '" + codSubfamilia + "'");
	curTama.first();
	curTama.editRecord();

  	return true;
}
	
/*function oficial_pbnEditarPlantilla_clicked() 
{
	var _i = this.iface;

	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length != 1) {
		formUI.ponMsgBox("Primero marque un solo art�culo y luego use este bot�n","warn");
		return false;
	} 
	var cursor = this.cursor();
	var codAlta = cursor.valueBuffer("codigo");
	if(!codAlta || codAlta == "") {
		return false;
	}	
	var idPlantilla = AQUtil.sqlSelect("em_plantillasaltamasivacompleta","idplantilla","codalta = '" + codAlta + "'");
	if(!idPlantilla) {
		formUI.ponMsgBox("No hay plantilla asociada","warn");
		return true;
	}
	

	var curPlantilla = new FLSqlCursor("em_plantillasprod"); 
	curPlantilla.select("idplantilla = " + idPlantilla);
	curPlantilla.first();
	curPlantilla.editRecord();
  	return true;
}*/

function oficial_pbnEditarPlantilla_clicked() 
{
	var _i = this.iface;

	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length != 1) {
		formUI.ponMsgBox("Primero marque un solo art�culo y luego use este bot�n","warn");
		return false;
	} 
	var referencia = aSel[0];
				
	var q = new AQSqlQuery;	
	q.setSelect("codtamanoem,codsubfamilia,codcoleccionem,codcolorem");
	q.setFrom("articulos");
	q.setWhere("referencia = '" + referencia + "'");	
	if (!q.exec()){
		return;
	}  
	if(!q.first())
	{
		return false;			
	}	

	var codTamano = q.value("codtamanoem");
	var codSubfamilia = q.value("codsubfamilia");
	var codColeccion = q.value("codcoleccionem"); 
	var codColor = q.value("codcolorem");

	var curPlantilla = new FLSqlCursor("em_plantillasprod");
	curPlantilla.select("codtamanoem = '" + codTamano + "' and codsubfamilia = '" + codSubfamilia + "' and codcoleccionem = '" + codColeccion + "' and codcolorem = '" + codColor + "'");
	if(!curPlantilla.first()) {
		formUI.ponMsgBox("No hay plantilla asociada.","warn");
		return true;
	}
	curPlantilla.editRecord();
  	return true;
}

function oficial_editarArticulo()
{
	var _i = this.iface;
	var row = _i.tblCostes_.fActual_;
	var referencia = _i.tblCostes_.cellValue(row, "v_articuloslog.referencia");

	_i.curArticulo_.select("referencia = '" + referencia + "'");
	_i.curArticulo_.first();
	_i.curArticulo_.editRecord();

	
  	return true;
}	

function oficial_refrescaTabla()
{	
	var _i = this.iface;
	_i.tblCostes_.refresh();
}

function oficial_tbwArticulo_currentChanged(nombreTab)
{
	var _i = this.iface;
	if(nombreTab == "em_costes") {
		_i.cargaDatosCostes();
	}

}

function oficial_toolButtonInsertSF_clicked()
{
    var cursor = this.cursor();
    var f = new FLFormSearchDB("em_altamasivasubfam2");  
    var curA = f.cursor();
    curA.setModeAccess(curA.Insert);
    curA.refreshBuffer();
    curA.setValueBuffer("codalta",cursor.valueBuffer("codigo")); 
    curA.setValueBuffer("desalta",cursor.valueBuffer("descripcion"));        
    f.setMainWidget();
    f.exec();  
    if(f.accepted()) {  
        if(!curA.commitBuffer()) {
            return false;
        }
        this.child("tdbAltaMasivaSubfamilia").refresh();
    }
}

function oficial_toolButtonEditSF_clicked()
{
    var cursor = this.cursor();
    var f = new FLFormSearchDB("em_altamasivasubfam2");  
    var curA = f.cursor();
    curA.select("codalta = '" + cursor.valueBuffer("codigo") + "' ");
    if (!curA.first()) {
        return false;
    }
    curA.setModeAccess(curA.Edit);
    curA.refreshBuffer();       
    f.setMainWidget();
    f.exec();  
    if(f.accepted()) {  
        if(!curA.commitBuffer()) {
            return false;
        }
        this.child("tdbAltaMasivaSubfamilia").refresh();
    }

}

function oficial_toolButtonZoomSF_clicked()
{
    var cursor = this.cursor();
    var f = new FLFormSearchDB("em_altamasivasubfam2");  
    var curA = f.cursor();
    curA.select("codalta = '" + cursor.valueBuffer("codigo") + "' ");
    if (!curA.first()) {
        return false;
    }
    curA.setModeAccess(curA.Browse);
    curA.refreshBuffer();       
    f.setMainWidget();
    f.exec();  
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////