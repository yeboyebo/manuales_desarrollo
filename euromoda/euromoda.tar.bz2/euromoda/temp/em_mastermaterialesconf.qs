/***************************************************************************
                 em_mastermaterialesconf.qs  -  description
                             -------------------
    begin                : lubjul 18 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  var tdbRecords_, listaPedidos_;
  var codOrdenDesde_, codOrdenHasta_;
  function oficial(context)
  {
    interna(context);
  }
  function ordenarCols()
  {
    return this.ctx.oficial_ordenarCols();
  }
  function tbnTransferir_clicked()
  {
    return this.ctx.oficial_tbnTransferir_clicked();
  }
  function filtra()
  {
    return this.ctx.oficial_filtra();
  }
  function ordenActual()
  {
    return this.ctx.oficial_ordenActual();
  }
  function tbnOK_clicked()
  {
    return this.ctx.oficial_tbnOK_clicked();
  }
  function terminaTareaPM(oParam)
  {
    return this.ctx.oficial_terminaTareaPM(oParam);
  }
  function tbnInventario_clicked()
  {
    return this.ctx.oficial_tbnInventario_clicked();
  }
  function chkSoloCortadas_clicked()
  {
    return this.ctx.oficial_chkSoloCortadas_clicked();
  }
	function tbnInforme_clicked() {
		return this.ctx.oficial_tbnInforme_clicked();
	}
	function dameParamInforme() {
		return this.ctx.oficial_dameParamInforme();
	}
	function tbnEtiquetas_clicked() {
		return this.ctx.oficial_tbnEtiquetas_clicked();
	}
	function tbnInformeMat_clicked() {
		return this.ctx.oficial_tbnInformeMat_clicked();
	}
	function dameOrdenDH(tipoImpreso) {
		return this.ctx.oficial_dameOrdenDH(tipoImpreso);
	}
	function tbnEtiquetasCaja_clicked() {
		return this.ctx.oficial_tbnEtiquetasCaja_clicked();
	}
	function imprimeEtiquetasCaja(w) {
		return this.ctx.oficial_imprimeEtiquetasCaja(w);
	}
	function dameArrayEtiquetas(w) {
		return this.ctx.oficial_dameArrayEtiquetas(w);
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
  function pub_ordenActual() {
    return this.ordenActual();
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.codOrdenDesde_ = "";
	_i.codOrdenHasta_ = "";
	_i.tdbRecords_ = this.child("tableDBRecords");

	_i.ordenarCols();

	connect(this.child("tbnTransferir"), "clicked()", _i, "tbnTransferir_clicked");
	connect(this.child("tbnOK"), "clicked()", _i, "tbnOK_clicked");
	connect(this.child("tbnInventario"), "clicked()", _i, "tbnInventario_clicked");
	connect(this.child("chkSoloCortadas"), "clicked()", _i, "chkSoloCortadas_clicked");
	connect(this.child("tbnInforme"), "clicked()", _i, "tbnInforme_clicked");
	connect(this.child("tbnEtiquetas"), "clicked()", _i, "tbnEtiquetas_clicked");
	connect(this.child("tbnInformeMat"), "clicked()", _i, "tbnInformeMat_clicked");
	connect(this.child("tbnEtiquetasCaja"), "clicked()", _i, "tbnEtiquetasCaja_clicked");

	_i.filtra();
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnOK_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var codOrden = cursor.valueBuffer("codorden");
  if (!codOrden) {
    return;
  }
  var codAsigConf = cursor.valueBuffer("codasigconf");
  if (codAsigConf) {
    sys.warnMsgBox(sys.translate("La orden %1 est� asociada a una asignaci�n.\nSi quiere enviarla por separado debe sacarla antes del registro de asignaci�n.").arg(codOrden));
    return;
  }
  var codConfec = cursor.valueBuffer("codconfeccionista");
  if (!codConfec) {
    MessageBox.warning(sys.translate("Debe indicar antes el confeccionista de la orden %1.").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return;
  }
  /** Eliminado al no usarse la tarea de preparaci�n de materiales. Lo �nico que hacemos es no dejar distibuir si no est� activado pr_ordenesproduccion.materialconfok
  var idTareaPM = AQUtil.sqlSelect("pr_tareas", "idtarea", "idobjeto = '" + codOrden + "' AND tipoobjeto = 'pr_ordenesproduccion' AND estado = 'PTE' AND idtipotarea = 'PM'");
  if (!idTareaPM) {
    MessageBox.warning(sys.translate("No hay una tarea de preparaci�n de material pendiente para la orden %1").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return;
  }*/
  var res = MessageBox.warning(sys.translate("Va a dar por concluida la preparaci�n de materiales para la orden %1.\n�Est� seguro?").arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
  if (res != MessageBox.Yes) {
    return;
  }
  res = MessageBox.warning(sys.translate("Desea aprobar el resto de �rdenes asignadas al confeccionista %1 - %2?").arg(codConfec).arg(cursor.valueBuffer("nombreconfeccionista")), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	var todoConfec = (res == MessageBox.Yes);
  
	_i.listaPedidos_ = [];
	var oParam = new Object;
  oParam.errorMsg = sys.translate("Error al marcar la orden de producci�n como Material OK");
  var f = new Function("oParam", "return formem_materialesconf.iface.terminaTareaPM(oParam)");
  if (todoConfec) {
		flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Generando pedidos"), 2);
		var q = new AQSqlQuery;
		q.setSelect("codorden");
		q.setFrom("pr_ordenesproduccion");
		q.setWhere("codconfeccionista = '" + codConfec + "' AND NOT materialconfok AND codasigconf IS NULL");
		if (!q.exec()) {
			return false;
		}
		AQUtil.setTotalSteps(q.size());
		var p = 0;
		while (q.next()) {
			oParam.codOrden = q.value("codorden");
			AQUtil.setLabelText(sys.translate("Procesando orden %1").arg(oParam.codOrden));
			AQUtil.setProgress(p++)
			if (!sys.runTransaction(f, oParam)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
		AQUtil.destroyProgressDialog();
	} else {
		flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Generando pedido"), 2);
		oParam.codOrden = codOrden;
		AQUtil.setLabelText(sys.translate("Procesando orden %1").arg(oParam.codOrden));
		AQUtil.setProgress(0)
		if (!sys.runTransaction(f, oParam)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		AQUtil.destroyProgressDialog();
	}

  this.child("tableDBRecords").refresh();
	if (_i.listaPedidos_.length > 0) {
		var t = _i.listaPedidos_.length;
// 		var lP = _i.listaPedidos_.join(", ");
		sys.infoMsgBox(sys.translate("Se han generado %1 pedidos a confeccionistas").arg(t));
	}
}

function oficial_terminaTareaPM(oParam)
{
	var _i = this.iface;
	var codOrden = oParam.codOrden;
  
	var oParamPC = new Object;
  oParamPC.codPedido = false;
	oParamPC.codOrden = codOrden;
	if (!formem_districonf.iface.pub_creaPedidoConf(oParamPC)) {
		return false;
	}
  _i.listaPedidos_.push(oParamPC.codPedido);
  
  if (!AQSql.update("pr_ordenesproduccion", ["materialconfok"], [true], "codorden = '" + codOrden + "'")) {
    return false;
  }

  return true;
}

function oficial_filtra()
{
  var filtro = "NOT materialconfok AND estado <> 'TERMINADA'";
	if (this.child("chkSoloCortadas").checked) {
		filtro += " AND estado = 'PTE CONFECCION'";
	}
debug("filtro = " + filtro);
  this.child("tableDBRecords").cursor().setMainFilter(filtro);
	this.child("tableDBRecords").refresh();
}

function oficial_ordenarCols()
{
	var _i = this.iface;
  var cols = ["codorden", "emobservaciones", "fecha", "codpreparamat", "codasigconf", "codconfeccionista", "nombreconfeccionista", "materialconfok", "subfamilia", "dibujo", "fechaentrega", "estado", "totaluds", "totallotes", "codpedidocli", "codpedidocli", "fechadesde", "fechahasta", "atiempo", "impresoorden", "impresomaterial", "codpedidoconf", "codpedidofaltas", "codalbaranconf", "codalbaranfaltas", "codcliente", "nombrecliente"];
	
	var oCAncho = [["codorden", 90], ["fecha", 80], ["codpreparamat", 80], ["codasigconf", 70], ["codconfeccionista", 60], ["materialconfok", 50], ["fechaentrega", 80], ["totaluds", 60], ["totallotes", 60], ["codpedidocli", 90], ["fechadesde", 80], ["fechahasta", 80], ["atiempo", 30], ["impresoorden", 40], ["impresomaterial", 40], ["codpedidoconf", 90], ["codpedidofaltas", 90], ["codalbaranconf", 90], ["codalbaranfaltas", 90], ["codcliente", 60]];
	for (var c = 0; c < oCAncho.length; c++) {
		_i.tdbRecords_.setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
	
  _i.tdbRecords_.setOrderCols(cols);
  _i.tdbRecords_.refresh();
}

function oficial_tbnTransferir_clicked()
{
  var cursor = this.cursor();
  var f = new FLFormSearchDB("em_transstock");
  var curTS = f.cursor();

  var codOrden = cursor.valueBuffer("codorden");
  if (!codOrden) {
    return;
  }

  var filtro = "codordenprod = '" + codOrden + "'";
  curTS.setMainFilter(filtro);

  f.setMainWidget();
  f.exec();
}

function oficial_ordenActual()
{
  var cursor = this.cursor();
  var codOrden = cursor.valueBuffer("codorden");
  return codOrden;
}

function oficial_tbnInventario_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codOrden = cursor.valueBuffer("codorden");
	var codConfec = cursor.valueBuffer("codconfeccionista");
	if (!codConfec) {
		MessageBox.warning(sys.translate("No ha establecido el confeccionista asociado a la orden"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	flprodppal.iface.pub_lanzaInventarioConf(codConfec);
}

function oficial_chkSoloCortadas_clicked()
{
	var _i = this.iface;
	_i.filtra();
}

function oficial_tbnInforme_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var oParam = _i.dameParamInforme();
	if (!oParam) {
		return;
	}
	
	if(!flfactinfo.iface.pub_lanzaInforme(cursor, oParam)) {
		return false;
	}
	var idUsuarioMod = sys.nameUser();
	var fechaMod = flfactppal.iface.dameFechaActual();
	var horaMod = flfactppal.iface.dameHoraActual();
	var where = "NOT materialconfok AND estado <> 'TERMINADA'";
	var codOrdenDesde = _i.codOrdenDesde_;
	var codOrdenHasta = _i.codOrdenHasta_;
	if(codOrdenDesde && codOrdenDesde != "" && codOrdenDesde != "VACIO") {
		if(where!= "") {
			where += " AND ";
		}
		where += "codorden >= '" + codOrdenDesde + "'";
	}
	if(codOrdenHasta && codOrdenHasta != "" && codOrdenHasta != "VACIO") {
		if(where!= "") {
			where += " AND ";
		}
		where += "codorden <= '" + codOrdenHasta + "'";
	}
	debug("where para update: "+where);
	AQUtil.execSql("UPDATE pr_ordenesproduccion SET idusuariomodiagmat = '" + idUsuarioMod + "', fechamodiagmat = '" + fechaMod + "', horamodiagmat = '" + horaMod + "'   WHERE " + where);

	formem_preparacionmat.iface.codOrdenDesde_ = "";	
	formem_preparacionmat.iface.codOrdenHasta_ = "";
		
	this.child("tableDBRecords").refresh();
	
}

function oficial_dameParamInforme()
{
	var _i = this.iface;
	var oParam = flfactinfo.iface.pub_dameParamInforme();

	var oDH = _i.dameOrdenDH("informeprepmat");
	if (!oDH) {
		return false;
	}
	if(!oDH.codOrdenDesde || oDH.codOrdenDesde == "") {
		formem_preparacionmat.iface.codOrdenDesde_ = "VACIO";		
	}
	if(!oDH.codOrdenHasta || oDH.codOrdenHasta == "") {
		formem_preparacionmat.iface.codOrdenHasta_ = "VACIO";		
	}

	formem_preparacionmat.iface.codOrdenDesde_ = oDH.codOrdenDesde;
	formem_preparacionmat.iface.codOrdenHasta_ = oDH.codOrdenHasta;
	_i.codOrdenDesde_ = oDH.codOrdenDesde;
	_i.codOrdenHasta_ = oDH.codOrdenHasta;

	oParam.whereFijo = "NOT pr_ordenesproduccion.materialconfok AND pr_ordenesproduccion.estado <> 'TERMINADA' AND pr_ordenesproduccion.codorden >= '" + oDH.codOrdenDesde + "' AND pr_ordenesproduccion.codorden <= '" + oDH.codOrdenHasta + "'";
	if (this.child("chkInfoResumido").checked) {
		oParam.nombreInforme = "pr_i_preparamatop_res";
		oParam.groupBy = "movistock.referencia, articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion, articulos.codtamanoem, articulos.codcolorem, empresa.nombre, articuloscomp.componormal, articuloscomp.ancho";
		oParam.orderBy = "articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion";
	} else {
		oParam.nombreInforme = "pr_i_preparamatf";
		oParam.groupBy = "pr_ordenesproduccion.codorden, pr_ordenesproduccion.ordenpremat, movistock.referencia, articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion, articulos.codtamanoem, articulos.codcolorem, empresa.nombre, lotesstock.canlote, articuloscomp.componormal, articuloscomp.ancho";
		oParam.orderBy = "articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion, pr_ordenesproduccion.ordenpremat";
	}
	//var listaFamEstampado = flfactalma.iface.pub_dameFamEstampado();
	//var listaFamCrudo = flfactalma.iface.pub_dameFamCrudo();
// 	oParam.whereFijo += " AND articulos.codfamilia NOT IN (" + listaFamEstampado + ") AND articulos.codfamilia NOT IN (" + listaFamCrudo+ ")";
	oParam.whereFijo += " AND (articuloscomp.idseccion = '9' OR articuloscomp.id IS NULL OR articuloscomp.componormal = 'BIES')";


	return oParam;
}

function oficial_tbnEtiquetas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var oDH = _i.dameOrdenDH("etiquetas");
	if (!oDH) {
		return false;
	}	
	var w = "op.codorden >= '" + oDH.codOrdenDesde + "' AND op.codorden <= '" + oDH.codOrdenHasta + "' AND NOT op.materialconfok AND op.estado <> 'TERMINADA'";

	var oB = this.child("chkEtiOrdenInverso").checked ? "op.codorden desc, referencia DESC " : "op.codorden, referencia";
	debug("w: " + w + " ORDER BY " + oB);
	formpr_ordenesproduccion.iface.pub_imprimeEtiquetas(w + " ORDER BY " + oB);
	this.child("tableDBRecords").refresh();
}

function oficial_tbnInformeMat_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var oDH = _i.dameOrdenDH("materiales");
	if (!oDH) {
		return false;
	}	
	var oP = new Object;
	oP.codOrdenDesde= oDH.codOrdenDesde;
	oP.codOrdenHasta= oDH.codOrdenHasta;
	oP.masWhere = " AND NOT materialconfok AND pr_ordenesproduccion.estado <> 'TERMINADA'";
	formpr_ordenesproduccion.iface.pub_imprimeOrdenMat(oP);
	this.child("tableDBRecords").refresh();
}

function oficial_dameOrdenDH(tipoImpreso)
{
	var _i = this.iface;
	var d = new Dialog;
	d.caption = sys.translate("�rdenes de producci�n");
	d.okButtonText = sys.translate("Aceptar");
	d.cancelButtonText = sys.translate("Cancelar");

	var desde = new NumberEdit;
	desde.label = sys.translate("Desde orden");
	desde.decimals = 0;
	desde.minimum = 0;
	d.add( desde );
	
	var hasta = new NumberEdit;
	hasta.label = sys.translate("Hasta orden");
	hasta.decimals = 0;
	hasta.minimum = 0;
	d.add( hasta );	

	var cbImpresosPM = new ComboBox;
	if(tipoImpreso == "informeprepmat") {
		var aListaPM = ["000 - Informe subfamilia","001 - Impreso de preparaci�n de materiales cl�sica"];
		
		cbImpresosPM.label = sys.translate("Impreso de Preparaci�n de materiales    ");
		cbImpresosPM.editable = false;
		cbImpresosPM.itemList = aListaPM;
		d.add(cbImpresosPM);

	} else if(tipoImpreso == "etiquetas") {	
		var aListaET = ["000 - Informe subfamilia","001 - Etiquetas cl�sica"];
		
		cbImpresosPM.label = sys.translate("Etiquetas    ");
		cbImpresosPM.editable = false;
		cbImpresosPM.itemList = aListaET;
		d.add(cbImpresosPM);

	} else if(tipoImpreso == "etiquetascaja") {	
		var aListaET = ["000 - Informe subfamilia","001 - Etiquetas de caja"];
		
		cbImpresosPM.label = sys.translate("Etiquetas    ");
		cbImpresosPM.editable = false;
		cbImpresosPM.itemList = aListaET;
		d.add(cbImpresosPM);

	}else if(tipoImpreso == "materiales") {	
		var aListaET = ["000 - Informe subfamilia","001 - Orden de materiales cl�sica"];
		
		cbImpresosPM.label = sys.translate("Etiquetas    ");
		cbImpresosPM.editable = false;
		cbImpresosPM.itemList = aListaET;
		d.add(cbImpresosPM);
	}
	
	if (!d.exec()) {
		return false;
	}
	if (desde.value > hasta.value) {
		return false;
	}
	var oDatos = new Object;
	oDatos.codOrdenDesde = "OP" + flfactppal.iface.pub_cerosIzquierda(desde.value, 8);
	oDatos.codOrdenHasta = "OP" + flfactppal.iface.pub_cerosIzquierda(hasta.value, 8);	
	oDatos.impresoOP = cbImpresosPM.currentItem;
		
	return oDatos;
}

function oficial_tbnEtiquetasCaja_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var oDH = _i.dameOrdenDH("etiquetascaja");
	if (!oDH) {
		return false;
	}	
	var w = "op.codorden >= '" + oDH.codOrdenDesde + "' AND op.codorden <= '" + oDH.codOrdenHasta + "' AND NOT op.materialconfok AND op.estado <> 'TERMINADA' ORDER BY op.codorden, a.referencia, a.descripcion, a.codtamanoem";	
	_i.imprimeEtiquetasCaja(w);


	//this.child("tableDBRecords").refresh();
}

function oficial_imprimeEtiquetasCaja(w)
{
	//debug("euromoda_imprimeEtiquetas " + w);
	var _i = this.iface;
	var aEtiquetas = _i.dameArrayEtiquetas(w);
	if (!aEtiquetas) {
		return false;
	}
  	formem_etiquetascaja.iface.pub_imprimeEtiquetasCaja(aEtiquetas);

  	//var idUsuarioMod = sys.nameUser();
	//var fechaMod = flfactppal.iface.dameFechaActual();
	//var horaMod = flfactppal.iface.dameHoraActual();

	//var aWhere = w.split("ORDER");
	//var sWhere = aWhere[0];
	//sWhere = flfactppal.iface.replace(sWhere, "op.", "");
	//debug("sWhere: "+sWhere);	

	//AQUtil.execSql("UPDATE pr_ordenesproduccion SET idusuariomodiet = '" + idUsuarioMod + "', fechamodiet = '" + fechaMod + "', horamodiet = '" + horaMod + "'   WHERE " + sWhere);


}

function oficial_dameArrayEtiquetas(w)
{
	var _i = this.iface;
	
	/*if (_i.etiquetasExtra_ == undefined) {
		_i.calculaEtiquetasExtra();
	}*/
	
	var qE = new AQSqlQuery;
	qE.setSelect("a.descripcion, a.codtamanoem, a.referencia, a.codcolorem, a.codbarras, em_disenos.codseriediseno, sf.descripcion, sf.em_abreviaturalog, a.emdibujo, op.codcliente, ls.canlote");
	qE.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion INNER JOIN articulos a ON ls.referencia = a.referencia LEFT OUTER JOIN em_dibujos ON a.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno LEFT OUTER JOIN subfamilias sf ON sf.codsubfamilia = a.codsubfamilia");
	qE.setWhere(w);
	debug(qE.sql());
	qE.setForwardOnly(true);
	if (!qE.exec()) {
		return;
	}
	debug(qE.sql());
	var aEtiquetas = [];
	var referencia, cantidad, datosEmb, canEmb, observaciones;
	var descDibujo = "";
	var codseriediseno = "";
	var descripcion = "";
	while (qE.next()) {
		referencia = qE.value("a.referencia");
		cantidad = qE.value("ls.canlote");
		datosEmb = flfactalma.iface.pub_dameEmbalajeArticulo(referencia, qE.value("op.codcliente"), true);
		canEmb = datosEmb ? (Math.ceil(cantidad / datosEmb.capacidad)) : 0;
		//cantidad += parseFloat(canEmb);
		//cantidad += parseFloat(_i.etiquetasExtra_);
		var aE = new Object;
		aE["referencia"] = qE.value("a.referencia");		
		aE["tamanocolor"] = qE.value("a.codtamanoem") + "    " + qE.value("a.codcolorem");	

		codseriediseno = qE.value("em_disenos.codseriediseno");
		descDibujo = qE.value("a.emdibujo");

		if (codseriediseno && codseriediseno != ""){
			codseriediseno = "[" + codseriediseno + "]";
			descDibujo = descDibujo + " - " + codseriediseno;
		}
		aE["descripcion"] = qE.value("a.descripcion");
		aE["codseriediseno"] = codseriediseno;
		aE["cantidad"] = canEmb;
		aE["barcode"] = qE.value("a.codbarras");
		aE["abrevlog"] = qE.value("sf.em_abreviaturalog");
		aE["descdibujo"] = descDibujo;
		aE["descsubfamilia"] = qE.value("sf.descripcion");	   	
    	aEtiquetas.push(aE);
    }
  	return aEtiquetas;
}




//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////