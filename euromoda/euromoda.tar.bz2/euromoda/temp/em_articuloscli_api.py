# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa

# em_articuloscli = qsa.class_("em_articuloscli")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */
class Oficial(Base):

    def get(self, params, username=None):

        mapa = self.get_mapa()

        obj = qsa.from_project("formAPI").get_resources('em_articuloscli', params, mapa, username)

        return obj

    def get_mapa(self):
        return {
            'join': 'em_articuloscli',
            'order': 'id',
            'map': {
                'id': {'field': 'em_articuloscli.id', 'type': 'string'},
                'referencia': {'field': 'em_articuloscli.referencia', 'type': 'string'}
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
