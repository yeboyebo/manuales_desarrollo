/***************************************************************************
                 em_asignacionesconf.qs  -  description
                             -------------------
    begin                : mar may 14 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
	function calculateField(fN) { return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var listaOPSel_, listaPrepSel_;
	function oficial( context ) { interna( context ); } 
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function formReady() {
		return this.ctx.oficial_formReady();
	}
	function controlUsuario() {
		return this.ctx.oficial_controlUsuario();
	}
	function ledCodOrden_returnPressed() {
		return this.ctx.oficial_ledCodOrden_returnPressed();
	}
	function validaOrdenLed() {
		return this.ctx.oficial_validaOrdenLed();
	}
	function validaOrden(codOrden) {
		return this.ctx.oficial_validaOrden(codOrden);
	}
	function asignaOrden(codOrden) {
		return this.ctx.oficial_asignaOrden(codOrden);
	}
	function habilitaPorModo() {
		return this.ctx.oficial_habilitaPorModo();
	}
	function tbnEliminaAsignacion_clicked() {
		return this.ctx.oficial_tbnEliminaAsignacion_clicked();
	}
	function eliminaAsignacion(oParam) {
		return this.ctx.oficial_eliminaAsignacion(oParam);
	}
	function habilitaPorEstado() {
		return this.ctx.oficial_habilitaPorEstado();
	}
	function ponListaOPSel(l) {
		return this.ctx.oficial_ponListaOPSel(l);
	}
	function ponListaPrepSel(l) {
		return this.ctx.oficial_ponListaPrepSel(l);
	}
	function tbnAsignaVarias_clicked() {
		return this.ctx.oficial_tbnAsignaVarias_clicked();
	}
	function habilitaPorLineas() {
		return this.ctx.oficial_habilitaPorLineas();
	}
	function tbnAsignaPrep_clicked() {
		return this.ctx.oficial_tbnAsignaPrep_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
	function pub_eliminaAsignacion(oParam) {
		return this.eliminaAsignacion(oParam);
	}
	function pub_ponListaOPSel(l) {
		return this.ponListaOPSel(l);
	}
	function pub_ponListaPrepSel(l) {
		return this.ponListaPrepSel(l);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	/*if (sys.nameBD() == "abanq_creaciones") {
		this.child("tbnAsignaPrep").close();
	}*/
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this, "formReady()", _i, "formReady");
	connect(this.child("ledCodOrden"), "returnPressed()", _i, "ledCodOrden_returnPressed");
	connect(this.child("tbnEliminaAsignacion"), "clicked()", _i, "tbnEliminaAsignacion_clicked");
	connect(this.child("tbnAsignaVarias"), "clicked()", _i, "tbnAsignaVarias_clicked");
	connect(this.child("tbnAsignaPrep"), "clicked()", _i, "tbnAsignaPrep_clicked");
	
	_i.habilitaPorModo();
	_i.habilitaPorEstado();
	_i.habilitaPorLineas();
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_formReady()
{
	var _i = this.iface;
	_i.controlUsuario();
}

function oficial_controlUsuario()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbIdUser", sys.nameUser());
			break;
		}
	}
}

function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		default: {
		}
	}
			
	return valor;
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		default: {
		}
	}
}

function oficial_ledCodOrden_returnPressed()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbOrdenes").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}
	
	var codOrden = _i.validaOrdenLed();
	if (!codOrden) {
		return false;
	}
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al asociar la orden %1").arg(codOrden);
	oParam.codOrden = codOrden;
	var f = new Function("oParam", "return formRecordem_asignacionesconf.iface.asignaOrden(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	
	_i.habilitaPorModo();
	this.child("ledCodOrden").text = "";
	this.child("tdbOrdenes").refresh();
	_i.habilitaPorLineas();
}

function oficial_asignaOrden(oParam)
{
	var _i = this.iface;
	var codOrden = oParam.codOrden;
	var cursor = this.cursor();
	
	var vB = cursor.valueBuffer;
	if (!AQSql.update("pr_ordenesproduccion", ["codasigconf", "codconfeccionista", "nombreconfeccionista"], [vB("codasigconf"), vB("codconfeccionista"), vB("nombreconfeccionista")], "codorden = '" + codOrden + "'")) {
		return false;
	}
	return true;
}

function oficial_validaOrdenLed()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var orden = this.child("ledCodOrden").text;
	if (orden == "") {
		return false;
	}
	var codOrden;
	if (orden.length != 10) {
		if (isNaN(orden)) {
			return false;
		}
		codOrden = "OP" + flfactppal.iface.pub_cerosIzquierda(orden, 8);
	}
	if (!_i.validaOrden(codOrden)) {
		return false;
	}
	return codOrden;
}

function oficial_validaOrden(codOrden)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var datosOrden = flfactppal.iface.pub_ejecutarQry("pr_ordenesproduccion", "estado,codconfeccionista,codasigconf,nombreconfeccionista", "codorden = '" + codOrden + "'");
debug("select estado,codconfeccionista,codasigconf,nombreconfeccionista from pr_ordenesproduccion where codorden = '" + codOrden + "'");
	
	if (datosOrden.result != 1) {
		sys.warnMsgBox(sys.translate("La orden %1 no existe").arg(codOrden));
		return false;
	}
	var estado = datosOrden.estado;
	switch (estado) {
		case "PTE":
		case "EN CURSO":
		case "PTE CONFECCION": {
			if (datosOrden.codconfeccionista && datosOrden.codconfeccionista != "") {
				sys.warnMsgBox(sys.translate("La orden %1 est� asociada al confeccionista %2").arg(codOrden).arg(datosOrden.nombreconfeccionista));
				return false;
			}
			if (datosOrden.codasigconf && datosOrden.codasigconf != "") {
				sys.warnMsgBox(sys.translate("La orden %1 ya est� asociada al otra asignaci�n (%2)").arg(codOrden).arg(datosOrden.codasigconf));
				return false;
			}
			break;
		}
		default: {
			sys.warnMsgBox(sys.translate("La orden %1 no existe o tiene un estado no controlado").arg(codOrden));
			return false;
		}
	}
	return true;
}

function oficial_habilitaPorModo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var hayA = AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", "codasigconf = '" + cursor.valueBuffer("codasigconf") + "'");
	if (hayA) {
		sys.disableObj(this, "fdbCodConfeccionista");
		sys.disableObj(this, "fdbDesConfeccionista");
	} else {
		sys.enableObj(this, "fdbCodConfeccionista");
		sys.enableObj(this, "fdbDesConfeccionista");
	}
}

function oficial_habilitaPorEstado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (cursor.valueBuffer("estado") != "Asignada") {
		cursor.setModeAccess(cursor.Browse);
		cursor.refreshBuffer();
		this.child("tdbOrdenes").setReadOnly(true);
		this.child("gbxBotones").enabled = false;
	}
}

function oficial_tbnEliminaAsignacion_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var curOrden = this.child("tdbOrdenes").cursor();
	var codOrden = curOrden.valueBuffer("codorden");
	
	var estado = curOrden.valueBuffer("estado");
	if (estado != "PTE" && estado != "EN CURSO" && estado != "PTE CONFECCION") {
		sys.warnMsgBox(sys.translate("El estado de la orden debe ser PTE, EN CURSO o PTE CONFECCION"));
		return false;
	}
	if (AQUtil.sqlSelect("pedidosprov", "idpedido", "codordenprod = '" + codOrden + "'")) {
		sys.warnMsgBox(sys.translate("No puede desvincular la orden, tiene pedidos de proveedor asociados"));
		return false;
	}
	
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al desvincular la orden %1").arg(codOrden);
	oParam.codOrden = codOrden;
	var f = new Function("oParam", "return formRecordem_asignacionesconf.iface.eliminaAsignacion(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	this.child("tdbOrdenes").refresh();
	_i.habilitaPorLineas();
	return true;
}

function oficial_eliminaAsignacion(oParam)
{
	if (!AQSql.update("pr_ordenesproduccion", ["codasigconf", "codconfeccionista", "nombreconfeccionista"], [], "codorden = '" + oParam.codOrden + "'")) {
		return false;
	}
	
	// 	var codOrden = this.child("tdbOrdenes").cursor().valueBuffer("codorden");
// 	var curO = new FLSqlCursor("pr_ordenesproduccion");
// 	curO.select("codorden = '" + codOrden + "'");
// 	if (!curO.first()) {
// 		sys.warnMsgBox(sys.translate("Error al desvincular la orden %1. No se ha encontrado la orden").arg(codOrden));
// 		return false;
// 	}
// 	curO.setModeAccess(curO.Edit);
// 	curO.refreshBuffer();
// 	curO.setNull("codasigconf");
// 	curO.setNull("codconfeccionista");
// 	curO.setNull("nombreconfeccionista");
// 	if (!curO.commitBuffer()) {
// 		sys.warnMsgBox(sys.translate("Error al desvincular la orden %1").arg(codOrden));
// 		return false;
// 	}
// 	this.child("tdbOrdenes").refresh();

	return true;
}

function oficial_tbnAsignaVarias_clicked()
{
	var _i = this.iface;
  var cursor = this.cursor();
	
	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbOrdenes").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}
	var wOrdenes = "estado = 'PTE CONFECCION' AND codasigconf IS NULL AND codconfeccionista IS NULL";
//	if (sys.nameBD() == "abanq_creaciones") {
		wOrdenes += " AND NOT materialconfok";
//	}
	var f = new FLFormSearchDB("em_selectopasignaconf");
	f.cursor().setMainFilter(wOrdenes);
	f.setMainWidget();
	f.exec();
	if (!f.accepted()){
		return false;
	}
	if (!_i.listaOPSel_ || _i.listaOPSel_.length == 0) {
		return false;
	}
	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Asignando �rdenes"), _i.listaOPSel_.length);
	var p = 0;
	var oParam = new Object;
	var f = new Function("oParam", "return formRecordem_asignacionesconf.iface.asignaOrden(oParam)");
	for (var i = 0; i < _i.listaOPSel_.length; i++) {
		oParam.codOrden = _i.listaOPSel_[i];
		AQUtil.setProgress(++p);
		AQUtil.setLabelText(sys.translate("Asignando orden %1").arg(oParam.codOrden));
		oParam.errorMsg = sys.translate("Error al asociar la orden %1").arg(oParam.codOrden);
		if (!sys.runTransaction(f, oParam)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		this.child("tdbOrdenes").refresh();
	}
	AQUtil.destroyProgressDialog();
	_i.habilitaPorLineas();
	
}

function oficial_tbnAsignaPrep_clicked()
{
	var _i = this.iface;
  var cursor = this.cursor();
	
	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbOrdenes").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}
	
	var wOrdenes = "estado = 'PTE CONFECCION' AND codasigconf IS NULL AND codconfeccionista IS NULL";
	var f = new FLFormSearchDB("em_selectprepasignaconf");
	f.cursor().setMainFilter("materialconfok AND codpreparamat IN (SELECT codpreparamat FROM pr_ordenesproduccion WHERE " + wOrdenes + ")");
	f.setMainWidget();
	f.exec();
	if (!f.accepted()){
		return false;
	}
	if (!_i.listaPrepSel_ || _i.listaPrepSel_.length == 0) {
		return false;
	}
	var lPrep = "'" + _i.listaPrepSel_.join("', '") + "'";
	
	var q = new AQSqlQuery;
	q.setSelect("codorden");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("codpreparamat IN (" + lPrep + ") AND " + wOrdenes);
	if (!q.exec()) {
		return false;
	}
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Asignando �rdenes"), q.size());
	var p = 0;
	var oParam = new Object;
	var f = new Function("oParam", "return formRecordem_asignacionesconf.iface.asignaOrden(oParam)");
	while (q.next()) {
		oParam.codOrden = q.value("codorden");
		AQUtil.setProgress(++p);
		AQUtil.setLabelText(sys.translate("Asignando orden %1").arg(oParam.codOrden));
		oParam.errorMsg = sys.translate("Error al asociar la orden %1").arg(oParam.codOrden);
		if (!sys.runTransaction(f, oParam)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		this.child("tdbOrdenes").refresh();
	}
	AQUtil.destroyProgressDialog();
	_i.habilitaPorLineas();
	
}


function oficial_ponListaOPSel(l)
{
	var _i = this.iface;
	_i.listaOPSel_ = l;
}

function oficial_ponListaPrepSel(l)
{
	var _i = this.iface;
	_i.listaPrepSel_ = l;
}

function oficial_habilitaPorLineas()
{
	var curL = this.child("tdbOrdenes").cursor();
	if (curL.size() > 0) {
		sys.disableObj(this, "fdbCodConfeccionista");
		sys.disableObj(this, "fdbDesConfeccionista");
	} else {
		sys.enableObj(this, "fdbCodConfeccionista");
		sys.enableObj(this, "fdbDesConfeccionista");
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////