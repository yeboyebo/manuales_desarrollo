
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
  var codAlmaFiltro_;
  var curS_, pK_;
  var valorCombo_;
  var lineaAct_;
  function euromoda( context ) { oficial ( context ); }
  function init() {
    return this.ctx.euromoda_init();
  }
  function tbnAcumulaLotes_clicked() {
    return this.ctx.euromoda_tbnAcumulaLotes_clicked();
  }
  function ordenaCols() {
    return this.ctx.euromoda_ordenaCols();
  }
  function ordenCols() {
    return this.ctx.euromoda_ordenCols();
  }
  	function toolButtonInsert_clicked() {
		return this.ctx.euromoda_toolButtonInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.euromoda_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.euromoda_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.euromoda_toolButtonZoom_clicked();
	}
	function curS_bufferCommited() {
		return this.ctx.euromoda_curS_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tdbLotes_recordChoosed() {
		return this.ctx.euromoda_tdbLotes_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function tbnFiltroEM_clicked() {
		return this.ctx.euromoda_tbnFiltroEM_clicked();
	}
	function tbnQuitarFiltroEM_clicked(){
		return this.ctx.euromoda_tbnQuitarFiltroEM_clicked();
	}
	function filtroInicial() {
		return this.ctx.euromoda_filtroInicial();
	}
	function preloadMainFilter() {
		return this.ctx.euromoda_preloadMainFilter();
	}
	function filtraEM() {
		return this.ctx.euromoda_filtraEM();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
	
	var cursor = this.cursor();
	_i.ordenaCols();
	connect(this.child("toolButtonInsert"), "clicked()", _i, "toolButtonInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	
	
	if(cursor.action() != "v_lotesstock") {
		if(this.child("tbnQuitarFiltroEM")) {
			this.child("tbnQuitarFiltroEM").close();	
		}
		if(this.child("tbnFiltroEM")) {
			this.child("tbnFiltroEM").close();
		}
		if(this.child("cbOpcionEM")) {
			this.child("cbOpcionEM").close();
		}
		if(this.child("txtmostrar")) {
			this.child("txtmostrar").close();
		}
	} else {
		connect(this.child("tbnQuitarFiltroEM"), "clicked()", _i, "tbnQuitarFiltroEM_clicked");
		connect(this.child("tbnFiltroEM"), "clicked()", _i, "tbnFiltroEM_clicked");	
		connect(this.child("cbOpcionEM"), "activated(QString)", _i, "filtraEM");
		connect(this.child("tdbLotes").cursor(), "recordChoosed()", _i, "tdbLotes_recordChoosed");
	}
	//_i.filtroInicial();

	
	
}           

function euromoda_ordenaCols()
{
	var _i = this.iface;
	var cols = _i.ordenCols();
	var cursor = this.cursor();
	if (cursor.action() == "em_seleccionpartida") {
		this.child("tableDBRecords").setOrderCols(cols);
	} else {
		this.child("tdbLotes").setOrderCols(cols);
	}
}

function euromoda_ordenCols()
{
	var cursor = this.cursor();
	var cols;
	if (cursor.action() == "em_seleccionpartida") {
		cols = ["codlote", "fechaentradaem", "referencia", "mptedist"];
	} else {
		cols = ["codlote", "fechaentradaem", "codordenest","referencia", "articulo", "codalmacen", "ubicacion", "candisponible", "canlote","canreservada","cantotal","codformato","em_observaciones"];
	}
	return cols;
}

function euromoda_tbnAcumulaLotes_clicked()
{
// 	var _i = this.iface;
// 	var cursor = this.cursor();
// 	
// 	if (cursor.valueBuffer("estado") != "PTE") {
// 		MessageBox.warning(sys.translate("El estado del lote debe ser PTE"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
// 		return false;
// 	}
// 	if (cursor.isNull("codordenproduccion")) {
// 		MessageBox.warning(sys.translate("El lote debe estar asociado a una orden de producci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
// 		return false;
// 	}
// 	var dispFuturo = cursor.valueBuffer("canlote") - cursor.valueBuffer("canreservada");
// 	if (dispFuturo <= 0) {
// 		MessageBox.warning(sys.translate("El lote est� ya completamente reservado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
// 		return false;
// 	}
// 	if (!flfactalma.iface.pub_acumulaLotesPendientes(cursor)) {
// 		return false;
// 	}
	return true;
}


function euromoda_tdbLotes_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEdit_clicked();
}
function euromoda_toolButtonInsert_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");
}

function euromoda_toolButtonEdit_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDelete_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoom_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}
function euromoda_accionCursorExterno(accion)
{
	debug("euromoda_accionCursorExterno");
	var _i = this.iface;
	var cursor = this.cursor();
	var curTabla = this.child("tdbLotes").cursor();
	if (_i.curS_) {
		disconnect(_i.curS_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curS_, "commited()", _i, "curS_bufferCommited");
		_i.curS_ = undefined;
	}
	
	_i.curS_ = new FLSqlCursor("lotesstock");
	_i.curS_.setAction("lotesstock");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			debug("parteA: "+cursor.primaryKey());
			debug("parteB: "+cursor.valueBuffer(cursor.primaryKey()));
			debug("codlote: "+cursor.valueBuffer("codlote"));
			debug("parteA2: "+curTabla.primaryKey());
			debug("parteB2: "+curTabla.valueBuffer(cursor.primaryKey()));			
			debug("codlote2: "+curTabla.valueBuffer("codlote"));
			//_i.curS_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			_i.curS_.select(curTabla.primaryKey() + " = '" + curTabla.valueBuffer(curTabla.primaryKey()) +"'");
			if (!_i.curS_.first()) {
				debug("no lo encuentra");
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");
			_i.curS_.insertRecord();
			break;
		}
		case "edit": {
			_i.lineaAct_ = this.child("tdbLotes").currentRow();			
			debug("linea antes de editar: "+_i.lineaAct_);
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");
			//connect(_i.curS_, "commited()", _i, "refrescaTabla");
			_i.curS_.editRecord();			
			
			break;
		}
		case "del": {
			var res = flfactppal.iface.preguntaMsg(sys.translate("El registro activo ser� borrado. �Est� seguro?"),"info",this,MessageBox.Yes, MessageBox.No);  	
        	if (res != MessageBox.Yes) {					
        		return true
        	}
			//this.child("tdbLotes").deleteRecord();
			_i.curS_.setModeAccess(_i.curS_.Del);
			_i.curS_.refreshBuffer();
			if(!_i.curS_.commitBuffer()) {
				debug("error al borrar registro");
			}	
			this.child("tdbLotes").refresh();
			break;
		}
		case "browse": {	
			_i.curS_.browseRecord();
			break;
		}
	}
}
function euromoda_curS_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	debug("linea al guardar: "+_i.lineaAct_);
	this.child("tdbLotes").refresh();
	var dtbLC = this.mainWidget().child("tdbLotes").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);
	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);
	var pos = cursor.atFromBinarySearch("codlote", _i.pK_, asc);
	debug("posici�n: "+pos);
	cursor.seek(pos);
	cursor.refresh()
}
function euromoda_refrescaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.refresh()
}

function euromoda_filtroInicial()
{
	var _i = this.iface;
	var filtroInicial = "";
	var sesion = flfactalma.iface.pub_dameSesion();
	
	AQUtil.sqlDelete("em_filtroslotstock","sesion = '" + sesion + "'");

	filtroInicial = "1 = 2";	

	this.cursor().setMainFilter(filtroInicial);	

}

function euromoda_tbnFiltroEM_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);



	var sesion = flfactalma.iface.pub_dameSesion();
	debug("sesion: "+sesion);
	var f = new FLFormSearchDB("em_filtroslotstock");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
	
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
		
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);
	f.setMainWidget();
	f.exec();
	
	try {
		if(f.accepted()) {
			curF.commitBuffer();
			var filtro = curF.valueBuffer("filtro"); 
			
			this.child("cbOpcionEM").currentText = _i.valorCombo_;
	      _i.filtraEM();
			/*if (filtro) {
				
				cursor.setMainFilter(filtro);
			} else {
				cursor.setMainFilter("");
			}*/
			
			this.child("tdbLotes").refresh();
			curT.commit();
		} else {
			 curT.rollback();
		}
	} catch(e) {		
		curT.rollback();		
		MessageBox.critical(sys.translate("Error al filtrar") + e, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}		
}

function euromoda_tbnQuitarFiltroEM_clicked()
{
	var _i = this.iface;
	var sesion = flfactalma.iface.pub_dameSesion();
	AQUtil.sqlDelete("em_filtroslotstock","sesion = '" + sesion + "'");
	_i.filtraEM();
	//this.child("tdbLotes").refresh();
	
}

function euromoda_preloadMainFilter()
{
	var _i = this.iface;
	var cursor = this.cursor();
	debug("accion: "+cursor.action());
	/*if (!cursor.mainFilter().toString().isEmpty()){
		_i.filtroMainAnterior_ = cursor.mainFilter();
	}
	else{
		_i.filtroMainAnterior_ = "";
	}
	
	if(flfactppal.iface.valorDefecto("fpclientes"))*/
	if(cursor.action() == "v_lotesstock") {
		return "1 = 2";
	}
	//return "1 = 1";
}

function euromoda_filtraEM()
{
	var _i = this.iface;	
	formem_filtroslotstock.iface.valorComboFiltro_ = this.child("cbOpcionEM").currentText;
	var cursor = this.cursor();
	var sesion = flfactalma.iface.pub_dameSesion();	
	var filtro = AQUtil.sqlSelect("em_filtroslotstock","filtro","sesion = '" + sesion + "'");	
	if(!filtro) {
		filtro = "";
	}	
	if(filtro == "1 = 2") {
		filtro = "";
	}
	var opcion = this.child("cbOpcionEM").currentText;
	if(opcion == "Solo con disponible") {
		filtro += filtro == "" ? "" : " AND ";
		filtro += "candisponible > 0";				
	} else if (opcion ==	"Ninguno") {
		filtro = "1 = 2";
	}

	this.child("tdbLotes").cursor().setMainFilter(filtro);
	this.child("tdbLotes").refresh();


}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
