
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function dameParamInforme(idTrans, cursor) {
		return this.ctx.euromoda_dameParamInforme(idTrans, cursor);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_dameParamInforme(idTrans, cursor) {
		return this.dameParamInforme(idTrans, cursor);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_dameParamInforme(idTrans, cursor)
{
	var _i = this.iface;
	var oParam = _i.__dameParamInforme(idTrans);
	if (!cursor) {
		cursor = this.cursor();
	}
	var codAlmaOrigen = cursor.valueBuffer("codalmaorigen");
	var codAlmaDestino = cursor.valueBuffer("codalmadestino");
	if (codAlmaOrigen.toString() > codAlmaDestino.toString()) {
		oParam.orderBy = "almacenes.codalmacen DESC";
	} else {
		oParam.orderBy = "almacenes.codalmacen ASC";
	}
	oParam.orderBy += ", subfamilias.codsubfamilia, lineastransstock.descripcion";
	
// 	oParam.numCopias = 2;
	return oParam;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
