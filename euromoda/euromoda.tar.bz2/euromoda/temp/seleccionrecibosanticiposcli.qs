
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
  function euromoda(context)
  {
    oficial(context);
  }
  function incluirRecibo() {
		return this.ctx.euromoda_incluirRecibo();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_incluirRecibo()
{
	debug("euromoda_incluirRecibo");
	var _i = this.iface;
	var cursor = this.cursor();
	var aListado= this.child("tableDBRecords").primarysKeysChecked();
	var aListadoOrd = [];	
	if (aListado && aListado.length > 0) {
	
		var q = new AQSqlQuery;	
		q.setSelect("idrecibo");
		q.setFrom("reciboscli");
		q.setWhere("idrecibo IN (" + aListado + ") order by importe asc"); 			
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			aListadoOrd.push(q.value("idrecibo"));
		}	
		debug("aListado: "+aListado);
		debug("aListadoOrd: "+aListadoOrd);
		formRecordanticiposcli.iface.pub_ponListaRecibos(aListadoOrd);
	} else {
		formRecordanticiposcli.iface.pub_ponListaRecibos(false);
	}
	sys.setObjText(this, "lblTotal", _i.lblTotalTexto_ + _i.calcularImporte(aListado));
 
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

