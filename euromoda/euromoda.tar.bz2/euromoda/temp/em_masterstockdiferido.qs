/***************************************************************************
                 em_masterstockdiferido.qs  -  description
                             -------------------
    begin                : mie mar 08 2006
    copyright            : (C) 2006 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 
/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var timerId;
	var activado_;
	var intervalo_;
	var pbnActivar;
	var spbIntervalo;
	var lblEstado;
	var nombreLog_;
	var nombreLogFile_;
	function oficial( context ) { interna( context ); }
	function pbnActivar_clicked() {
		return this.ctx.oficial_pbnActivar_clicked();
	}
	function activar() {
		return this.ctx.oficial_activar();
	}
	function iniciarTablaLlamadas() {
		return this.ctx.oficial_iniciarTablaLlamadas();
	}
	function activarBackground(ms) {
		return this.ctx.oficial_activarBackground(ms);
	}
	function cerrar() {
		return this.ctx.oficial_cerrar();
	}
	function comprobarStock() {
		return this.ctx.oficial_comprobarStock();
	}
	function procesarStock(oParam) {
		return this.ctx.oficial_procesarStock(oParam);
	}
	function ejecutar(funcion, idLlamada) {
		return this.ctx.oficial_ejecutar(funcion, idLlamada);
	}
	function activado() {
		return this.ctx.oficial_activado();
	}
	function generarFactura(idLlamada) {
		return this.ctx.oficial_generarFactura(idLlamada);
	}
	function testFunction(param) {
		return this.ctx.oficial_testFunction(param);
	}
	function abreLog() {
		return this.ctx.oficial_abreLog();
	}
	function dameNombreLog(esquema) {
		return this.ctx.oficial_dameNombreLog(esquema);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_activado() {
  	return this.activado();
  }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
Este formulario realiza la gestion de los albaranes a clientes.

Los albaranes pueden ser generados de forma manual o a partir de uno o mas pedidos.
\end */
function interna_init()
{
	var _i = this.iface;

	_i.activado_ = false;
	_i.pbnActivar = this.child("pbnActivar");
	_i.lblEstado = this.child("lblEstado");
	_i.spbIntervalo = this.child("spbIntervalo");

	_i.spbIntervalo.setValue(3000);

	connect(_i.pbnActivar, "clicked()", _i, "pbnActivar_clicked()");
	connect(this, "closed()", _i, "cerrar()");

	var cursor = this.cursor();
	cursor.setMainFilter("idusuario = '" + sys.nameUser() + "'");
	this.child("tableDBRecords").refresh();
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_cerrar()
{
	var _i = this.iface;

	_i.activado_ = false;
	killTimer(_i.timerId);
}

/** \D Determina si el aut�mata est� procesando acciones o no
@return	True si est� ejecutando acciones, false en caso contrario
\end */
function oficial_activado()
{
	var _i = this.iface;

	return _i.activado_;
}

function oficial_pbnActivar_clicked()
{
	var _i = this.iface;

	_i.activar();
}

function oficial_activar()
{
	var _i = this.iface;

	if (_i.activado_)
	{
		killTimer(_i.timerId);
		_i.activado_ = false;
		_i.pbnActivar.text = sys.translate("Activar");
		_i.lblEstado.text = "";
	}
	else {
		_i.activado_ = true;
		_i.pbnActivar.text = sys.translate("Desactivar");
		_i.intervalo_ = _i.spbIntervalo.value;
		_i.lblEstado.text = sys.translate("Esperando...");
		_i.abreLog();
		_i.timerId = startTimer(_i.intervalo_, _i.comprobarStock);
	}
}

function oficial_activarBackground(ms)
{
	var _i = this.iface;

	if(!ms)
		ms = 300;
	var d1 = new Date, d2;
	var t1 = d1.getTime(), t2;

	_i.abreLog();

	_i.intervalo_ = ms;
	_i.timerId = startTimer(_i.intervalo_, _i.comprobarStock);
	var f = new FLFormSearchDB("au_automata");
	f.exec("x");
}

/** \D Comprueba si se ha insertado alguna nueva llamada y la procesa
\end */
function oficial_comprobarStock()
{
	var _i = this.iface;

	debug("oficial_comprobarStock");

	var idStockPte = AQUtil.sqlSelect("stocksptes", "idstockpte", "idusuario = '" + sys.nameUser() + "'");
	debug("idStockPte: " + idStockPte);
	killTimer(_i.timerId);
	_i.timerId = false;

	while (idStockPte)
	{

		
		if (sys.interactiveGUI())
		{
			_i.lblEstado.text = sys.translate("Procesando idStockPte %1").arg(idStockPte);
			_i.lblEstado.text = sys.translate("Esperando...");
		}
		var oParam = new Object;
		oParam.errorMsg = sys.translate("<Response desc=\"Error al procesar idStockPte %1\"/>").arg(idStockPte.toString());
		oParam.idStockPte = idStockPte;
		
		
		var f = new Function("oParam", "return formem_stockdiferido.iface.procesarStock(oParam)");
		if (!sys.runTransaction(f, oParam)) {
			flfactppal.iface.pub_appendTextToLogFile(_i.nombreLog_, sys.translate("Se ha producido un error: %1").arg(e));
		}
		oParam = undefined;
		f = undefined;
		idStockPte = AQUtil.sqlSelect("stocksptes", "idstockpte", "idusuario = '" + sys.nameUser() + "'");
	}
	if (!_i.timerId)
	{
		_i.timerId = startTimer(_i.intervalo_, _i.comprobarStock);
	}
}

function oficial_procesarStock(oParam)
{
	
	if (!flfactalma.iface.procesaStocks()) {
		return false;
	}
	if (sys.interactiveGUI()) {
		this.child("tableDBRecords").refresh();
	}
	return true;
}

function oficial_abreLog()
{
	var _i = this.iface;

	var prefijo = "STOCK_DIFERIDO";
	var nombreLog = _i.dameNombreLog(prefijo);
	_i.nombreLog_ = flfactalma.iface.pub_ponLogName(nombreLog);
	var dirLog = AQUtil.sqlSelect("au_general", "directoriolog", "1 = 1");;

	if(!dirLog || dirLog == "")
	{
		dirLog = Dir.home;
	}

	dirLog += dirLog.endsWith("/") ? "" : "/";
	_i.nombreLogFile_ = dirLog + nombreLog;

	if (!flfactppal.iface.pub_abreLogFile(_i.nombreLog_, _i.nombreLogFile_))
	{
		sys.infoMsgBox(sys.translate("No se ha creado el fichero del log de la sincronizaci�n."));
	}
	debug(_i.nombreLog_);
	debug(_i.nombreLogFile_);
}

function oficial_dameNombreLog(esquema)
{
	var _i = this.iface;

	var fecha = new Date();
	var dia = fecha.getDate().toString();
	if(dia.length < 2)
	{
		dia = "0" + dia;
	}
	var mes = fecha.getMonth().toString();
	if(mes.length < 2)
	{
		mes = "0" + mes;
	}
	var anyo = fecha.getYear().toString();
	var hora = fecha.getHours().toString();
	if(hora.length < 2)
	{
		hora = "0" + hora;
	}
	var minuto = fecha.getMinutes().toString();
	if(minuto.length < 2)
	{
		minuto = "0" + minuto;
	}
	var prefijo;
	if(esquema && esquema != "")
	{
		prefijo = esquema;
	}
	else
	{
		prefijo = "STOCK_DIFERIDO";
	}

	var nombreFichero = prefijo + "_" + anyo + mes + dia + hora + minuto + ".log"

	return nombreFichero;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
