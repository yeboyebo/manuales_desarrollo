
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
	function euromoda(context) { oficial(context); }
	function init() {
    return this.ctx.euromoda_init();
  }
	function habilitaPorAsigConf() {
    return this.ctx.euromoda_habilitaPorAsigConf();
  }
	function filtraTareas() {
    return this.ctx.euromoda_filtraTareas();
  }
	function filtraConfecciones() {
    return this.ctx.euromoda_filtraConfecciones();
  }
	function habilitarPestanas() {
    return this.ctx.euromoda_habilitarPestanas();
	}/*
	function validateForm() {
    return this.ctx.euromoda_validateForm();
	}*/
	function validarConfeccionista(cursor) {
		return this.ctx.euromoda_validarConfeccionista(cursor);
  }
	function formReady() {
    return this.ctx.euromoda_formReady();
  }
	function calculaTotalLotes() {
    return this.ctx.euromoda_calculaTotalLotes();
  }
	function tdbLotes_bufferCommited() {
    return this.ctx.euromoda_tdbLotes_bufferCommited();
  }
	function calculateField(fN) {
    return this.ctx.euromoda_calculateField(fN);
  }
	function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
	function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
	function filtraModoOper() {
		return this.ctx.euromoda_filtraModoOper();
	}
	function  validaModoOper(cursor) {
		return this.ctx.euromoda_validaModoOper(cursor);
	}
	function  validateCursor(cursor) {
		return this.ctx.euromoda_validateCursor(cursor);
	}
	function  comprobarFechaUltimaModificacion(cursor) {
		return this.ctx.euromoda_comprobarFechaUltimaModificacion(cursor);
	}

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();

  _i.filtraTareas();
  _i.filtraConfecciones();
  _i.filtraModoOper();
	
	connect(this, "formReady()", _i, "formReady");
	connect(this.child("tdbLotes").cursor(), "bufferCommited()", _i, "tdbLotes_bufferCommited");

  this.child("tbwOrdenes").setTabEnabled("procesos", false);
  this.child("tbwOrdenes").setTabEnabled("planificacion", false);
  this.child("tbwOrdenes").setTabEnabled("buscar", false);
	
	_i.habilitaPorAsigConf();
}

function euromoda_habilitaPorAsigConf()
{
	var _i = this.iface;
  var cursor = this.cursor();
  
	if (cursor.valueBuffer("codasigconf")) {
		sys.disableObj(this, "fdbCodConfeccionista");
		sys.disableObj(this, "fdbDesConfeccionista");
		sys.disableObj(this, "fdbMaterialConfOk");
		sys.setObjText(this, "lblTieneAsignacion", sys.translate("ESTA ORDEN ESTA ASIGNADA EN EL REGISTRO DE ASIGNACION N� %1, ELIMINELO DE ALLI SI DESEA VOLVER A REASIGNAR LA ORDEN").arg(cursor.valueBuffer("codasigconf")));
	} else {
		sys.setObjText(this, "lblTieneAsignacion", "");
	}
}

function euromoda_filtraTareas()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var filtro = "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + cursor.valueBuffer("codorden") + "'";
  this.child("tdbTareas").cursor().setMainFilter(filtro);
  this.child("tdbTareas").refresh();
}

function euromoda_filtraConfecciones()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var filtro = "";
  this.child("tdbPedidosProv").cursor().setMainFilter(filtro);
  this.child("tdbAlbaranesProv").cursor().setMainFilter(filtro);
}

function euromoda_habilitarPestanas()
{
  return;
}

/*function euromoda_validateForm()
{
  var _i = this.iface;
  if (!_i.__validateForm()) {
    return false;
  }
  if (!_i.validarConfeccionista()) {
    return false;
  }
  if(!_i.validaModoOper()) {
    return false;
  }
  return true;
}*/

function euromoda_validarConfeccionista(cursor)
{
  var _i = this.iface;
	// var cursor = this.cursor();
	var codConfec = cursor.valueBuffer("codconfeccionista");
  if (cursor.valueBuffer("materialconfok")) {
    if (!codConfec || codConfec == "") {
      MessageBox.warning(sys.translate("Si el material est� listo debe indicar el confeccionista"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }
  
  var codProveedor = codConfec;
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
      return false;
    }
  }
  return true;
}

function euromoda_formReady()
{
	var cursor = this.cursor();
	if (cursor.action() == "em_materialesconf") {
		this.child("tbwOrdenes").showPage("confeccion");
		this.child("fdbCodConfeccionista").setFocus();
	}
}

function euromoda_calculaTotalLotes()
{
	return true;
}

function euromoda_tdbLotes_bufferCommited()
{
	var _i = this.iface;
	
	sys.setObjText(this, "fdbTotalUds", _i.calculateField("totaluds"));
}

function euromoda_calculateField(fN)
{
	var res;
	var cursor = this.cursor();
			
	switch(fN) {
		case "totaluds": {
			res = AQUtil.sqlSelect("lotesstock", "SUM(canlote)", "codordenproduccion = '" + cursor.valueBuffer("codorden") + "'");
			res = isNaN(res) ? 0 : res;
			break;
		}
		default: {
			res = _i.__calculateField(fN);
			break;
		}
	}
	return res;
}

function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "materialconfok": {
			if (!cursor.valueBuffer("materialconfok") && !cursor.isNull("codpreparamat")) {
				var res = MessageBox.warning(sys.translate("Esta orden est� asociada al grupo de preparaci�n %1.\n�Desea continuar y eliminar la asociaci�n de la orden con dicha preparaci�n?").arg(cursor.valueBuffer("codpreparamat")), MessageBox.Yes, MessageBox.No, "AbanQ");
				if (res == MessageBox.Yes) {
					sys.setObjText(this, "fdbCodPreparaMat", "");
					cursor.setNull("idusuariomatok");
					cursor.setNull("fechamatok");
					cursor.setNull("horamatok");
				} else {
					cursor.setValueBuffer("materialconfok", true);
				}
			}
			break;
		}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	
	switch(fN){
		case "em_codmodooper": {
			valor = AQUtil.sqlSelect("subfamilias", "em_codmodooper", "codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
			if (!valor) {
				valor = AQUtil.sqlSelect("subfamilias s INNER JOIN familias f ON s.codfamilia = f.codfamilia", "f.em_codmodooper", "s.codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'", "familias");
				if (!valor) {
					valor = "";
				}
			}
			break;
		}
		default: {
			try {
				valor = _i.__commonCalculateField(fN, cursor);
			} catch (e) {
			}
		}
	}
	return valor;
}

function euromoda_filtraModoOper()
{
	var _i = this.iface;
 	var cursor = this.cursor();
 	// var codOrden = cursor.valueBuffer("codorden")
  	// var filtro = "codmodooper IN (SELECT em_codmodooper from familias inner join articulos on familias.codfamilia = articulos.codfamilia inner join lotesstock on lotesstock.referencia = articulos.referencia where lotesstock.codordenproduccion = '" + codOrden + "')";
  	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
  	var filtro = "codmodooper IN (SELECT mo.codmodooper FROM subfamilias s INNER JOIN familias f ON s.codfamilia = f.codfamilia INNER JOIN em_modosoperacion mo ON f.em_codseccion = mo.codseccion WHERE s.codsubfamilia = '" + codSubfamilia + "')";
  	debug("filtro: "+filtro);
  	this.child("fdbModoProducion").setFilter(filtro);
  	
  	//this.child("tdbTareas").refresh();	
}

function euromoda_validaModoOper(cursor)
{
	return true;
	
	var _i = this.iface;
	// var cursor = this.cursor();
	var codModoOper = cursor.valueBuffer("em_codmodooper");
	var codOrden = cursor.valueBuffer("codorden");


	if(!AQUtil.sqlSelect("familias INNER JOIN articulos ON familias.codfamilia = articulos.codfamilia INNER JOIN lotesstock ON lotesstock.referencia = articulos.referencia","familias.em_codmodooper","lotesstock.codordenproduccion = '" + codOrden + "' and familias.em_codmodooper = '" + codModoOper + "'","familias,articulos,lotesstock")) {
		MessageBox.warning(sys.translate("El modo de operaci�n no est� asignado a ninguna de las familias de los art�culos de los lotes de la orden de producci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
  		return false;
	}


	return true;

}

function euromoda_validateCursor(cursor) 
{
	var _i = this.iface;
	
	if (!_i.__validateCursor(cursor)) {
		return false;
	}
	if (!_i.validarConfeccionista(cursor)) {
		return false;
	}
	if(!_i.validaModoOper(cursor)) {
		return false;
	}
	if (!_i.comprobarFechaUltimaModificacion(cursor)) {
		return false
	}
	return true;
}

function euromoda_comprobarFechaUltimaModificacion(cursor)
{
	var _i = this.iface;
	if (cursor.isModifiedBuffer()) {
		if (!flfactppal.iface.pub_controlDatosMod(cursor)) {
			return false;
		}
	} 
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
