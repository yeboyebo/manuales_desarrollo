/***************************************************************************
                 em_i_masterestadisticascompra.qs  -  description
                             -------------------
    begin                : mar feb 13 2018
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var origen_;
	function oficial( context ) { interna( context ); } 
	function lanzar() {
		return this.ctx.oficial_lanzar();
	}
	function obtenerParamInforme() {
		return this.ctx.oficial_obtenerParamInforme();
	}
	function dimeOrigen(campo) {
		return this.ctx.oficial_dimeOrigen(campo);
	}
	function dameFiltroEstadisticasCompra(cursor) {
		return this.ctx.oficial_dameFiltroEstadisticasCompra(cursor);
	}
	function dameDescripcionInforme(campo) {
		return this.ctx.oficial_dameDescripcionInforme(campo);
	}
	function dimeFamiliaTamano(nodo, campo) {
		return this.ctx.oficial_dimeFamiliaTamano(nodo, campo);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  	var _i = this.iface;
  	connect (this.child("toolButtonPrint"), "clicked()", _i, "lanzar()");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_lanzar()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var pI = this.iface.obtenerParamInforme();
	if (!pI) {
		return;
	}
	flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

/** \D Obtiene un array con los par�metros necesarios para establecer el informe
@return	array de par�metros o false si hay error
\end */
function oficial_obtenerParamInforme()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var seleccion= cursor.valueBuffer("id");
	if (!seleccion) {
		return false;
	}
	var paramInforme = flfactinfo.iface.pub_dameParamInforme();
	//paramInforme.nombreInforme = cursor.action();
	var origen = cursor.valueBuffer("origendatos");     
debug("origen: "+origen);
	if(origen == "Albaranes") {
		_i.origen_ = "Estad�sticas de albaranado de compra";
	} else {
		_i.origen_ = "Estad�sticas de facturaci�n de compra";
	}
debug("origen2: "+_i.origen_);
  
	switch(cursor.valueBuffer("tipo")) {
	  	case "Normal": {
	  		switch(cursor.valueBuffer("agrupacion")) {
	  			case "No agrupar": {
	  			  	if(origen == "Albaranes") {
	  					paramInforme.nombreInforme = "em_i_alb_estadisticascompra";
	  					paramInforme.nombreReport = "em_i_estadisticascompra";
	  				} else {
	  					paramInforme.nombreInforme = "em_i_estadisticascompra";


	  				}
	  				paramInforme.groupBy = "empresa.cifnif, empresa.direccion, empresa.codpostal, empresa.ciudad, empresa.provincia,cab.fecha, cab.codigo, cab.codproveedor,lin.referencia, lin.descripcion, lin.dtopor, lin.pvpunitario, lin.pvptotal,(lin.pvptotal * (100 - cab.pordtoesp) / 100), lin.cantidad,articulos.descripcion, articulos.codcoleccionem, articulos.codunidad,articulos.referencia,em_colecciones.descripcion, articulos.codtamanoem, articulos.codcolorem";	  				
			  		break;
	  			}
	  			case "Familia/Tam.": {
	  			  	if(origen == "Albaranes") {
	  					paramInforme.nombreInforme = "em_i_alb_estadisticascompra_ft";
	  					paramInforme.nombreReport = "em_i_estadisticascompra_ft";
	  				} else { 
	  					paramInforme.nombreInforme = "em_i_estadisticascompra_ft";
	  				}	  				
			  		break;
	  			}
	  			default: return false;
	  		}
	  		break;
	  	}
	  	case "Abreviado": {
	  		switch(cursor.valueBuffer("agrupacion")) {
				case "No agrupar": {
					if(origen == "Albaranes") {
	  					paramInforme.nombreInforme = "em_i_alb_estadisticascompra_abr";
	  					paramInforme.nombreReport = "em_i_estadisticascompra_abr";
	  				} else {
						paramInforme.nombreInforme = "em_i_estadisticascompra_abr";
					}
					break;
				}
				case "Familia/Tam.": {
					  	if(origen == "Albaranes") {
	  						paramInforme.nombreInforme = "em_i_alb_estadisticascompra_abr_ft";
	  						paramInforme.nombreReport = "em_i_estadisticascompra_abr_ft";
	  					} else {
							paramInforme.nombreInforme = "em_i_estadisticascompra_abr_ft";
						}
						break;
					}
				default: return false;
			}
			break;
		}
		case "Superreducido": {
			switch(cursor.valueBuffer("agrupacion")) {
				case "No agrupar": {
					sys.warnMsgBox(sys.translate("No hay un formato de informe para la agrupaci�n y tipo seleccionados"));
					return false;
					break;
				}
				case "Familia/Tam.": {
				  	if(origen == "Albaranes") {
  						paramInforme.nombreInforme = "em_i_alb_estadisticascompra_sre_ft";
  						paramInforme.nombreReport = "em_i_estadisticascompra_sre_ft";  						
  					} else {
						paramInforme.nombreInforme = "em_i_estadisticascompra_sre_ft";						
					}
					paramInforme.groupBy = "empresa.cifnif, empresa.direccion, empresa.codpostal, empresa.ciudad, empresa.provincia,articulos.codfamilia, familias.descripcion,lin.codtamanoem";
					break;
				}
				default: return false;
			}
			break;
		}
	  	default: return false;
	}
  
	if (cursor.valueBuffer("codintervalo")) {
		var intervalo= [];
		intervalo = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalo"));
		cursor.setValueBuffer("d_cab_fecha", intervalo.desde);
		cursor.setValueBuffer("h_cab_fecha", intervalo.hasta);
	}
  
	var filtroEM = formem_filtrosarticulos.iface.pub_construirFiltro(cursor);
	var where = filtroEM;
	var whereEstadisticas = _i.dameFiltroEstadisticasCompra(cursor);
	if (whereEstadisticas != ""){
		where += (where != "") ? " AND " : "";
		where += whereEstadisticas;
	}

	if(origen == "Albaranes") {
		where += (where != "") ? " AND " : "";
		//where += "cab.tipodeposito IN ('Venta','Venta dep�sito') ";
		where += " 1=1 ";	
	}
debug("obtenerParamInforme__Where: " + where);	
	if (where && where != "") {
		paramInforme.whereFijo = where;
	}
	
  	return paramInforme;
}

function oficial_dimeOrigen(campo)
{
	
	var _i = this.iface;		
debug("origen3: "+_i.origen_);
	return _i.origen_;
}

function oficial_dameFiltroEstadisticasCompra(cursor)
{
	var _i = this.iface;
	var where = "";

	var listaSeries = cursor.valueBuffer("listaseries");
	if (listaSeries && listaSeries != "") {
		var aSeries = listaSeries.split(",");
		where += (where != "") ? " AND " : "";
		where += "cab.codserie IN ('" + aSeries.join("', '") + "')";
	}
	
	var codProveedor = cursor.valueBuffer("codproveedor");
	if(codProveedor && codProveedor != "") {
		where += (where != "") ? " AND " : "";
		where += "cab.codproveedor = '" + codProveedor + "'";
	}
	
	var codTipoTercero = cursor.valueBuffer("codtipotercero");
	if (codTipoTercero && codTipoTercero != "") {		
		where += (where != "") ? " AND " : "";
		where += "proveedores.codtipotercero = '" + codTipoTercero + "'";
	}

	var codSectorTercero = cursor.valueBuffer("codsectortercero");
	if (codSectorTercero && codSectorTercero != "") {		
		where += (where != "") ? " AND " : "";
		where += "proveedores.codsectortercero = '" + codSectorTercero + "'";
	}

	var codCatTercero = cursor.valueBuffer("codcattercero");
	if (codCatTercero && codCatTercero != "") {		
		where += (where != "") ? " AND " : "";
		where += "proveedores.codcattercero = '" + codCatTercero + "'";
	}

	var codSubCatTercero = cursor.valueBuffer("codsubcattercero");
	if (codSubCatTercero && codSubCatTercero != "") {		
		if(where != ""){
			where += " AND ";
		}
		where += "proveedores.codsubcattercero = '" + codSubCatTercero + "'";
	}

	var clasificacion = cursor.valueBuffer("clasificacion");
	if (clasificacion == "Sin valor"){
		clasificacion = "";
	}	
	if (clasificacion && clasificacion != "") {				
		where += (where != "") ? " AND " : "";
		where += "proveedores.clasificacion = '" + clasificacion + "'";
	}

	var codEvalTercero = cursor.valueBuffer("codevaltercero");
	if (codEvalTercero && codEvalTercero != "") {		
		where += (where != "") ? " AND " : "";
		where += "proveedores.codevaltercero = '" + codEvalTercero + "'";
	}

	var evaluacion = cursor.valueBuffer("evaluacion");
	if (evaluacion && evaluacion != "") {		
		where += (where != "") ? " AND " : "";
		where += "proveedores.evaluacion = '" + evaluacion + "'";
	}

	var desdeFechaUltEval = cursor.valueBuffer("desde_fechaulteval");
	var hastaFechaUltEval = cursor.valueBuffer("hasta_fechaulteval");
	if (desdeFechaUltEval && desdeFechaUltEval != "" && hastaFechaUltEval && hastaFechaUltEval != "") {		
		where += (where != "") ? " AND " : "";
		where += "proveedores.fechaulteval >= '" + desdeFechaUltEval + "' AND proveedores.fechaulteval <= '" + hastaFechaUltEval + "'";
	}

	return where;
}

function oficial_dameDescripcionInforme(campo)
{
	
	var _i = this.iface;		
	var cursor = this.cursor();
	var seleccion= cursor.valueBuffer("id");
	if (!seleccion) {
		return false;
	}	
	var descripcion = cursor.valueBuffer("descripcion");
	
	return descripcion;
}

function oficial_dimeFamiliaTamano(nodo, campo)
{
	var _i = this.iface;
	var res;
	switch (campo){
		case "familia":{
			res = nodo.attributeValue("familias.descripcion"); 
			if(!res || res == ""){
				res = "SIN FAMILIA";
			}
			break;
		}
		case "tamano":{
			res = nodo.attributeValue("lin.codtamanoem"); 
			if(!res || res == ""){
				res = "SIN TAMA�O";
			}
		}  
	}
	return res;

}	
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
