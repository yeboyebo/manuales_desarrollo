/***************************************************************************
                 em_mastervaloresmercado.qs  -  description
                             -------------------
    begin                : vie abr 20 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna { 
	var curS_;
	var pK_;
	function oficial( context ) { interna( context ); } 
	function toolButtonInsert_clicked() {
		return this.ctx.oficial_toolButtonInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.oficial_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.oficial_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.oficial_toolButtonZoom_clicked();
	}
	function curS_bufferCommited() {
		return this.ctx.oficial_curS_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.oficial_refrescaTabla();
	}
	function tableDBRecords_recordChoosed() {
		return this.ctx.oficial_tableDBRecords_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.oficial_accionCursorExterno(accion);
	}	
	function ordenarFilas() {
		return this.ctx.oficial_ordenarFilas();
	}
	function pbnVerArticulo_clicked() {
		return this.ctx.oficial_pbnVerArticulo_clicked();
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}
const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
	var _i = this.iface;

	connect(this.child("toolButtonInsert"), "clicked()", _i, "toolButtonInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");	
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tableDBRecords_recordChoosed");
	connect(this.child("pbnVerArticulo"), "clicked()", _i, "pbnVerArticulo_clicked");

	_i.ordenarFilas();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tableDBRecords_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEdit_clicked();
}
function oficial_toolButtonInsert_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");
}

function oficial_toolButtonEdit_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function oficial_toolButtonDelete_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function oficial_toolButtonZoom_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}
function oficial_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (_i.curS_) {
		disconnect(_i.curS_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curS_, "commited()", _i, "curS_bufferCommited");
		_i.curS_ = undefined;
	}
	
	_i.curS_ = new FLSqlCursor("em_valoresmercado");
	_i.curS_.setAction("em_valoresmercado");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curS_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curS_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");
			_i.curS_.insertRecord();
			break;
		}
		case "edit": {
			connect(_i.curS_, "commited()", _i, "refrescaTabla");
			_i.curS_.editRecord();
			break;
		}
		case "del": {
			//eliminar registro pero de la tabla em_valoresmercado	

			var res = flfactppal.iface.preguntaMsg(sys.translate("El registro activo ser� borrado. �Est� seguro?"),"info",this,MessageBox.Yes, MessageBox.No);  
  			if (res != MessageBox.Yes) {
				return false;
  			}	
			_i.curS_.setModeAccess(_i.curS_.Del);
  			_i.curS_.refreshBuffer();
			if (!_i.curS_.commitBuffer()) {
				return false;
			}			
			this.child("tableDBRecords").refresh();
			break;
		}
		case "browse": {	
			_i.curS_.browseRecord();
			break;
		}
	}
}
function oficial_curS_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	this.child("tableDBRecords").refresh();
	var dtbLC = this.mainWidget().child("tableDBRecords").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);
	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);
	var pos = cursor.atFromBinarySearch("id", _i.pK_, asc);
	cursor.seek(pos);
	cursor.refresh()
}
function oficial_refrescaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.refresh()
}

function oficial_ordenarFilas()
{
    var tdbLC = this.child("tableDBRecords");
    var dtbLC = this.mainWidget().child("tableDBRecords").tableRecords();   

	var hHeader = dtbLC.horizontalHeader();
	hHeader.setClickEnabled(false);
	hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbLC.setSort(["referencia ASC", "em_fechavalmercado ASC"]);  
    dtbLC.refresh(AQS.RefreshData);
}

function oficial_pbnVerArticulo_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var referencia = cursor.valueBuffer("referencia");
	var curArticulo = new FLSqlCursor("articulos");
	curArticulo.setAction("articulos");
	curArticulo.select("referencia = '" + referencia + "'");
	if (!curArticulo.first()) {
		return false;
	}
	connect(curArticulo, "commited()", _i, "refrescaTabla");
	curArticulo.editRecord();

}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////