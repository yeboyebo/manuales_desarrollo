
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends kits {
	var curS_, pK_;
	var filtroMainAnterior_;
	function euromoda( context ) { kits ( context ); }
	function revisarStock(where, mostrarDialogo) {
		return this.ctx.euromoda_revisarStock(where, mostrarDialogo);
	}
	function init() {
		return this.ctx.euromoda_init();
	}
	function ordenaCols() {
		return this.ctx.euromoda_ordenaCols();
	}
	function tbnFiltroEM_clicked() {
		return this.ctx.euromoda_tbnFiltroEM_clicked();
	}
	function tbnQuitarFiltroEM_clicked() {
		return this.ctx.euromoda_tbnQuitarFiltroEM_clicked();
	}
	function toolButtonInsert_clicked() {
		return this.ctx.euromoda_toolButtonInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.euromoda_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.euromoda_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.euromoda_toolButtonZoom_clicked();
	}
	function curS_bufferCommited() {
		return this.ctx.euromoda_curS_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tdbRegStocks_recordChoosed() {
		return this.ctx.euromoda_tdbRegStocks_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function tbnExportarDatos_clicked() {
		return this.ctx.euromoda_tbnExportarDatos_clicked();
	}
	/*function preloadMainFilter() {
		return this.ctx.euromoda_preloadMainFilter();
	}
	function formReady() {
		return this.ctx.euromoda_formReady();
	}
	function tbnfiltroP_clicked() {
		return this.ctx.euromoda_tbnfiltroP_clicked();
	}
	function dameFiltroPrevio(valorF) {
		return this.ctx.euromoda_dameFiltroPrevio(valorF);
	}
	function filtroTabla() {
		return this.ctx.euromoda_filtroTabla();
	}
	function filtrarTabla() {
		return this.ctx.euromoda_filtrarTabla();
	}*/
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_revisarStock(where, mostrarDialogo) {
		return this.revisarStock(where, mostrarDialogo);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_revisarStock(where, mostrarDialogo)
{
	var curStock = new FLSqlCursor("stocks");
	curStock.select(where);
	if (mostrarDialogo) {
		AQUtil.createProgressDialog(sys.translate("Revisando stocks..."), curStock.size());
	}
	var paso:Number = 0;
	var canUltReg:Number;
	while (curStock.next()) {
		if (mostrarDialogo) {
			AQUtil.setProgress(++paso);
		}
		curStock.setModeAccess(curStock.Edit);
		curStock.refreshBuffer();
		curStock.setValueBuffer("fechaultreg", formRecordregstocks.iface.pub_commonCalculateField("fechaultreg", curStock));
		curStock.setValueBuffer("horaultreg", formRecordregstocks.iface.pub_commonCalculateField("horaultreg", curStock));
		canUltReg = formRecordregstocks.iface.pub_commonCalculateField("cantidadultreg", curStock);
		if (!canUltReg || isNaN(canUltReg)) {
			canUltReg = 0;
		}
		curStock.setValueBuffer("cantidadultreg", canUltReg);
		curStock.setValueBuffer("cantidad", formRecordregstocks.iface.pub_commonCalculateField("cantidad", curStock));
		curStock.setValueBuffer("pterecibir", formRecordregstocks.iface.pub_commonCalculateField("pterecibir", curStock));
		curStock.setValueBuffer("prevision", formRecordregstocks.iface.pub_commonCalculateField("prevision", curStock));
		if (!flfactalma.iface.pub_calculaReservasStock(curStock)) {
			return false;
		}
		if (!curStock.commitBuffer()) {
			if (mostrarDialogo) {
				AQUtil.destroyProgressDialog();
			}
			return false;
		}
	}
	if (mostrarDialogo) {
		AQUtil.destroyProgressDialog();
	}
	return true;
}

function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	_i.ordenaCols();
	
	connect(this.child("tbnQuitarFiltroEM"), "clicked()", _i, "tbnQuitarFiltroEM_clicked");
	connect(this.child("tbnFiltroEM"), "clicked()", _i, "tbnFiltroEM_clicked");
	
	var usuario = sys.nameUser();
	if (!(usuario == "infosial" || usuario == "arodriguez" || usuario == "antonio" || usuario == "pozuelo")) {
		if (this.child("tbnEvolStock")) {
			this.child("tbnEvolStock").close();
		}
		if (this.child("tbnRevisarStock")) {
			this.child("tbnRevisarStock").close();
		}
	}

	connect(this.child("toolButtonInsert"), "clicked()", _i, "toolButtonInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");

	
	connect(this.child("tdbRegStocks").cursor(), "recordChoosed()", _i, "tdbRegStocks_recordChoosed");

	debug("******************cursor.action(): "+cursor.action());
	if(cursor.action() != "v_stocksext") {
		if(this.child("tbnExportarDatos")) {
			this.child("tbnExportarDatos").close();
		}
	} else {
		connect(this.child("tbnExportarDatos"), "clicked()", _i, "tbnExportarDatos_clicked");	
	}

	
	/*connect(this.child("tbnFiltroP"), "clicked()", _i, "tbnfiltroP_clicked");
	connect(this, "formReady()", _i, "formReady()");	*/
	
}

function euromoda_tbnFiltroEM_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();
	
	var f = new FLFormSearchDB("em_filtrosarticulos");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);
	curF.setValueBuffer("accion", cursor.action());	
	f.setMainWidget();
	
	var filtroAr = f.exec("filtro");
 debug("filtroAr " + filtroAr);
	if (filtroAr) {
		curF.commitBuffer();
		if (cursor.action() == "regstocks") {
			filtroAr = "stocks.referencia IN (SELECT articulos.referencia FROM articulos WHERE " + filtroAr + ")";
			
		} else if (cursor.action() == "v_stocksext") {
			//filtroAr = "v_stocksext.referencia IN (SELECT v_stocksext.referencia FROM v_stocksext WHERE " + filtroAr + ")";
			//filtroAr = "v_stocksext.referencia IN (SELECT v_stocksext.referencia FROM v_stocksext WHERE " + filtroAr + ")";
			
		}
	} else {
		filtroAr = "";
	}
	debug("filtroAr2 " + filtroAr);
	var filtroAl = curF.valueBuffer("filtroalmacen");
// debug("filtroAl " + filtroAl);
	var filtro = filtroAl;
	if (filtroAr && filtroAr != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += filtroAr;
	}
// debug("Filtro " + filtro);
	if (filtro) {
		curF.commitBuffer();
		cursor.setMainFilter(filtro);
	} else {
		cursor.setMainFilter("");
	}
	debug("Main filter: " +cursor.mainFilter());
	this.child("tdbRegStocks").refresh();
}

function euromoda_tbnQuitarFiltroEM_clicked()
{
	var _i = this.iface;
	this.cursor().setMainFilter("");
	this.child("tdbRegStocks").refresh();
}

function euromoda_ordenaCols()
{
	var cursor = this.cursor();
	
	var oCAncho = [["referencia", 80],["articulo", 250],["codtamanoem", 110],["cantidad", 80], ["reservada", 80], ["disponible", 80], ["pterecibir", 80], ["reservadapterecibir", 80], ["disponiblepterecibir", 80], ["afaltas", 80], ["prevision", 80], ["codalmacen", 60],  ["coddibestamp", 80], ["stockmin", 80], ["stockmax", 80], ["necesidad", 80], ["emcolorgit", 40], ["nombre", 125] , ["codcolorem", 115], ["em_fechaultventaalm", 160], ["em_fechaultcompraalm", 170], ["em_fechaultventa", 160], ["em_fechaultcompra", 170], ["em_fechaultcoste", 170],["em_costeprod", 110],["em_totalcosteprod", 110],["em_margenprod", 120], ["em_fechacosteprod", 115], ["em_horacosteprod", 110], ["em_idusuariocosteprod", 120], ["em_observcosteprod", 170], ["em_fechamargenprod", 120], ["em_horamargenprod", 115], ["em_idusuariomargenprod", 125], ["em_observmargenprod", 175]];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tdbRegStocks").setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
	var oC;
	debug("cursor.action() " + cursor.action());
	switch (cursor.action()) {
		case "stocks": {
			oC = ["referencia", "articulo","codtamanoem", "emcolorgit", "codcolorem", "coddibestamp", "emdibujo", "codbarras", "codalmacen", "nombre", "cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir", "disponiblepterecibir", "afaltas", "prevision", "stockmin", "necesidad"];
			break;
		}
		case "qrystocksval": {
			oC = ["referencia", "articulo", "codtamanoem", "emcolorgit", "codcolorem","codalmacen", "nombre",  "cantidad", "reservada", "disponible","em_costeprod", "em_totalcosteprod", "em_fechacosteprod", "em_horacosteprod","em_margenprod","em_fechamargenprod", "em_horamargenprod", "em_fechaultcompraalm","em_fechaultcompra","em_fechaultcoste", "costemedio", "pvp", "em_fechaultventaalm","em_fechaultventa", "em_valmercado","em_unidmercado", "em_fechavalmercado", "pterecibir", "reservadapterecibir","disponiblepterecibir", "prevision", "afaltas", "stockmin","em_tipoalmacen" ,"em_tipodeposito" ,"necesidad", "coddibestamp", "emdibujo", "enreservapterx","reservadaprod","fechaultreg","horaultreg","cantidadultreg","stockmax","ubicacion","idsincro","fechaultmov","horaultmov","codbarras","em_reservadaoe","codfamilia", "descfamilia", "codsubfamilia", "descsubfamilia", "codcoleccionem", "desccoleccion", "debaja", "fechaliq", "descatalogado","em_controlvalmercado", "em_relalmacen", "em_actalmacen", "em_deposito", "em_duaalmacen", "em_grupoalmacen", "em_tmercaalmacen", "em_caractalmacen", "em_grupoinvent","em_idusuariocosteprod","em_observcosteprod","em_idusuariomargenprod","em_observmargenprod" ];

			break;
		}
		/*case "qrystocksval": {
			oC = ["referencia", "articulo","costemedio", "pvp", "codtamanoem", "emcolorgit", "codcolorem", "codalmacen", "nombre", "cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir","disponiblepterecibir", "prevision", "afaltas", "stockmin", "necesidad", "coddibestamp", "emdibujo"];


			break;
		}*/
	case "qrystocks": {
			oC = ["referencia", "articulo","codtamanoem", "emcolorgit", "codcolorem", "codalmacen", "nombre", "cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir","disponiblepterecibir", "prevision", "afaltas", "stockmin", "em_tipoalmacen", "em_tipodeposito", "necesidad", "coddibestamp", "emdibujo"];			
			break;
		}
	case "v_stocksext": {
			oC = ["referencia", "articulo","codtamanoem", "emcolorgit", "codcolorem", "codalmacen", "nombre", "cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir","disponiblepterecibir", "prevision", "afaltas", "stockmin", "em_tipoalmacen", "em_tipodeposito","necesidad", "em_fechaultventaalm","em_fechaultventa", "em_fechaultcompraalm", "em_fechaultcompra",  "coddibestamp", "emdibujo","reservadaprod","fechaultreg", "horaultreg", "cantidadultreg", "stockmax",  "ubicacion", "idsincro", "fechaultmov", "horaultmov", "codbarras", "codfamilia", "descfam", "codsubfamilia", "descsubfam", "codcoleccionem", "desccol", "debaja","fechaliq", "descatalogado", "aliasart",  "em_relalmacen", "em_actalmacen", "em_deposito", "em_duaalmacen", "em_grupoalmacen", "em_tmercaalmacen","em_caractalmacen","em_grupoinvent"];
			break;
		}
		default: {
			oC = ["referencia", "articulo","codtamanoem", "emcolorgit", "codcolorem", "codalmacen", "nombre", "cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir","disponiblepterecibir", "prevision", "afaltas", "stockmin", "necesidad", "coddibestamp", "emdibujo"];
			break;
		}
	}
	this.child("tdbRegStocks").setOrderCols(oC);
}
function euromoda_tdbRegStocks_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEdit_clicked();
}
function euromoda_toolButtonInsert_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");
}

function euromoda_toolButtonEdit_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDelete_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoom_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}
function euromoda_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (_i.curS_) {
		disconnect(_i.curS_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curS_, "commited()", _i, "curS_bufferCommited");
		_i.curS_ = undefined;
	}
	
	_i.curS_ = new FLSqlCursor("stocks");
	_i.curS_.setAction("stocks");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curS_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curS_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");
			_i.curS_.insertRecord();
			break;
		}
		case "edit": {
			connect(_i.curS_, "commited()", _i, "refrescaTabla");
			_i.curS_.editRecord();
			break;
		}
		case "del": {
			this.child("tdbRegStocks").deleteRecord();
			break;
		}
		case "browse": {	
			_i.curS_.browseRecord();
			break;
		}
	}
}
function euromoda_curS_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	this.child("tdbRegStocks").refresh();
	var dtbLC = this.mainWidget().child("tdbRegStocks").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);
	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);
	var pos = cursor.atFromBinarySearch("referencia", _i.pK_, asc);
	cursor.seek(pos);
	cursor.refresh()
}
function euromoda_refrescaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.refresh()
}

function euromoda_tbnExportarDatos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

  	var mF = this.child("tdbRegStocks").cursor().mainFilter();
  	var fF = this.child("tdbRegStocks").findFilter();
  	var f = this.child("tdbRegStocks").filter();
    var filtro = "";
    if(mF && mF != "") {
    	if(filtro != "") {
    		filtro = filtro  + " AND ";
    	}
    	filtro += mF;
    }

    if(fF && fF != "") {
    	if(filtro != "") {
    		filtro = filtro + " AND ";
    	}
    	filtro += fF;
    }

    if(f && f != "") {
    	if(filtro != "") {
    		filtro = filtro + " AND ";
    	}
    	filtro += f;
    }
	if(!formalbaranescli.iface.exportarDatosCSV(cursor, filtro)){
		return false;
	}
	return true;

}

/*function euromoda_preloadMainFilter()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (!cursor.mainFilter().toString().isEmpty()){
		_i.filtroMainAnterior_ = cursor.mainFilter();
	}
	else{
		_i.filtroMainAnterior_ = "";
	}	
	return "1 = 2";
}

function euromoda_formReady()
{
	var _i = this.iface;
	try {
		_i.__formReady();
	} catch (e) {}
	
	this.child("ledFiltroP").setFocus();
}

function euromoda_tbnfiltroP_clicked()
{
	var _i = this.iface;
	
	var valorF = this.child("ledFiltroP").text;
	var t = this.child("tdbRegStocks");
	_i.filtrarTabla();
	
	//if (!valorF || valorF == "") {
	//	t.setFindHidden(false);
	//}
	
	t.refresh();
}

function euromoda_filtroTabla()
{
	var _i = this.iface;
	var t = this.child("tdbRegStocks");
	var valorF = this.child("ledFiltroP").text;
	
	var filtroP = "";
	if (valorF && valorF != "") {
		valorF = valorF.toString().toUpperCase();
		filtroP =_i.dameFiltroPrevio(valorF); 
	}
	var filtro;
	try {
		filtro = _i.__filtroTabla();
	} catch (e) {
		filtro = "";
	}
	if (filtroP != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += filtroP;
	} 
	if (_i.filtroMainAnterior_ != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += _i.filtroMainAnterior_;
	}
	
	return filtro;
}

function euromoda_dameFiltroPrevio(valorF)
{
	var filtro = "";
	
	if(this.cursor().action() == "v_stocksext") {
		filtro = "(UPPER(v_stocksext.codalmacen) LIKE '%" + valorF + "%' OR UPPER(v_stocksext.articulo) LIKE '%" + valorF + "%' OR UPPER(v_stocksext.referencia) LIKE '%" + valorF + "%'";
	} else {
		filtro = "(UPPER(stocks.codalmacen) LIKE '%" + valorF + "%' OR UPPER(stocks.articulo) LIKE '%" + valorF + "%' OR UPPER(stocks.referencia) LIKE '%" + valorF + "%'";
	}
	filtro += ")";
	return filtro;
}

function euromoda_filtrarTabla()
{
	var _i = this.iface;
	var filtro = _i.filtroTabla();
  	var cur = this.cursor();
  	if (filtro != cur.mainFilter()) {
    	cur.setMainFilter(filtro);
	}
  return true;
}*/
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
