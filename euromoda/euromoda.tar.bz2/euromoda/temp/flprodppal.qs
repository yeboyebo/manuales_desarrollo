
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var alturaFila_ = 50;
	var filaVacia_;
	function euromoda( context ) { oficial ( context ); }
	function afterCommit_pr_ordenesproduccion(curOP) {
		return this.ctx.euromoda_afterCommit_pr_ordenesproduccion(curOP);
	}
	function controlConfeccionistaOP(curOP) {
		return this.ctx.euromoda_controlConfeccionistaOP(curOP);
	}
	function lanzaInventarioConf(codConfec) {
		return this.ctx.euromoda_lanzaInventarioConf(codConfec);
	}
	function obtenerParamInventarioConf(codAlmacen) {
		return this.ctx.euromoda_obtenerParamInventarioConf(codAlmacen);
	}
	function beforeCommit_pr_ordenesproduccion(curOP) {
    return this.ctx.euromoda_beforeCommit_pr_ordenesproduccion(curOP);
  }
  function controlOrdenPreMat(curOP) {
    return this.ctx.euromoda_controlOrdenPreMat(curOP);
  }
  function medidaTablaProd(nM) {
    return this.ctx.euromoda_medidaTablaProd(nM);
  }
  function formatoTablaProd(dtb) {
    return this.ctx.euromoda_formatoTablaProd(dtb);
  }
  function excelColaProd(codgruposeccion, ampliada) {
  	return this.ctx.euromoda_excelColaProd(codSeccion, ampliada);
  }
	function calcularDatosColaProd(oParamExcel) {
		return this.ctx.euromoda_calcularDatosColaProd(oParamExcel);
	}
	function exportarColaProdExcel(oParam, ampliada) {
		return this.ctx.euromoda_exportarColaProdExcel(oParam, ampliada);
	}
	function calcularDatosColaProdAmp(oParamExcel) {
		return this.ctx.euromoda_calcularDatosColaProdAmp(oParamExcel);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB_EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_lanzaInventarioConf(codConfec) {
		return this.lanzaInventarioConf(codConfec);
	}
	function pub_medidaTablaProd() {
		return this.medidaTablaProd();
	}
	function pub_formatoTablaProd(dtb) {
		return this.formatoTablaProd(dtb);
	}
	function pub_excelColaProd(codSeccion, ampliada) {
		return this.excelColaProd(codSeccion, ampliada);
	}
}
//// PUB_EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_afterCommit_pr_ordenesproduccion(curOP)
{
  var _i = this.iface;
  if (!_i.controlConfeccionistaOP(curOP)) {
    return false;
  }
  return true;
}

function euromoda_beforeCommit_pr_ordenesproduccion(curOP)
{
  var _i = this.iface;
  if (!_i.controlOrdenPreMat(curOP)) {
    return false;
  }

	if (curOP.modeAccess() == curOP.Insert || (curOP.modeAccess() == curOP.Edit && curOP.valueBuffer("fechaentrega") != curOP.valueBufferCopy("fechaentrega"))) {		
		if (!flfactppal.iface.pub_controlDatosMod(curOP)) {
			return false;
		}
	}

  return true;
}

function euromoda_controlOrdenPreMat(curOP)
{
	var _i = this.iface;
	if (curOP.modeAccess() != curOP.Edit) {
		return true;
	}
	var codPreparaMat = curOP.valueBuffer("codpreparamat");
	if (codPreparaMat && codPreparaMat != "" && codPreparaMat != curOP.valueBufferCopy("codpreparamat")) {
		var oPM = AQUtil.sqlSelect("pr_ordenesproduccion", "MAX(ordenpremat)", "codpreparamat = '" + codPreparaMat + "'");
		oPM = isNaN(oPM) ? 0 : oPM;
		oPM = parseFloat(oPM) + 1;
		curOP.setValueBuffer("ordenpremat", oPM);
	} else {
		if (!codPreparaMat || codPreparaMat == "") {
			curOP.setNull("ordenpremat");
		}
	}
  return true;
}

function euromoda_controlConfeccionistaOP(curOP)
{
  var _i = this.iface;
  if (curOP.modeAccess() != curOP.Edit) {
    return true;
  }
  var codConfec = curOP.valueBuffer("codconfeccionista");
  if (codConfec == curOP.valueBufferCopy("codconfeccionista")) {
    return true;
  }
  /// Cambia los movimientos pendientes de los lotes de la orden al stock del almac�n del confeccionista
  var codAlmaCon;
  if (!codConfec || codConfec == "") {
    codAlmaCon = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
  } else {
    codAlmaCon = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codConfec + "'");
  }
  if (!codAlmaCon) {
    MessageBox.warning(sys.translate("El confeccionista %1 no tiene almac�n asociado").arg(codConfec), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  var codOrden = curOP.valueBuffer("codorden");
  var qLote = new FLSqlQuery;
  qLote.setSelect("codlote");
  qLote.setFrom("lotesstock");
  qLote.setWhere("codordenproduccion = '" + codOrden + "'");
  qLote.setForwardOnly(true);
  if (!qLote.exec()) {
    return false;
  }
  var codFamEstampado = flfactalma.iface.pub_dameFamEstampado();
  var codLote, referencia, idStock, idStockCon;
  var oArticulo = new Object;
  var curMoviStock = new FLSqlCursor("movistock");
  while (qLote.next()) {
    codLote = qLote.value("codlote");
    curMoviStock.select("codloteprod = '" + codLote + "' AND estado = 'PTE'");
    while (curMoviStock.next()) {
      curMoviStock.setModeAccess(curMoviStock.Edit);
      curMoviStock.refreshBuffer();
      referencia = curMoviStock.valueBuffer("referencia");
      if (AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'") == codFamEstampado) {
        continue;
      }
      oArticulo.referencia = referencia;
      oArticulo.localizador = "referencia = '" + referencia + "'";
      idStock = curMoviStock.valueBuffer("idstock");
      idStockCon = flfactalma.iface.dameIdStock(codAlmaCon, oArticulo);
      if (!idStockCon) {
        return false;
      }
      curMoviStock.setValueBuffer("idstock", idStockCon);
      if (!curMoviStock.commitBuffer()) {
        return false;
      }
      if (!flfactalma.iface.actualizarStockPteServir(idStock)) {
        return false;
      }
      if (!flfactalma.iface.actualizarStockPteServir(idStockCon)) {
        return false;
      }
    }
  }
  return true;
}

function euromoda_lanzaInventarioConf(codConfec)
{
	var _i = this.iface;
	var codAlmacen = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codConfec + "'");
	if (!codAlmacen) {
		MessageBox.warning(sys.translate("El confeccionista %1 no tiene almac�n asociado").arg(codConfec), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var curI = new FLSqlCursor("i_inventario");
	curI.setModeAccess(curI.Insert);
	curI.refreshBuffer();
	curI.setValueBuffer("descripcion", "Temp");
	curI.setValueBuffer("i_almacenes_codalmacen", codAlmacen);
	
	var pI = _i.obtenerParamInventarioConf(codAlmacen);
	if (!pI) {
		return;
	}

	flfactinfo.iface.pub_lanzaInforme(curI, pI);
}

function euromoda_obtenerParamInventarioConf(codAlmacen)
{
	var paramInforme = flfactinfo.iface.pub_dameParamInforme();
	paramInforme.nombreInforme = "i_em_inventario_nec_con";
	var listaFamEstampado = flfactalma.iface.pub_dameFamEstampado();
	var listaFamCrudo = flfactalma.iface.pub_dameFamCrudo();
	paramInforme.whereFijo = "(stocks.cantidad - (stocks.reservada + stocks.reservadapterecibir + stocks.afaltas)) < 0 AND articulos.codfamilia NOT IN (" + listaFamEstampado + ") AND articulos.codfamilia NOT IN (" + listaFamCrudo+ ")";
	paramInforme.orderBy = "almacenes.codalmacen, articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion";
	
	return paramInforme;
}

function euromoda_medidaTablaProd(nM)
{
	var m;
	switch (nM) {
		case "altoFilas": {
			m = 50;
			break;
		}
		case "anchoScroll": {
			m = 25;
			break;
		}
	}
	return m;
}

function euromoda_formatoTablaProd(dtb)
{
	var _i = this.iface;
	
	if (!dtb) {
		return;
	}
	dtb.defaultRowHeight = _i.medidaTablaProd("altoFilas");
	dtb.setNumRows(0);
  dtb.setNumRows(dtb.numRows());
	
	dtb.setLeftMargin(0);
  dtb.verticalHeader().hide();
	
	dtb.verticalScrollBar().minimumWidth = _i.medidaTablaProd("anchoScroll");
  dtb.horizontalScrollBar().minimumWidth = _i.medidaTablaProd("anchoScroll");

}

function euromoda_excelColaProd(codSeccion, ampliada)
{
	var _i = this.iface;
	var oParamExcel;
	if(ampliada) {
		oParamExcel = fleumoesta.iface.dameParamExcelCola("Prev_colaprod_amp");
	} else {
		oParamExcel  = fleumoesta.iface.dameParamExcelCola("Prev_colaprod");
	}
	oParamExcel["codseccion"] = codSeccion;
	if(ampliada) {
		_i.calcularDatosColaProdAmp(oParamExcel);
	} else {
		_i.calcularDatosColaProd(oParamExcel);
	}
	
	_i.exportarColaProdExcel(oParamExcel, ampliada);
	fleumoesta.iface.abreExcel(oParamExcel);
}

function euromoda_calcularDatosColaProd(oParamExcel)
{
	var _i = this.iface;
	
	var i=0;
	
	_i.filaVacia_ = ["","","","","","","","","","","'"];
	oParamExcel.array = [];
	oParamExcel.nombreColumnas = [];
	oParamExcel.tipoColumna = [];
	oParamExcel.colasProd = [];

	var  where = "1 = 1";
	if ("codseccion" in oParamExcel) {
		where = "codseccion = '" + oParamExcel.codseccion + "'";
	}
	var q = new AQSqlQuery;	
	q.setSelect("codmaquinacol");
	q.setFrom("em_maquinascol");		
	q.setWhere(where + " ORDER BY codmaquinacol"); 		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var arrayFilas = [];
		var codMaquina = q.value("codmaquinacol");
		oParamExcel.colasProd[i] = codMaquina;		
		var qC = new AQSqlQuery;	
		qC.setSelect("pr_ordenesproduccion.fecha, pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.em_codmodooper, pr_ordenesproduccion.codorden, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.udsptes,pr_ordenesproduccion.metrosptes, pr_ordenesproduccion.em_horasbrutascola, pr_ordenesproduccion.em_fechafinprev, pr_ordenesproduccion.em_horafinprev,subfamilias.descripcion,pr_ordenesproduccion.em_horasdia, pr_ordenesproduccion.em_ordenprod, pr_ordenesproduccion.em_paralizada, pr_ordenesproduccion.em_motivopara");		
		qC.setFrom("pr_ordenesproduccion INNER JOIN subfamilias ON pr_ordenesproduccion.codsubfamilia=subfamilias.codsubfamilia");
		qC.setWhere(formem_colaproduccion.iface.dameFiltroCola(codMaquina) + " ORDER BY " + formem_colaproduccion.iface.dameOrderByCola());

		if (!qC.exec()){
			return;
		}  
		while(qC.next())
		{
			

			var codOrden = qC.value("pr_ordenesproduccion.codorden");
			var udPdt = qC.value("pr_ordenesproduccion.udsptes");
			var canPte = qC.value("pr_ordenesproduccion.metrosptes");
			var codModOp = qC.value("pr_ordenesproduccion.em_codmodooper");
			var fecha = qC.value("pr_ordenesproduccion.fecha");
			var horasBrutasEst = qC.value("pr_ordenesproduccion.em_horasbrutascola");
			var fechaFinPrev = qC.value("pr_ordenesproduccion.em_fechafinprev");
			var horaFinPrev = qC.value("pr_ordenesproduccion.em_horafinprev");
			var descSubfam = qC.value("subfamilias.descripcion");
			var horasDia = qC.value("pr_ordenesproduccion.em_horasdia");

			var paralizada = qC.value("pr_ordenesproduccion.em_paralizada");
			if(paralizada) {
				paralizada = "SI";
			} else {
				paralizada = "NO";
			}
			var motivoParaliza = qC.value("pr_ordenesproduccion.em_motivopara");

			var descripcion = formem_colaproduccion.iface.dameDescripcionOrden(qC);
			fecha = AQUtil.dateAMDtoDMA(fecha);
			fecha = fecha.toString();
	
			//descripcion = descOrden;
		
			if(horasBrutasEst.left(1) == "0") {
				horasBrutasEst = horasBrutasEst.right(9);				
			}
			if(horasBrutasEst.left(1) == "0")  {
				horasBrutasEst = horasBrutasEst.right(8);				
			}
			
			if(fechaFinPrev && fechaFinPrev != "" && 	horaFinPrev && horaFinPrev != "") {		
				fechaFinPrev = new Date(Date.parse(fechaFinPrev.toString().left(10)+horaFinPrev.toString().right(9)));		
				fechaFinPrev = AQUtil.dateAMDtoDMA(fechaFinPrev)+" "+horaFinPrev.toString().right(8);		
			}

			arrayFilas.push([descripcion ,codOrden, udPdt ,canPte ,codModOp ,descSubfam, horasBrutasEst ,fechaFinPrev, paralizada,motivoParaliza, " " ]);
		}	
		if (i==0) {
			oParamExcel.array = arrayFilas;			
		} else {
			if(oParamExcel.array.length > arrayFilas.length) {
				for(var k = 0; k < oParamExcel.array.length; k++) {

					if(k < arrayFilas.length) {
						oParamExcel.array[k] = oParamExcel.array[k].concat(arrayFilas[k]);					  	
					}else {
						oParamExcel.array[k] = oParamExcel.array[k].concat(_i.filaVacia_);					  	
					}
					
				}				      
							
				
			}else {
				for(var k = 0; k < arrayFilas.length; k++) {
				     
					if(k < oParamExcel.array.length) {

						oParamExcel.array[k] = oParamExcel.array[k].concat(arrayFilas[k]);
					} else{						
					  	var numCols = _i.filaVacia_.length;
						oParamExcel.array.push(_i.filaVacia_);
					  	while(oParamExcel.array[k].length < numCols*(i)) {
					  		oParamExcel.array[k] = oParamExcel.array[k].concat(_i.filaVacia_);	
					  	}
					    oParamExcel.array[k] = oParamExcel.array[k].concat(arrayFilas[k]);
					    
					}				
					
				}
			}
		}
		oParamExcel.nombreColumnas.push("Descripci�n");		
		oParamExcel.nombreColumnas.push("N�Orden");
		oParamExcel.nombreColumnas.push("Unidades pendientes");
		oParamExcel.nombreColumnas.push("Metros pendientes");
		oParamExcel.nombreColumnas.push("Modo operaci�n");
		oParamExcel.nombreColumnas.push("Subfamilia");
		oParamExcel.nombreColumnas.push("Horas brutas");
		oParamExcel.nombreColumnas.push("Fecha fin prevista");		
		oParamExcel.nombreColumnas.push("Paralizada");
		oParamExcel.nombreColumnas.push("M.Paralizada");
		oParamExcel.nombreColumnas.push("");

		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");

		i++;
	}
	var aTotales = [];
	var aVacias = [];
	for(d=0; d< oParamExcel.colasProd.length; d++) {
		var maquinaStr = "";
		var codMaquina = oParamExcel.colasProd[d];		
		var where = formem_colaproduccion.iface.dameFiltroCola(codMaquina);
			
		var cantPte = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(udsptes)", where);	
		
		var metrtPte = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(metrosptes)", where);	

		maquinaStr = "TOTAL: " + codMaquina;
		debug("////////////// maquinaStr:"+maquinaStr+"  cantPte:"+cantPte+" metrtPte"+metrtPte);
		if(aTotales.length == 0) {
			
			aTotales.push(["",maquinaStr,cantPte,metrtPte,"","","","","",""," "]);
			aVacias.push(_i.filaVacia_);

		} else {
			
			aTotales[0] = aTotales[0].concat(["",maquinaStr,cantPte,metrtPte,"","","","","","","'"]);
			aVacias[0] = aVacias[0].concat(_i.filaVacia_);

		}
	}

	oParamExcel.array.push(aVacias[0]);
	oParamExcel.array.push(aVacias[0]);
	oParamExcel.array.push(aVacias[0]);
	oParamExcel.array.push(aTotales[0]);

	//Ahora la tabla de tejido confirmado y tejido pendiente de confirmar
	var arrayFilasTC = [];
	var qTC = new AQSqlQuery;
	qTC.setSelect("pr_ordenesproduccion.codorden,pr_ordenesproduccion.fecha, pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.totaluds,pr_ordenesproduccion.totalmetros,pr_ordenesproduccion.em_codmodooper, pr_ordenesproduccion.codsubfamilia,pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.em_codgruposeccion, pr_ordenesproduccion.em_paralizada, pr_ordenesproduccion.em_motivopara");
	qTC.setFrom("pr_ordenesproduccion");
	qTC.setWhere(formem_colaproduccion.iface.dameFiltroConfirmado());
	qTC.setOrderBy(formem_colaproduccion.iface.dameOrderByConfirmado());	
	if (!qTC.exec()){
		debug("///////////no se ejecuta consulta");
		return;
	}  
	while(qTC.next())
	{
		var codOrden = 	qTC.value("pr_ordenesproduccion.codorden");
		
		var uds = qTC.value("pr_ordenesproduccion.totaluds");
		
		var metros = qTC.value("pr_ordenesproduccion.totalmetros");
		var codModOp = qTC.value("pr_ordenesproduccion.em_codmodooper");		
		var descSubfam = qTC.value("pr_ordenesproduccion.subfamilia");

		var descripcion = formem_colaproduccion.iface.dameDescripcionOrden(qTC);

		var paralizada = qTC.value("pr_ordenesproduccion.em_paralizada");
		if(paralizada) {
			paralizada = "SI";
		} else {
			paralizada = "NO";
		}
		var motivoParaliza = qTC.value("pr_ordenesproduccion.em_motivopara");

		arrayFilasTC.push([descripcion ,codOrden, uds ,metros ,codModOp ,descSubfam, paralizada,motivoParaliza, "" ,"", "'" ]);
	}

	var arrayFilasTPC = [];
	var qTPC = new AQSqlQuery;

	qTPC.setSelect("pr_ordenesproduccion.codorden,pr_ordenesproduccion.fecha, pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.totaluds,pr_ordenesproduccion.totalmetros,pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.codsubfamilia,pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.em_codgruposeccion, pr_ordenesproduccion.em_paralizada, pr_ordenesproduccion.em_motivopara");
	qTPC.setFrom("pr_ordenesproduccion");
	qTPC.setWhere(formem_colaproduccion.iface.dameFiltroPteConfirmar());
	qTPC.setOrderBy(formem_colaproduccion.iface.dameOrderByPteConfirmar());	
	if (!qTPC.exec()){
		return;
	}  
	while(qTPC.next())
	{
		var codOrden = qTPC.value("pr_ordenesproduccion.codorden");
		var uds = qTPC.value("pr_ordenesproduccion.totaluds");
		var metros = qTPC.value("pr_ordenesproduccion.totalmetros");
		var codModOp = qTPC.value("pr_ordenesproduccion.em_codmodooper");		
		var descSubfam = qTPC.value("pr_ordenesproduccion.subfamilia");

		var descripcion = formem_colaproduccion.iface.dameDescripcionOrden(qTPC);

		var paralizada = qTPC.value("pr_ordenesproduccion.em_paralizada");
		if(paralizada) {
			paralizada = "SI";
		} else {
			paralizada = "NO";
		}
		var motivoParaliza = qTPC.value("pr_ordenesproduccion.em_motivopara");
		
		arrayFilasTPC.push([descripcion ,codOrden, uds ,metros ,codModOp ,descSubfam, paralizada, motivoParaliza, "" ,"", "'" ]);
	}	
	var aCabTejidos = [""];
	
	var aVaciasTej = [];
	oParamExcel.arrayTej = [];
	  
	oParamExcel.tipoColumnaTej = [];
	oParamExcel.nombreColumnasTej = [];
	oParamExcel.titulosTej = [];

	for (var i=0 ; i<2; i++) {
	     if(i==0) {
			aVaciasTej.push(_i.filaVacia_);
			oParamExcel.nombreColumnasTej.push("Descripci�n");
		} else {
			aVaciasTej[0] = aVaciasTej[0].concat(_i.filaVacia_);
			oParamExcel.nombreColumnasTej.push("Descripci�n");
		}
		oParamExcel.nombreColumnasTej.push("N�Orden");
		oParamExcel.nombreColumnasTej.push("Unidades");
		oParamExcel.nombreColumnasTej.push("Metros");
		oParamExcel.nombreColumnasTej.push("Modo operaci�n");
		oParamExcel.nombreColumnasTej.push("Subfamilia");
		oParamExcel.nombreColumnasTej.push("Paralizada");
		oParamExcel.nombreColumnasTej.push("M.Paralizada");	
		oParamExcel.nombreColumnasTej.push("");
		oParamExcel.nombreColumnasTej.push("");		
		oParamExcel.nombreColumnasTej.push("");


		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");			

		oParamExcel.tipoColumnaTej.push("double");
		oParamExcel.tipoColumnaTej.push("double");

		oParamExcel.tipoColumnaTej.push("string");		
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");


	}
	
	oParamExcel.titulosTej = ["ORDENES CONFIRMADAS","ORDENES PENDIENTES DE CONFIRMAR"];	

	if(arrayFilasTC.length != 0) {
	     oParamExcel.arrayTej = arrayFilasTC;
	}


	if(oParamExcel.arrayTej.length > arrayFilasTPC.length) {
		for(var k = 0; k < oParamExcel.arrayTej.length; k++) {

			if(k < arrayFilasTPC.length) {
				oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(arrayFilasTPC[k]);					  	
			}else {
				oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(_i.filaVacia_);					  	
			}			
		}			
	}else {
		for(var k = 0; k < arrayFilasTPC.length; k++) {
		     
			if(k < oParamExcel.arrayTej.length) {

				oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(arrayFilasTPC[k]);
			} else{						
			  	var numCols = _i.filaVacia_.length;
				oParamExcel.arrayTej.push(_i.filaVacia_);
			  	while(oParamExcel.arrayTej[k].length < numCols) {
			  		oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(_i.filaVacia_);	
			  	}
			    oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(arrayFilasTPC[k]);			    
			}				
			
		}
	}


	//totales tejido confirmado y tejido pte de confirmar
	var cantTC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totaluds)", formem_colaproduccion.iface.dameFiltroConfirmado());
	var cantMTC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totalmetros)", formem_colaproduccion.iface.dameFiltroConfirmado());
	
		
	var cantTPC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totaluds)", formem_colaproduccion.iface.dameFiltroPteConfirmar());
	var cantMTPC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totalmetros)", formem_colaproduccion.iface.dameFiltroPteConfirmar());	

	
	var aTotalesTej = [];
	var aVaciasTej = [];

	aTotalesTej.push(["","TOTAL CONFIRMADOS:",cantTC,cantMTC,"","","","","","",""]);
	aVaciasTej.push(_i.filaVacia_);
		
	if(aTotalesTej.length == 0) {
		aTotalesTej.push(["","TOTAL POR CONFIRMAR:",cantPC,cantMTPC,"","","","","","",""]);
		
		aVaciasTej.push(_i.filaVacia_);
	} else {
		aTotalesTej[0] = aTotalesTej[0].concat(["","TOTAL POR CONFIRMAR:",cantTPC,cantMTPC,"","","","","","",""]);
		
		aVaciasTej[0] = aVaciasTej[0].concat(_i.filaVacia_);
	}

	
	oParamExcel.arrayTej.push(aVaciasTej[0]);
	oParamExcel.arrayTej.push(aVaciasTej[0]);
	oParamExcel.arrayTej.push(aVaciasTej[0]);
	oParamExcel.arrayTej.push(aTotalesTej[0]);



}

function euromoda_calcularDatosColaProdAmp(oParamExcel)
{
	var _i = this.iface;
	
	var i=0;
	_i.filaVacia_ = ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","'"];

	oParamExcel.array = [];
	oParamExcel.nombreColumnas = [];
	oParamExcel.tipoColumna = [];
	oParamExcel.colasProd = [];

	var  where = "1 = 1";
	if ("codseccion" in oParamExcel) {
		where = "codseccion = '" + oParamExcel.codseccion + "'";
	}
	var q = new AQSqlQuery;	
	q.setSelect("codmaquinacol");
	q.setFrom("em_maquinascol");		
	q.setWhere(where + " ORDER BY codmaquinacol"); 		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var arrayFilas = [];
		var codMaquina = q.value("codmaquinacol");
		oParamExcel.colasProd[i] = codMaquina;		
		var qC = new AQSqlQuery;	

		qC.setSelect("pr_ordenesproduccion.fecha, pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.em_codmodooper, pr_ordenesproduccion.codorden, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.udsptes,pr_ordenesproduccion.metrosptes, pr_ordenesproduccion.em_horasbrutascola, pr_ordenesproduccion.em_fechafinprev, pr_ordenesproduccion.em_horafinprev,subfamilias.descripcion,pr_ordenesproduccion.em_horasdia, pr_ordenesproduccion.em_ordenprod,pr_ordenesproduccion.em_codgruposeccion,pr_ordenesproduccion.em_acabados,pr_ordenesproduccion.em_alias,pr_ordenesproduccion.em_anverso,pr_ordenesproduccion.em_reverso,pr_ordenesproduccion.em_retardototal,pr_ordenesproduccion.em_retardoacu,pr_ordenesproduccion.em_retardoacabado,pr_ordenesproduccion.em_retardotipotejido,pr_ordenesproduccion.em_retardoanverso,pr_ordenesproduccion.em_retardoreverso, pr_ordenesproduccion.em_colordibujo, pr_ordenesproduccion.em_anchotejido, pr_ordenesproduccion.em_colorreverso, pr_ordenesproduccion.em_gramaje, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.em_paralizada, pr_ordenesproduccion.em_motivopara");		
		qC.setFrom("pr_ordenesproduccion INNER JOIN subfamilias ON pr_ordenesproduccion.codsubfamilia=subfamilias.codsubfamilia");
		qC.setWhere(formem_colaproduccion.iface.dameFiltroCola(codMaquina) + " ORDER BY " + formem_colaproduccion.iface.dameOrderByCola());

		if (!qC.exec()){
			return;
		}  
		while(qC.next())
		{
			

			var codOrden = qC.value("pr_ordenesproduccion.codorden");
			var udPdt = qC.value("pr_ordenesproduccion.udsptes");
			var canPte = qC.value("pr_ordenesproduccion.metrosptes");
			var codModOp = qC.value("pr_ordenesproduccion.em_codmodooper");
			var fecha = qC.value("pr_ordenesproduccion.fecha");
			var horasBrutasEst = qC.value("pr_ordenesproduccion.em_horasbrutascola");
			var fechaFinPrev = qC.value("pr_ordenesproduccion.em_fechafinprev");
			var horaFinPrev = qC.value("pr_ordenesproduccion.em_horafinprev");
			var descSubfam = qC.value("subfamilias.descripcion");
			var horasDia = qC.value("pr_ordenesproduccion.em_horasdia");
			var retardoAcu =qC.value("pr_ordenesproduccion.em_retardoacu");
			if(!retardoAcu || retardoAcu == "") {
				retardoAcu = 0;
			}

			var descripcion = formem_colaproduccion.iface.dameDescripcionOrden(qC);
			fecha = AQUtil.dateAMDtoDMA(fecha);
			fecha = fecha.toString();
	
			//descripcion = descOrden;
		
			if(horasBrutasEst.left(1) == "0") {
				horasBrutasEst = horasBrutasEst.right(9);				
			}
			if(horasBrutasEst.left(1) == "0")  {
				horasBrutasEst = horasBrutasEst.right(8);				
			}
			
			if(fechaFinPrev && fechaFinPrev != "" && 	horaFinPrev && horaFinPrev != "") {		
				fechaFinPrev = new Date(Date.parse(fechaFinPrev.toString().left(10)+horaFinPrev.toString().right(9)));		
				fechaFinPrev = AQUtil.dateAMDtoDMA(fechaFinPrev)+" "+horaFinPrev.toString().right(8);		
			}
			var paralizada = qC.value("pr_ordenesproduccion.em_paralizada");
			if(paralizada) {
				paralizada = "SI";
			} else {
				paralizada = "NO";
			}
			var motivoParaliza = qC.value("pr_ordenesproduccion.em_motivopara");

			arrayFilas.push([descripcion ,qC.value("pr_ordenesproduccion.dibujo"), codOrden, AQUtil.dateAMDtoDMA(qC.value("pr_ordenesproduccion.fechaentrega")), udPdt ,canPte,qC.value("pr_ordenesproduccion.em_codgruposeccion"),qC.value("pr_ordenesproduccion.em_acabados") ,descSubfam,qC.value("pr_ordenesproduccion.em_alias"),qC.value("pr_ordenesproduccion.em_gramaje"),fechaFinPrev,codModOp ,qC.value("pr_ordenesproduccion.em_anchotejido"),retardoAcu,qC.value("pr_ordenesproduccion.em_retardototal"),qC.value("pr_ordenesproduccion.em_retardoacabado"),qC.value("pr_ordenesproduccion.em_retardotipotejido"),qC.value("pr_ordenesproduccion.em_retardoanverso"),qC.value("pr_ordenesproduccion.em_retardoreverso"),qC.value("pr_ordenesproduccion.em_anverso"),qC.value("pr_ordenesproduccion.em_reverso"),qC.value("pr_ordenesproduccion.em_colordibujo"),qC.value("pr_ordenesproduccion.em_colorreverso") ,qC.value("pr_ordenesproduccion.em_horasdia"), horasBrutasEst, paralizada, motivoParaliza," " ]);
		}	
		if (i==0) {
			oParamExcel.array = arrayFilas;			
		} else {
			if(oParamExcel.array.length > arrayFilas.length) {
				for(var k = 0; k < oParamExcel.array.length; k++) {

					if(k < arrayFilas.length) {
						oParamExcel.array[k] = oParamExcel.array[k].concat(arrayFilas[k]);					  	
					}else {
						oParamExcel.array[k] = oParamExcel.array[k].concat(_i.filaVacia_);					  	
					}
					
				}				      
							
				
			}else {
				for(var k = 0; k < arrayFilas.length; k++) {
				     
					if(k < oParamExcel.array.length) {

						oParamExcel.array[k] = oParamExcel.array[k].concat(arrayFilas[k]);
					} else{						
					  	var numCols = _i.filaVacia_.length;
						oParamExcel.array.push(_i.filaVacia_);
					  	while(oParamExcel.array[k].length < numCols*(i)) {
					  		oParamExcel.array[k] = oParamExcel.array[k].concat(_i.filaVacia_);	
					  	}
					    oParamExcel.array[k] = oParamExcel.array[k].concat(arrayFilas[k]);
					    
					}				
					
				}
			}
		}
		oParamExcel.nombreColumnas.push("Descripci�n");	
		oParamExcel.nombreColumnas.push("Dibujo anverso");	
		oParamExcel.nombreColumnas.push("N�Orden");
		oParamExcel.nombreColumnas.push("F.Entrega");
		oParamExcel.nombreColumnas.push("Unidades pendientes");
		oParamExcel.nombreColumnas.push("Metros pendientes");
		oParamExcel.nombreColumnas.push("Agrupaci�n");
		oParamExcel.nombreColumnas.push("Acabados");
		oParamExcel.nombreColumnas.push("Subfamilia");
		oParamExcel.nombreColumnas.push("Alias");
		oParamExcel.nombreColumnas.push("Gramaje");
		oParamExcel.nombreColumnas.push("Fecha fin prevista");	
		oParamExcel.nombreColumnas.push("Modo operaci�n");
		oParamExcel.nombreColumnas.push("Ancho tejido");
		oParamExcel.nombreColumnas.push("Retardo acumulado");
		oParamExcel.nombreColumnas.push("Retardo total");		
		oParamExcel.nombreColumnas.push("Retardo acabado");
		oParamExcel.nombreColumnas.push("Retardo tipo tejido");
		oParamExcel.nombreColumnas.push("Retardo anverso");
		oParamExcel.nombreColumnas.push("Retardo reverso");
		oParamExcel.nombreColumnas.push("Anverso");
		oParamExcel.nombreColumnas.push("Reverso");
		oParamExcel.nombreColumnas.push("Color dibujo");
		
		oParamExcel.nombreColumnas.push("Color reverso");
		oParamExcel.nombreColumnas.push("Horas d�a");
		oParamExcel.nombreColumnas.push("Horas brutas");
		oParamExcel.nombreColumnas.push("Paralizada");
		oParamExcel.nombreColumnas.push("M.Paralizada");
		oParamExcel.nombreColumnas.push("");

		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("string");		
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("double");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");
		oParamExcel.tipoColumna.push("string");

		i++;
	}
	var aTotales = [];
	var aVacias = [];
	for(d=0; d< oParamExcel.colasProd.length; d++) {
		var maquinaStr = "";
		var codMaquina = oParamExcel.colasProd[d];		
		var where = formem_colaproduccion.iface.dameFiltroCola(codMaquina);
			
		var cantPte = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(udsptes)", where);	
		
		var metrtPte = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(metrosptes)", where);	

		maquinaStr = "TOTAL: " + codMaquina;
		debug("////////////// maquinaStr:"+maquinaStr+"  cantPte:"+cantPte+" metrtPte"+metrtPte);
		if(aTotales.length == 0) {
			aTotales.push(["","",maquinaStr,"",cantPte,metrtPte,"","","","","","","","","","","","","","","","","","","","","","",""," "]);
			aVacias.push(_i.filaVacia_);

		} else {
			aTotales[0] = aTotales[0].concat(["",maquinaStr,"",cantPte,metrtPte,"","","","","","","","","","","","","","","","","","","","","","","","","'"]);
			aVacias[0] = aVacias[0].concat(_i.filaVacia_);

		}
	}

	oParamExcel.array.push(aVacias[0]);
	oParamExcel.array.push(aVacias[0]);
	oParamExcel.array.push(aVacias[0]);
	oParamExcel.array.push(aTotales[0]);

	//Ahora la tabla de tejido confirmado y tejido pendiente de confirmar
	var arrayFilasTC = [];
	var qTC = new AQSqlQuery;
	qTC.setSelect("pr_ordenesproduccion.codorden,pr_ordenesproduccion.fecha, pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.totaluds,pr_ordenesproduccion.totalmetros,pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.codsubfamilia,pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.em_codgruposeccion,pr_ordenesproduccion.em_paralizada,pr_ordenesproduccion.em_acabados, pr_ordenesproduccion.em_alias,pr_ordenesproduccion.em_gramaje, pr_ordenesproduccion.em_anchotejido,pr_ordenesproduccion.em_anverso, pr_ordenesproduccion.em_reverso, pr_ordenesproduccion.em_colordibujo, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.em_colorreverso, pr_ordenesproduccion.em_motivopara");
	qTC.setFrom("pr_ordenesproduccion");
	qTC.setWhere(formem_colaproduccion.iface.dameFiltroConfirmado());
	qTC.setOrderBy(formem_colaproduccion.iface.dameOrderByConfirmado());	
	if (!qTC.exec()){
		debug("///////////no se ejecuta consulta");
		return;
	}  
	while(qTC.next())
	{
		var codOrden = 	qTC.value("pr_ordenesproduccion.codorden");		
		var uds = qTC.value("pr_ordenesproduccion.totaluds");		
		var metros = qTC.value("pr_ordenesproduccion.totalmetros");
		var codModOp = qTC.value("pr_ordenesproduccion.em_codmodooper");		
		var descSubfam = qTC.value("pr_ordenesproduccion.subfamilia");

		var descripcion = formem_colaproduccion.iface.dameDescripcionOrden(qTC);
		var paralizada = qTC.value("pr_ordenesproduccion.em_paralizada");
		if(paralizada) {
			paralizada = "SI";
		} else {
			paralizada = "NO";
		}
		var motivoParaliza = qTC.value("pr_ordenesproduccion.em_motivopara");
		
		arrayFilasTC.push([descripcion ,qTC.value("pr_ordenesproduccion.dibujo"),codOrden,AQUtil.dateAMDtoDMA(qTC.value("pr_ordenesproduccion.fechaentrega")),uds,metros,qTC.value("pr_ordenesproduccion.em_codgruposeccion"),qTC.value("pr_ordenesproduccion.em_acabados"),descSubfam,qTC.value("pr_ordenesproduccion.em_alias"),qTC.value("pr_ordenesproduccion.em_gramaje"),"",codModOp,qTC.value("pr_ordenesproduccion.em_anchotejido"),"","","","","","",qTC.value("pr_ordenesproduccion.em_anverso"),qTC.value("pr_ordenesproduccion.em_reverso"),qTC.value("pr_ordenesproduccion.em_colordibujo"),qTC.value("pr_ordenesproduccion.em_colorreverso"),"","",paralizada,motivoParaliza,"'" ]);
	}

	var arrayFilasTPC = [];
	var qTPC = new AQSqlQuery;

	qTPC.setSelect("pr_ordenesproduccion.codorden,pr_ordenesproduccion.fecha, pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.totaluds,pr_ordenesproduccion.totalmetros,pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.codsubfamilia,pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.em_codgruposeccion, pr_ordenesproduccion.em_paralizada,pr_ordenesproduccion.em_acabados, pr_ordenesproduccion.em_alias,pr_ordenesproduccion.em_gramaje, pr_ordenesproduccion.em_anchotejido,pr_ordenesproduccion.em_anverso, pr_ordenesproduccion.em_reverso, pr_ordenesproduccion.em_colordibujo, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.em_colorreverso, pr_ordenesproduccion.em_motivopara");
	qTPC.setFrom("pr_ordenesproduccion");
	qTPC.setWhere(formem_colaproduccion.iface.dameFiltroPteConfirmar());
	qTPC.setOrderBy(formem_colaproduccion.iface.dameOrderByPteConfirmar());
	
	if (!qTPC.exec()){
		return;
	}  
	while(qTPC.next())
	{
		var codOrden = qTPC.value("pr_ordenesproduccion.codorden");
		var uds = qTPC.value("pr_ordenesproduccion.totaluds");
		var metros = qTPC.value("pr_ordenesproduccion.totalmetros");
		var codModOp = qTPC.value("pr_ordenesproduccion.em_codmodooper");		
		var descSubfam = qTPC.value("pr_ordenesproduccion.subfamilia");

		var descripcion = formem_colaproduccion.iface.dameDescripcionOrden(qTPC);

		var paralizada = qTPC.value("pr_ordenesproduccion.em_paralizada");
		if(paralizada) {
			paralizada = "SI";
		} else {
			paralizada = "NO";
		}

		var motivoParaliza = qTPC.value("pr_ordenesproduccion.em_motivopara");
		
		
		arrayFilasTPC.push([descripcion ,qTPC.value("pr_ordenesproduccion.dibujo"),codOrden,AQUtil.dateAMDtoDMA(qTPC.value("pr_ordenesproduccion.fechaentrega")),uds,metros,qTPC.value("pr_ordenesproduccion.em_codgruposeccion"),qTPC.value("pr_ordenesproduccion.em_acabados"),descSubfam,qTPC.value("pr_ordenesproduccion.em_alias"),qTPC.value("pr_ordenesproduccion.em_gramaje"),"",codModOp,qTPC.value("pr_ordenesproduccion.em_anchotejido"),"","","","","","",qTPC.value("pr_ordenesproduccion.em_anverso"),qTPC.value("pr_ordenesproduccion.em_reverso"),qTPC.value("pr_ordenesproduccion.em_colordibujo"),qTPC.value("pr_ordenesproduccion.em_colorreverso"),"","",paralizada,motivoParaliza,"'" ]);


	}	
	var aCabTejidos = [""];
	
	var aVaciasTej = [];
	oParamExcel.arrayTej = [];
	  
	oParamExcel.tipoColumnaTej = [];
	oParamExcel.nombreColumnasTej = [];
	oParamExcel.titulosTej = [];

	for (var i=0 ; i<2; i++) {
	     if(i==0) {
			aVaciasTej.push(_i.filaVacia_);
			oParamExcel.nombreColumnasTej.push("Descripci�n");
		} else {
			aVaciasTej[0] = aVaciasTej[0].concat(_i.filaVacia_);
			oParamExcel.nombreColumnasTej.push("Descripci�n");
		}

		oParamExcel.nombreColumnasTej.push("Dibujo anverso");
		oParamExcel.nombreColumnasTej.push("N�Orden");		
		oParamExcel.nombreColumnasTej.push("F.Entrega");
		oParamExcel.nombreColumnasTej.push("Unidades");
		oParamExcel.nombreColumnasTej.push("Metros");
		oParamExcel.nombreColumnasTej.push("Agrupaci�n");
		oParamExcel.nombreColumnasTej.push("Acabados");
		oParamExcel.nombreColumnasTej.push("Subfamilia");
		oParamExcel.nombreColumnasTej.push("Alias");
		oParamExcel.nombreColumnasTej.push("Gramaje");	
		oParamExcel.nombreColumnasTej.push("");	
		oParamExcel.nombreColumnasTej.push("Modo operaci�n");
		oParamExcel.nombreColumnasTej.push("Ancho tejido");	
		oParamExcel.nombreColumnasTej.push("");		
		oParamExcel.nombreColumnasTej.push("");		
		oParamExcel.nombreColumnasTej.push("");
		oParamExcel.nombreColumnasTej.push("");		
		oParamExcel.nombreColumnasTej.push("");	
		oParamExcel.nombreColumnasTej.push("");	
		oParamExcel.nombreColumnasTej.push("Anverso");
		oParamExcel.nombreColumnasTej.push("Reverso");
		oParamExcel.nombreColumnasTej.push("Color dibujo");
		
		oParamExcel.nombreColumnasTej.push("Color reverso");
		
		oParamExcel.nombreColumnasTej.push("");	
		oParamExcel.nombreColumnasTej.push("");	
			

		
		oParamExcel.nombreColumnasTej.push("Paralizada");
		oParamExcel.nombreColumnasTej.push("M.Paralizada");	
		oParamExcel.nombreColumnasTej.push("");	
		


		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("double");
		oParamExcel.tipoColumnaTej.push("double");
		oParamExcel.tipoColumnaTej.push("string");		
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("double");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");

		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");


		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		

		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");


		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");
		oParamExcel.tipoColumnaTej.push("string");

	}
	
	oParamExcel.titulosTej = ["ORDENES CONFIRMADAS","ORDENES PENDIENTES DE CONFIRMAR"];	

	if(arrayFilasTC.length != 0) {
	     oParamExcel.arrayTej = arrayFilasTC;
	}


	if(oParamExcel.arrayTej.length > arrayFilasTPC.length) {
		for(var k = 0; k < oParamExcel.arrayTej.length; k++) {

			if(k < arrayFilasTPC.length) {
				oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(arrayFilasTPC[k]);					  	
			}else {
				oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(_i.filaVacia_);					  	
			}			
		}			
	}else {
		for(var k = 0; k < arrayFilasTPC.length; k++) {
		     
			if(k < oParamExcel.arrayTej.length) {

				oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(arrayFilasTPC[k]);
			} else{						
			  	var numCols = _i.filaVacia_.length;
				oParamExcel.arrayTej.push(_i.filaVacia_);
			  	while(oParamExcel.arrayTej[k].length < numCols) {
			  		oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(_i.filaVacia_);	
			  	}
			    oParamExcel.arrayTej[k] = oParamExcel.arrayTej[k].concat(arrayFilasTPC[k]);			    
			}				
			
		}
	}


	//totales tejido confirmado y tejido pte de confirmar
	var cantTC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totaluds)", formem_colaproduccion.iface.dameFiltroConfirmado());
	var cantMTC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totalmetros)", formem_colaproduccion.iface.dameFiltroConfirmado());

		
	var cantTPC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totaluds)", formem_colaproduccion.iface.dameFiltroPteConfirmar());
	var cantMTPC = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(pr_ordenesproduccion.totalmetros)", formem_colaproduccion.iface.dameFiltroPteConfirmar());	



	var aTotalesTej = [];
	var aVaciasTej = [];

	aTotalesTej.push(["","","TOTAL CONFIRMADOS:","",cantTC,cantMTC,"","","","","","","","","","","","","","","","","","","","","","",""]);
	aVaciasTej.push(_i.filaVacia_);
		
	if(aTotalesTej.length == 0) {
		aTotalesTej.push(["","","TOTAL POR CONFIRMAR:","",cantPC,cantMTPC,"","","","","","","","","","","","","","","","","","","","","","",""]);		
		aVaciasTej.push(_i.filaVacia_);
	} else {
		aTotalesTej[0] = aTotalesTej[0].concat(["","","TOTAL POR CONFIRMAR:","",cantTPC,cantMTPC,"","","","","","","","","","","","","","","","","","","","","","",""]);	
		aVaciasTej[0] = aVaciasTej[0].concat(_i.filaVacia_);
	}

	
	oParamExcel.arrayTej.push(aVaciasTej[0]);
	oParamExcel.arrayTej.push(aVaciasTej[0]);
	oParamExcel.arrayTej.push(aVaciasTej[0]);
	oParamExcel.arrayTej.push(aTotalesTej[0]);



}

function euromoda_exportarColaProdExcel(oParam, ampliada)
{
	var _i = this.iface;
	var numColumnasCola;
	if(ampliada) {
		numColumnasCola = 29;
	} else {
		numColumnasCola = 12;
	}
	var colorRipeado = new AQOdsColor(0,187,255);
	var colorMaquetado = new AQOdsColor(255,140,0);

	if(oParam.array == undefined){
		sys.warnMsgBox(sys.translate("No se ha podido crear el archivo excel porque no hay tabla."));
		return;
	}
	if(oParam.nombreFichero == ""){
		sys.warnMsgBox(sys.translate("No se ha podido crear el archivo excel porque falta el nombre del fichero."));
		return;
	}

	var totalRegistros = oParam.array.length;
	if (totalRegistros == 0) {
		sys.warnMsgBox(sys.translate("No hay datos que exportar"));
		return;
	}
	var numCols = oParam.array[0].length;
	// Estilos para poner a las celdas
	var titleCellStyle = new AQOdsStyle(AQS.ODS_ALIGN_CENTER |
	AQS.ODS_TEXT_BOLD);
	var italic = new AQOdsStyle(AQS.ODS_TEXT_ITALIC);
	var tSep = new AQOdsStyle(AQS.ODS_BORDER_TOP);
	var bSep = new AQOdsStyle(AQS.ODS_BORDER_BOTTOM);
	var rSep = new AQOdsStyle(AQS.ODS_BORDER_RIGHT);
	var lSep = new AQOdsStyle(AQS.ODS_BORDER_LEFT);
	var lAlig = new AQOdsStyle(AQS.ODS_ALIGN_LEFT);
	var rAlig = new AQOdsStyle(AQS.ODS_ALIGN_RIGHT);
	var none = new AQOdsStyle(AQS.ODS_NONE);
	var undeline = new AQOdsStyle(AQS.ODS_TEXT_UNDERLINE);
	var bold = new AQOdsStyle(AQS.ODS_TEXT_BOLD);

		//_i.creaDialogoProgreso(sys.translate("Creando fichero ..."), totalRegistros);

	// Creación del archivo ods.
	var odsGen = new AQOdsGenerator;
	var spreadsheet = new AQOdsSpreadSheet(odsGen);
	var sheet = new AQOdsSheet(spreadsheet, oParam.nombreFichero);

	//Cabecera del fichero
	if(oParam.titulo != ""){
		var row= new AQOdsRow(sheet);
		row.opIn(titleCellStyle).opIn(oParam.titulo,numCols);
		row.close();
	}

	// Para dejar varias filas de separación entre la cabecera y la tabla con los datos.
	for (var i = 0; i < 2; i++){
		var row= new AQOdsRow(sheet);

		
		if(i == 0) {
			var contDig = 0;
			if(oParam.nombreColumnas && oParam.nombreColumnas.length > 0){
				var maxCol = oParam.nombreColumnas.length > numCols ? numCols : oParam.nombreColumnas.length;
				for(var col = 0; col < maxCol; col++){
					if((col+1) % (_i.filaVacia_.length) == 0 && col !=0) {
						if (contDig % 2 != 0){
							row.addBgColor(new AQOdsColor(255,255,255));
							
						}else {
							row.addBgColor(new AQOdsColor(170,255,255));
						}
						row.opIn(rSep).opIn(tSep).opIn(titleCellStyle).opIn(oParam.colasProd[contDig],_i.filaVacia_.length,2);
						contDig++;
					}
				}
			}
		}


		
		row.close();
	}

	// Cabecera para las columnas.
	var row = new AQOdsRow(sheet);
	row.addBgColor(new AQOdsColor(225,223,223)); // color de fondo para toda la fila
	//row.addFgColor(new AQOdsColor(0xff0000));
	if(oParam.nombreColumnas && oParam.nombreColumnas.length > 0){
		var maxCol = oParam.nombreColumnas.length > numCols ? numCols : oParam.nombreColumnas.length;
		for(var col = 0; col < maxCol; col++){

			
				if((col+1) % (_i.filaVacia_.length) == 0 && col !=0) {
					row.addBgColor(new AQOdsColor(0,0,0));	
				}else {
					row.addBgColor(new AQOdsColor(225,223,223)); // color de fondo para toda la fila
				}


			row.opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn(bSep).opIn(oParam.nombreColumnas[col]); // opIn(string, colSpan, rowSpan)
		}
	}
	row.close();

	// Una fila en el archivo para cada fila del array.
	for (var f = 0; f < totalRegistros; f++){
		AQUtil.setProgress(f);
		var row2 = new AQOdsRow(sheet);

		if ( f % 2 == 0){
			row2.addBgColor(new AQOdsColor(255,255,255));
		} else{
			row2.addBgColor(new AQOdsColor(228,228,228));
		}

		var codOrden = oParam.array[f][1];
		if(codOrden && codOrden != "") {
			/*var oMaqRip = flfactppal.iface.pub_ejecutarQry("em_ordenesestampacion", "maquetado,ripeado", "codordenest = '" + codOrden + "'");
			if(oMaqRip && ("maquetado" in oMaqRip) && ("ripeado" in oMaqRip)) {
				var maquetado = oMaqRip.maquetado;
				var ripeado = oMaqRip.ripeado;	
				if (!ripeado || ripeado=="" || !maquetado || maquetado=="") {
						
				} else {
					var aMaquetado= maquetado.split("/");
					var aRipeado= ripeado.split("/");
					if(aRipeado[0] == aRipeado[1]  && aRipeado[1] != 0) {			
						row2.addBgColor(colorRipeado);
					} else if(aMaquetado[0] == aMaquetado[1] && aMaquetado[1]!= 0) {					
						row2.addBgColor(colorMaquetado);
					} 
						
				}
			}*/
		}

		var col = 0;
		var texto;
		if( f == (totalRegistros - 1)){ // Para dibujar la lí­nea de abajo de la íºltima fila de celdas.
			texto = oParam.array[f][col];
			if (texto == ""){
				texto = " ";
			}

			row2.opIn(rSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(texto);
			
			for(col = 1; col < numCols ; col++){
				texto = oParam.array[f][col];
				if (texto == "") {
					texto = " ";
				} else {
					texto = fleumoesta.iface.formateaDato(oParam.tipoColumna[col],texto);
				
				}

				if((col+1) % (_i.filaVacia_.length) == 0 && col !=0) {
					row2.addBgColor(new AQOdsColor(0,0,0));	
				}else {
					if ( f % 2 == 0){
						row2.addBgColor(new AQOdsColor(255,255,255));
					} else{
						row2.addBgColor(new AQOdsColor(228,228,228));
					}
					
					if((col) % (_i.filaVacia_.length) == 0 && col !=0) {
						var codOrden = oParam.array[f][col+1];
						if(codOrden && codOrden != "") {
							/*var oMaqRip = flfactppal.iface.pub_ejecutarQry("em_ordenesestampacion", "maquetado,ripeado", "codordenest = '" + codOrden + "'");
							if(oMaqRip && ("maquetado" in oMaqRip) && ("ripeado" in oMaqRip)) {
								var maquetado = oMaqRip.maquetado;
								var ripeado = oMaqRip.ripeado;	
								if (!ripeado || ripeado=="" || !maquetado || maquetado=="") {
										
								} else {
									var aMaquetado= maquetado.split("/");
									var aRipeado= ripeado.split("/");
									if(aRipeado[0] == aRipeado[1]  && aRipeado[1] != 0) {			
										row2.addBgColor(colorRipeado);
									} else if(aMaquetado[0] == aMaquetado[1] && aMaquetado[1]!= 0) {					
										row2.addBgColor(colorMaquetado);
									} 
										
								}
							}*/
						}
					}

				}
				row2.opIn(rSep).opIn(bSep).opIn(lAlig).opIn(tSep).opIn(bold).opIn(texto);
			}
		} else{
			texto = oParam.array[f][col];
			if (texto == "") {
				texto = " ";
			}
			row2.opIn(rSep).opIn(lAlig).opIn(texto);
			for(col = 1; col < numCols; col++){
				texto = oParam.array[f][col];
				if (texto == "") {
					var fac = parseInt(col / numColumnasCola);				
					var columna0 = numColumnasCola*fac;								
 					if(oParam.tipoColumna[col] == "double" && oParam.array[f][columna0] != "") {
						texto = 0;
					} else {
						texto = " ";
					}					

				} else {
					texto = fleumoesta.iface.formateaDato(oParam.tipoColumna[col],texto);
				}
				
				if((col+1) % (_i.filaVacia_.length) == 0 && col !=0) {
					row2.addBgColor(new AQOdsColor(0,0,0));	
				}else {
					if ( f % 2 == 0){
						row2.addBgColor(new AQOdsColor(255,255,255));
					} else{
						row2.addBgColor(new AQOdsColor(228,228,228));
					}
										
					if((col) % (_i.filaVacia_.length) == 0 && col !=0) {
						var codOrden = oParam.array[f][col+1];
					
						if(codOrden && codOrden != "") {
							/*var oMaqRip = flfactppal.iface.pub_ejecutarQry("em_ordenesestampacion", "maquetado,ripeado", "codordenest = '" + codOrden + "'");
							if(oMaqRip && ("maquetado" in oMaqRip) && ("ripeado" in oMaqRip)) {
								var maquetado = oMaqRip.maquetado;
								var ripeado = oMaqRip.ripeado;	
								if (!ripeado || ripeado=="" || !maquetado || maquetado=="") {
										
								} else {
									var aMaquetado= maquetado.split("/");
									var aRipeado= ripeado.split("/");
									if(aRipeado[0] == aRipeado[1]  && aRipeado[1] != 0) {			
										row2.addBgColor(colorRipeado);
									} else if(aMaquetado[0] == aMaquetado[1] && aMaquetado[1]!= 0) {					
										row2.addBgColor(colorMaquetado);
									} 
										
								}
							}*/
						}
					}
				}
				row2.opIn(rSep).opIn(lAlig).opIn(texto);
			}
		}
		row2.close();
	}


	//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	// TABLAS DE TEJIDOS
	numCols = oParam.arrayTej[0].length;

	if(oParam.arrayTej == undefined){
		sys.warnMsgBox(sys.translate("No se ha podido crear el archivo excel porque no hay tabla."));
		return;
	}
	var totalRegistros = oParam.arrayTej.length;
	if (totalRegistros != 0) {		

		// Para dejar varias filas de separación entre la cabecera y la tabla con los datos.
		for (var i = 0; i < 1; i++){
			var row= new AQOdsRow(sheet);
			row.close();
		}


		for (var i = 0; i < 2; i++){
			var row= new AQOdsRow(sheet);
			
			if(i == 0) {
				var contTitulos = 0;
				if(oParam.nombreColumnasTej && oParam.nombreColumnasTej.length > 0){
					var maxCol = oParam.nombreColumnasTej.length > numCols ? numCols : oParam.nombreColumnasTej.length;
					for(var col = 0; col < maxCol; col++){
						if((col+1) % (_i.filaVacia_.length) == 0 && col !=0) {
							if(contTitulos == 0) {
								row.addBgColor(new AQOdsColor(0,255,0));
							} else {
								row.addBgColor(new AQOdsColor(255,255,0));
							}
							row.opIn(rSep).opIn(tSep).opIn(titleCellStyle).opIn(oParam.titulosTej[contTitulos],_i.filaVacia_.length,2);
							contTitulos++;
						}
					}
				}
			}
			
			row.close();
		}

		// Cabecera para las columnas.
		for (var i = 0; i < 2; i++){
		var row = new AQOdsRow(sheet);
		row.addBgColor(new AQOdsColor(225,223,223));
		if(i == 0) {
			row.addBgColor(new AQOdsColor(225,223,223)); // color de fondo para toda la fila
			//row.addFgColor(new AQOdsColor(0xff0000));
			if(oParam.nombreColumnasTej && oParam.nombreColumnasTej.length > 0){
				var maxCol = oParam.nombreColumnasTej.length > numCols ? numCols : oParam.nombreColumnasTej.length;
				for(var col = 0; col < maxCol; col++){
					row.opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn(bSep).opIn(oParam.nombreColumnasTej[col],1,2); // opIn(string, colSpan, rowSpan)
				}
			}
	    }
		row.close();
	    }
		// Una fila en el archivo para cada fila del array.
		for (var f = 0; f < totalRegistros; f++){
			AQUtil.setProgress(f);
			var row2 = new AQOdsRow(sheet);

			if ( f % 2 == 0){
				row2.addBgColor(new AQOdsColor(255,255,255));
			} else{
				row2.addBgColor(new AQOdsColor(228,228,228));
			}

			var col = 0;
			var texto;
			if( f == (totalRegistros - 1)){ // Para dibujar la lí­nea de abajo de la íºltima fila de celdas.
				texto = oParam.arrayTej[f][col];
				if (texto == ""){
					texto = " ";
				}

				row2.opIn(rSep).opIn(bSep).opIn(lAlig).opIn(tSep).opIn(bold).opIn(texto);
				
				for(col = 1; col < numCols ; col++){
					texto = oParam.arrayTej[f][col];
					if (texto == "") {
						texto = " ";
					} else {
						texto = fleumoesta.iface.formateaDato(oParam.tipoColumnaTej[col],texto);
					
					}
					if ( f % 2 == 0){
						row2.addBgColor(new AQOdsColor(255,255,255));
					} else{
						row2.addBgColor(new AQOdsColor(228,228,228));
					}
					row2.opIn(rSep).opIn(bSep).opIn(lAlig).opIn(tSep).opIn(bold).opIn(texto);
				}
			} else{
				texto = oParam.arrayTej[f][col];
				if (texto == "") {
					texto = " ";
				}
				row2.opIn(rSep).opIn(lAlig).opIn(texto);
				for(col = 1; col < numCols; col++){
					texto = oParam.arrayTej[f][col];
					if (texto == "") {
						texto = " ";
					} else {
						texto = fleumoesta.iface.formateaDato(oParam.tipoColumnaTej[col],texto);
					}
					if ( f % 2 == 0){
						row2.addBgColor(new AQOdsColor(255,255,255));
					} else{
						row2.addBgColor(new AQOdsColor(228,228,228));
					}
					row2.opIn(rSep).opIn(lAlig).opIn(texto);
				}
			}
			row2.close();
		}
	}

		

	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);

	sheet.close();
	spreadsheet.close();
	oParam.odsGen = odsGen;
	oParam.sheet = sheet;
	/*//Nombre del archivo.
	var odsFileName = "";
	if(oParam.path == "home"){
		odsFileName = Dir.home + "/" + oParam.nombreFichero +".ods";
	} else{
		var dirDestino = FileDialog.getExistingDirectory("", "Directorio de archivos");
		if (!dirDestino) {
			sys.warnMsgBox(sys.translate("No existe el directorio seleccionado."));
		}
		odsFileName =  dirDestino + "/" + oParam.nombreFichero +".ods";
	}
	odsFileName = Dir.cleanDirPath(odsFileName);
	odsFileName = Dir.convertSeparators(odsFileName);
	// Función que crea "fí­sicamente" el archivo con la configuración y datos introducidos anteriormente.
	odsGen.generateOds(odsFileName);
	sys.infoMsgBox(sys.translate("Fichero generado en %1").arg(odsFileName));
	// Abrir archivo.
	sys.openUrl("file://" + odsFileName);*/
}


//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
