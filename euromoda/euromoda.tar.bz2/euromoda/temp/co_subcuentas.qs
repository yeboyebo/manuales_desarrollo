
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends modelo303 {
	function euromoda( context ) { modelo303 ( context ); }
	function habilitarIVA() {
		return this.ctx.euromoda_habilitarIVA();
	}
	function init() {
		return this.ctx.euromoda_init();
	}
	function calculateField(fN) {
		return this.ctx.euromoda_calculateField(fN);
	}
	function calculaSaldoInicial(codSubcuenta, codEjercicio) {
		return this.ctx.euromoda_calculaSaldoInicial(codSubcuenta, codEjercicio);
	}
	function revisaSaldoSubcuenta(saldoInicial, codSubcuenta, codEjercicio) {
		return this.ctx.oficial_revisaSaldoSubcuenta(saldoInicial, codSubcuenta, codEjercicio);
	}
	function tbnRecalculaSaldo_clicked() {
		return this.ctx.euromoda_tbnRecalculaSaldo_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx ( context ); }
	function pub_calculaSaldoInicial(codSubcuenta, codEjercicio) {
		return this.calculaSaldoInicial(codSubcuenta, codEjercicio);
	}
	function revisaSaldoSubcuenta(saldoInicial, codSubcuenta, codEjercicio) {
		return this.ctx.euromoda_revisaSaldoSubcuenta(saldoInicial, codSubcuenta, codEjercicio);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_habilitarIVA()
{
	var _i = this.iface;
	_i.__habilitarIVA();
	this.child("fdbCodImpuesto").setDisabled(false);
	this.child("fdbSaldo").close();
}

function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	var sI = _i.calculateField("saldoinicial");
	sys.setObjText(this, "lblSaldoInicial", sys.translate("Saldo inicial %1").arg(sI));
	if (this.child("tdbPartidas")) {
		this.child("tdbPartidas").refresh();
	}
	connect(this.child("tbnRecalculaSaldo"), "clicked()", _i, "tbnRecalculaSaldo_clicked");
}

function euromoda_tbnRecalculaSaldo_clicked()
{
	var _i = this.iface;
    var cursor = this.cursor();
    
    var idSubcuenta = cursor.valueBuffer("idsubcuenta");
    var qryTotales = new FLSqlQuery();
	with (qryTotales) {
		setTablesList("co_partidas");
		setSelect("SUM(debe), SUM(haber)");
		setFrom("co_partidas");
		setWhere("idsubcuenta = " + idSubcuenta);
	}
	try { qryTotales.setForwardOnly( true ); } catch (e) {}
	if (!qryTotales.exec()) {
		return false;
	}
	var debe= 0;
	var haber= 0;
	var saldo= 0;
	if (qryTotales.next()) {
		debe = parseFloat(qryTotales.value(0));
		if (isNaN(debe))
			debe = 0;
		debe = AQUtil.roundFieldValue(debe, "co_subcuentas", "debe");
		haber = parseFloat(qryTotales.value(1));
		if (isNaN(haber))
			haber = 0;
		haber = AQUtil.roundFieldValue(haber, "co_subcuentas", "haber");
		saldo = debe - haber;
		saldo = AQUtil.roundFieldValue(saldo, "co_subcuentas", "saldo");
	}
	cursor.setValueBuffer("debe", debe);
	cursor.setValueBuffer("haber", haber);
	cursor.setValueBuffer("saldo", saldo);
}


function euromoda_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "saldoinicial": {
			valor = AQUtil.formatoMiles(AQUtil.roundFieldValue(_i.calculaSaldoInicial(cursor.valueBuffer("codsubcuenta"), cursor.valueBuffer("codejercicio")), "co_subcuentas", "saldo"));
			break;
		}
		default: {
			valor = _i.__calculateField(fN);
		}
	}
	return valor;
}

function euromoda_calculaSaldoInicial(codSubcuenta, codEjercicio)
{
	var _i = this.iface;
	var valor;
	var fechaInicio = AQUtil.sqlSelect("ejercicios", "fechainicio", "codejercicio = '" + codEjercicio + "'");
	if (!fechaInicio) {
		valor = 0;
	}
	valor = AQUtil.sqlSelect("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento", "SUM(debe-haber)", "p.codsubcuenta = '" + codSubcuenta + "' AND a.fecha < '" + fechaInicio + "'", "co_partidas,co_asientos");
	valor = isNaN(valor) ? 0 : valor;
	_i.revisaSaldoSubcuenta(valor, codSubcuenta, codEjercicio);
	// Para poder usar el valor en la ventana de punteo
	//valor = AQUtil.formatoMiles(AQUtil.roundFieldValue(valor, "co_partidas", "debe"));
	return valor;
}

function euromoda_revisaSaldoSubcuenta(saldoInicial, codSubcuenta, codEjercicio)
{
	var _i = this.iface;
	var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codejercicio = '" + codEjercicio + "' AND codsubcuenta = '" + codSubcuenta + "'");
	if (!idSubcuenta) {
		return false;
	}
	
	var sI = saldoInicial;
	var q = new AQSqlQuery;
	q.setSelect("p.debe-p.haber, p.idpartida, p.saldo");
	q.setFrom("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento");
	q.setWhere("p.idsubcuenta = " + idSubcuenta + " ORDER BY a.fecha, p.idpartida");
	if (!q.exec()) {
		return false;
	}
	AQUtil.createProgressDialog(sys.translate("Revisando saldo"), q.size());
	var p = 0;
	var s = sI, inc;
	while (q.next()) {
		AQUtil.setProgress(p++);
		inc = parseFloat(q.value("p.debe-p.haber"));
		inc = isNaN(inc) ? 0 : inc;
		s += parseFloat(inc);
		if (AQUtil.roundFieldValue(s, "co_partidas", "saldo") == q.value("p.saldo")) {
			continue;
		}
		AQUtil.execSql("UPDATE co_partidas SET saldo = " + AQUtil.roundFieldValue(s, "co_partidas", "saldo") + " WHERE idpartida = " + q.value("p.idpartida"));
	}
	AQUtil.destroyProgressDialog();
	
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
