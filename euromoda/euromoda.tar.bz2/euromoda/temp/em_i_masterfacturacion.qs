/***************************************************************************
                 em_i_masterfacturacion.qs  -  description
                             -------------------
    begin                : mar feb 19 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var origen_;
	function oficial( context ) { interna( context ); } 
	function lanzar() {
		return this.ctx.oficial_lanzar();
	}
	function obtenerParamInforme() {
		return this.ctx.oficial_obtenerParamInforme();
	}
	function dimeOrigen(campo) {
		return this.ctx.oficial_dimeOrigen(campo);
	}
	function dameDescripcionInforme(campo) {
		return this.ctx.oficial_dameDescripcionInforme(campo);
	}
	function tbnExcel_clicked() {
		return this.ctx.oficial_tbnExcel_clicked();
	}
	function dameNivelesInforme(nombreInforme) {
		return this.ctx.oficial_dameNivelesInforme(nombreInforme);
	}
	function obtenerParamExcel(cursor) {
		return this.ctx.oficial_obtenerParamExcel(cursor);
	}
	function dameNumMaxColumnas(nombreInforme) {
		return this.ctx.oficial_dameNumMaxColumnas(nombreInforme);
	}
	function dameFiltrosInforme() {
		return this.ctx.oficial_dameFiltrosInforme();
	}
    function getCamposCalculados(nombreInforme) {
        return this.ctx.oficial_getCamposCalculados(nombreInforme);
    }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	connect (this.child("toolButtonPrint"), "clicked()", _i, "lanzar()");
	connect (this.child("tbnExcel"), "clicked()", _i, "tbnExcel_clicked()");

}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_lanzar()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var pI = this.iface.obtenerParamInforme();
  if (!pI) {
    return;
  }
  flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

/** \D Obtiene un array con los par�metros necesarios para establecer el informe
@return	array de par�metros o false si hay error
\end */
function oficial_obtenerParamInforme()
{
	var _i = this.iface;
  var cursor = this.cursor();
  var seleccion= cursor.valueBuffer("id");
  if (!seleccion) {
    return false;
  }
  var paramInforme = flfactinfo.iface.pub_dameParamInforme();
  //paramInforme.nombreInforme = cursor.action();
  var origen = cursor.valueBuffer("origendatos");     
  debug("origen: "+origen);
  if(origen == "Albaranes") {
  	_i.origen_ = "Estad�sticas de albaranado de venta";
  } else {
  	_i.origen_ = "Estad�sticas de facturaci�n de venta";
  }
  debug("origen2: "+_i.origen_);
  
  switch(cursor.valueBuffer("tipo")) {
  	case "Normal": {
  		switch(cursor.valueBuffer("agrupacion")) {
  			case "No agrupar": {
  			  	if(origen == "Albaranes") {
  					paramInforme.nombreInforme = "em_i_albaranado";
  					paramInforme.nombreReport = "em_i_facturacion";
  				} else {
  					paramInforme.nombreInforme = "em_i_facturacion";
  				}

		  		break;
  			}
  			case "Familia/Tam.": {
  			  if(origen == "Albaranes") {
  					paramInforme.nombreInforme = "em_i_albaranado_ft";
  					paramInforme.nombreReport = "em_i_facturacion_ft";
  				} else { 
  					paramInforme.nombreInforme = "em_i_facturacion_ft";
  				}

		  		break;
  			}
  			default: return false;
  		}
  		break;
  	}
  	case "Abreviado": {
  		switch(cursor.valueBuffer("agrupacion")) {
				case "No agrupar": {
				if(origen == "Albaranes") {
  					paramInforme.nombreInforme = "em_i_albaranado_abr";
  					paramInforme.nombreReport = "em_i_facturacion_abr";
  				} else {
					paramInforme.nombreInforme = "em_i_facturacion_abr";
				}
					break;
				}
				case "Familia/Tam.": {
				  	if(origen == "Albaranes") {
  						paramInforme.nombreInforme = "em_i_albaranado_abr_ft";
  						paramInforme.nombreReport = "em_i_facturacion_abr_ft";
  					} else {
						paramInforme.nombreInforme = "em_i_facturacion_abr_ft";
					}
					break;
				}
				default: return false;
			}
			break;
		}
		case "Superreducido": {
			switch(cursor.valueBuffer("agrupacion")) {
				case "No agrupar": {
					sys.warnMsgBox(sys.translate("No hay un formato de informe para la agrupaci�n y tipo seleccionados"));
					return false;
					break;
				}
				case "Familia/Tam.": {
				  	if(origen == "Albaranes") {
  						paramInforme.nombreInforme = "em_i_albaranado_sre_ft";
  						paramInforme.nombreReport = "em_i_facturacion_sre_ft";  						
  					} else {
						paramInforme.nombreInforme = "em_i_facturacion_sre_ft";						
					}
					paramInforme.groupBy = "empresa.cifnif, empresa.direccion, empresa.codpostal, empresa.ciudad, empresa.provincia,articulos.codfamilia, familias.descripcion, articulos.codtamanoem";
					break;
				}
				default: return false;
			}
			break;
		}
  	default: return false;
  }
  
  if (cursor.valueBuffer("codintervalo")) {
    var intervalo= [];
    intervalo = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalo"));
    cursor.setValueBuffer("d_v_fecha", intervalo.desde);
    cursor.setValueBuffer("h_v_fecha", intervalo.hasta);
  }
  
	var filtroEM = formem_filtrosarticulos.iface.pub_construirFiltro(cursor);
	var where = filtroEM;
	
	var listaSeries = cursor.valueBuffer("listaseries");
	if (listaSeries && listaSeries != "") {
		var aSeries = listaSeries.split(",");
		where += (where != "") ? " AND " : "";
		where += "v.codserie IN ('" + aSeries.join("', '") + "')";
	}
	if(origen == "Albaranes") {
		where += (where != "") ? " AND " : "";
		where += "v.tipodeposito IN ('Venta','Venta dep�sito') ";	
	}
	var listaAgentes = cursor.valueBuffer("listaagentes");
	if (listaAgentes && listaAgentes != "") {
		var aAgentes = listaAgentes.split(",");
		where += (where != "") ? " AND " : "";
		where += "v.codagente IN ('" + aAgentes.join("', '") + "')";
	}

	var necesidad = cursor.valueBuffer("necesidad");	
	if (necesidad && necesidad != "Todos"){
		if (where != "") {
			where += " AND ";
		}
		switch (necesidad){
			case "No": {
				where += "stocks.necesidad = 0";
				break;
			}
			default:
				where += "stocks.necesidad > 0";
				break;
		}
	}


	 
	if (where && where != "") {
		paramInforme.whereFijo = where;
	}
	
  return paramInforme;
}

function oficial_dimeOrigen(campo)
{
	debug("oficial_dimeOrigen");
	
	var _i = this.iface;		
	debug("origen3: "+_i.origen_);
	return _i.origen_;
}

function oficial_dameDescripcionInforme(campo)
{
	
	var _i = this.iface;		
	var cursor = this.cursor();
	var seleccion= cursor.valueBuffer("id");
	if (!seleccion) {
		return false;
	}	
	var descripcion = cursor.valueBuffer("descripcion");
	
	return descripcion;
}	


function oficial_tbnExcel_clicked()
{

	var _i = this.iface;	
	var cursor = this.cursor();
	var oParam = _i.obtenerParamExcel(cursor);
	if (!oParam) {
		return;
	}	
	debug("CONSULTA INFORME: " + oParam["q"].sql());	
	formEXCEL.lanzaInformeExcel(oParam);	

}



function oficial_dameNivelesInforme(nombreInforme)
{

	var italic = formEXCEL.italic;
	var tSep = formEXCEL.tSep,
	var bSep = formEXCEL.bSep;
	var rSep = formEXCEL.rSep;
	var lSep = formEXCEL.lSep;
	var lAlig = formEXCEL.lAlig;
	var rAlig = formEXCEL.rAlig;
	var none = formEXCEL.none;
	var undeline = formEXCEL.undeline;
	var bold = formEXCEL.bold;
	

	var oNiveles = new Object;
	var aNiveles = [];
	var niveles = [];
	var report = {};

	if(nombreInforme == "em_i_facturacion" || nombreInforme == "em_i_albaranado") {
		//origen facturas/albaranes - tipo normal - no agrupar
		niveles = ["articulos.referencia"];
		report = {
			"footer": function (valores, acumulados, sheet) {
				var row= new AQOdsRow(sheet);
				row.opIn("");
				row.opIn("");
				row.opIn("");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL INFORME");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(report["acumulados"]["v.cantidad"]);
				row.opIn("");
				row.opIn("");
				row.opIn("");
				row.opIn("");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(report["acumulados"]["v.totallinea"]));
				row.close();
			},
			"acumulados": {
				"v.cantidad": "SUMA",
				"v.totallinea": "SUMA"
			}
		}
		aNiveles[0] = new Object;
		aNiveles[0]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		//aNiveles[0]["cabecera"] = function (valores, sheet) {}
		aNiveles[0]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.referencia"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.descripcion"] + " " + valores["articulos.codtamanoem"] + " " + valores["articulos.codcolorem"]);
			row.close();

			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("N� Documento");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("Fecha");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("Cantidad");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("Unidad");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("Precio");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("% Dto.");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("Importe Dto.");			
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn("TOTAL");
			row.close();

		} 
		aNiveles[0]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL " + valores["articulos.referencia"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.descripcion"] + " " + valores["articulos.codtamanoem"] + " " + valores["articulos.codcolorem"]);		
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(acumulados[0]["v.cantidad"]);
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[0]["v.totallinea"]));
			row.close();
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.close();
		}
		aNiveles[1] = new Object;
		aNiveles[1]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["v.codigo"]);	
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(AQUtil.dateAMDtoDMA(valores["v.fecha"].toString().left(10)));
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["v.cantidad"]);
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["articulos.codunidad"]);
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.pvpunitario"]));
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.dtopor"]));
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.dtolin"]));
			row.opIn(lSep).opIn(rSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.totallinea"]));		
			row.close();
		}

	} else if (nombreInforme == "em_i_facturacion_ft" || nombreInforme == "em_i_albaranado_ft") {
		//origen facturas/albaranes - tipo normal - agrupado		
		niveles = ["articulos.codfamilia","articulos.codtamanoem","articulos.referencia"]; 
		report = {
			"footer": function (valores, acumulados, sheet) {
				var row= new AQOdsRow(sheet);
				row.opIn("");
				row.opIn("");
				row.opIn("");
				row.opIn("");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL INFORME");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(report["acumulados"]["v.cantidad"]);
				row.opIn("");
				row.opIn("");
				row.opIn("");
				row.opIn("");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(report["acumulados"]["v.totallinea"]));				
				row.close();
			},
			"acumulados": {
				"v.cantidad": "SUMA",
				"v.totallinea": "SUMA"
			}

		}

		aNiveles[0] = new Object;
		aNiveles[0]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[0]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("FAMILIA:");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["familias.descripcion"]);
			row.close();

		}
		aNiveles[0]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL FAMILIA");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["familias.descripcion"]);		
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(acumulados[0]["v.cantidad"]);
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[0]["v.totallinea"]));
			row.close();
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.close();
		}

		aNiveles[1] = new Object;
		aNiveles[1]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[1]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TAMA�O:");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.codtamanoem"]);
			row.close();

		}
		aNiveles[1]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL TAMA�O");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.codtamanoem"]);			
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(acumulados[1]["v.cantidad"]);
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[1]["v.totallinea"]));
			row.close();
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.close();
		}

		aNiveles[2] = new Object;
		aNiveles[2]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[2]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("PRODUCTO:");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.referencia"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.descripcion"] + " " + valores["articulos.codtamanoem"] + " " + valores["articulos.codcolorem"]);
			row.close();

			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("N� Documento");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Fecha");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Cantidad");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Unidad");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Precio");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("% Dto.");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Importe Dto.");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL");
			row.close();

		}
		aNiveles[2]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL PRODUCTO");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.referencia"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.descripcion"] + " " + valores["articulos.codtamanoem"] + " " + valores["articulos.codcolorem"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(acumulados[2]["v.cantidad"]);
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[2]["v.totallinea"]));
			row.close();
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.close();
		}
		
		aNiveles[3] = new Object;
		aNiveles[3]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[3]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["v.codigo"]);	
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(AQUtil.dateAMDtoDMA(valores["v.fecha"].toString().left(10)));
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["v.cantidad"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["articulos.codunidad"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.pvpunitario"]));
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.dtopor"]));
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.dtolin"]));
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["v.totallinea"]));		
			row.close();
		}
		aNiveles[3]["pie"] = function (valores, sheet) {}


	} else if (nombreInforme == "em_i_facturacion_abr" || nombreInforme == "em_i_albaranado_abr") {
		//origen facturas - tipo abreviado - no agrupar
		niveles = ["articulos.referencia"];
		report = {
			"header": function (valores, sheet) {
				var row= new AQOdsRow(sheet);
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Producto");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Descripcion");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Total Cantidad");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL");
				row.close();
			},
			"footer": function (valores, acumulados, sheet) {
				var row= new AQOdsRow(sheet);
				row.opIn("");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL");
				//row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(report["acumulados"]["lin.cantidad"]);
				//row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(AQUtil.roundFieldValue(report["acumulados"]["(lin.pvptotal * (100 - cab.pordtoesp) / 100)"], "lineasfacturascli", "pvptotal")));
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(report["acumulados"]["v.cantidad"]);
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(report["acumulados"]["v.totallinea"]));
				
				row.close();
			},
			"acumulados": {
				"v.cantidad": "SUMA",
				"v.totallinea": "SUMA"
			}

		}
		
		aNiveles[0] = new Object;
		aNiveles[0]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[0]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["articulos.referencia"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["articulos.descripcion"] + " " + valores["articulos.codtamanoem"] + " " + valores["articulos.codcolorem"]);
			//row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(acumulados[0]["lin.cantidad"]);
			//row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(AQUtil.roundFieldValue(acumulados[0]["(lin.pvptotal * (100 - cab.pordtoesp) / 100)"], "lineasfacturascli", "pvptotal")));
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(acumulados[0]["v.cantidad"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[0]["v.totallinea"]));
			row.close();
		}

	} else if (nombreInforme == "em_i_facturacion_abr_ft" || nombreInforme == "em_i_albaranado_abr_ft") {
		//origen facturas - tipo abreviado - agrupado
		niveles = ["articulos.codfamilia","articulos.codtamanoem","articulos.referencia"];

		report = {
			"footer": function (valores, acumulados, sheet) {
				var row= new AQOdsRow(sheet);
				row.opIn("");
				row.opIn("");
				row.opIn("");				
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL INFORME");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(report["acumulados"]["v.cantidad"]);
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(report["acumulados"]["v.totallinea"]));				
				row.close();
			},
			"acumulados": {
				"v.cantidad": "SUMA",
				"v.totallinea": "SUMA"
			}

		}

		aNiveles[0] = new Object;
		aNiveles[0]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[0]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("FAMILIA:");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["familias.descripcion"]);
			row.close();

		}
		aNiveles[0]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL FAMILIA");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["familias.descripcion"]);				
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(acumulados[0]["v.cantidad"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[0]["v.totallinea"]));
			row.close();
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.close();
		}

		aNiveles[1] = new Object;
		aNiveles[1]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[1]["detalle"] = function (valores, sheet) {
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TAMA�O:");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.codtamanoem"]);
			row.close();		

			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");		
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Referencia");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Descripci�n");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Total Cantidad");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL");
			row.close();

		}
		aNiveles[1]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL TAMA�O");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(valores["articulos.codtamanoem"]);					
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(acumulados[1]["v.cantidad"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[1]["v.totallinea"]));
			row.close();
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.close();
		}

		aNiveles[2] = new Object;
		aNiveles[2]["acumulados"] = {
			"v.cantidad": "SUMA",
			"v.totallinea": "SUMA"
		}
		aNiveles[2]["pie"] = function (valores, acumulados, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn("");
			row.opIn("");
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["articulos.referencia"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["articulos.descripcion"] + " " + valores["articulos.codtamanoem"] + " " + valores["articulos.codcolorem"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(acumulados[2]["v.cantidad"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(acumulados[2]["v.totallinea"]));
			row.close();
			
		}

	} else if (nombreInforme == "em_i_facturacion_sre_ft" || nombreInforme == "em_i_albaranado_sre_ft") {
		//origen facturas/albaranes - tipo superreducido - agrupado
		niveles = [];
		report = {
			"header": function (valores, sheet) {
				var row= new AQOdsRow(sheet);
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Familia");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Tama�o");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("Total Cantidad");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL");
				row.close();
			},
			"footer": function (valores, acumulados, sheet) {
				var row= new AQOdsRow(sheet);
				row.opIn("");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn("TOTAL");
				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(report["acumulados"]["SUM(v.cantidad)"]);				

				row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(report["acumulados"]["SUM(v.totallinea)"]));
				//row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(bold).opIn(lAlig).opIn(32329.87,10,2);
				row.close();
			},
			"acumulados": {
				"SUM(v.cantidad)": "SUMA",
				"SUM(v.totallinea)": "SUMA"
			}

		}
		aNiveles[0] = new Object;
		aNiveles[0]["acumulados"] = {
			"SUM(v.cantidad)": "SUMA",
			"SUM(v.totallinea)": "SUMA"
		}
		aNiveles[0]["cabecera"] = function (valores, sheet) {}		
		aNiveles[0]["detalle"] = function (valores, sheet) { 
			var row= new AQOdsRow(sheet);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["familias.descripcion"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["articulos.codtamanoem"]);
			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).opIn(valores["SUM(v.cantidad)"]);

			//debug("---: "+parseFloat(AQUtil.roundFieldValue(valores["SUMv.totallinea"], "lineasfacturascli", "pvptotal")));

			row.opIn(lSep).opIn(bSep).opIn(tSep).opIn(lAlig).setFixedPrecision(2).opIn(parseFloat(valores["SUM(v.totallinea)"]));

			row.close();
		}
		aNiveles[0]["pie"] = function (valores, sheet) {} 		
	}	

	oNiveles["aNiveles"] = aNiveles;
	oNiveles["niveles"] = niveles;
	oNiveles["report"] = report;


	return oNiveles;
}


function oficial_obtenerParamExcel(cursor)
{
	var _i  = this.iface;
	var oParam = _i.obtenerParamInforme();
	if(!oParam) {
		return false;
	}	
	var prefijo = "";

	if(oParam["nombreInforme"] == "em_i_facturacion") {
		prefijo = "facturacion";
	} else if(oParam["nombreInforme"] == "em_i_albaranado") {
		prefijo = "albaranado";
	} else if(oParam["nombreInforme"] == "em_i_facturacion_ft") {
		prefijo = "facturacion_a";
	} else if(oParam["nombreInforme"] == "em_i_albaranado_ft") {
		prefijo = "albaranado_a";
	} else if(oParam["nombreInforme"] == "em_i_facturacion_abr") {
		prefijo = "facturacion_ab";
	} else if(oParam["nombreInforme"] == "em_i_albaranado_abr") {
		prefijo = "albaranado_ab";
	} else if(oParam["nombreInforme"] == "em_i_facturacion_abr_ft") {
		prefijo = "facturacion_aba";
	} else if(oParam["nombreInforme"] == "em_i_albaranado_abr_ft") {
		prefijo = "albaranado_aba";
	} else if(oParam["nombreInforme"] == "em_i_facturacion_sre_ft") {
		prefijo = "facturacion_sr";
	} else if(oParam["nombreInforme"] == "em_i_albaranado_sre_ft") {
		prefijo = "albaranado_sr";
	}

	oParam["nombreFichero"] = flfactppal.iface.pub_dameNombreFecha(prefijo);
	if(!oParam["nombreFichero"] || oParam["nombreFichero"] == "" || oParam["nombreFichero"] == undefined) {
		return false;
	}		

	oParam["titulo"] = _i.origen_ ;
	oParam["titulo2"] = _i.dameDescripcionInforme("");
	oParam["titulo3"] = "";
	var aFiltros = _i.dameFiltrosInforme();
	if(aFiltros && aFiltros.length > 0) {
		oParam.filtros = aFiltros;	
	}
	//oParam.path = "home";
	oParam["numCols"] = _i.dameNumMaxColumnas(oParam["nombreInforme"]);
	oParam["q"] = flfactinfo.iface.estableceConsulta(cursor, oParam);
	oParam["oNiveles"] = _i.dameNivelesInforme(oParam["nombreInforme"]);
    oParam["camposCalculados"] = _i.getCamposCalculados(oParam["nombreInforme"]);
	return oParam;
}


function oficial_dameNumMaxColumnas(nombreInforme)
{
	
	if(nombreInforme == "em_i_facturacion" || nombreInforme == "em_i_albaranado") {
		return 10;
	} else if (nombreInforme == "em_i_facturacion_ft" || nombreInforme == "em_i_albaranado_ft") {
		return 11;
	} else if (nombreInforme == "em_i_facturacion_abr" || nombreInforme == "em_i_albaranado_abr") {
		return 4;
	} else if (nombreInforme == "em_i_facturacion_abr_ft" || nombreInforme == "em_i_albaranado_abr_ft") {
		return 6;
	} else if (nombreInforme == "em_i_facturacion_sre_ft" || nombreInforme == "em_i_albaranado_sre_ft") {
		return 4;
	}	
	return 0;
}

function oficial_dameFiltrosInforme()
{
	var res = formUI.preguntaMsg(sys.translate("�Quieres imprimir los filtros tambi�n?"), "info", this, MessageBox.Yes, MessageBox.No);

	if (res != 	MessageBox.Yes) {
		return false;
	}

	var cursor = this.cursor();

	var aFiltros = [];
	aFiltros.push("Obtener datos de: " + cursor.valueBuffer("origendatos"));
	aFiltros.push("Tipo: " + cursor.valueBuffer("tipo"));
	aFiltros.push("Agrupaci�n: " + cursor.valueBuffer("agrupacion"));

	if(cursor.valueBuffer("d_v_fecha") && cursor.valueBuffer("d_v_fecha") != "") {
		aFiltros.push("Fecha desde: " + AQUtil.dateAMDtoDMA(cursor.valueBuffer("d_v_fecha")));		
	}

	if(cursor.valueBuffer("h_v_fecha") && cursor.valueBuffer("h_v_fecha") != "") {
		aFiltros.push("Fecha hasta: " + AQUtil.dateAMDtoDMA(cursor.valueBuffer("h_v_fecha")));		
	}

	if(cursor.valueBuffer("listaseries") && cursor.valueBuffer("listaseries") != "") {
		aFiltros.push("Series: " + cursor.valueBuffer("listaseries"));	
	} else {
		aFiltros.push("Series: Todas");
	}

	if(cursor.valueBuffer("listaagentes") && cursor.valueBuffer("listaagentes") != "") {
		aFiltros.push("Agentes: " + cursor.valueBuffer("listaagentes"));
	} else {
		aFiltros.push("Agentes: Todos");
	}

	if(cursor.valueBuffer("codfamilia") && cursor.valueBuffer("codfamilia") != "") {
		aFiltros.push("Familias: " + cursor.valueBuffer("codfamilia"));		
	}

	if(cursor.valueBuffer("codsubfamilia") && cursor.valueBuffer("codsubfamilia") != "") {
		aFiltros.push("Subfamilias: " + cursor.valueBuffer("codsubfamilia"));		
	}

	if(cursor.valueBuffer("codcoleccionem") && cursor.valueBuffer("codcoleccionem") != "") {
		aFiltros.push("Colecciones: " + cursor.valueBuffer("codcoleccionem"));		
	}

	if(cursor.valueBuffer("dibujos") && cursor.valueBuffer("dibujos") != "") {
		aFiltros.push("Dibujos: " + cursor.valueBuffer("dibujos"));		
	}

	if(cursor.valueBuffer("refcomponente") && cursor.valueBuffer("refcomponente") != "") {
		aFiltros.push("Con componente: " + cursor.valueBuffer("refcomponente"));		
	}

	if(cursor.valueBuffer("codtamanoem") && cursor.valueBuffer("codtamanoem") != "") {
		aFiltros.push("Tama�o: " + cursor.valueBuffer("codtamanoem"));		
	}

	if(cursor.valueBuffer("codcolorem") && cursor.valueBuffer("codcolorem") != "") {
		aFiltros.push("Color: " + cursor.valueBuffer("codcolorem"));		
	}

	if(cursor.valueBuffer("aliasart") && cursor.valueBuffer("aliasart") != "") {
		aFiltros.push("Ref.Cliente: " + cursor.valueBuffer("aliasart"));		
	}

	if(cursor.valueBuffer("descatalogado") && cursor.valueBuffer("descatalogado") != "") {
		aFiltros.push("Incluir descatalogado: " + cursor.valueBuffer("descatalogado"));		
	}

	if(cursor.valueBuffer("aliquidar") && cursor.valueBuffer("aliquidar") != "") {
		aFiltros.push("Incluir a liquidar: " + cursor.valueBuffer("aliquidar"));		
	}

	if(cursor.valueBuffer("debaja") && cursor.valueBuffer("debaja") != "") {
		aFiltros.push("Incluir de baja: " + cursor.valueBuffer("debaja"));		
	}

	if(cursor.valueBuffer("necesidad") && cursor.valueBuffer("necesidad") != "") {
		aFiltros.push("Incluir con necesidad: " + cursor.valueBuffer("necesidad"));		
	}

	if(cursor.valueBuffer("i_v_codcliente") && cursor.valueBuffer("i_v_codcliente") != "") {
		aFiltros.push("Cliente: " + cursor.valueBuffer("i_v_codcliente"));		
	}

	return aFiltros;

}

function oficial_getCamposCalculados(nombreInforme)
{
    const _i = this.iface;   
    const cc = [];
    
    return cc;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
