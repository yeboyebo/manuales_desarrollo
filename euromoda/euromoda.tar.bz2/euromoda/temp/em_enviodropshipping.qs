var form = this;
/***************************************************************************
         em_colaestampacion.qs  -  description
                             -------------------
    begin                : lun mar 10 2014
    copyright            : (C) 2014 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	var utf8_;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {

    function oficial( context ) { interna( context ); }   
    function tbnBuscarFichero_clicked(){
    	return this.ctx.oficial_tbnBuscarFichero_clicked();	
    }
    function pbnCargaEnvios_clicked() {
    	return this.ctx.oficial_pbnCargaEnvios_clicked();
    }
    function cargaEnvios(oParam) {
    	return this.ctx.oficial_cargaEnvios(oParam);
    }
    function vaciaCanAlbPedido(idPedido) {
    	return this.ctx.oficial_vaciaCanAlbPedido(idPedido);
    }
	function marcaCanAlbPedido(oParamCan) {
		return this.ctx.oficial_marcaCanAlbPedido(oParamCan);
	}
	function sirvePedido(idPedido, aLineasPed) {
		return this.ctx.oficial_sirvePedido(idPedido, aLineasPed);
	}
	function asociaAlbaranesEnvio(aAlbaranes, codEnvio) {
		return this.ctx.oficial_asociaAlbaranesEnvio(aAlbaranes, codEnvio);
	}
	function pbGenerarAlb_clicked(){
    	return this.ctx.oficial_pbGenerarAlb_clicked();	
    }
    function generarAlbaranes(oParam) {
    	return this.ctx.oficial_generarAlbaranes(oParam);
    }
    function totalizaEnvio(cursor) {	 
    	return this.ctx.oficial_totalizaEnvio(cursor);
	}	
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function dameColorCarga(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_dameColorCarga(fN, fV, cursor, fT, sel);
	}
	function compruebaCierrePedido(oParamPed) {
		return this.ctx.oficial_compruebaCierrePedido(oParamPed);
	}
	function gestionaAvisos(codCliente, curCD) {
		return this.ctx.oficial_gestionaAvisos(codCliente, curCD);
	}
	function gestionaAvisosCasos(oParamAvisos)  {
		return this.ctx.oficial_gestionaAvisosCasos(oParamAvisos);
	}
	function aniadeAviso(oParam) {
		return this.ctx.oficial_aniadeAviso(oParam);
	}	
	function abrirLinea(idLineaPedido, idPedido) {
		return this.ctx.oficial_abrirLinea(idLineaPedido, idPedido);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}
const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;	
	connect(this.child("tbnBuscarFichero"), "clicked()", _i, "tbnBuscarFichero_clicked()");
	connect(this.child("pbGenerarAlb"), "clicked()", _i, "pbGenerarAlb_clicked()");
	connect(this.child("pbnCargaEnvios"), "clicked()", _i, "pbnCargaEnvios_clicked()");
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_tbnBuscarFichero_clicked()
{
	var fichero = FileDialog.getOpenFileName("*.csv", sys.translate( "scripts", "Fichero CSV importaci�n l�neas"));
	this.child("fdbNombreFichero").setValue(fichero);	
	return true;  	
}
  	
function oficial_pbnCargaEnvios_clicked()
{
	var _i = this.iface;
	var cursor= this.cursor();
	var sep = cursor.valueBuffer("camposeparador");
	var codEnvio = cursor.valueBuffer("emcodenviodrop");
	var codDrop = cursor.valueBuffer("coddropshipping");
	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbCargaEnviosDropshipping").cursor().commitBufferCursorRelation())
			return false;
	}

	var rutaF = cursor.valueBuffer("nombrefichero");
	if (!rutaF) {
		formUI.ponMsgWarn(sys.translate("Debe de informar un fichero para poder realizar la carga."));
		return false;
	}


	if(this.child("tdbCargaEnviosDropshipping").cursor().size() > 0) {
		var res = formUI.preguntaMsg(sys.translate("Ya se ha importado un fichero para este env�o �Desea eliminarlo y cargar el nuevo fichero?"), "info", this, MessageBox.Yes, MessageBox.No);
   		if(res != MessageBox.Yes) {
       		return false;
       	}  
	}


	/*if(sep == "Espacio") {
		sep = " ";
	} else if(sep == "Tabulador")  {
		sep = "\t";
	}*/
	var conCabecera = true;
	


	var f = new File(rutaF);
	try {
		f.open(File.ReadOnly);
		if(f.size == 0) {
			formUI.ponMsgWarn(sys.translate("Fichero vac�o"));			
			return false;
		}
	} catch(e) {
		formUI.ponMsgWarn(sys.translate("Error al abrir el fichero:\n%1").arg(rutaF));		
		return false;
	}		
	
	var steps = 0;
	while (!f.eof) {
		f.readLine();
		++steps;
	}
	f.close();

	f.open(File.ReadOnly);
	var longLinea = 26;
	
	var head = f.readLine().split(sep);	
	

	if (head.length != longLinea) {
		formUI.ponMsgWarn(sys.translate("El fichero csv %1 no contiene %2 columnas, contiene %3 columnas").arg(rutaF).arg(longLinea).arg(head.length));
		return false;
	}
	
	var oParam = new Object;
	oParam["errorMsg"] = sys.translate("Error al cargar el fichero csv %1.").arg(rutaF);
	oParam["cursor"] = cursor;
	oParam["f"] = f;
	oParam["steps"] = steps;
	oParam["sep"] = sep;
	oParam["longLinea"] = longLinea;
	var curR = cursor.cursorRelation();  
 	if (!curR || !curR.table() == "em_dropshipping") {	 		
 		curR = new FLSqlCursor("em_dropshipping");
 		curR.select("em_coddropshipping = '" + codDrop + "'");
 		if (!curR.first()) {
 			f.close();
 			return false;
 		}
 		curR.setModeAccess(curR.Edit);
		curR.refreshBuffer();
    }    
    oParam["curR"] = curR;    

	if (!sys.runTransaction(formRecordem_enviodropshipping.iface.cargaEnvios, oParam)) {
		f.close();
		return false;
	}
	f.close();
	this.child("tdbCargaEnviosDropshipping").refresh();
	this.child("tdbAvisosEnviosDropshipping").refresh();

	formUI.ponMsgInfo(sys.translate("Fichero cargado correctamente"));
}

function oficial_cargaEnvios(oParam)
{
	var _i = this.iface;

	var cursor = oParam["cursor"];
	var curR = oParam["curR"];
	var f = oParam.f;
	_i.utf8_ = this.child("cbCodificacion").currentText;
	//debug("\n\n\n UTF8: "+_i.utf8_);
	if (!AQUtil.execSql("DELETE FROM em_cargaenviosdropshipping WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
		formUI.ponMsgWarn(sys.translate("Error al borrar la carga anterior"));			
		return false;
	}

	if (!AQUtil.execSql("DELETE FROM em_avisosenviosdropshipping WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
		formUI.ponMsgWarn(sys.translate("Error al borrar la carga anterior"));			
		return false;
	}

	var i = {"pedidoprivalia" : 0, "cliente" : 1, "nombre" : 2, "direccion" : 3, "localidad" : 4, "provincia" : 5, "codpostal" : 6, "telefono1" : 7, "telefono2" : 8, "refstockprivalia" : 9, "ean" : 10, "sku" : 11, "articulo" : 12, "costeunitario" : 13, "costetotal" : 14, "descripcion" : 15, "unidadespedidas" : 16, "unidadesservidas" : 17, "carrier" : 18, "tracking" : 19, "infocarrier1" : 20, "infocarrier2" : 21, "infocarrier3" : 22, "infocarrier4" : 23, "infocarrier5" : 24, "pais" : 25};

	var l = 1;
	var codCliente = curR.valueBuffer("codcliente");
	var fecha = cursor.valueBuffer("fecha");
	var campo = "";
	AQUtil.createProgressDialog(sys.translate("Cargando fichero"), oParam.steps);
	var aLinea;
	var curCD = new FLSqlCursor("em_cargaenviosdropshipping");
	var refInterna, importeCalculado, ean, estado, descInterna;
	var sLinea = "";
	var qAC = new FLSqlQuery;
	qAC.setSelect("referencia, pvpeuromoda, descripcioncliente");
	qAC.setFrom("em_articuloscli");

	while(!f.eof) {
		AQUtil.setProgress(++l);
		sLinea = f.readLine();
		sLinea = sLinea.replace("\n","");
		sLinea = sLinea.replace("\r","");		
		if(!sLinea || sLinea == "") {
			continue;
		}
		aLinea = sLinea.split(oParam.sep);
		debug("aLinea: "+aLinea);
		if (!aLinea || aLinea.length != oParam.longLinea) {
			AQUtil.destroyProgressDialog();
			MessageBox.warning(sys.translate("La l�nea %1 del fichero no contiene %2 columnas").arg(l).arg(oParam.longLinea), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		if (aLinea[i["pedidoprivalia"]] == "") { /// Viene una �ltima l�nea solo con separadores
			continue;
		}
		curCD.setModeAccess(curCD.Insert);
		curCD.refreshBuffer();
		curCD.setValueBuffer("emcodenviodrop", cursor.valueBuffer("emcodenviodrop"));

		for (col in i) {
			//curCD.setValueBuffer(col, aLinea[i[col]].replace("\n",""));	
			campo = aLinea[i[col]].replace("\n","");
			if(campo == "") {	
				curCD.setNull(col);				
			} else {
				curCD.setValueBuffer(col, campo);	
				//debug("_i.utf8_ : "+_i.utf8_);
				/*if(_i.utf8_  == "UTF8") {	
					curCD.setValueBuffer(col,  sys.fromUnicode(campo,"utf8"));	
				} else {					
					curCD.setValueBuffer(col,  sys.fromUnicode(campo,"ISO-8859-1"));	
				}*/
			}
			
		}		

		refInterna = false;
		importeCalculado = false;
		qAC.setWhere("codcliente = '" + codCliente + "' AND referenciacliente = '" + aLinea[i["sku"]] + "'");
		//debug("qAC: "+qAC.sql());
		if (qAC.exec() && qAC.first()) {
			refInterna = qAC.value("referencia");
			//debug("1 refInterna: "+refInterna);
			importeCalculado = qAC.value("pvpeuromoda");
			descInterna = qAC.value("descripcioncliente");
			if(!descInterna || descInterna == "") {
				ean = aLinea[i["ean"]].left(13);
				descInterna = AQUtil.sqlSelect("articulos", "descripcion", "codbarras = '" + ean + "'");		
			}
		} else {
			ean = aLinea[i["ean"]].left(13);
			//debug("2 ean: "+ean);
			//refInterna = AQUtil.sqlSelect("articulos", "referencia", "codbarras = '" + ean + "'");

			var qRef = new AQSqlQuery;	
			qRef.setSelect("referencia, descripcion");
			qRef.setFrom("articulos");
			qRef.setWhere("codbarras = '" + ean + "'");				
			if (!qRef.exec()){
				return;
			}  
			if(qRef.first())
			{
				refInterna = qRef.value("referencia");
				//debug("3 refInterna: "+refInterna);
				descInterna = qRef.value("descripcion");
			} else {
			    
			    var refCSV = aLinea[i["articulo"]];
			    //debug("4 refCSV: "+refCSV);
			    var esNumero = true;
			    var digito;
			    referencia = "";
			    for (var k=0; k< refCSV.length && esNumero; k++) {
					digito = refCSV.charAt(k);
					if (!isNaN(digito)) {
				    
				    	referencia +=digito.toString();
					} else {
				    	esNumero = false;
					}			
			    }
			    var qRefAC = new AQSqlQuery;	
			    qRefAC.setSelect("referencia, codbarras");
			    qRefAC.setFrom("em_articuloscli");
			    qRefAC.setWhere("codcliente = '" + codCliente + "' AND (referencia = '" + referencia + "' OR referenciacliente = '" + referencia + "' OR codbarras = '" + referencia + "')");	
			    //debug("q2: "+qRefAC.sql());
			    if (!qRefAC.exec()){
					return;
			    }  
			    if(qRefAC.first())
			    {
					ean = qRefAC.value("codbarras");
					refInterna = qRefAC.value("referencia");
					//debug("5 ean: "+ean);
					//debug("6 refInterna: "+refInterna);
					descInterna = qAC.value("descripcioncliente");
					if(!descInterna || descInterna == "") {				   
				    	descInterna = AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + refInterna + "'");	
					}
			    } else {
			    	//debug("7A ean: "+ean);
			    	var qRef = new AQSqlQuery;	
					qRef.setSelect("referencia, descripcion, codbarras");
					qRef.setFrom("articulos");
					qRef.setWhere("referencia = '" + refCSV + "'");				
					//debug("qRef: "+qRef.sql());
					if (!qRef.exec()){
						return;
					}  
					if(qRef.first())
					{
						refInterna = qRef.value("referencia");
						descInterna = qRef.value("descripcion");
						ean = qRef.value("codbarras");
						//debug("7 ean: "+ean);
						//debug("8 refInterna: "+refInterna);
					}
			    }
				
			}	
			//debug("**********************************************************refInterna: "+refInterna);
			if (refInterna) {
				importeCalculado = formRecordlineaspedidoscli.iface.pub_damePrecioArticulo(refInterna, codCliente, fecha);
			}
		}
		if (refInterna) {
			curCD.setValueBuffer("refinterna", refInterna);
			curCD.setValueBuffer("descinterna", descInterna);

			estado = "Precio incorrecto";
		} else {
			estado = "No encontrado";
		}

		if (parseFloat(importeCalculado) && !isNaN(importeCalculado)) {
			curCD.setValueBuffer("importecalculado", importeCalculado);	
			if (importeCalculado == parseFloat(flfactppal.iface.reemplazoPuntosXcomas(aLinea[i["costeunitario"]]))) {
				estado = "OK";
			}
		}
		curCD.setValueBuffer("estado", estado);	
		curCD.setValueBuffer("ignorar", false);
		curCD.setValueBuffer("abrirlinea", false);

		var aviso = _i.gestionaAvisos(codCliente, curCD);

		if(aviso == 1) {
			curCD.setValueBuffer("ignorar", true);
		}

		if (!curCD.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			MessageBox.warning(sys.translate("Error al guardar la l�nea %1").arg(l), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}


	}
	if (!_i.totalizaEnvio(cursor)) {
		return false;
	}

	//AQUtil.execSql("update em_cargadropshipping set descripcion = convert_to(descripcion, 'latin-1') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	//AQUtil.execSql("update em_cargadropshipping set direccion = convert_from(   convert(   convert_to(direccion, 'utf-8'), 'utf-8', 'ISO-8859-1'), 'ISO-8859-1' ) WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	//AQUtil.execSql("update em_cargadropshipping set descripcion = convert(descripcion, 'UTF8','LATIN1') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	//AQUtil.execSql("update em_cargadropshipping set descripcion = convert_from(descripcion, UTF8) WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");


	if(_i.utf8_  == "UTF8") {	

		var codificacion = "";
		var plataforma = AQUtil.getOS();
		
		if (plataforma == "WIN32"){
			codificacion = "WIN1252";
		} else {
			codificacion = "LATIN9";
		}



		if(!AQUtil.execSql("update em_cargaenviosdropshipping set descripcion = convert_from( convert_to(descripcion, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea descripcion"),"warn",this);
			//return false;
		}
		
		if(!AQUtil.execSql("update em_cargaenviosdropshipping set direccion = convert_from( convert_to(direccion, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea direccion"),"warn",this);
			//return false;
		}		
		
		if(!AQUtil.execSql("update em_cargaenviosdropshipping set nombre = convert_from( convert_to(nombre, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea nombre"),"warn",this);
			//return false;
		}		

		if(!AQUtil.execSql("update em_cargaenviosdropshipping set localidad = convert_from( convert_to(localidad, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea localidad"),"warn",this);
			//return false;
		}

		if(!AQUtil.execSql("update em_cargaenviosdropshipping set provincia = convert_from( convert_to(provincia, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea provincia"),"warn",this);
			//return false;
		}

		if(!AQUtil.execSql("update em_cargaenviosdropshipping set infocarrier2 = convert_from( convert_to(infocarrier2, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea infoc2"),"warn",this);
			//return false;
		}


		if(!AQUtil.execSql("update em_avisosenviosdropshipping set descripcion = convert_from( convert_to(descripcion, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea descripcion"),"warn",this);
			//return false;
		}
		if(!AQUtil.execSql("update em_avisosenviosdropshipping set direccion = convert_from( convert_to(direccion, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea direccion"),"warn",this);
			//return false;
		}		
		
		if(!AQUtil.execSql("update em_avisosenviosdropshipping set nombre = convert_from( convert_to(nombre, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea nombre"),"warn",this);
			//return false;
		}		

		if(!AQUtil.execSql("update em_avisosenviosdropshipping set localidad = convert_from( convert_to(localidad, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea localidad"),"warn",this);
			//return false;
		}

		if(!AQUtil.execSql("update em_avisosenviosdropshipping set provincia = convert_from( convert_to(provincia, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea provincia"),"warn",this);
			//return false;
		}

		if(!AQUtil.execSql("update em_avisosenviosdropshipping set infocarrier2 = convert_from( convert_to(infocarrier2, '" + codificacion +"'),'UTF8') WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
			//flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea infoc2"),"warn",this);
			//return false;
		}	
		
	}
	//select descripcion, convert_from( convert_to(descripcion, 'LATIN9'),'UTF8') from em_cargadropshipping where coddropshipping = '000002';
//convert('text_in_utf8', 'UTF8', 'LATIN1')
//convert_from('text_in_utf8', 'UTF8')
	
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_pbGenerarAlb_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var curR = cursor.cursorRelation();  
 	if (!curR || !curR.table() == "em_dropshipping") {	 		
 		curR = new FLSqlCursor("em_dropshipping");
 		curR.select("em_coddropshipping = '" + cursor.valueBuffer("coddropshipping") + "'");
 		if (!curR.first()) {
 			return false;
 		}
 		curR.setModeAccess(curR.Edit);
		curR.refreshBuffer();
    }   



	var oParam = new Object;
	oParam["errorMsg"] = sys.translate("Error al generar albaranes.");
	oParam["cursor"] = cursor;	
	oParam["curR"] = curR;

	if (!sys.runTransaction(formRecordem_enviodropshipping.iface.generarAlbaranes, oParam)) {
		return false;
	}
	this.child("tdbCargaEnviosDropshipping").refresh();
	this.child("tdbAvisosEnviosDropshipping").refresh();

	formUI.ponMsgInfo(sys.translate("Albaranes generados correctamente"));

}

function oficial_generarAlbaranessssss(oParam)
{
	var _i = this.iface;
	var cursor = oParam["cursor"];
	var codEnvio = cursor.valueBuffer("emcodenviodrop");
	var aAlbaranes = [];

	var codCliente = oParam["curR"].valueBuffer("codcliente");
	var q = new AQSqlQuery;	
	q.setSelect("em_cerrarlindropcero, em_cerrarlindroppar");
	q.setFrom("clientes");
	q.setWhere("codcliente = '" + codCliente + "'"); 		
	if (!q.exec()){
		return;
	}  
	if(!q.first()) {
		formUI.ponMsgWarn(sys.translate("No existe el cliente. Error al obtener los datos del cliente"));
		return false;
	}	

	var cerrarLineasCero = q.value("em_cerrarlindropcero");
	var cerrarLineasPar = q.value("em_cerrarlindroppar");

	var oParamPed = new Object;
	oParamPed["cerrarLineasCero"] = cerrarLineasCero;
	oParamPed["cerrarLineasPar"] = cerrarLineasPar;
	oParamPed["codEnvio"] = codEnvio;



	var pedidoPrivalia,refInterna, unitServed, unidadesServidas, idPedido, idPedidoAnt, idLineaPedido, canAlbaran, unidadesPedidas;
	var aLineasPed = [];
	var oParamCan = [];
	var idCarEnv;	
	var p = 1;
	var q = new AQSqlQuery;	
	q.setSelect("carenv.id,carenv.pedidoprivalia, carenv.refinterna, carenv.unidadesservidas,car.unidadesservidas, car.idpedido, car.idlineapedido, carenv.id, car.unidadespedidas, carenv.abrirlinea, car.idpedido");
	q.setFrom("em_enviodropshipping env INNER JOIN em_cargaenviosdropshipping carenv ON carenv.emcodenviodrop = env.emcodenviodrop LEFT OUTER JOIN em_cargadropshipping car ON carenv.pedidoprivalia = car.pedidoprivalia AND carenv.refInterna = car.refInterna AND env.coddropshipping=car.coddropshipping");
	q.setWhere("env.emcodenviodrop = '" + codEnvio + "' AND carenv.unidadesservidas IS NOT NULL AND NOT carenv.ignorar order by car.idpedido, car.idlineapedido"); 		
	//debug("q: "+q.sql());		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		//debug("\n\n------------------------------------------------");
		//debug("linea "+p);
		idCarEnv = q.value("carenv.id");
		pedidoPrivalia = q.value("carenv.pedidoprivalia");		
		refInterna = q.value("carenv.refinterna");
		unitServed = q.value("carenv.unidadesservidas");
		idLineaPedido = q.value("car.idlineapedido"); 

		if(q.value("carenv.abrirlinea")) {
			//debug("hay que abrir la l�nea primero");
			_i.abrirLinea(idLineaPedido, q.value("car.idpedido"));
		}

		unidadesPedidas = q.value("car.unidadespedidas");  
		if(!unidadesPedidas || unidadesPedidas == "") {
			unidadesPedidas = 0;
		}
		unidadesServidas = q.value("car.unidadesservidas");
		if(!unidadesServidas || unidadesServidas == "") {
			unidadesServidas = 0;
		}
		idPedido = q.value("car.idpedido");
		/*debug("pedidoPrivalia: "+pedidoPrivalia);
		debug("refInterna: "+refInterna);
		debug("unitServed: "+unitServed);
		debug("idLineaPedido: "+idLineaPedido);
		debug("unidadesServidas: "+unidadesServidas);*/
		if(!idPedidoAnt || idPedidoAnt == "") {
			idPedidoAnt = idPedido;
			aLineasPed = [];
			if(!_i.vaciaCanAlbPedido(idPedido)) {
				debug("error 1");
				return false;
			}
		}
		if(idPedido != idPedidoAnt) {

			oParamPed["idPedido"] = idPedidoAnt;
			oParamPed["aLineasPed"] = aLineasPed;
			var idAlbaran = _i.sirvePedido(oParamPed);
			aLineasPed = [];
			
			if(!idAlbaran) {
				return false;
			} else if(idAlbaran != -1) {
				aAlbaranes.push(idAlbaran);	
			} else {
				if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
					return false;
				}
			}
			if(q.isNull(3) == "") {
				canAlbaran = "";
			} else {
				canAlbaran = parseFloat(unitServed) - parseFloat(unidadesServidas);

				oParamCan = [];
				oParamCan["idLineaPedido"] = idLineaPedido;
				oParamCan["canAlbaran"] = canAlbaran;
				oParamCan["idCarEnv"] = idCarEnv;
				oParamCan["idPedido"] = idPedido;
				/*if(parseFloat(unitServed) == 0 && cerrarLineasCero) {					
					debug("si true");
					oParamCan["cerrar"] = true;	
				} else if(parseFloat(canAlbaran) > 0 && parseFloat(canAlbaran) != parseFloat(unidadesPedidas) && cerrarLineasPar){
					debug("si true por parcial");
					oParamCan["cerrar"] = true;	
				} else {
					debug("no false");
					oParamCan["cerrar"] = false;
				}*/
				if(!_i.marcaCanAlbPedido(oParamCan)) {
					debug("error 4");
					return false;
				}
			}			 
			aLineasPed.push(idLineaPedido);
			idPedidoAnt = idPedido;
		} else {
			if(q.isNull(3)) {
				canAlbaran = "";
			} else {
				canAlbaran = parseFloat(unitServed) - parseFloat(unidadesServidas);
				oParamCan = [];
				oParamCan["idLineaPedido"] = idLineaPedido;
				oParamCan["canAlbaran"] = canAlbaran;
				oParamCan["idCarEnv"] = idCarEnv;
				oParamCan["idPedido"] = idPedido;
				/*debug("unitServed: "+parseFloat(unitServed));
				debug("parseFloat(canAlbaran): "+parseFloat(canAlbaran));
				debug("parseFloat(unidadesPedidas): "+parseFloat(unidadesPedidas));
				debug("cerrarLineasPar: "+cerrarLineasPar);*/
			



				/*if(parseFloat(unitServed) == 0 && cerrarLineasCero) {					
					oParamCan["cerrar"] = true;	
				} else if(parseFloat(canAlbaran) > 0 && parseFloat(canAlbaran) != parseFloat(unidadesPedidas) && cerrarLineasPar){
					oParamCan["cerrar"] = true;	
				} else {
					oParamCan["cerrar"] = false;
				}*/

				if(!_i.marcaCanAlbPedido(oParamCan)) {
					debug("error 5");
					return false;
				}
			} 
			aLineasPed.push(idLineaPedido);
		}
		p++;
	}	
	//sirvo el ultimo pedido
	if(idPedido) {	
		oParamPed["idPedido"] = idPedido;
		oParamPed["aLineasPed"] = aLineasPed;
		var idAlbaran = _i.sirvePedido(oParamPed);		
		if(!idAlbaran) {
			return false;
		} else if(idAlbaran != -1) {
			aAlbaranes.push(idAlbaran);	
		} else {
			if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
				return false;
			}
		}		
	}

	if(!_i.asociaAlbaranesEnvio(aAlbaranes, codEnvio)) {
		return false;
	}
	if (!_i.totalizaEnvio(cursor)) {
		return false;
	}
	return true;
}

function oficial_generarAlbaranes(oParam)
{
	var _i = this.iface;
	var cursor = oParam["cursor"];
	var codEnvio = cursor.valueBuffer("emcodenviodrop");
	var aAlbaranes = [];

	var codCliente = oParam["curR"].valueBuffer("codcliente");
	var q = new AQSqlQuery;	
	q.setSelect("em_cerrarlindropcero, em_cerrarlindroppar");
	q.setFrom("clientes");
	q.setWhere("codcliente = '" + codCliente + "'"); 		
	if (!q.exec()){
		return;
	}  
	if(!q.first()) {
		formUI.ponMsgWarn(sys.translate("No existe el cliente. Error al obtener los datos del cliente"));
		return false;
	}	

	var cerrarLineasCero = q.value("em_cerrarlindropcero");
	var cerrarLineasPar = q.value("em_cerrarlindroppar");

	var oParamPed = new Object;
	oParamPed["cerrarLineasCero"] = cerrarLineasCero;
	oParamPed["cerrarLineasPar"] = cerrarLineasPar;
	oParamPed["codEnvio"] = codEnvio;



	var pedidoPrivalia,refInterna, unitServed, unidadesServidas, idPedido, idPedidoAnt, idLineaPedido, canAlbaran, unidadesPedidas;
	var aLineasPed = [];
	var oParamCan = [];
	var idCarEnv;	
	var p = 1;
	var q = new AQSqlQuery;	
	q.setSelect("carenv.id,carenv.pedidoprivalia, carenv.refinterna, carenv.unidadesservidas,car.unidadesservidas, car.idpedido, car.idlineapedido, carenv.id, car.unidadespedidas, carenv.abrirlinea, car.idpedido");
	q.setFrom("em_enviodropshipping env INNER JOIN em_cargaenviosdropshipping carenv ON carenv.emcodenviodrop = env.emcodenviodrop LEFT OUTER JOIN em_cargadropshipping car ON carenv.pedidoprivalia = car.pedidoprivalia AND carenv.refInterna = car.refInterna AND env.coddropshipping=car.coddropshipping");
	q.setWhere("env.emcodenviodrop = '" + codEnvio + "' AND carenv.unidadesservidas IS NOT NULL AND NOT carenv.ignorar order by car.idpedido, car.idlineapedido"); 		
	//debug("q: "+q.sql());		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		//debug("\n\n------------------------------------------------");
		//debug("linea "+p);
		idCarEnv = q.value("carenv.id");
		pedidoPrivalia = q.value("carenv.pedidoprivalia");		
		refInterna = q.value("carenv.refinterna");
		unitServed = q.value("carenv.unidadesservidas");
		idLineaPedido = q.value("car.idlineapedido"); 

		if(q.value("carenv.abrirlinea")) {
			//debug("hay que abrir la l�nea primero");
			_i.abrirLinea(idLineaPedido, q.value("car.idpedido"));
		}

		unidadesPedidas = q.value("car.unidadespedidas");  
		if(!unidadesPedidas || unidadesPedidas == "") {
			unidadesPedidas = 0;
		}
		unidadesServidas = q.value("car.unidadesservidas");
		if(!unidadesServidas || unidadesServidas == "") {
			unidadesServidas = 0;
		}
		idPedido = q.value("car.idpedido");
		/*debug("pedidoPrivalia: "+pedidoPrivalia);
		debug("refInterna: "+refInterna);
		debug("unitServed: "+unitServed);
		debug("idLineaPedido: "+idLineaPedido);
		debug("unidadesServidas: "+unidadesServidas);*/
		if(!idPedidoAnt || idPedidoAnt == "") {
			idPedidoAnt = idPedido;
			aLineasPed = [];
			if(!_i.vaciaCanAlbPedido(idPedido)) {
				debug("error 1");
				return false;
			}
		}
		if(idPedido != idPedidoAnt) {
			//debug("\n-------1");
			oParamPed["idPedido"] = idPedidoAnt;
			oParamPed["aLineasPed"] = aLineasPed;
			var idAlbaran = _i.sirvePedido(oParamPed);
			//debug("idAlbaran: "+idAlbaran);
			aLineasPed = [];
			
			if(!idAlbaran) {
				return false;
			} else if(idAlbaran != -1) {
				aAlbaranes.push(idAlbaran);	
			} else {
				if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedidoAnt)) {
					debug("error 55");
					return false;
				}
			}
			//debug("q.isNull(3): "+q.isNull(3));
			if(q.isNull(3)) {
				canAlbaran = "";
				debug("canAlbaran en 1.1: "+canAlbaran);
			} else {
				canAlbaran = parseFloat(unitServed) - parseFloat(unidadesServidas);
				//debug("canAlbaran en 1.2: "+canAlbaran);
				oParamCan = [];
				oParamCan["idLineaPedido"] = idLineaPedido;
				oParamCan["canAlbaran"] = canAlbaran;
				oParamCan["idCarEnv"] = idCarEnv;
				oParamCan["idPedido"] = idPedido;
				
				if(!_i.marcaCanAlbPedido(oParamCan)) {
					debug("error 4");
					return false;
				}
			}			 
			aLineasPed.push(idLineaPedido);
			idPedidoAnt = idPedido;
		} else {
			//debug("\n-------2");
			//debug("q.isNull(3): "+q.isNull(3));
			if(q.isNull(3)) {
				canAlbaran = "";
				//debug("canAlbaran en 2.1: "+canAlbaran);
			} else {
				canAlbaran = parseFloat(unitServed) - parseFloat(unidadesServidas);
				//debug("canAlbaran en 2.2: "+canAlbaran);
				oParamCan = [];
				oParamCan["idLineaPedido"] = idLineaPedido;
				oParamCan["canAlbaran"] = canAlbaran;
				oParamCan["idCarEnv"] = idCarEnv;
				oParamCan["idPedido"] = idPedido;
				if(!_i.marcaCanAlbPedido(oParamCan)) {
					debug("error 5");
					return false;
				}
			} 
			aLineasPed.push(idLineaPedido);
		}
		p++;
	}	
	//sirvo el ultimo pedido
	if(idPedido) {	
		oParamPed["idPedido"] = idPedido;
		oParamPed["aLineasPed"] = aLineasPed;
		var idAlbaran = _i.sirvePedido(oParamPed);		
		if(!idAlbaran) {
			return false;
		} else if(idAlbaran != -1) {
			aAlbaranes.push(idAlbaran);	
		} else {
			if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
				return false;
			}
		}		
	}

	if(!_i.asociaAlbaranesEnvio(aAlbaranes, codEnvio)) {
		return false;
	}
	if (!_i.totalizaEnvio(cursor)) {
		return false;
	}
	return true;
}

function oficial_vaciaCanAlbPedido(idPedido)
{
	if (!AQUtil.execSql("UPDATE lineaspedidoscli set canalbaran = 0, incluiralbaran = false WHERE idpedido = " + idPedido)) {
		formUI.ponMsgWarn(sys.translate("Error al borrar la carga anterior"));			
		return false;
	}
	return true;
}

function oficial_marcaCanAlbPedido(oParamCan)
{
	//debug("marcaCanAlbPedido");
	var idLineaPedido = oParamCan["idLineaPedido"];
	var canAlbaran = oParamCan["canAlbaran"];
	var idCarEnv = oParamCan["idCarEnv"];
	var idPedido = oParamCan["idPedido"];

	/*debug("canAlbaran: "+canAlbaran);
	debug("idLineaPedido: "+idLineaPedido);
	debug("idPedido: "+idPedido);
	debug("idCarEnv: "+idCarEnv);*/

	//var cerrar = oParamCan["cerrar"];

	/*debug("idLineaPedido: "+idLineaPedido);
	debug("canAlbaran: "+canAlbaran);
	debug("idCarEnv: "+idCarEnv);
	debug("idPedido: "+idPedido);
	debug("cerrar: "+cerrar);
	*/


	//if(cerrar) {
		//cerramos linea
	//	if (!AQUtil.execSql("UPDATE lineaspedidoscli set cerrada = true WHERE idlinea = " + idLineaPedido)) {
	//		formUI.ponMsgWarn(sys.translate("Error al actualizar l�nea de pedido con cantidad a albaranar"));
	//		return false;
	//	}

	//} else {		
		if (!AQUtil.execSql("UPDATE lineaspedidoscli set canalbaran = " + canAlbaran + ", incluiralbaran = true WHERE idlinea = " + idLineaPedido)) {
			formUI.ponMsgWarn(sys.translate("Error al actualizar l�nea de pedido con cantidad a albaranar"));
			return false;
		}
	//}

	if (!AQUtil.execSql("UPDATE em_cargaenviosdropshipping set idlineapedido = " + idLineaPedido + ", idpedido = " + idPedido + " WHERE id = " + idCarEnv)) {
		formUI.ponMsgWarn(sys.translate("Error al actualizar l�nea de env�o con linea de pedido"));		
		return false;
	}

	
	return true;
}

function oficial_sirvePedido(oParam)
{
	var _i = this.iface;

	var idPedido = oParam["idPedido"];
	var aLineasPed = oParam["aLineasPed"];
	var idAlbaran = -1;
	if(AQUtil.sqlSelect("lineaspedidoscli","idlinea","idpedido = " + idPedido + " AND canalbaran > 0 AND incluiralbaran")) {
		var curPedido = new FLSqlCursor("pedidoscli");
		curPedido.select("idpedido = " + idPedido);
		if(!curPedido.first()) {
			debug("error 7");
			return false;
		}
		curPedido.setModeAccess(curPedido.Edit);
		curPedido.refreshBuffer();
		var codCliente = curPedido.valueBuffer("codcliente");
		//formpedidoscli.iface.silent_ = true;
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_ = true;
		idAlbaran = formpedidoscli.iface.pub_generarAlbaranParcial(curPedido);

		var codAlbaran = AQUtil.sqlSelect("albaranescli","codigo","idalbaran = " + idAlbaran);

		for(var i=0; i<aLineasPed.length;i++) {

			var idLineaAlbaran = AQUtil.sqlSelect("lineasalbaranescli la inner join lineaspedidoscli lp on la.idlineapedido = lp.idlinea","la.idlinea","la.idalbaran = " + idAlbaran + " AND lp.idlinea = " + aLineasPed[i],"lineasalbaranescli");	
			if(idLineaAlbaran) {			
				if (!AQUtil.execSql("UPDATE em_cargaenviosdropshipping set codalbaran = '" + codAlbaran + "', idlineaalbaran = " + idLineaAlbaran + " WHERE emcodenviodrop = '" + oParam["codEnvio"] + "' AND idlineapedido = " + aLineasPed[i])) {
					formUI.ponMsgWarn(sys.translate("Error al actualizar linea de carga"));			
					return false;
				}
			}
		}		
		if(idAlbaran && idAlbaran != 0){
			formpedidoscli.iface.idAlbaranC_ = idAlbaran;	
		}	
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_ = false;
		//formpedidoscli.iface.silent_ = false;
	}
	if(!_i.vaciaCanAlbPedido(idPedido)) {
		debug("error 8");
		//formpedidoscli.iface.silent_ = false;
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_ = false;
		return false;
	}

	if(!_i.compruebaCierrePedido(oParam)) {
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_ = false;
		return false;
	}
	formRecordpresupuestoscli.iface.ignorarAvisosCostes_ = false;
	return idAlbaran;
}

function oficial_asociaAlbaranesEnvio(aAlbaranes, codEnvio)
{
	if(aAlbaranes.length == 0) {
		return true;
	}
	var sAlbaranes = aAlbaranes.join(",");
	if (!AQUtil.execSql("UPDATE albaranescli SET emcodenviodrop = '" + codEnvio + "' WHERE idalbaran IN (" + sAlbaranes + ")")) {
		sys.warnMsgBox(sys.translate("Error al asociar los albaranes al env�o"));
		return false;	
	}
	return true;

}

function oficial_totalizaEnvio(cursor)
{
	var _i = this.iface;
	this.child("fdbNumeroEnvios").setValue(_i.commonCalculateField("numeroenvios",cursor));
	this.child("fdbUnidadesSer").setValue(_i.commonCalculateField("unidadesservidas",cursor));
	this.child("fdbUnidadesPendientes").setValue(_i.commonCalculateField("unidadespendientes",cursor));
	this.child("fdbNumCeros").setValue(_i.commonCalculateField("numceros",cursor));
	return true;
	 
}

function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
  	var valor;

	var cx; try { cx = cursor.connectionName();} catch(e) { cx = ""; }
	if(fN == "numeroenvios") {
		valor = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran","count(distinct(a.idalbaran))","a.emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'","albaranescli");
		if(!valor || valor == "") {
			valor = 0;
		}
	} else if(fN == "unidadesservidas") {
		valor = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran","SUM(l.cantidad)","a.emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'","albaranescli");
		if(!valor || valor == "") {
			valor = 0;
		}
	} else if(fN == "unidadespendientes") {
		var codDrop = cursor.valueBuffer("coddropshipping"); 
		var pedidasTotal = AQUtil.sqlSelect("pedidoscli p INNER JOIN lineaspedidoscli l ON l.idpedido = p.idpedido","SUM(l.cantidad)","p.em_coddropshipping = '" + codDrop + "'","pedidoscli");
		if(!pedidasTotal || pedidasTotal == "") {
			pedidasTotal = 0;
		}
		var servidasTotal = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran","SUM(l.cantidad)","a.em_coddropshipping = '" + codDrop + "'","albaranescli");
		if(!servidasTotal || servidasTotal == "") {
			servidasTotal = 0;
		}

		valor = parseFloat(pedidasTotal) - parseFloat(servidasTotal);
	} else if(fN == "numceros") {
		valor = AQUtil.sqlSelect("em_cargaenviosdropshipping","COUNT(*)","emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "' AND unidadesservidas = 0 ");
		if(!valor || valor == "") {
			valor = 0;
		}
	}
	return valor;
}

function oficial_dameColorCarga(fN, fV, cursor, fT, sel)
{
	var color = "";
	var codAlbaran = cursor.valueBuffer("codalbaran");	
	var unidadesPedidas = cursor.valueBuffer("unidadespedidas");
	var UNIT_SERVED = cursor.valueBuffer("unidadesservidas");
	var pendiente = parseFloat(unidadesPedidas) - parseFloat(UNIT_SERVED); 
	if(codAlbaran) {	
		if(cursor.isNull("unidadesservidas")) {
			color = "";
		} else if (Math.abs(pendiente) < 0.001) {
			color = flfactppal.iface.pub_dameColor("fondo_verde");
		} else if (UNIT_SERVED == 0) {
			color = flfactppal.iface.pub_dameColor("fondo_rojo");
		} else {
			color = flfactppal.iface.pub_dameColor("fondo_naranja");
		}
	} else {
		if(cursor.isNull("unidadesservidas")) {
			color = "";
		} else if (UNIT_SERVED == 0) {
			color = flfactppal.iface.pub_dameColor("fondo_rojo");
		}		
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}

}

function oficial_compruebaCierrePedido(oParamPed)
{

	var idPedido = oParamPed["idPedido"];
	var cerrarLineasCero = oParamPed["cerrarLineasCero"];
	var cerrarLineasPar = oParamPed["cerrarLineasPar"];
	var codEnvio = oParamPed["codEnvio"];

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al cerrar el pedido");
	oParam.idPedido = idPedido;	
	oParam.cerrar = true;	

	if(cerrarLineasCero) {

		/*if (!AQUtil.execSql("UPDATE lineaspedidoscli set cerrada = true FROM em_cargaenviosdropshipping WHERE lineaspedidoscli.idlinea = em_cargaenviosdropshipping.idlineapedido AND em_cargaenviosdropshipping.emcodenviodrop = '" + codEnvio + "' AND  lineaspedidoscli.idpedido = " + idPedido + " AND em_cargaenviosdropshipping.unidadesservidas = 0")) {
			formUI.ponMsgWarn(sys.translate("Error al cerrar l�nea del pedido"));
			return false;
		}*/	

		var q = new AQSqlQuery;	
		q.setSelect("l.idlinea");
		q.setFrom("em_cargaenviosdropshipping c INNER JOIN lineaspedidoscli l ON l.idlinea = c.idlineapedido");
		q.setWhere("c.emcodenviodrop = '" + codEnvio + "' AND  l.idpedido = " + idPedido + " AND c.unidadesservidas = 0"); 				
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			if(!AQUtil.sqlUpdate("lineaspedidoscli","cerrada",true,"idlinea = " + q.value("l.idlinea"))) {
				formUI.ponMsgWarn(sys.translate("Error al cerrar l�nea del pedido"));
				return false;
			}		
		}		

		if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
			return false;
		}

		
	} 

	if(cerrarLineasPar) {

		/*if (!AQUtil.execSql("UPDATE lineaspedidoscli set cerrada = true FROM em_cargaenviosdropshipping WHERE lineaspedidoscli.idlinea = em_cargaenviosdropshipping.idlineapedido AND em_cargaenviosdropshipping.emcodenviodrop = '" + codEnvio + "' AND  lineaspedidoscli.idpedido = " + idPedido + " AND em_cargaenviosdropshipping.unidadesservidas <> 0 AND lineaspedidoscli.cantidad <> lineaspedidoscli.totalenalbaran")) {
			formUI.ponMsgWarn(sys.translate("Error al cerrar l�nea del pedido"));
			return false;
		}*/


		
		
		
		var q = new AQSqlQuery;	
		q.setSelect("l.idlinea");
		q.setFrom("em_cargaenviosdropshipping c INNER JOIN lineaspedidoscli l ON l.idlinea = c.idlineapedido");
		q.setWhere("c.emcodenviodrop = '" + codEnvio + "' AND  l.idpedido = " + idPedido + " AND c.unidadesservidas <> 0 AND l.cantidad <> l.totalenalbaran"); 				
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			if(!AQUtil.sqlUpdate("lineaspedidoscli","cerrada",true,"idlinea = " + q.value("l.idlinea"))) {
				formUI.ponMsgWarn(sys.translate("Error al cerrar l�nea del pedido"));
				return false;
			}		
		}

		if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
			return false;
		}	
	}
	return true;

}

function oficial_gestionaAvisos(codCliente, curCD)
{
	var _i = this.iface;
	//hay que ver:
	//Si est� en otro drop para el mismo cliente, pedido, refinterna y no est� servido --> Miramos segun caso de excel, si hubiera que hacer algo ponemos aviso --> Requiere Acci�n: crguelo en el drop n� XXXX
	//Si no est� en otro drop del mismo cliente ni en este mismo dopr, con mismo cliente, pedido, refinterna --> AVISO linea huerfana --> Requiere Acci�n: No hay drop cargado para este pedido �lo ha generado?
	//

	var codDrop = this.cursor().valueBuffer("coddropshipping"); 
	var oParamAvisos = new Object;	
	var pedidoPrivalia = curCD.valueBuffer("pedidoprivalia");
	var refInterna= curCD.valueBuffer("refinterna");	
	var unitServed = curCD.valueBuffer("unidadesservidas");

	var codOtroDrop = "";
	var encontrado = false;
	var cerrarLineasPar = false;
	var cerrarLineasPar = false;
	var totalEnAlbaran = 0;
	var unidadesPedidas = 0;
	var cerrada = false;
	oParamAvisos["codDrop"] = codDrop;
	oParamAvisos["curCD"] = curCD;
	var q = new AQSqlQuery;	
	q.setSelect("d.codigo, c.idpedido, c.idlineapedido, d.codcliente, c.unidadesservidas, cli.em_cerrarlindropcero, cli.em_cerrarlindroppar, lin.cerrada, c.unidadespedidas, lin.totalenalbaran");
	q.setFrom("em_cargadropshipping c INNER JOIN em_dropshipping d ON c.coddropshipping = d.codigo INNER JOIN clientes cli ON cli.codcliente = d.codcliente INNER JOIN lineaspedidoscli lin ON lin.idlinea = c.idlineapedido");
	q.setWhere("d.codcliente = '" + codCliente + "' AND c.pedidoprivalia = '" + pedidoPrivalia + "' AND c.refinterna = '" + refInterna + "' AND c.idlineapedido IS NOT NULL AND c.idlineapedido <> 0"); 		
	if (!q.exec()){
		return;
	}  
	while(q.next()){
		encontrado = true;
		codOtroDrop = q.value("d.codigo");
		cerrarLineasCero = q.value("cli.em_cerrarlindropcero");
		cerrarLineasPar = q.value("cli.em_cerrarlindroppar");
		if(codOtroDrop != codDrop) {
			oParamAvisos["codOtroDrop"] = codOtroDrop;
			oParamAvisos["cerrarLineasCero"] = cerrarLineasCero;
			oParamAvisos["cerrarLineasPar"] = cerrarLineasPar;
			oParamAvisos["idLineaPedido"] = q.value("c.idlineapedido");
			oParamAvisos["unidadesServidas"] = q.value("c.unidadesservidas");
			return _i.gestionaAvisosCasos(oParamAvisos);		
		}  else {
			cerrada = q.value("lin.cerrada");
			totalEnAlbaran = q.value("lin.totalenalbaran");
			unidadesPedidas = q.value("c.unidadespedidas"); 
			if((cerrarLineasCero || cerrarLineasPar) && cerrada && parseFloat(unitServed) > 0 && parseFloat(totalEnAlbaran) == 0) {
				curCD.setValueBuffer("abrirlinea",true);
				oParamAvisos["tipoAviso"] = "AlbaranSobreLinCerrada";
				return _i.aniadeAviso(oParamAvisos);
			} else if(cerrarLineasPar && cerrada && unitServed >0 && parseFloat(totalEnAlbaran) >0 && parseFloat(unidadesPedidas) != parseFloat(totalEnAlbaran)) {
				oParamAvisos["tipoAviso"] = "LineaCerradaOtroFichero";
				return _i.aniadeAviso(oParamAvisos);
			} else if(parseFloat(unitServed) > parseFloat(unidadesPedidas)) {
				oParamAvisos["tipoAviso"] = "cantidadMayorPedida";
				return _i.aniadeAviso(oParamAvisos);
			}
		}		
	}
	if(!encontrado) {
		oParamAvisos["tipoAviso"] = "Huerfana";
		return _i.aniadeAviso(oParamAvisos);
	}
	return 0;
}

function oficial_gestionaAvisosCasos(oParamAvisos)
{
	var _i = this.iface;
	var avisa = false;
	var curCD = oParamAvisos["curCD"];
	var idLineaPedido = oParamAvisos["idLineaPedido"];
	var cerrarLineasCero = oParamAvisos["cerrarLineasCero"];
	var cerrarLineasPar = oParamAvisos["cerrarLineasPar"];
	//1. Si esta servida la linea no metemos aviso	
	if(idLineaPedido && idLineaPedido != "") {		
		//debug("cantidad-totalenalbaran: "+AQUtil.sqlSelect("lineaspedidoscli","cantidad-totalenalbaran","idlinea = " + idLineaPedido));
		if(AQUtil.sqlSelect("lineaspedidoscli","idlinea","cantidad-totalenalbaran = 0 AND idlinea = " + idLineaPedido)) {
			return 0;
		}
	}
	if(curCD.isNull("unidadesservidas")) {
		return 0;
	}
	var unitServed = curCD.valueBuffer("unidadesservidas");
	var unidadesServidas = oParamAvisos["unidadesServidas"];
	if(!unidadesServidas || unidadesServidas == "") {
		unidadesServidas = 0;
	}
	var canAlbaran = parseFloat(unitServed) - parseFloat(unidadesServidas); 

	//2. No est� servida, vamos a ver seg�n casos si habria que hacer algo
	if(parseFloat(unitServed) == 0 && cerrarLineasCero) {					
		avisa = true;
	} else if(canAlbaran > 0 && cerrarLineasPar){
		avisa = true;	
	} else if(canAlbaran > 0) {
		avisa = true;
	}
	if(avisa) {
		oParamAvisos["tipoAviso"] = "AccionCaso";
		return _i.aniadeAviso(oParamAvisos);
	} 
	return 0;
}

function oficial_aniadeAviso(oParam)
{

	var tipoAviso = oParam["tipoAviso"];
	var motivo = "";
	var ignorar = true; 

	if(tipoAviso == "Huerfana") {
		motivo = "Requiere Acci�n: No hay drop cargado para este pedido. �Lo ha generado?";
	} else if(tipoAviso == "AccionCaso") {
		motivo = "Requiere Acci�n: C�rguelo en el drop n� " +  oParam["codOtroDrop"];
	} else if(tipoAviso == "AlbaranSobreLinCerrada") {
		motivo = "Informativo: Albar�n generado sobre l�nea cerrada";
		ignorar = false;
	} else if(tipoAviso == "cantidadMayorPedida"){
		motivo = "Requiere Acci�n: SIRVE M�S CANTIDAD. AVISAR URGENTE AL RESPONSABLE DE ENVIOS DEL DROP PARA RECTIFICARLO";
	} else if (tipoAviso == "LineaCerradaOtroFichero") {
		motivo = "Requiere Acci�n: L�NEA CERRADA CON OTRO FICHERO. AVISAR URGENTE AL RESPONSABLE DE ENV�OS DEL DROP PARA RECTIFICARLO SI PROCEDE EN EL ALBAR�N.";
	} else {
		motivo = "Requiere Acci�n";
	}

	var curCD = oParam["curCD"];	
	var curA = new FLSqlCursor("em_avisosenviosdropshipping");
	curA.setModeAccess(curCD.Insert);
	curA.refreshBuffer();	

	var campos = AQUtil.nombreCampos("em_cargaenviosdropshipping");
	var totalCampos = campos[0];
	for (var i = 1; i <= totalCampos; i++) {
		if(campos[i] == "id") {			
			continue;
		}
		if (curCD.isNull(campos[i])) {
			curA.setNull(campos[i]);
		} else {
			curA.setValueBuffer(campos[i], curCD.valueBuffer(campos[i]));
		}	
	}
	curA.setValueBuffer("motivo", motivo);
	if(!curA.commitBuffer()) {
		return false;
	}
	if(ignorar) {
		return 1;
	}
	return 0;
}

function oficial_abrirLinea(idLineaPedido, idPedido)
{
	if (!AQUtil.execSql("UPDATE lineaspedidoscli set cerrada = false  WHERE idlinea = " + idLineaPedido)) {
		formUI.ponMsgWarn(sys.translate("Error al abrir l�nea del pedido"));
		return false;
	}
	if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
		return false;
	}
	return true;

}
//// OFICIAL  ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
