
/** @class_declaration euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////////
class euromoda extends oficial {
	var pK_;
	function euromoda( context ) { oficial( context ); } 
	function init() {
		this.ctx.euromoda_init();
	}
	function calculateCounter(curLS) {
		return this.ctx.euromoda_calculateCounter(curLS);
	}
	function guardaDocumentoCommit() {
		return this.ctx.euromoda_guardaDocumentoCommit();
	}
	function calculaReservasDerivadas() {
		return this.ctx.euromoda_calculaReservasDerivadas();
	}
	function ordenarColumnas() {
		return this.ctx.euromoda_ordenarColumnas();
	}
	function ordenarColumnasLotes() {
		return this.ctx.euromoda_ordenarColumnasLotes();
	}
}
//// EUROMODA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	_i.pK_ = cursor.valueBuffer(cursor.primaryKey());	
	connect(this.child("tdbLineasRegStocks").cursor(), "commited()", _i, "guardaDocumentoCommit()");
	connect(this.child("tdbRegLoteStock").cursor(), "commited()", _i, "guardaDocumentoCommit()");
	//connect(this.child("tdbLineasRegStocks").cursor(), "bufferCommited()", _i, "calculaReservasDerivadas()");144063
	_i.ordenarColumnas();
	_i.ordenarColumnasLotes();


}

function euromoda_ordenarColumnas()
{
	var tdbLC = this.child("tdbLineasRegStocks");
	var dtbLC = this.mainWidget().child("tdbLineasRegStocks").tableRecords();

	var listaCampos;
	try {	
		//listaCampos = ["fecha", "hora", "impreso", "editable"];
		//tdbLC.setOrderCols(listaCampos);	
		tdbLC.autoSortColumn = false;
		var hHeader = dtbLC.horizontalHeader();
		hHeader.setClickEnabled(false);
		hHeader.setSortIndicator(-1, AQS.Ascending);
		dtbLC.setSort(["fecha", "hora","fechamod", "horamod"]);	
	}
	catch (e) {
		//listaCampos = ["codigo", "impreso", "editable", "fecha"];
		//tdbLC.setOrderCols(listaCampos);

	}    
	dtbLC.refresh(AQS.RefreshData);
}

function euromoda_ordenarColumnasLotes()
{
	var tdbLC = this.child("tdbRegLoteStock");
	var dtbLC = this.mainWidget().child("tdbRegLoteStock").tableRecords();

	var listaCampos;
	try {	
		//listaCampos = ["fecha", "hora", "impreso", "editable"];
		//tdbLC.setOrderCols(listaCampos);	
		tdbLC.autoSortColumn = false;
		var hHeader = dtbLC.horizontalHeader();
		hHeader.setClickEnabled(false);
		hHeader.setSortIndicator(-1, AQS.Ascending);
		dtbLC.setSort(["fecha", "hora","fechamod", "horamod"]);	
	}
	catch (e) {
		//listaCampos = ["codigo", "impreso", "editable", "fecha"];
		//tdbLC.setOrderCols(listaCampos);

	}    
	dtbLC.refresh(AQS.RefreshData);
}




function euromoda_calculateCounter(curLS)
{
	var _i = this.iface;	
	
	var ultimoInv = AQUtil.sqlSelect("em_secuenciasinv","valor","1=1");

	if (!ultimoInv) {
		var idUltimo = AQUtil.sqlSelect("inventarios", "codinventario"," 1=1 ORDER BY codinventario DESC");
		if(idUltimo && idUltimo != "") {
			ultimoInv = parseFloat(idUltimo);	
		} else {
			ultimoInv = 0;	
		}
		
		ultimoInv += 1;
		AQSql.insert("em_secuenciasinv", ["valor"], [ultimoInv]);
	} else {
		ultimoInv += 1;		
		AQSql.update("em_secuenciasinv", ["valor"], [ultimoInv], "1 = 1");
	}

	var codigo =flfacturac.iface.pub_cerosIzquierda((ultimoInv).toString(), 6);
	return codigo;
}

function euromoda_guardaDocumentoCommit()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() != cursor.Edit) {
		return true;
	}

	if (!_i.validateForm(cursor)) {
		return false;
	}
	if (!cursor.commitBuffer()) {
		return false;
	}
	cursor.commit();
	cursor.transaction(false);
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
	if (cursor.valueBuffer(cursor.primaryKey()) != _i.pK_) {
		cursor.select(cursor.primaryKey() + " = " + _i.pK_);
		if (!cursor.first()) {
			sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
			return false;
		}
		cursor.setModeAccess(cursor.Edit);
		cursor.refreshBuffer();
	}
}

function euromoda_calculaReservasDerivadas()
{
	var _i = this.iface;
	var cursor = this.child("tdbLineasRegStocks").cursor();	
	if (!flfactalma.iface.calculaReservasStockDerivadas(cursor.valueBuffer("idstock"), 0, 0, undefined)) {			
		return false;
	}
	if (!flfactalma.iface.procesaStocks()) {
		return false;
	}
	
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
