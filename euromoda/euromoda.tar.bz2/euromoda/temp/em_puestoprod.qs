/***************************************************************************
                 em_puestoprod.qs  -  description
                             -------------------
    begin                : mar may 9 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var usuarioActual_;
	var oColorLinea_, codAsigConfAnt_;
	var codMaquina_;
	var oEstado_;
	var contador_;
	var estado_;
	var tipoProduccion_;
	function oficial( context ) { interna( context ); }
	function dameColorLinea(fN, fV, cursor, sel, fT) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, sel, fT);
	}
	function tbnCambiarUsuario_clicked() {
		return this.ctx.oficial_tbnCambiarUsuario_clicked();
	}
	function muestraUsuarioActual() {
		return this.ctx.oficial_muestraUsuarioActual();
	}
	function filtra() {
		return this.ctx.oficial_filtra();
	}
	function filtraPtes() {
		return this.ctx.oficial_filtraPtes();
	}
	function dameFiltro() {
		return this.ctx.oficial_dameFiltro();
	}
	function dameFiltroProducidos() {
		return this.ctx.oficial_dameFiltroProducidos();
	}
	function trProduceLote(oParam) {
		return this.ctx.oficial_trProduceLote(oParam);
	}
	function controlFinTarea(codOrden) {
		return this.ctx.oficial_controlFinTarea(codOrden);
	}
	function tbnBorraFiltro_clicked() {
		return this.ctx.oficial_tbnBorraFiltro_clicked();
	}
	function ledCodOrden_returnPressed() {
		return this.ctx.oficial_ledCodOrden_returnPressed();
	}
	function anchuraCols() {
		return this.ctx.oficial_anchuraCols();
	}
	function cargaComboMaquina() {
		return this.ctx.oficial_cargaComboMaquina();
	}
	function cbMaquina_activated() {
		return this.ctx.oficial_cbMaquina_activated();
	}
	function asignaMaquina(codMaquina) {
		return this.ctx.oficial_asignaMaquina(codMaquina);
	}
	function tbnPlay_clicked() {
		return this.ctx.oficial_tbnPlay_clicked();
	}
	function tbnPause_clicked() {
		return this.ctx.oficial_tbnPause_clicked();
	}
	function tbnRev_clicked() {
		return this.ctx.oficial_tbnRev_clicked();
	}
	function procesaEstado() {
		return this.ctx.oficial_procesaEstado();
	}
	function actualizaEstadoOrden(codOrden, estado) {
		return this.ctx.oficial_actualizaEstadoOrden(codOrden, estado);
	}
	function actualizaLoteActMaq(codLote) {
		return this.ctx.oficial_actualizaLoteActMaq(codLote);
	}
	function produceLote(estadoLote) {
		return this.ctx.oficial_produceLote(estadoLote);
	}
	function dameTipoTareasMaq() {
		return this.ctx.oficial_dameTipoTareasMaq();
	}
	function tbnAparcar_clicked() {
		return this.ctx.oficial_tbnAparcar_clicked();
	}
	function tbnDesAparcar_clicked() {
		return this.ctx.oficial_tbnDesAparcar_clicked();
	}
	function gestionaAparcar(aparcar)  {
		return this.ctx.oficial_gestionaAparcar(aparcar) ;
	}
	function cargaImagen() {
		return this.ctx.oficial_cargaImagen();
	}
	function borraImagen() {
		return this.ctx.oficial_borraImage();
	}
	function tbnRefresca_clicked() {
		return this.ctx.oficial_tbnRefresca_clicked();
	}
	function pbnIncidencia_clicked() {
	    return this.ctx.oficial_pbnIncidencia_clicked();
	}
	function miroRegistrosTableDBRecords(){
		return this.ctx.oficial_miroRegistrosTableDBRecords();
	}
	/*function unidadesYMetrosPtesOP(codOrden){
		return this.ctx.oficial_unidadesYMetrosPtesOP(codOrden);
	}*/
	function calculaCantidadPte(codOrden){
		return this.ctx.oficial_calculaCantidadPte(codOrden);
	}
	function tbnReabrir_clicked() {
		return this.ctx.oficial_tbnReabrir_clicked();
	}
	function trReabrir(oParam) {
		return this.ctx.oficial_trReabrir(oParam);
	}
	function tbnOK_clicked() {
		return this.ctx.oficial_tbnOK_clicked();
	}
	function pbnImagen_clicked() {
		return this.ctx.oficial_pbnImagen_clicked();
	}
	
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
	function pub_trProduceLote(oParam) {
		return this.trProduceLote(oParam);
	}
	function pub_dameTipoTareasMaq() {
		return this.dameTipoTareasMaq();	
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	if (_i.oEstado_ == undefined) {
		_i.oEstado_ = new Object;
	}
	var e = _i.oEstado_;
	e.msg = sys.translate("Listo...");
	e.estado = "Listo";

	connect(this.child("tbnCambiarUsuario"), "clicked()", _i, "tbnCambiarUsuario_clicked");
	connect(this.child("tbnOK"), "clicked()", _i, "tbnOK_clicked");	
	connect(this.child("tbnReabrir"), "clicked()", _i, "tbnReabrir_clicked");
	connect(this.child("tbnBorraFiltro"), "clicked()", _i, "tbnBorraFiltro_clicked");
	connect(this.child("ledCodOrden"), "returnPressed()", _i, "ledCodOrden_returnPressed");
	//connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tbnOK_clicked");
	//connect(this.child("tdbLotesProducidos").cursor(), "recordChoosed()", _i, "tbnReabrir_clicked");
	connect(this.child("cbMaquina"), "activated(QString)", _i, "cbMaquina_activated");
	connect(this.child("tbnPlay"), "clicked()", _i, "tbnPlay_clicked");
	connect(this.child("tbnPausa"), "clicked()", _i, "tbnPause_clicked");
	connect(this.child("tbnRev"), "clicked()", _i, "tbnRev_clicked");
	connect(this.child("tbnAparcar"), "clicked()", _i, "tbnAparcar_clicked");
	connect(this.child("tbnDesAparcar"), "clicked()", _i, "tbnDesAparcar_clicked");
	//connect(this.child("tableDBRecords"), "currentChanged()", _i, "procesaEstado");  14-03-2018 se comenta porque se mete en bucle infinito en algunas ocasiones.
	connect(this.child("pbnIncidencia"), "clicked()", _i, "pbnIncidencia_clicked");
	connect(this.child("tbnRefresca"), "clicked()", _i, "tbnRefresca_clicked");
	connect(this.child("tableDBRecords"), "currentChanged()", _i, "cargaImagen");
	connect(this.child("pbnImagen"), "clicked()", _i, "pbnImagen_clicked");

	this.child("tdbLotesProducidos").cursor().setMainFilter("1 = 2");
	//this.child("tdbLotesProducidos").refresh();
	this.child("tableDBRecords").cursor().setMainFilter("1 = 2");
	//this.child("tableDBRecords").refresh();

	flprodppal.iface.pub_formatoTablaProd(this.mainWidget().child("tdbLotesProducidos").tableRecords());
	flprodppal.iface.pub_formatoTablaProd(this.mainWidget().child("tableDBRecords").tableRecords());
	
	_i.anchuraCols();
	if (!_i.cargaComboMaquina()) {
		this.close();
		return false;
	}
	var codMaquina = this.child("cbMaquina").currentText;
	_i.asignaMaquina(codMaquina);

	_i.procesaEstado();

	this.child("tbnRev").close();
	_i.miroRegistrosTableDBRecords();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_dameColorLinea(fN, fV, cursor, sel, fT)
{
	
	var _i = this.iface;
	var color = "";
	var aparcado = cursor.valueBuffer("em_aparcado");		
	if(aparcado) {	
			
		color = flfactppal.iface.pub_dameColor(sel ? "fondo_naranja" : "fondo_amarillo");
	}
	
	if (color != "") {
		var a = [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}




	/*if (!sel && codAsigConf == _i.codAsigConfAnt_) {
		return _i.oColorLinea_;
	}
	if (!sel) {
		_i.codAsigConfAnt_ = codAsigConf;
	} else {
		_i.codAsigConfAnt_ = -1;
	}
	var color = "";
	if (cursor.valueBuffer("estado") == "Enviada") {
		color = flfactppal.iface.pub_dameColor(sel ? "fondo_azul_sel" : "fondo_azul");
	} else {
		color = flfactppal.iface.pub_dameColor(sel ? "fondo_gris_sel" : "fondo_gris");
	}
	if (color != "") {
		_i.oColorLinea_ = [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
		return _i.oColorLinea_;
	} else {

		_i.codAsigConfAnt_ = -1;
	}*/
}

function oficial_tbnCambiarUsuario_clicked()
{
	var _i = this.iface;
	
	var f = new FLFormSearchDB("pr_bustrabajador");
	var curU = f.cursor();
	
	f.setMainWidget();
	var idUsuario = f.exec("idtrabajador");

	if (!idUsuario) {
		return;
	}
	_i.usuarioActual_ = idUsuario;
	_i.muestraUsuarioActual();
}

function oficial_muestraUsuarioActual()
{
	var _i = this.iface;
	var usuario;
	if (_i.usuarioActual_) {
		var n = AQUtil.sqlSelect("pr_trabajadores", "nombre", "idtrabajador = '" + _i.usuarioActual_ + "'");
		usuario = n + " (" + _i.usuarioActual_ + ")";
	} else {
		usuario = sys.translate("Usuario actual no establecido");
	}
	sys.setObjText(this, "lblUsuario", usuario);
}

function oficial_filtra()
{
	var _i  = this.iface;

	_i.filtraPtes();

	var fC = _i.dameFiltroProducidos();
	this.child("tdbLotesProducidos").cursor().setMainFilter(fC);
	this.child("tdbLotesProducidos").refresh();
	_i.miroRegistrosTableDBRecords();
	// 	flprodppal.iface.pub_alturaFilas(this.c);
}

function oficial_filtraPtes()
{
	var _i  = this.iface;

	var f = _i.dameFiltro();

	//debug("filtroptes: "+f);

	this.child("tableDBRecords").cursor().setMainFilter(f);
	this.child("tableDBRecords").refresh();
	// 	flprodppal.iface.pub_alturaFilas(this.child("tableDBRecords"));
}

function oficial_dameFiltro()
{
	var _i = this.iface;
	var tipoTareas = _i.dameTipoTareasMaq();

	var   f = "lotesstock.estado = 'PTE' AND (pr_tareas.estado = 'PTE' OR pr_tareas.estado = 'EN CURSO')  AND pr_ordenesproduccion.em_codmaquinacol = '" + _i.codMaquina_ + "' AND pr_tareas.idtipotarea IN (" + tipoTareas + ")";
	var codProd = this.child("ledCodOrden").text;
	if (codProd && codProd != "") {
		f += (" AND codordenproduccion LIKE '%" + codProd + "%'");
	}
	return f;
}

function oficial_dameFiltroProducidos()
{////////////////////////////////////////////////////////////////////////////////////////////////////
	var _i = this.iface;
	var tipoTareas = _i.dameTipoTareasMaq();
	var   f = "lotesstock.estado = 'PROCESADO' AND pr_ordenesproduccion.estado <> 'TERMINADA' AND pr_ordenesproduccion.em_codmaquinacol = '" + _i.codMaquina_ + "' AND pr_tareas.idtipotarea IN (" + tipoTareas + ")";
	var codProd = this.child("ledCodOrden").text;
	if (codProd && codProd != "") {
		//si la orden esta activa pertenece a la orden buscada
		f += (" AND codordenproduccion LIKE '%" + codProd + "%'");		   
	}
  	return f;  
}

function oficial_dameTipoTareasMaq()
{
	var _i = this.iface;

	var tipoTareas = AQUtil.sqlSelect("em_maquinascol", "tipotareas", "codmaquinacol='"+_i.codMaquina_+"'");
	
	var aTipoTareas = tipoTareas.split(",");
 	tipoTareas = "'" + aTipoTareas.join("', '") + "'";

 	return tipoTareas;

}

function oficial_tbnOK_clicked()
{
	var _i = this.iface;

	var e = _i.oEstado_;
	e.valorFinal = 0;
	e.valorInicial = 0;
	
	_i.produceLote("PROCESADO_OK");
	return true;
}

function oficial_produceLote(estadoLote)
{
	var _i = this.iface;
	_i.estado_ = "PTE";
	var cursor = this.cursor();
	var e = _i.oEstado_;
	var idUsuario = _i.usuarioActual_;
	if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
	}

	var f;
	//debug("\n\ntipoproduccion: "+_i.tipoProduccion_);
	if(_i.tipoProduccion_ == "Metros") {
		f = new FLFormSearchDB("em_metrospuestoprod");
	} else {
		f = new FLFormSearchDB("em_cantidadpuestoprod");
	}
	var curCPR = f.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();
	curCPR.select("sesion = '" + sesion + "'");
	if (curCPR.first()) {
		curCPR.setModeAccess(curCPR.Edit);
	} else {
		curCPR.setModeAccess(curCPR.Insert);
	}

	var canProdAnt = cursor.valueBuffer("em_canprod");
	if (!canProdAnt || canProdAnt == "") {
		canProdAnt = 0;
	}
	var canProdAntM = AQUtil.sqlSelect("lotesstock", "em_metrosprod", "codlote = '" + cursor.valueBuffer("codlote") + "'");
	if (!canProdAntM || canProdAntM == "") {
		canProdAntM = 0;
	}	

	curCPR.refreshBuffer();
	curCPR.setValueBuffer("sesion", sesion);
	curCPR.setValueBuffer("idusuario", idUsuario);
	curCPR.setValueBuffer("referencia", cursor.valueBuffer("referencia"));
	curCPR.setValueBuffer("canprogramada", cursor.valueBuffer("canprogramada"));
	curCPR.setValueBuffer("canproducida2", e.valorFinal - e.valorInicial);
	curCPR.setValueBuffer("canproducida", 0);
	/*if (estadoLote == "PROCESADO_OK") {
		curCPR.setValueBuffer("canproducidaant", 0);
		curCPR.setValueBuffer("canproducidaant2", 0);
	} else {
	*/	if (_i.tipoProduccion_ == "Metros") {
			curCPR.setValueBuffer("canproducidaant2", canProdAntM);
		} else {
			curCPR.setValueBuffer("canproducidaant", canProdAnt);
		}
	//}

	f.setMainWidget();
	idUsuario= f.exec("idusuario");
	if (!idUsuario) {
		return;
	}
	if (!curCPR.commitBuffer()) {
		return;
	}


	var oParam = new Object;
	oParam.canProducida = curCPR.valueBuffer("cantotalnueva");
//debug("curPCR Cantotalnueva = " + curCPR.valueBuffer("cantotalnueva"));
	oParam.canProducidaM = curCPR.valueBuffer("cantotalnueva2");
	oParam.canProgramada = curCPR.valueBuffer("canprogramada");
	oParam.idUsuario = idUsuario;
	oParam.codLote = cursor.valueBuffer("codlote");
	oParam.codOrden = cursor.valueBuffer("codordenproduccion");

	oParam.estado = estadoLote;
	var codOrden = cursor.valueBuffer("codordenproduccion");

	oParam.errorMsg = sys.translate("Error al marcar el lote %1 como producido").arg(oParam.codLote);
	oParam.msg = ""
	var f = new Function("oParam", "return formem_puestoprod.iface.trProduceLote(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	if(oParam.msg != "") {

		sys.infoMsgBox(oParam.msg);
	}

	this.child("tableDBRecords").refresh();
	this.child("tdbLotesProducidos").refresh();	
	_i.tbnRefresca_clicked();

}

function oficial_controlFinTarea(codOrden)
{
	var _i = this.iface;
	if (AQUtil.sqlSelect("lotesstock", "codlote", "codordenproduccion = '" + codOrden + "' AND estado <> 'PROCESADO'")) {
		return true;
	}
	
	var f = new FLFormSearchDB("em_resumenpuestoprod");
	var curOP = f.cursor();

	curOP.select("codorden = '" + codOrden + "'");
	if (!curOP.first()) {
		return false;
	}
	curOP.setModeAccess(curOP.Edit);
	curOP.refreshBuffer();

	f.setMainWidget();
	var codOrdenOK = f.exec("codorden");
	if (!codOrdenOK) {
		return false;
	}
	_i.tbnRefresca_clicked();
	return true;
}

function oficial_trProduceLote(oParam)
{
	var _i = this.iface;
	var msg = "";
	var codLote = oParam.codLote;
	var idUsuario = oParam.idUsuario;

	var canProducida = oParam.canProducida;
	var canProducidaM = oParam.canProducidaM;
	var canProgramada = oParam.canProgramada;

	var codOrden = oParam.codOrden;

	var hoy = new Date;

	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("codlote = '" + codLote + "'");
	if (!curLote.first()) {
		oParam.errorMsg = sys.translate("Error al localizar el lote %1").arg(codLote);
		return false;
	}
	curLote.setModeAccess(curLote.Edit);
	curLote.refreshBuffer();
	curLote.setValueBuffer("em_canprod", canProducida);	
	curLote.setValueBuffer("em_metrosprod", canProducidaM);	
	curLote.setValueBuffer("idusuarioprocesado", idUsuario);
	curLote.setValueBuffer("fechaprocesado", hoy.toString().left(10));
	curLote.setValueBuffer("horaprocesado", hoy.toString().right(8));


	//debug("canProgramada " + canProgramada);
	//debug("canProducida " + canProducida);

	
	if(parseFloat(canProgramada) <= parseFloat(canProducida) || oParam.estado == "PROCESADO_OK"){	
		curLote.setValueBuffer("canlote", canProducida);
//debug("Establezco canlote a " + canProducida);
		curLote.setValueBuffer("estado", "PROCESADO");
		msg = sys.translate("El lote %1 ha sido marcado como PRODUCIDO correctamente").arg(oParam.codLote);

	} else {
		curLote.setValueBuffer("estado", "PTE");
		msg = sys.translate("El lote %1 ha sido marcado como PTE").arg(oParam.codLote);
	}
	var codOrden = curLote.valueBuffer("codordenproduccion");
	if (!curLote.commitBuffer()) {
		oParam.errorMsg = sys.translate("Error al marcar el lote %1 como PROCESADO").arg(codLote);
			return false;
	}
	if (oParam.estado != "PROCESADO") {
		//debug("1111111111111111111");
		AQS.Application_restoreOverrideCursor();
		if (!_i.controlFinTarea(codOrden)) {
			oParam.errorMsg = sys.translate("Error al confirmar el procesado de la orden %1").arg(codOrden);
			return false;
		}
	} else {
		//debug("2222222222222222222222222222");
		if(parseFloat(canProgramada) > parseFloat(canProducida)){		
			//debug("33333333333333333333333333333333333");
			var tipoTareas = _i.dameTipoTareasMaq();
			var curTareas = new FLSqlCursor("pr_tareas");
			curTareas.select("pr_tareas.idobjeto = '" + codOrden + "' AND idtipotarea IN (" + tipoTareas + ") AND estado = 'TERMINADA' ORDER BY idtarea desc");
			if (!curTareas.first()) {
				return true;	
			}
			curTareas.setModeAccess(curTareas.Edit);
			curTareas.refreshBuffer();
			flcolaproc.iface.pub_deshacerTareaTerminada(curTareas);

			curTareas.select("pr_tareas.idobjeto = '" + codOrden + "' AND idtipotarea IN (" + tipoTareas + ") AND estado = 'EN CURSO' ORDER BY idtarea desc");
			if (!curTareas.first()) {
				return true;	
			}
			curTareas.setModeAccess(curTareas.Edit);
			curTareas.refreshBuffer();
			flcolaproc.iface.pub_deshacerTareaEnCurso(curTareas);
		}

	}
	_i.calculaCantidadPte(codOrden);
	oParam.msg = msg;
	
	return true;
}

/*function oficial_tbnReabrir_clicked()
{
//VER POR QUE SE CAMBIA LA PROGRAMADA Y VER QUE CARGAR MEJOR Y QUE CAMPO HABILITAR

	var _i = this.iface;
	var cursor = this.child("tdbLotesProducidos").cursor();
	_i.estado_ = "PROCESADO";
	var codOrden = cursor.valueBuffer("codordenproduccion");
	if (AQUtil.sqlSelect("pr_ordenesproduccion", "materialconfok", "codorden = '" + codOrden + "'")) {
		sys.warnMsgBox(sys.translate("La orden %1 ya tiene el material preparado. No puede modificar el lote").arg(codOrden));
	return false;
	}

	var idUsuario = _i.usuarioActual_;
	if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
	}

	var f;
	debug("\n\ntipoproduccion: "+_i.tipoProduccion_);
	if(_i.tipoProduccion_ == "Metros") {
		f = new FLFormSearchDB("em_metrospuestoprod");
	} else {
		f = new FLFormSearchDB("em_cantidadpuestoprod");
	}
	
	var curCPR = f.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();
	curCPR.select("sesion = '" + sesion + "'");
	if (curCPR.first()) {
		curCPR.setModeAccess(curCPR.Edit);
	} else {
		curCPR.setModeAccess(curCPR.Insert);
	}

	var canProdAnt = cursor.valueBuffer("em_canprod");
	if(!canProdAnt || canProdAnt == "") {
		canProdAnt = 0;
	}	



	curCPR.refreshBuffer();
	curCPR.setValueBuffer("sesion", sesion);
	curCPR.setValueBuffer("idusuario", idUsuario);
	curCPR.setValueBuffer("referencia", cursor.valueBuffer("referencia"));
	curCPR.setValueBuffer("canprogramada", cursor.valueBuffer("canprogramada"));
	//curCPR.setValueBuffer("canproducida", cursor.valueBuffer("canlote"));
	curCPR.setValueBuffer("canproducida", cursor.valueBuffer("em_canprod"));
	curCPR.setValueBuffer("canproducidaant", 0);


	f.setMainWidget();
	idUsuario= f.exec("idusuario");
	if (!idUsuario) {
		return;
	}
	if (!curCPR.commitBuffer()) {
		return;
	}

	var oParam = new Object;
	oParam.canProducida = curCPR.valueBuffer("cantotalnueva");
	oParam.canProgramada = curCPR.valueBuffer("canprogramada");
	oParam.idUsuario = idUsuario;
	oParam.codLote = cursor.valueBuffer("codlote");
	oParam.codOrden = cursor.valueBuffer("codordenproduccion");
	oParam.estado = "PROCESADO";

	oParam.errorMsg = sys.translate("Error al revisar el lote %1 como producido").arg(oParam.codLote);
	var f = new Function("oParam", "return formem_puestoprod.iface.trProduceLote(oParam)")
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	sys.infoMsgBox(sys.translate("El lote %1 ha sido revisado correctamente").arg(oParam.codLote));

	this.child("tableDBRecords").refresh();
	this.child("tdbLotesProducidos").refresh();
	_i.miroRegistrosTableDBRecords();
}*/

function oficial_tbnReabrir_clicked()
{


	var _i = this.iface;
	var cursor = this.child("tdbLotesProducidos").cursor();
	_i.estado_ = "PROCESADO";
	var codOrden = cursor.valueBuffer("codordenproduccion");
	if (AQUtil.sqlSelect("pr_ordenesproduccion", "materialconfok", "codorden = '" + codOrden + "'")) {
		sys.warnMsgBox(sys.translate("La orden %1 ya tiene el material preparado. No puede modificar el lote").arg(codOrden));
	return false;
	}

	var idUsuario = _i.usuarioActual_;
	if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
	}

	var oParam = new Object;	
	oParam.idUsuario = idUsuario;
	oParam.codLote = cursor.valueBuffer("codlote");
	oParam.codOrden = cursor.valueBuffer("codordenproduccion");
	oParam.errorMsg = sys.translate("Error al reabrir el lote %1").arg(oParam.codLote);
	oParam.msg = ""
	var f = new Function("oParam", "return formem_puestoprod.iface.trReabrir(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	if(oParam.msg != "") {

		sys.infoMsgBox(oParam.msg);
	}





	this.child("tableDBRecords").refresh();
	this.child("tdbLotesProducidos").refresh();
	_i.miroRegistrosTableDBRecords();
}

function oficial_trReabrir(oParam)
{
	var _i = this.iface;
	
	var codLote = oParam.codLote;
	var idUsuario = oParam.idUsuario;	

	var codOrden = oParam.codOrden;

	var hoy = new Date;

	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("codlote = '" + codLote + "'");
	if (!curLote.first()) {
		oParam.errorMsg = sys.translate("Error al localizar el lote %1").arg(codLote);
		return false;
	}
	curLote.setModeAccess(curLote.Edit);
	curLote.refreshBuffer();
	curLote.setValueBuffer("idusuarioprocesado", idUsuario);
	curLote.setValueBuffer("fechaprocesado", hoy.toString().left(10));
	curLote.setValueBuffer("horaprocesado", hoy.toString().right(8));
	curLote.setValueBuffer("estado", "PTE");	
	if (!curLote.commitBuffer()) {
		oParam.errorMsg = sys.translate("Error al marcar el lote %1 como PTE").arg(codLote);
			return false;
	}

	var tipoTareas = _i.dameTipoTareasMaq();
	var curTareas = new FLSqlCursor("pr_tareas");
	curTareas.select("pr_tareas.idobjeto = '" + codOrden + "' AND idtipotarea IN (" + tipoTareas + ") AND estado = 'TERMINADA' ORDER BY idtarea desc");
	if (!curTareas.first()) {
		return true;	
	}
	curTareas.setModeAccess(curTareas.Edit);
	curTareas.refreshBuffer();
	flcolaproc.iface.pub_deshacerTareaTerminada(curTareas);

	curTareas.select("pr_tareas.idobjeto = '" + codOrden + "' AND idtipotarea IN (" + tipoTareas + ") AND estado = 'EN CURSO' ORDER BY idtarea desc");
	if (!curTareas.first()) {
		return true;	
	}
	curTareas.setModeAccess(curTareas.Edit);
	curTareas.refreshBuffer();
	flcolaproc.iface.pub_deshacerTareaEnCurso(curTareas);

	return true;
}

function oficial_tbnBorraFiltro_clicked()
{
	var _i = this.iface;
	
	this.child("ledCodOrden").text = "";
	this.child("ledCodOrden").setFocus();
	_i.filtra();
}


function oficial_ledCodOrden_returnPressed()
{
	var _i = this.iface;
	_i.filtra();
}

function oficial_anchuraCols()
{
	var oC = [["em_ordenprod", 5], ["referencia", 90], ["codordenproduccion", 130], ["idtarea", 110], ["descripcion", 550], ["codtamanoem", 150], ["codcolorem", 220]];

	for (var c = 0; c < oC.length; c++) {
		this.child("tableDBRecords").setColumnWidth(oC[c][0], oC[c][1]);
		this.child("tdbLotesProducidos").setColumnWidth(oC[c][0], oC[c][1]);
	}

	var tdbLC = this.child("tableDBRecords");
	var dtbLC = this.mainWidget().child("tableDBRecords").tableRecords();

	tdbLC.autoSortColumn = false;
	var hHeader = dtbLC.horizontalHeader();
	hHeader.setClickEnabled(false);
	hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbLC.setSort(["em_aparcado ASC", "em_ordenprod ASC"]);
	dtbLC.refresh(AQS.RefreshData);



	var tdbLC = this.child("tdbLotesProducidos");
	var dtbLC = this.mainWidget().child("tdbLotesProducidos").tableRecords();

	tdbLC.autoSortColumn = false;
	var hHeader = dtbLC.horizontalHeader();
	hHeader.setClickEnabled(false);
	hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbLC.setSort(["fechaprocesado DESC", "horaprocesado DESC"]);
	dtbLC.refresh(AQS.RefreshData);
}

function oficial_cargaComboMaquina()
{
	var aMaquinas = [];
	var codPantalla = AQUtil.readSettingEntry("scripts/flprodppal/codPantalla");
	if(!codPantalla || codPantalla == "") {
		sys.warnMsgBox(sys.translate("No hay pantalla asignada a este terminal, por favor asigne una pantalla en el formulario de pantallas"));
		return false;
	}	
	
	var q = new AQSqlQuery;
	q.setSelect("codmaquinacol");
	q.setFrom("em_pantallas");
	q.setWhere("codPantalla='" + codPantalla + "'");

	if (!q.exec()){	
		return false;
	} 	
	while(q.next()) {
		aMaquinas.push(q.value("codmaquinacol"));
	}
	if(aMaquinas.length == 0) {
		sys.warnMsgBox(sys.translate("No hay ninguna m�quina asociada a la pantalla %1, por favor asigne una m�quina a la pantalla en el formulario de pantallas").arg(codPantalla));
		return false;
	}
	this.child("cbMaquina").clear();
	this.child("cbMaquina").insertStringList(aMaquinas);
	return true;
}

function oficial_cbMaquina_activated()
{
	
	var _i = this.iface;
	_i.borraImagen();
	var codMaquina = this.child("cbMaquina").currentText;
	if (!codMaquina) {		
		_i.codMaquina_ = false;		
	} else {
		_i.asignaMaquina(codMaquina);
	}
	_i.procesaEstado();
}

function oficial_asignaMaquina(codMaquina)
{
	var _i = this.iface;
	this.child("cbMaquina").currentText = codMaquina;
	
	_i.codMaquina_ = codMaquina;	
	_i.contador_ = AQUtil.sqlSelect("em_maquinascol","contador","codmaquinacol = '" + _i.codMaquina_ + "'");
	_i.tipoProduccion_ = AQUtil.sqlSelect("em_maquinascol", "tipoproduccion", "codmaquinacol = '" + codMaquina + "'");
	_i.filtra();

}

function oficial_tbnPlay_clicked()
{
	var _i = this.iface;
	var e = _i.oEstado_;

	var idUsuario = _i.usuarioActual_;
	if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
	}
	var cursor = this.child("tableDBRecords").cursor();
	var codLote = cursor.valueBuffer("codlote");
	var codOrden = cursor.valueBuffer("codordenproduccion");
	var referencia = cursor.valueBuffer("referencia");
	var descripcion = cursor.valueBuffer("descripcion");

	var tama = cursor.valueBuffer("codtamanoem");
	var color = cursor.valueBuffer("codcolorem");
	var prodAcumulada;
//debug("TIPO PROD ACUMULADA: " + _i.tipoProduccion_);
//debug("vB metros prod = " + cursor.valueBuffer("em_metrosprod"));
	if(_i.tipoProduccion_ == "Metros") {
		prodAcumulada = AQUtil.sqlSelect("lotesstock", "em_metrosprod", "codlote = '" + cursor.valueBuffer("codlote") + "'");;
	} else {
		prodAcumulada = cursor.valueBuffer("em_canprod");
	}
	if (isNaN(prodAcumulada)) {
		prodAcumulada = 0;
	}

	_i.actualizaLoteActMaq(codLote);

	if (_i.oEstado_ == undefined) {
		_i.oEstado_ = new Object;
	}
	//var e = _i.oEstado_;
	e.valorInicial = 0;

	if(_i.contador_) {
		//nos guardamos la lectura actual del contador _i.contador_
		e.valorInicial = formem_estampacion.iface.dameValorContadorSQL(_i.contador_);
	}		
	
	//e.aEstampar = aEstampar;
	//e.referencia = referencia;
	//e.idTramoTPPE = oParamPlay.idTramoTPPE;
	
	//e.codPartidaTPPE = _i.tblTPPE_.cellValue(0, "em_tramostejido.codpartida");
	//e.idLinea = oParamPlay.idLinea;	
	//e.estadoIniLinea = estadoLinea;
	
	//para cuando la tabla no tenga registro no salga mensaje
	//debug("/////////codOrden:"+codOrden);
	/*if(!codOrden || codOrden==""){
		e.msg = sys.translate("No hay registros en la tabla pendientes de producir.");
	}else{*/
		e.msg = sys.translate("Produciendo: %1, REF. %2 %3 %4 %5.\nProducci�n acumulada: %6 %7").arg(codOrden).arg(referencia).arg(descripcion).arg(tama).arg(color).arg(prodAcumulada).arg(_i.tipoProduccion_);

		e.estado = "Produciendo";	
		//var codOrden = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.codordenest");
		//e.codOrden = codOrden;
		//e.margenInicio = margenInicio;
		//e.consumo = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.consumo");
		_i.actualizaEstadoOrden(codOrden,"EN CURSO");
		_i.procesaEstado();

		/*if(_i.lineaColaAct_ && !isNaN(_i.lineaColaAct_) && _i.lineaColaAct_ < _i.tblLineas_.numRows()) {
			this.child("tblLineas").selectRow(_i.lineaColaAct_);	
		}*/

		_i.cargaImagen();
	//}

	

}

function oficial_actualizaEstadoOrden(codOrden, estado)
{
	var _i = this.iface;
	if (!AQSql.update("pr_ordenesproduccion", ["estado"], [estado], "codorden = '" + codOrden + "'")) {
		return false;
	}
	return true;
}

function oficial_actualizaLoteActMaq(codLote)
{
	var _i = this.iface;
	if (!AQSql.update("em_maquinascol", ["loteactual"], [codLote], "codmaquinacol = '" + _i.codMaquina_ + "'")) {
		return false;
	}
	return true;
}

/*function oficial_tbnPlay_clicked()
{
	var _i = this.iface;
		
	var hoy = new Date();
	fechaActual_ = hoy.toString().left(10);
	horaDesdeActual_ = hoy.toString().right(8);

	if(!_i.usuarioActual_ || !_i.turnoActual_ || _i.usuarioActual_ == "" || _i.turnoActual_ == "") {
	    _i.tbnCambiarUsuario_clicked();
	}	
	_i.curTurno_.setValueBuffer("idtrabajador", _i.usuarioActual_);
	_i.curTurno_.setValueBuffer("codturno", _i.turnoActual_);
	_i.curTurno_.setValueBuffer("fecha", new Date().toString().left(10));
	
	var oParamPlay = new Object;
	oParamPlay.row = this.child("tblLineas").currentRow();
	oParamPlay.idTramoTPPE = _i.tblTPPE_.cellValue(0, "em_tramostejido.idtramo");
	oParamPlay.idLinea= _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.idlinea");
	
	if(!_i.obligatoriosPlay(oParamPlay)) {	  
		_i.lineaColaAct_ = undefined;  
		_i.tblLineas_.setColorFunction("formem_estampacion.iface.colorCola");
	    return false;
	}	
	_i.lineaColaAct_ = oParamPlay.row;
	var mT = _i.tblTPPE_.cellValue(0, "em_tramostejido.candisponible");

	mT = isNaN(mT) ? 0 : mT;
	debug("mT: "+mT)
	if(parseFloat(mT) == 0) {
		sys.warnMsgBox(sys.translate("La cantidad disponible de la partida de preparado para estampar es cero,\npor favor cambie la bobina o reajuste la partida."));
		_i.lineaColaAct_ = undefined;  		
		_i.tblLineas_.refresh();
		return false;
	}


	var tejido = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.tejido");
	var referencia = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.referencia");
	var mO = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.canpendiente");
	var codGrupo = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.grupo");
	var codOrdenEst = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.codordenest");
	var estadoLinea = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.estado");
	if(!_i.compruebaGrupo(codOrdenEst,codGrupo)) {
		_i.lineaColaAct_ = undefined;  		
		_i.tblLineas_.refresh();
		return false;
	}
	
	mO = isNaN(mO) ? 0 : mO;
	
	
	var margenInicio = this.child("leMargenInicio").text;
	margenInicio = isNaN(margenInicio) ? 0 : margenInicio;
	margenInicio = margenInicio/100;
	
	mO = parseFloat(mO) + parseFloat(margenInicio);
	
	var aEstampar;
	
	aEstampar = mO;


	var res = MessageBox.information(sys.translate("Va a estampar %1m de tejido %2 - %3\n�Est� seguro?").arg(aEstampar).arg(referencia).arg(tejido), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		_i.lineaColaAct_ = undefined;  		
		_i.tblLineas_.refresh();
		return;
	}		
	

	
	
	_i.tblLineas_.setColorFunction("formem_estampacion.iface.colorCola");		
	_i.tblLineas_.refresh();
	
	if (_i.oEstado_ == undefined) {
		_i.oEstado_ = new Object;
	}
	var e = _i.oEstado_;
	e.valorInicial = 0;
	if(_i.automatico_) {
		//nos guardamos la lectura actual del contador _i.contador_
		e.valorInicial = _i.dameValorContadorSQL(_i.contador_);
	}
	
	
	
	e.aEstampar = aEstampar;
	e.referencia = referencia;
	e.idTramoTPPE = oParamPlay.idTramoTPPE;
	//e.codBobinaTPPE = _i.tblTPPE_.cellValue(0, "em_tramostejido.codpartida");
	e.codPartidaTPPE = _i.tblTPPE_.cellValue(0, "em_tramostejido.codpartida");
	e.idLinea = oParamPlay.idLinea;	
	e.estadoIniLinea = estadoLinea;
	
	e.msg = sys.translate("Estampando %1m de tejido %2 - %3").arg(aEstampar).arg(referencia).arg(tejido);
	e.estado = "Estampando";	
	var codOrden = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.codordenest");
	e.codOrden = codOrden;
	e.margenInicio = margenInicio;
	e.consumo = _i.tblLineas_.cellValue(oParamPlay.row, "em_lineasordenest.consumo");
	_i.actualizaEstadoOrden(codOrden,"EN CURSO");
	_i.procesaEstado();
	if(_i.lineaColaAct_ && !isNaN(_i.lineaColaAct_) && _i.lineaColaAct_ < _i.tblLineas_.numRows()) {
		this.child("tblLineas").selectRow(_i.lineaColaAct_);	
	}
	
}*/

function oficial_procesaEstado()
{////////////////////////////////////////////////////////////////////////////////////////////////////z
	var _i = this.iface;
	var e = _i.oEstado_;	
	var c = ["tableDBRecords", "tdbLotesProducidos", "tbnPlay", "tbnRev", "tbnCambiarUsuario", "cbMaquina","tbnAparcar", "tbnDesAparcar"];
	var d = ["tbnPausa"];

	/*------------------------------------------------------------------*/
	var _i = this.iface;

	var cursor = this.child("tableDBRecords").cursor();

	var codOrden = cursor.valueBuffer("codordenproduccion");	
	var codLote = cursor.valueBuffer("codlote");

	var numLineas = cursor.size();//AQUtil.sqlSelect("lotesstock INNER JOIN pr_tareas ON (lotesstock.codordenproduccion = pr_tareas.idobjeto)INNER JOIN articulos ON lotesstock.referencia = articulos.referencia INNER JOIN pr_ordenesproduccion ON lotesstock.codordenproduccion = pr_ordenesproduccion.codorden","count(*)",_i.dameFiltro() + " AND NOT lotesstock.em_aparcado","lotesstock,pr_tareas,articulos,pr_ordenesproduccion");
	//debug("///////numLineas 1:"+numLineas);
	//si hay registros en tableDBRecords hago switch

	if(numLineas==0){
		_i.miroRegistrosTableDBRecords();
	} else {
		this.child("pbnIncidencia").enabled = true;
		
		switch (e.estado) {
			case "Produciendo": {
				for (var i = 0; i < c.length; i++) {
					if (this.child(c[i])) {
						this.child(c[i]).enabled = false;
					}
				}
				for (var i = 0; i < d.length; i++) {
					if (this.child(d[i])) {
						this.child(d[i]).enabled = true;
					}
				}
				//_i.actualizaEstadoLinea(e.idLinea,e.estado);
				break;
			}
			default: {
				for (var i = 0; i < c.length; i++) {
					if (this.child(c[i])) {
						this.child(c[i]).enabled = true;
					}
				}
				for (var i = 0; i < d.length; i++) {
					if (this.child(d[i])) {
						this.child(d[i]).enabled = false;
					}
				}
				if (cursor.valueBuffer("em_aparcado") == true) {
					this.child("tbnPlay").enabled = false;
					this.child("tbnAparcar").enabled = false;
					this.child("tbnDesAparcar").enabled = true;
				
				} else {
					this.child("tbnPlay").enabled = true;	
					this.child("tbnAparcar").enabled = true;		
					this.child("tbnDesAparcar").enabled = false;
				}
				
				break;
			}
		}	
	}
	this.child("lblEstado").text = e.msg;


	_i.cargaImagen();

	
	//_i.calculaMetros();
}

function oficial_tbnPause_clicked()
{
	var _i = this.iface;
	var e = _i.oEstado_;
	e.valorFinal = 0;

	if(_i.contador_) {		
		var valorFinal = parseFloat(formem_estampacion.iface.dameValorContadorSQL(_i.contador_));
		e.valorFinal = valorFinal; 		
	}


	_i.produceLote("PTE");
	_i.actualizaLoteActMaq(null);
	
	e.msg = sys.translate("Listo...");
	e.estado = "Listo";
	
	_i.procesaEstado();
}
function oficial_tbnAparcar_clicked() 
{/////////////////////////////////////////////////////////////////////////////////////////////////

   	/*a�ado campo:em_aparcado en facturacion/almacen/lotesstock*/

	var _i = this.iface;
	var dialogo = false;

	var cursor = this.child("tableDBRecords").cursor();

	var codOrden = cursor.valueBuffer("codordenproduccion");	
	var codLote = cursor.valueBuffer("codlote");

	var numLineas = AQUtil.sqlSelect("lotesstock INNER JOIN pr_tareas ON (lotesstock.codordenproduccion = pr_tareas.idobjeto)INNER JOIN articulos ON lotesstock.referencia = articulos.referencia INNER JOIN pr_ordenesproduccion ON lotesstock.codordenproduccion = pr_ordenesproduccion.codorden","count(*)",_i.dameFiltro() + " AND NOT lotesstock.em_aparcado","lotesstock,pr_tareas,articulos,pr_ordenesproduccion")

	
	if(numLineas > 1) {
		dialogo = true;	
	}
	//debug("///////////////////////numLineas 2:"+numLineas);
	if(!dialogo) {
		if (!AQUtil.execSql("UPDATE lotesstock SET em_aparcado=true WHERE codlote = '" + codLote + "'")) {
			return false;
		}
		sys.infoMsgBox(sys.translate("Lote aparcado"));
	} else {	
	
		var dialog = new Dialog;
		dialog.caption = "Aparcar";
		dialog.okButtonText = "Aparcar";
		dialog.cancelButtonText = "Cancelar";    
		var texto = new Label;
		texto.text = sys.translate("Seleccione:");
		dialog.add( texto );	    
		var grupo = new GroupBox;
		dialog.add( grupo );   
	
		var botonAL = new RadioButton;
		botonAL.text = "Aparcar lote";
		botonAL.checked = true;
		grupo.add( botonAL );
		
		var botonAO = new RadioButton;
		botonAO.text = "Aparcar todos los lotes de la Orden";	
		botonAO.checked = false;	
		grupo.add( botonAO );		

		if(!dialog.exec() ) {
			return false;
		}
		if (botonAL.checked) {
			if (AQUtil.execSql("UPDATE lotesstock SET em_aparcado=true WHERE codlote = '" + codLote + "'")) {	
					sys.infoMsgBox(sys.translate("Lote aparcado"));
			}

		} else if (botonAO.checked) {
			if (!AQUtil.execSql("UPDATE lotesstock SET em_aparcado=true FROM pr_tareas,articulos,pr_ordenesproduccion  WHERE (lotesstock.codordenproduccion = pr_tareas.idobjeto) AND lotesstock.referencia = articulos.referencia AND lotesstock.codordenproduccion = pr_ordenesproduccion.codorden AND pr_ordenesproduccion.codorden = lotesstock.codordenproduccion AND lotesstock.codordenproduccion='" + codOrden + "' AND " + _i.dameFiltro())) {
				return false;
			}   		
			sys.infoMsgBox(sys.translate("Lotes de la orden %1 aparcados").arg(codOrden));			
		}	
	}
	this.child("tableDBRecords").refresh();
	return true;
}

function oficial_tbnDesAparcar_clicked() 
{
	var _i = this.iface;

	if(!_i.gestionaAparcar(false)) {
		return true;
	}	
	return true;
}

function oficial_gestionaAparcar(aparcar) 
{

   	/*a�ado campo:em_aparcado en facturacion/almacen/lotesstock*/

	var _i = this.iface;
	var dialogo = false;
	var msg = "";
	var msg2 = "";
	var accion = "";
	var where = "";
	if(aparcar) {
		msg = "aparcado";
		msg = "aparcados";
		accion = "Aparcar";
		where = _i.dameFiltro() + " AND NOT lotesstock.em_aparcado"
	} else {
		msg = "desaparcado";
		msg = "desaparcados";
		accion = "Desaparcar";
		where = _i.dameFiltro() + " AND lotesstock.em_aparcado"
	}


	var cursor = this.child("tableDBRecords").cursor();

	var codOrden = cursor.valueBuffer("codordenproduccion");	
	var codLote = cursor.valueBuffer("codlote");

	var numLineas = AQUtil.sqlSelect("lotesstock INNER JOIN pr_tareas ON (lotesstock.codordenproduccion = pr_tareas.idobjeto)INNER JOIN articulos ON lotesstock.referencia = articulos.referencia INNER JOIN pr_ordenesproduccion ON lotesstock.codordenproduccion = pr_ordenesproduccion.codorden","count(*)",where,"lotesstock,pr_tareas,articulos,pr_ordenesproduccion");

	
	if(numLineas > 1) {
		dialogo = true;	
	}	
	if(!dialogo) {
		if (!AQUtil.execSql("UPDATE lotesstock SET em_aparcado = " + aparcar + " WHERE codlote = '" + codLote + "'")) {
			return false;
		}
		sys.infoMsgBox(sys.translate("Lote %1").arg(msg));
	} else {	
		
		var dialog = new Dialog;
		dialog.caption = accion;
		dialog.okButtonText = accion;
		dialog.cancelButtonText = "Cancelar";    
		var texto = new Label;
		texto.text = sys.translate("Seleccione:");
		dialog.add( texto );	    
		var grupo = new GroupBox;
		dialog.add( grupo );   
	
		var botonAL = new RadioButton;
		botonAL.text = accion + " lote";
		botonAL.checked = true;
		grupo.add( botonAL );
		
		var botonAO = new RadioButton;
		botonAO.text = accion + " todos los lotes de la Orden";	
		botonAO.checked = false;	
		grupo.add( botonAO );		

		if(!dialog.exec() ) {
			return false;
		}
		if (botonAL.checked) {
			if (AQUtil.execSql("UPDATE lotesstock SET em_aparcado = " + aparcar + " WHERE codlote = '" + codLote + "'")) {	
					sys.infoMsgBox(sys.translate("Lote %1").arg(msg));
			}

		} else if (botonAO.checked) {
			if (!AQUtil.execSql("UPDATE lotesstock SET em_aparcado = " + aparcar + " FROM pr_tareas,articulos,pr_ordenesproduccion  WHERE (lotesstock.codordenproduccion = pr_tareas.idobjeto) AND lotesstock.referencia = articulos.referencia AND lotesstock.codordenproduccion = pr_ordenesproduccion.codorden AND pr_ordenesproduccion.codorden = lotesstock.codordenproduccion AND lotesstock.codordenproduccion='" + codOrden + "' AND " + _i.dameFiltro())) {
				return false;
			}   		
			sys.infoMsgBox(sys.translate("Lotes de la orden %1 %2").arg(codOrden).arg(msg2));			
		}	
	}
	this.child("tableDBRecords").refresh();
	return true;
}

function oficial_cargaImagen()
{
	var _i = this.iface;
	_i.borraImagen();
	var cursor = this.child("tableDBRecords").cursor();
	var referencia = cursor.valueBuffer("referencia");
	if (referencia == "") {
		_i.borraImagen();
		return;
	}	
	var imagen = AQUtil.sqlSelect("articulos a INNER JOIN em_dibujos d ON a.coddibestamp = d.coddibujoem INNER JOIN em_disenos dis ON d.coddiseno = dis.coddiseno", "COALESCE(dis.urlambiente,dis.urlbajaresolucion)", "a.referencia = '" + referencia + "'", "articulos");	
	if(!imagen || imagen == ""){
		return;
	}
	//debug("////////hace consulta imagen");
	var i = new QImage;
	i.load(imagen);
	var s = this.child("pbnImagen").size;
	var i2 = i.scale(s, AQS.ScaleMin);
	var p = new QPixmap;
	p.convertFromImage(i2);
	//this.child("lblImagen").pixmap = p;
	this.child("pbnImagen").pixmap = p;
}

function oficial_borraImage()
{
	this.child("pbnImagen").pixmap = new QPixmap;
}

function oficial_tbnRefresca_clicked(){
	var _i = this.iface;
	_i.cbMaquina_activated();
	_i.miroRegistrosTableDBRecords();
}

function oficial_pbnImagen_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tableDBRecords").cursor();
	var referencia = cursor.valueBuffer("referencia");
	if (referencia == "") {
		_i.borraImagen();
		return;
	}	
	
	var imagenAmbiente, imagenBaja;
	if (referencia == "") {
		_i.borraImagen();
		return;
	}
	
	var qImagenes = new AQSqlQuery;
	qImagenes.setSelect("dis.urlambiente, dis.urlbajaresolucion");
	qImagenes.setFrom("articulos a INNER JOIN em_dibujos d ON a.coddibestamp = d.coddibujoem INNER JOIN em_disenos dis ON d.coddiseno = dis.coddiseno");
	qImagenes.setWhere("a.referencia = '" + referencia + "'"); 			

	if (!qImagenes.exec()){
		return;
	}  
	if(qImagenes.first())
	{
		imagenAmbiente = qImagenes.value("dis.urlambiente");
		imagenBaja = qImagenes.value("dis.urlbajaresolucion");

	}
	if(imagenAmbiente && imagenAmbiente != "") {
		if(File.exists(imagenAmbiente)) {
			sys.openUrl(imagenAmbiente);
			//fleumoesta.iface.pub_abrirURL(imagenAlta);			
		}//else {
		//	sys.warnMsgBox(sys.translate("La imagen en alta resoluci�n no se encuentra en la ubicaci�n %1").arg(imagenAlta));
		//}
	}else if (imagenBaja && imagenBaja != "") {
		if(File.exists(imagenBaja)) {
			sys.openUrl(imagenBaja);
			//fleumoesta.iface.pub_abrirURL(imagenBaja);	
		}//else {
		//	sys.warnMsgBox(sys.translate("La imagen en baja resoluci�n no se encuentra en la ubicaci�n %1").arg(imagenBaja));
		//}
	}else {		
		sys.warnMsgBox(sys.translate("No hay ninguna imagen cargada ni de ambiente  ni de baja resoluci�n."));
	}
	
	
	/*var imagen = AQUtil.sqlSelect("articulos a INNER JOIN em_dibujos d ON a.coddibestamp = d.coddibujoem INNER JOIN em_disenos dis ON d.coddiseno = dis.coddiseno", "dis.urlaltaresolucion", "a.referencia = '" + referencia + "'", "articulos");
	if(!imagen || imagen == "") {
		return;
	}
	sys.openUrl(imagen);	*/
}

function oficial_pbnIncidencia_clicked() {
/////////////////////////////////////////////////////////////////////////////////////////////////    
    var _i = this.iface;

 	var _i = this.iface;

	var cursor = this.child("tableDBRecords").cursor();

	var codOrden = cursor.valueBuffer("codordenproduccion");	
	var codLote = cursor.valueBuffer("codlote");

	var numLineas = AQUtil.sqlSelect("lotesstock INNER JOIN pr_tareas ON (lotesstock.codordenproduccion = pr_tareas.idobjeto)INNER JOIN articulos ON lotesstock.referencia = articulos.referencia INNER JOIN pr_ordenesproduccion ON lotesstock.codordenproduccion = pr_ordenesproduccion.codorden","count(*)",_i.dameFiltro() + " AND NOT lotesstock.em_aparcado","lotesstock,pr_tareas,articulos,pr_ordenesproduccion");
	//debug("///////numLineas 4:"+numLineas);


    if(!_i.usuarioActual_ || _i.usuarioActual_ == "" || numLineas==0) {
		sys.warnMsgBox(sys.translate("Debe de seleccionar usuario, lote pendiente de producir."));
		return false;
    }
    //debug("/////////_i.usuarioActual_:"+_i.usuarioActual_);
    var curIncidencia = new FLSqlCursor("em_parosprod");    
    curIncidencia.setAction("em_parosprod");
    curIncidencia.insertRecord();
    curIncidencia.setValueBuffer("idtrabajador",_i.usuarioActual_);
    curIncidencia.setValueBuffer("codmaquinacol",_i.codMaquina_);

    var codOrden = cursor.valueBuffer("codordenproduccion");
    var codLote = cursor.valueBuffer("codlote");
    curIncidencia.setValueBuffer("codorden",codOrden);
    curIncidencia.setValueBuffer("lotesproduccion",codLote);
    
    
}
function oficial_miroRegistrosTableDBRecords(){
	/*--------------miro si hay registros--------------*/
	//tbnPlay pbnIncidencia
	var _i = this.iface;

	var cursor = this.child("tableDBRecords").cursor();

	var codOrden = cursor.valueBuffer("codordenproduccion");	
	var codLote = cursor.valueBuffer("codlote");

	var numLineas = AQUtil.sqlSelect("lotesstock INNER JOIN pr_tareas ON (lotesstock.codordenproduccion = pr_tareas.idobjeto)INNER JOIN articulos ON lotesstock.referencia = articulos.referencia INNER JOIN pr_ordenesproduccion ON lotesstock.codordenproduccion = pr_ordenesproduccion.codorden","count(*)",_i.dameFiltro() + " AND NOT lotesstock.em_aparcado","lotesstock,pr_tareas,articulos,pr_ordenesproduccion");
	//debug("///////numLineas 3:"+numLineas);

	if(numLineas==0){
		this.child("tbnPlay").enabled = false;
		this.child("pbnIncidencia").enabled = false;
		this.child("tbnPausa").enabled = false;
		this.child("cbMaquina").enabled = true;

	}else{
		this.child("tbnPlay").enabled = true;
		this.child("pbnIncidencia").enabled = true;
	}
}

function oficial_calculaCantidadPte(codOrden) 
{
    var _i = this.iface;

    var referencia;
	var prendas;
	var metros;
	var totalMetros = 0, totalPrendas = 0;
	
	var qLote = new FLSqlQuery;
	qLote.setSelect("referencia, canprogramada - em_canprod");
	qLote.setFrom("lotesstock");
	qLote.setWhere("codordenproduccion = '" + codOrden + "'");
	qLote.setForwardOnly(true);
	if (!qLote.exec()) {			
		return false;
	}

	while (qLote.next()) {
		referencia = qLote.value("referencia");		
		prendas = qLote.value("canprogramada - em_canprod");
		if (prendas < 0) {
    		prendas = 0;
    	}
    	if (prendas == 0) {
    		continue;
    	}
		metros = formRecordarticulos.iface.prendasAMetros(referencia, prendas);
		if (!metros) {
			metros = 0;
		}
		totalMetros = parseFloat(totalMetros) + parseFloat(metros);
		totalPrendas = parseFloat(totalPrendas) + parseFloat(prendas);
	}
	//debug("totalMetros: "+totalMetros);
	//debug("totalPrendas: "+totalPrendas);
	if(!AQUtil.execSql("UPDATE pr_ordenesproduccion SET udsptes = " + totalPrendas + ", metrosptes = " + totalMetros + " WHERE codorden = '" + codOrden + "'")){
		sys.warnMsgBox(sys.translate("No ha podido actualizar las unidades y metros pendientes de la orden: %1").arg(codOrden));
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////