
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function validaFamilia() {
		return this.ctx.euromoda_validaFamilia();
	}
	/*function datosInsercion() {
	     return this.ctx.euromoda_datosInsercion();
	}*/
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	switch (cursor.modeAccess()) {
  		case cursor.Insert: {
      	sys.setObjText(this, "fdbEmIdUsuario", sys.nameUser());
      break;
    }
  }
	
}
function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.validaFamilia()) {
		return false;
	}
	return true;
}

function euromoda_validaFamilia()
{
	debug("euromoda_validaFamilia");
	var _i = this.iface;
	var cursor = this.cursor();
	
// 	var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + cursor.valueBuffer("referencia") + "'");
// debug("codFamilia" + codFamilia);
// 	if (!codFamilia) {
// 		return true;
// 	}
	var referencia = cursor.valueBuffer("referencia");
// 	if (flfactalma.iface.pub_esFamiliaEstampado(codFamilia)) {
	if (flfactalma.iface.pub_esReferenciaXPiezas(referencia)) {
		MessageBox.warning(sys.translate("scripts", "Las piezas de tejido estampado deben regularizase una a una en la pesta�a Lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
// 	if (flfactalma.iface.pub_esFamiliaCrudo(codFamilia)) {
	if (flfactalma.iface.pub_esReferenciaXPartidas(referencia)) {
		MessageBox.warning(sys.translate("scripts", "Las partidas de tejido en crudo deben regularizase una a una en la gesti�n de partidas"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}
/*function euromoda_datosInsercion()
{
     var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.modeAccess() != cursor.Insert) {
		return;
	}
	var curRel = cursor.cursorRelation();
	if (!curRel) {
		return;
	}
	switch (curRel.table()) {
		case "v_stocksext": {
			this.child("fdbCantidadIni").setValue(curRel.valueBuffer("cantidad"));
			this.child("fdbCantidadFin").setValue(curRel.valueBuffer("cantidad"));
			break;
		}
		default: {
			 _i.__datosInsercion();
		}
	}
}*/
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
