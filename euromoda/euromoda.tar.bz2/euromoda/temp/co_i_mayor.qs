
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var bloqueoTS_;
  function euromoda( context ) { oficial ( context ); }
  function init() {
    return this.ctx.euromoda_init();
  }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function calculateField(fN) {
    return this.ctx.euromoda_calculateField(fN);
  }
  function calculaDesAux() {
    return this.ctx.euromoda_calculaDesAux();
  }
  function deshabilitarSubcuentas(valor_disabled) {
    return this.ctx.euromoda_deshabilitarSubcuentas(valor_disabled);
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;

  _i.__init();
	
  _i.bloqueoTS_ = false;
	
  var cursor = this.cursor();
  formRecordco_partidas.iface.pub_habilitaPorTipoSubcuenta(this);
  _i.calculaDesAux();
}

function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "tiposubcuenta": {
			formRecordco_partidas.iface.pub_habilitaPorTipoSubcuenta(this);
			break;
		}
		case "todassubcuentas": {
			if (!_i.bloqueoTS_) {
				_i.bloqueoTS_ = true;
				sys.setObjText(this, "fdbCodCliente", "");
				sys.setObjText(this, "fdbCodProveedor", "");
				sys.setObjText(this, "fdbCodCuentaBanco", "");
				sys.setObjText(this, "fdbCodActivo", "");
				_i.__bufferChanged(fN);
				_i.bloqueoTS_ = false;
			}
			break;
		}
		case "i_co__partidas_codcliente": {
			if (cursor.valueBuffer("i_co__partidas_codcliente") != "") {
				if (!_i.bloqueoTS_) {
					_i.bloqueoTS_ = true;
					sys.setObjText(this, "fdbTodasSubcuentas", false);
					_i.bloqueoTS_ = false;
				}
			}
			sys.setObjText(this, "fdbIdSubcuentaDesde",  "");
			sys.setObjText(this, "fdbIdSubcuentaHasta",  "");
			sys.setObjText(this, "fdbCodSubcuentaDesde",  "");
			sys.setObjText(this, "fdbCodSubcuentaHasta",  "");
			this.child("lblDesAux").text = _i.calculateField("lblDesAuxCliente");
			_i.deshabilitarSubcuentas();
			break;
		}
		case "i_co__partidas_codproveedor": {
			if (cursor.valueBuffer("i_co__partidas_codproveedor") != "") {
				if (!_i.bloqueoTS_) {
					_i.bloqueoTS_ = true;
					sys.setObjText(this, "fdbTodasSubcuentas", false);
					_i.bloqueoTS_ = false;
				}
			}
			sys.setObjText(this, "fdbIdSubcuentaDesde",  "");
			sys.setObjText(this, "fdbIdSubcuentaHasta",  "");
			sys.setObjText(this, "fdbCodSubcuentaDesde",  "");
			sys.setObjText(this, "fdbCodSubcuentaHasta",  "");
			this.child("lblDesAux").text = _i.calculateField("lblDesAuxProveedor");
			_i.deshabilitarSubcuentas();
			break;
		}
		case "codcuentabanco": {
			if (cursor.valueBuffer("codcuentabanco") != "") {
				if (!_i.bloqueoTS_) {
					_i.bloqueoTS_ = true;
					sys.setObjText(this, "fdbTodasSubcuentas", false);
					_i.bloqueoTS_ = false;
				}
			}
			var idSubcuenta = _i.calculateField("idsubcuentabanco");
			sys.setObjText(this, "fdbIdSubcuentaDesde",  idSubcuenta);
			sys.setObjText(this, "fdbIdSubcuentaHasta",  idSubcuenta);
			this.child("lblDesAux").text = _i.calculateField("lblDesAuxCuentaBanco");
			_i.deshabilitarSubcuentas();
			break;
		}
		case "i_co__partidas_codactivo": {
			if (cursor.valueBuffer("i_co__partidas_codactivo") != "") {
				if (!_i.bloqueoTS_) {
					_i.bloqueoTS_ = true;
					sys.setObjText(this, "fdbTodasSubcuentas", false);
					_i.bloqueoTS_ = false;
				}
			}
			var idSubcuenta = _i.calculateField("idsubcuentaactivo");
			sys.setObjText(this, "fdbIdSubcuentaDesde",  idSubcuenta);
			sys.setObjText(this, "fdbIdSubcuentaHasta",  idSubcuenta);
			this.child("lblDesAux").text = _i.calculateField("lblDesAuxActivo");
			_i.deshabilitarSubcuentas();
			break;
			}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_calculaDesAux()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tiposubcuenta")) {
  case "Proveedor": {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxProveedor");
      break;
    }
  case "Banco": {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxCuentaBanco");
      break;
    }
  case "Activo": {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxActivo");
      break;
    }
  default: {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxCliente");
      break;
    }
  }
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  var codEjercicio = cursor.valueBuffer("i_co__subcuentas_codejercicio");
  switch (fN) {
    case "lblDesAuxCliente": {
      var codCliente = cursor.valueBuffer("i_co__partidas_codcliente");
      valor = AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + codCliente + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxProveedor": {
      var codProveedor = cursor.valueBuffer("i_co__partidas_codproveedor");
      valor = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxCuentaBanco": {
      var codCuenta = cursor.valueBuffer("codcuentabanco");
      valor = AQUtil.sqlSelect("cuentasbanco", "descripcion", "codcuenta = '" + codCuenta + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxActivo": {
      var codActivo = cursor.valueBuffer("i_co__partidas_codactivo");
      valor = AQUtil.sqlSelect("co_amortizaciones", "elemento", "codamortizacion = '" + codActivo + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "idsubcuentacliente": {
        valor = "";
        var codCliente = cursor.valueBuffer("i_co__partidas_codcliente");
        if (!AQUtil.sqlSelect("clientes", "codcliente", "codcliente = '" + codCliente + "'")) {
          break;
        }
        var oAux = new Object;
        oAux.codejercicio = codEjercicio;
        var oDC = flfactppal.iface.pub_datosCtaCliente(codCliente, oAux);
        if (oDC) {
          valor = oDC.idsubcuenta;
        }
        break;
    }
    case "idsubcuentaproveedor": {
      valor = "";
      var codProveedor = cursor.valueBuffer("i_co__partidas_codproveedor");
      if (!AQUtil.sqlSelect("proveedores", "codproveedor", "codproveedor = '" + codProveedor + "'")) {
        break;
      }
      var oAux = new Object;
      oAux.codejercicio = codEjercicio;
      var oDC = flfactppal.iface.pub_datosCtaProveedor(codProveedor, oAux);
      if (oDC) {
        valor = oDC.idsubcuenta;
      }
      break;
    }
    case "idsubcuentabanco": {
      valor = "";
      var codCuenta = cursor.valueBuffer("codcuentabanco");
      var codSubcuenta = AQUtil.sqlSelect("cuentasbanco", "codsubcuenta", "codcuenta = '" + codCuenta + "'");
      if (codSubcuenta) {
        valor = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
      }
      break;
    }
    case "idsubcuentaactivo": {
      valor = "";
      var codActivo = cursor.valueBuffer("i_co__partidas_codactivo");
      var codSubcuenta = AQUtil.sqlSelect("co_amortizaciones a INNER JOIN co_gruposcontablesamo gca ON a.codgrupocontableamo = gca.codgrupo", "gca.codsubcuentaele", "a.codamortizacion = '" + codActivo + "'", "co_amortizaciones,co_gruposcontablesamo");
      if (codSubcuenta) {
        valor = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
      }
      break;
    }
    default: {
        try {
          valor = _i.__calculateField(fN);
        } catch (e) {}
    }
  }
  return valor;
}

function euromoda_deshabilitarSubcuentas(valor_disabled)
{
	var cursor = this.cursor();
	valor_disabled = (cursor.valueBuffer("todassubcuentas") || cursor.valueBuffer("i_co__partidas_codcliente") || cursor.valueBuffer("i_co__partidas_codproveedor") || cursor.valueBuffer("codcuentabanco") || cursor.valueBuffer("i_co__partidas_codactivo"));
	
	this.child("fdbCodSubcuentaDesde").setDisabled(valor_disabled);
	this.child("fdbIdSubcuentaDesde").setDisabled(valor_disabled);
	this.child("fdbCodSubcuentaHasta").setDisabled(valor_disabled);
	this.child("fdbIdSubcuentaHasta").setDisabled(valor_disabled);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
