
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	var curP_, pK_;
	
	var curFactura, curLineaFactura;
	var totalTareas_;
	var totalPrendasTareas_;
	var lineaAnt_;
	var totalCant_;
	var fechaInforme_;
	var ordenes_;
	var totalOrdenes_;
	var silent_;
	var idPedAlbCDB_;

  function euromoda( context ) { prod ( context ); }
  function init() {
    return this.ctx.euromoda_init();
  }
  function tbnRecalcularFServicio_clicked() {
    return this.ctx.euromoda_tbnRecalcularFServicio_clicked();
  }
  function anchoCols() {
    return this.ctx.euromoda_anchoCols();
  }
  function datosAlbaran(curPedido, where, datosAgrupacion) {
    return this.ctx.euromoda_datosAlbaran(curPedido, where, datosAgrupacion);
  }
  function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function generarAlbaran(where, curPedido, datosAgrupacion) {
    return this.ctx.euromoda_generarAlbaran(where, curPedido, datosAgrupacion);
  }
  function datosLineaAlbaran(curLineaPedido) {
    return this.ctx.euromoda_datosLineaAlbaran(curLineaPedido);
  }
  function copiaLineas(idPedido, idAlbaran) {
    return this.ctx.euromoda_copiaLineas(idPedido, idAlbaran);
  }
//   function copiaLineaPedidoParcial(curLineaPedido, idAlbaran) {
//     return this.ctx.euromoda_copiaLineaPedidoParcial(curLineaPedido, idAlbaran);
//   }
  function copiaLineasParcial(idPedido, idAlbaran) {
		return this.ctx.euromoda_copiaLineasParcial(idPedido, idAlbaran);
	}
	function imprimir(codPedido) {
		return this.ctx.euromoda_imprimir(codPedido);
	}
	function lineaParcialCopiable(curLineaPedido, idAlbaran) {
		return this.ctx.euromoda_lineaParcialCopiable(curLineaPedido, idAlbaran);
	}
	function pbnGenerarFactura_clicked() {
		return this.ctx.euromoda_pbnGenerarFactura_clicked();
	}
	function generarFactura(where, curPedido, datosAgrupacion) {
		return this.ctx.euromoda_generarFactura(where, curPedido, datosAgrupacion);
	}
	function datosFactura(curPedido, where, datosAgrupacion) {
		return this.ctx.euromoda_datosFactura(curPedido, where, datosAgrupacion);
	}
	function copiaLineasPedidoFactura(idPedido, idFactura) {
		return this.ctx.euromoda_copiaLineasPedidoFactura(idPedido, idFactura);
	}
	function copiaLineaPedidoFactura(curLineaPedido, idFactura) {
		return this.ctx.euromoda_copiaLineaPedidoFactura(curLineaPedido, idFactura);
	}
	function datosLineaPedidoFactura(curLineaPedido) {
		return this.ctx.euromoda_datosLineaPedidoFactura(curLineaPedido);
	}
	function dameColor(fN, fV, cursor, fT, sel) {
		return this.ctx.euromoda_dameColor(fN, fV, cursor, fT, sel);
	}
	function tbnFiltroClientes_clicked() {
		return this.ctx.euromoda_tbnFiltroClientes_clicked();
	}
	function tbnQuitarFiltro_clicked() {
		return this.ctx.euromoda_tbnQuitarFiltro_clicked();
	}
	function filtroDefecto() {
		return this.ctx.euromoda_filtroDefecto();
	}
	function preloadMainFilter() {
		return this.ctx.euromoda_preloadMainFilter();
	}
	function tbnEstadoProduccion_clicked() {
		return this.ctx.euromoda_tbnEstadoProduccion_clicked();
	}
	function tbnEstadoProduccionTP_clicked() {
		return this.ctx.euromoda_tbnEstadoProduccionTP_clicked();
	}
	function dameParamEstadoProduccion(codPedido) {
		return this.ctx.euromoda_dameParamEstadoProduccion(codPedido);
	}
	function imprimirEstadoProduccion(codPedido) {
		return this.ctx.euromoda_imprimirEstadoProduccion(codPedido);
	}
	function imprimirEstadoProduccionTP(codPedido) {
		return this.ctx.euromoda_imprimirEstadoProduccionTP(codPedido);
	}
	function dameEstado(nodo, campo) {
		return this.ctx.euromoda_dameEstado(nodo, campo);
	}
	function inicializaTotalTareas() {
		return this.ctx.euromoda_inicializaTotalTareas();
	}
	function inicializaTotalPrendasTareas() {
		return this.ctx.euromoda_inicializaTotalPrendasTareas();
	}
	function dameTotalPrendasTareas(nodo, campo) {
		return this.ctx.euromoda_dameTotalPrendasTareas(nodo, campo);
	}
	function dameTotalTareas(nodo, campo) {
		return this.ctx.euromoda_dameTotalTareas(nodo, campo);
	}
	function dameNumOrdenes() {
		return this.ctx.euromoda_dameNumOrdenes();
	}
	function calculaNumOrdenes(orden) {
		return this.ctx.euromoda_calculaNumOrdenes(orden);
	}
	function inicializaOrdenes() {
		return this.ctx.euromoda_inicializaOrdenes();
	}
	function cambioProceso(nodo, campo) {
		return this.ctx.euromoda_cambioProceso(nodo, campo);
	}
	function pintolinea(nodo, campo) {
		return this.ctx.euromoda_pintolinea(nodo, campo);
	}
	function ordenEstadoProd(nodo, campo) {
		return this.ctx.euromoda_ordenEstadoProd(nodo, campo);
	}
	function dameTotalCant() {
		return this.ctx.euromoda_dameTotalCant();
	}
	function dameFechaInforme() {
		return this.ctx.euromoda_dameFechaInforme();
	}
	function formateaFechaInforme() {
		return this.ctx.euromoda_formateaFechaInforme();
	}
	function almacenaFechaInforme() {
		return this.ctx.euromoda_almacenaFechaInforme();
	}
	function datosDirAlbaran(curPedido, where, datosAgrupacion) {
		return this.ctx.euromoda_datosDirAlbaran(curPedido, where, datosAgrupacion);
	}
	function copiaDatosPedido(curPedido) {
		return this.ctx.euromoda_copiaDatosPedido(curPedido);
	}
	function totalesPedido() {
		return this.ctx.euromoda_totalesPedido();
	}
	function ordenaCols() {
		return this.ctx.euromoda_ordenaCols();
	}
	function pbnGenerarAlbaran_clicked() {
		return this.ctx.euromoda_pbnGenerarAlbaran_clicked();
	}
	function toolButtomInsert_clicked() {
		return this.ctx.euromoda_toolButtomInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.euromoda_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.euromoda_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.euromoda_toolButtonZoom_clicked();
	}
	function toolButtonCopy_clicked() {
		return this.ctx.euromoda_toolButtonCopy_clicked();
	}
	function curP_bufferCommited() {
		return this.ctx.euromoda_curP_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tableDBRecords_recordChoosed() {
		return this.ctx.euromoda_tableDBRecords_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function estableceAlmacenDepositoAlbaran(codAlmaDeposito, curPedido) {
    	return this.ctx.euromoda_estableceAlmacenDepositoAlbaran(codAlmaDeposito, curPedido);
    }
    function totalesAlbaran() {
    	return this.ctx.euromoda_totalesAlbaran();
    }
    function pbnGenerarAlbaranCDB_clicked() {
    	return this.ctx.euromoda_pbnGenerarAlbaranCDB_clicked();
    }
    function tbnExportarDatos_clicked() {
		return this.ctx.euromoda_tbnExportarDatos_clicked();
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
	_i.ordenaCols();
  _i.anchoCols();

	_i.almacenaFechaInforme();

	connect(this.child("tbnFiltroClientes"), "clicked()", _i, "tbnFiltroClientes_clicked");
	connect(this.child("tbnQuitarFiltro"), "clicked()", _i, "tbnQuitarFiltro_clicked");
	connect(this.child("tbnRecalcularFServicio"), "clicked()", _i, "tbnRecalcularFServicio_clicked");
	connect(this.child("tbnEstadoProduccion"), "clicked()", _i, "tbnEstadoProduccion_clicked");
	connect(this.child("tbnEstadoProduccionTP"), "clicked()", _i, "tbnEstadoProduccionTP_clicked");
	
	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	
	
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tableDBRecords_recordChoosed");

	sys.runObjMethod(this, "tbnRoturaStock", "close()");

	connect(this.child("pbnGenerarAlbaranCDB"), "clicked()", _i, "pbnGenerarAlbaranCDB_clicked"); //13-02-2020 generar albaranes CDB
	/*if(this.child("pbnGenerarAlbaranCDB")) {
		this.child("pbnGenerarAlbaranCDB").close(); //13-02-2020 generar albaranes CDB	
	}*/
	connect(this.child("tbnExportarDatos"), "clicked()", _i, "tbnExportarDatos_clicked");
	if(this.child("tbnCambiarAlmacen")) {
  		this.child("tbnCambiarAlmacen").close();
  	}

}

function euromoda_ordenaCols()
{
	var oC;
	oC = ["idpedido", "codigo", "servido", "editable", "hojacarga", "fechahc", "fecha", "fechaservicio", "fechasalida", "total", "codcliente", "nombrecliente","docexterno", "observaciones"];
	this.child("tableDBRecords").setOrderCols(oC);
}


function euromoda_tbnRecalcularFServicio_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var idPedido = cursor.valueBuffer("idpedido");
	if (!idPedido) {
		return;
	}
	var servido = cursor.valueBuffer("servido");
	if (servido == "S�") {
		sys.warnMsgBox(sys.translate("El pedido ya est� servido"));
		return;
	}
	var oParam = new Object;
	oParam.idPedidoPar = idPedido;
	if (!formmt_procesos.iface.emRevisaFechaServicioPedPte(oParam)) {
		return false;
	}
// 	sys.runObjMethod(this, "tableDBRecords", "refresh()");
	this.child("tableDBRecords").refresh();
}

function euromoda_tbnQuitarFiltro_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var filtro = _i.preloadMainFilter();
	
	this.cursor().setMainFilter(filtro);
	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_filtroDefecto()
{
	return "servido IN ('No', 'Parcial')";
}

function euromoda_preloadMainFilter()
{
  var _i = this.iface;
	var cursor = this.cursor();
	
	var filtro = _i.filtroDefecto();
	var fBase = _i.filtroTabla();
	filtro = fBase != "" ? (fBase + " AND " + filtro) : filtro;
	
	return filtro;
}

function euromoda_tbnFiltroClientes_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();

	var f = new FLFormSearchDB("em_filtropedidoscli");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);

	f.setMainWidget();

	var filtro = f.exec("filtro");
	if (!filtro) {
		filtro = _i.filtroDefecto();;
	}
	var fBase = _i.filtroTabla();

	if (filtro) {
		curF.commitBuffer();
		cursor.setMainFilter(fBase + " AND " + filtro);
	} else {
		cursor.setMainFilter(fBase);
	}

	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_anchoCols()
{
	var oCAncho = [["editable", 60], ["hojacarga", 40], ["servido", 60], ["fechahc", 80]];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tableDBRecords").setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
}

function euromoda_datosAlbaran(curPedido, where, datosAgrupacion)
{
  var _i = this.iface;
  if (!_i.__datosAlbaran(curPedido, where, datosAgrupacion)) {
    return false;
  }

  _i.curAlbaran.setValueBuffer("departamento", curPedido.valueBuffer("departamento"));
  _i.curAlbaran.setValueBuffer("docexterno", curPedido.valueBuffer("docexterno"));
  _i.curAlbaran.setValueBuffer("codclientefac", curPedido.valueBuffer("codclientefac"));
  _i.curAlbaran.setValueBuffer("em_codpago", curPedido.valueBuffer("em_codpago"));
	_i.curAlbaran.setValueBuffer("pobincoterm", curPedido.valueBuffer("pobincoterm"));
	_i.curAlbaran.setValueBuffer("emcatservicio", curPedido.valueBuffer("emcatservicio"));
	_i.curAlbaran.setValueBuffer("codagencia", curPedido.valueBuffer("codagencia"));
	_i.curAlbaran.setValueBuffer("bultos", curPedido.valueBuffer("bultos"));
	_i.curAlbaran.setValueBuffer("pesobruto", curPedido.valueBuffer("pesobruto"));
	_i.curAlbaran.setValueBuffer("volumen", curPedido.valueBuffer("volumen"));
	_i.curAlbaran.setValueBuffer("desbultos", curPedido.valueBuffer("desbultos"));
	_i.curAlbaran.setValueBuffer("obstransporte", curPedido.valueBuffer("obstransporte"));
	var codCliente = curPedido.valueBuffer("codcliente");
  if (codCliente && _i.curAlbaran.isNull("codagencia")) {
    _i.curAlbaran.setValueBuffer("codagencia", AQUtil.sqlSelect("clientes", "codtransportista", "codcliente = '" + codCliente + "'"));
    _i.curAlbaran.setValueBuffer("tipoportes", AQUtil.sqlSelect("clientes", "tipoportes", "codcliente = '" + codCliente + "'"));
  }
  _i.curAlbaran.setValueBuffer("idfactura", curPedido.valueBuffer("idfactura"));
	if(datosAgrupacion) {
		if("optFechaValor" in datosAgrupacion && datosAgrupacion.optFechaValor == "Agrupar por fecha valor") {
			_i.curAlbaran.setValueBuffer("fechavalor", curPedido.valueBuffer("fechavalor"));
		} 
	} else {
		_i.curAlbaran.setValueBuffer("fechavalor", curPedido.valueBuffer("fechavalor"));	
	}


  var codDropshipping = curPedido.valueBuffer("em_coddropshipping");
  if(codDropshipping && codDropshipping != "") {
  	var nombre = curPedido.valueBuffer("nombrecliente");
  	var idPedido = curPedido.valueBuffer("idpedido");
  	var pedidoPrivalia = AQUtil.sqlSelect("em_cargadropshipping","pedidoprivalia","idpedido = " + idPedido);
  	var descripcion = nombre + " / " + pedidoPrivalia;
  	_i.curAlbaran.setValueBuffer("descripciondir", descripcion);
  } else {
  	 _i.curAlbaran.setValueBuffer("descripciondir", AQUtil.sqlSelect("dirclientes","descripcion","id = " + curPedido.valueBuffer("coddir")));
  }
  
  if(curPedido.valueBuffer("em_coddropshipping") && curPedido.valueBuffer("em_coddropshipping") != ""){
  	_i.curAlbaran.setValueBuffer("em_coddropshipping", curPedido.valueBuffer("em_coddropshipping"));
  }

	var distinAutorizados = AQUtil.sqlSelect("pedidoscli", "count(distinct(em_autorizadocostes))", where );	
	if(distinAutorizados > 1) {
		_i.curAlbaran.setValueBuffer("em_autorizadocostes", false);	
	} else {
		_i.curAlbaran.setValueBuffer("em_autorizadocostes", curPedido.valueBuffer("em_autorizadocostes"));
	}
	
	_i.curAlbaran.setValueBuffer("em_estadocostes", curPedido.valueBuffer("em_estadocostes"));
	_i.curAlbaran.setValueBuffer("em_politicacostes", curPedido.valueBuffer("em_politicacostes"));
	_i.curAlbaran.setValueBuffer("em_motivocostes", curPedido.valueBuffer("em_motivocostes"));

  return true;
}

function euromoda_commonCalculateField(fN, cursor)
{
  var _i = this.iface;
  var valor;

  switch (fN) {
  case "pordtoesp_fp": {
      valor = AQUtil.sqlSelect("formaspago", "pordtoesp", "codpago = '" + cursor.valueBuffer("codpago") + "'");
      valor = parseFloat(AQUtil.roundFieldValue(valor, "pedidoscli", "pordtoesp"));
      break;
    }
	case "fechaservicio": {
      valor = AQUtil.sqlSelect("lineaspedidoscli", "fechaservicio", "idpedido = " + cursor.valueBuffer("idpedido") + " AND NOT cerrada AND cantidad - totalenalbaran - servidogit > 0 ORDER BY fechaservicio DESC");
			var fCliente = cursor.valueBuffer("fechasalida");
			if (fCliente) {
				if (AQUtil.daysTo(valor, fCliente) > 0) {
					valor = fCliente;
				}
			}
      break;
    }
	case "codserie": {
		if (cursor.valueBuffer("codserie") == "Z") {
			valor = "Z"; /// Migraci�n
			break;
		}
		valor = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli gc ON c.codgrupocontablecli = gc.codgrupo", "gc.codseriefac", "c.codcliente = '" + cursor.valueBuffer("codcliente") + "'", "clientes");
		break;
	}
	case "dirfacturacion": {
		valor = formpresupuestoscli.iface.pub_commonCalculateField(fN, cursor);
		break;
	}
	default: {
      valor = _i.__commonCalculateField(fN, cursor);
      break;
    }
  }
  return valor;
}

function euromoda_generarAlbaran(where, curPedido, datosAgrupacion)
{
  	var _i = this.iface;
  
  	var codCliente = curPedido.valueBuffer("codcliente");
  	//if (codCliente && codCliente != "") {
	if (codCliente && codCliente != "" && !_i.silent_) { //12-02-2020 Generar Albaran CDB
		if (!flfacturac.iface.pub_controlBloqueoCliente(codCliente, "Enviar")) {
		  return false;
		}
		if (!flfacturac.iface.pub_controlRiesgoCliente(codCliente, true)) {
		  return false;
		}
	}

  var idAlbaran = _i.__generarAlbaran(where, curPedido, datosAgrupacion);
	if (!idAlbaran) {
		return false;
	}
//   if (!_i.__generarAlbaran(where, curPedido, datosAgrupacion)) {
//     return false;
//   }
  return idAlbaran;
}

function euromoda_datosLineaAlbaran(curLineaPedido)
{
	
  var _i = this.iface;

  if (!_i.__datosLineaAlbaran(curLineaPedido)) {
    return false;
  }

  _i.curLineaAlbaran.setValueBuffer("tipoconcepto", curLineaPedido.valueBuffer("tipoconcepto"));
  _i.curLineaAlbaran.setValueBuffer("texto", curLineaPedido.valueBuffer("texto"));
  _i.curLineaAlbaran.setValueBuffer("codsubcuenta", curLineaPedido.valueBuffer("codsubcuenta"));
  if (curLineaPedido.valueBuffer("idsubcuenta")) {
    _i.curLineaAlbaran.setValueBuffer("idsubcuenta", curLineaPedido.valueBuffer("idsubcuenta"));
  }
  _i.curLineaAlbaran.setValueBuffer("codamortizacion", curLineaPedido.valueBuffer("codamortizacion"));
	_i.curLineaAlbaran.setValueBuffer("codarancelario", curLineaPedido.valueBuffer("codarancelario"));
	_i.curLineaAlbaran.setValueBuffer("refcliente", curLineaPedido.valueBuffer("refcliente"));
	_i.curLineaAlbaran.setValueBuffer("codtamanoem", curLineaPedido.valueBuffer("codtamanoem"));
	_i.curLineaAlbaran.setValueBuffer("codcolorem", curLineaPedido.valueBuffer("codcolorem"));

	if(curLineaPedido.valueBuffer("tipoconcepto") == "Producto") {	
		//21-01-2019 Que vaya por separado el coste y el margen a la hora de evaluar si se recalcula o se copia.	
		var costeProd = false;
		var margenProd = false;	
		if(curLineaPedido.valueBuffer("em_costeprod") && curLineaPedido.valueBuffer("em_costeprod") != "" && !curLineaPedido.isNull("em_costeprod")) {
			_i.curLineaAlbaran.setValueBuffer("em_costeprod", curLineaPedido.valueBuffer("em_costeprod"));
			_i.curLineaAlbaran.setValueBuffer("em_fechacosteprod", curLineaPedido.valueBuffer("em_fechacosteprod"));
			_i.curLineaAlbaran.setValueBuffer("em_horacosteprod", curLineaPedido.valueBuffer("em_horacosteprod"));
		} else {
			costeProd = true;
		}	
		if(curLineaPedido.valueBuffer("em_margenprod") && curLineaPedido.valueBuffer("em_margenprod") != "" && !curLineaPedido.isNull("em_margenprod")) {
			_i.curLineaAlbaran.setValueBuffer("em_margenprod", curLineaPedido.valueBuffer("em_margenprod"));
			_i.curLineaAlbaran.setValueBuffer("em_fechamargenprod", curLineaPedido.valueBuffer("em_fechamargenprod"));
			_i.curLineaAlbaran.setValueBuffer("em_horamargenprod", curLineaPedido.valueBuffer("em_horamargenprod"));
		} else {
			margenProd = true;
		}
		if(costeProd || margenProd) {
			var oParamLin = new Object;
			oParamLin.cursor = _i.curLineaAlbaran;
			oParamLin.ignorarAvisos = true;
			oParamLin.forzarReg = false;
			oParamLin.ignorarCalculoInsert = false; 

			var codCliente;
			var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(_i.curLineaAlbaran);
			if (!datosTP) {
				codCliente = false;
			} else {
				codCliente = datosTP["codcliente"];
			}

			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",codCliente);			
			formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);	
		} else {
			_i.curLineaAlbaran.setValueBuffer("em_estadocostes", curLineaPedido.valueBuffer("em_estadocostes"));
			_i.curLineaAlbaran.setValueBuffer("em_politicacostes", curLineaPedido.valueBuffer("em_politicacostes"));
			_i.curLineaAlbaran.setValueBuffer("em_motivocostes", curLineaPedido.valueBuffer("em_motivocostes"));
			_i.curLineaAlbaran.setValueBuffer("em_alarmaoff", curLineaPedido.valueBuffer("em_alarmaoff"));
		}

	}

  return true;
}

function euromoda_copiaLineas(idPedido, idAlbaran)
{
	var _i = this.iface;	
	var cantidad:Number;
	var totalEnAlbaran:Number;
	var curLineaPedido:FLSqlCursor = new FLSqlCursor("lineaspedidoscli");
	curLineaPedido.select("idpedido = " + idPedido + " AND (cerrada = false or cerrada IS NULL) ORDER BY numlinea");
	while (curLineaPedido.next()) {
		curLineaPedido.setModeAccess(curLineaPedido.Browse);
		curLineaPedido.refreshBuffer();
		cantidad = parseFloat(curLineaPedido.valueBuffer("cantidad"));
		totalEnAlbaran = parseFloat(curLineaPedido.valueBuffer("totalenalbaran"));

		if (cantidad != totalEnAlbaran || curLineaPedido.valueBuffer("tipoconcepto") == "Texto") {
			/*if (!this.iface.copiaLineaPedido(curLineaPedido, idAlbaran)) {
				return false;
			}*/
			/******************#H1384 Ver asociar pedidos a un albaran de Euromoda*********************************************/	
			if (!_i.copiaLineaPedidoParcial(curLineaPedido, idAlbaran)) {
				return false;
			}
			curLineaPedido.setValueBuffer("totalenalbaran", cantidad + totalEnAlbaran);
			if (!curLineaPedido.commitBuffer()) {
				return false;
			}
			/*****************#H1384 Ver asociar pedidos a un albaran de Euromoda*********************************************/	
		}
	}
	return true;
}

function euromoda_copiaLineaPedidoParcial(curLineaPedido, idAlbaran)
{
	var util:FLUtil = new FLUtil;
	var _i = this.iface;

// 	if(curLineaPedido.valueBuffer("cerrada")) {
// 		MessageBox.warning(util.translate("scripts", "No se pueden servir l�neas cerradas."), MessageBox.Ok, MessageBox.NoButton);
// 		return false;
// 	}

	if (!this.iface.curLineaAlbaran)
		this.iface.curLineaAlbaran = new FLSqlCursor("lineasalbaranescli");

	with (this.iface.curLineaAlbaran) {
		setModeAccess(Insert);
		refreshBuffer();
		setValueBuffer("idalbaran", idAlbaran);
	}

	var cantidad:Number = parseFloat(curLineaPedido.valueBuffer("canalbaran"));
	var pvpSinDto:Number = parseFloat(curLineaPedido.valueBuffer("pvpsindto")) * cantidad / parseFloat(curLineaPedido.valueBuffer("cantidad"));
	pvpSinDto = util.roundFieldValue(pvpSinDto, "lineasalbaranescli", "pvpsindto");

	_i.numLinea_++;
	with (this.iface.curLineaAlbaran) {
		setValueBuffer("idlineapedido", curLineaPedido.valueBuffer("idlinea"));
		setValueBuffer("idpedido", curLineaPedido.valueBuffer("idpedido"));
		setValueBuffer("referencia", curLineaPedido.valueBuffer("referencia"));
		setValueBuffer("descripcion", curLineaPedido.valueBuffer("descripcion"));
		setValueBuffer("pvpunitario", curLineaPedido.valueBuffer("pvpunitario"));
		setValueBuffer("cantidad", cantidad);
		setValueBuffer("codimpuesto", curLineaPedido.valueBuffer("codimpuesto"));
		setValueBuffer("iva", curLineaPedido.valueBuffer("iva"));
		setValueBuffer("recargo", curLineaPedido.valueBuffer("recargo"));
		setValueBuffer("dtolineal", curLineaPedido.valueBuffer("dtolineal"));
		setValueBuffer("dtopor", curLineaPedido.valueBuffer("dtopor"));
		setValueBuffer("numlinea", _i.numLinea_);
	}

	this.iface.curLineaAlbaran.setValueBuffer("pvpsindto", pvpSinDto);
	this.iface.curLineaAlbaran.setValueBuffer("pvptotal", formRecordlineaspedidoscli.iface.pub_commonCalculateField("pvptotal", this.iface.curLineaAlbaran));

	if (!this.iface.curLineaAlbaran.commitBuffer())
		return false;

	return this.iface.curLineaAlbaran.valueBuffer("idlinea");
}

function euromoda_copiaLineasParcial(idPedido, idAlbaran)
{
	var _i = this.iface;
	_i.numLinea_ = 0;
	var _fP = flfactppal.iface;
	var cantidad;
	cantidad = 0;
	var totalEnAlbaran;
	totalEnAlbaran = 0;
	
	if(_fP.pub_extension("numeros_linea")) {
		_i.numLinea_ = 0;
	}
	
	var curLineaPedido:FLSqlCursor = new FLSqlCursor("lineaspedidoscli");
	curLineaPedido.select("idpedido = " + idPedido);
	while (curLineaPedido.next()) {
		curLineaPedido.setModeAccess(curLineaPedido.Edit);
		curLineaPedido.refreshBuffer();
		cantidad = parseFloat(curLineaPedido.valueBuffer("canalbaran"));
		totalEnAlbaran = parseFloat(curLineaPedido.valueBuffer("totalenalbaran"));
		debug("totalEnAlbaran: " +totalEnAlbaran);
		debug("cantidad: "+cantidad);
		if (_i.lineaParcialCopiable(curLineaPedido, idAlbaran)) {
			if (!_i.copiaLineaPedidoParcial(curLineaPedido, idAlbaran)) {
				return false;
			}
			//aqui si es de tejido la canalbaran deber�a de ser 0 04-02-2022
			if (flfactalma.iface.pub_esTrazable(curLineaPedido.valueBuffer("referencia"))) {
				cantidad = 0;
			}
			curLineaPedido.setValueBuffer("totalenalbaran", cantidad + totalEnAlbaran);
			if (!curLineaPedido.commitBuffer()) {
				return false;
			}
			debug("totalEnAlbaran2: " +curLineaPedido.valueBuffer("totalenalbaran"));
		}
	}
	return true;
}

function euromoda_imprimir(codPedido)
{
  oficial_imprimir(codPedido);
}

function euromoda_lineaParcialCopiable(curLineaPedido, idAlbaran)
{
	var cantidad = parseFloat(curLineaPedido.valueBuffer("canalbaran"));
	return (cantidad != 0 || curLineaPedido.valueBuffer("tipoconcepto") == "Texto");
}

function euromoda_pbnGenerarFactura_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.valueBuffer("servido") != "No") {
		sys.warnMsgBox(sys.translate("No puede facturar un pedido total o parcialmente servido, debe facturar sus albaranes"));
		return;
	}
  var where = "idpedido = " + cursor.valueBuffer("idpedido");

	var idFactura = cursor.valueBuffer("idfactura");
	if (idFactura) {
    sys.warnMsgBox(sys.translate("Ya existe la factura correspondiente a este pedido"));
    _i.procesarEstado();
    return;
  }
  _i.pbnGFactura.setEnabled(false);

  cursor.transaction(false);
  try {
    if (_i.generarFactura(where, cursor)) {
      cursor.commit();
		} else {
      cursor.rollback();
		}
  } catch (e) {
    cursor.rollback();
		sys.errorMsgBox(sys.translate("Hubo un error en la generaci�n de la factura:") + e);
  }

  _i.tdbRecords.refresh();
  _i.procesarEstado();
}

function euromoda_generarFactura(where, curPedido, datosAgrupacion)
{
  var _i = this.iface;
  var codCliente = curPedido.valueBuffer("codcliente");
  if (codCliente && codCliente != "") {
    if (!flfacturac.iface.pub_controlBloqueoCliente(codCliente, "Facturar")) {
      return false;
    }
  }
  _i.numLinea_ = 0;

  if (!_i.curFactura) {
    _i.curFactura = new FLSqlCursor("facturascli");
	}
  _i.curFactura.setModeAccess(_i.curFactura.Insert);
  _i.curFactura.refreshBuffer();

  if (!_i.datosFactura(curPedido, where, datosAgrupacion)) {
    return false;
  }

  if (!_i.curFactura.commitBuffer()) {
    return false;
  }

  var idFactura = _i.curFactura.valueBuffer("idfactura");

  var curPedidos = new FLSqlCursor("pedidoscli");
  curPedidos.select(where);
  var idPedido;
  while (curPedidos.next()) {
    curPedidos.setModeAccess(curPedidos.Browse);
    curPedidos.refreshBuffer();
    idPedido = curPedidos.valueBuffer("idPedido");
    if (!_i.copiaLineasPedidoFactura(idPedido, idFactura)) {
      return false;
    }
  }

  _i.curFactura.select("idfactura = " + idFactura);
  if (_i.curFactura.first()) {
    _i.curFactura.setModeAccess(_i.curFactura.Edit);
    _i.curFactura.refreshBuffer();

		formalbaranescli.iface.curFactura = _i.curFactura
    if (!formalbaranescli.iface.totalesFactura()) {
      return false;
		}
    if (!_i.curFactura.commitBuffer()) {
      return false;
		}
  }
  if (!formalbaranescli.iface.validarFactura(idFactura)) {
    return false;
  }

  curPedidos.select(where);
  while (curPedidos.next()) {
    curPedidos.setModeAccess(curPedidos.Edit);
    curPedidos.refreshBuffer();
    if (curPedidos.valueBuffer("idfactura")) {
      var codFacturaPed = AQUtil.sqlSelect("facturascli", "codigo", "idfactura = " + curPedidos.valueBuffer("idfactura"));
      sys.warnMsgBox(sys.translate("Error al facturar el pedido %1. Este pedido ya est� facturado en la factura %2").arg(curPedidos.valueBuffer("codigo")).arg(codFacturaAlb), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
    curPedidos.setValueBuffer("idfactura", idFactura);
    if (!curPedidos.commitBuffer()) {
      return false;
    }
  }
  return idFactura;
}

function euromoda_datosFactura(curPedido, where, datosAgrupacion)
{
  var _i = this.iface;
  var util: FLUtil = new FLUtil();
  var fecha: String;
  var hora: String;
  if (datosAgrupacion) {
    fecha = datosAgrupacion["fecha"];
    hora = datosAgrupacion["hora"];
  } else {
    var hoy: Date = new Date();
    fecha = hoy.toString();
    hora = hoy.toString().right(8);
  }

  var codEjercicio: String = curPedido.valueBuffer("codejercicio");
  var datosDoc: Array = flfacturac.iface.pub_datosDocFacturacion(fecha, codEjercicio, "facturascli");
  if (!datosDoc.ok)
    return false;
  if (datosDoc.modificaciones == true) {
    codEjercicio = datosDoc.codEjercicio;
    fecha = datosDoc.fecha;
  }

  with(_i.curFactura) {
    setValueBuffer("codserie", curPedido.valueBuffer("codserie"));
    setValueBuffer("codejercicio", codEjercicio);
    setValueBuffer("irpf", curPedido.valueBuffer("irpf"));
    setValueBuffer("fecha", fecha);
    setValueBuffer("hora", hora);
    setValueBuffer("codagente", curPedido.valueBuffer("codagente"));
    setValueBuffer("porcomision", curPedido.valueBuffer("porcomision"));
    setValueBuffer("codalmacen", curPedido.valueBuffer("codalmacen"));
    setValueBuffer("codpago", curPedido.valueBuffer("codpago"));
    setValueBuffer("coddivisa", curPedido.valueBuffer("coddivisa"));
    setValueBuffer("tasaconv", curPedido.valueBuffer("tasaconv"));
    setValueBuffer("codcliente", curPedido.valueBuffer("codcliente"));
    setValueBuffer("cifnif", curPedido.valueBuffer("cifnif"));
    setValueBuffer("nombrecliente", curPedido.valueBuffer("nombrecliente"));
    setValueBuffer("observaciones", curPedido.valueBuffer("observaciones"));
    setValueBuffer("recfinanciero", curPedido.valueBuffer("recfinanciero"));
		setValueBuffer("deabono", false);
		setValueBuffer("automatica", true);
		setValueBuffer("incoterm", curPedido.valueBuffer("incoterm"));
		setValueBuffer("pordtoesp", curPedido.valueBuffer("pordtoesp"));
		setValueBuffer("codgrupoivaneg", curPedido.valueBuffer("codgrupoivaneg"));

	//Cambiado por #EUR #H1384 #T2 Propagaci�n de fecha valor de pedido a albar�n y de albar�n a factura de cliente
	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	if (datosAgrupacion) {
		if("optFechaValor" in datosAgrupacion && datosAgrupacion.optFechaValor == "Agrupar por fecha valor") {
			setValueBuffer("fechavalor", curPedido.valueBuffer("fechavalor"));
		} 
	}else {
		setValueBuffer("fechavalor", curPedido.valueBuffer("fechavalor"));	
	}	
	//////////////////////////////////////////////////////////////////////////////////////////////////////
  }


  with (_i.curFactura) {
    setValueBuffer("em_codpago", curPedido.valueBuffer("em_codpago"));
		setValueBuffer("codagencia", curPedido.valueBuffer("codagencia"));
		setValueBuffer("docexterno", curPedido.valueBuffer("docexterno"));
		setValueBuffer("departamento", curPedido.valueBuffer("departamento"));
		setValueBuffer("pobincoterm", curPedido.valueBuffer("pobincoterm"));
  }

  var codCliente = curPedido.valueBuffer("codcliente");
  if (codCliente) {
    var codClienteFac = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente = '" + codCliente + "'");
		var q = new FLSqlQuery;
		q.setSelect("c.nombre, c.cifnif, dc.id, dc.direccion, dc.codpostal, dc.ciudad, dc.provincia, dc.codpais");
		q.setFrom("clientes c INNER JOIN dirclientes dc ON (c.codcliente = dc.codcliente AND dc.domfacturacion)");
		q.setForwardOnly(true);
    if (codClienteFac) {
      q.setWhere("c.codcliente = '" + codClienteFac + "'");
      if (!q.exec()) {
        return false;
      }
      if (!q.first()) {
        MessageBox.warning(sys.translate("Error al obtener los datos y direcci�n de facturaci�n del cliente de facturaci�n %1").arg(codClienteFac). MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
        return false;
      }
      with (_i.curFactura) {
        setValueBuffer("codcliente", codClienteFac);
        setValueBuffer("cifnif", q.value("c.cifnif"));
        setValueBuffer("nombrecliente", q.value("c.nombre"));
        setValueBuffer("coddir", q.value("dc.id"));
        setValueBuffer("direccion", q.value("dc.direccion"));
        setValueBuffer("codpostal", q.value("dc.codpostal"));
        setValueBuffer("ciudad", q.value("dc.ciudad"));
        setValueBuffer("provincia", q.value("dc.provincia"));
        setValueBuffer("codpais", q.value("dc.codpais"));
			}
    } else {
      q.setWhere("c.codcliente = '" + codCliente + "'");
      if (!q.exec()) {
        return false;
      }
      if (!q.first()) {
        MessageBox.warning(sys.translate("Error al obtener los datos y direcci�n de facturaci�n del cliente de facturaci�n %1").arg(codClienteFac). MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
        return false;
      }
      with (_i.curFactura) {
        setValueBuffer("coddir", q.value("dc.id"));
        setValueBuffer("direccion", q.value("dc.direccion"));
        setValueBuffer("codpostal", q.value("dc.codpostal"));
        setValueBuffer("ciudad", q.value("dc.ciudad"));
        setValueBuffer("provincia", q.value("dc.provincia"));
        setValueBuffer("codpais", q.value("dc.codpais"));
			}
		}
  }
  with (_i.curFactura) {
		setValueBuffer("coddire", curPedido.valueBuffer("coddir"));
		setValueBuffer("direccione", curPedido.valueBuffer("direccion"));
		setValueBuffer("codpostale", curPedido.valueBuffer("codpostal"));
		setValueBuffer("ciudade", curPedido.valueBuffer("ciudad"));
		setValueBuffer("provinciae", curPedido.valueBuffer("provincia"));
		setValueBuffer("codpaise", curPedido.valueBuffer("codpais"));
	}
  return true;
}

function euromoda_copiaLineasPedidoFactura(idPedido, idFactura)
{
	var _i = this.iface;
  var curLineaPedido = new FLSqlCursor("lineaspedidoscli");
  curLineaPedido.select("idpedido = " + idPedido + " ORDER BY numlinea");

  while (curLineaPedido.next()) {
    curLineaPedido.setModeAccess(curLineaPedido.Browse);
    if (!_i.copiaLineaPedidoFactura(curLineaPedido, idFactura)) {
      return false;
		}
  }
  return true;
}

function euromoda_copiaLineaPedidoFactura(curLineaPedido, idFactura)
{
	var _i = this.iface;
  if (!_i.curLineaFactura) {
    _i.curLineaFactura = new FLSqlCursor("lineasfacturascli");
	}
  with(_i.curLineaFactura) {
    setModeAccess(Insert);
    refreshBuffer();
    setValueBuffer("idfactura", idFactura);
  }

  if (!_i.datosLineaPedidoFactura(curLineaPedido)) {
    return false;
	}
  if (!_i.curLineaFactura.commitBuffer()) {
    return false;
	}
  return _i.curLineaFactura.valueBuffer("idlinea");
}

function euromoda_datosLineaPedidoFactura(curLineaPedido)
{
	var _i = this.iface;
  var iva, recargo;
  var codImpuesto = curLineaPedido.valueBuffer("codimpuesto");

	
	_i.curLineaFactura.setValueBuffer("referencia", curLineaPedido.valueBuffer("referencia"));
	_i.curLineaFactura.setValueBuffer("descripcion", curLineaPedido.valueBuffer("descripcion"));
	_i.curLineaFactura.setValueBuffer("pvpunitario", curLineaPedido.valueBuffer("pvpunitario"));
	_i.curLineaFactura.setValueBuffer("pvpsindto", curLineaPedido.valueBuffer("pvpsindto"));
	_i.curLineaFactura.setValueBuffer("cantidad", curLineaPedido.valueBuffer("cantidad"));
	_i.curLineaFactura.setValueBuffer("pvptotal", curLineaPedido.valueBuffer("pvptotal"));
	_i.curLineaFactura.setValueBuffer("codimpuesto", codImpuesto);
    if (curLineaPedido.isNull("iva")) {
      setNull("iva");
    } else {
      iva = curLineaPedido.valueBuffer("iva");
      if (iva != 0 && codImpuesto && codImpuesto != "") {
			iva = formRecordlineaspedidoscli.iface.pub_commonCalculateField("iva", _i.curLineaFactura); /// Para cambio de IVA seg�n fechas
      }
		_i.curLineaFactura.setValueBuffer("iva", iva);
    }
    if (curLineaPedido.isNull("recargo")) {
      setNull("recargo");
    } else {
      recargo = curLineaPedido.valueBuffer("recargo");
      if (recargo != 0 && codImpuesto && codImpuesto != "") {
			recargo = formRecordlineaspedidoscli.iface.pub_commonCalculateField("recargo", _i.curLineaFactura); /// Para cambio de IVA seg�n fechas
      }
		_i.curLineaFactura.setValueBuffer("recargo", recargo);
    }
	_i.curLineaFactura.setValueBuffer("irpf", curLineaPedido.valueBuffer("irpf"));
	_i.curLineaFactura.setValueBuffer("dtolineal", curLineaPedido.valueBuffer("dtolineal"));
	_i.curLineaFactura.setValueBuffer("dtopor", curLineaPedido.valueBuffer("dtopor"));
	_i.curLineaFactura.setValueBuffer("porcomision", curLineaPedido.valueBuffer("porcomision"));	

  var codEjercicio = AQUtil.sqlSelect("facturascli", "codejercicio", "idfactura = " + _i.curLineaFactura.valueBuffer("idfactura"));

	_i.numLinea_++;
	_i.curLineaFactura.setValueBuffer("numlinea", _i.numLinea_);

	if (curLineaPedido.valueBuffer("tipoconcepto") != "Texto") {
		var codSubcuenta = curLineaPedido.valueBuffer("codsubcuenta");
		if (codSubcuenta) {
			_i.curLineaFactura.setValueBuffer("codsubcuenta", codSubcuenta);
			if (curLineaPedido.valueBuffer("idsubcuenta")) {
				_i.curLineaFactura.setValueBuffer("idsubcuenta", curLineaPedido.valueBuffer("idsubcuenta"));
			}
		} else {
			var codEjercicio = AQUtil.sqlSelect("facturascli", "codejercicio", "idfactura = " + _i.curLineaFactura.valueBuffer("idfactura"));
			codSubcuenta = formRecordlineaspedidoscli.iface.pub_dameSubcuentaProducto(_i.curLineaFactura);
			if (codSubcuenta) {
				_i.curLineaFactura.setValueBuffer("codsubcuenta", codSubcuenta);
				var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
				if (idSubcuenta) {
					_i.curLineaFactura.setValueBuffer("idsubcuenta", idSubcuenta);
				}
			}
		}
		if (!codSubcuenta || codSubcuenta == "" || codSubcuenta == 0) {
			MessageBox.warning(sys.translate("Error a facturar la l�nea %1. No se ha encontrado la subcuenta de ventas asociada al producto, activo o cuenta").arg(curLineaPedido.valueBuffer("numlinea")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}

	}

  var codArancelario = curLineaPedido.valueBuffer("codarancelario")
  if (!codArancelario || codArancelario == "") {
		codArancelario = AQUtil.sqlSelect("articulos", "codarancelario", "referencia = '" + curLineaPedido.valueBuffer("referencia") + "'");
	}
  _i.curLineaFactura.setValueBuffer("codarancelario", codArancelario);
  _i.curLineaFactura.setValueBuffer("tipoconcepto", curLineaPedido.valueBuffer("tipoconcepto"));
  _i.curLineaFactura.setValueBuffer("texto", curLineaPedido.valueBuffer("texto"));
	_i.curLineaFactura.setValueBuffer("codamortizacion", curLineaPedido.valueBuffer("codamortizacion"));
	_i.curLineaFactura.setValueBuffer("refcliente", curLineaPedido.valueBuffer("refcliente"));
	_i.curLineaFactura.setValueBuffer("codtamanoem", curLineaPedido.valueBuffer("codtamanoem"));
	_i.curLineaFactura.setValueBuffer("codcolorem", curLineaPedido.valueBuffer("codcolorem"));

	if (_i.curFactura.valueBuffer("deabono")) {
		_i.curLineaFactura.setValueBuffer("iva", curLineaPedido.valueBuffer("iva"));
		_i.curLineaFactura.setValueBuffer("recargo", curLineaPedido.valueBuffer("recargo"));
	}
	if(curLineaPedido.valueBuffer("tipoconcepto") == "Producto") {		
		var costeProd = false;
		var margenProd = false;	
		if(curLineaPedido.valueBuffer("em_costeprod") && curLineaPedido.valueBuffer("em_costeprod") != "" && !curLineaPedido.isNull("em_costeprod")) {
			_i.curLineaFactura.setValueBuffer("em_costeprod", curLineaPedido.valueBuffer("em_costeprod"));
			_i.curLineaFactura.setValueBuffer("em_fechacosteprod", curLineaPedido.valueBuffer("em_fechacosteprod"));
			_i.curLineaFactura.setValueBuffer("em_horacosteprod", curLineaPedido.valueBuffer("em_horacosteprod"));
		} else {
			costeProd = true;
		}	
		if(curLineaPedido.valueBuffer("em_margenprod") && curLineaPedido.valueBuffer("em_margenprod") != "" && !curLineaPedido.isNull("em_margenprod")) {
			_i.curLineaFactura.setValueBuffer("em_margenprod", curLineaPedido.valueBuffer("em_margenprod"));
			_i.curLineaFactura.setValueBuffer("em_fechamargenprod", curLineaPedido.valueBuffer("em_fechamargenprod"));
			_i.curLineaFactura.setValueBuffer("em_horamargenprod", curLineaPedido.valueBuffer("em_horamargenprod"));
		} else {
			margenProd = true;
		}
		if(costeProd || margenProd) {				
			var oParamLin = new Object;
			oParamLin.cursor = _i.curLineaFactura;
			oParamLin.ignorarAvisos = true;
			oParamLin.forzarReg = false;
			oParamLin.ignorarCalculoInsert = false; 

			var codCliente;
			var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(_i.curLineaFactura);
			if (!datosTP) {
				codCliente = false;
			} else {
				codCliente = datosTP["codcliente"];
			}
			
			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("facturascli", codCliente);	
			formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);	

		} else {
			_i.curLineaFactura.setValueBuffer("em_estadocostes", curLineaPedido.valueBuffer("em_estadocostes"));
			_i.curLineaFactura.setValueBuffer("em_politicacostes", curLineaPedido.valueBuffer("em_politicacostes"));
			_i.curLineaFactura.setValueBuffer("em_motivocostes", curLineaPedido.valueBuffer("em_motivocostes"));
			_i.curLineaFactura.setValueBuffer("em_alarmaoff", curLineaPedido.valueBuffer("em_alarmaoff"));
		}

	}


  return true;
}

function euromoda_dameColor(fN, fV, cursor, fT, sel)
{
	var color = "";
	switch (fN) {
		case "codigo": {
			if (cursor.valueBuffer("idfactura")) {
				color = flfactppal.iface.pub_dameColor("fondo_facturado");
			}
			break;
		}
		default: {
			return;
		}
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}

function euromoda_tbnEstadoProduccion_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.lineaAnt_ = undefined;
	var cod = cursor.valueBuffer("codigo");

	_i.inicializaTotalTareas();
	_i.inicializaTotalPrendasTareas();
	_i.inicializaOrdenes();

	_i.imprimirEstadoProduccion(cod);
	
}

function euromoda_tbnEstadoProduccionTP_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var cod = cursor.valueBuffer("codigo");

	_i.inicializaTotalTareas();
	_i.inicializaTotalPrendasTareas();
	_i.inicializaOrdenes();

	_i.imprimirEstadoProduccionTP(cod);

}

function euromoda_imprimirEstadoProduccion(codPedido)
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (!codPedido)
	{
		return false;
	}

	var oParam = _i.dameParamEstadoProduccion(codPedido);
	if (!oParam) {
		return;
	}

	oParam.nombreInforme = "i_estadoproduccion";

	_i.inicializaTotalTareas();
	_i.totalOrdenes_ = 0;
	_i.totalCant_ = 0;

	var curImprimir = new FLSqlCursor("i_pedidoscli");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_presupuestoscli_codigo", codPedido);
	curImprimir.setValueBuffer("h_presupuestoscli_codigo", codPedido);

	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
}

function euromoda_imprimirEstadoProduccionTP(codPedido)
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (!codPedido)
	{
		return false;
	}

	var oParam = _i.dameParamEstadoProduccion(codPedido);
	if (!oParam) {
		return;
	}

	oParam.nombreInforme = "i_estadoproduccion_tp";

	_i.inicializaTotalTareas();
	_i.totalOrdenes_ = 0;
	_i.totalCant_ = 0;

	var curImprimir = new FLSqlCursor("i_pedidoscli");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_presupuestoscli_codigo", codPedido);
	curImprimir.setValueBuffer("h_presupuestoscli_codigo", codPedido);

	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
}

function euromoda_dameParamEstadoProduccion(codPedido)
{
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.whereFijo = "pedidoscli.codigo = '" + codPedido + "'";

	return oParam;
}

function euromoda_dameEstado(nodo, campo)
{
	var _i = this.iface;

	if (!_i.totalTareas_) {
		_i.inicializaTotalTareas();
		_i.inicializaTotalPrendasTareas();
	}

	var orden = nodo.attributeValue("op.codorden");
	orden = orden && orden != "" ? orden : nodo.attributeValue("op2.codorden")
	var sumaTarea = _i.calculaNumOrdenes(orden);

	var tipoTarea = nodo.attributeValue("pr_tareas.idtipotarea");
	var cantidad = nodo.attributeValue("em_reservaspterx.cantidad");

	switch (tipoTarea) {
		case "PT":
		case "CV": {
			if (sumaTarea){
				_i.totalTareas_["PT"]++;
			}
			_i.totalPrendasTareas_["PT"] = parseFloat(_i.totalPrendasTareas_["PT"]) + parseFloat(cantidad);
			break;
		}
		case "J1":
		case "CH":
		case "CO": {
			if (sumaTarea){
				_i.totalTareas_["CH"]++;
			}
			_i.totalPrendasTareas_["CH"] = parseFloat(_i.totalPrendasTareas_["CH"]) + parseFloat(cantidad);
			break;
		}
		case "ACE":
		case "ACO": {
			if (sumaTarea){
				_i.totalTareas_["AC"]++;
			}
			_i.totalPrendasTareas_["AC"] = parseFloat(_i.totalPrendasTareas_["AC"]) + parseFloat(cantidad);
			break;
		}
		case "DC": {
			if (sumaTarea){
				_i.totalTareas_["DC"]++;
			}
			_i.totalPrendasTareas_["DC"] = parseFloat(_i.totalPrendasTareas_["DC"]) + parseFloat(cantidad);
			break;
		}
		default: {
			if (nodo.attributeValue(campo) == "TERMINADA") {
				if (sumaTarea){
					_i.totalTareas_["TE"]++;
				}
				_i.totalPrendasTareas_["TE"] = parseFloat(_i.totalPrendasTareas_["TE"]) + parseFloat(cantidad);
			}
			break;
		}
	}

	var idLinea = nodo.attributeValue("lineaspedidoscli.idlinea");
	var desc = nodo.attributeValue("pr_tareas.descripcion");

	if (_i.lineaAnt_ == idLinea) {
		if (desc && desc != "") {
			return desc;
		}
		else {
			return nodo.attributeValue(campo);
		}
	}

	var afaltas = nodo.attributeValue("movistock.reservaaf");
	var existencias = nodo.attributeValue("movistock.reservaex");
	var pendiente = nodo.attributeValue("movistock.reservapr");

	if (desc && desc != "") {
		return "EX: " + existencias + ", PR: " + pendiente + ", AF: " + afaltas + ", " + desc;
	}	else {
		return "EX: " + existencias + ", PR: " + pendiente + ", AF: " + afaltas + ", " + nodo.attributeValue(campo);
	}

}

function euromoda_inicializaTotalTareas()
{
	var _i = this.iface;

	_i.totalTareas_ = new Object;

	_i.totalTareas_["PT"] = 0;
	_i.totalTareas_["CH"] = 0;
	_i.totalTareas_["AC"] = 0;
	_i.totalTareas_["DC"] = 0;
	_i.totalTareas_["TE"] = 0;
}

function euromoda_inicializaTotalPrendasTareas()
{
	var _i = this.iface;

	_i.totalPrendasTareas_ = new Object;

	_i.totalPrendasTareas_["PT"] = 0;
	_i.totalPrendasTareas_["CH"] = 0;
	_i.totalPrendasTareas_["AC"] = 0;
	_i.totalPrendasTareas_["DC"] = 0;
	_i.totalPrendasTareas_["TE"] = 0;
}

function euromoda_inicializaOrdenes()
{
	var _i = this.iface;

	_i.ordenes_ = [];
}

function euromoda_dameTotalTareas(nodo, campo)
{
	var _i = this.iface;

	return _i.totalTareas_[campo];
}

function euromoda_dameTotalPrendasTareas(nodo, campo)
{
	var _i = this.iface;

	return _i.totalPrendasTareas_[campo];
}

function euromoda_calculaNumOrdenes(orden)
{
	var _i = this.iface;

	if (!_i.ordenes_) {
		_i.inicializaOrdenes();
	}

	var repetido = false;

	if (orden == "")
	{
		repetido = true;
	} else {
		for (var i = 0; i < _i.ordenes_.length; i++) {
			if (orden == _i.ordenes_[i]) {
				repetido = true;
				break;
			}
		}
	}


	if (!repetido) {
		_i.ordenes_[_i.ordenes_.length] = orden;
		_i.totalOrdenes_++;
		return true;
	}
	return false;
}

function euromoda_dameNumOrdenes()
{
	var _i = this.iface;

	return _i.totalOrdenes_;
}

function euromoda_cambioProceso(nodo, campo)
{
	var _i = this.iface;

	_i.inicializaTotalTareas();
	_i.inicializaTotalPrendasTareas();
	_i.inicializaOrdenes();

	_i.lineaAnt_ = undefined;
	_i.totalCant_ = 0;
	_i.totalOrdenes_ = 0;

	return nodo.attributeValue(campo);
}

function euromoda_pintolinea(nodo, campo)
{
	var _i = this.iface;

	var idLinea = nodo.attributeValue("lineaspedidoscli.idlinea");
	if (_i.lineaAnt_ != idLinea) {
		switch (campo) {
			case "ref": {
				return nodo.attributeValue("lineaspedidoscli.referencia");
			}
			case "desc": {
				_i.lineaAnt_ = idLinea;

				var tamano = nodo.attributeValue("articulos.codtamanoem");
				var color = nodo.attributeValue("articulos.codcolorem");

				return nodo.attributeValue("lineaspedidoscli.descripcion") + " " + tamano + " " + color;
			}
			case "cant": {
				_i.totalCant_ = parseInt(_i.totalCant_) + parseInt(nodo.attributeValue("lineaspedidoscli.cantidad"));
				return nodo.attributeValue("lineaspedidoscli.cantidad");
			}
		}
	} else {
		return "";
	}
}

function euromoda_ordenEstadoProd(nodo, campo)
{
	var _i = this.iface;
	var orden = nodo.attributeValue("op.codorden");
	orden = orden && orden != "" ? orden : nodo.attributeValue("op2.codorden")
	return orden;
}

function euromoda_dameTotalCant()
{
	var _i = this.iface;

	return _i.totalCant_;
}

function euromoda_almacenaFechaInforme()
{
	var _i = this.iface;

	_i.fechaInforme_ = new Date();
	_i.formateaFechaInforme();
}

function euromoda_dameFechaInforme()
{
	var _i = this.iface;

	return _i.fechaInforme_;
}

function euromoda_formateaFechaInforme()
{
	var _i = this.iface;

	var fecha = _i.fechaInforme_;

	var anio = fecha.getYear();
	var mes = fecha.getMonth();
	var dia = fecha.getDate();
	var hora = fecha.getHours();
	var minuto = fecha.getMinutes();

	var arrayMeses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

	if (hora < 10) {
		hora = "0" + hora;
	}

	if (minuto < 10) {
		minuto = "0" + minuto;
	}

	_i.fechaInforme_ = dia + " de " + arrayMeses[mes-1] + " de " + anio + " - " + hora + ":" + minuto;
}

function euromoda_datosDirAlbaran(curPedido, where, datosAgrupacion)
{
	var _i = this.iface;
	var codCliente = curPedido.valueBuffer("codcliente");
	var codDir;
	with (_i.curAlbaran) {
		codDir = curPedido.valueBuffer("coddir")
		if (codDir == 0) {
			setNull("coddir");
		} else  {
			setValueBuffer("coddir", curPedido.valueBuffer("coddir"));
		}
		setValueBuffer("direccion", curPedido.valueBuffer("direccion"));
		setValueBuffer("codpostal", curPedido.valueBuffer("codpostal"));
		setValueBuffer("ciudad", curPedido.valueBuffer("ciudad"));
		setValueBuffer("provincia", curPedido.valueBuffer("provincia"));
		setValueBuffer("apartado", curPedido.valueBuffer("apartado"));
		setValueBuffer("codpais", curPedido.valueBuffer("codpais"));
	}
	return true;
}

function euromoda_copiaDatosPedido(curPedido)
{
	var _i = this.iface;
  
  if(!_i.__copiaDatosPedido(curPedido)) {
  	return false;
  }
  
  var fecha = _i.curPedido_.valueBuffer("fecha");
  if(!fecha || fecha == "") {
  	return false;
  }
  
  _i.curPedido_.setValueBuffer("fechasalida", fecha);

  return true;
}

function euromoda_totalesPedido()
{
	var _i = this.iface;
	
	if(!_i.__totalesPedido()) {
		return false;
	}
	
	_i.curPedido_.setValueBuffer("fechaservicio", formpedidoscli.iface.pub_commonCalculateField("fechaservicio", _i.curPedido_));
	
  return true;
}

function euromoda_pbnGenerarAlbaran_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var nombreBD = sys.nameBD();
	formpedidoscliparciales.iface.idAlbaran_ = false; //13-02-2020 generar albaranes CDB
	var codCliente = cursor.valueBuffer("codcliente");
	if (codCliente && codCliente != "") {
		if (!flfacturac.iface.pub_controlBloqueoCliente(codCliente, "Enviar")) {
		  return false;
		}
		if (!flfacturac.iface.pub_controlRiesgoCliente(codCliente, true)) {
		  return false;
		}
	}
	//if(nombreBD != "pruebas" && nombreBD != "abanq_creaciones") {
		_i.__pbnGenerarAlbaran_clicked(); //Descomentaremos esta llamada y lo de abajo lo eliminamos cuando pongamos generar albaranes CDB	
	/*} else {

		_i.asociarAlbaran_ = false;
		flfacturac.iface.geneFacturaCli = false;
		if (!cursor.isValid())
			return;
		if (!cursor.valueBuffer("editable"))
			return;

		var idPedido= cursor.valueBuffer("idpedido");
		delete this.iface.curPedido_;
		this.iface.curPedido_ = new FLSqlCursor("pedidoscli");
		this.iface.curPedido_.select("idpedido = " + idPedido);
		if (!this.iface.curPedido_.first())
			return;
		
		this.iface.curPedido_.setAction("pedidoscliparciales");
		connect(this.iface.curPedido_, "bufferCommited()", this, "iface.procesarEstado");
		this.iface.curPedido_.editRecord();
	}*/
}

function euromoda_tableDBRecords_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEdit_clicked();
}

function euromoda_toolButtomInsert_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");

}

function euromoda_toolButtonEdit_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDelete_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoom_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}

function euromoda_toolButtonCopy_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("copy");
}

function euromoda_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (_i.curP_) {
		disconnect(_i.curP_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curP_, "commited()", _i, "curP_bufferCommited");
		_i.curP_ = undefined;
	}
	
	_i.curP_ = new FLSqlCursor("pedidoscli");
	_i.curP_.setAction("pedidoscli");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curP_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curP_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curP_, "commited()", _i, "curP_bufferCommited");
			_i.curP_.insertRecord();
			break;
		}
		case "edit": {
			connect(_i.curP_, "commited()", _i, "refrescaTabla");
			_i.curP_.editRecord();
			break;
		}
		case "del": {
			this.child("tableDBRecords").deleteRecord();
			break;
		}
		case "browse": {	
			_i.curP_.browseRecord();
			break;
		}
		case "copy": {
			this.child("tableDBRecords").copyRecord(); // Deber�amos llamar a curP_.copyRecord, pero no est� publicado
			break;
		}
	}
}

function euromoda_refrescaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.refresh()
}

function euromoda_curP_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	this.child("tableDBRecords").refresh();
	var dtbLC = this.mainWidget().child("tableDBRecords").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);

	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);

	var oParams = [];
	oParams.fN = "codigo";
	oParams.valor = _i.pK_;
	oParams.cursor = cursor;
	oParams.tipoOrden = asc
	oParams.objTabla = this.child("tableDBRecords");

	var pos = flfacturac.iface.pub_buscaPosEnCursor(oParams);
	if (pos == -1) {
		debug("No encontrado");
		return false;
	}

	cursor.seek(pos);
	cursor.refresh()
}

function euromoda_estableceAlmacenDepositoAlbaran(codAlmaDeposito, curPedido)
{
	var _i = this.iface;
	var codAlmacenPedido = curPedido.valueBuffer("codalmacen");
	if(AQUtil.sqlSelect("almacenes", "em_deposito", "codalmacen = '" + codAlmacenPedido + "'") && codAlmacenPedido == codAlmaDeposito) {
		_i.curAlbaran.setValueBuffer("tipodeposito", "Venta dep�sito");
		_i.curAlbaran.setValueBuffer("codalmadeposito", codAlmaDeposito);
	} else {
	
	_i.curAlbaran.setValueBuffer("tipodeposito", "Entrega dep�sito");
	_i.curAlbaran.setValueBuffer("codalmadeposito", codAlmaDeposito);
	}

	return true;
}

function euromoda_totalesAlbaran()
{	
	var _i = this.iface;
	if(!_i.__totalesAlbaran()) {
		return false;
	}

	formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",_i.curAlbaran.valueBuffer("codcliente"));	
	
	if(!formRecordpresupuestoscli.iface.pub_evaluarCostesCab(_i.curAlbaran)) {
		return false;
	}			
	
	return true;	
}

function euromoda_pbnGenerarAlbaranCDB_clicked()
{
	var _i = this.iface;
	var f = new FLFormSearchDB("em_genalbarancdb");
	var curGenAlbCDB = f.cursor();  
	curGenAlbCDB.setModeAccess(curGenAlbCDB.Insert);
	curGenAlbCDB.refreshBuffer();
	_i.idPedAlbCDB_ = curGenAlbCDB.valueBuffer("em_idpedalbcdb");
	f.setMainWidget();
	f.exec();
}

/*function euromoda_pbnGenerarAlbaranCDB_clicked()
{
	var _i = this.iface;
	var curGenAlbCDB = new FLSqlCursor("em_genalbarancdb");
	curGenAlbCDB.insertRecord();
}*/


function euromoda_tbnExportarDatos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(!formalbaranescli.iface.exportarDatosCSV(cursor,false)){
		return false;
	}
	return true;

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
