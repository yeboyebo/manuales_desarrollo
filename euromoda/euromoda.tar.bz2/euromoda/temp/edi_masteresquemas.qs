
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
  function euromoda(context)
  {
    oficial(context);
  }
  function init()
  {
    this.ctx.euromoda_init();
  }
  function genEdiFileEmoda(codEsquema, where, fileName)
  {
    return this.ctx.euromoda_genEdiFileEmoda(codEsquema, where, fileName);
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx
{
  function pubEuromoda(context)
  {
    ifaceCtx(context);
  }
  function pub_genEdiFile(codEsquema, where, fileName)
  {
    return this.genEdiFileEmoda(codEsquema, where, fileName);
  }
  function pub_objEdiFromRec(curEsquema)
  {
    return this.objEdiFromRec(curEsquema);
  }
  function pub_funsEdiFromRec(curEsquema)
  {
    return this.funsEdiFromRec(curEsquema);
  }
  function pub_fieldsEdiFromRec(curEsquema)
  {
    return this.fieldsEdiFromRec(curEsquema);
  }
  function pub_formatValueEdi(val, field, objEdi)
  {
    return this.formatValueEdi(val, field, objEdi);
  }
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;

  var pwd = Input.getText(
              sys.translate("Restringido a desarrolladores\nContrase�a:"),
              "", "AbanQ"
            );
  if (!pwd || pwd != "3m0d4") {
    this.close();
    return;
  }

  _i.__init();
}

function euromoda_genEdiFileEmoda(codEsquema, where, fileName)
{
	var _i = this.iface;

	_i.cur_ = new FLSqlCursor("edi_esquemas");
	_i.cur_.select("codesquema='" + codEsquema + "'");
	_i.cur_.first();

	if (!_i.cur_.isValid()) {
		var msg = sys.translate("No existe el esquema ") + codEsquema;
		//sys.errorPopup(msg);
		debug(msg);
		return msg;
	}

	var objEdi = _i.objEdiFromRec(_i.cur_);
	var funs = _i.funsEdiFromRec(_i.cur_);
	var fields = _i.fieldsEdiFromRec(_i.cur_);

	if (where && where != "") {
		if (!objEdi.where || objEdi.where == "") {
			objEdi.where = where;
		} else {
			objEdi.where += " AND " + where;
		}
	}

	var txt = _i.genEdiText(objEdi, funs, fields);

	var workDir = "u:/edicom";
	_i.curSet_ = new AQSqlCursor("edi_settings");
	_i.curSet_.select("");
	if (_i.curSet_.first()) {
		workDir = _i.curSet_.valueBuffer("workdir");
	}
	var nombreFichero = objEdi.nombrefichero;	
	if(!nombreFichero || nombreFichero == "" || nombreFichero == undefined) {  
		nombreFichero = objEdi.cod;
	}
	
	
	if (!fileName || fileName == "") {
		//fileName = objEdi.cod;
		fileName = nombreFichero;
	}
	var filePath = workDir + "/" + fileName + ".txt";

	var file = new QFile(filePath);
	if (!file.open(File.WriteOnly)) {
		var msg = file.errorString();
		//sys.errorPopup(msg);
		debug(msg);
		return msg;
	}

	var ts = new QTextStream(file.ioDevice());
	ts.opIn(txt);
	file.close();

	debug(
		sys.translate("Fichero EDI generado en:\n") +
		filePath
	);

	return filePath;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
