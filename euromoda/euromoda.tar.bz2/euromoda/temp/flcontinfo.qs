
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends ivaNav {
	function euromoda( context ) { ivaNav ( context ); }
	function cabeceraInforme(nodo, campo) {
		return this.ctx.euromoda_cabeceraInforme(nodo, campo);
	}
    function compararAcumGruposIva(a, b) {
        return this.ctx.euromoda_compararAcumGruposIva(a, b);
    }
    function dameBasePie(i) {
        return this.ctx.euromoda_dameBasePie(i);
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_cabeceraInforme(nodo, campo)
{
	var _i = this.iface;
	var texto;
	var sep = "       ";
debug("NOMBE NFORME " + _i.nombreInformeActual);
	switch (_i.nombreInformeActual) {
		case "co_i_mayor_cli":
		case "co_i_mayor_prov": {
			var qCondiciones:FLSqlQuery = new FLSqlQuery();
			qCondiciones.setTablesList("co_i_mayor");
			qCondiciones.setFrom("co_i_mayor");
			qCondiciones.setWhere("id = " + _i.idInformeActual);
			qCondiciones.setSelect("descripcion, i_co__subcuentas_codejercicio, d_co__asientos_fecha, h_co__asientos_fecha, d_co__subcuentas_codsubcuenta, h_co__subcuentas_codsubcuenta");
debug("qCondiciones " + qCondiciones.sql()); 
			if (!qCondiciones.exec()) {
				return "";
			}
			if (!qCondiciones.first()) {
				return "";
			}
			var desc = qCondiciones.value(0);
			var ejAct = qCondiciones.value(1);
			var fchDesde = qCondiciones.value(2).toString().left(10);
			var fchHasta = qCondiciones.value(3).toString().left(10);
			var fchDesde = AQUtil.dateAMDtoDMA(fchDesde);
			var fchHasta = AQUtil.dateAMDtoDMA(fchHasta);
			var sctDesde = qCondiciones.value(4);
			var sctHasta = qCondiciones.value(5);

			texto = "[ " + desc + " ]" + sep + "Ejercicio " + ejAct + sep + "Periodo  " + fchDesde + " - " + fchHasta;
			break;
		}
		default: {
			texto = _i.__cabeceraInforme(nodo, campo);
		}
	}
	return texto;
}

function euromoda_compararAcumGruposIva(a, b)
{
    if (a["nombre"] > b["nombre"]) {
        return 1;
    } else if (a["nombre"] < b["nombre"]) {
        return -1
    } else {
        return 0;
    }
}

function euromoda_dameBasePie(i)
{
    const _i = this.iface;    
    return AQUtil.roundFieldValue(_i.gruposIvaNeg_[i]["base"], "co_partidas", "baseimponible");
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
