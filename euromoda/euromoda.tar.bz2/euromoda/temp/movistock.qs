
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var tblReservas_;
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function filtraReservas() {
		return this.ctx.euromoda_filtraReservas();
	}
	function cargaDatosInit() {
		return this.ctx.euromoda_cargaDatosInit();
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function validaLote() {
		return this.ctx.euromoda_validaLote();
	}
	function filtraReservasPteRx() {
		return this.ctx.euromoda_filtraReservasPteRx();
	}
	function commonCalculateField(fN, cursor) {
    	return this.ctx.euromoda_commonCalculateField(fN, cursor);
   } 
 	function iniciaTablaReservas() {
 		return this.ctx.euromoda_iniciaTablaReservas();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	_i.filtraReservas();
	_i.filtraReservasPteRx();
	_i.cargaDatosInit();
	_i.iniciaTablaReservas();

}

function euromoda_cargaDatosInit()
{
	debug("euromoda_cargaDatosInit");
	var _i = this.iface;
	var cursor = this.cursor();
	
	var curRel = cursor.cursorRelation();
	if (curRel && curRel.table() == "lotesstock" && cursor.valueBuffer("codlote") == curRel.valueBuffer("codlote")) {
		sys.disableObj(this, "fdbReferencia");
		sys.disableObj(this, "fdbIdStock");
		if (cursor.modeAccess() == cursor.Insert) {
			sys.setObjText(this, "fdbReferencia", curRel.valueBuffer("referencia"));
			var oArticulo = new Object;
			oArticulo.referencia = curRel.valueBuffer("referencia");
			var idStock = flfactalma.iface.pub_dameIdStock(curRel.valueBuffer("codalmacen"), oArticulo);
			sys.setObjText(this, "fdbIdStock", idStock);
		}
	}
}

function euromoda_filtraReservas()
{
	var cursor = this.cursor();
	var curR = this.child("tdbReservas").cursor();
	curR.setAction("em_reservasmovistock");
	if (AQUtil.sqlSelect("movistock", "idmovimiento", "idmovproducto = " + cursor.valueBuffer("idmovimiento"))) {
		this.child("tdbReservas").setFilter("idmovproducto = " + cursor.valueBuffer("idmovimiento"));
	} else {
		this.child("tdbReservas").setFilter("idmovproducto = -1");
	}
}

function euromoda_filtraReservasPteRx()
{
	this.child("tbwMovistock").setTabEnabled("reservas", false);
	
	var cursor = this.cursor();
	
	this.child("tdbReservasPteRx").setFilter("em_reservaspterx.idmovreserva = " + cursor.valueBuffer("idmovimiento"));
	
	this.child("tdbReservasRes").setFilter("em_reservaspterx.idmovpterx = " + cursor.valueBuffer("idmovimiento"));
// 	debug("euromoda_filtraReservasPteRx");
// 	var curR = this.child("tdbReservasPteRx").cursor();
// 	curR.setAction("em_reservasmovistock");
// 	curR.setMainFilter("idmovimiento IN (SELECT idmovpterx FROM em_reservaspterx WHERE idmovreserva = " + cursor.valueBuffer("idmovimiento") + ")");
}

function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.validaLote()) {
		return false;
	}
	return true;
}

function euromoda_validaLote()
{
	var cursor = this.cursor();
	if (!cursor.valueBuffer("codlote")) {
		if (flfactalma.iface.pub_esTrazable(cursor.valueBuffer("referencia"))) {
			sys.warnMsgBox(sys.translate("Debe indicar el c�digo de partida o pieza en el campo Lote"));
			return false;
		}
	}
	return true;
}

function euromoda_commonCalculateField(fN, cursor)
{
	var valor;
	switch (fN) {
		case "enreservares": {
			valor = AQUtil.sqlSelect("em_reservaspterx", "SUM(cantidad)", "idmovreserva = " + cursor.valueBuffer("idmovimiento"));
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
		case "enreservapterx": {
			valor = AQUtil.sqlSelect("em_reservaspterx", "SUM(cantidad)", "idmovpterx = " + cursor.valueBuffer("idmovimiento"));
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
	}
	return valor;
}

function euromoda_iniciaTablaReservas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (this.child("tdbReservasPteRx")) {
		this.child("tdbReservasPteRx").close();
	}
	if (this.child("tdbReservasRes")) {
		this.child("tdbReservasRes").close();
	}
	
	_i.tblReservas_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblReservas"));
	 
	 var q = new AQSqlQuery;
	if (cursor.valueBuffer("cantidad") < 0 && cursor.valueBuffer("estado") == "PTE") {
		if (AQUtil.sqlSelect("articulos", "em_tipoarticulo", "referencia = '" + cursor.valueBuffer("referencia") + "'") == "Producto") {
			q.setSelect("em_reservaspterx.id, em_reservaspterx.cantidad, lotesstock.codlote, lotesstock.estado, lotesstock.codordenproduccion");
			q.setFrom("em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovpterx = movistock.idmovimiento INNER JOIN lotesstock ON movistock.codlote = lotesstock.codlote");
			q.setWhere("em_reservaspterx.idmovreserva = " + cursor.valueBuffer("idmovimiento"));
		} else {
			q.setSelect("em_reservaspterx.id, em_reservaspterx.cantidad, em_lineasordenest.idlinea, em_lineasordenest.codordenest");
			q.setFrom("em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovpterx = movistock.idmovimiento INNER JOIN em_lineasordenest ON movistock.emidlineaest = em_lineasordenest.idlinea");
			q.setWhere("em_reservaspterx.idmovreserva = " + cursor.valueBuffer("idmovimiento"));
		}
		_i.tblReservas_.setQuery(q);
		_i.tblReservas_.refresh();
	} else if (cursor.valueBuffer("cantidad") > 0) {
		if (AQUtil.sqlSelect("articulos", "em_tipoarticulo", "referencia = '" + cursor.valueBuffer("referencia") + "'") == "Producto") {
			q.setSelect("em_reservaspterx.id, em_reservaspterx.cantidad, pedidoscli.codigo, lineaspedidoscli.numlinea, lineaspedidoscli.referencia, lineaspedidoscli.descripcion");
			q.setFrom("em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovreserva  = movistock.idmovimiento INNER JOIN lineaspedidoscli ON movistock.idlineapc = lineaspedidoscli.idlinea INNER JOIN pedidoscli ON lineaspedidoscli.idpedido = pedidoscli.idpedido");
			q.setWhere("em_reservaspterx.idmovpterx = " + cursor.valueBuffer("idmovimiento"));
		} else {
			q.setSelect("em_reservaspterx.id, em_reservaspterx.cantidad, pedidoscli.codigo, lineaspedidoscli.numlinea, lineaspedidoscli.referencia, lineaspedidoscli.descripcion");
			q.setFrom("em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovreserva  = movistock.idmovimiento INNER JOIN movistock ms2 ON (movistock.idmovproducto = ms2.idmovimiento OR movistock.idmovimiento = ms2.idmovimiento) INNER JOIN lineaspedidoscli ON ms2.idlineapc = lineaspedidoscli.idlinea INNER JOIN pedidoscli ON lineaspedidoscli.idpedido = pedidoscli.idpedido");
			q.setWhere("em_reservaspterx.idmovpterx = " + cursor.valueBuffer("idmovimiento"));
			if (q.exec() && q.size() == 0) {
				q.setSelect("em_reservaspterx.id, em_reservaspterx.cantidad, lotesstock.codlote, lotesstock.estado, lotesstock.codordenproduccion");
				q.setFrom("em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovreserva  = movistock.idmovimiento INNER JOIN lotesstock ON movistock.codloteprod = lotesstock.codlote");
				q.setWhere("em_reservaspterx.idmovpterx = " + cursor.valueBuffer("idmovimiento"));
			}
		}
		_i.tblReservas_.setQuery(q);
		_i.tblReservas_.refresh();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
