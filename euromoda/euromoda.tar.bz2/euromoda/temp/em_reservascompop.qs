/***************************************************************************
                 em_reservascompop.qs  -  description
                             -------------------
    begin                : mar feb 12 2019
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	var filtroPreload_;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var curStock_;	
	var curOP_;
	var tblReservas_;
	var tblStocks_;
	var codOrden_;
	function oficial( context ) { interna( context ); } 

	function abrirStocks() {
		return this.ctx.oficial_abrirStocks();
	}
	function abrirOP() {
		return this.ctx.oficial_abrirOP();
	}
	function cargaDatosReservas() {
		return this.ctx.oficial_cargaDatosReservas();
	}
	function dameTablaReservas() {
		return this.ctx.oficial_dameTablaReservas();
	}
	function cargaDatosStocks() {
		return this.ctx.oficial_cargaDatosStocks();
	}
	function dameTablaStocks() {
		return this.ctx.oficial_dameTablaStocks();
	}
}

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.tblReservas_ = undefined;
	_i.tblStocks_ = undefined;
	_i.cargaDatosReservas();
	_i.cargaDatosStocks();
	connect (this.child("mte_tblExt_Reservas"), "clicked(int, int)", _i, "cargaDatosStocks");
}


//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_cargaDatosReservas()
{
	var _i = this.iface;

	var obj = _i.dameTablaReservas();	
	var codOrden = _i.codOrden_;
	var miTabla = obj.miTabla;
	var q = new FLSqlQuery;
	q.setSelect("v_reservalotenotej.codorden,v_reservalotenotej.codlote, v_reservalotenotej.referencia, v_reservalotenotej.cantidad,v_reservalotenotej.descripcion,v_reservalotenotej.componormal,v_reservalotenotej.refcompo, v_reservalotenotej.descripcioncompo, v_reservalotenotej.cantidadcompo,v_reservalotenotej.reservaex,v_reservalotenotej.reservapr, v_reservalotenotej.reservaaf, v_reservalotenotej.idmovimiento, v_reservalotenotej.idstockcompo");
	q.setFrom("v_reservalotenotej");
	q.setWhere("v_reservalotenotej.codorden = '" + codOrden + "'");
	q.setOrderBy("v_reservalotenotej.codorden,v_reservalotenotej.codlote");	
	miTabla.setQuery(q);	


	miTabla.setColumnWidth("v_reservalotenotej.referencia", 80);
	miTabla.setColumnWidth("v_reservalotenotej.refcompo", 80);
	miTabla.setColumnWidth("v_reservalotenotej.componormal", 100);
	miTabla.setColumnWidth("v_reservalotenotej.descripcion", 350);
	miTabla.setColumnWidth("v_reservalotenotej.descripcioncompo", 450);


	miTabla.setReadOnly(true);	
	miTabla.refresh();
	
	return true;	
}

function oficial_dameTablaReservas()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblReservas_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Reservas");
	obj.gb = this.child("mte_gbExt_Reservas");

	if (!obj.creado) {
		_i.tblReservas_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblReservas_.checkColumnEnabled(false);
		_i.tblReservas_.setAliasCheckColumn("Sel.");
		_i.tblReservas_.setSearchEnabled(false);
		_i.tblReservas_.setDoubleClickedFunction("formem_reservascompop.iface.abrirOP");

		this.child("mte_tbnExcel_Reservas").close();
	}
	
	obj.miTabla = _i.tblReservas_;

	return obj;
}

function oficial_cargaDatosStocks()
{
	var _i = this.iface;

	var obj = _i.dameTablaStocks();
	var codOrden = _i.codOrden_;

	var idStock = _i.tblReservas_.dameCursor().valueBuffer("idstockcompo");


	var miTabla = obj.miTabla;

	var q = new FLSqlQuery;
	q.setSelect("v_stocksart.idstock, v_stocksart.codalmacen, v_stocksart.referencia, v_stocksart.descripciontejido, v_stocksart.cantidad, v_stocksart.reservada, v_stocksart.disponible, v_stocksart.pterecibir, v_stocksart.disponiblepterecibir, v_stocksart.afaltas");
	q.setFrom("v_stocksart");
	q.setWhere("v_stocksart.idstock = " + idStock);
	q.setOrderBy("v_stocksart.codalmacen, v_stocksart.referencia");
	miTabla.setQuery(q);

	miTabla.setColumnWidth("v_stocksart.referencia", 80);	
	miTabla.setColumnWidth("v_stocksart.descripciontejido", 450);
	

	var sep = "~";
	var cab = "Almac�n"+sep+"Componente"+sep+"Descripci�n"+sep+"Existencias"+sep+"Reservada"+sep+"Disponible"+sep+"Pte.Recibir"+sep+"Disp.P.R."+sep+"A Faltas";

	miTabla.setColumnLabels(sep, cab);


	miTabla.setReadOnly(true);
	miTabla.refresh();

	return true;	
}

function oficial_dameTablaStocks()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblStocks_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Stocks");
	obj.gb = this.child("mte_gbExt_Stocks");

	if (!obj.creado) {
		_i.tblStocks_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblStocks_.checkColumnEnabled(false);
		_i.tblStocks_.setAliasCheckColumn("Sel.");
		_i.tblStocks_.setSearchEnabled(false);

		this.child("mte_tbnExcel_Stocks").close();

		_i.tblStocks_.setDoubleClickedFunction("formem_reservascompop.iface.abrirStocks");
	}
	
	obj.miTabla = _i.tblStocks_;

	return obj;
}

function oficial_abrirStocks()
{
	var _i = this.iface;
	if (!_i.curStock_) {
		_i.curStock_ = new FLSqlCursor("stocks");
	}	
	var idStock = _i.tblStocks_.dameCursor().valueBuffer("idstock");
	_i.curStock_.select("idstock = " + idStock);
	if (_i.curStock_.first()) {
		_i.curStock_.browseRecord();
	}
}

function oficial_abrirOP()
{
	var _i = this.iface;
	if (!_i.curOP_) {
		_i.curOP_ = new FLSqlCursor("pr_ordenesproduccion");
	}
	_i.curOP_.select("codorden = '" + _i.codOrden_ + "'");
	if (_i.curOP_.first()) {
		_i.curOP_.browseRecord();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////

