/***************************************************************************
                         em_masteredifacturascli.qs
                             -------------------
    begin                : lun jun 25 2012
    copyright            : (C) 2003-2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  var cur_;
  var pbGenEdi_;

  function oficial(context)
  {
    interna(context);
  }
  function genEdi()
  {
    this.ctx.oficial_genEdi();
  }
  function buildWhere()
  {
    return this.ctx.oficial_buildWhere();
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;

  _i.cur_ = this.cursor();
  _i.pbGenEdi_ = this.child("pbGenEdi");

  connect(_i.pbGenEdi_, "clicked()", _i, "genEdi()");
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_genEdi()
{
	var _i = this.iface;

	if (!_i.cur_.isValid()) {
		sys.errorMsgBox(sys.translate("Debe seleccionar un registro"));
		return;
	}

	var where = _i.buildWhere();
	var ediIface = formedi_esquemas.iface;



	/* var msg = sys.translate("Proceso finalizado") + "\n\n";
	msg += ediIface.pub_genEdiFile("CABFAC", where, "EDIFCFAC") + "\n";
	msg += ediIface.pub_genEdiFile("VTOFAC", where, "EDIFVFAC") + "\n";
	msg += ediIface.pub_genEdiFile("LINFAC", where, "EDIFLFAC") + "\n";
	msg += ediIface.pub_genEdiFile("DTOLFAC", where) + "\n";
	sys.infoMsgBox(msg);*/

	var msg = sys.translate("Proceso finalizado") + "\n\n";
	var mensaje = _i.cur_.valueBuffer("codmensaje");
	
	var q = new AQSqlQuery;	
	q.setSelect("codesquema,nombrefichero");
	q.setFrom("edi_esquemas");
	q.setWhere("codmensaje = '" + mensaje + "'"); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var codEsquema = q.value("codesquema");
		msg += ediIface.pub_genEdiFile(codEsquema, where) + "\n";			
		
	}
	sys.infoMsgBox(msg);
  
}

function oficial_buildWhere()
{
  var _i = this.iface;

  if (!_i.cur_.isNull("codintervalo") && _i.cur_.valueBuffer("codintervalo") != "") {
    var intervalo = [];
    intervalo = flfactppal.iface.pub_calcularIntervalo(
                  _i.cur_.valueBuffer("codintervalo")
                );
    _i.cur_.setValueBuffer("d_facturascli_fecha", intervalo.desde);
    _i.cur_.setValueBuffer("h_facturascli_fecha", intervalo.hasta);
  }

  var q = flfactinfo.iface.pub_establecerConsulta(_i.cur_, "i_facturascli");
  var where = q.where();

  if (!where.isEmpty())
    where += " AND ";

  if (_i.cur_.valueBuffer("deabono"))
    where += " facturascli.deabono=true";
  else
    where += " facturascli.deabono=false";

  if (!_i.cur_.isNull("codgrupo")) {
    if (!where.isEmpty())
      where += " AND ";
    where += " clientes.codgrupo='" +
             _i.cur_.valueBuffer("codgrupo") + "'";
  }

  if (!where.isEmpty())
    where += " AND ";
  where += " clientes.ediactivo='t'";

  return where;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
