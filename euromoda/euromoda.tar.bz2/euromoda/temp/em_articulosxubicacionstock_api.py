# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa
import json

# lotesstock = qsa.class_("em_articulosxubicacion")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */ 
# UBICACIONES 
class Oficial(Base):

    def get(self, params, username=None):

        mapa = self.get_mapa()
        obj = qsa.from_project("formAPI").get_resources('em_articulosxubicacion', params, mapa, username)

        return obj

    # def cortarPieza(self, params, username=None):
    #     print(params)
    #     obj = qsa.from_project("formau_automata").iface.cortaPiezaJson(params)
    #     return True


    def get_mapa(self):
        return {            
            'join': 'em_articulosxubicacion INNER JOIN articulos ON articulos.referencia = em_articulosxubicacion.referencia INNER JOIN subfamilias ON subfamilias.codsubfamilia = articulos.codsubfamilia LEFT OUTER JOIN stocks ON stocks.referencia = articulos.referencia',
            # 'order': 'stocks.codalmacen, subfamilias.descripcion, articulos.referencia',
            'order': 'codalmacen',
            'map': {
                'id': {'field': 'em_articulosxubicacion.id', 'type': 'string'},
                'actual': {'field': 'em_articulosxubicacion.actual', 'type': 'bool'},
                'em_ubialternativa': {'field': 'em_articulosxubicacion.em_ubialternativa', 'type': 'string'},
                'referencia': {'field': 'em_articulosxubicacion.referencia', 'type': 'string'},
                'descripcion': {'field': 'articulos.descripcion', 'type': 'string'},
                'codcolorem': {'field': 'articulos.codcolorem', 'type': 'string'},
                'codtamanoem': {'field': 'articulos.codtamanoem', 'type': 'string'},
                'cantidad': {'field': 'stocks.cantidad', 'type': 'string'},
                'codalmacen': {'field': 'stocks.codalmacen', 'type': 'string'},
                'subfamiliasdescripcion': {'field': 'subfamilias.descripcion', 'type': 'string'},
                'idstock': {'field': 'stocks.idstock', 'type': 'string'},
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
