/***************************************************************************
                 em_altamasivasubfam.qs  -  description
                             -------------------
    begin                : mar ago 16 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { 
        return this.ctx.interna_init(); 
    }
	function calculateField(fN:String):String { 
        return this.ctx.interna_calculateField(fN); 
    }
	function validateForm():Boolean {
        return this.ctx.interna_validateForm();
    }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var aTamanos_;
	function oficial( context ) { interna( context ); } 
	function tbnPonTamano_clicked() {
		return this.ctx.oficial_tbnPonTamano_clicked();
	}
	function cargaTamanos() {
		return this.ctx.oficial_cargaTamanos();
	}
    function comprobarDeBaja(cursor){
        return this.ctx.oficial_comprobarDeBaja(cursor);
    }
    function pushButtonAccept_clicked() {
        return this.ctx.oficial_pushButtonAccept_clicked();
    }

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

/** \C El valor de --stockfis-- se calcula autom�ticamente para cada art�culo como la suma de existencias del art�culo en todos los almacenes.
\end */
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();


    sys.disableObj(this, "fdbCodAlta");
    if(this.child("pushButtonAccept")) {        
        disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
        connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
    }
    
    if(cursor.modeAccess() == cursor.Browse) {
        sys.disableObj(this, "tbnPonTamano");
    }
    this.child("tdbTamanosSubfam").cursor().setMainFilter("idaltasubfam = '" + cursor.valueBuffer("idaltasubfam") + "'");
    this.child("tdbTamanosSubfam").refresh();
    
    
	/*switch (cursor.modeAccess()) {
		case cursor.Insert: {
            debug("1");
			var cR = cursor.cursorRelation();
			if (cR && cR.table() == "em_altamasivacompleta") {
                debug("2");
				sys.setObjText(this, "fdbDesAlta", AQUtil.sqlSelect("em_altamasivacompleta", "descripcion", "codigo = '" + cursor.valueBuffer("codalta") + "'"));
			}
			break;
		}
	}*/
// 	this.child("tdbTamanosSubfam").cursor().setMainFilter("codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
	
	connect(this.child("tbnPonTamano"), "clicked()", _i, "tbnPonTamano_clicked");
}

function interna_calculateField(fN)
{
	return 0;
}

function interna_validateForm()
{
    const _i = this.iface;
    const cursor = this.cursor();

    if (!_i.comprobarDeBaja(cursor)) 
    {
        return false
    }

	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnPonTamano_clicked()
{
    var _i = this.iface;
    var cursor = this.cursor();
    if (cursor.modeAccess() == cursor.Insert) {
        if (!this.child("tdbTamanosSubfam").cursor().commitBufferCursorRelation()) {
            return false;
        }
    }

    _i.aTamanos_ = false;
    if (!_i.cargaTamanos()) {
        return false;
    }

    var f = new FLFormSearchDB("em_selaltatamanossubfam");
    var c = f.cursor();
    c.setMainFilter("codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
    f.setMainWidget();
    f.exec();
    if (!f.accepted()) {
        return;
    }
    if (!_i.aTamanos_) {
        return;
    }
    var idaltasubfam = cursor.valueBuffer("idaltasubfam");
    if (!AQSql.del("em_altamasivatamsub", "idaltasubfam = " + idaltasubfam)) {
        return false;
    }
    var codSubfamilia = cursor.valueBuffer("codsubfamilia");
    var codAlta = cursor.valueBuffer("codAlta");
    for (var i = 0; i < _i.aTamanos_.length; i++) {
        if (_i.aTamanos_[i] && !isNaN(_i.aTamanos_[i])) {
            if (!AQSql.insert("em_altamasivatamsub", ["idaltasubfam", "codalta", "codsubfamilia", "codtamanoem"], [idaltasubfam, codAlta, codSubfamilia, AQUtil.sqlSelect("em_tamanossubfam", "codtamanoem", "idtamanosubfam = " + _i.aTamanos_[i])])) {
                return false;
            }
        }
    }
    this.child("tdbTamanosSubfam").cursor().setMainFilter("idaltasubfam = '" + cursor.valueBuffer("idaltasubfam") + "' and codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
    this.child("tdbTamanosSubfam").refresh();
}

function oficial_cargaTamanos()
{
    var cursor = this.cursor();
    var _i = this.iface;

    var codSubfamilia = cursor.valueBuffer("codsubfamilia");
    var idaltasubfam = cursor.valueBuffer("idaltasubfam");


    var q = new FLSqlQuery();
    q.setTablesList("em_altamasivatamsub");
    q.setSelect("codtamanoem");
    q.setFrom("em_altamasivatamsub");
    q.setWhere("idaltasubfam = " + idaltasubfam);
    q.setForwardOnly(true);
    if (!q.exec()) {
        return false;
    }
    _i.aTamanos_ = [];
    var i = 0;
    while (q.next()) {
        if (!AQUtil.sqlSelect("em_tamanossubfam", "idtamanosubfam", "codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + q.value("codtamanoem") + "'")) {
        }
        _i.aTamanos_[i++] = AQUtil.sqlSelect("em_tamanossubfam", "idtamanosubfam", "codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + q.value("codtamanoem") + "'");
    }
    return true;
}

function oficial_comprobarDeBaja(cursor)
{
    const altaMasivaSubFamilia = formCURSOR.toDict(cursor);
    const baja = altaMasivaSubFamilia["codsubfamilia"];

    const deBaja = AQUtil.sqlSelect("subfamilias","embaja","codsubfamilia = '" + baja +"'");

    if (deBaja){
        const res = formUI.preguntaMsg(sys.translate("La subfamilia seleccionada est� marcada como *Baja* �Desea continuar?"), "warn", this, MessageBox.Yes, MessageBox.No);        
        return (res == MessageBox.Yes)
    }

    return true;
}

function oficial_pushButtonAccept_clicked()
{
    var _i = this.iface;
    var cursor = this.cursor();    
    if (!_i.comprobarDeBaja(cursor)) {
        return false
    }  
    this.obj().accept();
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
