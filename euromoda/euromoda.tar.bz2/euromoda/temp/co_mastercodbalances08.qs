
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA  //////////////////////////////////////////////
class euromoda extends oficial {
    function euromoda( context ) { oficial ( context ); }
    function init() {
        return this.ctx.euromoda_init();
    }
}
//// EUROMODA  //////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////
function euromoda_init()
{
    var _i = this.iface;
    _i.__init();
    var usuario = sys.nameUser();
    if(usuario != "antonio" && usuario != "antonio2" && usuario != "pozuelo" && usuario != "andres") {
    var c = ["pbnActualizarCodBalances2008", "pbnActualizarCuentas2008", "pbnActualizarCuentas2008ba"];
    for (var i = 0; i < c.length; i++) {
        if (this.child(c[i])) {
            this.child(c[i]).close();
        }
    }
    }

}
//// EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
