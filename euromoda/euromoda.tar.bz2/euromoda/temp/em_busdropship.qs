/***************************************************************************
                 em_busdropship.qs  -  description
                             -------------------
    begin                : lun abr 26 2004
    copyright            : (C) 2004 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  function oficial(context)
  {
    interna(context);
  }
  	function init() {
    	return this.ctx.oficial_init();
  	}
  	/*function toolButtomInsert_clicked() {
		return this.ctx.oficial_toolButtomInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.oficial_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.oficial_toolButtonDelete_clicked();
	}*/
	function toolButtonZoom_clicked() {
		return this.ctx.oficial_toolButtonZoom_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////


function oficial_init()
{
  	var _i = this.iface;
	
	//connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	//connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	//connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	//connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "toolButtonEdit_clicked");
	
}

/*function oficial_toolButtomInsert_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.insertRecord();

}

function oficial_toolButtonEdit_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.editRecord();
}

function oficial_toolButtonDelete_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	this.child("tableDBRecords").deleteRecord();
}*/

function oficial_toolButtonZoom_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.browseRecord();
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////