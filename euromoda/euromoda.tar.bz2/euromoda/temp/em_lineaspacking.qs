/***************************************************************************
                            em_lineaspacking.qs
                             -------------------
    begin                : mar jun 26 2012
    copyright            : (C) 2003-2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
	function calculateField(fN) { 
		return this.ctx.interna_calculateField(fN); 
	}
	function validateForm() { 
		return this.ctx.interna_validateForm(); 
	}
	function formReady() { 
		return this.ctx.interna_formReady(); 
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	function oficial(context)
	{
		interna(context);
	}
	function bufferChanged(fN)
	{
		this.ctx.oficial_bufferChanged(fN);
	}
	function calcularCantidades()
	{
		this.ctx.oficial_calcularCantidades();
	}
	function ponNumLinea()
	{
		this.ctx.oficial_ponNumLinea();
	}
	function addDetalleAuto(idLineaPacking,numBultos,cantidad) {
		return this.ctx.oficial_addDetalleAuto(idLineaPacking,numBultos,cantidad);
	}
	function tbnAddDetalleAuto_clicked() {
		return this.ctx.oficial_tbnAddDetalleAuto_clicked();
	}
	function desdeHastaBulto() {
		return this.ctx.oficial_desdeHastaBulto();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	this.child("fdbIdLineaAlbaran").setFilter("idalbaran = '" + cursor.valueBuffer("idalbaran") + "'");	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged()");
	connect(this.child("tdbEmDetalleLineaPacking").cursor(), "bufferCommited()", _i, "calcularCantidades()");
	_i.ponNumLinea();
	sys.setObjText(this, "fdbDescTipoEmbalaje", _i.calculateField("desctipoembalaje"));
	connect(this.child("tbnAddDetalleAuto"), "clicked()", _i, "tbnAddDetalleAuto_clicked");
	_i.desdeHastaBulto();
}

function interna_formReady()
{
		var cursor = this.cursor();
		
}


function interna_calculateField(fN)
{
	
  var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "numlineapacking":{
			valor = AQUtil.sqlSelect("em_lineaspacking", "numlineapacking", "idalbaran = '" + cursor.valueBuffer("idalbaran") + "' ORDER BY numlineapacking DESC");
			if(!valor){
				valor = 0;
			}
			valor += 10000;
			break;
		}
		case "numbultos":{
			if(parseFloat(cursor.valueBuffer("hastabulto")) < parseFloat(cursor.valueBuffer("desdebulto"))) {
				valor = 0;
			} else {
				valor = parseFloat(cursor.valueBuffer("hastabulto")) - parseFloat(cursor.valueBuffer("desdebulto")) + 1;
			}
			break;
		}
		case "totalcantidadalbaran":{
			valor = AQUtil.sqlSelect("lineasalbaranescli", "SUM(canfactura)", "idalbaran = '" + cursor.valueBuffer("idalbaran") + "' AND referencia = '" + cursor.valueBuffer("referencia") + "'");
			if (!valor){
				valor = 0;
			}
			break;
		}
		case "cantidad":{
			valor = AQUtil.sqlSelect("em_lineaspacking lp INNER JOIN em_detallelineapacking dl ON lp.idlinea_packing = dl.idlinea_packing", "SUM(dl.cantidad)", "lp.idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "' AND lp.referencia = '" + cursor.valueBuffer("referencia") + "'", "em_lineaspacking");
			if (!valor){
				valor = 0;
			}
			break;
		}
		case "totalcantidad":{
			valor = AQUtil.sqlSelect("em_lineaspacking lp INNER JOIN em_detallelineapacking dl ON lp.idlinea_packing = dl.idlinea_packing", "SUM(dl.cantidad)", "lp.idalbaran = '" + cursor.valueBuffer("idalbaran") + "' AND lp.referencia = '" + cursor.valueBuffer("referencia") + "'", "em_lineaspacking");
			if (!valor){
				valor = 0;
			}
			break;
		}
		case "totalmetros":{
			valor = parseFloat(cursor.valueBuffer("numbultos")) * parseFloat(cursor.valueBuffer("metrosporbulto"));
			break;
		}
		case "desctipoembalaje":{
			valor = AQUtil.sqlSelect("em_tiposembalajeedi", "descripcion", "codtipoembalajeedi = '" + cursor.valueBuffer("codtipoembalajeedi") + "'");
			break;
		}
		case "desdebulto": {
			valor = AQUtil.sqlSelect("em_lineaspacking","SUM(numbultos)","idalbaran = " + cursor.valueBuffer("idalbaran"));
			if(!valor || valor == "") {
				valor = 0;
			} 
			valor++;
			break;
		}
	}
	return valor;
}

function interna_validateForm()
{
	debug("interna_validateForm()");
	var _i = this.iface;
	var cursor = this.cursor();
	
	if(cursor.valueBuffer("hastabulto") < cursor.valueBuffer("desdebulto")) {
		sys.warnMsgBox(sys.translate("El campo 'Hasta bulto' debe de ser mayor o igual que el campo 'Desde bulto'."));
		return false;
	}
	
	var numBultos = parseFloat(cursor.valueBuffer("numbultos"));
	var numBultosTeoricos = _i.calculateField("numbultos");
	if(numBultos != numBultosTeoricos){
		var res = MessageBox.warning(sys.translate("El n�mero de bultos no coincide con el rango elegido (desde-hasta).\n�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	
	var cantidad = parseFloat(cursor.valueBuffer("cantidad"));
	var totalCantidadAlbaran = parseFloat(cursor.valueBuffer("totalcantidadalbaran"));
	
	if(cantidad > totalCantidadAlbaran){
		var res = MessageBox.warning(sys.translate("La cantidad supera el total cantidad de la l�nea del albar�n.\n�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
	
  var _i = this.iface;
	var cursor = this.cursor();
	
  switch (fN) {
		case "hastabulto":{
			sys.setObjText(this, "fdbNumBultos", _i.calculateField("numbultos"));
			sys.setObjText(this, "fdbTotalMetros", _i.calculateField("totalmetros"));
			break;
		}
		case "desdebulto":{
			if(parseFloat(cursor.valueBuffer("hastabulto")) < parseFloat(cursor.valueBuffer("desdebulto"))){
				sys.setObjText(this, "fdbHastaBulto", parseFloat(cursor.valueBuffer("desdebulto")));
			}
			sys.setObjText(this, "fdbNumBultos", _i.calculateField("numbultos"));
			sys.setObjText(this, "fdbTotalMetros", _i.calculateField("totalmetros"));
			break;
		}
		case "metrosporbulto":{
			sys.setObjText(this, "fdbTotalMetros", _i.calculateField("totalmetros"));
			break;
		}
		case "referencia":{
			sys.setObjText(this, "fdbTotalCantidadAlbaran", _i.calculateField("totalcantidadalbaran"));
			sys.setObjText(this, "fdbTotalCantidad", _i.calculateField("totalcantidad"));
			break;
		}
		case "codtipoembalajeedi":{
			sys.setObjText(this, "fdbDescTipoEmbalaje", _i.calculateField("desctipoembalaje"));
			break;
		}
  }
}

function oficial_ponNumLinea()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	sys.setObjText(this, "fdbNumLineaPacking", _i.calculateField("numlineapacking"));
}

function oficial_desdeHastaBulto()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.modeAccess() == cursor.Insert) {
		var desdeBulto = _i.calculateField("desdebulto");
		sys.setObjText(this, "fdbDesdeBulto", desdeBulto);		
	}

}

function oficial_calcularCantidades()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	sys.setObjText(this, "fdbCantidad", _i.calculateField("cantidad"));
	sys.setObjText(this, "fdbTotalCantidad", _i.calculateField("totalcantidad"));
	
}

function oficial_tbnAddDetalleAuto_clicked()
{
	var _i = this.iface;	
	var cursor = this.cursor();

	var cantidadCaja = cursor.valueBuffer("cantidadcaja");
	var metrosPorBulto = cursor.valueBuffer("metrosporbulto");
	var idLineaPacking = cursor.valueBuffer("idlinea_packing");
	var cantidad = "";
	if(cantidadCaja && cantidadCaja != "" && cantidadCaja !=0 ) {
		cantidad = cantidadCaja;
	} else if (metrosPorBulto && metrosPorBulto != "" && metrosPorBulto !=0 ) {
		cantidad = metrosPorBulto;
	} 	
	if(!cantidad || cantidad =="") {
		sys.warnMsgBox(sys.translate("Para informar las l�neas de detalle autom�ticamente debe de informar el campo 'Cantidad/Caja' o el campo 'Metros/Bulto'"));
		return false;
	}	
	if (cursor.modeAccess() == cursor.Insert) {			
			
		/*if (!this.child("tdbEmDetalleLineaPacking").cursor().commitBufferCursorRelation()) {
			return false;
		}*/
		//lo hacemos as� porque no funciona bien el commitBufferCursorRelation
		var pk = cursor.valueBuffer("idlinea_packing");
		cursor.commitBuffer();
		cursor.select("idlinea_packing = " + pk);
		cursor.first();
		cursor.setModeAccess(cursor.Edit);
		cursor.refreshBuffer();		
	}
	var numBultos = cursor.valueBuffer("numbultos"); 	

	if(!_i.addDetalleAuto(idLineaPacking,numBultos,cantidad)) {
		sys.warnMsgBox(sys.translate("Error al introducir las l�neas de detalle autom�ticamente"));
		return false;
	}		
}

function oficial_addDetalleAuto(idLineaPacking,numBultos,cantidad) 
{	

	var _i = this.iface;
	if(!AQUtil.sqlDelete("em_detallelineapacking", "idlinea_packing = " + idLineaPacking)) {
		return false;
	}	
	var curDetalle = this.child("tdbEmDetalleLineaPacking").cursor();
	for(var i=0; i<numBultos; i++) {
	
		curDetalle.setModeAccess(curDetalle.Insert);
    	curDetalle.refreshBuffer();		
    	
    	curDetalle.setValueBuffer("idlinea_packing",idLineaPacking);
    	curDetalle.setValueBuffer("numbulto", formRecordem_detallelineapacking.iface.commonCalculateField("numbulto",curDetalle));
    	curDetalle.setValueBuffer("cantidad",cantidad);		
		
		if(!curDetalle.commitBuffer()) {
			return false;
		}
	}

	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
