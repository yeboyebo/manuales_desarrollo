/***************************************************************************
                 em_masteraltamasiva.qs  -  description
                             -------------------
    begin                : mar ene 23 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var cxTx_;
	function oficial( context ) { interna( context ); } 
	function toolButtonInsert_clicked() {
		return this.ctx.oficial_toolButtonInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.oficial_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.oficial_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.oficial_toolButtonZoom_clicked();
	}
	function tableDBRecords_recordChoosed() {
		return this.ctx.oficial_tableDBRecords_recordChoosed();
	}
	function abreCxTx() {
		return this.ctx.oficial_abreCxTx();
	}
	function compruebaUsuario() {
		return this.ctx.oficial_compruebaUsuario();
	}
}

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;

	connect(this.child("toolButtonInsert"), "clicked()", _i, "toolButtonInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");	
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tableDBRecords_recordChoosed");
	sys.runObjMethod(this, "tableDBRecords", "setOnlyTable", true);
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////


function oficial_tableDBRecords_recordChoosed()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!_i.abreCxTx()) {
		return false;
	}
	if(!_i.compruebaUsuario()) {  		
		return false;			
  	}
  	this.child("tableDBRecords").editRecord();
	//cursor.editRecord();

}
function oficial_toolButtonInsert_clicked()
{
	var _i = this.iface;
	if (!_i.abreCxTx()) {
		return false;
	}
	if(!_i.compruebaUsuario()) {  		
		return false;			
  	}
	var cursor = this.cursor();
	this.child("tableDBRecords").insertRecord();
}

function oficial_toolButtonEdit_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!_i.abreCxTx()) {
		return false;
	}
	if(!_i.compruebaUsuario()) {  		
		return false;			
  	}
	this.child("tableDBRecords").editRecord();
}

function oficial_toolButtonDelete_clicked()
{
	var _i = this.iface;
	this.child("tableDBRecords").deleteRecord();
}

function oficial_toolButtonZoom_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.browseRecord();
	
}

function oficial_compruebaUsuario()
{
	var _i =this.iface;
	var cursor = this.cursor();
	var usuario = sys.nameUser();
	var idAlta = cursor.valueBuffer("idalta");	
	//var usuarioCon = AQUtil.sqlSelect("em_ctrlusualtamasiva","idusuario","idaltamasiva = " + idAlta, "em_ctrlusualtamasiva",_i.cxTx_);
	var usuarioCon = AQUtil.sqlSelect("em_ctrlusualtamasiva","idusuario","1=1", "em_ctrlusualtamasiva",_i.cxTx_);
	debug("usuario: "+usuario);
	debug("usuarioCon: "+usuarioCon);
	
	if(usuarioCon && usuarioCon != usuario) {
		var res = MessageBox.information(sys.translate("El usuario %1 est� utilizando esta funcionalidad �Desea continuar?").arg(usuarioCon), MessageBox.Yes, MessageBox.No)
		if (res != MessageBox.Yes) {
			sys.AQTimer.singleShot(0, formRecordem_altamasiva.reject);
			//this.form.close();
			return false;
		}		

		//if(!AQUtil.sqlUpdate("em_ctrlusualtamasiva", "idusuario",  usuario, "idaltamasiva = " + idAlta + " AND idusuario = '" + usuarioCon + "'",_i.cxTx_)) {
		if(!AQUtil.sqlUpdate("em_ctrlusualtamasiva", "idusuario",  usuario, "idusuario = '" + usuarioCon + "'",_i.cxTx_)) {
			return false;
		}

	} else if(!usuarioCon || usuarioCon == "") {		
		
		var curUsuAltaMas = new FLSqlCursor("em_ctrlusualtamasiva", _i.cxTx_);
		curUsuAltaMas.setModeAccess(curUsuAltaMas.Insert);
		curUsuAltaMas.refreshBuffer();
		curUsuAltaMas.setValueBuffer("idusuario", usuario);		
		//curUsuAltaMas.setValueBuffer("idaltamasiva", idAlta);	
		if (!curUsuAltaMas.commitBuffer()) {
			return false;
		}	
	}

	return true;
 
}

function oficial_abreCxTx()
{
	var _i = this.iface;
	
	if (!_i.cxTx_) {
		_i.cxTx_ = "CxTx";
	}
	var dbTx= AQSql.database(_i.cxTx_);
	
	if (_i.cxTx_ && dbTx.connectionName() == _i.cxTx_ ) {
		/// Porque aunque se deje abierta a los 15min de inactividad TCP muere y no se detecta que se haya roto la conexi�n
		if (!sys.removeDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error en la desconexi�n."), "info");
			return false;
		}
		dbTx = AQSql.database(_i.cxTx_);
	}
	if (dbTx.connectionName() != _i.cxTx_ || !dbTx.isOpen()) {
		if (!sys.addDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error al establecer la conexi�n de comprobaci�n de transacciones."), "warn");
			return false;
		}
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////

