
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	function euromoda( context ) { prod ( context ); }
  function esTareaProduccion(curTarea) {
		return this.ctx.euromoda_esTareaProduccion(curTarea);
	}
	function iniciarTareaEsp(curTareas) {
		return this.ctx.euromoda_iniciarTareaEsp(curTareas);
	}
	function deshacerTareaEnCursoEsp(curTareas) {
		return this.ctx.euromoda_deshacerTareaEnCursoEsp(curTareas);
	}
	function terminarProcesoEsp(curProceso) {
		return this.ctx.euromoda_terminarProcesoEsp(curProceso);
	}
	function controlBorradoProcesoProd(curProceso) {
		return this.ctx.euromoda_controlBorradoProcesoProd(curProceso);
	}
	function loteCreado(curProceso) {
		return this.ctx.euromoda_loteCreado(curProceso);
	}
	function deshacerProcesoTerminadoEsp(idProceso) {
		return this.ctx.euromoda_deshacerProcesoTerminadoEsp(idProceso);
	}
	function iniciaTareaTrEm(idTarea, idUsuario) {
		return this.ctx.euromoda_iniciaTareaTrEm(idTarea, idUsuario);
	}
	function beforeCommit_pr_procesos(curProceso) {
		return this.ctx.euromoda_beforeCommit_pr_procesos(curProceso);
	}
	function controlProcesoDuplicado(curProceso) {
		return this.ctx.euromoda_controlProcesoDuplicado(curProceso);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_esTareaProduccion(curTarea)
{
	var es = (curTarea.valueBuffer("tipoobjeto") == "pr_ordenesproduccion");
	return es;
}

function euromoda_iniciarTareaEsp(curTareas)
{
	var _i = this.iface;
	if (!_i.esTareaProduccion(curTareas)) {
		return _i.__iniciarTareaEsp(curTareas);
	}

	var idTarea = curTareas.valueBuffer("idtarea");
	var idProceso = curTareas.valueBuffer("idproceso");
	var codOrden = AQUtil.sqlSelect("pr_procesos", "idobjeto", "idproceso = " + idProceso);
	if (!codOrden) {
		MessageBox.warning(sys.translate("scripts", "Error al obtener la orden de producci�n correspondiente a la tarea %1").arg(idTarea), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	
	switch (curTareas.valueBuffer("idtipotarea")) {
		/*
		case "PM": { /// Preparacion de material
			if (!AQSql.update("pr_ordenesproduccion", ["materialconfok"], [true], "codorden = '" + codOrden + "'")) {
				return false;
			}
			break;
		}
		*/
		case "DC": { /// Distribuci�n a confecciones
			if (!AQSql.update("lotesstock", ["estado"], ["TERMINADO"], "codordenproduccion = '" + codOrden + "'")) {
				return false;
			}
			break;
		}
	}
	
	var idTipoTarea = curTareas.valueBuffer("idtipotarea");
	switch (idTipoTarea) {
		case "DC":
		case "PT": {
			var hoy:Date = new Date();
			var curMoviStock:FLSqlCursor = new FLSqlCursor("movistock");
			
			var qLote = new FLSqlQuery;
			qLote.setSelect("codlote");
			qLote.setFrom("lotesstock");
			qLote.setWhere("codordenproduccion = '" + codOrden + "'");
			qLote.setForwardOnly(true);
			if (!qLote.exec()) {
				return false;
			}
			var codLote, estado, codFamilia;
			while (qLote.next()) {
				codLote = qLote.value("codlote");
				curMoviStock.select("codloteprod = '" + codLote + "'");
				while (curMoviStock.next()) {
					curMoviStock.setModeAccess(curMoviStock.Edit);
					curMoviStock.refreshBuffer();
// 					if (!_i.comprobarStockConsumo(curMoviStock)) { No comprueba si el stock pasa a negativo
// 						return false;
// 					}
					/// Los consumos de tejido estampado no se realizan as�, sino que las piezas se consumen por entero desde otro form. Aqu� pasan a OFF para no tenerlos ya en cuenta en el stock
					if (curMoviStock.isNull("codlote")) { /// Los consumos reales de piezas llevan el c�digo informado
						if (flfactalma.iface.pub_esReferenciaXPiezas(curMoviStock.valueBuffer("referencia"))) {
							if (idTipoTarea != "PT") { /// La tela estampada se consume en la preparaci�n de tejido
								continue;
							}
							estado = "OFF";
						} else {
							if (idTipoTarea != "DC") { /// El resto de materieales se consume en la distribuci�n a confecciones
								continue;
							}
							estado = "HECHO";
						}
					}
					curMoviStock.setValueBuffer("estado", estado);
					curMoviStock.setValueBuffer("fechareal", hoy.toString());
					curMoviStock.setValueBuffer("horareal", hoy.toString().right(8));
					curMoviStock.setValueBuffer("idtarea", idTarea);
					curMoviStock.setValueBuffer("idproceso", idProceso);
					if (!curMoviStock.commitBuffer()) {
						return false;
					}
				}
			}
			break;
		}
	}
	return true;
}

function euromoda_deshacerTareaEnCursoEsp(curTareas)
{
	var _i = this.iface;
	if (!_i.esTareaProduccion(curTareas)) {
		return _i.__deshacerTareaEnCursoEsp(curTareas);
	}
	
	var idTarea = curTareas.valueBuffer("idtarea");
	var idProceso = curTareas.valueBuffer("idproceso");
	var codOrden = AQUtil.sqlSelect("pr_procesos", "idobjeto", "idproceso = " + idProceso);
	if (!codOrden) {
		MessageBox.warning(sys.translate("scripts", "Error al obtener la orden de producci�n correspondiente a la tarea %1").arg(idTarea), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
	switch (curTareas.valueBuffer("idtipotarea")) {
		case "PM": { /// Preparacion de material
			if (!AQSql.update("pr_ordenesproduccion", ["materialconfok"], [false], "codorden = '" + codOrden + "'")) {
				return false;
			}
			break;
		}
		case "DC": { /// Distribuci�n a confecciones
			if (!AQSql.update("lotesstock", ["estado"], ["PTE"], "codordenproduccion = '" + codOrden + "'")) {
				return false;
			}
			break;
		}
	}
	
	var idTipoTarea = curTareas.valueBuffer("idtipotarea");
	switch (idTipoTarea) {
		case "DC":
		case "PT": {
			var hoy:Date = new Date();
			var curMoviStock:FLSqlCursor = new FLSqlCursor("movistock");
			
			var qLote = new FLSqlQuery;
			qLote.setSelect("codlote");
			qLote.setFrom("lotesstock");
			qLote.setWhere("codordenproduccion = '" + codOrden + "'");
			qLote.setForwardOnly(true);
			if (!qLote.exec()) {
				return false;
			}
			var codLote, estado, codFamilia;
			while (qLote.next()) {
				codLote = qLote.value("codlote");
				curMoviStock.select("codloteprod = '" + codLote + "'");
				while (curMoviStock.next()) {
					curMoviStock.setModeAccess(curMoviStock.Edit);
					curMoviStock.refreshBuffer();
// 					if (!_i.comprobarStockConsumo(curMoviStock)) { No comprueba si el stock pasa a negativo
// 						return false;
// 					}
					/// Los consumos de tejido estampado no se realizan as�, sino que las piezas se consumen por entero desde otro form. Aqu� pasan a OFF para no tenerlos ya en cuenta en el stock
					if (curMoviStock.isNull("codlote")) { /// Los consumos reales de piezas llevan el c�digo informado
						if (flfactalma.iface.pub_esReferenciaXPiezas(curMoviStock.valueBuffer("referencia"))) {
							if (idTipoTarea != "PT") { /// La tela estampada se consume en la preparaci�n de tejido
								continue;
							}
						} else {
							if (idTipoTarea != "DC") { /// El resto de materieales se consume en la distribuci�n a confecciones
								continue;
							}
						}
					}
					if (curMoviStock.valueBuffer("estado") == "OFF" && idTipoTarea != "PT") {
						continue;
					}
					curMoviStock.setValueBuffer("estado", "PTE");
					curMoviStock.setNull("idtarea");
					curMoviStock.setNull("idproceso");
					curMoviStock.setNull("fechareal");
					curMoviStock.setNull("horareal");
					if (!curMoviStock.commitBuffer()) {
						return false;
					}
				}
			}
			break;
		}
	}

	return true;
}

function euromoda_terminarProcesoEsp(curProceso)
{
	var _i = this.iface;
	var idTipoProceso = curProceso.valueBuffer("idtipoproceso");
	var tipoObjeto = AQUtil.sqlSelect("pr_tiposproceso", "tipoobjeto", "idtipoproceso = '" + idTipoProceso + "'");

	switch (tipoObjeto) {
		case "pr_ordenesproduccion": {
			if (!_i.__terminarProcesoEsp(curProceso)) {
				return false;
			}
			if (_i.esProcesoFabricacion(idTipoProceso)) {
				if (!_i.loteCreado(curProceso)) {
					return false;
				}
			}
			break;
		}
		default: {
			if (!_i.__terminarProcesoEsp(curProceso)) {
				return false;
			}
			break;
		}
	}
	return true;
}

function euromoda_loteCreado(curProceso)
{
	var idProceso:String = curProceso.valueBuffer("idproceso");
	var fecha:Date = new Date;
	
// 	var curMoviStock:FLSqlCursor = new FLSqlCursor("movistock");
// 	curMoviStock.select("idproceso = " + idProceso + " AND estado = 'PTE'");
// 	while (curMoviStock.next()) {
// // 		curMoviStock.setModeAccess(curMoviStock.Edit);
// // 		curMoviStock.refreshBuffer();
// // 		curMoviStock.setValueBuffer("estado", "HECHO");
// // 		curMoviStock.setValueBuffer("fechareal", fecha);
// // 		curMoviStock.setValueBuffer("horareal", fecha.toString().right(8));
// 		curMoviStock.setModeAccess(curMoviStock.Del);
// 		curMoviStock.refreshBuffer();
// 		if (!curMoviStock.commitBuffer()) {
// 			return false;
// 		}
// 	}
	var codOrden = curProceso.valueBuffer("idobjeto");
	if (!AQSql.update("pr_ordenesproduccion", ["estado"], ["TERMINADA"], "codorden = '" + codOrden + "'")) {
		return false;
	}
	if (!AQSql.update("lotesstock", ["estado"], ["TERMINADO"], "codordenproduccion = '" + codOrden + "'")) {
		return false;
	}
	 
	return true;
}

function euromoda_deshacerProcesoTerminadoEsp(idProceso)
{
	var _i = this.iface;
	var tipoObjeto = AQUtil.sqlSelect("pr_procesos", "tipoobjeto", "idproceso = " + idProceso);
	var idTipoProceso = AQUtil.sqlSelect("pr_procesos", "idtipoproceso", "idproceso = " + idProceso);

	switch (tipoObjeto) {
		case "pr_ordenesproduccion": {
			var codOrden = AQUtil.sqlSelect("pr_procesos", "idobjeto", "idproceso = " + idProceso);
			if (_i.esProcesoFabricacion(idTipoProceso)) {
				if (!AQSql.update("pr_ordenesproduccion", ["estado"], ["EN CURSO"], "codorden = '" + codOrden + "'")) {
					return false;
				}
				if (!AQSql.update("lotesstock", ["estado"], ["PTE"], "codordenproduccion = '" + codOrden + "'")) {
					return false;
				}
			}
			break;
		}
		default: {
			if (!_i.__deshacerProcesoTerminadoEsp(idProceso)) {
				return false;
			}
			break;
		}
	}

	return true;
}


/// Los procesos de producci�n tienen las mismas restricciones de borrado que cualquier otro proceso
function euromoda_controlBorradoProcesoProd(curProceso)
{
	return true;
}

function euromoda_iniciaTareaTrEm(idTarea, idUsuario)
{
	var _i = this.iface;
	
	if (!AQUtil.sqlSelect("pr_tareas","idtarea","idtarea = '" + idTarea + "'")) {
		return false;
	}

	var estado = AQUtil.sqlSelect("pr_tareas","estado","idtarea = '" + idTarea + "'");
	debug("estado " + estado);
	switch(estado) {
		case "TERMINADA": {
			debug("entra");
			return -2;
		}
		case "OFF": {
			return -3;
		}
	}
	
	if(AQUtil.sqlSelect("pr_tareas","idtipotarea","idtarea = '" + idTarea + "'") == "DC") {
		return -1;
	}
	
	return _i.__iniciaTareaTr(idTarea, idUsuario);
}

function euromoda_beforeCommit_pr_procesos(curProceso)
{
	var _i = this.iface;
	
	if (!_i.__beforeCommit_pr_procesos(curProceso)) {
		return false;
	}
	if (!_i.controlProcesoDuplicado(curProceso)) {
		return false;
	}
	return true;
}

function euromoda_controlProcesoDuplicado(curProceso)
{
	var _i = this.iface;
	if (curProceso.modeAccess() != curProceso.Insert) {
		return true;
	}
	var idProceso= curProceso.valueBuffer("idproceso");
	var codOrden = curProceso.valueBuffer("idobjeto");
	if (AQUtil.sqlSelect("pr_procesos", "idproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "' AND idproceso <> " + idProceso)) {
		sys.warnMsgBox(sys.translate("Error al generar el proceso para la orden %1. Parece que la orden ya tiene un proceso asociado").arg(codOrden));
		return false;
	}
	return true;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
