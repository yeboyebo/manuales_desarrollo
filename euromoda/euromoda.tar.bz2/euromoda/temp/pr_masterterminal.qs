
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	function euromoda( context ) { prod ( context ); }
	function filtroBase() {
		return this.ctx.euromoda_filtroBase();
	}
	function init() {
		return this.ctx.euromoda_init();
	}
	function avanzarTarea() {
		return this.ctx.euromoda_avanzarTarea();
	}
	function tbnImprimeAA_clicked() {
		return this.ctx.euromoda_tbnImprimeAA_clicked();
	}
	function toolButtonPrint_clicked() {
		return this.ctx.euromoda_toolButtonPrint_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_filtroBase()
{
	return "tipoobjeto = 'pr_ordenesproduccion'";
}

function euromoda_init()
{
	var _i = this.iface;
	_i.__init();

	this.child("tdbTareasS").putFirstCol("idobjeto");
	connect(this.child("toolButtonPrint"), "clicked()", _i, "toolButtonPrint_clicked");
	connect(this.child("tbnImprimeAA"), "clicked()", _i, "tbnImprimeAA_clicked");
}

function euromoda_avanzarTarea()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.valueBuffer("estado") == "TERMINADA") {
		MessageBox.warning(sys.translate("La tarea indicada ya est� terminada"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	if (cursor.valueBuffer("idtipotarea") == "DC") {
		MessageBox.warning(sys.translate("Las tareas de distribuci�n a confecciones deben terminarse desde su formulario correspondiente"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return _i.__avanzarTarea();
}

function euromoda_toolButtonPrint_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codOrden = cursor.valueBuffer("idobjeto");
	if (!codOrden) {
		return;
	}
	var oDH = new Object;
	oDH.codOrdenDesde = codOrden;
	oDH.codOrdenHasta = codOrden;
	oDH.cliente = undefined;
	formpr_ordenesproduccion.iface.pub_imprimeOrdenProd(oDH);
}

function euromoda_tbnImprimeAA_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codOrden = cursor.valueBuffer("idobjeto");
	if (!codOrden) {
		return;
	}
	debug("1");
	var oDH = new Object;
	debug("2");
	oDH.codOrdenDesde = codOrden;
	debug("3");
	oDH.codOrdenHasta = codOrden;
	debug("4");
	oDH.cliente = undefined;
	debug("5");
	formpr_ordenesproduccion.iface.pub_imprimeOrdenMat(oDH);
	debug("6");
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

