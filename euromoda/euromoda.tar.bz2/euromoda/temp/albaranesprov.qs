
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
  var pK_;
  function euromoda( context ) { oficial ( context ); }
  function init() {
    return this.ctx.euromoda_init();
  }
  function tbnPiezas_clicked() {
    return this.ctx.euromoda_tbnPiezas_clicked();
  }
  function tbnEtiquetas_clicked() {
    return this.ctx.euromoda_tbnEtiquetas_clicked();
  }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function controlBloqueo() {
		return this.ctx.euromoda_controlBloqueo();
	}
	function guardaDocumentoCommit() {
		return this.ctx.euromoda_guardaDocumentoCommit();
	}
	function calcularTotales() {
		return this.ctx.euromoda_calcularTotales();
	}
	function habilitarBobinas() {
		return this.ctx.euromoda_habilitarBobinas();
	}
	function filtraBobinas() {
		return this.ctx.euromoda_filtraBobinas();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	connect(this.child("tbnPiezas"), "clicked()", _i, "tbnPiezas_clicked");
	connect(this.child("tbnEtiquetas"), "clicked()", _i, "tbnEtiquetas_clicked");
	disconnect(this.child("tdbLineasAlbaranesProv").cursor(), "bufferCommited()", this, "iface.calcularTotales()");
	connect(this.child("tdbLineasAlbaranesProv").cursor(), "commited()", _i, "calcularTotales");	
	
	var cursor = this.cursor();
	_i.pK_ = cursor.valueBuffer(cursor.primaryKey());
	
	_i.habilitarBobinas();	
	var desdeAlbAca = formem_albaranaracabados.iface.desdeAlbAcabado_;	
	if(desdeAlbAca) {		
		this.child("tabWidget8").showPage("observaciones");
		formem_albaranaracabados.iface.pub_setDesdeAlbAcabado(false);
	}	
	_i.filtraBobinas();
}

function euromoda_tbnPiezas_clicked()
{
  var f = new FLFormSearchDB("em_asignarpiezas");
  f.setMainWidget();
  f.exec();
}

function euromoda_tbnEtiquetas_clicked()
{
	var _i = this.iface;
	var curL = this.child("tdbLineasAlbaranesProv").cursor();

	var qE = new AQSqlQuery;
	qE.setSelect("ms.codlote, ls.codpartida, ls.codalbaranprov, ls.candisponible, a.referencia, a.descripcion, a.codtamanoem, a.codcolorem, c.descripcion");
	qE.setFrom("movistock ms INNER JOIN lotesstock ls ON ms.codlote = ls.codlote INNER JOIN articulos a ON ms.referencia = a.referencia LEFT OUTER JOIN em_composiciones c ON a.em_codcomposicion = c.em_codcomposicion");
	qE.setWhere("ms.idlineaap = " + curL.valueBuffer("idlinea") + " ORDER BY ms.codlote");
	if (!qE.exec()) {
		return false;
	}

	var aEtiquetas = [];
	var codLote, referencia, cantidad;
	while (qE.next()) {
		codLote = qE.value("ms.codlote");
		referencia = qE.value("a.referencia");
		cantidad = 1;

	  var aE = new Object;
    aE["codlote"] = qE.value("ms.codlote");
		aE["referencia"] = qE.value("a.referencia");
    aE["descripcion"] = qE.value("a.descripcion");
    aE["tamano"] = qE.value("a.codtamanoem");
    aE["color"] = qE.value("a.codcolorem");
		aE["composicion"] = qE.value("c.descripcion");
		aE["partida"] = qE.value("ls.codpartida");
		aE["albaran"] = qE.value("ls.codalbaranprov");
		aE["metros"] = qE.value("ls.candisponible");
    aE["cantidad"] = cantidad;
    aEtiquetas.push(aE);
  }
  formem_etiquetaspie.iface.pub_imprimeEtiquetas(aEtiquetas);
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
  case "codproveedor": {
		_i.__bufferChanged(fN);
		sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
		if (!flfacturac.iface.pub_controlBloqueoProveedor(cursor.valueBuffer("codproveedor"), "Todo")) {
			sys.AQTimer.singleShot(0, formRecordalbaranesprov.reject)
		}
		break;
	}
	default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.controlBloqueo()) {
		return false;
	}
	_i.__calcularTotales();

	return true;
}

function euromoda_controlBloqueo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codProveedor = cursor.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
      return false;
    }
  }
	return true;
}

function euromoda_calcularTotales()
{
	var _i = this.iface;
	
	_i.guardaDocumentoCommit();

	_i.__calcularTotales();
}

function euromoda_guardaDocumentoCommit()
{
  	var _i = this.iface;
  	var cursor = this.cursor();

  	if (cursor.modeAccess() != cursor.Edit) {
    	return true;
  	}
  	var pk = cursor.valueBuffer(cursor.primaryKey());
  	formalbaranesprov.iface.pK_ = cursor.valueBuffer("codigo");

  	if (!_i.validateForm()) {
    	return false;
  	}

  	if (!cursor.commitBuffer()) {
    	return false;
  	}

  	cursor.commit();
  	cursor.transaction(false);

   	cursor.select(cursor.primaryKey() + " = " + _i.pK_);
	if (!cursor.first()) {
		sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
		return false;
	}
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
}
function euromoda_habilitarBobinas()
{
	if(this.cursor().valueBuffer("acabados")) {		
		this.child("tabWidget8").setTabEnabled("bobinas", true);
	}else {
		this.child("tabWidget8").setTabEnabled("bobinas", false);			
	}  

}

function euromoda_filtraBobinas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idAlbaran = cursor.valueBuffer("idalbaran");
	var filtro;
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			filtro = "1 = 2";
			break;
		}
		default: {
			var aBobinas = [];
			var q = new AQSqlQuery;	
			q.setSelect("distinct(codbobinaprl)");
			q.setFrom("em_tramostejido");
			q.setWhere("idalbaranprov = " + idAlbaran); 			
			if (!q.exec()){
				return;
			}  
			while(q.next())
			{
				aBobinas.push(q.value("distinct(codbobinaprl)"));
			}	
			aBobinas = "'" + aBobinas.join("', '") + "'";
			filtro = "codbobina IN (" + aBobinas + ")";
		}
	}
	this.child("tdbBobinas").cursor().setMainFilter(filtro);
	
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
