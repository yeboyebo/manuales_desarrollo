
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends ctaVentasArt {
  function euromoda( context ) { ctaVentasArt ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function calculateField(fN) {
    return this.ctx.euromoda_calculateField(fN);
  }
  function init() {
    return this.ctx.euromoda_init();
  }
	function modoTexto() {
    return this.ctx.euromoda_modoTexto();
  }
  function pbnInsertarPlantillaTexto_clicked() {
    return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
  }
  function validateForm() {
    return this.ctx.euromoda_validateForm();
  }
  function dameFiltroReferencia() {
    return this.ctx.euromoda_dameFiltroReferencia();
  }
  function ledEmArticulo_returnPressed() {
    return this.ctx.euromoda_ledEmArticulo_returnPressed();
  }
  function validaFacturaAbono(cursor, curFactura) {
     return this.ctx.euromoda_validaFacturaAbono(cursor, curFactura);
  }
  	function aceptarFormulario() {
  		return this.ctx.euromoda_aceptarFormulario();
  	}
  	function aceptaContinuaFormulario() {
  		return this.ctx.euromoda_aceptaContinuaFormulario();
  	}
  	function habilitarBotonesAceptar() {
  		return this.ctx.euromoda_habilitarBotonesAceptar();
  	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
    function pubEuromoda( context ) { ifaceCtx( context ); }
//     function pub_dameSubcuentaProducto(cursor) {
//       return this.dameSubcuentaProducto(cursor);
//     }
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
  _i.__init();
	var codCliente;
	var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(cursor);
	if (!datosTP) {
		codCliente = false;
	} else {
		codCliente = datosTP["codcliente"];
	}
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",codCliente);
  
  connect(this.child("fdbCodSubcuenta").obj(), "lostFocus()", this.child("fdbPvpUnitario"), "setFocus()");
  connect(this.child("fdbCodAmortizacion").obj(), "lostFocus()", this.child("fdbPvpUnitario"), "setFocus()");
  connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");
  
  switch (cursor.modeAccess()) {
  case cursor.Insert: {
      this.child("fdbReferencia").setFocus();
      break;
    }
  case cursor.Edit: {
      sys.disableObj(this, "fdbTipoConcepto");
      if (cursor.valueBuffer("tipoconcepto") == "Activo fijo") {
        sys.disableObj(this, "fdbCodAmortizacion");
      }
      break;
    }
  }
  formRecordlineaspedidoscli.iface.pub_habilitaTipoConcepto(this);
  _i.modoTexto();
	
	try {
		AQS.setTabOrder(this.child("fdbReferencia").obj(), this.child("fdbCantidad").obj());
		AQS.setTabOrder(this.child("fdbCantidad").obj(), this.child("fdbPvpUnitario").obj());
	} catch (e) {}
	
	connect(this.child("ledEmArticulo"), "returnPressed()", _i, "ledEmArticulo_returnPressed");
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			this.child("ledEmArticulo").setFocus();
			break;
		}
  	}

  	//Desconectamos el boton aceptar
	if(this.child("pushButtonAccept")){
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	  	connect(this.child("pushButtonAccept"), "clicked()", _i, "aceptarFormulario");
	}

	if(this.child("pushButtonAcceptContinue")){
  		disconnect(this.child("pushButtonAcceptContinue"), "clicked()", this.obj(), "acceptContinue()");
  		connect(this.child("pushButtonAcceptContinue"), "clicked()", _i, "aceptaContinuaFormulario");

  		_i.habilitarBotonesAceptar();
  	}
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  switch (fN) {
		case "codsubcuenta":
		case "referencia": { /// Evita ejecutar el c�digo de ctaVentaArt
			formRecordlineaspedidoscli.iface.pub_commonBufferChanged(fN, this);
			break;
		}
  case "refcliente": {
      sys.setObjText(this, "fdbReferencia", _i.calculateField("referencia"));
      break;
    }
//   case "codamortizacion": {
//       sys.setObjText(this, "fdbDescripcion", _i.calculateField("desactivo"));
//       sys.setObjText(this, "fdbCodSubcuenta", _i.calculateField("codsubcuentaaf"));
//       break;
//     }
//   case "referencia": {
//       sys.setObjText(this, "fdbDescripcion", _i.calculateField("desarticulo"));
//       _i.__bufferChanged(fN);
//       break;
//     }
//   case "idsubcuenta": {
//       sys.setObjText(this, "fdbDescripcion", _i.calculateField("dessubcuenta"));
//       _i.__bufferChanged(fN);
//       break;
//     }
  case "tipoconcepto": {
      //_i.habilitaTipoConcepto();
			_i.__bufferChanged(fN);
      _i.modoTexto();
      break;
    }
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
  case "referencia": {
      valor = AQUtil.sqlSelect("articulos", "referencia", "aliasart = '" + cursor.valueBuffer("refcliente") + "'");
      break;
    }
//   case "desactivo": {
//       valor = AQUtil.sqlSelect("co_amortizaciones", "elemento", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
//       break;
//     }
//   case "desarticulo": {
//       valor = AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + cursor.valueBuffer("referencia") + "'");
//       break;
//     }
//   case "dessubcuenta": {
//       valor = AQUtil.sqlSelect("co_subcuentas", "descripcion", "idsubcuenta = '" + cursor.valueBuffer("idsubcuenta") + "'");
//       break;
//     }
//   case "codsubcuenta": {
//       valor = _i.dameSubcuentaProducto(cursor);
//       break;
//     }
//     case "codsubcuentaaf": {
//       var codAF = cursor.valueBuffer("codamortizacion");
//       if (!codAF || codAF == "") {
//         valor = "";
//       } else {
//         valor = AQUtil.sqlSelect("co_amortizaciones a INNER JOIN co_gruposcontablesamo g ON a.codgrupocontableamo = g.codgrupo", "g.codsubcuentaele", "a.codamortizacion = '" + codAF + "'", "co_amortizaciones,co_gruposcontablesamo");
//       }
//       break;
//     }
  default: {
      valor = _i.__calculateField(fN);
    }
  }
  return valor;
}

// function euromoda_dameSubcuentaProducto(cursor)
// {
//   var valor;
//   var cR = cursor.cursorRelation();
//   var codCliente, deAbono;
//   if (cR) {
//     codCliente = cR.valueBuffer("codcliente");
//     deAbono = cR.valueBuffer("deabono");
//   } else {
//     codCliente = AQUtil.sqlSelect("facturascli", "codcliente", "idfactura = " + cursor.valueBuffer("idfactura"));
//     deAbono = AQUtil.sqlSelect("facturascli", "deabono", "idfactura = " + cursor.valueBuffer("idfactura"));
//   }
//   var gCNegocio = AQUtil.sqlSelect("clientes", "codgrupocontableneg", "codcliente = '" + codCliente  + "'");
//   var referencia = cursor.valueBuffer("referencia");
//   if (!referencia || referencia == "") {
//     valor = "";
//   } else {
//     if (deAbono) {
//       valor = AQUtil.sqlSelect("articulos a INNER JOIN gruposcontablesproneg g ON a.codgrupocontablepro = g.codgrupocontablepro", "g.codsubcuentadven", "referencia = '" + referencia + "' AND g.codgrupocontableneg = '" + gCNegocio + "'", "articulos,gruposcontablesproneg");
//     } else {
//       valor = AQUtil.sqlSelect("articulos a INNER JOIN gruposcontablesproneg g ON a.codgrupocontablepro = g.codgrupocontablepro", "g.codsubcuentaven", "referencia = '" + referencia + "' AND g.codgrupocontableneg = '" + gCNegocio + "'", "articulos,gruposcontablesproneg");
//     }
//   }
//   return valor;
// }

// function euromoda_habilitaTipoConcepto()
// {
//   var cursor = this.cursor();
//   switch (cursor.valueBuffer("tipoconcepto")) {
//   case "Producto": {
//       this.child("fdbCodAmortizacion").close();
//       this.child("fdbCodAmortizacion").setValue("");
//       this.child("fdbReferencia").obj().show();
// 			this.child("fdbRefCliente").obj().show();
//       this.child("fdbReferencia").setFocus();
//       break;
//     }
//   case "Cuenta": {
//       this.child("fdbCodAmortizacion").close();
//       this.child("fdbCodAmortizacion").setValue("");
//       this.child("fdbReferencia").close();
// 			this.child("fdbRefCliente").close();
//       this.child("fdbReferencia").setValue("");
//       this.child("fdbCodSubcuenta").setFocus();
//       break;
//     }
//   case "Activo fijo": {
//       this.child("fdbCodAmortizacion").obj().show();
//       this.child("fdbCodAmortizacion").setFocus();
//       this.child("fdbReferencia").close();
//       this.child("fdbRefCliente").close();
//       this.child("fdbReferencia").setValue("");
//       break;
//     }
//   }
// }

function euromoda_modoTexto()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
  case "Texto": {
      this.child("fdbReferencia").setValue("");
      this.child("fdbCantidad").setValue(0);
      this.child("fdbPvpUnitario").setValue(0);
      this.child("fdbCodImpuesto").setValue("");
      this.child("groupBox7").enabled = false;
      this.child("groupBox8").enabled = false;
      this.child("groupBox9").enabled = false;
      this.child("groupBox10").enabled = false;
      this.child("gbxTexto").enabled = true;
      this.child("fdbTexto").setFocus();
      break;
    }
  default: {
      this.child("groupBox7").enabled = true;
      this.child("groupBox8").enabled = true;
      this.child("groupBox9").enabled = true;
      this.child("groupBox10").enabled = true;
      this.child("gbxTexto").enabled = false;
      this.child("fdbTexto").setValue("");
      break;
    }
  }
}
function euromoda_pbnInsertarPlantillaTexto_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbTexto").setValue(texto);
}

function euromoda_validateForm()
{
	var cursor = this.cursor();
	var _i = this.iface;

	var oParamLin = new Object;
	oParamLin.cursor = cursor;
	oParamLin.ignorarAvisos = false;
	oParamLin.forzarReg = false;
	oParamLin.ignorarCalculoInsert = false; 

	if (!_i.__validateForm()) {
		_i.habilitarBotonesAceptar();
		return false;
	}
	if (!flfacturac.iface.pub_validaIvaLinea(cursor)) {
		_i.habilitarBotonesAceptar();
		return false;
	}
	if(!formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin)) {
  		_i.habilitarBotonesAceptar();
		return false;
	}
	return true;
}

function euromoda_dameFiltroReferencia()
{
	var _i = this.iface;
// 	var f = _i.__dameFiltroReferencia();
	var f = "NOT debaja";
	return f;
}
function euromoda_ledEmArticulo_returnPressed()
{
	formRecordlineaspedidoscli.iface.pub_commonLedEmArticulo_returnPressed(this);
}

function euromoda_validaFacturaAbono(cursor, curFactura)
{

	if ((curFactura.valueBuffer("deabono") == true || curFactura.valueBuffer("em_deabono") == true)  && cursor.valueBuffer("pvptotal") > 0) {
		var res = MessageBox.warning(AQUtil.translate("scripts","Si esta creando una factura de abono la cantidad total debe ser negativa.\n\n�Desea continuar?"), MessageBox.No, MessageBox.Yes, MessageBox.NoButton);
		if (res == MessageBox.No)
			return false;
	}
	if (curFactura.valueBuffer("deabono") == false && curFactura.valueBuffer("em_deabono") == false && cursor.valueBuffer("pvptotal") < 0) {
		var res = MessageBox.warning(AQUtil.translate("scripts","Si esta creando una factura que no es de abono la cantidad total debe ser positiva.\n\n�Desea continuar?"), MessageBox.No, MessageBox.Yes, MessageBox.NoButton);
		if (res == MessageBox.No)
			return false;
	}
	return true;

}

function euromoda_aceptarFormulario()
{
	var _i = this.iface;

	debug("euromoda_aceptarFormulario");
	this.child("pushButtonAccept").setDisabled(true);
	this.obj().accept();
}

function euromoda_aceptaContinuaFormulario()
{
	var _i = this.iface;

	debug("euromoda_aceptaContinuaFormulario");
	this.child("pushButtonAcceptContinue").setDisabled(true);
	this.obj().acceptContinue();
}

function euromoda_habilitarBotonesAceptar()
{
	this.child("pushButtonAccept").setDisabled(false);
	this.child("pushButtonAcceptContinue").setDisabled(false);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
