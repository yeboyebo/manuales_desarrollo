
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {	
	function euromoda( context ) { prod ( context ); }
	function beforeCommit_lineaspedidosprov(curLP) {
		return this.ctx.euromoda_beforeCommit_lineaspedidosprov(curLP);
	}
	function afterCommit_lineaspedidosprov(curLP) {
		return this.ctx.euromoda_afterCommit_lineaspedidosprov(curLP);
	}
	function controlAlarmasMat(curLP) {
		return this.ctx.euromoda_controlAlarmasMat(curLP);
	}
	function calculaPendienteLP(curLP) {
		return this.ctx.euromoda_calculaPendienteLP(curLP);
	}
	function beforeCommit_lineasalbaranesprov(curLA) {
		return this.ctx.euromoda_beforeCommit_lineasalbaranesprov(curLA);
	}
	function controlBorradoEstampado(curLA) {
		return this.ctx.euromoda_controlBorradoEstampado(curLA);
	}
	function siGenerarRecibosCli(curFactura, masCampos) {
		return this.ctx.euromoda_siGenerarRecibosCli(curFactura, masCampos);
	}
	function generarPartidasVenta(curFactura, idAsiento, valoresDefecto) {
		return this.ctx.euromoda_generarPartidasVenta(curFactura, idAsiento, valoresDefecto);
	}
	function generarPartidasVentaEM(curFactura, idAsiento, valoresDefecto) {
		return this.ctx.euromoda_generarPartidasVentaEM(curFactura, idAsiento, valoresDefecto);
	}
	function generarPartidasCompra(curFactura, idAsiento, valoresDefecto) {
		return this.ctx.euromoda_generarPartidasCompra(curFactura, idAsiento, valoresDefecto);
	}
	function generarPartidasCompraEM(curFactura, idAsiento, valoresDefecto) {
		return this.ctx.euromoda_generarPartidasCompraEM(curFactura, idAsiento, valoresDefecto);
	}
	function datosCtaDto(valoresDefecto, curFactura, idAsiento) {
		return this.ctx.euromoda_datosCtaDto(valoresDefecto, curFactura, idAsiento);
	}
	function asientoFacturaAbonoCli(curFactura, valoresDefecto) {
		return this.ctx.euromoda_asientoFacturaAbonoCli(curFactura, valoresDefecto);
	}
	function asientoFacturaAbonoProv(curFactura, valoresDefecto) {
		return this.ctx.euromoda_asientoFacturaAbonoProv(curFactura, valoresDefecto);
	}
  function afterCommit_lineaspedidomarcocli(curLP) {
    return this.ctx.euromoda_afterCommit_lineaspedidomarcocli(curLP);
  }
  function gestionPedidoParcial(curPedido) {
    return this.ctx.euromoda_gestionPedidoParcial(curPedido);
  }
  function controlBloqueoCliente(codCliente, tipoControl) {
    return this.ctx.euromoda_controlBloqueoCliente(codCliente, tipoControl);
  }
  function controlBloqueoProveedor(codProveedor, tipoControl) {
    return this.ctx.euromoda_controlBloqueoProveedor(codProveedor, tipoControl);
  }
  function avisarObservacionesCliente(codCliente) {
    return this.ctx.euromoda_avisarObservacionesCliente(codCliente);
  }
  function afterCommit_facturascli(curF) {
    return this.ctx.euromoda_afterCommit_facturascli(curF);
  }
  function controlUltimaFacturaCli(curF) {
    return this.ctx.euromoda_controlUltimaFacturaCli(curF);
  }
  function controlRiesgoCliente(codCliente, preguntar) {
    return this.ctx.euromoda_controlRiesgoCliente(codCliente, preguntar);
  }
  function comprobarFacturaAbonoCli(curFactura) {
    return this.ctx.euromoda_comprobarFacturaAbonoCli(curFactura);
  }
  function comprobarFacturaAbonoProv(curFactura) {
    return this.ctx.euromoda_comprobarFacturaAbonoProv(curFactura);
  }
  function beforeCommit_facturascli(curF) {
    return this.ctx.euromoda_beforeCommit_facturascli(curF);
  }
  function validaFechaFacturaCli(curF) {
    return this.ctx.euromoda_validaFechaFacturaCli(curF);
  }
  function beforeCommit_facturasprov(curF) {
    return this.ctx.euromoda_beforeCommit_facturasprov(curF);
  }
  function validaFechaFacturaProv(curF) {
    return this.ctx.euromoda_validaFechaFacturaProv(curF);
  }
  function generarPartidasCliente(curFactura, idAsiento, valoresDefecto, ctaCliente) {
		return this.ctx.euromoda_generarPartidasCliente(curFactura, idAsiento, valoresDefecto, ctaCliente);
	}
	function generarPartidasProveedor(curFactura, idAsiento, valoresDefecto, ctaProveedor, concepto, sinIVA) {
		return this.ctx.euromoda_generarPartidasProveedor(curFactura, idAsiento, valoresDefecto, ctaProveedor, concepto, sinIVA);
	}
	function datosPartidaFactura(curPartida, curFactura, tipo, concepto) {
		return this.ctx.euromoda_datosPartidaFactura(curPartida, curFactura, tipo, concepto);
	}
	function datosPartidaIVAFacturaImport(curPartida, curFactura, tipo, concepto, curFacturaImport) {
		return this.ctx.euromoda_datosPartidaIVAFacturaImport(curPartida, curFactura, tipo, concepto, curFacturaImport);
	}
	function validaIvaLinea(cursor) {
		return this.ctx.euromoda_validaIvaLinea(cursor);
	}
	function comprobarCambioSerie(cursor) {
		return this.ctx.euromoda_comprobarCambioSerie(cursor);
	}
	function afterCommit_lineasfacturasprov(curLF) {
		return this.ctx.euromoda_afterCommit_lineasfacturasprov(curLF);
	}
	function controlValorActivo(curLF) {
		return this.ctx.euromoda_controlValorActivo(curLF);
	}
	function actualizaValorActivo(codActivo) {
		return this.ctx.euromoda_actualizaValorActivo(codActivo);
	}
	function gestionPedidoParcial(curPedido) {
		return this.ctx.euromoda_gestionPedidoParcial(curPedido);
	}
	function afterCommit_pedidosmarcocli(curPM) {
		return this.ctx.euromoda_afterCommit_pedidosmarcocli(curPM);
	}
	function controlEstadoPedidoMarco(curPM) {
		return this.ctx.euromoda_controlEstadoPedidoMarco(curPM);
	}
	function restarCantidadCli(idLineaPedido, idLineaAlbaran) {
		return this.ctx.euromoda_restarCantidadCli(idLineaPedido, idLineaAlbaran);
	}
	function restarCantidadProv(idLineaPedido, idLineaAlbaran) {
		return this.ctx.euromoda_restarCantidadProv(idLineaPedido, idLineaAlbaran);
	}
	function sirveLineaPedidoCli(curLA) {
		return this.ctx.euromoda_sirveLineaPedidoCli(curLA);
	}
	function sirveLineaPedidoProv(curLA) {
		return this.ctx.euromoda_sirveLineaPedidoProv(curLA);
	}
	function liberarAlbaranesCli(idFactura) {
		return this.ctx.euromoda_liberarAlbaranesCli(idFactura);
	}
	function liberarPedidoCli(idPedido) {
		return this.ctx.euromoda_liberarPedidoCli(idPedido);
	}
	function afterCommit_pedidoscli(curPedido) {
		return this.ctx.euromoda_afterCommit_pedidoscli(curPedido);
	}
	function controlFechaCliente(curPedido) {
		return this.ctx.euromoda_controlFechaCliente(curPedido);
	}
	function afterCommit_pedidosprov(curPedido) {
		return this.ctx.euromoda_afterCommit_pedidosprov(curPedido);
	}
 	function controlHistoricoAcabados(curPedido) {
		return this.ctx.euromoda_controlHistoricoAcabados(curPedido);
	}
	function creaHistoricoAcabados(idPedido, estadoA) {
		return this.ctx.euromoda_creaHistoricoAcabados(idPedido, estadoA);
	}
    function beforeCommit_pedidosprov(curP) {
		return this.ctx.euromoda_beforeCommit_pedidosprov(curP);
	}
	function beforeCommit_pedidoscli(curP) {
		return this.ctx.euromoda_beforeCommit_pedidoscli(curP);
	}
	function beforeCommit_albaranesprov(curP) {
		return this.ctx.euromoda_beforeCommit_albaranesprov(curP);
	}
	function beforeCommit_albaranescli(curP) {
		return this.ctx.euromoda_beforeCommit_albaranescli(curP);
	}
	function beforeCommit_em_imppednoc(curImp) {
		return this.ctx.euromoda_beforeCommit_em_imppednoc(curImp);
	}
	function controlImpPedNoctalia(curImp) {
		return this.ctx.euromoda_controlImpPedNoctalia(curImp);
	}
	function beforeCommit_em_impalbnoc(curImp) {
	     return this.ctx.euromoda_beforeCommit_em_impalbnoc(curImp) ;
	}
	function controlImpFacNoctalia(curImp) {
		return this.ctx.euromoda_controlImpFacNoctalia(curImp);
	}
	function controlImpAlbNoctalia(curImp) {
		return this.ctx.euromoda_controlImpAlbNoctalia(curImp);
	}
    function beforeCommit_lineasfacturascli(curLF) {
		return this.ctx.euromoda_beforeCommit_lineasfacturascli(curLF);
	}
	function controlBorradoActivoFacturacli(curLF) {
		return this.ctx.euromoda_controlBorradoActivoFacturacli(curLF);
	}
	function afterCommit_lineasalbaranesprov(curLA) {
		return this.ctx.euromoda_afterCommit_lineasalbaranesprov(curLA);
	}
	function afterCommit_lineasalbaranescli(curLA) {
		return this.ctx.euromoda_afterCommit_lineasalbaranescli(curLA);
	}
	function recalcularHuecos( serie, ejercicio, fN, emTipoFra ) {
		return this.ctx.euromoda_recalcularHuecos( serie, ejercicio, fN, emTipoFra );
	}
	function controlFacturasBloqSerie(curF) {
		return this.ctx.euromoda_controlFacturasBloqSerie(curF);
	}
	function beforeCommit_lineasalbaranescli(curLA){
		return this.ctx.euromoda_beforeCommit_lineasalbaranescli(curLA);
	}
	function beforeCommit_lineaspedidoscli(curLP){
		return this.ctx.euromoda_beforeCommit_lineaspedidoscli(curLP);
	}
	function buscaPosEnCursor(oParams) {
		return this.ctx.euromoda_buscaPosEnCursor(oParams);
	}
	function afterCommit_albaranesprov(curAlbaran) {
		return this.ctx.euromoda_afterCommit_albaranesprov(curAlbaran);
	}
 	function actualizarDatosUltCompraAP(curAlbaran) {
 		return this.ctx.euromoda_actualizarDatosUltCompraAP(curAlbaran);
 	}
 	function afterCommit_facturasprov(curFactura) {
		return this.ctx.euromoda_afterCommit_facturasprov(curFactura);
	}
 	function actualizarDatosUltCompraFP(curFactura) {
 		return this.ctx.euromoda_actualizarDatosUltCompraFP(curFactura);
 	} 	
 	function actualizarFechaUltVentaAlbAlm(curLA) {
 		return this.ctx.euromoda_actualizarFechaUltVentaAlbAlm(curLA);
 	}
	function actualizarDatosUltCompraAlbAlm(curLA) {
		return this.ctx.euromoda_actualizarDatosUltCompraAlbAlm(curLA);
	}
	function actualizarDatosUltCompraFraAlm(curLF) {
		return this.ctx.euromoda_actualizarDatosUltCompraFraAlm(curLF);
	}
	function afterCommit_albaranescli(curAlbaran) {
		return this.ctx.euromoda_afterCommit_albaranescli(curAlbaran);
	}
	function actualizarDatosUltVentaAC(curAlbaran) {
 		return this.ctx.euromoda_actualizarDatosUltVentaAC(curAlbaran);
 	}
 	function beforeCommit_em_dropshipping(curDS) {
 		return this.ctx.euromoda_beforeCommit_em_dropshipping(curDS);
 	}
 	function totalizaDrop(codDrop) {
 		return this.ctx.euromoda_totalizaDrop(codDrop);
 	}
	function totalizaEnvioDrop(curLA) {
		return this.ctx.euromoda_totalizaEnvioDrop(curLA);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
  function pubEuromoda( context ) { ifaceCtx( context ); }
  function pub_controlBloqueoProveedor(codProveedor, tipoControl) {
    return this.controlBloqueoProveedor(codProveedor, tipoControl);
  }
  function pub_controlBloqueoCliente(codCliente, tipoControl) {
    return this.controlBloqueoCliente(codCliente, tipoControl);
  }
  function pub_controlRiesgoCliente(codCliente, preguntar) {
    return this.controlRiesgoCliente(codCliente, preguntar);
  }
  function pub_validaIvaLinea(cursor) {
    return this.validaIvaLinea(cursor);
  }
  function pub_buscaPosEnCursor(oParams) {
	return this.buscaPosEnCursor(oParams);
  }
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_gestionPedidoParcial(curPedido)
{
	var _i = this.iface;
	var idAlbaran = _i.__gestionPedidoParcial(curPedido);
	if (!idAlbaran) {
		return false;
	}
	if (typeof(idAlbaran) == "boolean") {
		return true;
	}
	var codAlbaran = AQUtil.sqlSelect("albaranescli", "codigo", "idalbaran = " + idAlbaran);
	if (!codAlbaran) {
		return false;
	}
	var res = MessageBox.information(sys.translate("Se gener� el albar�n %1.\n�Desea imprimirlo?").arg(codAlbaran), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res == MessageBox.Yes) {
		formalbaranescli.iface.pub_imprimir(codAlbaran);
	}
	return idAlbaran;
}

function euromoda_afterCommit_lineaspedidomarcocli(curLP)
{
	debug("euromoda_afterCommit_lineaspedidomarcocli");
  if (sys.isLoadedModule("flfactalma")) {
    if (!flfactalma.iface.pub_controlStockPedidosMarcoCli(curLP)) {
      return false;
    }
  }
  return true;
}

function euromoda_beforeCommit_lineaspedidosprov(curLP)
{
	var _i = this.iface;
	if (!_i.calculaPendienteLP(curLP)) {
		return false;
	}
	if (!_i.__beforeCommit_lineaspedidosprov(curLP)) {
		debug("__beforeCommit_lineaspedidosprov falla");
		return false;
	}
	return true;
}

function euromoda_afterCommit_lineaspedidosprov(curLP)
{
	var _i = this.iface;
	if (!_i.__afterCommit_lineaspedidosprov(curLP)) {
		return false;
	}
	if (!curLP.isNull("codloteprod")) {
		var codLote = curLP.valueBuffer("codloteprod");
		if (!flfactalma.iface.pub_revisaReservasLoteProd(codLote)) {
			return false;
		}
	}
	if (!_i.controlAlarmasMat(curLP)) {
		return false;
	}
	return true;
}

function euromoda_afterCommit_lineasalbaranesprov(curLA)
{
	var _i = this.iface;
	if (!_i.__afterCommit_lineasalbaranesprov(curLA)) {
		return false;
	}
	if (!curLA.isNull("codloteprod")) {
		var codLote = curLA.valueBuffer("codloteprod");
		if (!flfactalma.iface.pub_revisaReservasLoteProd(codLote)) {
			return false;
		}
	}
	var referencia = curLA.valueBuffer("referencia");
	if (!flfactalma.iface.pub_actualizarDatosUltCompra(referencia)) {
		return false;
	}	
	if(!_i.actualizarDatosUltCompraAlbAlm(curLA)) {
		return false;
	}
	return true;
}

function euromoda_afterCommit_lineasalbaranescli(curLA)
{
	debug("\n\neuromoda_afterCommit_lineasalbaranescli");
	var _i = this.iface;
	if (!_i.__afterCommit_lineasalbaranescli(curLA)) {
		return false;
	}
	var referencia = curLA.valueBuffer("referencia");
	if (!flfactalma.iface.pub_actualizarFechaUltVenta(referencia)) {
		return false;
	}
	if(!_i.actualizarFechaUltVentaAlbAlm(curLA)) {
		return false;
	}
	if(curLA.modeAccess() == curLA.Del){
		var codDropshipping = AQUtil.sqlSelect("albaranescli", "em_coddropshipping", "idalbaran = " + curLA.valueBuffer("idalbaran"));				
		if(codDropshipping && codDropshipping != ""){		
			if(!_i.totalizaEnvioDrop(curLA)) {
				return false;
			}
			if(!_i.totalizaDrop(codDropshipping)) {
				return false;
			}

		}
	}
	return true;
}

function euromoda_controlAlarmasMat(curLP)
{
	if (curLP.modeAccess() != curLP.Edit) {
		return true;
	}
	if (curLP.valueBuffer("totalenalbaran") == curLP.valueBufferCopy("totalenalbaran") && curLP.valueBuffer("cerrada") == curLP.valueBufferCopy("cerrada")) {
		return true;
	}
	var ahora = new Date;
	var restante = curLP.valueBuffer("totalenalbaran");
	var cantidad, servida, pendiente;
	var curA = new FLSqlCursor("em_alarmasmat");
	curA.select("idlineapp = " + curLP.valueBuffer("idlinea") + " ORDER BY idalarma");
	while (curA.next()) {
		curA.setModeAccess(curA.Edit);
		curA.refreshBuffer();
		cantidad = curA.valueBuffer("cantidad");
		servida = restante > cantidad ? cantidad : restante;
		restante -= servida;
		pendiente = curLP.valueBuffer("cerrada") ? 0 : cantidad - servida;
		if (curA.valueBuffer("canservida") == servida && curA.valueBuffer("canpendiente") == pendiente) {
			continue;
		}
		curA.setValueBuffer("canservida", servida);
		curA.setValueBuffer("canpendiente", pendiente);
		if (pendiente == 0 && !curA.valueBuffer("fin")) {
			curA.setValueBuffer("fin", true);
			curA.setValueBuffer("fechafin", ahora.toString().left(10));
		} else {
			curA.setValueBuffer("fin", false);
			curA.setNull("fechafin");
		}
		if (!curA.commitBuffer()) {
			return false;
		}
	}
	return true;
}


function euromoda_calculaPendienteLP(curLP)
{
debug("euromoda_calculaPendienteLP");
	switch (curLP.modeAccess()) {
		case curLP.Insert:
		case curLP.Edit: {
			var curRel = curLP.cursorRelation();
			if (curRel && curRel.table() == "pedidosprov") {
				break;
			}
			curLP.setValueBuffer("pendiente", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pendiente", curLP));
			break;
		}
	}
debug("euromoda_calculaPendienteLP OK");
	return true;
}

function euromoda_beforeCommit_lineasalbaranesprov(curLA)
{
	debug("euromoda_beforeCommit_lineasalbaranesprov");
	var _i = this.iface;
	var acabados = false;
	var idAlbaran = curLA.valueBuffer("idalbaran");
	var acabados = AQUtil.sqlSelect("albaranesprov", "acabados", "idalbaran = " + idAlbaran);	
	if(!acabados) {	
		if (!_i.controlBorradoEstampado(curLA)) {
			return false;
		}
	}
	if (!_i.__beforeCommit_lineasalbaranesprov(curLA)) {
		return false;
	}
	return true;
}

function euromoda_controlBorradoEstampado(curLA)
{
	if (curLA.modeAccess() != curLA.Del) {
		return true;
	}
	
	var _i = this.iface;
	var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + curLA.valueBuffer("referencia") + "'");
	if (!flfactalma.iface.pub_esFamiliaEstampado(codFamilia)) {
		return true;
	}
	var cantidad = curLA.valueBuffer("cantidad");
	if (cantidad != 0) {
		MessageBox.warning(sys.translate("scripts", "La cantidad de las l�neas de tejido estampado a borrar debe ser 0.\nElimine antes sus piezas asociadas"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function euromoda_siGenerarRecibosCli(curFactura, masCampos)
{
	var _i = this.iface;
	var aMasCampos = ["fechavalor", "em_codpago"];
	return _i.__siGenerarRecibosCli(curFactura, aMasCampos);
}

function euromoda_generarPartidasVenta(curFactura, idAsiento, valoresDefecto)
{
  var _i = this.iface;
  if (!_i.generarPartidasVentaEM(curFactura, idAsiento, valoresDefecto)) {
    return false;
  }
  if (!_i.generarPartidasDtoEspCli(curFactura, idAsiento, valoresDefecto)) {
    return false;
  }
  return true;
}

function euromoda_generarPartidasVentaEM(curFactura, idAsiento, valoresDefecto)
{
  var ctaVentas = [];
	var monedaSistema = (valoresDefecto.coddivisa == curFactura.valueBuffer("coddivisa"));
	var haber:Number = 0;
	var haberME:Number = 0;
	var idUltimaPartida:Number = 0;

	var idFactura = curFactura.valueBuffer("idfactura");
	var codCliente = curFactura.valueBuffer("codcliente");
	var codGrupoNegocio = AQUtil.sqlSelect("clientes", "codgrupocontableneg", "codcliente = '" + codCliente + "'");
	var qrySubcuentas = new FLSqlQuery();
	with (qrySubcuentas) {
		setTablesList("lineasfacturascli,articulos");
		setSelect("l.codsubcuenta, a.codgrupocontablepro, l.codamortizacion, SUM(l.pvptotal)");
		setFrom("lineasfacturascli l LEFT OUTER JOIN articulos a ON l.referencia = a.referencia");
		setWhere("idfactura = " + curFactura.valueBuffer("idfactura") + " AND tipoconcepto <> 'Texto' GROUP BY l.codsubcuenta, a.codgrupocontablepro, l.codamortizacion");
	}
	if (!qrySubcuentas.exec()) {
debug("euromoda_generarPartidasVentaEM 1");
		return false;
	}
	var neto = this.iface.netoVentasFacturaCli(curFactura);;
	neto = AQUtil.roundFieldValue(neto, "facturascli", "neto");
	var iSubcuenta = 1;
	var totalHaber = 0;
	valoresDefecto.ctaVentasCompras = false;
	var codSubcuenta, hayCtaVentasCompras = false;
	valoresDefecto.ctaVentasCompras = false;

	var codActivo;
	while (qrySubcuentas.next()) {
		codActivo = qrySubcuentas.value("l.codamortizacion");
		codSubcuenta = qrySubcuentas.value("l.codsubcuenta");
		if (codSubcuenta && codSubcuenta != "") {
			ctaVentas.codsubcuenta = codSubcuenta;
		} else {
			ctaVentas.codgrupoprod = qrySubcuentas.value("a.codgrupocontablepro");
			if (curFactura.valueBuffer("deabono")) {
				ctaVentas.codsubcuenta = AQUtil.sqlSelect("gruposcontablesproneg", "codsubcuentadven", "codgrupocontablepro = '" + ctaVentas.codgrupoprod + "' AND codgrupocontableneg = '" + codGrupoNegocio + "'");
			} else {
				ctaVentas.codsubcuenta = AQUtil.sqlSelect("gruposcontablesproneg", "codsubcuentaven", "codgrupocontablepro = '" + ctaVentas.codgrupoprod + "' AND codgrupocontableneg = '" + codGrupoNegocio + "'");
			}
			if (!ctaVentas.codsubcuenta) {
				MessageBox.warning(sys.translate("No se ha definido ninguna subcuenta para el grupo de producto %1 y el grupo de negocio %2.\nPara poder crear la factura debe crear antes esta subcuenta").arg(ctaVentas.codgrupoprod).arg(codGrupoNegocio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
			}
		}
		ctaVentas.idsubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + ctaVentas.codsubcuenta + "' AND codejercicio = '" + valoresDefecto.codejercicio + "'");
		if (!ctaVentas.idsubcuenta) {
			MessageBox.warning(sys.translate("No existe la subcuenta %1 correspondiente al ejercicio %2.\nPara poder crear la factura debe crear antes esta subcuenta").arg(ctaVentas.codsubcuenta).arg(valoresDefecto.codejercicio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		/// S�lo consideramos una cta de ventas para luego poder usarla en el dto p.p.
		if (!hayCtaVentasCompras) {
debug("establece cta ventas a " + ctaVentas.codsubcuenta);
			hayCtaVentasCompras = true;
			valoresDefecto.ctaVentasCompras = ctaVentas;
		}	
		
		if (monedaSistema) {
			haber = parseFloat(qrySubcuentas.value("SUM(l.pvptotal)"));
			haberME = 0;
		} else {
			haber = parseFloat(qrySubcuentas.value("SUM(l.pvptotal)")) * parseFloat(curFactura.valueBuffer("tasaconv"));
			haberME = parseFloat(qrySubcuentas.value("SUM(l.pvptotal)"));
		}
		haber = AQUtil.roundFieldValue(haber, "co_partidas", "haber");
		haberME = AQUtil.roundFieldValue(haberME, "co_partidas", "haberme");
		totalHaber += parseFloat(haber);

		var curPartida:FLSqlCursor = new FLSqlCursor("co_partidas");
		with (curPartida) {
			setModeAccess(curPartida.Insert);
			refreshBuffer();
			setValueBuffer("idsubcuenta", ctaVentas.idsubcuenta);
			setValueBuffer("codsubcuenta", ctaVentas.codsubcuenta);
			setValueBuffer("idasiento", idAsiento);
			setValueBuffer("debe", 0);
			setValueBuffer("haber", haber);
			setValueBuffer("coddivisa", curFactura.valueBuffer("coddivisa"));
			setValueBuffer("tasaconv", curFactura.valueBuffer("tasaconv"));
			setValueBuffer("debeME", 0);
			setValueBuffer("haberME", haberME);
			if (codActivo && codActivo != "") {
				setValueBuffer("codactivo", codActivo);
			}
		}
			
		this.iface.datosPartidaFactura(curPartida, curFactura, "cliente")
	
		if (!curPartida.commitBuffer()) {
debug("euromoda_generarPartidasVentaEM 2");
			return false;
		}
		idUltimaPartida = curPartida.valueBuffer("idpartida");
		iSubcuenta++;
		
		if (codActivo && codActivo != "") {
			if (!AQUtil.sqlSelect("co_amortizaciones", "codamortizacion", "codamortizacion = '" + codActivo + "' AND ((NOT vendido AND idfacturaventa IS NULL) OR (vendido AND idfacturaventa = " + idFactura + "))")) {
				MessageBox.warning(sys.translate("El activo %1 est� marcado como vendido o tiene ya una factura de venta asociada").arg(codActivo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
				return false;
			}
			var curA = new FLSqlCursor("co_amortizaciones");
// 			curA.setActivatedCommitActions(false);
			curA.select("codamortizacion = '" + codActivo + "'");
			if (!curA.first()) {
				return false;
			}
			curA.setModeAccess(curA.Edit);
			curA.refreshBuffer();
			var estado = curA.valueBuffer("estado");
			if (estado != "Terminada") {
				res = MessageBox.warning(sys.translate("Se cerrar� la amortizaci�n del activo %1.\n�Est� seguro?").arg(codActivo), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
				if (res != MessageBox.Yes) {
					return false;
				}
				curA.setValueBuffer("fechacierre", curFactura.valueBuffer("fecha"));
				curA.setValueBuffer("estado", "Cerrada");
			}
			curA.setValueBuffer("vendido", true);
			curA.setValueBuffer("idfacturaventa", idFactura);
			if (!curA.commitBuffer()) {
				return false;
			}
			
			
// 			if (AQSql.update("co_amortizaciones", ["vendido", "idfacturaventa"], ["true", idFactura], "codamortizacion = '" + codActivo + "'")) {
// debug("Falla update");
// 				return false;
// 			}
		}
	}

	/** \C En los asientos de factura de cliente, y en el caso de que se use moneda extranjera, la �ltima partida de compras tiene un saldo tal que haga que el asiento cuadre perfectamente. Esto evita errores de redondeo de conversi�n de moneda entre las partidas del asiento.
	\end */
// 	if (!monedaSistema) {
// 		haber = AQUtil.sqlSelect("co_partidas", "SUM(debe - haber)", "idasiento = " + idAsiento + " AND idpartida <> " + idUltimaPartida);
// 		if (!haber) {
// 			return false;
// 		}
// 		if (!AQSql.update("co_partidas", ["haber"], [haber], "idpartida = " + idUltimaPartida)) {
// 			return false;
// 		}
// 	}
debug("euromoda_generarPartidasVentaEM OK");
	return true;
}

function euromoda_generarPartidasCompra(curFactura, idAsiento, valoresDefecto)
{
  var _i = this.iface;
  if (!_i.generarPartidasCompraEM(curFactura, idAsiento, valoresDefecto)) {
    return false;
  }
  if (!_i.generarPartidasDtoEspProv(curFactura, idAsiento, valoresDefecto)) {
    return false;
  }
	return true;
}

function euromoda_generarPartidasCompraEM(curFactura, idAsiento, valoresDefecto)
{
  var ctaVentas = [];
	var monedaSistema = (valoresDefecto.coddivisa == curFactura.valueBuffer("coddivisa"));
	var debe = 0;
	var debeME = 0;
	var idUltimaPartida = 0;

	var idFactura = curFactura.valueBuffer("idfactura");
	var codProveedor = curFactura.valueBuffer("codproveedor");
	var codGrupoNegocio = AQUtil.sqlSelect("proveedores", "codgrupocontableneg", "codproveedor = '" + codProveedor + "'");
	var qrySubcuentas = new FLSqlQuery();
	with (qrySubcuentas) {
		setTablesList("lineasfacturasprov,articulos");
		setSelect("l.codsubcuenta, a.codgrupocontablepro, l.codamortizacion, SUM(l.pvptotal)");
		setFrom("lineasfacturasprov l LEFT OUTER JOIN articulos a ON l.referencia = a.referencia");
		setWhere("idfactura = " + idFactura + " AND tipoconcepto <> 'Texto' GROUP BY l.codsubcuenta, a.codgrupocontablepro, l.codamortizacion");
	}
	if (!qrySubcuentas.exec()) {
		return false;
	}
	var neto = curFactura.valueBuffer("neto");
	//neto = AQUtil.roundFieldValue(neto, "facturascli", "neto");
	var iSubcuenta = 1;
	var totalDebe = 0;
	valoresDefecto.ctaVentasCompras = false;
	var codSubcuenta, hayCtaVentasCompras = false;
	valoresDefecto.ctaVentasCompras = false;

	var codActivo;
	while (qrySubcuentas.next()) {
		codActivo = qrySubcuentas.value("l.codamortizacion");
		codSubcuenta = qrySubcuentas.value("l.codsubcuenta");
		if (codSubcuenta && codSubcuenta != "") {
			ctaVentas.codsubcuenta = codSubcuenta;
		} else {
			ctaVentas.codgrupoprod = qrySubcuentas.value("a.codgrupocontablepro");
			ctaVentas.codgrupoprod = qrySubcuentas.value("a.codgrupocontablepro");
			if (curFactura.valueBuffer("deabono")) {
				ctaVentas.codsubcuenta = AQUtil.sqlSelect("gruposcontablesproneg", "codsubcuentadcom", "codgrupocontablepro = '" + ctaVentas.codgrupoprod + "' AND codgrupocontableneg = '" + codGrupoNegocio + "'");
			} else {
				ctaVentas.codsubcuenta = AQUtil.sqlSelect("gruposcontablesproneg", "codsubcuentacom", "codgrupocontablepro = '" + ctaVentas.codgrupoprod + "' AND codgrupocontableneg = '" + codGrupoNegocio + "'");
			}
			if (!ctaVentas.codsubcuenta) {
				MessageBox.warning(sys.translate("No se ha definido ninguna subcuenta para el grupo de producto %1 y el grupo de negocio %2.\nPara poder crear la factura debe crear antes esta subcuenta").arg(ctaVentas.codgrupoprod).arg(codGrupoNegocio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
			}
		}
		ctaVentas.idsubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + ctaVentas.codsubcuenta + "' AND codejercicio = '" + valoresDefecto.codejercicio + "'");
		if (!ctaVentas.idsubcuenta) {
			MessageBox.warning(sys.translate("No existe la subcuenta %1 correspondiente al ejercicio %2.\nPara poder crear la factura debe crear antes esta subcuenta").arg(ctaVentas.codsubcuenta).arg(valoresDefecto.codejercicio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		/// S�lo consideramos una cta de ventas para luego poder usarla en el dto p.p.
		if (!hayCtaVentasCompras) {
			hayCtaVentasCompras = true;
			valoresDefecto.ctaVentasCompras = ctaVentas;
		}

		if (monedaSistema) {
			debe = parseFloat(qrySubcuentas.value("SUM(l.pvptotal)"));
			debeME = 0;
		} else {
			debe = parseFloat(qrySubcuentas.value("SUM(l.pvptotal)")) * parseFloat(curFactura.valueBuffer("tasaconv"));
			debeME = parseFloat(qrySubcuentas.value("SUM(l.pvptotal)"));
		}
		debe = AQUtil.roundFieldValue(debe, "co_partidas", "debe");
		debeME = AQUtil.roundFieldValue(debeME, "co_partidas", "debeme");
		totalDebe += parseFloat(debe);

		var curPartida:FLSqlCursor = new FLSqlCursor("co_partidas");
		with (curPartida) {
			setModeAccess(curPartida.Insert);
			refreshBuffer();
			setValueBuffer("idsubcuenta", ctaVentas.idsubcuenta);
			setValueBuffer("codsubcuenta", ctaVentas.codsubcuenta);
			setValueBuffer("idasiento", idAsiento);
			setValueBuffer("debe", debe);
			setValueBuffer("haber", 0);
			setValueBuffer("coddivisa", curFactura.valueBuffer("coddivisa"));
			setValueBuffer("tasaconv", curFactura.valueBuffer("tasaconv"));
			setValueBuffer("debeME", debeME);
			setValueBuffer("haberME", 0);
			if (codActivo && codActivo != "") {
				setValueBuffer("codactivo", codActivo);
			}
		}
			
		this.iface.datosPartidaFactura(curPartida, curFactura, "proveedor")
	
		if (!curPartida.commitBuffer()) {
			return false;
		}
		
// 		if (codActivo && codActivo != "") {
// 			if (!AQUtil.sqlSelect("co_amortizaciones", "codamortizacion", "codamortizacion = '" + codActivo + "' AND ((NOT comprado AND idfacturacompra IS NULL) OR (comprado AND idfacturacompra = " + idFactura + "))")) {
// 				MessageBox.warning(sys.translate("El activo %1 est� marcado como comprado o tiene ya una factura de compra asociada").arg(codActivo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
// 				return false;
// 			}
// 			var curA = new FLSqlCursor("co_amortizaciones");
// // 			curA.setActivatedCommitActions(false);
// 			curA.select("codamortizacion = '" + codActivo + "'");
// 			if (!curA.first()) {
// 				return false;
// 			}
// 			curA.setModeAccess(curA.Edit);
// 			curA.refreshBuffer();
// 			curA.setValueBuffer("comprado", true);
// 			curA.setValueBuffer("idfacturacompra", idFactura);
// 			if (!curA.commitBuffer()) {
// 				return false;
// 			}
// 			
// 			
// // 			if (AQSql.update("co_amortizaciones", ["vendido", "idfacturaventa"], ["true", idFactura], "codamortizacion = '" + codActivo + "'")) {
// // debug("Falla update");
// // 				return false;
// // 			}
// 		}
		
		idUltimaPartida = curPartida.valueBuffer("idpartida");
		iSubcuenta++;
	}

	/** \C En los asientos de factura de cliente, y en el caso de que se use moneda extranjera, la �ltima partida de compras tiene un saldo tal que haga que el asiento cuadre perfectamente. Esto evita errores de redondeo de conversi�n de moneda entre las partidas del asiento.
	\end */
// 	if (!monedaSistema) {
// 		debe = AQUtil.sqlSelect("co_partidas", "SUM(haber - debe)", "idasiento = " + idAsiento + " AND idpartida <> " + idUltimaPartida);
// 		if (!debe) {
// 			return false;
// 		}
// 		if (!AQSql.update("co_partidas", ["debe"], [debe], "idpartida = " + idUltimaPartida)) {
// 			return false;
// 		}
// 	}

	return true;
}

function euromoda_datosCtaDto(valoresDefecto, curFactura, idAsiento)
{
	debug("euromoda_datosCtaDto");
	var datos;
	if (valoresDefecto.ctaVentasCompras) {
debug("euromoda_datosCtaDto hay");
		datos = valoresDefecto.ctaVentasCompras;
		datos.error = 0;
	} else {
debug("euromoda_datosCtaDto no hay");
		datos = new Object;
		datos.error = 1;
	}
	return datos;
}

function euromoda_asientoFacturaAbonoCli(curFactura, valoresDefecto)
{
	var idAsiento:String  = curFactura.valueBuffer("idasiento").toString();
  var idFactura:String = curFactura.valueBuffer("idfactura");
	var curPartidas:FLSqlCursor = new FLSqlCursor("co_partidas");
	var debe:Number = 0;
	var haber:Number = 0;
	var debeME:Number = 0;
	var haberME:Number = 0;
	var aux:Number;
	var util:FLUtil = new FLUtil;
	
	curPartidas.select("idasiento = '" + idAsiento + "'");
	while (curPartidas.next()) {
		curPartidas.setModeAccess(curPartidas.Edit);
		curPartidas.refreshBuffer();
		debe = parseFloat(curPartidas.valueBuffer("debe"));
		haber = parseFloat(curPartidas.valueBuffer("haber"));
		debeME = parseFloat(curPartidas.valueBuffer("debeme"));
		haberME = parseFloat(curPartidas.valueBuffer("haberme"));
		if (debe > 0 || haber > 0) {
			continue;
		}
		aux = debe;
		debe = haber * -1;
		haber = aux * -1;
		aux = debeME;
		debeME = haberME * -1;
		haberME = aux * -1;
		debe = util.roundFieldValue(debe, "co_partidas", "debe");
		haber = util.roundFieldValue(haber, "co_partidas", "haber");
		debeME = util.roundFieldValue(debeME, "co_partidas", "debeme");
		haberME = util.roundFieldValue(haberME, "co_partidas", "haberme");

		curPartidas.setValueBuffer("debe",  debe);
		curPartidas.setValueBuffer("haber", haber);
		curPartidas.setValueBuffer("debeme",  debeME);
		curPartidas.setValueBuffer("haberme", haberME);

		if (!curPartidas.commitBuffer()) {
			return false;
		}
	}

	return true;
}

function euromoda_asientoFacturaAbonoProv(curFactura, valoresDefecto)
{
	var idAsiento:String  = curFactura.valueBuffer("idasiento").toString();
  var idFactura:String = curFactura.valueBuffer("idfactura");
	var curPartidas:FLSqlCursor = new FLSqlCursor("co_partidas");
	var debe:Number = 0;
	var haber:Number = 0;
	var debeME:Number = 0;
	var haberME:Number = 0;
	var aux:Number;
	var util:FLUtil = new FLUtil;
	
	curPartidas.select("idasiento = '" + idAsiento + "'");
	while (curPartidas.next()) {
		curPartidas.setModeAccess(curPartidas.Edit);
		curPartidas.refreshBuffer();
		debe = parseFloat(curPartidas.valueBuffer("debe"));
		haber = parseFloat(curPartidas.valueBuffer("haber"));
		debeME = parseFloat(curPartidas.valueBuffer("debeme"));
		haberME = parseFloat(curPartidas.valueBuffer("haberme"));
		if (debe > 0 || haber > 0) {
			continue;
		}
		aux = debe;
		debe = haber * -1;
		haber = aux * -1;
		aux = debeME;
		debeME = haberME * -1;
		haberME = aux * -1;
		debe = util.roundFieldValue(debe, "co_partidas", "debe");
		haber = util.roundFieldValue(haber, "co_partidas", "haber");
		debeME = util.roundFieldValue(debeME, "co_partidas", "debeme");
		haberME = util.roundFieldValue(haberME, "co_partidas", "haberme");

		curPartidas.setValueBuffer("debe",  debe);
		curPartidas.setValueBuffer("haber", haber);
		curPartidas.setValueBuffer("debeme",  debeME);
		curPartidas.setValueBuffer("haberme", haberME);

		if (!curPartidas.commitBuffer()) {
			return false;
		}
	}

	return true;
}

function euromoda_controlBloqueoCliente(codCliente, tipoControl)
{
	if (!codCliente || codCliente == "" || codCliente.length != 6) {
		return true;
	}
  var bC = AQUtil.sqlSelect("clientes", "bloqueado", "codcliente = '" + codCliente + "'");
  if (!bC || bC == "No") {
    return true;
  }
  var res;
  if (bC == "Todo") {
  	sys.warnMsgBox(sys.translate("El cliente %1 est� bloqueado para TODO\nConsulte con administraci�n ").arg(codCliente));
  	return false;
  	/* A petici�n de J.Ruiz
    res = MessageBox.warning(sys.translate("El cliente %1 est� bloqueado.\n�Desea continuar?").arg(codCliente), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
    if (res != MessageBox.Yes) {
      return false;
    } else {
       return true;
     }
     */
  }
  switch (tipoControl) {
  case "Facturar": {
      if (bC == "Facturar") {
        res = MessageBox.warning(sys.translate("El cliente %1 est� bloqueado para facturaci�n.\n�Desea continuar?").arg(codCliente), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
        if (res != MessageBox.Yes) {
          return false;
        }
      }
      break;
    }
  case "Enviar": {
      if (bC == "Enviar") {
        res = MessageBox.warning(sys.translate("El cliente %1 est� bloqueado para env�o.\n�Desea continuar?").arg(codCliente), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
        if (res != MessageBox.Yes) {
          return false;
        }
      }
      break;
    }
  }
  return true;
}

function euromoda_controlBloqueoProveedor(codProveedor, tipoControl)
{
  var bC = AQUtil.sqlSelect("proveedores", "bloqueado", "codproveedor = '" + codProveedor + "'");
  if (!bC || bC == "No") {
    return true;
  }
  var res;
  if (bC == "Todo") {
    res = MessageBox.warning(sys.translate("El proveedor %1 est� bloqueado.\n�Desea continuar?").arg(codProveedor), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
    if (res != MessageBox.Yes) {
      return false;
    } else {
       return true;
     }
  }
  switch (tipoControl) {
  case "Pago": {
      if (bC == "Pago") {
        res = MessageBox.warning(sys.translate("El proveedor %1 est� bloqueado para pago.\n�Desea continuar?").arg(codProveedor), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
        if (res != MessageBox.Yes) {
          return false;
        }
      }
      break;
    }
  }
  return true;
}

function euromoda_controlRiesgoCliente(codCliente, preguntar)
{
  var curC = new FLSqlCursor("clientes");
  curC.select("codcliente = '" + codCliente + "'");
  if (!curC.first()) {
    return true;
  }
  if (curC.isNull("riesgomax")) {
    return true;
  }
  curC.setModeAccess(curC.Browse);
  curC.refreshBuffer();
  var riesgo = parseFloat(curC.valueBuffer("riesgoalcanzado"));
  riesgo = isNaN(riesgo) ? 0 : riesgo;
  var riesgoMax = parseFloat(curC.valueBuffer("riesgomax"))
  if (riesgo > riesgoMax) {
    var sR = AQUtil.roundFieldValue(riesgo, "clientes", "riesgoalcanzado");
    var sRMax = AQUtil.roundFieldValue(riesgoMax, "clientes", "riesgoalcanzado");
    var msg = sys.translate("El riesgo cliente %1, %2, ha superado su riesgo m�ximo de %3.").arg(codCliente).arg(sR).arg(sRMax);
    if (preguntar) {
      var res = MessageBox.warning(msg + "\n" + sys.translate("�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
      if (res != MessageBox.Yes) {
        return false;
      }
    } else {
      MessageBox.warning(msg, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    }
  }
  return true;
}

function euromoda_avisarObservacionesCliente(codCliente)
{
  var _i = this.iface;
  if (!codCliente || codCliente == "") {
    return true;
  }
  var bC = AQUtil.sqlSelect("clientes", "bloqueado", "codcliente = '" + codCliente + "'");
  if (bC == "Todo") {
    MessageBox.warning(sys.translate("Aviso: El cliente %1 est� bloqueado").arg(codCliente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
  }
  _i.__avisarObservacionesCliente(codCliente);
  return true;
}

function euromoda_afterCommit_facturascli(curF)
{
  var _i = this.iface;
  if (!_i.validaFechaFacturaCli(curF)) {
    return false;
  }
  if (!_i.__afterCommit_facturascli(curF)) {
    return false;
  }
  if (!_i.controlUltimaFacturaCli(curF)) {
    return false;
  }
  return true;
}

function euromoda_controlUltimaFacturaCli(curF)
{
  var codCliente = curF.valueBuffer("codcliente");
  if (!codCliente || codCliente == "") {
    return true;
  }
  //#bloqueo facturas por serie
	var numero = curF.valueBuffer("numero");
	if(numero.left(1) == "#") {
		return true;
	}
  // fin #bloqueo facturas por serie
  var f = AQUtil.sqlSelect("facturascli", "fecha", "codcliente = '" + codCliente + "' ORDER BY fecha DESC");
  //var curC = new FLSqlCursor("clientes");
  //curC.setActivatedCommitActions(false);
  //if (!AQSql.update(curC, ["fechaultfactura"], [f], "codcliente = '"  + codCliente + "'")) {
  if (!AQSql.update("clientes", ["fechaultfactura"], [f], "codcliente = '"  + codCliente + "'")) {   
    return false;
  }
  return true;
}

function euromoda_comprobarFacturaAbonoCli(curFactura)
{
	var util:FLUtil = new FLUtil();
	if (curFactura.valueBuffer("deabono") == true) {
		var idFacturaRect = curFactura.valueBuffer("idfacturarect");
		if (!idFacturaRect) {
			sys.warnMsgBox(sys.translate("Debe seleccionar la factura que desea rectificar"));
			return false;
		}	

		var codFacturaB = util.sqlSelect("facturascli", "codigo", "idfacturarect = " + idFacturaRect + " AND idfactura <> " + curFactura.valueBuffer("idfactura"));
		if (codFacturaB) {
			var codFacturaA = util.sqlSelect("facturascli", "codigo", "idfactura = " + idFacturaRect);
			var res = MessageBox.warning(util.translate("scripts", "La factura %1 ya est� rectificada en la factura %2. �Desea continuar?").arg(codFacturaA).arg(codFacturaB), MessageBox.Yes, MessageBox.No);
			if (res != MessageBox.Yes) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_comprobarFacturaAbonoProv(curFactura)
{
	var util:FLUtil = new FLUtil();
	if (curFactura.valueBuffer("deabono") == true) {
		var idFacturaRect = curFactura.valueBuffer("idfacturarect");
		if (!idFacturaRect) {
			return true;
		}
		var codFacturaB = util.sqlSelect("facturasprov", "codigo", "idfacturarect = " + idFacturaRect + " AND idfactura <> " + curFactura.valueBuffer("idfactura"));
		if (codFacturaB) {
			var codFacturaA = util.sqlSelect("facturasprov", "codigo", "idfactura = " + idFacturaRect);
			var res = MessageBox.warning(util.translate("scripts", "La factura %1 ya est� rectificada en la factura %2. �Desea continuar?").arg(codFacturaA).arg(codFacturaB), MessageBox.Yes, MessageBox.No);
			if (res != MessageBox.Yes) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_beforeCommit_facturascli(curF)
{
  var _i = this.iface;
  //#bloqueo facturas por serie
  if(!_i.controlFacturasBloqSerie(curF)) {
  	return false;
  }
  		
  //fin bloqueo facturas por serie
  if (!_i.__beforeCommit_facturascli(curF)) {
    return false;
  }
//   if (!_i.validaFechaFacturaCli(curF)) {
//     return false;
//   }
  return true;
}


function euromoda_beforeCommit_lineasfacturascli(curLF)
{
    var _i = this.iface;
    if (!_i.__beforeCommit_lineasfacturascli(curLF)) {
        return false;
    }
    if (!_i.controlBorradoActivoFacturacli(curLF)) {
        return false;
    }
    return true;
}

function euromoda_controlBorradoActivoFacturacli(curLF)
{
    var _i = this.iface;
    if (curLF.modeAccess() != curLF.Del) {
        return true;
    }
    if (curLF.isNull("codamortizacion")) {
        return true;
    }
    var codActivo = curLF.valueBuffer("codamortizacion");
    if (!codActivo || codActivo == "") {
        return true;
    }
    var idFacturaVenta = AQUtil.sqlSelect("co_amortizaciones", "idfacturaventa", "codamortizacion = '" + codActivo + "'");
    if (idFacturaVenta == curLF.valueBuffer("idfactura")) {
        sys.warnMsgBox(sys.translate("La l�nea de factura a borrar est� ligada con el activo %1.\nAntes de borrarla debe desmarcar el indicador de Vendida en el activo, y reabrir si es necesario su amortizaci�n eliminando el asiento de cierre.\nPuede realizar estas acciones en la ventana de edici�n de amortizaciones").arg(codActivo));
        return false;
    }
    
    return true;
}

function euromoda_validaFechaFacturaCli(curF)
{	
  var cursor = curF;
  var codEjercicio = cursor.valueBuffer("codejercicio");
  var codSerie = cursor.valueBuffer("codserie");
  var fecha = cursor.valueBuffer("fecha");
  var codigo = cursor.valueBuffer("codigo");
  var numero = cursor.valueBuffer("numero");

  debug("codEjercicio: "+codEjercicio);
  debug("codSerie: "+codSerie);
  debug("fecha: "+fecha);
  debug("codigo: "+codigo);
	debug("numero: "+numero);
  
 //#bloqueo facturas por serie
  if(numero.left(1) == "#") {
  	return true;
  }
  //fin #bloqueo facturas por serie
  var fechaAnt = AQUtil.sqlSelect("facturascli", "fecha", "codejercicio = '" + codEjercicio + "' AND codserie = '" + codSerie + "' AND codigo < '" + codigo + "' ORDER BY codigo DESC"); 
  if (fechaAnt && AQUtil.daysTo(fechaAnt, fecha) < 0) {
    MessageBox.warning(sys.translate("La fecha de la factura es menor que la fecha de la factura anterior para esta serie de facturaci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
   debug("fechaAnt: "+fechaAnt);

  var fechaSig = AQUtil.sqlSelect("facturascli", "fecha", "codejercicio = '" + codEjercicio + "' AND codserie = '" + codSerie + "' AND codigo > '" + codigo + "'  ORDER BY codigo ASC");
	if (cursor.modeAccess() == cursor.Del && fechaSig) {
		MessageBox.warning(sys.translate("No puede borrar la factura. Hay otras facturas posteriores con el mismo ejercicio y serie"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
	}
	debug("fechaSig: "+fechaSig);
  if (fechaSig && AQUtil.daysTo(fechaSig, fecha) > 0) {
    MessageBox.warning(sys.translate("La fecha de la factura es mayor que la fecha de la factura siguiente para esta serie de facturaci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  

  var otroCod = AQUtil.sqlSelect("facturascli", "idfactura", "codejercicio = '" + codEjercicio + "' AND codserie = '" + codSerie + "' AND codigo = '" + codigo + "' AND idfactura <> " + curF.valueBuffer("idfactura"));
  debug("otroCod: "+otroCod);
  
  
	if (otroCod) {
		MessageBox.warning(sys.translate("Hay ya otra factura con el c�digo %1").arg(codigo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
	}
                       
  return true;
}

function euromoda_beforeCommit_facturasprov(curF)
{
  var _i = this.iface;
  if (!_i.__beforeCommit_facturasprov(curF)) {
    return false;
  }
  if (!_i.validaFechaFacturaProv(curF)) {
    return false;
  }
  return true;
}

function euromoda_validaFechaFacturaProv(curF)
{
  var cursor = curF;
  var codEjercicio = cursor.valueBuffer("codejercicio");
  var codSerie = cursor.valueBuffer("codserie");
  var fecha = cursor.valueBuffer("fecha");
  var codigo = cursor.valueBuffer("codigo");
  var numero = cursor.valueBuffer("numero");
  
  var fechaAnt = AQUtil.sqlSelect("facturasprov", "fecha", "codejercicio = '" + codEjercicio + "' AND codserie = '" + codSerie + "' AND codigo < '" + codigo + "' ORDER BY codigo DESC");
  if (fechaAnt && AQUtil.daysTo(fechaAnt, fecha) < 0) {
    MessageBox.warning(sys.translate("La fecha de la factura es menor que la fecha de la factura anterior para esta serie de facturaci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }

  var fechaSig = AQUtil.sqlSelect("facturasprov", "fecha", "codejercicio = '" + codEjercicio + "' AND codserie = '" + codSerie + "' AND codigo > '" + codigo + "'  ORDER BY codigo ASC");
	if (cursor.modeAccess() == cursor.Del && fechaSig) {
		MessageBox.warning(sys.translate("No puede borrar la factura. Hay otras facturas posteriores con el mismo ejercicio y serie"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
	}
  if (fechaSig && AQUtil.daysTo(fechaSig, fecha) > 0) {
    MessageBox.warning(sys.translate("La fecha de la factura es mayor que la fecha de la factura siguiente para esta serie de facturaci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
                       
  return true;
}

/// A�ade informaci�n en el campo codcliente
function euromoda_generarPartidasCliente(curFactura, idAsiento, valoresDefecto, ctaCliente)
{
		var util:FLUtil = new FLUtil();
		var debe:Number = 0;
		var debeME:Number = 0;
		var monedaSistema:Boolean = (valoresDefecto.coddivisa == curFactura.valueBuffer("coddivisa"));
		if (monedaSistema) {
				debe = parseFloat(curFactura.valueBuffer("total"));
				debeME = 0;
		} else {
				debe = parseFloat(curFactura.valueBuffer("total")) * parseFloat(curFactura.valueBuffer("tasaconv"));
				debeME = parseFloat(curFactura.valueBuffer("total"));
		}
		debe = util.roundFieldValue(debe, "co_partidas", "debe");
		debeME = util.roundFieldValue(debeME, "co_partidas", "debeme");
		
		var curPartida:FLSqlCursor = new FLSqlCursor("co_partidas");

		with (curPartida) {
				setModeAccess(curPartida.Insert);
				refreshBuffer();
				setValueBuffer("idsubcuenta", ctaCliente.idsubcuenta);
				setValueBuffer("codsubcuenta", ctaCliente.codsubcuenta);
				setValueBuffer("idasiento", idAsiento);
				setValueBuffer("debe", debe);
				setValueBuffer("haber", 0);
				setValueBuffer("coddivisa", curFactura.valueBuffer("coddivisa"));
				setValueBuffer("tasaconv", curFactura.valueBuffer("tasaconv"));
				setValueBuffer("debeME", debeME);
				setValueBuffer("haberME", 0);
				setValueBuffer("codcliente", curFactura.valueBuffer("codcliente"));
		}
		
		this.iface.datosPartidaFactura(curPartida, curFactura, "cliente")
		
		if (!curPartida.commitBuffer())
				return false;

		return true;
}

/// A�ade informaci�n en el campo codproveedor
function euromoda_generarPartidasProveedor(curFactura, idAsiento, valoresDefecto, ctaProveedor, concepto, sinIVA)
{
	var util:FLUtil = new FLUtil;
	var haber:Number = 0;
	var haberME:Number = 0;
	var totalIVA:Number = 0;
	
	if (sinIVA) {
		totalIVA = parseFloat(curFactura.valueBuffer("totaliva"));
	}
	var monedaSistema:Boolean = (valoresDefecto.coddivisa == curFactura.valueBuffer("coddivisa"));
	if (monedaSistema) {
		haber = parseFloat(curFactura.valueBuffer("total"));
		haber -= totalIVA;
		haberME = 0;
	} else {
		haber = (parseFloat(curFactura.valueBuffer("total")) - totalIVA) * parseFloat(curFactura.valueBuffer("tasaconv"));
		haberME = parseFloat(curFactura.valueBuffer("total"));
	}
	haber = util.roundFieldValue(haber, "co_partidas", "haber");
	haberME = util.roundFieldValue(haberME, "co_partidas", "haberme");

	var curPartida:FLSqlCursor = new FLSqlCursor("co_partidas");
	with (curPartida) {
		setModeAccess(curPartida.Insert);
		refreshBuffer();
		setValueBuffer("idsubcuenta", ctaProveedor.idsubcuenta);
		setValueBuffer("codsubcuenta", ctaProveedor.codsubcuenta);
		setValueBuffer("idasiento", idAsiento);
		setValueBuffer("debe", 0);
		setValueBuffer("haber", haber);
		setValueBuffer("coddivisa", curFactura.valueBuffer("coddivisa"));
		setValueBuffer("tasaconv", curFactura.valueBuffer("tasaconv"));
		setValueBuffer("debeME", 0);
		setValueBuffer("haberME", haberME);
		setValueBuffer("codproveedor", curFactura.valueBuffer("codproveedor"));
	}
	
	this.iface.datosPartidaFactura(curPartida, curFactura, "proveedor", concepto);
	
	if (!curPartida.commitBuffer()) {
		return false;
	}
	return true;
}

/// Si es una partida de registro de IVA se informa el cliente / proveedor de su contrapartida
function euromoda_datosPartidaFactura(curPartida, curFactura, tipo, concepto)
{
	var _i = this.iface;
	_i.__datosPartidaFactura(curPartida, curFactura, tipo, concepto);
	if (!curPartida.isNull("codimpuesto")) {
		if (tipo == "cliente") {
			curPartida.setValueBuffer("codclientecontra", curFactura.valueBuffer("codcliente"));
		} else {
			if (curPartida.isNull("codproveedorcontra")) { /// Puede tratarse de una factura de transitario ya informada
				curPartida.setValueBuffer("codproveedorcontra", curFactura.valueBuffer("codproveedor"));
			}
		}
	}
	return true;
}

function euromoda_datosPartidaIVAFacturaImport(curPartida, curFactura, tipo, concepto, curFacturaImport)
{
	var _i = this.iface;
	if (!_i.__datosPartidaIVAFacturaImport(curPartida, curFactura, tipo, concepto, curFacturaImport)) {
		return false;
	}
	var refIvaImport = flfactalma.iface.pub_valorDefectoAlmacen("refivaimport");
	var codProveedor;
	var codGrupoIvaNeg;
	if (curFacturaImport) {
		codProveedor = curFacturaImport.valueBuffer("codproveedor");
		curPartida.setValueBuffer("codproveedorcontra", codProveedor);
		codGrupoIvaNeg = curFacturaImport.valueBuffer("codgrupoivaneg");
	} else {
		codProveedor = curFactura.valueBuffer("codproveedor");
		curPartida.setValueBuffer("codproveedorcontra", codProveedor);
		codGrupoIvaNeg = curFactura.valueBuffer("codgrupoivaneg");
	}
	curPartida.setValueBuffer("factura", curFactura.valueBuffer("numero"));

	// aqui habr�a que ir a la factura que hemos seleccionado y porner el grupo de iva de negocio de esta factura 25-02-2021
	//curPartida.setValueBuffer("codgrupoivaneg", AQUtil.sqlSelect("proveedores", "codgrupoivaneg", "codproveedor = '" + codProveedor + "'"));
	curPartida.setValueBuffer("codgrupoivaneg", codGrupoIvaNeg);


	/// Se toma el IVA de la factura y no del art�culo porque puede darse el caso de un IVA total BI (Bienes de inversi�n), distinto del IVA total normal asociado al art�culo
	curPartida.setValueBuffer("codimpuesto", AQUtil.sqlSelect("lineasfacturasprov", "codimpuesto", "idfactura = " + curFactura.valueBuffer("idfactura") + " AND referencia = '" + refIvaImport + "'"));
	return true;
}

function euromoda_validaIvaLinea(cursor)
{
	var tipoConcepto = cursor.valueBuffer("tipoconcepto");
	if (tipoConcepto == "Texto") {
		return true;
	}
	var codImpuesto = cursor.valueBuffer("codimpuesto");
	if (!codImpuesto || codImpuesto == "") {
		MessageBox.warning(sys.translate("Debe indicar un c�digo de I.V.A."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var iva = cursor.valueBuffer("iva");
debug("IVA ? " + iva);
debug("nulo " + cursor.isNull("iva"));
debug("vac�o" + (iva == ""));
	if (cursor.isNull("iva") || isNaN(iva)) {
debug("aqu�");
		MessageBox.warning(sys.translate("Debe indicar el porcentaje de I.V.A."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function euromoda_comprobarCambioSerie(cursor)
{
	var _i = this.iface;
	if (cursor.valueBufferCopy("codserie") == "Z") {
		return true;
	}
	return _i.__comprobarCambioSerie(cursor);
}

function euromoda_afterCommit_lineasfacturasprov(curLF)
{
debug("euromoda_afterCommit_lineasfacturasprov");
	var _i = this.iface;
	if (!_i.__afterCommit_lineasfacturasprov(curLF)) {
		return false;
	}
	if (!_i.controlValorActivo(curLF)) {
		return false;
	}
	var referencia = curLF.valueBuffer("referencia");	
	if (!flfactalma.iface.pub_actualizarDatosUltCompra(referencia)) {
		return false;
	}
	if(!_i.actualizarDatosUltCompraFraAlm(curLF)) {
		return false;
	}
	return true;
}

function euromoda_controlValorActivo(curLF)
{
	var _i = this.iface;
	var codActivo = curLF.valueBuffer("codamortizacion");
	switch (curLF.modeAccess()) {
		case curLF.Insert:
		case curLF.Del: {
			if (codActivo) {
				if (!_i.actualizaValorActivo(codActivo)) {
					return false;
				}
			}
			break;
		}
		case curLF.Edit: {
			var codActivoCopy = curLF.valueBufferCopy("codamortizacion");
			if (codActivoCopy && codActivoCopy != codActivo) {
				if (!_i.actualizaValorActivo(codActivoCopy)) {
					return false;
				}
			}
			if (codActivo) {
				if (!_i.actualizaValorActivo(codActivo)) {
					return false;
				}
			}
			break;
		}
	}
	return true;
}

function euromoda_actualizaValorActivo(codActivo)
{
	var curA = new FLSqlCursor("co_amortizaciones");
	curA.select("codamortizacion = '" + codActivo + "'");
	if (!curA.first()) {
		MessageBox.warning(sys.translate("Error al actualizar el valor del activo.\nEl valor %1 no existe en la tabla de amortizaciones").arg(codActivo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	curA.setModeAccess(curA.Edit);
	curA.refreshBuffer();
	if (curA.valueBuffer("estado") != "Suspendida") {
		MessageBox.warning(sys.translate("Error al actualizar el valor del activo.\nLa amortizaci�n del activo %1 no est� en estado \"Suspendida\"").arg(codActivo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var fA = formRecordco_amortizaciones.iface;
	curA.setValueBuffer("valoradquisicion", fA.pub_commonCalculateField("valoradquisicion", curA));
	curA.setValueBuffer("valoramortizable", fA.pub_commonCalculateField("valoramortizable", curA));
	curA.setValueBuffer("pendiente", fA.pub_commonCalculateField("pendiente", curA));
	if (!curA.commitBuffer()) {
		return false;
	}
	return true;
}

function euromoda_gestionPedidoParcial(curPedido)
{
	var util:FLUtil;
	var _i = this.iface;

	var idAlbaran;
	if (curPedido.modeAccess() == curPedido.Edit && curPedido.action() == "em_pedidoscliparciales") {
		var curT = new FLSqlCursor("empresa");
		curT.transaction(false);
		try {
			idAlbaran = formpedidoscli.iface.pub_generarAlbaranParcial(curPedido);
			if (idAlbaran) {
				curT.commit();
			} else {
				curT.rollback();
				return false;
			}
		}
		catch (e) {
			curT.rollback();
			MessageBox.critical(util.translate("scripts", "Hubo un error en la generaci�n del albar�n"), MessageBox.Ok, MessageBox.NoButton);
			return false;
		}
	} else {
		idAlbaran = _i.__gestionPedidoParcial(curPedido);
	}
	return idAlbaran;
}

function euromoda_afterCommit_pedidosmarcocli(curPM)
{
debug("euromoda_afterCommit_pedidosmarcocli");
	var _i = this.iface;
	try {
		if (!_i.__afterCommit_pedidosmarcocli(curPM)) {
			return false;
		}
	} catch (e) {};
debug("euromoda_afterCommit_pedidosmarcocli 1");
	if (!_i.controlEstadoPedidoMarco(curPM)) {
		return false;
	}
debug("euromoda_afterCommit_pedidosmarcocli OK");
	return true;
}

function euromoda_controlEstadoPedidoMarco(curPM)
{
debug("euromoda_controlEstadoPedidoMarco");
	var _i = this.iface;
	if (curPM.modeAccess() == curPM.Edit && curPM.valueBuffer("emestado") != curPM.valueBufferCopy("emestado")) {
		var curL = new FLSqlCursor("lineaspedidomarcocli");
		curL.select("codpedidomarco = '" + curPM.valueBuffer("codpedidomarco") + "'");
		while (curL.next()) {
			curL.setModeAccess(curL.Edit);
			curL.refreshBuffer();
debug("euromoda_controlEstadoPedidoMarco " + curL.valueBuffer("referencia"));
			if (!flfactalma.iface.pub_controlStockPedidosMarcoCli(curL)) {
				return false;
			}
		}
	}
	return true;
}

/// Para la migraci�n de pedidos parciales
function euromoda_restarCantidadCli(idLineaPedido, idLineaAlbaran)
{
	var _i = this.iface;
	var cantidad = parseFloat(AQUtil.sqlSelect("lineasalbaranescli", "SUM(cantidad)", "idlineapedido = " + idLineaPedido + " AND idlinea <> " + idLineaAlbaran));
	if (isNaN(cantidad))
		cantidad = 0;

	var curLineaPedido = new FLSqlCursor("lineaspedidoscli");
	curLineaPedido.select("idlinea = " + idLineaPedido);
	if (curLineaPedido.first()) {
		curLineaPedido.setModeAccess(curLineaPedido.Edit);
		curLineaPedido.refreshBuffer();
		curLineaPedido.setValueBuffer("totalenalbaran", cantidad + parseFloat(curLineaPedido.valueBuffer("servidogit")));
		if (!curLineaPedido.commitBuffer()) {
			return false;
		}
	}
	return true;
}

function euromoda_restarCantidadProv(idLineaPedido, idLineaAlbaran)
{
	var _i = this.iface;
	var cantidad = parseFloat(AQUtil.sqlSelect("lineasalbaranesprov", "SUM(cantidad)", "idlineapedido = " + idLineaPedido + " AND idlinea <> " + idLineaAlbaran));
	if (isNaN(cantidad))
		cantidad = 0;

	var curLineaPedido = new FLSqlCursor("lineaspedidosprov");
	curLineaPedido.select("idlinea = " + idLineaPedido);
	if (curLineaPedido.first()) {
		curLineaPedido.setModeAccess(curLineaPedido.Edit);
		curLineaPedido.refreshBuffer();
		curLineaPedido.setValueBuffer("totalenalbaran", cantidad + parseFloat(curLineaPedido.valueBuffer("servidogit")));
		if (!curLineaPedido.commitBuffer()) {
			return false;
		}
	}
	return true;
}


function euromoda_sirveLineaPedidoCli(curLA)
{
	var _i = this.iface;
	
	var idLineaPedido = curLA.valueBuffer("idlineapedido");
	if (idLineaPedido == 0) {
		return true;
	}
	var idPedido = curLA.valueBuffer("idpedido");
	var referencia = curLA.valueBuffer("referencia");
	var idLineaAlbaran = curLA.valueBuffer("idlinea");
	var canAlbaran = curLA.valueBuffer("cantidad");
	
	if (idLineaPedido == 0) {
		return true;
	}
		
	var cantidadServida;
	var curLineaPedido = new FLSqlCursor("lineaspedidoscli");
	curLineaPedido.select("idlinea = " + idLineaPedido);
	curLineaPedido.setModeAccess(curLineaPedido.Edit);
	if (!curLineaPedido.first()) {
		return true;
	}

	var cantidadPedido = parseFloat(curLineaPedido.valueBuffer("cantidad"));
	var query = new FLSqlQuery();
	query.setTablesList("lineasalbaranescli");
	query.setSelect("SUM(cantidad)");
	query.setFrom("lineasalbaranescli");
	query.setWhere("idlineapedido = " + idLineaPedido + " AND idlinea <> " + idLineaAlbaran);
	if (!query.exec()) {
		return false;
	}
	if (query.next()) {
		var canOtros = parseFloat(query.value("SUM(cantidad)"));
		if (isNaN(canOtros)) {
			canOtros = 0;
		}
		cantidadServida = canOtros + parseFloat(canAlbaran);
	}
// 	if (cantidadServida > cantidadPedido) {
// 		cantidadServida = cantidadPedido;
// 	}
	cantidadServida += parseFloat(curLineaPedido.valueBuffer("servidogit"))
		
	curLineaPedido.setValueBuffer("totalenalbaran", cantidadServida);
	if (!curLineaPedido.commitBuffer()) {
		return false;
	}

	var codDropshipping = AQUtil.sqlSelect("pedidoscli", "em_coddropshipping", "idpedido = " + curLineaPedido.valueBuffer("idpedido"));

	if(codDropshipping && codDropshipping != ""){

		//if(!AQUtil.execSql("UPDATE em_cargadropshipping SET unidadesservidas = " + cantidad + " where coddropshipping = '" + codDropshipping + "' AND idlineapedido = " + curLineaPedido.valueBuffer("idlinea"))){
		if(!AQUtil.execSql("UPDATE em_cargadropshipping SET unidadesservidas = " + cantidadServida + " where coddropshipping = '" + codDropshipping + "' AND idlineapedido = " + curLineaPedido.valueBuffer("idlinea"))){
			return false;
		}

	}
	
	return true;
}

function euromoda_sirveLineaPedidoProv(curLA)
{
	var _i = this.iface;
	
	var idLineaPedido = curLA.valueBuffer("idlineapedido");
	if (idLineaPedido == 0) {
		return true;
	}
	var idPedido = curLA.valueBuffer("idpedido");
	var referencia = curLA.valueBuffer("referencia");
	var idLineaAlbaran = curLA.valueBuffer("idlinea");
	var canAlbaran = curLA.valueBuffer("cantidad");
	
	var cantidadServida;
	var curLineaPedido = new FLSqlCursor("lineaspedidosprov");
	curLineaPedido.select("idlinea = " + idLineaPedido);
	curLineaPedido.setModeAccess(curLineaPedido.Edit);
	if (!curLineaPedido.first()) {
		return true;
	}
	var cantidadPedido = parseFloat(curLineaPedido.valueBuffer("cantidad"));
	var query = new FLSqlQuery();
	query.setTablesList("lineasalbaranesprov");
	query.setSelect("SUM(cantidad)");
	query.setFrom("lineasalbaranesprov");
	query.setWhere("idlineapedido = " + idLineaPedido + " AND idlinea <> " + idLineaAlbaran);
	if (!query.exec()) {
		return false;
	}
	if (query.next()) {
		var canOtros = parseFloat(query.value("SUM(cantidad)"));
		if (isNaN(canOtros)) {
			canOtros = 0;
		}
		cantidadServida = canOtros + parseFloat(canAlbaran);
	}
// 	if (cantidadServida > cantidadPedido) {
// 		cantidadServida = cantidadPedido;
// 	}
	cantidadServida += parseFloat(curLineaPedido.valueBuffer("servidogit"))
	curLineaPedido.setValueBuffer("totalenalbaran", cantidadServida);
	if (!curLineaPedido.commitBuffer()) {
		return false;
	}
		
	return true;
}

function euromoda_liberarAlbaranesCli(idFactura)
{
	debug("euromoda_liberarAlbaranesCli");
	var _i = this.iface;
	
	if (!_i.__liberarAlbaranesCli(idFactura)) {
		return false;
	}
	debug("euromoda_liberarAlbaranesCli OK");
	var curPedidos = new FLSqlCursor("pedidoscli");
	curPedidos.select("idfactura = " + idFactura);
	while (curPedidos.next()) {
		if (!_i.liberarPedidoCli(curPedidos.valueBuffer("idpedido"))) {
			return false;
		}
	}
	debug("euromoda_liberarAlbaranesCli OK2");
	return true;
}

function euromoda_liberarPedidoCli(idPedido)
{
	var _i = this.iface;
	
	/// Puede estar bloqueado por estar albaranado
	if (!AQUtil.execSql("UPDATE pedidoscli SET idfactura = 0 WHERE idpedido = " + idPedido)) {
		return false;
	}
	return true;
}

function euromoda_afterCommit_pedidoscli(curPedido)
{
	var _i = this.iface;
	if (!_i.__afterCommit_pedidoscli(curPedido)) {
		return false;
	}
	/*var nombreBD = sys.nameBD(); lo parcheo, esto estaba puesto mientras no se terminaba CDB
	if(nombreBD == "pruebas" || nombreBD == "abanq_creaciones") {
		var idAlbaran = _i.gestionPedidoParcial(curPedido);
		if (!idAlbaran) {
			return false;
		}
	}*/
	
	if (!_i.controlFechaCliente(curPedido)) {
		return false;
	}
	
	if(curPedido.modeAccess() == curPedido.Del){
		var codDropshipping = curPedido.valueBuffer("em_coddropshipping");
		if(codDropshipping && codDropshipping != ""){
			if(!_i.totalizaDrop(codDropshipping)) {
				return false;
			}
		}
	}	
	return true;
}

function euromoda_controlFechaCliente(curPedido)
{
	if (curPedido.modeAccess() != curPedido.Edit) {
		return true;
	}
	if (curPedido.valueBuffer("fechasalida") == curPedido.valueBufferCopy("fechasalida")) {
		return true;
	}
	var q = new AQSqlQuery;
	q.setSelect("ms.idstock");
	q.setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN movistock ms ON lp.idlinea = ms.idlineapc");
	q.setWhere("p.idpedido = " + curPedido.valueBuffer("idpedido") + " AND NOT ms.reservamanual");
	if (!q.exec()) {
		return false;
	}
	while (q.next()) {
		if (!flfactalma.iface.pub_distribuyeStockPteClientes(q.value("ms.idstock"), curPedido.valueBuffer("codcliente"))) {
			return false;
		}
	}
	return true;
}
function euromoda_afterCommit_pedidosprov(curPedido) {
	var _i = this.iface;
	if (!_i.__afterCommit_pedidosprov(curPedido)) {
		return false;
	}
	if (!_i.controlHistoricoAcabados(curPedido)) {
		return false;
	}
	return true;
}        
function euromoda_controlHistoricoAcabados(curPedido)
{
	var _i = this.iface;
	switch (curPedido.modeAccess()) {
		case curPedido.Insert: {
			var estadoA = curPedido.valueBuffer("em_estadoacabado");
			if (estadoA && estadoA != "") {
				if (!_i.creaHistoricoAcabados(curPedido.valueBuffer("idpedido"), estadoA)) {
					return false;
				}
			} 
			break;
		}
		case curPedido.Edit: {
			if (curPedido.valueBuffer("em_estadoacabado") != curPedido.valueBufferCopy("em_estadoacabado")) {				
				var estadoA = curPedido.valueBuffer("em_estadoacabado");
				if (!_i.creaHistoricoAcabados(curPedido.valueBuffer("idpedido"), estadoA)) {
					return false;
				}
			} 
			break;
		}
	}
	return true;
}

function euromoda_creaHistoricoAcabados(idPedido, estadoA) 
{
	var _i = this.iface;
	var curEstadosLog = new FLSqlCursor("em_estadospedacabadolog");	
  	var ahora = new Date;
  	var fecha = ahora.toString().left(10);
  	var hora = ahora.toString().right(8);
  	curEstadosLog.setModeAccess(curEstadosLog.Insert);
  	curEstadosLog.refreshBuffer(); 
  	with (curEstadosLog) {
		setValueBuffer("idpedido",idPedido);
		setValueBuffer("idusuario",sys.nameUser());
		setValueBuffer("codestado",estadoA);
		setValueBuffer("fecha",fecha);
		setValueBuffer("hora",hora);
	}
	if(!curEstadosLog.commitBuffer()){
		return false;
	}
	return true;
}

function euromoda_beforeCommit_pedidosprov(curP)
{
	var _i = this.iface;

	if (!_i.__beforeCommit_pedidosprov(curP)) {
		return false;
	}
	formpedidosprov.iface.pK_ = curP.valueBuffer("codigo");
}

function euromoda_beforeCommit_pedidoscli(curP)
{
	var _i = this.iface;

	//debug("idpedido: " + curP.valueBuffer("idpedido"));

	if(curP.modeAccess() == curP.Del){
		var codDropshipping = AQUtil.sqlSelect("pedidoscli", "em_coddropshipping", "idpedido = " + curP.valueBuffer("idpedido"));

		//debug("///////////////coddropped: " + codDropshipping);

		if(codDropshipping && codDropshipping != ""){
			if(!AQUtil.execSql("UPDATE em_cargadropshipping SET idpedido = NULL where coddropshipping = '" + codDropshipping + "' AND idpedido = " + curP.valueBuffer("idpedido"))){
				return false;
			}
		}
	}

	if (!_i.__beforeCommit_pedidoscli(curP)) {
		return false;
	}
	formpedidoscli.iface.pK_ = curP.valueBuffer("codigo");
}

function euromoda_beforeCommit_albaranesprov(curP)
{
	var _i = this.iface;

	if (!_i.__beforeCommit_albaranesprov(curP)) {
		return false;
	}
	formalbaranesprov.iface.pK_ = curP.valueBuffer("codigo");
}

function euromoda_beforeCommit_albaranescli(curP)
{
	var _i = this.iface;

	if (!_i.__beforeCommit_albaranescli(curP)) {
		return false;
	}
	formalbaranescli.iface.pK_ = curP.valueBuffer("codigo");
}
function euromoda_beforeCommit_em_imppednoc(curImp)
{
	var _i = this.iface;
	debug("entra");
	switch (curImp.modeAccess()) {
		case curImp.Del: {
  			if (!_i.controlImpPedNoctalia(curImp)) {
    			return false;
  			}
			break;
		}
	}
  return true;	
}
function euromoda_controlImpPedNoctalia(curImp)
{
	var idImportacion = curImp.valueBuffer("idimportacion");
  	var curPedidos = new FLSqlCursor("pedidoscli");
  	curPedidos.select("em_idimpnoctalia = " + idImportacion);
  	while (curPedidos.next()) {
		curPedidos.setModeAccess(curPedidos.Del);
    	curPedidos.refreshBuffer();		
		var servido = curPedidos.valueBuffer("servido");
		if(servido && servido != "No") {
			sys.warnMsgBox(sys.translate("No se puede eliminar la importaci�n porque contiene pedidos servidos."));
			return false;
		}else {
      	if (!curPedidos.commitBuffer()) {
      		return false;
    		}
		}
  	}
  	return true;
}
function euromoda_beforeCommit_em_impalbnoc(curImp)
{
	var _i = this.iface;
	debug("entra");
	switch (curImp.modeAccess()) {
		case curImp.Del: {
  			if (!_i.controlImpFacNoctalia(curImp)) {
    			return false;
  			}
			if (!_i.controlImpAlbNoctalia(curImp)) {
    			return false;
  			}
			break;
		}
	}
  return true;	
}
function euromoda_controlImpFacNoctalia(curImp)
{
	var idImportacion = curImp.valueBuffer("idimportacion");
  	var curFacturas = new FLSqlCursor("facturascli");
  	curFacturas.select("em_idimpnoctalia = " + idImportacion);
  	while (curFacturas.next()) {
		curFacturas.setModeAccess(curFacturas.Del);
    	curFacturas.refreshBuffer();		
		var editable = curFacturas.valueBuffer("editable");
		if(!editable) {
			sys.warnMsgBox(sys.translate("No se puede eliminar la importaci�n porque contiene facturas pagadas."));
			return false;
		}else {
      	if (!curFacturas.commitBuffer()) {
      		return false;
    		}
		}
  	}
  	return true;
}
function euromoda_controlImpAlbNoctalia(curImp)
{
	var idImportacion = curImp.valueBuffer("idimportacion");
  	var curAlbaranes = new FLSqlCursor("albaranescli");
  	curAlbaranes.select("em_idimpnoctalia = " + idImportacion);
  	while (curAlbaranes.next()) {
		curAlbaranes.setModeAccess(curAlbaranes.Del);
    	curAlbaranes.refreshBuffer();		
		var pteFactura = curAlbaranes.valueBuffer("ptefactura");
		if(!pteFactura) {
			sys.warnMsgBox(sys.translate("No se puede eliminar la importaci�n porque contiene facturas pagadas."));
			return false;
		}else {
      	if (!curAlbaranes.commitBuffer()) {
      		return false;
    		}
		}
  	}
  	return true;
}

function euromoda_recalcularHuecos( serie, ejercicio, fN, emTipoFra ) {
	debug("\n\n euromoda_recalcularHuecos");
	var _i = this.iface;
	var tipo;
	var tabla;

	if ( fN == "nfacturaprov" ) {
		tipo = "FP";
		tabla = "facturasprov"
	} else if (fN == "nfacturacli") {
		tipo = "FC";
		tabla = "facturascli";
	}

	var idSec = AQUtil.sqlSelect( "secuenciasejercicios", "id", "codserie = '" + serie + "' AND codejercicio = '" + ejercicio + "'" );

	if ( idSec ) {
		var nHuecos = parseInt( AQUtil.sqlSelect( "huecos", "count(*)", "codserie = '" + serie + "' AND codejercicio = '" + ejercicio + "' AND tipo = '" + tipo + "'" ) );
		var nFacturas = parseInt( AQUtil.sqlSelect( tabla, "count(*)", "codserie = '" + serie + "' AND codejercicio = '" + ejercicio + "'" ) );
		var maxFactura = parseInt( AQUtil.sqlSelect( "secuencias", "valorout", "id = " + idSec + " AND nombre='" + fN + "'" ) ) - 1;
		if (isNaN(maxFactura)) {
			maxFactura = 0;
		}
		var resta;
		if(emTipoFra && emTipoFra == "DIRECTA") {
			resta = maxFactura - nFacturas +1;
		} else {
			resta = maxFactura - nFacturas;
		}
		debug("TIPO: "+emTipoFra);
		debug("nHuecos: "+nHuecos);
		debug("nFacturas: "+nFacturas);
		debug("maxFactura: "+maxFactura);
		debug("resta: "+resta);
		if ( resta != nHuecos ) {
			var nSec = 0;
			var nFac = 0;
			var ultFac = -1;
			var cursorHuecos = new FLSqlCursor("huecos");
			var qryFac = new FLSqlQuery();

			AQUtil.createProgressDialog( sys.translate("Calculando huecos en la numeraci�n..." ), maxFactura );

			qryFac.setTablesList( tabla );
			qryFac.setSelect( "numero" );
			qryFac.setFrom( tabla );
			qryFac.setWhere( "codserie = '" + serie + "' AND codejercicio = '" + ejercicio + "'" );
			qryFac.setOrderBy( "codigo asc" );
			qryFac.setForwardOnly( true );

			if ( !qryFac.exec() )
				return true;

			AQUtil.sqlDelete( "huecos", "codserie = '" + serie + "' AND codejercicio = '" + ejercicio + "' AND ( tipo = 'XX' OR tipo = '" + tipo + "')" );

			while ( qryFac.next() ) {
				nFac = qryFac.value( 0 );

				// Por si hay duplicados, que no deber�a haberlos...
				if (ultFac == nFac)
					continue;
				ultFac = nFac;

				AQUtil.setProgress( ++nSec );
				while ( nSec < nFac ) {
					cursorHuecos.setModeAccess( cursorHuecos.Insert );
					cursorHuecos.refreshBuffer();
					cursorHuecos.setValueBuffer( "tipo", tipo );
					cursorHuecos.setValueBuffer( "codserie", serie );
					cursorHuecos.setValueBuffer( "codejercicio", ejercicio );
					cursorHuecos.setValueBuffer( "numero", nSec );
					cursorHuecos.commitBuffer();
					AQUtil.setProgress( ++nSec );
				}
			}

			AQUtil.setProgress( ++nSec );
			AQUtil.sqlUpdate( "secuencias", "valorout", nSec, "id = " + idSec + " AND nombre='" + fN + "'" );

			AQUtil.setProgress( maxFactura );
			AQUtil.destroyProgressDialog();
		}
	}

	return true;
}

function euromoda_controlFacturasBloqSerie(curF)
{
	//#bloqueo facturas por serie
	var codigo = curF.valueBuffer("codigo");
	if(codigo.left(1) != "#") {
		return true;
	}
	var numFac  = AQUtil.sqlSelect("facturascli","count(*)","substring(codigo,1,1)='#' and codigo <> '" + codigo + "'");
	if(numFac > 0) {
		sys.warnMsgBox(sys.translate("Hay una factura sin c�digo, por favor revise las facturas. Se cancela el prcoeso."));
		return false;
	}
	return true;
}

function euromoda_beforeCommit_lineasalbaranescli(curLA)
{
	var _i = this.iface;
	if (!_i.__beforeCommit_lineasalbaranescli(curLA)) {
		return false;
	}

	if(curLA.modeAccess() == curLA.Del){
		var codDropshipping = AQUtil.sqlSelect("albaranescli", "em_coddropshipping", "idalbaran = " + curLA.valueBuffer("idalbaran"));
		if(codDropshipping && codDropshipping != ""){
			if(!AQUtil.execSql("UPDATE em_cargadropshipping SET unidadesservidas = 0 where coddropshipping = '" + codDropshipping + "' AND idlineapedido = " + curLA.valueBuffer("idlineapedido"))){
				return false;
			}
		}
	}
	return true;
}

function euromoda_beforeCommit_lineaspedidoscli(curLP)
{
	var _i = this.iface;

	//debug("idpedido: " + curLP.valueBuffer("idpedido"));

	if(curLP.modeAccess() == curLP.Del){
		var codDropshipping = AQUtil.sqlSelect("pedidoscli", "em_coddropshipping", "idpedido = " + curLP.valueBuffer("idpedido"));

		//debug("///////////////coddrop: " + codDropshipping);

		if(codDropshipping && codDropshipping != ""){

			if(!AQUtil.execSql("UPDATE em_cargadropshipping SET idlineapedido = NULL where coddropshipping = '" + codDropshipping + "' AND idlineapedido = " + curLP.valueBuffer("idlinea"))){
				return false;
			}

		}
	}

	if (!_i.__beforeCommit_lineaspedidoscli(curLP)) {
		return false;
	}
}

function euromoda_buscaPosEnCursor(oParams)
{
	var pos = 0;
	var cursor = oParams.cursor;

	var aCols = oParams.objTabla.orderCols();
	if(aCols && aCols.length >= 1) {
		if(aCols[0] == "codigo") {
			debug("orden binario");
			return cursor.atFromBinarySearch(oParams.fN, oParams.valor, oParams.tipoOrden);
		}
	}

	var fin = cursor.size();
	AQUtil.createProgressDialog( sys.translate("Guardando..." ), fin );

	while (pos < fin) {
		AQUtil.setProgress(pos);	
		cursor.seek(pos);
		if (cursor.valueBuffer(oParams.fN) == oParams.valor) {
			AQUtil.destroyProgressDialog();
			return pos;
		}
		pos++;
	}

	AQUtil.destroyProgressDialog();
	return -1;
}

function euromoda_afterCommit_albaranesprov(curAlbaran) 
{
	var _i = this.iface;
	if(!_i.__afterCommit_albaranesprov(curAlbaran)) {
		return false;
	}
	if(!_i.actualizarDatosUltCompraAP(curAlbaran)) {
		return false;
	}
	return true;	
}

function euromoda_actualizarDatosUltCompraAP(curAlbaran)
{
	if(curAlbaran.modeAccess() == curAlbaran.Edit) {
		var codAlmacen = curAlbaran.valueBuffer("codalmacen"); 
		var fecha = curAlbaran.valueBuffer("fecha");
		var fechaCopy = curAlbaran.valueBufferCopy("fecha"); 
		if(fecha != fechaCopy) {
			var q = new FLSqlQuery;
			q.setSelect("referencia");
			q.setFrom("lineasalbaranesprov");
			q.setWhere("idalbaran = " + curAlbaran.valueBuffer("idalbaran") + " and referencia is not null");
			if (!q.exec()) {
				return false;
			}
			while(q.next()) {
				var referencia = q.value("referencia");
				if (!flfactalma.iface.pub_actualizarDatosUltCompra(referencia)) {
					return false;
				}		
				if(referencia && referencia != "") {
					var idStock = AQUtil.sqlSelect("stocks","idstock","referencia = '" + referencia + "' and codalmacen = '" + codAlmacen + "'");
					if(!idStock) {
						continue;
					}
					if (!flfactalma.iface.pub_actualizarDatosUltCompraAlm(idStock)) {
						return false;
					}
				}
			}
		}
	}
	return true;
}

function euromoda_afterCommit_facturasprov(curFactura) 
{
	var _i = this.iface;
	if(!_i.__afterCommit_facturasprov(curFactura)) {
		return false;
	}	
	if(!_i.actualizarDatosUltCompraFP(curFactura)) {
		return false;
	}	
	return true;	
}

function euromoda_actualizarDatosUltCompraFP(curFactura)
{
	if(curFactura.modeAccess() == curFactura.Edit) {
		var codAlmacen = curFactura.valueBuffer("codalmacen"); 
		var fecha = curFactura.valueBuffer("fecha");
		var fechaCopy = curFactura.valueBufferCopy("fecha"); 
		if(fecha != fechaCopy) {
			var q = new FLSqlQuery;
			q.setSelect("referencia");
			q.setFrom("lineasfacturasprov");
			q.setWhere("idfactura = " + curFactura.valueBuffer("idfactura") + " AND referencia is not null");
			if (!q.exec()) {
				return false;
			}
			while(q.next()) {
				var referencia = q.value("referencia");
				if (!flfactalma.iface.pub_actualizarDatosUltCompra(referencia)) {
					return false;
				}	
				if(referencia && referencia != "") {
					var idStock = AQUtil.sqlSelect("stocks","idstock","referencia = '" + referencia + "' and codalmacen = '" + codAlmacen + "'");
					if(!idStock) {
						continue;
					}
					if (!flfactalma.iface.pub_actualizarDatosUltCompraAlm(idStock)) {
						return false;
					}
				}	
			}
		}
	}
	return true;
}

function euromoda_actualizarDatosUltCompraAlbAlm(curLA)
{
	var _i = this.iface;
	var referencia = curLA.valueBuffer("referencia");
	if(!referencia || referencia == "") {
		return true;
	}
	var idAlbaran = curLA.valueBuffer("idalbaran");
	var idStock = AQUtil.sqlSelect("stocks INNER JOIN albaranesprov ON stocks.codalmacen = albaranesprov.codalmacen AND stocks.referencia = '" + referencia + "'","idstock","albaranesprov.idalbaran = " + idAlbaran,"stocks,albaranesprov");
	if(!idStock) {
		return true;
	}
	if (!flfactalma.iface.pub_actualizarDatosUltCompraAlm(idStock)) {
		return false;
	}
	return true;	
}

function euromoda_actualizarDatosUltCompraFraAlm(curLF)
{
	var _i = this.iface;
	var referencia = curLF.valueBuffer("referencia");
	if(!referencia || referencia == "") {
		return true;
	}
	var idFactura = curLF.valueBuffer("idfactura");
	var idStock = AQUtil.sqlSelect("stocks INNER JOIN facturasprov ON stocks.codalmacen = facturasprov.codalmacen AND stocks.referencia = '" + referencia + "'","idstock","facturasprov.idfactura = " + idFactura,"stocks,facturasprov");
	if(!idStock) {
		return true;
	}
	if (!flfactalma.iface.pub_actualizarDatosUltCompraAlm(idStock)) {
		return false;
	}
	return true;	
}

function euromoda_actualizarFechaUltVentaAlbAlm(curLA)
{
	var _i = this.iface;
	var referencia = curLA.valueBuffer("referencia");
	if(!referencia || referencia == "") {
		return true;
	}
	var idAlbaran = curLA.valueBuffer("idalbaran");
	var idStock = AQUtil.sqlSelect("stocks INNER JOIN albaranescli ON stocks.codalmacen = albaranescli.codalmacen AND stocks.referencia = '" + referencia + "'","idstock","albaranescli.idalbaran = " + idAlbaran,"stocks,albaranescli");
	if(!idStock) {
		return true;
	}
	if (!flfactalma.iface.pub_actualizarFechaUltVentaAlm(idStock)) {
		return false;
	}
	return true;	
}

function euromoda_afterCommit_albaranescli(curAlbaran)
{
	var _i = this.iface;
	if(!_i.__afterCommit_albaranescli(curAlbaran)) {
		return false;
	}
	if(!_i.actualizarDatosUltVentaAC(curAlbaran)) {
		return false;
	}
	return true;
}

function euromoda_actualizarDatosUltVentaAC(curAlbaran)
{
	if(curAlbaran.modeAccess() == curAlbaran.Edit) {
		var codAlmacen = curAlbaran.valueBuffer("codalmacen"); 
		var fecha = curAlbaran.valueBuffer("fecha");
		var fechaCopy = curAlbaran.valueBufferCopy("fecha"); 
		if(fecha != fechaCopy) {
			var q = new FLSqlQuery;
			q.setSelect("referencia");
			q.setFrom("lineasalbaranescli");
			q.setWhere("idalbaran = " + curAlbaran.valueBuffer("idalbaran") + " and referencia is not null");
			if (!q.exec()) {
				return false;
			}
			while(q.next()) {
				var referencia = q.value("referencia");
				if (!flfactalma.iface.pub_actualizarFechaUltVenta(referencia)) {
					return false;
				}		
				
				if(referencia && referencia != "") {
					var idStock = AQUtil.sqlSelect("stocks","idstock","referencia = '" + referencia + "' and codalmacen = '" + codAlmacen + "'");
					
					if(!idStock) {
						continue;
					}
					if (!flfactalma.iface.pub_actualizarFechaUltVentaAlm(idStock)) {
						return false;
					}
				}
			}
		}
	}
	return true;
}

function euromoda_beforeCommit_em_dropshipping(curDS)
{
	if (!flfactppal.iface.pub_controlDatosMod(curDS)) {
		return false;
	}
	return true;
}

function euromoda_totalizaDrop(codDrop)
{
	var curDrop = new FLSqlCursor("em_dropshipping");	
	curDrop.select("codigo = '" + codDrop + "'");
   	if(!curDrop.first()) {
   		return true;
   	}
   	curDrop.setModeAccess(curDrop.Edit);
	curDrop.refreshBuffer();
	curDrop.setValueBuffer("numeroenvios",formRecordem_dropshipping.iface.commonCalculateField("numeroenvios",curDrop));
	curDrop.setValueBuffer("unidadesservidas",formRecordem_dropshipping.iface.commonCalculateField("unidadesservidas",curDrop));
	curDrop.setValueBuffer("unidadespendientes",formRecordem_dropshipping.iface.commonCalculateField("unidadespendientes",curDrop));
	curDrop.setValueBuffer("numlinparcial",formRecordem_dropshipping.iface.commonCalculateField("numlinparcial",curDrop));	
	curDrop.setValueBuffer("numlincero",formRecordem_dropshipping.iface.commonCalculateField("numlincero",curDrop));
	curDrop.setValueBuffer("numeropedidos",formRecordem_dropshipping.iface.commonCalculateField("numeropedidos",curDrop));
	if(!curDrop.commitBuffer()) {
		return false;
	}	
	return true;
}

function euromoda_totalizaEnvioDrop(curLA)
{
	var emcodenviodrop = AQUtil.sqlSelect("em_cargaenviosdropshipping","emcodenviodrop","idlineaalbaran = " + curLA.valueBuffer("idlinea"));

	if(!emcodenviodrop || emcodenviodrop == "") {
		return true;
	} 

	var curEnvioDrop = new FLSqlCursor("em_enviodropshipping");	
	curEnvioDrop.select("emcodenviodrop = '" + emcodenviodrop + "'");
   	if(!curEnvioDrop.first()) {
   		return true;
   	}
   	curEnvioDrop.setModeAccess(curEnvioDrop.Edit);
	curEnvioDrop.refreshBuffer();
	curEnvioDrop.setValueBuffer("numeroenvios",formRecordem_enviodropshipping.iface.commonCalculateField("numeroenvios",curEnvioDrop));
	curEnvioDrop.setValueBuffer("unidadesservidas",formRecordem_enviodropshipping.iface.commonCalculateField("unidadesservidas",curEnvioDrop));
	curEnvioDrop.setValueBuffer("unidadespendientes",formRecordem_enviodropshipping.iface.commonCalculateField("unidadespendientes",curEnvioDrop));
	curEnvioDrop.setValueBuffer("numceros",formRecordem_enviodropshipping.iface.commonCalculateField("numceros",curEnvioDrop));
	if(!curEnvioDrop.commitBuffer()) {
		return false;
	}		
	if(!AQUtil.execSql("UPDATE em_cargaenviosdropshipping SET idlineaalbaran = NULL, idalbaran = NULL, codalbaran = NULL where idlineaalbaran = " + curLA.valueBuffer("idlinea"))){
		return false;
	}
	return true;	 
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
