
/** @class_declaration euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial( context ); } 
	function init() {
		return this.ctx.euromoda_init();
	}
	function controlBusqueda() {
		return this.ctx.euromoda_controlBusqueda();
	}
}
//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	_i.controlBusqueda();
}

function euromoda_controlBusqueda()
{
	var t = this.mainWidget().parentWidget().rtti();
// 	debug("Esto es un " + t);
	if (t != "FormSearchDB") {
		return true;
	}
	sys.runObjMethod(this, "tableDBRecords", "setOnlyTable", true);
// 	this.child("tableDBRecords").setOnlyTable(true);
	if (this.child("barraBotones")) {
		this.child("barraBotones").close();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
