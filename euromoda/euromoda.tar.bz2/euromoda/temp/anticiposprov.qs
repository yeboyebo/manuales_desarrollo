
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
  function euromoda(context)
  {
    oficial(context);
  }
  function commonCalculateField(fN, cursor) {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function controlBloqueo() {
		return this.ctx.euromoda_controlBloqueo();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
  var valor;
  switch (fN) {
		case "cancelado": {
      valor = _i.__commonCalculateField(fN, cursor);
      valor = isNaN(valor) ? 0 : valor;
			var partidas = AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idanticipoprov = " + cursor.valueBuffer("idanticipo"));
			partidas = isNaN(partidas) ? 0 : partidas;
			partidas = partidas / cursor.valueBuffer("tasaconv");
			valor = parseFloat(valor) - parseFloat(partidas);
			valor = AQUtil.roundFieldValue(valor, "anticiposprov", "cancelado");
      break;
    }
		case "canceladoeuros": {
      valor = _i.__commonCalculateField(fN, cursor);
      valor = isNaN(valor) ? 0 : valor;
			var partidas = AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idanticipoprov = " + cursor.valueBuffer("idanticipo"));
			partidas = isNaN(partidas) ? 0 : partidas;
			valor = parseFloat(valor) - parseFloat(partidas);
			valor = AQUtil.roundFieldValue(valor, "anticiposprov", "cancelado");
      break;
    }
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
			break;
		}
  }
  return valor;
}

function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.controlBloqueo()) {
		return false;
	}
	return true;
}

function euromoda_controlBloqueo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codProveedor = cursor.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Pago")) {
      return false;
    }
  }
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
