
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends kits {
	var curReserva_;
  function euromoda( context ) { kits ( context ); }
  function commonCalculateField(fN, cursor, oP:optional) {
		return this.ctx.euromoda_commonCalculateField(fN, cursor, oP);
  }
  function calcularCantidad() {
    return this.ctx.euromoda_calcularCantidad();
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function tbwStock_currentChanged(tab) {
    return this.ctx.euromoda_tbwStock_currentChanged(tab);
  }
  function columnasComponentes() {
    return this.ctx.euromoda_columnasComponentes();
  }
  function filtraComponentes() {
    return this.ctx.euromoda_filtraComponentes();
  }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function tbnReservas_clicked() {
    return this.ctx.euromoda_tbnReservas_clicked();
  }
  function tbnVerDocumento_clicked() {
    return this.ctx.euromoda_tbnVerDocumento_clicked();
  }
  function dameFiltroReservada() {
    return this.ctx.euromoda_dameFiltroReservada();
  }
  function dameFiltroPteRecibir() {
    return this.ctx.euromoda_dameFiltroPteRecibir();
  }
  function dameFiltroMerma() {
    return this.ctx.euromoda_dameFiltroMerma();
  }
  function dameFiltroPrev() {
    return this.ctx.euromoda_dameFiltroPrev();
  }
  function dameFiltroOFF() {
    return this.ctx.euromoda_dameFiltroOFF();
  }
  function dameFiltros() {
    return this.ctx.euromoda_dameFiltros();
  }
	function dameFiltroResPteRecibir() {
		return this.ctx.euromoda_dameFiltroResPteRecibir();
	}
	function dameFiltroAFaltas() {
		return this.ctx.euromoda_dameFiltroAFaltas();
	}
	function ordenarMovimientos() {
		return this.ctx.euromoda_ordenarMovimientos();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda*/
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_commonCalculateField(fN, cursor, oP:optional)
{
  var _i = this.iface;
  var valor;
  var idStock = cursor.valueBuffer("idstock");
	var fechaMax = oP ? oP.fechaMax : false;
  /// Van a faltas los movimientos pendientes que est�n asociados a una composici�n marcada como NO reservar y que no est�n asociados a una orden de producci�n
//   var masWhereFaltas = "(ms.idarticulocomp IS NOT NULL AND NOT ac.reservar AND ls.codordenproduccion IS NULL)";
  switch (fN) {
		case "necesidad": {
			var stockMin = parseFloat(cursor.valueBuffer("stockmin"));
			stockMin = isNaN(stockMin) ? 0 : stockMin;
			var aFaltas = parseFloat(cursor.valueBuffer("afaltas"));
			aFaltas = isNaN(aFaltas) ? 0 : aFaltas;
			var disponible = parseFloat(cursor.valueBuffer("disponible"));
			disponible = isNaN(disponible) ? 0 : disponible;
			var disponiblePteRx = parseFloat(cursor.valueBuffer("disponiblepterecibir"));
			disponiblePteRx = isNaN(disponiblePteRx) ? 0 : disponiblePteRx;
			valor = stockMin + aFaltas - disponible -disponiblePteRx ;
			valor = valor < 0 ? 0 : valor;
			break;
		}
  case "reservada": {
      valor = parseFloat(AQUtil.sqlSelect("movistock ms LEFT OUTER JOIN lotesstock ls ON ms.codloteprod = ls.codlote LEFT OUTER JOIN articuloscomp ac ON ms.idarticulocomp = ac.id", "SUM(ms.cantidad)", "ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0", "movistock,lotesstock,articuloscomp"));
// debug("Select SUM(ms.cantidad) from movistock ms LEFT OUTER JOIN lotesstock ls ON ms.codloteprod = ls.codlote LEFT OUTER JOIN articuloscomp ac ON ms.idarticulocomp = ac.id where ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0);
      if (!valor || isNaN(valor)) {
        valor = 0;
      }
      valor *= -1;
      valor = AQUtil.roundFieldValue(valor, "stocks", "reservada");
      break;
  }
  case "reservadaprod": {
      valor = parseFloat(AQUtil.sqlSelect("movistock ms LEFT OUTER JOIN lotesstock ls ON ms.codloteprod = ls.codlote LEFT OUTER JOIN articuloscomp ac ON ms.idarticulocomp = ac.id", "SUM(ms.cantidad)", "ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0 AND ls.codordenproduccion IS NOT NULL", "movistock,lotesstock,articuloscomp"));
// debug("Select SUM(ms.cantidad) from movistock ms LEFT OUTER JOIN lotesstock ls ON ms.codloteprod = ls.codlote LEFT OUTER JOIN articuloscomp ac ON ms.idarticulocomp = ac.id where ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0 AND AND ms.codloteprod IS NOT NULL");
      if (!valor || isNaN(valor)) {
        valor = 0;
      }
      valor *= -1;
      valor = AQUtil.roundFieldValue(valor, "stocks", "reservada");
      break;
  }
//   case "afaltas": {
//       var valorP = parseFloat(AQUtil.sqlSelect("movistock ms LEFT OUTER JOIN lotesstock ls ON ms.codloteprod = ls.codlote LEFT OUTER JOIN articuloscomp ac ON ms.idarticulocomp = ac.id", "SUM(ms.reservaaf)", "ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0 AND " + masWhereFaltas, "movistock,lotesstock,articuloscomp"));
//       if (!valorP || isNaN(valorP)) {
//         valorP = 0;
//       }
//       valor = AQUtil.roundFieldValue(valor, "stocks", "afaltas");
//       break;
//   }
	case "prevision": {
			valor = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idstock = " + cursor.valueBuffer("idstock") + " AND estado = 'PREV'");
      valor = AQUtil.roundFieldValue(valor, "stocks", "prevision");
      break;
  }
	case "cantidad": { /// El stock de la familia de tejido en crudo (partidas) se calcula como el total por distribuir de las partidas
		var referencia = cursor.valueBuffer("referencia");
		var codAlmacen = cursor.valueBuffer("codalmacen");
		if (flfactalma.iface.pub_esReferenciaXPartidas(referencia)) {
			if (fechaMax) {
				valor = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idstock = " + idStock + " AND estado = 'HECHO' AND fechareal < '" + fechaMax + "'");
				valor = isNaN(valor) ? 0 : valor;
			} else {
				valor = parseFloat(AQUtil.sqlSelect("lotesstock", "SUM(mptedist)", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "' AND NOT distribucionfin AND estado = 'TERMINADO'"));
				valor = (!valor || isNaN(valor)) ? 0 : valor;
				valor = AQUtil.roundFieldValue(valor, "stocks", "cantidad");
			}
		} else if (flfactalma.iface.pub_esReferenciaXPiezas(referencia)) {
			if (fechaMax) {
				valor = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idstock = " + idStock + " AND estado = 'HECHO' AND fechareal < '" + fechaMax + "'");
				valor = isNaN(valor) ? 0 : valor;
			} else {
				valor = parseFloat(AQUtil.sqlSelect("lotesstock", "SUM(cantotal-canusada)", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "' AND estado = 'TERMINADO'"));
				valor = (!valor || isNaN(valor)) ? 0 : valor;
				valor = AQUtil.roundFieldValue(valor, "stocks", "cantidad");
			}
		} else {
			valor = _i.__commonCalculateField(fN, cursor, oP)
		}
		break;
  }
		case "pterecibir": {
			valor = parseFloat(AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idstock = " + idStock + " AND estado = 'PTE' AND cantidad > 0 AND NOT em_merma"));
			valor =  (!valor || isNaN(valor)) ? 0 : valor;
			valor = AQUtil.roundFieldValue(valor, "stocks", "pterecibir");
			break;
		}
		case "enreservapterx": {
			valor = parseFloat(AQUtil.sqlSelect("movistock", "SUM(enreserva)", "idstock = " + idStock + " AND estado = 'PTE' AND cantidad > 0 AND NOT em_merma"));
			valor =  (!valor || isNaN(valor)) ? 0 : valor;
			valor = AQUtil.roundFieldValue(valor, "stocks", "enreservapterx");
			break;
		}
		case "em_fechaultventaalm": {
			 debug("euromoda_commonCalculateField 1: "+idStock);
			var codAlmacen = AQUtil.sqlSelect("stocks","codalmacen","idstock = " + idStock);
			debug("euromoda_commonCalculateField 2: "+codAlmacen);
	      	valor = AQUtil.sqlSelect("lineasalbaranescli la INNER JOIN albaranescli a ON la.idalbaran = a.idalbaran", "a.fecha", "la.referencia = '" + cursor.valueBuffer("referencia") + "' AND a.codalmacen = '" + codAlmacen + "' AND la.pvpunitario > 0 AND la.cantidad > 0 ORDER BY a.fecha DESC, a.idalbaran DESC", "lineasalbaranescli,albaranescli");
	      	debug("euromoda_commonCalculateField 3: "+valor);
      		break;
	    }
	    case "em_fechaultcompraalm": {
	    	var codAlmacen = AQUtil.sqlSelect("stocks","codalmacen","idstock = " + idStock);
	      	valor = AQUtil.sqlSelect("lineasalbaranesprov la INNER JOIN albaranesprov a ON la.idalbaran = a.idalbaran", "a.fecha", "la.referencia = '" + cursor.valueBuffer("referencia") + "' AND a.codalmacen = '" + codAlmacen + "' AND la.pvpunitario > 0 AND la.cantidad > 0 ORDER BY a.fecha DESC, a.idalbaran DESC", "lineasalbaranesprov,albaranesprov");
			break;
		}
  default: {
      valor = _i.__commonCalculateField(fN, cursor);
		break;
  }
  }
  return valor;
}

function  euromoda_calcularCantidad()
{
	var _i = this.iface;
	var cursor = this.cursor();

  _i.calcularValoresUltReg();
	sys.setObjText(this, "fdbCantidad", _i.calculateField("cantidad"));
	disconnect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");
	var estado = flfactalma.iface.pub_calculaReservasStock(cursor);
	debug("Estado " + estado);
	if (estado == "ERROR") {
		connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");
		return false;
	}
	if (estado == "A FALTAS") {
		if (!flfactalma.iface.calculaReservasStockDerivadas(cursor.valueBuffer("idstock"), 0, 0, undefined)) {
			connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");
			return false;
		}
		if (!flfactalma.iface.procesaStocks()) {
			return false;
		}
	}	
	connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");

	_i.filtrarMovimientos();
}

function euromoda_init()
{
	var _i = this.iface;
	_i.__init();

	var cursor = this.cursor();
	var referencia = cursor.valueBuffer("referencia");
// 	var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
// 	if (flfactalma.iface.pub_esFamiliaCrudo(codFamilia)) {
	if (flfactalma.iface.pub_esReferenciaXPartidas(referencia)) {
		this.child("tbwStock").setTabEnabled("movimientos", true);
		this.child("tbwStock").setTabEnabled("regularizaciones", false);
		this.child("tbwStock").setTabEnabled("piezas", false);
		var cols = ["fechaentradaem","codlote", "cantotal", "candisponible", "mdistribuidos", "mrecibidos", "mmerma", "pormerma", "mptedist", "mpterec", "distribucionfin", "ubicacion"];
		this.child("tdbPartidas").setOrderCols(cols);
		this.child("tdbPartidas").cursor().setMainFilter("referencia = '" + referencia + "' AND codalmacen = '" + cursor.valueBuffer("codalmacen") + "'");
		this.child("tbwStock").showPage("partidas");
// 	} else if (flfactalma.iface.pub_esFamiliaEstampado(codFamilia)) {
		} else if (flfactalma.iface.pub_esReferenciaXPiezas(referencia)) {
// 		this.child("tbwStock").setTabEnabled("movimientos", false);
		this.child("tbwStock").setTabEnabled("regularizaciones", false);
		this.child("tbwStock").setTabEnabled("partidas", false);
		var cols = ["codlote", "cantotal", "canusada", "canreservada", "candisponible", "ubicacion"];
		this.child("tdbPiezas").setOrderCols(cols);
		this.child("tdbPiezas").cursor().setMainFilter("referencia = '" + referencia + "' AND codalmacen = '" + cursor.valueBuffer("codalmacen") + "'");
		this.child("tbwStock").showPage("piezas");
	} else {
		this.child("tbwStock").setTabEnabled("partidas", false);
		this.child("tbwStock").setTabEnabled("piezas", false);
	}
	connect(this.child("chkMostrarTodosComp"), "clicked()", _i, "filtraComponentes");
	connect(this.child("tbnReservas"), "clicked()", _i, "tbnReservas_clicked");
	connect(this.child("chkPrevision"), "clicked()", this, "iface.filtrarMovimientos");
	connect(this.child("chkMerma"), "clicked()", this, "iface.filtrarMovimientos");
	connect(this.child("chkOff"), "clicked()", this, "iface.filtrarMovimientos");
	connect(this.child("chkResPteRecibir"), "clicked()", this, "iface.filtrarMovimientos");
	connect(this.child("chkResAFaltas"), "clicked()", this, "iface.filtrarMovimientos");
	
	_i.columnasComponentes();
	_i.ordenarMovimientos();
	_i.curReserva_ = new FLSqlCursor("stocks");
	_i.curReserva_.setAction("em_reservasstockmp");
}

function euromoda_tbwStock_currentChanged(tab)
{
	var _i = this.iface;
	switch (tab) {
		case "componentes": {
			_i.filtraComponentes();
			break;
		}
		default: {
			_i.__tbwStock_currentChanged(tab);
		}
	}
}

function euromoda_columnasComponentes()
{
	var oC = ["refart", "desart", "cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir", "disponiblepterecibir", "afaltas", "prevision"];

	var oCAncho = ["cantidad", "reservada", "disponible", "pterecibir", "reservadapterecibir", "disponiblepterecibir", "afaltas", "prevision"];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tdbStocksComp").setColumnWidth(oCAncho[c], 80);
	}
	this.child("tdbStocksComp").setOrderCols(oC);
}

function euromoda_tbnReservas_clicked()
{
	var _i = this.iface;
	var curComp = this.child("tdbStocksComp").cursor();
	var idStock = curComp.valueBuffer("idstock");
// 	var codAlmacen = cursor.cursorRelation().valueBuffer("codalmacen");
// 	_i.refReserva_ = cursor.valueBuffer("referencia");

// 	_i.curReserva_.select("referencia = '" + _i.refReserva_ + "' AND codalmacen = '" + codAlmacen + "'")
	_i.curReserva_.select("idstock = " + idStock)
	if (!_i.curReserva_.first()) {
		MessageBox.warning(sys.translate("No hay un registro de stock para la referencia y almac�n indicados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return;
	}
	disconnect(_i.curReserva_, "bufferCommited()", this.child("tdbStocksComp"), "refresh()");
	connect(_i.curReserva_, "bufferCommited()", this.child("tdbStocksComp"), "refresh()");
	_i.curReserva_.editRecord();
	return;
}

function euromoda_filtraComponentes()
{
	var cursor = this.cursor();
	var referencia = cursor.valueBuffer("referencia");
	var masWhere = this.child("chkMostrarTodosComp").checked ? "" :" AND reservar";
	this.child("tdbStocksComp").cursor().setMainFilter("stocks.referencia IN (SELECT refcomponente FROM articuloscomp WHERE refcompuesto = '" + referencia + "'" + masWhere + ") AND codalmacen = '1'");
	this.child("tdbStocksComp").refresh();
}

function euromoda_bufferChanged(fN)
{
debug("euromoda_bufferChanged " + fN);
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "cantidad": {
		/*	if (!flfactalma.iface.pub_calculaReservasStock(cursor)) {
				return false;
			}*/
			break;
		}
		case "reservada": {
			break;
		}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_tbnVerDocumento_clicked()
{
	var _i = this.iface;
	var curMS = this.child("tdbMoviStocks").cursor();
	var idMov = curMS.valueBuffer("idmovimiento");
	if (!idMov) {
		return;
	}
	if (!curMS.isNull("idproceso")) {
		var codOrden = AQUtil.sqlSelect("pr_procesos", "idobjeto", "idproceso = " + curMS.valueBuffer("idproceso") + " AND tipoobjeto = 'pr_ordenesproduccion'");
		if (!codOrden) {
			sys.warnMsgBox(sys.translate("Error al localizar la orden de producci�n asociado al movimiento seleccionado"));
			return;
		}
		_i.muestraDoc("pr_ordenesproduccion", "codorden = '" + codOrden + "'");
	} else if (!curMS.isNull("idlineapm")) {
		var codPedidoM = AQUtil.sqlSelect("lineaspedidomarcocli", "codpedidomarco", "idlinea = " + curMS.valueBuffer("idlineapm"));
		if (!codPedidoM) {
			sys.warnMsgBox(sys.translate("Error al localizar la previsi�n asociado al movimiento seleccionado"));
			return;
		}
		_i.muestraDoc("pedidosmarcocli", "codpedidomarco = '" + codPedidoM + "'");
	} else if (!curMS.isNull("em_codtraspaso")) {
		_i.muestraDoc("em_traspasosstock", "codtraspaso = '" + curMS.valueBuffer("em_codtraspaso") + "'");
	} else if (!curMS.isNull("idmovproducto")) {
		var idLinea = AQUtil.sqlSelect("movistock", "idlineapc", "idmovimiento = " + curMS.valueBuffer("idmovproducto"));
		var idPedido;
		if (idLinea) {
			idPedido = AQUtil.sqlSelect("lineaspedidoscli", "idpedido", "idlinea = " + idLinea);
			if (!idPedido) {
				sys.warnMsgBox(sys.translate("Error al localizar el pedido de cliente asociado al movimiento seleccionado"));
				return;
			}
			_i.muestraDoc("pedidoscli", "idpedido = " + idPedido);
		} else {
			idLinea = AQUtil.sqlSelect("movistock", "idlineapm", "idmovimiento = " + curMS.valueBuffer("idmovproducto"));
			if (idLinea) {
				idPedido = AQUtil.sqlSelect("lineaspedidomarcocli", "codpedidomarco", "idlinea = " + idLinea);
				if (!idPedido) {
					sys.warnMsgBox(sys.translate("Error al localizar el pedido marco asociado al movimiento seleccionado"));
					return;
				}
				_i.muestraDoc("pedidosmarcocli", "codpedidomarco = '" + idPedido + "'");
			} else {
				sys.warnMsgBox(sys.translate("Error al localizar el documento asociado al movimiento seleccionado"));
				return;
			}
		}
	} else if (!curMS.isNull("emidlineaest")) {
		var codOrden = AQUtil.sqlSelect("em_lineasordenest", "codordenest", "idlinea = " + curMS.valueBuffer("emidlineaest"));
		if (!codOrden) {
			sys.warnMsgBox(sys.translate("Error al localizar la orden de estampaci�n asociada al movimiento seleccionado"));
			return;
		}
		_i.muestraDoc("em_ordenesestampacion", "codordenest = '" + codOrden + "'");
	} else {
		return _i.__tbnVerDocumento_clicked();
	}
}

function euromoda_dameFiltroReservada()
{
	var filtro = "";
	if (this.child("chkReservado").checked) {
		filtro += "(estado = 'PTE' and cantidad < 0 AND NOT em_merma AND reservaex <> 0)";
	}
	return filtro;
}

function euromoda_dameFiltroPteRecibir()
{
	var filtro = "";
	if (this.child("chkPteRecibir").checked) {
		filtro += "(estado = 'PTE' and cantidad > 0 AND NOT em_merma)";
	}
	return filtro;
}

function euromoda_dameFiltroMerma()
{
	var filtro = "";
	if (this.child("chkMerma").checked) {
		filtro += "(em_merma AND cantidad <> 0)";
	}
	return filtro;
}

function euromoda_dameFiltroPrev()
{
	var filtro = "";
	if (this.child("chkPrevision").checked) {
		filtro += "(estado = 'PREV' AND cantidad <> 0)";
	}
	return filtro;
}

function euromoda_dameFiltroOFF()
{
	var filtro = "";
	if (this.child("chkOff").checked) {
		filtro += "(estado = 'OFF' AND cantidad <> 0)";
	}
	return filtro;
}

function euromoda_dameFiltroResPteRecibir()
{
	var filtro = "";
	if (this.child("chkResPteRecibir").checked) {
		filtro += "(estado = 'PTE' and cantidad < 0 AND NOT em_merma AND reservapr <> 0)";
	}
	return filtro;
}

function euromoda_dameFiltroAFaltas()
{
	var filtro = "";
	if (this.child("chkResAFaltas").checked) {
		filtro += "(estado = 'PTE' and cantidad < 0 AND NOT em_merma AND reservaaf <> 0)";
	}
	return filtro;
}

function euromoda_dameFiltros()
{
debug("euromoda_dameFiltros");
	var _i = this.iface;
	var filtro = _i.__dameFiltros();
debug("euromoda_dameFiltros " + filtro);	

	var filtroPteRecibir = _i.dameFiltroResPteRecibir();
	if(filtroPteRecibir && filtroPteRecibir != "") {
		if(filtro && filtro != "")
			filtro += " OR ";
		filtro += filtroPteRecibir;
	}

	var filtroAFaltas = _i.dameFiltroAFaltas();
	if(filtroAFaltas && filtroAFaltas != "") {
		if(filtro && filtro != "")
			filtro += " OR ";
		filtro += filtroAFaltas;
	}
	
	var filtroPrev = _i.dameFiltroPrev();
	if(filtroPrev && filtroPrev != "") {
		if(filtro && filtro != "")
			filtro += " OR ";
		filtro += filtroPrev;
	}
	var filtroMerma = _i.dameFiltroMerma();
	if(filtroMerma && filtroMerma != "") {
		if(filtro && filtro != "")
			filtro += " OR ";
		filtro += filtroMerma;
	}
	var filtroOff = _i.dameFiltroOFF();
	if(filtroOff && filtroOff != "") {
		if(filtro && filtro != "")
			filtro += " OR ";
		filtro += filtroOff;
	}
debug("euromoda_dameFiltros2 " + filtro);	
	return filtro;
}

function euromoda_ordenarMovimientos()
{
	var tdbLC = this.child("tdbMoviStocks");
	var dtbLC = this.mainWidget().child("tdbMoviStocks").tableRecords();
 
	/// Ordenar la tabla maestra por fecha desc.
	var listaCampos;
	try {	
		listaCampos = ["fechareal", "horareal", "fechaprev", "estado", "concepto", "cantidad","reservaex","reservapr","reservaaf","canpedida","emobservaciones","codcliente","nombrecliente","referencia","codlote","codloteprod","idlineapp","regularizacion","codpartida","em_merma","codordenconsumo","reservamanual","usuarioreserva","idmovproducto","mptedist","idmovtejidoprep","codsubfamiliatp","enreserva","forzarafaltas","idmovtejidopadre","em_idtramoppe","agotarexistencias"];
		tdbLC.setOrderCols(listaCampos);	
		tdbLC.autoSortColumn = false;
		var hHeader = dtbLC.horizontalHeader();
		hHeader.setClickEnabled(false);
		hHeader.setSortIndicator(-1, AQS.Ascending);
		dtbLC.setSort(["fechareal ASC", "codlote ASC", "horareal ASC"]);	
	} catch (e) {
		listaCampos = ["fechareal", "horareal", "fechaprev", "estado", "concepto", "cantidad"];
		tdbLC.setOrderCols(listaCampos);
		debug("Error en la ordenaci�n: " + e);
	}    
	dtbLC.refresh(AQS.RefreshData);
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
