/***************************************************************************
                 gruposcontablesprov.qs  -  description
                             -------------------
    begin                : lun nov 07 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) {
		this.ctx = context;
	}
	function init() {
		this.ctx.interna_init();
	}
	function validateForm():Boolean {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var ejercicioActual;
	var longSubcuenta;
	var posActualPuntoSubcuenta, posActualPuntoSubcuentaEf, posActualPuntoSubcuentaEfPago, posActualPuntoSubcuentaFacPago;
	var bloqueoSubcuenta;

	function oficial( context ) { interna( context ); } 
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.ejercicioActual = flfactppal.iface.pub_ejercicioActual();
	_i.longSubcuenta = AQUtil.sqlSelect("ejercicios", "longsubcuenta", "codejercicio = '" + _i.ejercicioActual + "'");
	_i.bloqueoSubcuenta = false; 
	_i.posActualPuntoSubcuenta = -1;
	_i.posActualPuntoSubcuentaEf = -1;
	_i.posActualPuntoSubcuentaEfPago = -1;
	_i.posActualPuntoSubcuentaFacPago = -1;
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();

	switch (fN) {
		case "codsubcuentaprov": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoSubcuenta = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaProv", _i.longSubcuenta, _i.posActualPuntoSubcuenta);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentaefectos": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoSubcuentaEf = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaEfectos", _i.longSubcuenta, _i.posActualPuntoSubcuentaEf);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentaefpago": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoSubcuentaEfPago = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaEfPago", _i.longSubcuenta, _i.posActualPuntoSubcuentaEfPago);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentafacpago": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoSubcuentaFacPago = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaFacPago", _i.longSubcuenta, _i.posActualPuntoSubcuentaFacPago);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
