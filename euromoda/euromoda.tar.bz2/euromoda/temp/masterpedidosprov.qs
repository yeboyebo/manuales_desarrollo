
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends numLineaProv
{
	var curP_, pK_;
	var cursorOrden_;
	var noPreguntar_;
  function euromoda(context)
  {
    numLineaProv(context);
  }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function datosPedidoRS(eLinea, curRS)
  {
    return this.ctx.euromoda_datosPedidoRS(eLinea, curRS);
  }
  function chkARevisar_clicked()
  {
    return this.ctx.euromoda_chkARevisar_clicked();
  }
  function filtroTabla()
  {
    return this.ctx.euromoda_filtroTabla();
  }
  function columnas()
  {
    return this.ctx.euromoda_columnas();
  }
  function commonCalculateField(fN, cursor)
  {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function datosAlbaran(curPedido, where, datosAgrupacion)
  {
    return this.ctx.euromoda_datosAlbaran(curPedido, where, datosAgrupacion);
  }
  function imprimir(codPedido)
  {
    return this.ctx.euromoda_imprimir(codPedido);
  }
  function tbnImprimirMembrete_clicked()
  {
    return this.ctx.euromoda_tbnImprimirMembrete_clicked();
  }
  function datosLineaRS(eLinea)
  {
    return this.ctx.euromoda_datosLineaRS(eLinea);
  }
  function datosLineaParcial(curLineaPedido)
  {
    return this.ctx.euromoda_datosLineaParcial(curLineaPedido);
  }
  function datosLineaAlbaran(curLineaPedido)
  {
    return this.ctx.euromoda_datosLineaAlbaran(curLineaPedido);
  }
  function pbnGenerarAlbaran_clicked()
  {
    return this.ctx.euromoda_pbnGenerarAlbaran_clicked();
  }
  function colorEstado(fN, fV, cursor, fT, sel)
  {
    return this.ctx.euromoda_colorEstado(fN, fV, cursor, fT, sel);
  }
  function tbnFiltro_clicked()
  {
    return this.ctx.euromoda_tbnFiltro_clicked();
  }
  function filtroDefecto()
  {
    return this.ctx.euromoda_filtroDefecto();
  }
  function tbnQuitarFiltro_clicked()
  {
    return this.ctx.euromoda_tbnQuitarFiltro_clicked();
  }
  function controlAlbaranadoPiezas(idPedido)
  {
    return this.ctx.euromoda_controlAlbaranadoPiezas(idPedido);
  }
  function controlAlbaranadoPartidas(idPedido)
  {
    return this.ctx.euromoda_controlAlbaranadoPartidas(idPedido);
  }
  function preloadMainFilter()
  {
    return this.ctx.euromoda_preloadMainFilter();
  }
  function acabados(idPedido, observaciones)
  {
    return this.ctx.euromoda_acabados(idPedido, observaciones);
  }
  function eliminarObserv(idPedido)
  {
    return this.ctx.euromoda_eliminarObserv(idPedido);
  }
  	function toolButtomInsert_clicked() {
		return this.ctx.euromoda_toolButtomInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.euromoda_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.euromoda_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.euromoda_toolButtonZoom_clicked();
	}
	function toolButtonCopy_clicked() {
		return this.ctx.euromoda_toolButtonCopy_clicked();
	}
	function curP_bufferCommited() {
		return this.ctx.euromoda_curP_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tableDBRecords_recordChoosed() {
		return this.ctx.euromoda_tableDBRecords_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function albaranaAcabados(oParam) {
		return this.ctx.euromoda_albaranaAcabados(oParam);
	}
	function copiaLineas(idPedido, idAlbaran) {
		return this.ctx.euromoda_copiaLineas(idPedido, idAlbaran);
	}
	function copiaLineaPedidoAcabados(curLineaPedido, idAlbaran, partidas) {
		return this.ctx.euromoda_copiaLineaPedidoAcabados(curLineaPedido, idAlbaran, partidas);
	}
	function calculaCantidadLineaAcabado(idLinea, partidas) {
		return this.ctx.euromoda_calculaCantidadLineaAcabado(idLinea, partidas);
	}
	function tbnImprimirSubinforme_clicked() {
		return this.ctx.euromoda_tbnImprimirSubinforme_clicked();
	}
	function imprimirInformesSel(codPedido) {
		return this.ctx.euromoda_imprimirInformesSel(codPedido);
	}
	function imprimirDesglose(codPedido) {
		return this.ctx.euromoda_imprimirDesglose(codPedido);
	}
	function treliminaPedido(oParam) {
		return this.ctx.euromoda_treliminaPedido(oParam);
	}
	function actualizaTramosTejido(idPedido) {
		return this.ctx.euromoda_actualizaTramosTejido(idPedido);
	}
	function actualizaBobina(idPedido) {
		return this.ctx.euromoda_actualizaBobina(idPedido);
	}
	function eliminaPedido(cursor) {
		return this.ctx.euromoda_eliminaPedido(cursor);
	}
	function convertirOrden() {
		return this.ctx.euromoda_convertirOrden();
	}
	function trConvertirOrden(oParam) {
		return this.ctx.euromoda_trConvertirOrden(oParam);
	}
	function crearCabeceraOrden(curPedido) {
		return this.ctx.euromoda_crearCabeceraOrden(curPedido);
	}
	function crearLineasOrden(codOrden, idPedido) {
		return this.ctx.euromoda_crearLineasOrden(codOrden, idPedido);
	}
 	function crearTotalesOrden(curOrden) {
 		return this.ctx.euromoda_crearTotalesOrden(curOrden);
 	}
 	function crearLineaOrden(qLinPP, curLinOrden) {
 		return this.ctx.euromoda_crearLineaOrden(qLinPP, curLinOrden);
 	}
 	function imprimeTransAca(idTrans, cursor) {
 		return this.ctx.euromoda_imprimeTransAca(idTrans, cursor);
 	} 	
	function dameParamInformeTransAca(idTrans, cursor) {
		return this.ctx.euromoda_dameParamInformeTransAca(idTrans, cursor);
	}
	function eliminaTransferencia(idPedido) {
		return this.ctx.euromoda_eliminaTransferencia(idPedido);
	}
	/*function dameParamInforme(idPedido) {
		return this.ctx.euromoda_dameParamInforme(idPedido);
	}*/
	function generarAlbaranParcial(curPedido) {
		return this.ctx.euromoda_generarAlbaranParcial(curPedido);
	}
	function ordenCopiaLineasParcial()
	{
		return this.ctx.euromoda_ordenCopiaLineasParcial();
	}
	function tbnExportarDatosDist_clicked() {
		return this.ctx.euromoda_tbnExportarDatosDist_clicked();
	}	
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA /////////////////////////////////////////////
class pubEuromoda extends pubProd {
    function pubEuromoda( context ) { pubProd( context ); }
	function pub_imprimirInformesSel(codPedido) {
		return this.imprimirInformesSel(codPedido);
	}
}
//// PUB EUROMODA /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////

function euromoda_datosLineaRS(eLinea)
{
  var _i = this.iface;
  if (!_i.__datosLineaRS(eLinea)) {
    return false;
  }
  with(_i.curLineaRS) {
    setValueBuffer("pendiente", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpunitario", this));
  }
  return true;
}

function euromoda_datosPedidoRS(eLinea, curRS)
{
  var _i = this.iface;

  if (!_i.__datosPedidoRS(eLinea, curRS)) {
    return false;
  }
  var codProveedor = _i.curPedidoRS.valueBuffer("codproveedor");
  with(_i.curPedidoRS) {
    setValueBuffer("em_codpago", AQUtil.sqlSelect("proveedores", "em_codpago", "codproveedor = '" + codProveedor + "'"));
    setValueBuffer("fechaentrada", _i.commonCalculateField("fechaentrada", this));
    setValueBuffer("fechacomprobacion", _i.commonCalculateField("fechacomprobacion", this));
    setValueBuffer("idcontactoenvio", sys.nameUser());
    setValueBuffer("telcontacto", AQUtil.sqlSelect("proveedores", "telefono1", "codproveedor = '" + codProveedor + "'"));
    setValueBuffer("direccione", _i.commonCalculateField("direccione", this));
    setValueBuffer("codpostale", _i.commonCalculateField("codpostale", this));
    setValueBuffer("ciudade", _i.commonCalculateField("ciudade", this));
    setValueBuffer("provinciae", _i.commonCalculateField("provinciae", this));
    setValueBuffer("codpaise", _i.commonCalculateField("codpaise", this));
    setValueBuffer("codgrupoivaneg", AQUtil.sqlSelect("proveedores", "codgrupoivaneg", "codproveedor = '" + codProveedor + "'"));
    setValueBuffer("codserie", _i.commonCalculateField("codserie", this));
  }
  return true;
}

function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
  _i.columnas();
  _i.noPreguntar_= false;
  connect(this.child("tbnFiltro"), "clicked()", _i, "tbnFiltro_clicked");
  connect(this.child("tbnQuitarFiltro"), "clicked()", _i, "tbnQuitarFiltro_clicked");
  connect(this.child("chkARevisar"), "clicked()", _i, "chkARevisar_clicked");
  connect(this.child("tbnImprimirMembrete"), "clicked()", _i, "tbnImprimirMembrete_clicked");
  
  	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	connect(this.child("toolButtonCopy"), "clicked()", _i, "toolButtonCopy_clicked");
	
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tableDBRecords_recordChoosed");
	connect(this.child("tbnImprimirSubinforme"), "clicked()", _i, "tbnImprimirSubinforme_clicked");  
  	connect(this.child("pbnConvertirOrden"), "clicked()", _i, "convertirOrden");  
  	connect(this.child("tbnExportarDatosDist"), "clicked()", _i, "tbnExportarDatosDist_clicked");

  	if(this.child("tbnCambiarAlmacen")) {
  		this.child("tbnCambiarAlmacen").close();
  	}

}

function euromoda_chkARevisar_clicked()
{
  var _i = this.iface;
  _i.filtrarTabla();
  _i.tdbRecords.refresh();
}

function euromoda_filtroTabla()
{
  var _i = this.iface;
  var filtro = _i.__filtroTabla();
  if (this.child("chkARevisar").checked) {
    filtro += filtro != "" ? " AND " : "";
    filtro += " servido <> 'S�' AND fechacomprobacion <= CURRENT_DATE";
  }
  return filtro;
}

function euromoda_columnas()
{
  var _i = this.iface;
  var aC = ["codigo", "servido", "em_estadoproceso","em_codmaquina","em_metros", "editable", "nombre", "fecha", "fechaentrada", "contactoprov", "telcontacto"];
  _i.tdbRecords.setOrderCols(aC);
}

function euromoda_commonCalculateField(fN, cursor)
{
  var _i = this.iface;
  var valor;
  switch (fN) {
    case "codserie": {
      if (cursor.valueBuffer("codserie") == "Z") {
        valor = "Z"; /// Migraci�n
        break;
      }
      valor = AQUtil.sqlSelect("proveedores p INNER JOIN gruposcontablesprov gp ON p.codgrupocontableprov = gp.codgrupo", "gp.codseriefac", "p.codproveedor = '" + cursor.valueBuffer("codproveedor") + "'", "proveedores");
      break;
    }
    case "fechaentrada": {
      var fecha = cursor.valueBuffer("fecha");
      valor = fecha ? AQUtil.addDays(fecha, 20) : "NULL";
      break;
    }
    case "codalmaorigen": {
      valor = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + cursor.valueBuffer("codproveedor") + "'");
      break;
    }
    case "codalmacen": {
      valor = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + cursor.valueBuffer("codproveedordestino") + "'");
      break;
    }
    case "direccione":
    case "ciudade":
    case "idprovinciae":
    case "codpostale": {
      var campo = (fN == "ciudade") ? "poblacion" : fN.left(fN.length - 1)
                  valor = AQUtil.sqlSelect("almacenes", campo, "codalmacen = '" + cursor.valueBuffer("codalmacen") + "'");
      if (!valor) {
        campo = fN.left(fN.length - 1);
        valor = AQUtil.sqlSelect("dirproveedores", campo, "codproveedor = '" + cursor.valueBuffer("codproveedordestino") + "' AND direccionppal");
      }
      if (valor == 0) {
        valor = "";
      }
      break;
    }
    case "fechacomprobacion": {
      var dias = AQUtil.daysTo(cursor.valueBuffer("fecha"), cursor.valueBuffer("fechaentrada"));
      var diasComp = 0;
      if (dias && !isNaN(dias)) {
        diasComp = Math.round(dias * 0.8);
      }
      valor = AQUtil.addDays(cursor.valueBuffer("fecha"), diasComp);
      break;
    }
	 case "em_metros": {
		valor = AQUtil.sqlSelect("lineaspedidosprov", "SUM(cantidad)", "idpedido = " + cursor.valueBuffer("idpedido") );
      if (valor == "") {
        valor = 0;
      }
		break;
	 }
    default: {
      valor = _i.__commonCalculateField(fN, cursor);
    }
  }
  return valor;
}
function euromoda_datosAlbaran(curPedido, where, datosAgrupacion)
{
  var _i = this.iface;
  if (!_i.__datosAlbaran(curPedido, where, datosAgrupacion)) {
    return false;
  }
  var codAlmacenDest = curPedido.valueBuffer("codalmacendest");
  if (codAlmacenDest) {
    _i.curAlbaran.setValueBuffer("codalmacen", codAlmacenDest);
  }

  _i.curAlbaran.setValueBuffer("codordenprod", curPedido.valueBuffer("codordenprod"));
  _i.curAlbaran.setValueBuffer("em_codpago", curPedido.valueBuffer("em_codpago"));
  _i.curAlbaran.setValueBuffer("numproveedor", curPedido.valueBuffer("numproveedor"));
  _i.curAlbaran.setValueBuffer("em_obsacabadoauto", curPedido.valueBuffer("em_obsacabadoauto"));

  return true;
}

function euromoda_imprimir(codPedido)
{
	var _i = this.iface;
	var util = new FLUtil;
	var idPedido, codigo, observaciones, observacionesAuto;
	if (codPedido) {
		codigo = codPedido;
		idPedido = util.sqlSelect("pedidosprov", "idpedido", "codigo = '" + codigo + "'");
		observaciones = util.sqlSelect("pedidosprov", "observaciones", "codigo = '" + codigo + "'");
		observacionesAuto = AQUtil.sqlSelect("pedidosprov", "em_obsacabadoauto", "codigo = '" + codigo + "'");
		if(!observacionesAuto) {
			observacionesAuto = "";
		}
	} else {
		if (this.child("tableDBRecords")) {
			this.child("tableDBRecords").refresh();
		}
		var cursor = this.cursor();
		if (!cursor.isValid()) {
			return;
		}
		codigo = cursor.valueBuffer("codigo");
		idPedido = cursor.valueBuffer("idpedido");
		observaciones = cursor.valueBuffer("observaciones");
		observacionesAuto = cursor.valueBuffer("em_obsacabadoauto");
	}
	if (!idPedido) {
		return;
	}
	observaciones += observacionesAuto == "" ? "" : "\n";
	observaciones += observacionesAuto;
	_i.acabados(idPedido, observaciones);

	var oParam = this.iface.dameParamInforme(idPedido);
	if (!oParam) {
		return;
	}

	if(!_i.noPreguntar_) {

		var dialog = new Dialog;
		dialog.caption = "Impresi�n";
		dialog.okButtonText = "Imprimir";
		dialog.cancelButtonText = "Cancelar";    
		var texto = new Label;
		texto.text = sys.translate("Seleccione el tipo de impreso");
		dialog.add( texto );    

		var grupo = new GroupBox;
		dialog.add( grupo );   


		var botonV = new RadioButton;
		botonV.text = "Valorado";
		botonV.checked = false;
		grupo.add( botonV );


		var botonNV = new RadioButton;
		botonNV.text = "No valorado";
		botonNV.checked = true;
		grupo.add( botonNV );

		if(!dialog.exec() ) {
			return;
		}

		if (botonV.checked) {
			oParam.nombreReport = "i_pedidosprov_v";
		}
	}


	var curImprimir = new FLSqlCursor("i_pedidosprov");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_pedidosprov_codigo", codigo);
	curImprimir.setValueBuffer("h_pedidosprov_codigo", codigo);
	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);

	_i.eliminarObserv(idPedido);
}

function euromoda_datosLineaParcial(curLineaPedido)
{
  var _i = this.iface;

  if (!_i.__datosLineaParcial(curLineaPedido))
    return false;

  _i.curLineaAlbaran.setValueBuffer("tipoconcepto", curLineaPedido.valueBuffer("tipoconcepto"));
  _i.curLineaAlbaran.setValueBuffer("texto", curLineaPedido.valueBuffer("texto"));
  _i.curLineaAlbaran.setValueBuffer("codloteprod", curLineaPedido.valueBuffer("codloteprod"));
  _i.curLineaAlbaran.setValueBuffer("codtamanoem", curLineaPedido.valueBuffer("codtamanoem"));
  _i.curLineaAlbaran.setValueBuffer("codcolorem", curLineaPedido.valueBuffer("codcolorem"));

  return true;
}

function euromoda_datosLineaAlbaran(curLineaPedido)
{
  var _i = this.iface;

  if (!_i.__datosLineaAlbaran(curLineaPedido)) {
    return false;
  }
  _i.curLineaAlbaran.setValueBuffer("codloteprod", curLineaPedido.valueBuffer("codloteprod"));
  _i.curLineaAlbaran.setValueBuffer("codtamanoem", curLineaPedido.valueBuffer("codtamanoem"));
  _i.curLineaAlbaran.setValueBuffer("codcolorem", curLineaPedido.valueBuffer("codcolorem"));
  return true;
}

function euromoda_pbnGenerarAlbaran_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codProveedor = cursor.valueBuffer("codproveedor");
	if (codProveedor && codProveedor != "") {
		if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
			return false;
		}
	}	
	if (!cursor.valueBuffer("acabados")) {
		if (!_i.controlAlbaranadoPiezas(cursor.valueBuffer("idpedido"))) {
			return false;
		}
		if (!_i.controlAlbaranadoPartidas(cursor.valueBuffer("idpedido"))) {
			return false;
		}
		_i.__pbnGenerarAlbaran_clicked();
		
	} else {
	
	  	if (cursor.valueBuffer("editable") == false) {
			MessageBox.warning(util.translate("scripts", "El pedido ya est� servido"), MessageBox.Ok, MessageBox.NoButton);
			this.iface.procesarEstado();
			return;
		}
	
		var curT = new FLSqlCursor("empresa");
		curT.transaction(false);
		try {
	 		if(!_i.albaranaAcabados()) {
	 			curT.rollback();	
	 		} else {
	 			curT.commit();  			
	 		}
	  		
	  	} catch(e) {		
	  		curT.rollback();	
			sys.warnMsgBox(sys.translate("No ha generado el albar�n, los cambios no se guardar�n"));
			return false;
		}	
	}
}

function euromoda_controlAlbaranadoPiezas(idPedido)
{
  var famPartidas = flfactalma.iface.pub_dameFamEstampado();
  var subfamPartidas = flfactalma.iface.pub_dameSubfamEstampado();

  var q = new AQSqlQuery;
  q.setSelect("lp.referencia");
  q.setFrom("lineaspedidosprov lp INNER JOIN articulos a ON lp.referencia = a.referencia");
  q.setWhere("lp.idpedido = " + idPedido + " AND (a.codfamilia IN (" + famPartidas + ") OR a.codsubfamilia IN (" + subfamPartidas + "))");
  if (!q.exec()) {
    return false;
  }
  if (q.first()) {
    var res = MessageBox.warning(sys.translate("Hay al menos un art�culo en el pedido que se gestiona por piezas.\nDebe albaranarlo mediante el bot�n de generar piezas de la ventana de albaranes\n�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
    if (res != MessageBox.Yes) {
      return false;
    }
  }
  return true;
}

function euromoda_controlAlbaranadoPartidas(idPedido)
{
  var q = new AQSqlQuery;
  q.setSelect("lp.referencia");
  q.setFrom("lineaspedidosprov lp INNER JOIN articulos a ON lp.referencia = a.referencia INNER JOIN movistock ms ON lp.idlinea = ms.idlineapp");
  q.setWhere("lp.idpedido = " + idPedido + " AND ms.codpartida IS NOT NULL");
  if (!q.exec()) {
    return false;
  }
  if (q.first()) {
    var res = sys.warnMsgBox(sys.translate("Alguna de las l�neas del pedido tiene asociada una partida de origen de material.\nDebe albaranarlo mediante el bot�n de generar piezas de la ventana de albaranes"));
	  return false;
  }
  return true;
}


function euromoda_tbnImprimirMembrete_clicked()
{
	var _i = this.iface;

	flfactinfo.iface.pub_ponerMembrete(true);
	_i.imprimir();
  	flfactinfo.iface.pub_ponerMembrete(false);
}

function euromoda_colorEstado(fN, fV, cursor, fT, sel)
{
  var _i = this.iface;
  switch (fN) {
    case "servido": {
      return _i.__colorEstado(fN, fV, cursor, fT, sel);
    }
    case "em_estadoproceso": {
      var color = "";
      switch (fV) {
        case "Estampado": {
          color = flfactppal.iface.pub_dameColor("fondo_naranja");
          break;
        }
        default: {
          return;
        }
      }
      if (color != "") {
        var a = [color, "#000000", "SolidPattern", "SolidPattern"];
        return a;
      }
      break;
    }
  }
}


function euromoda_tbnFiltro_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  var sesion = flfactalma.iface.pub_dameSesion();

  var f = new FLFormSearchDB("em_filtropedidosprov");
  var curF = f.cursor();

  curF.select("sesion = '" + sesion + "'");
  if (curF.first()) {
    curF.setModeAccess(curF.Edit);
  } else {
    curF.setModeAccess(curF.Insert);
  }
  curF.refreshBuffer();
  curF.setValueBuffer("sesion", sesion);

  f.setMainWidget();

  var filtro = f.exec("filtro");
  debug("filtro " + filtro);
  if (!filtro) {
    filtro = _i.filtroDefecto();;
  }
  var fBase = _i.filtroTabla();

  if (filtro) {
    curF.commitBuffer();
    cursor.setMainFilter(fBase + " AND " + filtro);
  } else {
    cursor.setMainFilter(fBase);
  }

  if (this.child("tableDBRecords")) {
    this.child("tableDBRecords").refresh();
  }
}

function euromoda_filtroDefecto()
{
  return "servido IN ('No', 'Parcial')";
}

function euromoda_tbnQuitarFiltro_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  var filtro = _i.preloadMainFilter();

  this.cursor().setMainFilter(filtro);
  if (this.child("tableDBRecords")) {
    this.child("tableDBRecords").refresh();
  }
}

function euromoda_preloadMainFilter()
{
  debug("euromoda_preloadMainFilter");
  var _i = this.iface;
  var cursor = this.cursor();

  var filtro = _i.filtroDefecto();
  var fBase = _i.filtroTabla();
  filtro = fBase != "" ? (fBase + " AND " + filtro) : filtro;
  debug("euromoda_preloadMainFilter " + filtro);
  return filtro;
}

function euromoda_acabados(idPedido, observaciones)
{
  var qLineaPP = new AQSqlQuery;
  qLineaPP.setSelect("idlinea");
  qLineaPP.setFrom("lineaspedidosprov");
  qLineaPP.setWhere("idpedido = " + idPedido + " ORDER BY idlinea desc");
  if (!qLineaPP.exec()) {
    return false;
  }
  if (!qLineaPP.first()) {
    return false;
  }
  var ultimaLinea = qLineaPP.value("idlinea");
  //sacamos las observaciones por intros
  var sObservaciones = observaciones.split("\n");

  var tam = sObservaciones.length;
  if (tam == 1 && sObservaciones[0] == "") {
    tam = 0;
  }
  var cursorAcabados = new FLSqlCursor("em_acabadospedprov");
  var linea = "------------------------------------------------------------------------------------------------------";
  var saltoLinea = "\n";
  var numAcabados = AQUtil.sqlSelect("em_acabadospedprov", "count (*)", "em_codacabado is not null and idpedido = " + idPedido);
  if (numAcabados > 0) {
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idpedido", idPedido);
    cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", linea);
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idpedido", idPedido);
    cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", " Acabados");
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    if (tam == 0) {
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idpedido", idPedido);
      cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", linea);
      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
    }
  }
  if (tam > 0) {
    if (numAcabados > 0) {
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idpedido", idPedido);
      cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", linea);
      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idpedido", idPedido);
      cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", saltoLinea);
      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
    }


    for (i = tam - 1; i >= 0; i--) {
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idpedido", idPedido);
      cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", sObservaciones[i]);

      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
    }

    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idpedido", idPedido);
    cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", linea);
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idpedido", idPedido);
    cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", " Observaciones");
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idpedido", idPedido);
    cursorAcabados.setValueBuffer("idlineapedido", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", linea);
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
  }



  cursorAcabados.setModeAccess(cursorAcabados.Edit);
  AQUtil.sqlUpdate("em_acabadospedprov", "idlineapedido", ultimaLinea, "idpedido = " + idPedido);

  return true;

}
function euromoda_eliminarObserv(idPedido)
{
  AQUtil.sqlDelete("em_acabadospedprov", "em_codacabado is null and idpedido = " + idPedido);


}

function euromoda_tableDBRecords_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEdit_clicked();
}

function euromoda_toolButtomInsert_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");

}

function euromoda_toolButtonEdit_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDelete_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoom_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}

function euromoda_toolButtonCopy_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("copy");
}

function euromoda_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (_i.curP_) {
		disconnect(_i.curP_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curP_, "commited()", _i, "curP_bufferCommited");
		_i.curP_ = undefined;
	}
	
	_i.curP_ = new FLSqlCursor("pedidosprov");
	_i.curP_.setAction("pedidosprov");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curP_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curP_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curP_, "commited()", _i, "curP_bufferCommited");
			_i.curP_.insertRecord();
			break;
		}
		case "edit": {
			connect(_i.curP_, "commited()", _i, "refrescaTabla");
			_i.curP_.editRecord();
			break;
		}
		case "del": {
		  	
  			if (!cursor.valueBuffer("acabados")) {
  				this.child("tableDBRecords").deleteRecord();
  			} else { 		
  				debug("llama a eliminarpedido");	
  				var res = MessageBox.information(sys.translate("El registro activo ser� borrado. �Est� seguro?"), MessageBox.Yes,MessageBox.No);
				if (res != MessageBox.Yes) {
					return;
				}
  				var oParam = new Object;
				oParam.errorMsg = sys.translate("Error al eliminar el pedido de acabados.");
				oParam.cursor = cursor;
				var f = new Function("oParam", "return formpedidosprov.iface.treliminaPedido(oParam)");
				if (!sys.runTransaction(f, oParam)) {									
					return false;
				}			

  			}
			
			break;
		}
		case "browse": {	
			_i.curP_.browseRecord();
			break;
		}
		case "copy": {
			this.child("tableDBRecords").copyRecord(); // Deber�amos llamar a curP_.copyRecord, pero no est� publicado
			break;
		}
	}
}

function euromoda_refrescaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.refresh()
}

function euromoda_curP_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	this.child("tableDBRecords").refresh();
	var dtbLC = this.mainWidget().child("tableDBRecords").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);
	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);

	var oParams = [];
	oParams.fN = "codigo";
	oParams.valor = _i.pK_;
	oParams.cursor = cursor;
	oParams.tipoOrden = asc
	oParams.objTabla = this.child("tableDBRecords");

	var pos = flfacturac.iface.pub_buscaPosEnCursor(oParams);
	if (pos == -1) {
		debug("No encontrado");
		return false;
	}
	cursor.seek(pos);
	cursor.refresh()
}

function euromoda_albaranaAcabados(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var fAA = new FLFormSearchDB("em_albaranaracabados");
	var curAA = fAA.cursor();
	curAA.select("idpedido = " + cursor.valueBuffer("idpedido"));
	if (!curAA.first()) {
		return false;
	}
	curAA.setModeAccess(curAA.Edit);
	curAA.refreshBuffer();
	
	fAA.setMainWidget();
	var idPedido = fAA.exec("idfactura");
	if(!fAA.accepted()) {
		return false;
	}	
	return true;
}

function euromoda_copiaLineas(idPedido, idAlbaran)
{

	var _i = this.iface;
	var cursor = this.cursor();
		
	if (!cursor.valueBuffer("acabados")) {
  		return _i.__copiaLineas(idPedido, idAlbaran);
  	}
	
	if(!AQSql.update("albaranesprov",["acabados"],[true],"idalbaran = " + idAlbaran)) {
		return false;
	}	
	var partidas = formem_albaranaracabados.iface.damePartidas();
	
	var numReg = AQUtil.sqlSelect("lineaspedidosprov","count(*)","idpedido = " + idPedido + " AND idlinea IN (SELECT lp.idlinea FROM lineaspedidosprov lp INNER JOIN em_tramostejido tt ON lp.idlinea = tt.idlineapedacabado INNER JOIN lotesstock ls ON tt.codbobina = ls.codbobina WHERE lp.idpedido = " + idPedido + " AND ls.codlote  IN (" + partidas + "))","lineaspedidosprov");
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Generando albar�n"), numReg);
	AQUtil.setProgress(1);
	var j = 0;
	
	var curLineaPedido = new FLSqlCursor("lineaspedidosprov");

	curLineaPedido.select("idpedido = " + idPedido + " AND idlinea IN (SELECT lp.idlinea FROM lineaspedidosprov lp INNER JOIN em_tramostejido tt ON lp.idlinea = tt.idlineapedacabado INNER JOIN lotesstock ls ON tt.codbobina = ls.codbobina WHERE lp.idpedido = " + idPedido + " AND ls.codlote  IN (" + partidas + ")) ORDER By lp.numlinea");
	
	var idLineaA;
	while (curLineaPedido.next()) {
		curLineaPedido.setModeAccess(curLineaPedido.Browse);
		curLineaPedido.refreshBuffer();
		idLineaA = _i.copiaLineaPedidoAcabados(curLineaPedido, idAlbaran, partidas);		
		if (!idLineaA) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		
		var qryPartidas = new AQSqlQuery();
		qryPartidas.setSelect("ls.codlote");		
		qryPartidas.setFrom("lotesstock ls INNER JOIN em_bobinas b ON ls.codbobina = b.codbobina INNER JOIN em_tramostejido tt ON b.codbobina = tt.codbobina INNER JOIN lineaspedidosprov lp ON tt.idlineapedacabado = lp.idlinea");
		qryPartidas.setWhere("lp.idlinea = " + curLineaPedido.valueBuffer("idlinea") + " AND ls.codlote IN (" + partidas + ")");
		
		qryPartidas.exec();
		
		while(qryPartidas.next()) {
		
			var curLS = new FLSqlCursor("lotesstock");
			curLS.setActivatedCheckIntegrity(false);
			curLS.setActivatedCommitActions(false);
			curLS.select("codlote = '" + qryPartidas.value("ls.codlote") + "'");
			if(curLS.first()) {
				curLS.setModeAccess(curLS.Edit);
				curLS.refreshBuffer();			
				curLS.setValueBuffer("idlinea",idLineaA);
				if (!curLS.commitBuffer()) {
					AQUtil.destroyProgressDialog();
					return false;
				}
			}	
		}
		AQUtil.setProgress(++j);	
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_copiaLineaPedidoAcabados(curLineaPedido, idAlbaran, partidas)
{
	var _i = this.iface;
	
	if (!_i.curLineaAlbaran) {
		_i.curLineaAlbaran = new FLSqlCursor("lineasalbaranesprov");
	}
	_i.curLineaAlbaran.setModeAccess(_i.curLineaAlbaran.Insert);
	_i.curLineaAlbaran.refreshBuffer();
	_i.curLineaAlbaran.setValueBuffer("idalbaran", idAlbaran);	
	_i.curLineaAlbaran.setValueBuffer("cantidad", _i.calculaCantidadLineaAcabado(curLineaPedido.valueBuffer("idlinea"), partidas));
	
	if (!_i.datosLineaAlbaran(curLineaPedido)) {
		return false;
	}
	
	if (!flfactalma.iface.pub_consistenciaLinea(curLineaPedido)) {
		return false;
	}
	if (!_i.curLineaAlbaran.commitBuffer()) {
		return false;
	}
	return _i.curLineaAlbaran.valueBuffer("idlinea");
}

function euromoda_calculaCantidadLineaAcabado(idLinea,partidas)
{
	var _i = this.iface;
	var bobinas = formem_albaranaracabados.iface.dameBobinas();	
	var cantidad;
	var q = new AQSqlQuery;	
	q.setSelect("sum(tt.candisponible)");
	q.setFrom("em_tramostejido tt inner join lotesstock on tt.codpartida=lotesstock.codlote");
	q.setWhere("tt.idlineapedacabado = " + idLinea + " AND lotesstock.codlote IN (" + partidas + ") and tt.codbobina in (" + bobinas +")"); 			
	debug("sql de la cantidad: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{
		cantidad = q.value("sum(tt.candisponible)");	
	}	
		
	if(!cantidad || cantidad == "") {
		cantidad = 0;
	}		
	return cantidad;
}

function euromoda_tbnImprimirSubinforme_clicked()
{
    var _i = this.iface;
    var cursor = this.cursor();
    if (!cursor.isValid()) {
    	return;
	}
    _i.imprimirInformesSel(cursor.valueBuffer("codigo"));
}

function euromoda_imprimirInformesSel(codPedido)
{
    var _i = this.iface;    
   	_i.noPreguntar_ = true;

    var dialog = new Dialog;
    dialog.caption = "Impresi�n";
    dialog.okButtonText = "Imprimir";
    dialog.cancelButtonText = "Cancelar";    
    var texto = new Label;
    texto.text = sys.translate("Seleccione el tipo de impreso");
    dialog.add( texto );    
    var grupo = new GroupBox;
    dialog.add( grupo );   
    var botonIA = new CheckBox;
    botonIA.text = "Impreso acabados";
    botonIA.checked = true;
    grupo.add( botonIA );
    
    var botonDB = new CheckBox;
    botonDB.text = "Desglose de bobinas";
    botonDB.checked = true;
    grupo.add( botonDB );
    
    var botonTS = new CheckBox;
    botonTS.text = "Transferencia";
    botonTS.checked = true;
    var idTrans = AQUtil.sqlSelect("pedidosprov pp INNER JOIN em_transstockaca ts ON pp.idpedido = ts.idpedacabado", "ts.idtrans", "pp.codigo = '" + codPedido + "'", "pedidosprov");
    if (idTrans) {
	    grupo.add(botonTS);
    }
    if(!dialog.exec() ) {
    	return;
	}
	if (botonIA.checked) {
	    _i.imprimir(codPedido);
	}
	if (botonDB.checked) {
	    _i.imprimirDesglose(codPedido);		
	}
	if (idTrans && botonTS.checked) {
	    var curTrans = new FLSqlCursor("em_transstockaca");
	    curTrans.select("idtrans = " + idTrans );
	    if (!curTrans.first()) {
		return false;
	    }
	    curTrans.setModeAccess(curTrans.Browse);
	    curTrans.refreshBuffer(); 
	    //formtransstock.iface.pub_imprimeTrans(idTrans, curTrans);		
	    _i.imprimeTransAca(idTrans, curTrans);
	}
	_i.noPreguntar_ = false;
}

function euromoda_imprimirDesglose(codPedido)
{
    var _i = this.iface;	    
    var idPedido, codigo, observaciones;
    if (codPedido) {
	codigo = codPedido;
	idPedido = AQUtil.sqlSelect("pedidosprov", "idpedido", "codigo = '" + codigo + "'");
	
    } else {
	if (this.child("tableDBRecords")) {
	    this.child("tableDBRecords").refresh();
	}
	var cursor = this.cursor();
	if (!cursor.isValid()) {
	    return;
	}
	codigo = cursor.valueBuffer("codigo");
	idPedido = cursor.valueBuffer("idpedido");
	
    }
    if (!idPedido) {
	return;
    }
    
    var oParam = _i.dameParamInforme(idPedido);
    if (!oParam) {
	return;
    }
    oParam.nombreInforme = "i_pedidosprovordest";
    oParam.nombreReport = "i_pedidosprovordest";
    oParam.whereFijo = " bob.idalbaranprov is null";
    var curImprimir = new FLSqlCursor("i_pedidosprov");
    curImprimir.setModeAccess(curImprimir.Insert);
    curImprimir.refreshBuffer();
    curImprimir.setValueBuffer("descripcion", "temp");
    curImprimir.setValueBuffer("d_pedidosprov_codigo", codigo);
    curImprimir.setValueBuffer("h_pedidosprov_codigo", codigo);
    flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
    
}

function euromoda_treliminaPedido(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;
	var idPedido = cursor.valueBuffer("idpedido");
	if(!_i.actualizaTramosTejido(idPedido)) {
		return false;
	}
	if(!_i.actualizaBobina(idPedido)) {		
		return false;
	}
	if(!_i.eliminaTransferencia(idPedido)) {		
		return false;
	}
	if(!_i.eliminaPedido(cursor)) {
		return false;
	}
	return true;	
}

/*function euromoda_actualizaTramosTejido(idPedido)
{

	var q = new AQSqlQuery;
	q.setSelect("idlinea");
	q.setFrom("lineaspedidosprov");
	q.setWhere("idpedido = "+ idPedido);
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idLinea = q.value("idlinea");
		var curTramos = new FLSqlCursor("em_tramostejido");		
		curTramos.setActivatedCommitActions(false);
  		curTramos.select("idlineapedacabado = " + idLinea);
  		while (curTramos.next()) {
		
	  		curTramos.setModeAccess(curTramos.Edit);
	  		curTramos.refreshBuffer(); 
	  		curTramos.setNull("idlineapedacabado");  
	  		curTramos.setNull("codbobinaaca");		
	  		curTramos.setNull("soporteaca");
		   if (!curTramos.commitBuffer()) {		   	
		   	return false;
		 	}
		 }
	}		
	return true;
}*/

function euromoda_actualizaTramosTejido(idPedido)
{
	debug("*********************************************************************");
	debug("euromoda_actualizaTramosTejido");
	var _i = this.iface;
	
	var q = new AQSqlQuery;
	q.setSelect("l.idlinea,l.referencia,c.codalmacen,c.codalmaorigen");
	q.setFrom("lineaspedidosprov l inner join pedidosprov c on l.idpedido = c.idpedido");
	q.setWhere("l.idpedido = "+ idPedido);
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idLinea = q.value("l.idlinea");	 
		var curTramos = new FLSqlCursor("em_tramostejido");		
		curTramos.setActivatedCommitActions(false);
  		curTramos.select("idlineapedacabado = " + idLinea);
  		while (curTramos.next()) {
  			curTramos.setModeAccess(curTramos.Browse);
	  		curTramos.refreshBuffer(); 	
			var idTramoV = curTramos.valueBuffer("idtramo");	
			var codBobina = curTramos.valueBuffer("codbobina");			 
			var codPartida =  curTramos.valueBuffer("codpartida");
			var codBobinaAca = curTramos.valueBuffer("codbobinaaca");
			var codSoporteAca = curTramos.valueBuffer("soporteaca");
			var codPartidaOri = curTramos.valueBuffer("codpartidaorigen");
			if (!AQUtil.execSql("UPDATE lotesstock SET codbobina = '" + codBobina + "' WHERE codlote = '" + codPartidaOri + "' ")) {
				return false;
			}
			debug("******************************************");
			debug("codBobina: "+codBobina);
			debug("idTramoV: "+idTramoV);
			debug("codPartida: "+codPartida);
			debug("codBobinaAca: "+codBobinaAca);
			debug("codSoporteAca: "+codSoporteAca);
			debug("******************************************");
			var oParam = new Object;
			oParam.curTB = curTramos;
			oParam.codBobina = codBobina;
			oParam.codPartidaH = codPartida;
			oParam.codBobinaD = codBobina;	
			//oParam.accion = "ACABADO";
			oParam.accion = AQUtil.sqlSelect("em_bobinas","estado","codbobina = '" + codBobina + "'");										
			if(!formem_generarbobinas.iface.quitaTramoBobinaConsu(oParam)) {
				return false;
			}			
		}
		var referencia = q.value("l.referencia");
		var codAlmacen = q.value("c.codalmacen");
		var idStock = AQUtil.sqlSelect("stocks","idstock","referencia = '" + referencia + "' and codalmacen = '" + codAlmacen + "'");
		if(idStock) {
			formregstocks.iface.revisarStock("idstock = " + idStock);
		}
		var codAlmaOri = q.value("c.codalmaorigen");
		var idStockOri = AQUtil.sqlSelect("stocks","idstock","referencia = '" + referencia + "' and codalmacen = '" + codAlmaOri + "'");
		if(idStockOri) {
			formregstocks.iface.revisarStock("idstock = " + idStockOri);
		}
		
	}
	return true;
}

function euromoda_actualizaBobina(idPedido)
{		
	var curBobinas = new FLSqlCursor("em_bobinas");	
	curBobinas.setActivatedCommitActions(false);
	curBobinas.select("idpedidoprov = " + idPedido);
	while (curBobinas.next()) {	
		curBobinas.setModeAccess(curBobinas.Edit);
		curBobinas.refreshBuffer(); 
		curBobinas.setNull("idpedidoprov");
		curBobinas.setNull("codpedidoprov");
		var estadoAct = curBobinas.valueBuffer("estado");
		var estado = "VAPORIZADO";
		if(estadoAct == "REOPERANDO") {
			estado = "PARA REOPERAR"; 	
		}   
		curBobinas.setValueBuffer("estado",estado); 		
		if (!curBobinas.commitBuffer()) {			
			return false;
	 	}
 	} 
	return true;

}

function euromoda_eliminaPedido(cursor)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idPedido = cursor.valueBuffer("idpedido");
	if (idPedido == "" ) 
	{		
		sys.warnMsgBox(sys.translate("No hay ning�n registro seleccionado."));
		return false;
	}
	connect(_i.curP_, "bufferCommited()", _i, "refrescaTabla");
	_i.curP_.setModeAccess(_i.curP_.Del);
	_i.curP_.refreshBuffer();
	if(!_i.curP_.commitBuffer()) {
		sys.warnMsgBox(sys.translate("Se ha producido un error al borrar el registro activo."));
		return false;
	}	
	return true;
}

function euromoda_convertirOrden()
{
	
	var _i = this.iface;
	var cursor = this.cursor()
	var estadoProceso = cursor.valueBuffer("em_estadoproceso");
	var codPedido = cursor.valueBuffer("codigo");
	if(estadoProceso && estadoProceso != "") {
		sys.warnMsgBox(sys.translate("El pedido %1 no puede convertirse en orden ya que ya se ha convertido o el estado est� avanzado.").arg(codPedido));
		return false;
	}
	var idPedido = cursor.valueBuffer("idpedido");
	
	if(!idPedido || idPedido == "") {
		sys.warnMsgBox(sys.translate("No se ha seleccionado ning�n pedido."));		
		return false;
	}
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al convertir el pedido en orden de estampaci�n.");
	oParam.cursorPedido = cursor;
	var f = new Function("oParam", "return formpedidosprov.iface.trConvertirOrden(oParam)");
	if (!sys.runTransaction(f, oParam)) {	
		return false;
	}		
	sys.infoMsgBox(sys.translate("Se ha creado la orden de estampacion %1 a partir del pedido %2.").arg(oParam.codOrden).arg(codPedido));
	return true;
}

function euromoda_trConvertirOrden(oParam)
{

	var _i = this.iface;
	var curPedido = oParam.cursorPedido;
	var idPedido = curPedido.valueBuffer("idpedido");
	_i.cursorOrden_ = new FLSqlCursor("em_ordenesestampacion");
	_i.cursorOrden_.setModeAccess(_i.cursorOrden_.Insert);
	_i.cursorOrden_.refreshBuffer();   
	if (!_i.crearCabeceraOrden(curPedido)) {
		return false;
	}
	if (!_i.cursorOrden_.commitBuffer()) {
		return false;
	}
	var codOrden = _i.cursorOrden_.valueBuffer("codordenest");	
	
	if(!_i.crearLineasOrden(codOrden, idPedido)) {
		return false;
	}
	_i.cursorOrden_.select("codordenest = '" + codOrden + "' ");
	if (!_i.cursorOrden_.first()) {
	    return false;
	}	
	_i.cursorOrden_.setModeAccess(_i.cursorOrden_.Edit);
	_i.cursorOrden_.refreshBuffer();
	if (!_i.crearTotalesOrden(_i.cursorOrden_)) {
		return false;
	}
	if (!_i.cursorOrden_.commitBuffer()) {
		return false;
	}
	
	if (!AQUtil.sqlUpdate("lineaspedidosprov","cerrada",true,"idpedido = " + idPedido)) {
		return false;
	}	
	if (!flfacturac.iface.pub_actualizarEstadoPedidoProv(idPedido)) {
		return false;
	}
	if (!AQUtil.execSql("UPDATE pedidosprov SET em_estadoproceso = '" + codOrden + "' WHERE idpedido = " + idPedido)) {
		return false;
	}
	oParam.codOrden = codOrden;
	return true;
}

function euromoda_crearCabeceraOrden(curPedido)
{
	
	var _i = this.iface;
	var codOrden = formRecordem_ordenesestampacion.iface.calculateCounter();
	_i.cursorOrden_.setValueBuffer("codordenest", codOrden)
	_i.cursorOrden_.setValueBuffer("fecha", curPedido.valueBuffer("fecha"));		
	_i.cursorOrden_.setValueBuffer("descripcion", curPedido.valueBuffer("contactoprov"));			
	_i.cursorOrden_.setValueBuffer("estado", "PTE");	
	_i.cursorOrden_.setValueBuffer("codpedidoprov", curPedido.valueBuffer("codigo"));	
	
	var codPedidoCli = curPedido.valueBuffer("numproveedor");
	if(codPedidoCli && codPedidoCli != "") {
		_i.cursorOrden_.setValueBuffer("codpedidocli", codPedidoCli);
		var codCliente = AQUtil.sqlSelect("pedidoscli", "codcliente", "codigo = '" + codPedidoCli + "'");
		if(codCliente && codCliente != "") {
			var nombreCliente = AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + codCliente + "'");
			_i.cursorOrden_.setValueBuffer("codcliente", codCliente);
			_i.cursorOrden_.setValueBuffer("nombrecliente", nombreCliente);
		}
	}				
	_i.cursorOrden_.setValueBuffer("fechaentrega", curPedido.valueBuffer("fechaentrada"));		
	var observaciones = sys.translate("ESTA ORDEN SUSTITUYE AL PEDIDO %1").arg(curPedido.valueBuffer("codigo"));
	observaciones +="\n\n";
	observaciones +=	curPedido.valueBuffer("observaciones");
	_i.cursorOrden_.setValueBuffer("observaciones", observaciones);		
	
	return true;
}

function euromoda_crearLineasOrden(codOrden, idPedido)
{
	var _i = this.iface;
	
	var i = 1;
	var qLinPP = new AQSqlQuery;	
	qLinPP.setSelect("articulos.codfamilia, articulos.codsubfamilia, lineaspedidosprov.codcolorem, lineaspedidosprov.cantidad, lineaspedidosprov.descripcion, lineaspedidosprov.idlinea,  lineaspedidosprov.codtamanoem, lineaspedidosprov.referencia, di.panotcont, di.coddibujoem, di.coddiseno,di.descripcion, co.descripcion, tt.tamancho, tt.tamlargo");
	qLinPP.setFrom("lineaspedidosprov INNER JOIN articulos ON articulos.referencia = lineaspedidosprov.referencia LEFT OUTER JOIN em_dibujos di ON (articulos.coddibestamp = di.coddibujoem OR articulos.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON lineaspedidosprov.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos tt ON lineaspedidosprov.codtamanoem = tt.codtamanoem");
	qLinPP.setWhere("lineaspedidosprov.idpedido = " + idPedido + " AND lineaspedidosprov.tipoconcepto='Producto' AND lineaspedidosprov.referencia is not null ORDER BY lineaspedidosprov.idlinea"); 			
	if (!qLinPP.exec()){
		return;
	}  
	while(qLinPP.next())
	{
		var curLinOrden = new FLSqlCursor("em_lineasordenest");
    	curLinOrden.setModeAccess(curLinOrden.Insert);
    	curLinOrden.refreshBuffer();	
    	curLinOrden.setValueBuffer("codordenest", codOrden);	
    	curLinOrden.setValueBuffer("grupo",i);
		if(!_i.crearLineaOrden(qLinPP, curLinOrden)) {
			return false;
		}		
		
		i++;
	}
	return true;
}

function euromoda_crearLineaOrden(qLinPP, curLinOrden)
{

	var _i = this.iface;
	
	var referencia = qLinPP.value("lineaspedidosprov.referencia");
	var tejido = qLinPP.value("lineaspedidosprov.descripcion");
	var cantidad = qLinPP.value("lineaspedidosprov.cantidad");
	var panotCont = qLinPP.value("di.panotcont");	
	panotCont = (!panotCont || panotCont == "") ? "N/A" : panotCont;
	
	var codDibujo = qLinPP.value("di.coddibujoem");
	var descDibujo = qLinPP.value("di.descripcion");	
	var tamanchoTej = qLinPP.value("tt.tamancho");
	var tamlargoTej = qLinPP.value("tt.tamlargo");
	var descColor = qLinPP.value("co.descripcion");
	var codDiseno = qLinPP.value("di.coddiseno");
	
	curLinOrden.setValueBuffer("estado", "PTE");
	curLinOrden.setValueBuffer("referencia", referencia);
	//curLinOrden.setValueBuffer("tejido", tejido);
	curLinOrden.setValueBuffer("tejido", formRecordlotesstock.iface.pub_commonCalculateField("articulo", curLinOrden));
	curLinOrden.setValueBuffer("cantidad", cantidad);
	curLinOrden.setValueBuffer("canpendiente",cantidad);
	curLinOrden.setValueBuffer("canestampada",0);
	curLinOrden.setValueBuffer("canrollada",0);
	curLinOrden.setValueBuffer("panotcont", panotCont);						
	curLinOrden.setValueBuffer("coddibujoem", codDibujo);
	curLinOrden.setValueBuffer("descdibujo", descDibujo);
	curLinOrden.setValueBuffer("tamanchotej",tamanchoTej);
	curLinOrden.setValueBuffer("tamlargotej",tamlargoTej);

	curLinOrden.setValueBuffer("desccolor",descColor);
	curLinOrden.setValueBuffer("coddiseno",codDiseno);

	if(!curLinOrden.commitBuffer()) {
		return false;
	}
	return true;
}

function euromoda_crearTotalesOrden(curOrden)
{

	var codOrden = curOrden.valueBuffer("codordenest");	
	
	
	var q = new AQSqlQuery;	
	q.setSelect("distinct(codsubfamilia)");
	q.setFrom("em_lineasordenest INNER JOIN articulos ON em_lineasordenest.referencia = articulos.referencia");
	q.setWhere("codordenest='" + codOrden + "'"); 			
	if (!q.exec()){
		return;
	}  
	var tam = q.size();

	if(tam >1) {
		return true;
	}	
	if(q.first())
	{
		var codSubfamilia = q.value("distinct(codsubfamilia)");
		curOrden.setValueBuffer("codsubfamilia",codSubfamilia);		
		curOrden.setValueBuffer("critagrupacion", "SF"+codSubfamilia);	

	}	
	
	return true;
}

function euromoda_imprimeTransAca(idTrans, cursor)
{
	var _i = this.iface;
	var oParam = _i.dameParamInformeTransAca(idTrans, cursor);
	if (!oParam) {
		return;
	}
	var curImprimir = new FLSqlCursor("em_i_transstockaca");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_em__transstockaca_idtrans", idTrans);
	curImprimir.setValueBuffer("h_em__transstockaca_idtrans", idTrans);
	var seleccion = curImprimir.valueBuffer("id");		
	if (!seleccion) {
	    return;
	}
	
	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
	
}

function euromoda_dameParamInformeTransAca(idTrans, cursor)
{
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "em_i_transstockaca";
	return oParam;
}

function euromoda_eliminaTransferencia(idPedido)
{
	debug("euromoda_eliminaTransferencia");
	var curT = new FLSqlCursor("em_transstockaca");
	curT.select("idpedacabado = "+ idPedido);
	if (curT.first()) {
		curT.setModeAccess(curT.Del);
   	curT.refreshBuffer();  
   	if(!curT.commitBuffer()) {
   		return false;
   	}
	}	
	return true;
} 

/*function euromoda_dameParamInforme(idPedido)
{
	var _i = this.iface;
	var oParam = _i.__dameParamInforme(idPedido);
	if(_i.valorado_) {
		oParam.nombreReport = "i_pedidosprov_v";
	}
	return oParam;
}*/

function euromoda_generarAlbaranParcial(curPedido)
{
	var _i = this.iface;

	_i.numLineaProv_ = 0;

	var idAlbaran = _i.__generarAlbaranParcial(curPedido);
	if (!idAlbaran) {
		return false;
	}

	return idAlbaran;
}

function euromoda_ordenCopiaLineasParcial()
{
	return " ORDER BY numlinea";
}

function euromoda_tbnExportarDatosDist_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(!formalbaranescli.iface.exportarDatosDistCSV(cursor,false)){
		return false;
	}
	return true;

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
