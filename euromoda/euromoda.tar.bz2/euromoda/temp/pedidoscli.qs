
/** @class_declaration euromoda*/
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod		
{
	var pK_;
	var fechasComprobadas_;
	var cambioModoFab_;
	var politicaCostes_;
  function euromoda(context)
  {
    prod(context);
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function calcularTotales()
  {
    return this.ctx.euromoda_calcularTotales();
  }
  function guardaPedido(curLineas)
  {
    return this.ctx.euromoda_guardaPedido(curLineas);
  }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function refrescarLotes()
  {
    return this.ctx.euromoda_refrescarLotes();
  }
  function validateForm(lineas) {
		return this.ctx.euromoda_validateForm(lineas);
	}
	function validaCatServicio() {
		return this.ctx.euromoda_validaCatServicio();
	}
	function guardaDocumentoCommit(curLineas)
  {
    return this.ctx.euromoda_guardaDocumentoCommit(curLineas);
  }
	function pushButtonNext_clicked() {
    	return this.ctx.euromoda_pushButtonNext_clicked();
  	}
	function comprobarFechas() {
    	return this.ctx.euromoda_comprobarFechas();
  	}
  	function controlReservasPedidoProd() {
		return this.ctx.euromoda_controlReservasPedidoProd();
	}
	function controlReservasLineaPedidoProd(idLinea, referencia) {
		return this.ctx.euromoda_controlReservasLineaPedidoProd(idLinea, referencia);
	}
	function ocultarCamposContabilidad() {
		return this.ctx.euromoda_ocultarCamposContabilidad();
	}
	function pbnEmModoFab_clicked() {
		return this.ctx.euromoda_pbnEmModoFab_clicked();
}
	function pbnImportarCSV_clicked() {
		return this.ctx.euromoda_pbnImportarCSV_clicked();
   }
	function activarModoFab() {
		return this.ctx.euromoda_activarModoFab();
	}
	function validaModoOperacion() {
		return this.ctx.euromoda_validaModoOperacion();
}
	function cambiarReservasPedido(idPedido) {
		return this.ctx.euromoda_cambiarReservasPedido(idPedido);
	}
	function tbnEmRegenerarCostes_clicked() {
		return this.ctx.euromoda_tbnEmRegenerarCostes_clicked();
	}
 	function tbnEmCargarCostes_clicked() {
 		return this.ctx.euromoda_tbnEmCargarCostes_clicked();
 	}
 	function importarDatosCSV(cursor) {
 		return this.ctx.euromoda_importarDatosCSV(cursor);
 	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
  var cursor = this.cursor();
  var _i = this.iface;
  switch (fN) {
    case "codpago": {
      _i.__bufferChanged(fN);
      sys.setObjText(this, "fdbPorDtoEsp", _i.calculateField("pordtoesp_fp"));
      break;
    }
    case "codcliente": {
      _i.__bufferChanged(fN);
      sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
      flfacturac.iface.pub_controlRiesgoCliente(cursor.valueBuffer("codcliente"), false);
      this.child("lblDirFacturacion").text = _i.calculateField("dirfacturacion");
			formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",cursor.valueBuffer("codcliente"));
			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",cursor.valueBuffer("codcliente"));	
      break;
    }
		case "fechasalida": {
			sys.setObjText(this, "fdbFechaServicio", _i.calculateField("fechaservicio"));
			break;
		}
		case "em_modofabricacion": {
			_i.activarModoFab();
			break;
		}
    default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_calcularTotales()
{
debug("euromoda_calcularTotales");
  var _i = this.iface;
  
  _i.guardaDocumentoCommit();
  
  this.child("fdbFechaServicio").setValue(_i.calculateField("fechaservicio"));
  _i.__calcularTotales();

  //_i.guardaPedido(this.child("tdbLineasPedidosCli").cursor());
}

function euromoda_guardaPedido(curLineas)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var pk = cursor.valueBuffer("idpedido");
  var commitLineas = (cursor.transactionLevel() == 2);
  if (curLineas == undefined) {
    commitLineas = false;
  }

  if (cursor.modeAccess() != cursor.Edit) {
    return true;
  }

  if (!_i.validateForm(true)) {
    return false;
  }

  var indice = cursor.atFrom();
  if (!cursor.commitBuffer()) {
    return false;
  }

  if (commitLineas)
    curLineas.commit();
  if (!cursor.commit()) {
    if (commitLineas)
      curLineas.transaction(false);
    return false;
  }

  if (!cursor.transaction(false)) {
    if (commitLineas)
      curLineas.transaction(false);
    return false;
  }
  if (commitLineas)
    curLineas.transaction(false);

  if (!cursor.seek(indice)) {
    return false;
  }

  cursor.setModeAccess(cursor.Edit);
  cursor.refreshBuffer();
	if (cursor.valueBuffer("idpedido") != pk) {
		cursor.select("idpedido = " + pk);
		if (!cursor.first()) {
			sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
			return false;
		}	  	
  }

  return true;
}

function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
	var cursor = this.cursor();

	formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",cursor.valueBuffer("codcliente"));
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",cursor.valueBuffer("codcliente"));	
	connect(this.child("tbnEmRegenerarCostes"), "clicked()", _i, "tbnEmRegenerarCostes_clicked");
 	connect(this.child("tbnEmCargarCostes"), "clicked()", _i, "tbnEmCargarCostes_clicked");

	disconnect(this.child("tdbLineasPedidosCli").cursor(), "bufferCommited()", this, "iface.calcularTotales()");
	connect(this.child("tdbLineasPedidosCli").cursor(), "commited()", _i, "calcularTotales");
	
	_i.pK_ = cursor.valueBuffer(cursor.primaryKey());
	//connect(this.child("tdbLineasPedidosCli").cursor(), "commited()", _i, "guardaDocumentoCommit()");
	
	
  this.child("lblDirFacturacion").text = _i.calculateField("dirfacturacion");
  _i.fechasComprobadas_ = false;
  
  /*
  	if (this.child("pushButtonNext")) {
	  	disconnect(this.child("pushButtonNext"), "clicked()", _i, "nextRecord");
  		connect(this.child("pushButtonNext"), "clicked()", _i, "pushButtonNext_clicked");
  	}
  */
	_i.cambioModoFab_ = false;
	connect(this.child("pbnEmModoFab"), "clicked()", _i, "pbnEmModoFab_clicked");
	connect(this.child("pbnImportarCSV"), "clicked()", _i, "pbnImportarCSV_clicked");
  	_i.activarModoFab();
  	if(this.child("tbnCambiarAlmacen")) {
  		this.child("tbnCambiarAlmacen").close();
  	}
}

function euromoda_pushButtonNext_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var curMaestro = formpedidoscli.cursor();
	
	if (!curMaestro.next()) {
	debug("Primero");
		curMaestro.first();
	}
	var id = cursor.valueBuffer(cursor.primaryKey());
	var idM = curMaestro.valueBuffer(cursor.primaryKey());
	
	if (!_i.validateForm(true)) {
      return;
    }
    debug("Validado");
    if (!cursor.checkIntegrity()) {
    	return false;
    }
    debug("Chequeado");
  	//_i.acceptedForm();
  	cursor.setActivatedCheckIntegrity(false);
  	if (!cursor.commitBuffer()) {
    debug("! Commit");
      	return false;
	}
	cursor.setActivatedCheckIntegrity(true);
    cursor.commit();
    
	var filtro = cursor.primaryKey() + " IN (" + id + ", " + idM + ") ORDER BY " + cursor.primaryKey();
	debug("Filtro " + filtro);
    cursor.select(filtro);
	if (!cursor.first()) {
	debug("No hay first");
		return false;
	}	
	cursor.next();
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
	
//	cursor.setMainFilter(filtro);
debug("Va el nextrecord!");
//	this.obj().nextRecord();
	return;
	connect (cursor, "commited()", formpedidoscli.iface, "toolButtonEdit_clicked");
	this.child("pushButtonAccept").animateClick();
//	sys.processEvents();
//	formpedidoscli.iface.accionCursorExterno("edit");
	return;
	debug("Siguiente");
	var pK = curMaestro.primaryKey();
	var idMaestro = curMaestro.valueBuffer(pK);
	debug("Busco " + pK + " = " + idMaestro);
	cursor.	select(pK + " = " + idMaestro);
	/*
	if (!cursor.next()) {
		return false;
	}
	*/
	if (!_i.validateForm(true)) {
      return;
    }
    debug("Validado");
    if (!cursor.checkIntegrity()) {
    	return false;
    }
    debug("Chequeado");
  	//_i.acceptedForm();
  	cursor.setActivatedCheckIntegrity(false);
  	if (!cursor.commitBuffer()) {
    debug("! Commit");
      	return false;
	}
	cursor.setActivatedCheckIntegrity(true);
    cursor.commit();
    
    cursor.setModeAccess(cursor.Edit);
   	cursor.transaction(false);
    debug("Tx abierta");
    if (cursor.first()) {
    	debug("First");
	} else {
		debug("!First");
	}
	this.setCursor(cursor);
	this.show();
    cursor.setModeAccess(cursor.Edit);
    cursor.refreshBuffer();
    cursor.refresh();
    cursor.refresh("nombrecliente");
    debug("Init va");
    this.obj().initForm();
    /*
    var w = this.mainWidget();
    this.setMainWidget(0);
	this.setMainWidget(w);
	this.show();
    _i.init();
    */
}

function euromoda_refrescarLotes()
{
	var cursor = this.cursor();

	var qryLotes = new AQSqlQuery();
	qryLotes.setSelect("ls.codlote");
	qryLotes.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion");
	qryLotes.setWhere("op.codpedidocli = '" + cursor.valueBuffer("codigo") + "'");
	qryLotes.setForwardOnly(true);
	if (!qryLotes.exec()) {
		return;
	}
	var listaLotes = "";
	while (qryLotes.next()) {
		if (listaLotes != "")
			listaLotes += ", "
		listaLotes += "'" + qryLotes.value("ls.codlote") + "'";
	}
	if (listaLotes && listaLotes != "")
		this.child("tdbLotesStock").cursor().setMainFilter("codlote IN (" + listaLotes + ")");
	else
		this.child("tdbLotesStock").cursor().setMainFilter("1 = 2");

	this.child("tdbLotesStock").refresh();
}

function euromoda_validateForm(lineas)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.validaCatServicio()) {
		return false;
	}
	if(!_i.validaModoOperacion()) {
		return false;
	}
	if (!lineas) {		
		if(!_i.comprobarFechas()) {
			return false;
		}
		if(!formRecordpresupuestoscli.iface.pub_evaluarCostesCab(cursor)) { 
			return false;
		}
	}
	_i.__calcularTotales();
	if (!_i.controlReservasPedidoProd()) {
		sys.warnMsgBox(sys.translate("Error al asignar las l�neas de pedido a lotes de producci�n pendientes de fabricaci�n"));
		return false;
	}
		
	return true;		
}
	
function euromoda_comprobarFechas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if(!_i.fechasComprobadas_){
		if(cursor.valueBuffer("fechasalida")<cursor.valueBuffer("fecha")){
				//pregunto la primera vez
			var mensaje = MessageBox.warning(sys.translate("Atenci�n!!, ha indicado como fecha de cliente una inferior a la del documento, debe corregirla. \n�desea continuar sin corregirlo?"), MessageBox.Yes, MessageBox.No);
			if (mensaje!=MessageBox.Yes){
				return false;
			}
					//pregunto una segunda vez
			var mensaje2 = MessageBox.warning(sys.translate("Creemos que es un error que contin�e con esta fecha de cliente\n�desea continuar?"), MessageBox.Yes, MessageBox.No);
			if (mensaje2!=MessageBox.Yes){
				return false;
			}
		}
	}
	_i.fechasComprobadas_ = true;
	
	return true;
}

		
function euromoda_validaCatServicio()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var catServicio = cursor.valueBuffer("emcatservicio");
	catServicio = isNaN(catServicio) ? 0 : catServicio;
	if (catServicio < 0 || catServicio > 100) {
		sys.warnMsgBox(sys.translate("La categor�a de servicio debe estar comprendida entre 0 y 100"));
		return false;
	}
	return true;
}

function euromoda_guardaDocumentoCommit()
{
debug("euromoda_guardaDocumentoCommit");
	var _i = this.iface;
  	var cursor = this.cursor();

  	if (cursor.modeAccess() != cursor.Edit) {
    	return true;
  	}
debug("euromoda_guardaDocumentoCommit 2");
  	var pk = cursor.valueBuffer(cursor.primaryKey());
  	formpedidoscli.iface.pK_ = cursor.valueBuffer("codigo");

  	if (!_i.validateForm(true)) {
    	return false;
  	}
debug("euromoda_guardaDocumentoCommit 3");

  	if (!cursor.commitBuffer()) {
    	return false;
  	}
debug("euromoda_guardaDocumentoCommit 4");


  	cursor.commit();
  	cursor.transaction(false);

   	cursor.select(cursor.primaryKey() + " = " + _i.pK_);
	if (!cursor.first()) {
		sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
		return false;
	}
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
debug("euromoda_guardaDocumentoCommit OK");

}

function euromoda_controlReservasPedidoProd()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var qL = new AQSqlQuery;
	qL.setSelect("lp.idlinea, ms.reservapr, lp.referencia");
	qL.setFrom("lineaspedidoscli lp INNER JOIN movistock ms ON lp.idlinea = ms.idlineapc");
	qL.setWhere("lp.idpedido = " + cursor.valueBuffer("idpedido") + " AND ms.reservapr > 0 AND NOT ms.forzarafaltas");
	if (!qL.exec()) {
		return false;
	}
	var estado;
	while (qL.next()) {
		estado = _i.controlReservasLineaPedidoProd(qL.value("lp.idlinea"), qL.value("lp.referencia"));
		if (!estado) {
			return false;
		}
		debug("Estado " + estado);
		if (estado == "REVISAR") {
			if (!flfactalma.iface.revisaReservasPedidoProd(qL.value("lp.idlinea"), false)) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_controlReservasLineaPedidoProd(idLinea, referencia)
{
	var _i = this.iface;
debug("idLinea " + idLinea);
	var reservaPR = AQUtil.sqlSelect("movistock", "reservapr", "idlineapc = " + idLinea);
	debug("reservaPR  " + reservaPR );
	reservaPR = isNaN(reservaPR) ? 0 : reservaPR;
	debug("reservaPR  " + reservaPR );
	if (!reservaPR) {
		return "OK";
	}
	if (!flfactalma.iface.borraReservasPedidoProd(idLinea)) {
		return false;
	}
	
	//var yaReservadoRx = AQUtil.sqlSelect("em_reservaslotepedido rlp INNER JOIN lotesstock ls ON rlp.codlote = ls.codlote INNER JOIN movistock ms ON ls.codlote = ms.codlote LEFT OUTER JOIN em_reservaspterx rpr ON ms.idmovimiento = rpr.idmovpterx", "SUM(rpr.cantidad)", "rlp.idlineapc = " + idLinea + " AND ms.estado = 'PTE' AND ms.cantidad > 0", "lotesstock");
	var yaReservadoRx =  AQUtil.sqlSelect("movistock mres INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva INNER JOIN movistock mpterx ON rpr.idmovpterx = mpterx.idmovimiento", "SUM(rpr.cantidad)", "mres.idlineapc = " + idLinea + " AND mpterx.estado = 'PTE'", "movistock");
	yaReservadoRx = isNaN(yaReservadoRx) ? 0 : yaReservadoRx;
	
	var porReservar = reservaPR - yaReservadoRx;
	debug("porReservar  " + porReservar );
	if (!porReservar) {
		return "OK_SIN_DIS_PTE_RX";
	}
	
	var qR = new AQSqlQuery;
	qR.setSelect("ls.codlote, ms.cantidad, SUM(rpr.cantidad)");
	qR.setFrom("lotesstock ls INNER JOIN movistock ms ON ls.codlote = ms.codlote LEFT OUTER JOIN em_reservaspterx rpr ON ms.idmovimiento = rpr.idmovpterx");
	qR.setWhere("ms.estado = 'PTE' and ms.cantidad > 0 AND ls.referencia = '" + referencia + "' GROUP BY ls.codlote, ms.cantidad ORDER BY codlote");
	if (!qR.exec()) {
		return false;
	}
debug(qR.sql());
	var enReservaPr, disponibleRx, cantidad;
	var estado = "OK";
	while (qR.next() && porReservar > 0) {
		enReservaPr = qR.value("SUM(rpr.cantidad)");
		enReservaPr = isNaN(enReservaPr) ? 0 : enReservaPr;
		
		disponibleRx = qR.value("ms.cantidad") - enReservaPr;
		disponibleRx = isNaN(disponibleRx) ? 0 : disponibleRx;
		
		if (disponibleRx > 0) {
			cantidad = Math.min(disponibleRx, porReservar);
			if (!AQSql.insert("em_reservaslotepedido", ["idlineapc", "codlote", "cantidad"], [idLinea, qR.value("ls.codlote"), cantidad])) {
				return false;
			}
			estado = "REVISAR";
		}
	debug("Next " + qR.value("ls.codlote"));
		porReservar -= disponibleRx;
	}
	return estado;
}

function euromoda_ocultarCamposContabilidad()
{
	return true;
}

function euromoda_pbnEmModoFab_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idPedido = cursor.valueBuffer("idpedido");

	//1 select * from em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovreserva  = movistock.idmovimiento INNER JOIN lineaspedidoscli ON movistock.idlineapc = lineaspedidoscli.idlinea I where lineaspedidoscli.idpedido = 134291; orden de produccion

	//2  select * from em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovreserva  = movistock.idmovimiento INNER JOIN movistock ms2 ON (movistock.idmovproducto = ms2.idmovimiento OR movistock.idmovimiento = ms2.idmovimiento) INNER JOIN lineaspedidoscli ON ms2.idlineapc = lineaspedidoscli.idlinea WHERE lineaspedidoscli.idpedido = 134292;	


	var resOrden = AQUtil.sqlSelect("em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovreserva  = movistock.idmovimiento INNER JOIN lineaspedidoscli ON movistock.idlineapc = lineaspedidoscli.idlinea","count(*)","lineaspedidoscli.idpedido = " + idPedido,"em_reservaspterx,movistock");

	if(!resOrden || resOrden == 0) {
		resOrden = AQUtil.sqlSelect("em_reservaspterx INNER JOIN movistock ON em_reservaspterx.idmovreserva  = movistock.idmovimiento INNER JOIN movistock ms2 ON (movistock.idmovproducto = ms2.idmovimiento OR movistock.idmovimiento = ms2.idmovimiento) INNER JOIN lineaspedidoscli ON ms2.idlineapc = lineaspedidoscli.idlinea","count(*)","lineaspedidoscli.idpedido = " + idPedido,"em_reservaspterx,movistock");

	}   
	if(resOrden && resOrden >0) {
		var res = flfactppal.iface.preguntaMsg(sys.translate("Hay �rdenes de producci�n/estampaci�n lanzadas\n�Est� seguro de que quiere cambiar las reservas?"),"info",this,MessageBox.Yes, MessageBox.No);  
  		if (res != MessageBox.Yes) {  			
			return false;
  		}
  		flfactppal.iface.ponMsgError(sys.translate("Este proceso puede tardar unos minutos, por favor, no cierre AbanQ, Pulse OK para continuar"),"info",this);
  		
	}
	if(!_i.cambiarReservasPedido(idPedido)) {
		return false;
	}
	_i.cambioModoFab_ = false;
	sys.disableObj(this, "pbnEmModoFab");
	return true;
}

function euromoda_activarModoFab()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var modoFab = cursor.valueBuffer("em_modofabricacion");
	var modoFabCopy = cursor.valueBufferCopy("em_modofabricacion"); 
	var numLineas = this.child("tdbLineasPedidosCli").cursor().size();
	if(modoFab != modoFabCopy && numLineas && numLineas>0) {
		sys.enableObj(this, "pbnEmModoFab");
		_i.cambioModoFab_ = true;
	} else {
		sys.disableObj(this, "pbnEmModoFab");
	}
}

function euromoda_validaModoOperacion()
{
	var _i = this.iface;
	if(_i.cambioModoFab_) {
		flfactppal.iface.ponMsgError(sys.translate("No puede guardar el pedido sin aplicar el modo de fabricaci�n en la pesta�a Producci�n"),"warn",this);		
		return false;
	}
	return true;
}

function euromoda_cambiarReservasPedido(idPedido) 
{
	var _i = this.iface;
	var cursor = this.cursor();
	var modoFab = cursor.valueBuffer("em_modofabricacion");
	/*var q = new AQSqlQuery;	
	q.setSelect("idlinea");
	q.setFrom("em_ordenesestampacion");
	q.setWhere("codmaquinaest = '" + _i.codMaquina_ + "' AND estado IN ('PTE', 'EN CURSO') AND ordenest >= " + ordenCola); 			
	q.setOrderBy
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var estado = q.value("estado");
		var codOrden = q.value("codordenest");		
	}	*/

	

	var curLineas = new FLSqlCursor("lineaspedidoscli");
	curLineas.select("idpedido = " + idPedido);
	while (curLineas.next()) {
		curLineas.setModeAccess(curLineas.Edit);
		curLineas.refreshBuffer();

		switch(modoFab) {
			case "Forzar a faltas": {
				curLineas.setValueBuffer("forzarafaltas", true);
				curLineas.setValueBuffer("agotarexistencias", false);
				break;
			}
			case "Agotar disponible de existencias (resto a faltas)": {
				curLineas.setValueBuffer("agotarexistencias" , true);
				curLineas.setValueBuffer("forzarafaltas", false);
				break
			}
			default: {
				curLineas.setValueBuffer("agotarexistencias" , false);
				curLineas.setValueBuffer("forzarafaltas", false);
				break;
			}
		}
		if(!curLineas.commitBuffer()) {
			return false;
		}

	}	
	flfactppal.iface.ponMsgError(sys.translate("L�neas del pedido cambiadas al modo de fabricaci�n %1").arg(modoFab),"info",this);
	return true;
}

function euromoda_tbnEmRegenerarCostes_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	//Permite regenerar los costes y m�rgenes de as l�neas. Esto supone borrar los actuales y volver a cargar sin dar avisos.
	
	var curLineas =  this.child("tdbLineasPedidosCli").cursor();
	formRecordpresupuestoscli.iface.pub_actualizaCostes(cursor,curLineas,true);
    this.child("tdbLineasPedidosCli").refresh();
}

function euromoda_tbnEmCargarCostes_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	//Permite regenerar los costes y m�rgenes de as l�neas. Esto supone borrar los actuales y volver a cargar sin dar avisos.
	var curLineas =  this.child("tdbLineasPedidosCli").cursor();
	formRecordpresupuestoscli.iface.pub_actualizaCostes(cursor,curLineas,false);
    this.child("tdbLineasPedidosCli").refresh();

}

function euromoda_pbnImportarCSV_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbLineasPedidosCli").cursor().commitBufferCursorRelation())
			return false;
	}

	
	if(!_i.importarDatosCSV(cursor)){
		return false;
	}
	_i.calcularTotales();
	this.child("tdbLineasPedidosCli").refresh();	
	return true;

}

function euromoda_importarDatosCSV(cursor)
{

	var idTipoDoc;
	var codCliente = "";
	var tipoDoc = cursor.table();
	if(tipoDoc == "pedidosprov") {
		idTipoDoc = cursor.valueBuffer("idpedido");
	} else {
		if(tipoDoc == "presupuestoscli") {
			idTipoDoc = cursor.valueBuffer("idpresupuesto");
		} else if(tipoDoc == "pedidoscli") {
			idTipoDoc = cursor.valueBuffer("idpedido");
		} else if(tipoDoc == "albaranescli") {
			idTipoDoc = cursor.valueBuffer("idalbaran");
		} else if(tipoDoc == "facturascli") {
			idTipoDoc = cursor.valueBuffer("idfactura");
		}
		codCliente = cursor.valueBuffer("codcliente");		 
	}
	
	var codificacion = "ANSI";
	var separador = ";";
	var simboloDecimal = ".";
	var expCabecera = true;
	var impDecimales = true;
	var numDecimalesImp = 2;
	var cantSinDecimales = true;
	var conMillares = false;
	var nombreFichero = "";

	var f = new FLFormSearchDB("em_importarcsv");
  	var curO = f.cursor();
  	curO.setModeAccess(curO.Insert);
  	curO.refreshBuffer();	

  	curO.setValueBuffer("tipodoc",tipoDoc);
  	curO.setValueBuffer("iddocumento",idTipoDoc);
  	curO.setValueBuffer("codificacion",codificacion);
  	curO.setValueBuffer("separador",separador);
  	curO.setValueBuffer("simbolodecimal",simboloDecimal);
  	curO.setValueBuffer("expcabecera",expCabecera);
  	curO.setValueBuffer("impdecimales",impDecimales);
  	curO.setValueBuffer("numdecimalesimp",numDecimalesImp);
  	curO.setValueBuffer("cantsindecimales",cantSinDecimales);
  	curO.setValueBuffer("conmillares",conMillares);
  	curO.setValueBuffer("codcliente",codCliente);

  	f.setMainWidget();
   	f.exec();
  	if (!f.accepted()) {   		
        return false;
    }
    return curO;
}

//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
