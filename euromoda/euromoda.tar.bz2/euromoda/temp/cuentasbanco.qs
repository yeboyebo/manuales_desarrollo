
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function iniciaSaldo() {
		return this.ctx.euromoda_iniciaSaldo();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	_i.iniciaSaldo()
}

function euromoda_iniciaSaldo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codEjercicio = flfactppal.iface.pub_ejercicioActual();
	var sI = formRecordco_subcuentas.iface.pub_calculaSaldoInicial(cursor.valueBuffer("codsubcuenta"), codEjercicio);
	sys.setObjText(this, "lblSaldoInicial", sys.translate("Saldo inicial %1: %2").arg(codEjercicio).arg(sI));
	
	if (this.child("tdbPartidas")) {
		this.child("tdbPartidas").refresh();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
