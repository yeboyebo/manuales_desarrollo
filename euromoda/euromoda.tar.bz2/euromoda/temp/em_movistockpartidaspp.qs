/***************************************************************************
                 em_movistockpartidaspp.qs  -  description
                             -------------------
    begin                : lun may 28 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
	function calculateField(fN) {
		return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
	function formReady() {
		return this.ctx.interna_formReady();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var canRecibida_;
	function oficial( context ) { interna( context ); } 
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function validaLote() {
		return this.ctx.oficial_validaLote();
	}
	function validaCantidadLote() {
		return this.ctx.oficial_validaCantidadLote();
	}
	function iniciaValores() {
		return this.ctx.oficial_iniciaValores();
	}
	function filtroPartidas() {
		return this.ctx.oficial_filtroPartidas();
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function ponConcepto() {
		return this.ctx.oficial_ponConcepto();
	}
	function validaPartida() {
		return this.ctx.oficial_validaPartida();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
	function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
}
const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this, "formReady()", _i, "formReady");
	
	_i.canRecibida_ = _i.calculateField("canrecibida");
	_i.iniciaValores();
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch(fN) {
		case "cantidad": {
			valor = cursor.valueBuffer("canpedida") - _i.canRecibida_;
			valor = valor < 0 ? 0 : valor; /// No ha que pedir negativos. Esto afecta al stock pendiente de servir desde pedidos de compra, lo que no tiene sentido
			break;
		}
		case "referencia_pedido": {
			valor = cursor.cursorRelation().valueBuffer("referencia");
			break;
		}
		case "idstock_pedido": {
			var referencia = cursor.cursorRelation().valueBuffer("referencia");
			var curAlbaran = cursor.cursorRelation().cursorRelation();
			var codAlmacen = curAlbaran.valueBuffer("codalmacen");
			var oArticulo = new Object;
			oArticulo.referencia = referencia;
			valor = flfactalma.iface.pub_dameIdStock(codAlmacen, oArticulo);
			break;
		}
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function interna_formReady()
{
	var _i = this.iface;
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (!_i.ponConcepto()) {
		return false;
	}
	if (!_i.validaPartida()) {
		return false;
	}

// 	if (!_i.validaLote()) {
// 		return false;
// 	}
// 	if (!_i.validaCantidadLote()) {
// 		return false;
// 	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_ponConcepto()
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (cursor.modeAccess()) {
		case cursor.Edit:
		case cursor.Insert: {
			var codPedido = cursor.cursorRelation().cursorRelation().valueBuffer("codigo");
			cursor.setValueBuffer("concepto", sys.translate("Pedido proveedor %1").arg(codPedido));
			break;
		}
	}
	return true;
}
function oficial_iniciaValores()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var curR = cursor.cursorRelation();
	
	this.child("fdbReferencia").setDisabled(true);
	this.child("fdbIdStock").setDisabled(true);
	sys.disableObj(this, "fdbCantidad");
	
	switch(cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbReferencia", _i.calculateField("referencia_pedido"));
			sys.setObjText(this, "fdbIdStock", _i.calculateField("idstock_pedido"));
			var hoy = new Date;
			sys.setObjText(this, "fdbFechaPrev", hoy);
			cursor.setValueBuffer("estado", "PTE");
			break;
		}
		case cursor.Edit: {
			if (!cursor.isNull("codpartida")) {
				sys.disableObj(this, "fdbCodPartida");
			}
			break;
		}
	}
	this.child("fdbCodPartida").setFilter(_i.filtroPartidas());
}

function oficial_filtroPartidas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codAlmacen = cursor.cursorRelation().cursorRelation().valueBuffer("codalmaorigen");
  if (!codAlmacen) {
    codAlmacen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
  }
  var cantidad = cursor.valueBuffer("canpedida");
  cantidad = isNaN(cantidad) ? 0 : cantidad;
  var filtro = "codalmacen = '" + codAlmacen + "' AND NOT distribucionfin AND mptedist > 0";
	return filtro;
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch(fN) {
		case "codlote": {
// 			sys.setObjText(this, "fdbCantidad", _i.calculateField("disponiblelote"));
			break;
		}
		case "canpedida": {
			sys.setObjText(this, "fdbCantidad", _i.calculateField("cantidad"));
			break;
		}
	}
}

function oficial_validaLote()
{
	return true;
	
	/// Copiado de movistockalbaranes
	var _i = this.iface;
	var cursor = this.cursor();
	var codLote = cursor.valueBuffer("codlote");
	if (!codLote || codLote == "") {
		MessageBox.warning(sys.translate("Debe indicar un lote"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var refLote = AQUtil.sqlSelect("lotesstock", "referencia", "codlote = '" + codLote + "'");
	if (refLote != refLote) {
		MessageBox.warning(sys.translate("La referencia del lote no coincide con la del movimiento"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function oficial_validaCantidadLote()
{
	return true; 
	
	/// Copiado de movistockalbaranes
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codLote = cursor.valueBuffer("codlote");
	var cantidad = cursor.valueBuffer("cantidad");
	var disponible = AQUtil.sqlSelect("lotesstock", "candisponible", "codlote = '" + codLote + "'");
	if (codLote == cursor.valueBufferCopy("codlote")) {
		disponible -= parseFloat(cursor.valueBufferCopy("cantidad"));
	}
	if (cantidad > disponible) {
		MessageBox.warning(sys.translate("La cantidad supera el disponible del lote seleccionado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "canrecibida": {
			var codPartida = cursor.valueBuffer("codpartida");
			if (codPartida && codPartida != "") {
				valor = AQUtil.sqlSelect("lineasalbaranesprov la INNER JOIN movistock ms ON la.idlinea = ms.idlineaap", "SUM(ms.cantidad)", "la.idlineapedido = " + cursor.valueBuffer("idlineapp") + " AND estado = 'HECHO' AND ms.codpartida = '" + cursor.valueBuffer("codpartida") + "'", "lineasalbaranesprov");
			} else {
				valor = AQUtil.sqlSelect("lineasalbaranesprov la INNER JOIN movistock ms ON la.idlinea = ms.idlineaap", "SUM(ms.cantidad)", "la.idlineapedido = " + cursor.valueBuffer("idlineapp") + " AND estado = 'HECHO' AND ms.codpartida IS NULL", "lineasalbaranesprov");
			}
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
	}
	return valor;
}

function oficial_validaPartida()
{
	debug("oficial_validaPartida");
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codPartida = cursor.valueBuffer("codpartida");
debug("codPartida " + codPartida);
	if (codPartida && codPartida != "") {
		if (AQUtil.sqlSelect("movistock", "idmovimiento", "idlineapp = " + cursor.valueBuffer("idlineapp") + " AND codpartida = '" + codPartida + "' AND idmovimiento <> " + cursor.valueBuffer("idmovimiento"))) {
			sys.warnMsgBox(sys.translate("Ya hay un movimiento para la partida %1\nModifique la cantidad de dicho movimiento.").arg(codPartida));
			return false;
		}
	} else {
		if (AQUtil.sqlSelect("movistock", "idmovimiento", "idlineapp = " + cursor.valueBuffer("idlineapp") + " AND codpartida IS NULL AND idmovimiento <> " + cursor.valueBuffer("idmovimiento"))) {
			sys.warnMsgBox(sys.translate("Ya hay un movimiento sin partida asignada.\nModifique la cantidad de dicho movimiento."));
			return false;
		}
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
