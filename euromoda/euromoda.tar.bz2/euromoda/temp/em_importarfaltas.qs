/***************************************************************************
                 em_filtrosarticulos.qs  -  description
                             -------------------
    begin                : mie nov 23 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	var numLinea_;
	var t_;
	var cSEL_, cREF_, cEAN_, cDES_, cCODTAMA_, cCODCOLOR_, cCAN_, cBLANCO_, cCANPED_, cCANREX_, cCANPRX_, cCANAFAL_, cSEXIS_, cSRES_, cSDIS_, cSPTEREC_, cSRESPTEREC_, cSAFALTA_, cSMIN_, cSMAX_, cColorSel_, cColorNoSel_, cColorCan_, cColorPedidos_, cColorStocks_, cDISPROV_, cColorDisProv_;      
	function oficial(context)
	{
		interna(context);
	}
	function iniciarTabla() {
		return this.ctx.oficial_iniciarTabla();
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function construirFiltro(cursor) {
		return this.ctx.oficial_construirFiltro(cursor);
	}
	function tbnLimpiarFiltro_clicked() {
		return this.ctx.oficial_tbnLimpiarFiltro_clicked();
	}
	function limpiarFiltro(form) {
		return this.ctx.oficial_limpiarFiltro(form);
	}
	function tbnBuscar_clicked() {
		return this.ctx.oficial_tbnBuscar_clicked();
	}
	function buscar(cursor) {
		return this.ctx.oficial_buscar(cursor);
	}
	function dameCantidad(fila, opcion) {
		return this.ctx.oficial_dameCantidad(fila, opcion);
	}
  	function colores() {
  		return this.ctx.oficial_colores();
  	}
  	function tblLineas_clicked(f, c) {
  		return this.ctx.oficial_tblLineas_clicked(f, c);
  	}
  	function tbnTodosSel_clicked() {
		return this.ctx.oficial_tbnTodosSel_clicked();
	}
	function tbnNingunoSel_clicked() {
		return this.ctx.oficial_tbnNingunoSel_clicked();
	}
	function colSelClicked(f) {
		return this.ctx.oficial_colSelClicked(f);
	}
	function trImportarLineas(cursor) {
		return this.ctx.oficial_trImportarLineas(cursor);
	}
	function crearLinea(idPedido,fila) {
		return this.ctx.oficial_crearLinea(idPedido,fila);
	}
	function habilitaciones() {
		return this.ctx.oficial_habilitaciones();
	}
	function dameCantDisProv(fila, codProveedor) {
		return this.ctx.oficial_dameCantDisProv(fila, codProveedor);
	}
	function dameColorCantidad(fila) {
		return this.ctx.oficial_dameColorCantidad(fila);
	}
	function tblLineas_valueChanged(f, c) {
    	return this.ctx.oficial_tblLineas_valueChanged(f, c);
  	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
	function head(context)
	{
		oficial(context);
	}
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
	function ifaceCtx(context)
	{
		head(context);
	}
	function pub_construirFiltro(cursor) {
		return this.construirFiltro(cursor);
	}
	function pub_limpiarFiltro(form) {
		return this.limpiarFiltro(form);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.t_ = this.child("tblLineas");
	connect(this.cursor(), "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");

	connect(this.child("tbnTodosSel"), "clicked()", _i, "tbnTodosSel_clicked()");
	connect(this.child("tbnNingunoSel"), "clicked()", _i, "tbnNingunoSel_clicked()");
	connect(_i.t_, "doubleClicked(int, int)", _i, "tblLineas_clicked");
	connect(_i.t_, "valueChanged(int, int)", _i, "tblLineas_valueChanged");

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked()");
	
	connect(this.child("tbnBuscar"), "clicked()", _i, "tbnBuscar_clicked");
	_i.colores();
	_i.iniciarTabla();
	_i.habilitaciones();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciarTabla()
{
	var _i = this.iface;

	var c = 0, cH = [];

	_i.cSEL_ = c++;
	_i.cREF_ = c++;
	_i.cEAN_ = c++;
	_i.cDES_ = c++;
	_i.cCODTAMA_ = c++; 
	_i.cCODCOLOR_ = c++;
	_i.cCAN_ = c++;
	_i.cBLANCO_ = c++;
	_i.cDISPROV_ = c++;
	_i.cSEXIS_ = c++; 
	_i.cSRES_ = c++;
	_i.cSDIS_ = c++;
	_i.cSPTEREC_ = c++;
	_i.cSRESPTEREC_ = c++;
	_i.cSAFALTA_ = c++;
	_i.cSMIN_ = c++;
	_i.cSMAX_ = c++;
	_i.cCANPED_ = c++;
	_i.cCANREX_ = c++;
	_i.cCANPRX_ = c++;
	_i.cCANAFAL_ = c++;

	/*_i.cCODCOLEC_ = c++;
	_i.cDESCOLEC_ = c++;
	_i.cCODFAM_ = c++; 
	_i.cDESFAM_ = c++; 
	_i.cCODSUBFAM_ = c++; 
	_i.cDESSUBFAM_ = c++;
	_i.cORDEN_ = c++;

	_i.cCOSTEACT_ = c++; 
	_i.cCOSTENUEVO_ = c++; 
	_i.cCOSTEART_ = c++; 
	_i.cMARGENACT_ = c++; 
	_i.cMARGENNUEVO_ = c++; 
	_i.cMARGENART_ = c++; 
	_i.cEXIS_ = c++; 
	_i.cPTEREC_ = c++;
	_i.cAFALTA_ = c++;
	_i.cREVISAR_ = c++;
	_i.cNUMREF_ = c++;
	_i.cNUMREFHERC_ = c++;
	_i.cNUMREFHERM_ = c++;
	_i.cNUMREFMANC_ = c++;
	_i.cNUMREFMANM_ = c++;
	_i.cIDPLANTILLA_ = c++;*/

  
	cH[_i.cSEL_] = AQUtil.translate("scripts", "SEL.");
	cH[_i.cREF_] = AQUtil.translate("scripts", "REFERENCIA");
	cH[_i.cEAN_] = AQUtil.translate("scripts", "EAN");
	cH[_i.cDES_] = AQUtil.translate("scripts", "DESCRIPCI�N");
	cH[_i.cCODTAMA_] = AQUtil.translate("scripts", "TAMA�O");
	cH[_i.cCODCOLOR_] = AQUtil.translate("scripts", "COLOR");
	cH[_i.cCAN_] = AQUtil.translate("scripts", "CANT.PEDIR");
	cH[_i.cBLANCO_] = AQUtil.translate("scripts", "  ");
	cH[_i.cDISPROV_] = AQUtil.translate("scripts", "DISP.PROVEE.");
	cH[_i.cSEXIS_] = AQUtil.translate("scripts", "ST.EXISTENCIAS");
	cH[_i.cSRES_] = AQUtil.translate("scripts", "ST.RESERVADA");
	cH[_i.cSDIS_] = AQUtil.translate("scripts", "ST.DISPONIBLE");
	cH[_i.cSPTEREC_] = AQUtil.translate("scripts", "ST.PTE.RECIBIR");
	cH[_i.cSRESPTEREC_] = AQUtil.translate("scripts", "ST.RES.PTE.RECIBIR");
	cH[_i.cSAFALTA_] = AQUtil.translate("scripts", "ST.FALTAS");
	cH[_i.cSMIN_] = AQUtil.translate("scripts", "ST.M�NIMO");
	cH[_i.cSMAX_] = AQUtil.translate("scripts", "ST.M�XIMO");
	cH[_i.cCANPED_] = AQUtil.translate("scripts", "CANTIDAD PD");
	cH[_i.cCANREX_] = AQUtil.translate("scripts", "R.EX.");
	cH[_i.cCANPRX_] = AQUtil.translate("scripts", "R.PTE.REC.");
	cH[_i.cCANAFAL_] = AQUtil.translate("scripts", "R.FALTAS");

	//var t = this.child("tblLineas");
  	_i.t_.setNumCols(c); 
	_i.t_.setColumnWidth(_i.cSEL_, 30);
	_i.t_.setColumnWidth(_i.cREF_, 80);
	_i.t_.setColumnWidth(_i.cEAN_, 110);
	_i.t_.setColumnWidth(_i.cDES_, 250); 
	_i.t_.setColumnWidth(_i.cCODTAMA_, 100); 
	_i.t_.setColumnWidth(_i.cCODCOLOR_, 80);
	_i.t_.setColumnWidth(_i.cCAN_, 80);
	_i.t_.setColumnWidth(_i.cBLANCO_, 20); 
	_i.t_.setColumnWidth(_i.cDISPROV_, 90);
	_i.t_.setColumnWidth(_i.cSEXIS_, 105); 
	_i.t_.setColumnWidth(_i.cSRES_, 100); 
	_i.t_.setColumnWidth(_i.cSDIS_, 100); 
	_i.t_.setColumnWidth(_i.cSPTEREC_, 100); 
	_i.t_.setColumnWidth(_i.cSRESPTEREC_, 105); 
	_i.t_.setColumnWidth(_i.cSAFALTA_, 80); 
	_i.t_.setColumnWidth(_i.cSMIN_, 80); 
	_i.t_.setColumnWidth(_i.cSMAX_, 80); 
	_i.t_.setColumnWidth(_i.cCANPED_, 90);
	_i.t_.setColumnWidth(_i.cCANREX_, 70);
	_i.t_.setColumnWidth(_i.cCANPRX_, 80);
	_i.t_.setColumnWidth(_i.cCANAFAL_, 75); 



	_i.t_.setColumnReadOnly(_i.cSEL_, true);
	_i.t_.setColumnReadOnly(_i.cREF_, true);
	_i.t_.setColumnReadOnly(_i.cEAN_, true);
	_i.t_.setColumnReadOnly(_i.cDES_, true); 
	_i.t_.setColumnReadOnly(_i.cCODTAMA_, true); 
	_i.t_.setColumnReadOnly(_i.cCODCOLOR_, true);
	_i.t_.setColumnReadOnly(_i.cCAN_, false);
	_i.t_.setColumnReadOnly(_i.cBLANCO_, true); 
	_i.t_.setColumnReadOnly(_i.cDISPROV_, true); 
	_i.t_.setColumnReadOnly(_i.cSEXIS_, true); 
	_i.t_.setColumnReadOnly(_i.cSRES_, true); 
	_i.t_.setColumnReadOnly(_i.cSDIS_, true); 
	_i.t_.setColumnReadOnly(_i.cSPTEREC_, true); 
	_i.t_.setColumnReadOnly(_i.cSRESPTEREC_, true); 
	_i.t_.setColumnReadOnly(_i.cSAFALTA_, true); 
	_i.t_.setColumnReadOnly(_i.cSMIN_, true); 
	_i.t_.setColumnReadOnly(_i.cSMAX_, true); 	
	_i.t_.setColumnReadOnly(_i.cCANPED_, true);
	_i.t_.setColumnReadOnly(_i.cCANREX_, true);
	_i.t_.setColumnReadOnly(_i.cCANPRX_, true);
	_i.t_.setColumnReadOnly(_i.cCANAFAL_, true); 
  
  	_i.t_.setColumnLabels("*", cH.join("*"));

	/*_i.t_.hideColumn(_i.cIDPLANTILLA_);
	_i.t_.hideColumn(_i.cNUMREF_);
	_i.t_.hideColumn(_i.cNUMREFHERC_);
	_i.t_.hideColumn(_i.cNUMREFHERM_);
	_i.t_.hideColumn(_i.cNUMREFMANC_);
	_i.t_.hideColumn(_i.cNUMREFMANM_);*/

} 


function oficial_construirFiltro(cursor)
{
	var _i = this.iface;
	var filtro = "";

	var referencia = cursor.valueBuffer("referencia");
	var refArtProv = AQUtil.sqlSelect("articulosprov","referencia","refproveedor = '" + cursor.valueBuffer("refproveedor") + "' AND codproveedor = '" + cursor.valueBuffer("codproveedor") + "' AND refproveedor IS NOT NULL");	
	if(refArtProv && refArtProv != ""){
		if(referencia && referencia != "") {
			referencia = referencia + "," + refArtProv;	
		} else {
			referencia = refArtProv;
		}
		
	}
	debug("referencia: "+referencia);
	if (referencia && referencia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (referencia.find(",") >= 0) {
			filtro += ("articulos.referencia IN ('" + referencia.split(",").join("', '") + "')");
		} else {
			if (referencia.find("-") >= 0) {
				var min = referencia.split("-")[0];
				var max = referencia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.referencia SIMILAR TO '[0-9]+' AND CAST(articulos.referencia AS INTEGER) BETWEEN '" + min + "' AND '" + max + "'");
				}
			} else {
				filtro += "articulos.referencia = '" + referencia + "'";
			}
		}
	}

	var tamano = cursor.valueBuffer("codtamanoem");
	debug("tamano: "+tamano);
	if(tamano && tamano != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.codtamanoem = '" + tamano + "'";
	}

	var color = cursor.valueBuffer("codcolorem");
	debug("color: "+color);
	if(color && color != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.codcolorem = '" + color + "'";
	}

	var familia = cursor.valueBuffer("codfamilia");
	debug("familia: "+familia);
	if (familia && familia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (familia.find(",") >= 0) {
			filtro += ("articulos.codfamilia IN ('" + familia.split(",").join("', '") + "')");
		} else {
			if (familia.find("-") >= 0) {
				var min = familia.split("-")[0];
				var max = familia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.codfamilia IN (SELECT familias.codfamilia FROM familias WHERE familias.codfamilia SIMILAR TO '[0-9]+' AND CAST(familias.codfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.codfamilia = '" + familia + "'";
			}
		}
	}

	var subFamilia = cursor.valueBuffer("codsubfamilia");
	debug("subFamilia: "+subFamilia);
	if(subFamilia && subFamilia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (subFamilia.find(",") >= 0) {
			filtro += ("articulos.codsubfamilia IN ('" + subFamilia.split(",").join("', '") + "')");
		} else {
			if (subFamilia.find("-") >= 0) {
				var min = subFamilia.split("-")[0];
				var max = subFamilia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.codsubfamilia IN (SELECT subfamilias.codsubfamilia FROM subfamilias WHERE subfamilias.codsubfamilia SIMILAR TO '[0-9]+' AND CAST(subfamilias.codsubfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.codsubfamilia = '" + subFamilia + "'";
			}
		}
	}
	var dibujos = cursor.valueBuffer("dibujos");
	debug("dibujos: "+dibujos);
	if (dibujos && dibujos != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (dibujos.find(",") >= 0) {
			filtro += ("articulos.coddibestamp IN (" + dibujos + ")");
		} else {
			if (dibujos.find("-") >= 0) {
				var min = dibujos.split("-")[0];
				var max = dibujos.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.coddibestamp IN (SELECT em_dibujos.coddibujoem FROM em_dibujos WHERE em_dibujos.coddibujoem  BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.coddibestamp = " + dibujos;
			}
		}
	}
// 		if(filtro != "")
// 			filtro += " AND ";
// 		filtro += "coddibestamp = '" + dibujo + "'";
// 	}

	var coleccion = cursor.valueBuffer("codcoleccionem");
	debug("coleccion: "+subFamilia);
	if (coleccion && coleccion != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (coleccion.find(",") >= 0) {
			filtro += ("articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem IN ('" + coleccion.split(",").join("', '") + "'))");
		} else {
			if (coleccion.find("-") >= 0) {
				var min = coleccion.split("-")[0];
				var max = coleccion.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart WHERE em_coleccionesart.codcoleccionem SIMILAR TO '[0-9]+' AND  CAST(em_coleccionesart.codcoleccionem AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem = '" + coleccion + "')";
			}
		}
	}

	var refCliente = cursor.valueBuffer("aliasart");
	debug("refCliente: "+refCliente);
	if(refCliente && refCliente != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.aliasart = '" + refCliente + "'";
	}

	var refComponente = cursor.valueBuffer("refcomponente");
	debug("refComponente: "+refComponente);
	if (refComponente && refComponente != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "articulos.referencia IN (SELECT articuloscomp.refcompuesto FROM articuloscomp WHERE articuloscomp.refcomponente = '" + refComponente + "')";
	}

	var descatalogado = cursor.valueBuffer("descatalogado");
	debug("descatalogado: "+descatalogado);
	if (descatalogado && descatalogado != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (descatalogado){
			case "No": {
				filtro += "NOT articulos.descatalogado";
				break;
			}
			default:
				filtro += "articulos.descatalogado";
				break;
		}
	}

	var deBaja = cursor.valueBuffer("debaja");
	debug("deBaja: "+deBaja);
	if (deBaja && deBaja != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (deBaja){
			case "No": {
				filtro += "NOT articulos.debaja";
				break;
			}
			default:
				filtro += "articulos.debaja";
				break;
		}
	}

	var aLiquidar = cursor.valueBuffer("aliquidar");
	debug("aLiquidar: "+aLiquidar);
	if (aLiquidar && aLiquidar != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (aLiquidar){
			case "No": {
				filtro += "articulos.fechaliq is null";
				break;
			}
			default:
				filtro += "articulos.fechaliq is not null";
				break;
		}
	}
	var descatalogadoF = cursor.valueBuffer("descatalogadof");
	debug("descatalogadoF: "+descatalogadoF);
	if (descatalogadoF && descatalogadoF != "N/A"){
		if (filtro != "") {
			filtro += " AND ";
		}
		if(descatalogadoF == "No") {
			filtro += "NOT articulos.descatalogado";	
		} else {
			filtro += "articulos.descatalogado";
			var fechaDesF = cursor.valueBuffer("fechadesf");
			debug("fechaDesF: "+fechaDesF);
			if(fechaDesF && fechaDesF != "") {
				filtro += " AND articulos.fechades = '" + fechaDesF + "'";
			}			
		}	
	}

	var deBajaF = cursor.valueBuffer("debajaf");
	debug("deBajaF: "+deBajaF);
	if (deBajaF && deBajaF != "N/A"){
		if (filtro != "") {
			filtro += " AND ";
		}
		if (deBajaF == "No"){			
			filtro += "NOT articulos.debaja";
		} else {
			filtro += "articulos.debaja";
			var fechaFajaF = cursor.valueBuffer("fechabajaf");
			debug("fechaFajaF: "+fechaFajaF);
			if(fechaFajaF && fechaFajaF != "") {
				filtro += " AND articulos.fechabaja = '" + fechaFajaF + "'";
			}	
		
		}
	}

	var aLiquidarF = cursor.valueBuffer("aliquidarf");
	debug("aLiquidarF: "+aLiquidarF);
	if (aLiquidarF && aLiquidarF != "N/A"){
		if (filtro != "") {
			filtro += " AND ";
		}
		if (aLiquidarF == "No"){
			filtro += "articulos.fechaliq is null";
			
		} else {			
			filtro += "articulos.fechaliq is not null";		
			var fechaLiqF = cursor.valueBuffer("fechaliqf");
			debug("fechaLiqF: "+fechaLiqF);
			if(fechaLiqF && fechaLiqF != "") {
				filtro += " AND articulos.fechaliq = '" + fechaLiqF + "'";
			}	
		}
	}	

	/*var codAlmacen = cursor.valueBuffer("codalmacen");
	if (codAlmacen && codAlmacen != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "stocks.codalmacen = '" + codAlmacen + "'";
	} else {
		var codAlmacenPed = cursor.valueBuffer("codalmacenped");
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "stocks.codalmacen = '" + codAlmacenPed + "'";
	}*/
	
	var conFaltas = cursor.valueBuffer("confaltas");
	if (conFaltas) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "stocks.afaltas > 0";
	}
	
	var conNecesidad = cursor.valueBuffer("connecesidad");
	if (conNecesidad) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "stocks.necesidad > 0";
	}
	
	var conDisponible = cursor.valueBuffer("condisponible");
	if (conDisponible) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "(stocks.disponible > 0 OR stocks.disponiblepterecibir > 0)";
	}

	var codPedidoCli = cursor.valueBuffer("codpedidocli");
	if(codPedidoCli && codPedidoCli != "") {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "pedidoscli.codigo = '" + codPedidoCli + "'";	
	}
	debug("Filtro " + filtro);
	return filtro;
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(fN == "coddibestamp") {		
		cursor.setValueBuffer("dibujos", cursor.valueBuffer("coddibestamp"));		
	} else if (fN == "cantidada") {
		_i.habilitaciones();
	}
}

function oficial_pushButtonAccept_clicked()
{
	var cursor = this.cursor();	
	var _i = this.iface;
	
	var nF = _i.t_.numRows();
	if(nF == 0) {
		formUI.ponMsgWarn(sys.translate("No hay ninguna l�nea que importar. Se cancela el proceso."));		
		return false;
	}
	_i.numLinea_ = AQUtil.sqlSelect("lineaspedidosprov","MAX(numlinea)","idpedido = " + cursor.valueBuffer("iddocumento"));
	if(!_i.numLinea_ || _i.numLinea_ == "") {
		_i.numLinea_ = 0;
	}
	_i.numLinea_++;

	if(!_i.trImportarLineas(cursor)) {
		return false;	
	}
	this.obj().accept();
}

function oficial_trImportarLineas(cursor)
{
	var _i = this.iface;		
	var idPedido = cursor.valueBuffer("iddocumento");
	var nF = _i.t_.numRows();
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Generando l�neas"), nF);
	var p = 0;
	var cantidad = 0;
	for (var fila = 0; fila < nF; fila++) {
		AQUtil.setProgress(++p);	
		cantidad = _i.t_.text(fila, _i.cCAN_);
		if(!cantidad || isNaN(cantidad) || cantidad == "") {
			cantidad = 0;
		}
		if(_i.t_.text(fila, _i.cSEL_) == "X" && parseFloat(cantidad) != 0) {
			if(!_i.crearLinea(idPedido,fila)) {
				AQUtil.destroyProgressDialog();
				debug("Error creando lineas");	
				return false;
			}			
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_crearLinea(idPedido,fila)
{
	var _i = this.iface;
	var _cFL = formRecordlineaspedidosprov.iface.pub_commonCalculateField;
	var curL = new FLSqlCursor("lineaspedidosprov");
	curL.setModeAccess(curL.Insert);
	curL.refreshBuffer();
	curL.setValueBuffer("idpedido", idPedido);
	curL.setValueBuffer("numlinea", _i.numLinea_++);
	curL.setValueBuffer("referencia", _i.t_.text(fila, _i.cREF_));
	curL.setValueBuffer("descripcion", _i.t_.text(fila, _i.cDES_));	
	curL.setValueBuffer("emcodbarras", _i.t_.text(fila, _i.cEAN_));
	curL.setValueBuffer("codtamanoem", _i.t_.text(fila, _i.cCODTAMA_));
	curL.setValueBuffer("codcolorem", _i.t_.text(fila, _i.cCODCOLOR_));
	curL.setValueBuffer("cantidad", _i.t_.text(fila, _i.cCAN_));
	curL.setValueBuffer("pvpunitario", _cFL("pvpunitario", curL));
	curL.setValueBuffer("pvpsindto", _cFL("pvpsindto", curL));
	curL.setValueBuffer("pvptotal", _cFL("pvptotal", curL));
	curL.setValueBuffer("codimpuesto", _cFL("codimpuesto", curL));
	curL.setValueBuffer("iva", _cFL("iva", curL));
	curL.setValueBuffer("recargo", _cFL("recargo", curL));
	curL.setValueBuffer("diasservicio", _cFL("diasservicio", curL));
	curL.setValueBuffer("fechaservicio", _cFL("fechaservicio", curL));
 	curL.setValueBuffer("codsubcuenta", _cFL("codsubcuenta", curL));
 	curL.setValueBuffer("idsubcuenta", _cFL("idsubcuenta", curL));	
	curL.setValueBuffer("porcomision", _cFL("porcomision", curL));	
	if (!curL.commitBuffer()) {	
		debug("error al guardar la linea");	
		return false;
	}	
	return true;	
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var _i = this.iface;
	var cursor = miForm.cursor();
	var campos = "fdbReferencia,fdbDesArticulo,fdbFamilia,fdbDescFamilia,fdbSubfamilia,fdbDescSubfamilia,fdbColeccion,fdbDescColeccion,fdbDibujo,fdbDibujos,fdbDescDibujo,fdbRefComponente,fdbDesComponente,fdbTamano,fdbColor,fdbRefCliente,fdbCodAlmacen,fdbAlmacen,fdbConFaltas,fdbConNecesidad,fdbConDisponible,fdbPedidoVenta";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(miForm, aCampos[i], "");
	}
	cursor.setNull("coddibestamp");
	cursor.setValueBuffer("descatalogado", "Todos");
	cursor.setValueBuffer("debaja", "No");
	cursor.setValueBuffer("aliquidar", "Todos");
	cursor.setValueBuffer("cantidada", "Stock: A FALTAS");	
	_i.t_.setNumRows(0);
}

function oficial_tbnBuscar_clicked()
{ 
	var _i = this.iface;
	var cursor = this.cursor();
	_i.buscar(cursor);	}

function oficial_buscar(cursor)
{
	var _i = this.iface;
	var codPedidoCli = cursor.valueBuffer("codpedidocli");
	var filtro = _i.construirFiltro(cursor);
	
	_i.t_.setNumRows(0);
	var f = 0;
	var p = 0;

	var codAlmacen = cursor.valueBuffer("codalmacen");
	if (!codAlmacen || codAlmacen == "") {
		codAlmacen = cursor.valueBuffer("codalmacenped");
	}	

	var sSelect = "articulos.referencia,articulos.codbarras, articulos.descripcion, articulos.codtamanoem, articulos.codcolorem,stocks.cantidad, stocks.reservada, stocks.disponible, stocks.pterecibir, stocks.reservadapterecibir, stocks.afaltas, stocks.stockmin, stocks.stockmax";
	var sFrom = "articulos LEFT OUTER JOIN stocks ON stocks.referencia = articulos.referencia AND codalmacen = '" + codAlmacen + "'";
	if(codPedidoCli && codPedidoCli != "") {
		sSelect = sSelect + ",lineaspedidoscli.cantidad, movistock.reservaex, movistock.reservapr, movistock.reservaaf";
		sFrom = sFrom + " LEFT OUTER JOIN lineaspedidoscli ON lineaspedidoscli.referencia = articulos.referencia LEFT OUTER JOIN movistock ON movistock.idlineapc = lineaspedidoscli.idlinea LEFT OUTER JOIN pedidoscli ON pedidoscli.idpedido = lineaspedidoscli.idpedido ";		
	} 
	var q = new AQSqlQuery;	
	q.setSelect(sSelect);
	q.setFrom(sFrom);
	q.setWhere(filtro);		
	//debug("q: "+q.sql());		
	if (!q.exec()){		
		return;
	}  	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Buscando referencias"), q.size());	
	while(q.next()) {
		AQUtil.setProgress(++p);
		_i.t_.insertRows(f);  
		_i.t_.setText(f, _i.cSEL_,"X");    		
		_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorSel_);
      	//_i.t_.setText(f, _i.cSEL_,"");
      	//_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorNoSel_);	
		_i.t_.setText(f, _i.cREF_, q.value("articulos.referencia"));
		_i.t_.setText(f, _i.cEAN_, q.value("articulos.codbarras"));
		_i.t_.setText(f, _i.cDES_, q.value("articulos.descripcion")); 
		_i.t_.setText(f, _i.cCODTAMA_, q.value("articulos.codtamanoem")); 
		_i.t_.setText(f, _i.cCODCOLOR_, q.value("articulos.codcolorem"));
		
		
		_i.t_.setText(f, _i.cBLANCO_, " "); 
		_i.t_.setCellBackgroundColor(f, _i.cBLANCO_, _i.cColorNoSel_);	

		if(codPedidoCli && codPedidoCli != "") {
			_i.t_.setText(f, _i.cCANPED_, AQUtil.roundFieldValue(parseFloat(q.value("lineaspedidoscli.cantidad")), "lineaspedidosprov", "cantidad"));
			_i.t_.setText(f, _i.cCANREX_, AQUtil.roundFieldValue(parseFloat(q.value("movistock.reservaex")), "lineaspedidosprov", "cantidad"));
			_i.t_.setText(f, _i.cCANPRX_, AQUtil.roundFieldValue(parseFloat(q.value("movistock.reservapr")), "lineaspedidosprov", "cantidad"));
			_i.t_.setText(f, _i.cCANAFAL_, AQUtil.roundFieldValue(parseFloat(q.value("movistock.reservaaf")), "lineaspedidosprov", "cantidad")); 
		} else {
			_i.t_.setText(f, _i.cCANPED_, "");
			_i.t_.setText(f, _i.cCANREX_, "");
			_i.t_.setText(f, _i.cCANPRX_, "");
			_i.t_.setText(f, _i.cCANAFAL_, ""); 

		}
		_i.t_.setCellBackgroundColor(f, _i.cCANPED_, _i.cColorPedidos_);
		_i.t_.setCellBackgroundColor(f, _i.cCANREX_, _i.cColorPedidos_);
		_i.t_.setCellBackgroundColor(f, _i.cCANPRX_, _i.cColorPedidos_);
		_i.t_.setCellBackgroundColor(f, _i.cCANAFAL_, _i.cColorPedidos_);

		_i.t_.setText(f, _i.cSEXIS_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.cantidad")), "lineaspedidosprov", "cantidad")); 
		_i.t_.setText(f, _i.cSRES_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.reservada")), "lineaspedidosprov", "cantidad")); 
		_i.t_.setText(f, _i.cSDIS_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.disponible")), "lineaspedidosprov", "cantidad")); 
		_i.t_.setText(f, _i.cSPTEREC_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.pterecibir")), "lineaspedidosprov", "cantidad")); 
		_i.t_.setText(f, _i.cSRESPTEREC_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.reservadapterecibir")), "lineaspedidosprov", "cantidad")); 
		_i.t_.setText(f, _i.cSAFALTA_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.afaltas")), "lineaspedidosprov", "cantidad")); 
		_i.t_.setText(f, _i.cSMIN_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.stockmin")), "lineaspedidosprov", "cantidad")); 
		_i.t_.setText(f, _i.cSMAX_, AQUtil.roundFieldValue(parseFloat(q.value("stocks.stockmax")), "lineaspedidosprov", "cantidad")); 	

		_i.t_.setCellBackgroundColor(f, _i.cSEXIS_, _i.cColorStocks_);
		_i.t_.setCellBackgroundColor(f, _i.cSRES_, _i.cColorStocks_);
		_i.t_.setCellBackgroundColor(f, _i.cSDIS_, _i.cColorStocks_);
		_i.t_.setCellBackgroundColor(f, _i.cSPTEREC_, _i.cColorStocks_);
		_i.t_.setCellBackgroundColor(f, _i.cSRESPTEREC_, _i.cColorStocks_);
		_i.t_.setCellBackgroundColor(f, _i.cSAFALTA_, _i.cColorStocks_);
		_i.t_.setCellBackgroundColor(f, _i.cSMIN_, _i.cColorStocks_);

		_i.t_.setText(f, _i.cDISPROV_, _i.dameCantDisProv(f, cursor.valueBuffer("codproveedor")));
		_i.t_.setCellBackgroundColor(f, _i.cDISPROV_, _i.cColorDisProv_);
		
		_i.t_.setText(f, _i.cCAN_, _i.dameCantidad(f, cursor.valueBuffer("cantidada")));

		_i.t_.setCellBackgroundColor(f, _i.cCAN_, _i.dameColorCantidad(f));			
		f++;
	}	
	AQUtil.destroyProgressDialog();	
}

function oficial_dameCantidad(fila, opcion)
{
	var _i = this.iface;
	var cantidad = 0;

	if(opcion == "Stock: A FALTAS") {
		cantidad = _i.t_.text(fila, _i.cSAFALTA_);
		if(!cantidad || cantidad == "") {
			cantidad = 0;
		}
	} else if(opcion == "Stock: NO reservado de existencias") {
		var reservadoPTX = _i.t_.text(fila, _i.cSRESPTEREC_); 		
		if(!reservadoPTX || reservadoPTX == "") {
			reservadoPTX = 0; 
		}
		var reserAFALTA = _i.t_.text(fila, _i.cSAFALTA_);
		if(!reserAFALTA || reserAFALTA == "") {
			reserAFALTA = 0; 
		}
		cantidad = parseFloat(reservadoPTX) + parseFloat(reserAFALTA);

	} else if(opcion == "Stock: Todas las reservas (R.EX + R.PR. + FALTAS)") {

		var reservada = _i.t_.text(fila, _i.cSRES_); 		
		if(!reservada || reservada == "") {
			reservada = 0; 
		}
		var reservadoPTX = _i.t_.text(fila, _i.cSRESPTEREC_); 		
		if(!reservadoPTX || reservadoPTX == "") {
			reservadoPTX = 0; 
		}
		var reserAFALTA = _i.t_.text(fila, _i.cSAFALTA_);
		if(!reserAFALTA || reserAFALTA == "") {
			reserAFALTA = 0; 
		}
		cantidad = parseFloat(reservada) + parseFloat(reservadoPTX) + parseFloat(reserAFALTA);
		
	} else if(opcion == "Stock: Necesidad M�nima (cubrir stock M�nimo)") {
		var minimo = _i.t_.text(fila, _i.cSMIN_);
		if(!minimo || minimo == "") {
			minimo = 0;
		}
		var existencias = _i.t_.text(fila, _i.cSEXIS_); 
		if(!existencias || existencias == "") {
			existencias = 0;
		}
		if(parseFloat(existencias) > parseFloat(minimo)) {
			cantidad = 0;
		} else {
			cantidad = parseFloat(minimo) - parseFloat(existencias);
		}		

	} else if(opcion == "Stock: Necesidad M�xima (cubrir stock M�ximo)") {
		var maximo = _i.t_.text(fila, _i.cSMAX_);
		if(!maximo || maximo == "") {
			maximo = 0;
		}
		var existencias = _i.t_.text(fila, _i.cSEXIS_); 
		if(!existencias || existencias == "") {
			existencias = 0;
		}
		if(parseFloat(existencias) > parseFloat(maximo)) {
			cantidad = 0;
		} else {
			cantidad = parseFloat(maximo) - parseFloat(existencias);
		}		
	} else if(opcion == "Pedido de venta: Cantidad A FALTAS") {
		cantidad = _i.t_.text(fila, _i.cCANAFAL_);
		if(!cantidad || cantidad == "") {
			cantidad = 0;
		}
		
	} else if(opcion == "Pedido de venta: Cantidad no reservada de existencias") {

		var cantidadPedido = _i.t_.text(fila, _i.cCANPED_); 		
		if(!cantidadPedido || cantidadPedido == "") {
			cantidadPedido = 0; 
		}
		var cantidadResEx = _i.t_.text(fila, _i.cCANREX_);
		if(!cantidadResEx || cantidadResEx == "") {
			cantidadResEx = 0; 
		}
		cantidad = parseFloat(cantidadPedido) - parseFloat(cantidadResEx);		

	} else if(opcion == "Pedido de venta: Cantidad pedida") {
		cantidad = _i.t_.text(fila, _i.cCANPED_);		
		if(!cantidad || cantidad == "") {
			cantidad = 0;
		}
	}
	cantidad =  AQUtil.roundFieldValue(parseFloat(cantidad), "lineaspedidosprov", "cantidad");
	return cantidad;
}

function oficial_colores()
{
	var _i = this.iface;
	_i.cColorNoSel_ = new Color("grey");
	_i.cColorSel_ = new Color("green"); 
	_i.cColorCan_ = new Color("yellow");
	_i.cColorPedidos_ = new Color("YellowGreen");
	_i.cColorStocks_ = new Color("SkyBlue");
	_i.cColorDisProv_ = new Color("orange");
}

function oficial_tblLineas_clicked(f, c)
{
	var _i = this.iface;
	if(c == _i.cSEL_) {	
		_i.colSelClicked(f); 	
	}	
}

function oficial_tbnTodosSel_clicked()
{
	var _i = this.iface;	
	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Marcando l�neas"), nF);
	var p = 0;
	for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		if (_i.t_.text(f, c) == "") {
			if (!_i.colSelClicked(f)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
			
		}
	}	
  	AQUtil.destroyProgressDialog();
}

function oficial_tbnNingunoSel_clicked()
{
	

	var _i = this.iface;	
	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Desmarcando l�neas"), nF);
	var p = 0;
	for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		if (_i.t_.text(f, c) == "X") {
			if (!_i.colSelClicked(f)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
			
		}
	}	
	AQUtil.destroyProgressDialog();
}

function oficial_colSelClicked(f)
{
	var _i = this.iface;
	var c = _i.cSEL_;
	
	if (_i.t_.text(f, c) == "") {
		_i.t_.setText(f, c, "X");   
	} else {
		_i.t_.setText(f, c, "");   
	}

	if (_i.t_.text(f, c) == "X") {
		_i.t_.setCellBackgroundColor(f, c, _i.cColorSel_);		
	} else {
		_i.t_.setCellBackgroundColor(f, c, _i.cColorNoSel_);		
	}
 	return true;
}

function oficial_habilitaciones()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var opcion = cursor.valueBuffer("cantidada");
	if(opcion == "Pedido de venta: Cantidad A FALTAS" || opcion == "Pedido de venta: Cantidad no reservada de existencias" || opcion == "Pedido de venta: Cantidad pedida") {
		sys.enableObj(this, "fdbPedidoVenta");
		

	} else {
		this.child("fdbPedidoVenta").setValue("");
		sys.disableObj(this, "fdbPedidoVenta");
	}
}

function oficial_dameCantDisProv(fila, codProveedor)
{
	var _i = this.iface;
	var referencia = _i.t_.text(fila, _i.cREF_);
	var codAlmacen = AQUtil.sqlSelect("proveedores","codalmacen","codproveedor = '" + codProveedor + "'");
	if(!codAlmacen || codAlmacen == "") {
		return 0;
	}
	
	var cantidad = 0;
	var q = new AQSqlQuery;	
	q.setSelect("sto.referencia,CASE WHEN SUM(sto.disponible) < 0 THEN 0 ELSE SUM(sto.disponible) END AS disponible");
	q.setFrom("(SELECT stk.referencia, stk.disponible FROM stocks stk INNER JOIN articulos art ON stk.referencia = art.referencia WHERE stk.codalmacen = '" + codAlmacen + "' UNION ALL SELECT lin.referencia, mv.cantidad * '-1' AS cantidad FROM pedidosprov cab INNER JOIN lineaspedidosprov lin ON cab.idpedido = lin.idpedido JOIN movistock mv ON lin.idlinea = mv.idlineapp WHERE cab.codproveedor = '" + codProveedor + "') sto");
	q.setWhere("referencia = '" + referencia + "' GROUP BY sto.referencia"); 			
	debug("q.sql: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		cantidad = q.value(1);	
	}	
	if(!cantidad || cantidad == "") {
		cantidad = 0;
	}

	return AQUtil.roundFieldValue(parseFloat(cantidad), "lineaspedidosprov", "cantidad");
}

function oficial_dameColorCantidad(fila)
{
	var _i = this.iface;
	var cantDisProv = _i.t_.text(fila, _i.cDISPROV_);
	var cantidad = _i.t_.text(fila, _i.cCAN_);
	if(!cantDisProv || isNaN(cantDisProv) || cantDisProv == "") {
		cantDisProv = 0;
	}
	if(!cantidad || isNaN(cantidad) || cantidad == "") {
		cantidad = 0;
	}

	if(parseFloat(cantidad) <= parseFloat(cantDisProv)) {
		return _i.cColorSel_;
	} else {
		return _i.cColorCan_;

	}	
}

function oficial_tblLineas_valueChanged(f, c)
{	
	var _i = this.iface;
	if(c == _i.cDISPROV_ || c == _i.cCAN_) {		
		_i.t_.setCellBackgroundColor(f, _i.cCAN_, _i.dameColorCantidad(f));	
	}	
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
