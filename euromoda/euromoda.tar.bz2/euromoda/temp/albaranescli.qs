
/** @class_declaration euromoda*/
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends ivaNav {
	var pK_;
	var idAlbaranDev_;
	var lblDatosAlbaranAbono_;
	var aLineasAbono_;
	var curLineaAbono_;
	var politicaCostes_;
  function euromoda( context ) { ivaNav ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function filtraTransportistas()
  {
    return this.ctx.euromoda_filtraTransportistas();
  }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function comprobarSincroGIT()
  {
    return this.ctx.euromoda_comprobarSincroGIT();
  }
  function recalculaAlbaranGIT()
  {
    return this.ctx.euromoda_recalculaAlbaranGIT();
  }
  function validateForm(lineas)
  {
    return this.ctx.euromoda_validateForm(lineas);
  }
  function calcularTotales() {
		return this.ctx.euromoda_calcularTotales();
	}
	function guardaAlbaran(curLineas) {
		return this.ctx.euromoda_guardaAlbaran(curLineas);
	}
	function guardaDocumentoCommit(curLineas)
  {
    return this.ctx.euromoda_guardaDocumentoCommit(curLineas);
  }
  function pbnDevolPiezas_clicked() {
  	return this.ctx.euromoda_pbnDevolPiezas_clicked();
  }
  function pbnAsignarPiezasOE_clicked() {
  	return this.ctx.euromoda_pbnAsignarPiezasOE_clicked();
  }
  function tbnBuscarAlbaran_clicked() {
  	return this.ctx.euromoda_tbnBuscarAlbaran_clicked();
  }
  function mostrarDatosAlbaran(idAlbaran) {
  	return this.ctx.euromoda_mostrarDatosAlbaran(idAlbaran);
  }
  function seleccionLineasAbono() {
  	return this.ctx.euromoda_seleccionLineasAbono();
  }
  function mostrarOpcionesAlbaranAbono(idAlbaran) {
  	return this.ctx.euromoda_mostrarOpcionesAlbaranAbono(idAlbaran);
  }
  function copiarLineasAbono(idAlbaranOriginal, aLineas, factor) {
  	return this.ctx.euromoda_copiarLineasAbono(idAlbaranOriginal, aLineas, factor);
  }
  function copiarCampoLineaAbono(nombreCampo, curLineaOriginal, factor, campoInformado) {
  	return this.ctx.euromoda_copiarCampoLineaAbono(nombreCampo, curLineaOriginal, factor, campoInformado);
  }
  function ponSeleccionValores(valores) {
  	return this.ctx.euromoda_ponSeleccionValores(valores);
  }
  function copiarDatosLineaAbono(idLinea, idLineaOriginal, factor) {
  	return this.ctx.euromoda_copiarDatosLineaAbono(idLinea, idLineaOriginal, factor);
  }
  function pbnInsertarPlantillaTextoO_clicked() {
    return this.ctx.euromoda_pbnInsertarPlantillaTextoO_clicked();
  }
  function pbnInsertarPlantillaTextoOT_clicked() {
    return this.ctx.euromoda_pbnInsertarPlantillaTextoOT_clicked();
  }
  function ocultarCamposContabilidad() {
	return this.ctx.euromoda_ocultarCamposContabilidad();
  }
  	function tbnEmRegenerarCostes_clicked() {
		return this.ctx.euromoda_tbnEmRegenerarCostes_clicked();
	}
 	function tbnEmCargarCostes_clicked() {
 		return this.ctx.euromoda_tbnEmCargarCostes_clicked();
 	}
 	function ordenTabulacion() {
 		return this.ctx.euromoda_ordenTabulacion();
 	}
 	function pbnImportarCSV_clicked() {
		return this.ctx.euromoda_pbnImportarCSV_clicked();
  }

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_ponSeleccionValores(valores) {
		return this.ponSeleccionValores(valores);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "codpago": {
      _i.__bufferChanged(fN);
      sys.setObjText(this, "fdbPorDtoEsp", _i.calculateField("pordtoesp_fp"));
      break;
    }
		case "codcliente": {
      if (!flfacturac.iface.pub_controlBloqueoCliente(cursor.valueBuffer("codcliente"), "Enviar")) {
				return false;
			}
			_i.__bufferChanged(fN);
      sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
      cursor.setValueBuffer("tipoportes", _i.calculateField("tipoportes"));
      this.child("lblDirFacturacion").text = _i.calculateField("dirfacturacion");
			formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",cursor.valueBuffer("codcliente"));
			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",cursor.valueBuffer("codcliente"));	
      break;
    }
		case "deabono": {
       _i.__bufferChanged(fN);
      sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
   	if(this.cursor().valueBuffer("deabono") == true) {
			this.child("tbnBuscarAlbaran").setDisabled(false);
		} else {
			this.child("tbnBuscarAlbaran").setDisabled(true);
			_i.lblDatosAlbaranAbono_.text = "";
			this.cursor().setValueBuffer("em_codigoabono", ""); 
			this.cursor().setNull("em_idalbaranabono"); 
		}
    }
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_filtraTransportistas()
{
	this.child("fdbCodTransportista").setFilter("esagenciat");
}

function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
	var cursor = this.cursor();

	formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",cursor.valueBuffer("codcliente"));
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",cursor.valueBuffer("codcliente"));	
	connect(this.child("tbnEmRegenerarCostes"), "clicked()", _i, "tbnEmRegenerarCostes_clicked");
 	connect(this.child("tbnEmCargarCostes"), "clicked()", _i, "tbnEmCargarCostes_clicked");
	
	_i.pK_ = cursor.valueBuffer(cursor.primaryKey());
	//connect(this.child("tdbLineasAlbaranesCli").cursor(), "commited()", _i, "guardaDocumentoCommit()");
	disconnect(this.child("tdbLineasAlbaranesCli").cursor(), "bufferCommited()", this, "iface.calcularTotales()");
	connect(this.child("tdbLineasAlbaranesCli").cursor(), "commited()", _i, "calcularTotales");	
						 
  this.child("lblDirFacturacion").text = _i.calculateField("dirfacturacion");

	//connect(this, "formReady()", _i, "comprobarSincroGIT()");
	connect(this.child("pbnDevolPiezas"), "clicked()", _i, "pbnDevolPiezas_clicked()");
	connect(this.child("pbnAsignarPiezasOE"), "clicked()", _i, "pbnAsignarPiezasOE_clicked()");
	connect(this.child("tbnBuscarAlbaran"), "clicked()", _i, "tbnBuscarAlbaran_clicked()");
	connect(this.child("pbnInsertarPlantillaTextoO"), "clicked()", _i, "pbnInsertarPlantillaTextoO_clicked");
	connect(this.child("pbnInsertarPlantillaTextoOT"), "clicked()", _i, "pbnInsertarPlantillaTextoOT_clicked");
	_i.lblDatosAlbaranAbono_ = this.child("lblDatosAlbaranAbono");
	if (cursor.modeAccess() == cursor.Insert) {
		this.child("tbnBuscarAlbaran").setDisabled(true);
	} else if (this.cursor().valueBuffer("deabono") == true){
		this.child("tbnBuscarAlbaran").setDisabled(false);
		_i.mostrarDatosAlbaran(AQUtil.sqlSelect("albaranescli", "em_idalbaranabono", "codigo = '" + this.child("fdbCodigo").value() + "'"));
	} else {
		this.child("tbnBuscarAlbaran").setDisabled(true);		
	}	
	_i.ordenTabulacion();	
	connect(this.child("pbnImportarCSV"), "clicked()", _i, "pbnImportarCSV_clicked");
}

function euromoda_comprobarSincroGIT()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.modeAccess() == cursor.Edit && cursor.valueBuffer("estadogit") < 2 && (sys.nameBD().find("creaciones") >= 0 || sys.nameBD().find("euromoda") >= 0) && cursor.valueBuffer("codserie") == "Z") {
		if (!_i.recalculaAlbaranGIT()) {
		  cursor.setValueBuffer("estadogit", 1);
			MessageBox.warning(sys.translate("Error al actualizar los datos del albar�n sincronizado con GIT"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			this.close();
		} else {
			cursor.setValueBuffer("estadogit", 2);
		}
	}
}

function euromoda_recalculaAlbaranGIT()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codCliente = cursor.valueBuffer("codcliente");
	cursor.setValueBuffer("nombrecliente", AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("cifnif", AQUtil.sqlSelect("clientes", "cifnif", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("coddivisa", AQUtil.sqlSelect("clientes", "coddivisa", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("codpago", AQUtil.sqlSelect("clientes", "codpago", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("em_codpago", AQUtil.sqlSelect("clientes", "em_codpago", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("codagente", AQUtil.sqlSelect("clientes", "codagente", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("codalmacen", "1");
	var datosDE = flfactppal.iface.pub_ejecutarQry("dirclientes", "id,descripciondir,direccion,codpostal,ciudad,provincia,apartado,codpais", "codcliente = '" + codCliente + "' AND domenvio", "dirclientes");
	if (datosDE.result != 1) {
		datosDE = flfactppal.iface.pub_ejecutarQry("dirclientes", "id,descripciondir,direccion,codpostal,ciudad,provincia,apartado,codpais", "codcliente = '" + codCliente + "' AND domfacturacion", "dirclientes");
		if (datosDE.result != 1) {
			MessageBox.warning(sys.translate("Error al obtener la direcci�n de env�o del albar�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
	}
	cursor.setValueBuffer("coddir", datosDE["id"]);
	cursor.setValueBuffer("descripciondir", datosDE["descripciondir"]);
	cursor.setValueBuffer("direccion", datosDE["direccion"]);
	cursor.setValueBuffer("codpostal", datosDE["codpostal"]);
	cursor.setValueBuffer("ciudad", datosDE["ciudad"]);
	cursor.setValueBuffer("provincia", datosDE["provincia"]);
	cursor.setValueBuffer("apartado", datosDE["apartado"]);
	cursor.setValueBuffer("codpais", datosDE["codpais"]);
	cursor.setValueBuffer("tasaconv", AQUtil.sqlSelect("divisas", "tasaconv", "coddivisa = '" + cursor.valueBuffer("coddivisa") + "'"));
	cursor.setValueBuffer("codclientefac", AQUtil.sqlSelect("clientes", "codclientefac", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("incoterm", AQUtil.sqlSelect("clientes", "incoterm", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("pobincoterm", AQUtil.sqlSelect("clientes", "pobincoterm", "codcliente = '" + codCliente + "'"));
	cursor.setValueBuffer("codgrupoivaneg", AQUtil.sqlSelect("clientes", "codgrupoivaneg", "codcliente = '" + codCliente + "'"));
	var codigo = cursor.valueBuffer("codigo");
	if (codigo != "" && codigo.startsWith("700/")) {
		cursor.setValueBuffer("deabono", true);
	}
	cursor.setValueBuffer("codserie", _i.calculateField("codserie"));
	var numero = flfacturac.iface.siguienteNumero(cursor.valueBuffer("codserie"), cursor.valueBuffer("codejercicio"), "nalbarancli");
	if (!numero)
		return false;
	cursor.setValueBuffer("numero", numero);
	cursor.setValueBuffer("codigo", _i.calculateField("codigo"));


	var curL = this.child("tdbLineasAlbaranesCli").cursor();
	curL.select();
	var fCalculaCampo = formRecordlineasalbaranescli.iface.pub_commonCalculateField;
	AQUtil.createProgressDialog(sys.translate("Recalculando l�neas"), curL.size());
	var p = 0;
	while (curL.next()) {
		AQUtil.setProgress(p++);
		curL.setModeAccess(curL.Edit);
		curL.refreshBuffer();
		curL.setValueBuffer("tipoconcepto", "Producto");
		curL.setValueBuffer("descripcion", fCalculaCampo("desarticulo", curL));
		curL.setValueBuffer("canfactura", curL.valueBuffer("cantidad"));
		curL.setValueBuffer("pvpunitario", fCalculaCampo("pvpunitario", curL));
		curL.setValueBuffer("dtopor", fCalculaCampo("dtopor", curL));
		curL.setValueBuffer("pvpsindto", fCalculaCampo("pvpsindto", curL));
		curL.setValueBuffer("pvptotal", fCalculaCampo("pvptotal", curL));
		curL.setValueBuffer("porcomision", fCalculaCampo("porcomision", curL));
		curL.setValueBuffer("codarancelario", AQUtil.sqlSelect("articulos", "codarancelario", "referencia = '" + curL.valueBuffer("referencia") + "'"));
		curL.setValueBuffer("refcliente", AQUtil.sqlSelect("articulos", "aliasart", "referencia = '" + curL.valueBuffer("referencia") + "'"));
		curL.setValueBuffer("codimpuesto", fCalculaCampo("codimpuesto", curL));
		curL.setValueBuffer("iva", fCalculaCampo("iva", curL));
		curL.setValueBuffer("recargo", fCalculaCampo("recargo", curL));

		if (!flfactalma.iface.generarEstructura(curL)) {
			return false;
		}
		if (!curL.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	_i.calcularTotales();
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_validateForm(lineas)
{
  var _i = this.iface;
	var cursor = this.cursor();

	if (!flfacturac.iface.pub_controlBloqueoCliente(cursor.valueBuffer("codcliente"), "Enviar")) {
		return false;
	}
  if (!_i.__validateForm()) {
    return false;
  }
  _i.__calcularTotales();
	if(!lineas) {
		if(!formRecordpresupuestoscli.iface.evaluarCostesCab(cursor)) { 
			return false;
		}
	}
  return true;
}

function euromoda_calcularTotales()
{
  var _i = this.iface;
  
  _i.guardaDocumentoCommit();
  
  _i.__calcularTotales();

  //_i.guardaAlbaran(this.child("tdbLineasAlbaranesCli").cursor());
}

function euromoda_guardaAlbaran(curLineas)
{
  var _i = this.iface;
	var cursor = this.cursor();

  var commitLineas = (cursor.transactionLevel() == 2);
  if (curLineas == undefined) {
    commitLineas = false;
  }

  if (cursor.modeAccess() != cursor.Edit) {
    return true;
  }

  if (!_i.validateForm()) {
    return false;
  }

  var indice = cursor.atFrom();
  if (!cursor.commitBuffer()) {
    return false;
  }

  if (commitLineas)
    curLineas.commit();
  if (!cursor.commit()) {
    if (commitLineas)
      curLineas.transaction(false);
    return false;
  }

  if (!cursor.transaction(false)) {
    if (commitLineas)
      curLineas.transaction(false);
    return false;
  }
  if (commitLineas)
    curLineas.transaction(false);

  if (!cursor.seek(indice)) {
    return false;
  }

  cursor.setModeAccess(cursor.Edit);
  cursor.refreshBuffer();

  return true;
}

function euromoda_guardaDocumentoCommit()
{
  	var _i = this.iface;
  	var cursor = this.cursor();

  	if (cursor.modeAccess() != cursor.Edit) {
    	return true;
  	}
  	var pk = cursor.valueBuffer(cursor.primaryKey());
  	formalbaranescli.iface.pK_ = cursor.valueBuffer("codigo");

  	if (!_i.validateForm(true)) {
    	return false;
  	}

  	if (!cursor.commitBuffer()) {
    	return false;
  	}

  	cursor.commit();
  	cursor.transaction(false);

   	cursor.select(cursor.primaryKey() + " = " + _i.pK_);
	if (!cursor.first()) {
		sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
		return false;
	}
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
}

function euromoda_pbnDevolPiezas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!this.child("tdbLineasAlbaranesCli").cursor().commitBufferCursorRelation()) {
		return false;
	}
	_i.idAlbaranDev_=cursor.valueBuffer("idalbaran");
	if(!_i.idAlbaranDev_) {
		return false;
	}
	
	var f = new FLFormSearchDB("em_devolucionpiezas");
	f.setMainWidget();
	f.exec();
	_i.tbnEmCargarCostes_clicked();
	_i.calcularTotales();
	return true;
}

function euromoda_pbnAsignarPiezasOE_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!this.child("tdbLineasAlbaranesCli").cursor().commitBufferCursorRelation()) {
		return false;
	}
	_i.idAlbaranDev_=cursor.valueBuffer("idalbaran");
	if(!_i.idAlbaranDev_) {
		return false;
	}
	
	var f = new FLFormSearchDB("em_asignacionpiezasoe");
	f.setMainWidget();
	f.exec();
	_i.tbnEmCargarCostes_clicked();
	_i.calcularTotales();
	return true;
}

function euromoda_tbnBuscarAlbaran_clicked()
{
	var _i = this.iface;
	var ruta = new FLFormSearchDB("busalbcli");
	var curFacturas = ruta.cursor();
	var cursor = this.cursor();

	
	if(cursor.valueBuffer("codcliente") == "" || !cursor.valueBuffer("codcliente")){
		sys.warnMsgBox(sys.translate("Debe seleccionar un cliente antes de buscar el albar�n a rectificar."));
		return false;
	}

	var codCliente = cursor.valueBuffer("codcliente");
	var masFiltro = "";
	if (codCliente)
		masFiltro += " AND codcliente = '" + codCliente + "'";
	
	if (cursor.modeAccess() == cursor.Insert)
		curFacturas.setMainFilter("deabono = false" + masFiltro);
	else
		curFacturas.setMainFilter("deabono = false and idalbaran <> " + cursor.valueBuffer("idalbaran") + masFiltro);

	ruta.setMainWidget();
	var idAlbaran = ruta.exec("idalbaran");

	var codDropshipping = curFacturas.valueBuffer("em_coddropshipping");

	if (!idAlbaran) {
		return;
	}

	if(codDropshipping && codDropshipping != ""){
		cursor.setValueBuffer("em_coddropshipping", codDropshipping);
	}

	cursor.setValueBuffer("em_idalbaranabono", idAlbaran);
	var codigo = AQUtil.sqlSelect("albaranescli", "codigo", "idalbaran = '" + idAlbaran + "'");
	cursor.setValueBuffer("em_codigoabono", codigo);
	_i.mostrarDatosAlbaran(idAlbaran);
	_i.mostrarOpcionesAlbaranAbono(idAlbaran);
}

function euromoda_mostrarOpcionesAlbaranAbono(idAlbaran)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var opciones = [sys.translate("Copiar l�neas del albar�n"), sys.translate("Copiar con cantidad negativa"), sys.translate("No copiar l�neas")];
	var opcion = flfactppal.iface.pub_elegirOpcion(opciones);
	switch (opcion) {
		case 0:
		case 1: {
			var aDatosAA = new Object;
			aDatosAA.tabla = "lineasalbaranescli";
			aDatosAA.signo = opcion == 0 ? "+" : "-";
			aDatosAA.idalbaran = idAlbaran;
			flfacturac.iface.pub_ponDatosFacturaRec(aDatosAA);
			var valores = _i.seleccionLineasAbono();
			if (!valores) {
				return false;
			}
			var factor = aDatosAA.signo == "+" ? 1 : -1;
			if (!_i.copiarLineasAbono(idAlbaran, valores, factor)) {
				return false;
			}
			var codDropshipping = AQUtil.sqlSelect("albaranescli","em_coddropshipping","idalbaran = " + idAlbaran);
			debug("codigo: " + codDropshipping);
			if(codDropshipping && codDropshipping != ""){
				cursor.setValueBuffer("em_coddropshipping", codDropshipping);
			}
			break;
		}
	}
}


function euromoda_copiarLineasAbono(idAlbaranOriginal, aLineas, factor)
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		var curLineas = this.child("tdbLineasAlbaranesCli").cursor();
		if (!curLineas.commitBufferCursorRelation()) {
			return false;
		}
	}

	var curLineaOriginal = new FLSqlCursor("lineasalbaranescli");
	_i.curLineaAbono_ = new FLSqlCursor("lineasalbaranescli");

	var camposLinea = AQUtil.nombreCampos("lineasalbaranescli");
	var totalCampos = camposLinea[0];
	var idLinea, cantidad;
	var oParamLin = new Object;
	oParamLin.ignorarAvisos = true;
	oParamLin.forzarReg = false;
	oParamLin.ignorarCalculoInsert = true; 

	for (var i = 0; i < aLineas.length; i++) {
		curLineaOriginal.select("idlinea = " + aLineas[i]["idlinea"]);
		if (!curLineaOriginal.first()) {
			return false;
		}
		curLineaOriginal.setModeAccess(curLineaOriginal.Browse);
		curLineaOriginal.refresh();
		
		var referencia = curLineaOriginal.valueBuffer("referencia");
		if (flfactalma.iface.pub_esReferenciaXPiezas(referencia)) {
			sys.warnMsgBox(sys.translate("La referencia %1 funciona por piezas, use la funcionalidad de devoluci�n de piezas para realizar la devoluci�n").arg(referencia));
		} else {		
			_i.curLineaAbono_.setModeAccess(_i.curLineaAbono_.Insert);
			_i.curLineaAbono_.refresh();
			_i.curLineaAbono_.setValueBuffer("cantidad", aLineas[i]["cantidad"]);
			_i.curLineaAbono_.setValueBuffer("canfactura", aLineas[i]["cantidad"]);
		
			var campoInformado= [];
			for (var i= 1; i <= totalCampos; i++) {
				campoInformado[camposLinea[i]] = false;
			}
		
			for (var i = 1; i <= totalCampos; i++) {
				if (!_i.copiarCampoLineaAbono(camposLinea[i], curLineaOriginal, factor, campoInformado)) {
					return false;
				}
			}

			//reevaluamos costes	

			oParamLin.cursor = _i.curLineaAbono_;
			formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);

			if (!_i.curLineaAbono_.commitBuffer()) {
				return false;
			}
			idLinea = _i.curLineaAbono_.valueBuffer("idlinea");
			if (!_i.copiarDatosLineaAbono(idLinea, curLineaOriginal.valueBuffer("idlinea"), factor)) {	
				return false;
			}
		}
	}
	_i.calcularTotales();
	this.child("tdbLineasAlbaranesCli").refresh();

	return true;
}

function euromoda_copiarCampoLineaAbono(nombreCampo, curLineaOriginal, factor, campoInformado)
{
	var _i = this.iface;
	if (campoInformado[nombreCampo]) {
		return true;
	}	
	var cursor = this.cursor();
	debug("nombreCampo: "+nombreCampo);
	switch (nombreCampo) {
		case "idlinea":
		case "idpedido":
		case "idlineapedido": {
			return true;
			break;
		}
		case "idalbaran": {
			_i.curLineaAbono_.setValueBuffer("idalbaran", cursor.valueBuffer("idalbaran"));
			break;
		}		
		case "canfactura":
		case "cantidad": {
			break;
		}		
		case "dtolineal": {
			_i.curLineaAbono_.setValueBuffer(nombreCampo, curLineaOriginal.valueBuffer(nombreCampo) * factor);
			break;
		}
		case "pvpsindto": {
			if (!campoInformado["pvpunitario"]) {
				if (!_i.copiarCampoLineaAbono("pvpunitario", curLineaOriginal, factor, campoInformado)) {
					return false;
				}
			}
			_i.curLineaAbono_.setValueBuffer("pvpsindto", formRecordlineaspedidoscli.iface.pub_commonCalculateField("pvpsindto", _i.curLineaAbono_));
			break;
		}
		case "pvptotal": {
			if (!campoInformado["pvpsindto"]) {
				if (!_i.copiarCampoLineaAbono("pvpsindto", curLineaOriginal, factor, campoInformado)) {
					return false;
				}
			}
			if (!campoInformado["dtolineal"]) {
				if (!_i.copiarCampoLineaAbono("dtolineal", curLineaOriginal, factor, campoInformado)) {
					return false;
				}
			}
			if (!campoInformado["dtopor"]) {
				if (!_i.copiarCampoLineaAbono("dtopor", curLineaOriginal, factor, campoInformado)) {
					return false;
				}
			}
			_i.curLineaAbono_.setValueBuffer("pvptotal", formRecordlineaspedidoscli.iface.pub_commonCalculateField("pvptotal", this.iface.curLineaAbono_));
			break;
		}
		case "idsubcuenta": {
			if (curLineaOriginal.isNull(nombreCampo)) {
				_i.curLineaAbono_.setNull(nombreCampo);
			} else {
				_i.curLineaAbono_.setValueBuffer("idsubcuenta", AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + curLineaOriginal.valueBuffer("codsubcuenta") + "' AND codejercicio = '" + cursor.valueBuffer("codejercicio") + "'"));
			}
			break;
		}
		default: {
			if (curLineaOriginal.isNull(nombreCampo)) {
				_i.curLineaAbono_.setNull(nombreCampo);
			} else {
				_i.curLineaAbono_.setValueBuffer(nombreCampo, curLineaOriginal.valueBuffer(nombreCampo));
			}
		}
	}
	campoInformado[nombreCampo] = true;
	return true;
}

function euromoda_seleccionLineasAbono()
{
	var _i = this.iface;
	var valores = "";	
	var curLineasAbono = new FLSqlCursor("lineasalbaranescli");
	var f= new FLFormSearchDB(curLineasAbono, "seleccionlineasrec");	
	f.setMainWidget();	
	f.exec();	
	if (f.accepted()) {
 		valores = _i.aLineasAbono_;
	} else {
		valores = false;
	}
	
	return valores;
}

function euromoda_ponSeleccionValores(valores)
{
	var _i = this.iface;
	_i.aLineasAbono_ = valores;
}

function euromoda_mostrarDatosAlbaran(idAlbaran)
{
	var _i = this.iface;
	var q = new FLSqlQuery();	
	q.setTablesList("albaranescli");
	q.setSelect("codigo,fecha");
	q.setFrom("albaranescli");
	q.setWhere("idalbaran = '" + idAlbaran + "'");
	if (!q.exec()) {
		return false;
	}
	if (!q.first()) {
		return false;
	}
	var codAlbaran = q.value(0);
	var fecha = AQUtil.dateAMDtoDMA(q.value(1));
	debug("fecha: "+q.value(1));
	_i.lblDatosAlbaranAbono_.text = "Abono del albar�n " + codAlbaran + " con fecha " + fecha;
	
	return true;
}

function euromoda_copiarDatosLineaAbono(idLinea, idLineaOriginal, factor)
{
	return true;
}

function euromoda_pbnInsertarPlantillaTextoO_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbObservaciones").setValue(texto);
}

function euromoda_pbnInsertarPlantillaTextoOT_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbObsTransporte").setValue(texto);
}

function euromoda_ocultarCamposContabilidad()
{
	return true;
}

function euromoda_tbnEmRegenerarCostes_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	//Permite regenerar los costes y m�rgenes de as l�neas. Esto supone borrar los actuales y volver a cargar sin dar avisos.
	var curLineas =  this.child("tdbLineasAlbaranesCli").cursor();
	formRecordpresupuestoscli.iface.pub_actualizaCostes(cursor,curLineas,true);
    this.child("tdbLineasAlbaranesCli").refresh();
}

function euromoda_tbnEmCargarCostes_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	//Permite regenerar los costes y m�rgenes de as l�neas. Esto supone borrar los actuales y volver a cargar sin dar avisos.
	var curLineas =  this.child("tdbLineasAlbaranesCli").cursor();
	formRecordpresupuestoscli.iface.pub_actualizaCostes(cursor,curLineas,false);
    this.child("tdbLineasAlbaranesCli").refresh();

}

function euromoda_ordenTabulacion()
{
	
	var controles = ["fdbCodSerie", "fdbCodCliente", "fdbNombreCliente", "fdbCifNif", "fdbPorDtoEsp", "fdbDtoEsp", "fdbDepartamento", "fdbDocExterrno", "fdbCodClienteFac"];
	for (var i = 0; i < controles.length - 1; i++) {
		if (this.child(controles[i]) && this.child(controles[i + 1])) {
			AQS.setTabOrder(this.child(controles[i]).obj(), this.child(controles[i + 1]).obj());
		}
	}
}

function euromoda_pbnImportarCSV_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbLineasAlbaranesCli").cursor().commitBufferCursorRelation())
			return false;
	}	
	if(!formRecordpedidoscli.iface.importarDatosCSV(cursor)){
		return false;
	}
	_i.calcularTotales();
	this.child("tdbLineasAlbaranesCli").refresh();	
	return true;

}


//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
