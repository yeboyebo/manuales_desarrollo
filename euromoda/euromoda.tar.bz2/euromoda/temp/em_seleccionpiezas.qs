/**************************************************************************
                 em_seleccionpiezas.qs  -  description
                             -------------------
    begin                : lun nov 16 2015
    copyright            : (C) 2015 by YeboYebo S.L.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tdbLineas;
	var todos_;
    function oficial( context ) { interna( context ); }
	function tbnTodos_clicked() {
		return this.ctx.oficial_tbnTodos_clicked();
	}
	function tbnNinguno_clicked() {
		return this.ctx.oficial_tbnNinguno_clicked();
	}
	/*function tdbLineas_primaryKeyToggled(id, checked) {
		return this.ctx.oficial_tdbLineas_primaryKeyToggled(id, checked);
	}*/
	function actualizarChecks(checked) {
		return this.ctx.oficial_actualizarChecks(checked);
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function actualizarOrden() {
		return this.ctx.oficial_actualizarOrden();
	}
	function ordernarLineas() {
		return this.ctx.oficial_ordernarLineas();
	}
	function anadePiezas() {
		return this.ctx.oficial_anadePiezas();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.todos_ = false;
	_i.tdbLineas = this.child("tdbLineas");
	_i.tdbLineas.setReadOnly(true);	
			
	connect(this.child("tbnTodos"), "clicked()", _i, "tbnTodos_clicked");
	connect(this.child("tbnNinguno"), "clicked()", _i, "tbnNinguno_clicked");
	//connect(_i.tdbLineas, "primaryKeyToggled(QVariant, bool)", _i, "tdbLineas_primaryKeyToggled");
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnTodos_clicked()
{
	var _i = this.iface;	
	_i.actualizarChecks(true);
}

function oficial_tbnNinguno_clicked()
{
	var _i = this.iface;
	
	_i.actualizarChecks(false);
}

/*function oficial_tdbLineas_primaryKeyToggled(id, checked)
{
	var _i = this.iface;
	if(_i.todos_) {
		return true;
	}
	var curL = new AQSqlCursor("em_lineasordenest");
	curL.select("idlinea = " + id);
	
	if(!curL.first()) {
		return false;
	}
	
	curL.setModeAccess(AQSql.Edit);
	curL.refreshBuffer();
	curL.setActivatedCommitActions(false);
	
	curL.setValueBuffer("maquetado",checked);
	
	if(!curL.commitBuffer()) {
		return false;
	}
	
	_i.tdbLineas.refresh();
}*/

function oficial_actualizarChecks(checked)
{
	var _i = this.iface;
	_i.todos_ = true;
	var mF = _i.tdbLineas.cursor().mainFilter();
	var fF = _i.tdbLineas.findFilter();
	var f = _i.tdbLineas.filter();

	var filtro = mF;
	if (fF != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += fF;
	}
	if (f != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += f;
	}
	
	if (!filtro || filtro == "") {
		return;
	}
	 
	var qryLineas = new FLSqlQuery();
	qryLineas.setTablesList("lotesstock");
	qryLineas.setSelect("codlote");
	qryLineas.setFrom("lotesstock");
	qryLineas.setWhere(filtro);
	qryLineas.setForwardOnly(true);
	if (!qryLineas.exec()) {
		return false;
	}
	while (qryLineas.next()) {
		_i.tdbLineas.setPrimaryKeyChecked(qryLineas.value("codlote"), checked);
	}	
	_i.tdbLineas.refresh();
	_i.todos_ = false;
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	
	_i.anadePiezas();
	
	this.obj().accept();
}

/*function oficial_anadePiezas()
{
	var _i = this.iface;
	var cursor = _i.tdbLineas.cursor();
	var curLinAlb = formRecordlineasalbaranescli.iface.cursorLA_;
	
   curLinAlb.setModeAccess(curLinAlb.Browse);
   curLinAlb.refreshBuffer(); 		
	
	var progress = 0;
	var seleccionados = this.child("tdbLineas").primarysKeysChecked();

	if(seleccionados.length > 0){
		debug("seleccionados: "+seleccionados);
	//	var curT = new FLSqlCursor("empresa");
	//	curT.transaction(false);
		AQUtil.createProgressDialog(AQUtil.translate("scripts", "A�adiendo l�neas..."), seleccionados.length);	

		for (var i = 0; i < seleccionados.length; i++) {
			AQUtil.setProgress(progress++);
			
			var curMoviStock = new FLSqlCursor("movistock");
    		curMoviStock.setModeAccess(curMoviStock.Insert);
    		curMoviStock.refreshBuffer();	    		
    		
    		curMoviStock.setValueBuffer("codlote",seleccionados[i]);
    		
			var oDatosLote = flfactppal.iface.pub_ejecutarQry("lotesstock","referencia,candisponible,codalmacen","codlote= '" + seleccionados[i] + "' ","lotesstock");
			if (oDatosLote.result != 1) {
				//curT.rollback();
				MessageBox.warning(sys.translate("Error al crear movimiento de los lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				AQUtil.destroyProgressDialog();
				return;
	  		}    		
    		var referencia = oDatosLote.referencia;
    		var canDisponible = oDatosLote.candisponible;
    		var codAlmacen = oDatosLote.codalmacen;
    		
    		
    		debug("referencia: "+referencia);
    		debug("candisponible: "+canDisponible);
    		debug("codAlmacen: "+codAlmacen);
    		
    		curMoviStock.setValueBuffer("referencia",referencia);   	
    		curMoviStock.setValueBuffer("estado","HECHO");
    		curMoviStock.setValueBuffer("cantidad",(-1)*canDisponible);    		
    		var aD = flfactalma.iface.pub_dameDatosStockLinea(curLinAlb);
			if (aD && aD.concepto != "") {
				curMoviStock.setValueBuffer("concepto", aD.concepto);
			}
			var hoy = new Date;
    		curMoviStock.setValueBuffer("fechareal",hoy);
    		curMoviStock.setValueBuffer("horareal",hoy);       		
			var idStock = AQUtil.sqlSelect("stocks", "idstock", "codalmacen = '" + codAlmacen + "' AND referencia = '" + referencia + "'");
			idStock = isNaN(idStock) ? 0 : idStock;			
			curMoviStock.setValueBuffer("idstock",idStock);
			curMoviStock.setValueBuffer("idlineaac",curLinAlb.valueBuffer("idlinea"));   
			//try {
				if(!curMoviStock.commitBuffer()){
					//curT.rollback();
					MessageBox.warning(sys.translate("Error al crear movimiento de los lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
					AQUtil.destroyProgressDialog();
					return;
				}
				
			//} catch(e) {
				//curT.rollback();
			//	MessageBox.warning(sys.translate("Error al crear movimiento de los lotes")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			//	AQUtil.destroyProgressDialog();
			//	return;
			//}
		}
		AQUtil.destroyProgressDialog();
		//curT.commit();
	}
}*/

function oficial_anadePiezas()
{
	var _i = this.iface;
	var cursor = _i.tdbLineas.cursor();
	var curLinAlb = formRecordlineasalbaranescli.iface.cursorLA_;
	
   //curLinAlb.setModeAccess(curLinAlb.Browse);
   //curLinAlb.refreshBuffer(); 		
	var idAlbaran = curLinAlb.valueBuffer("idalbaran");
	var idLineaAlb = curLinAlb.valueBuffer("idlinea");
	var progress = 0;
	var seleccionados = this.child("tdbLineas").primarysKeysChecked();

	if(seleccionados.length > 0){
		debug("seleccionados: "+seleccionados);

		AQUtil.createProgressDialog(AQUtil.translate("scripts", "A�adiendo l�neas..."), seleccionados.length);	

		for (var i = 0; i < seleccionados.length; i++) {
			AQUtil.setProgress(progress++);			
      	var codPieza = seleccionados[i];
      	var oDatosLote = flfactppal.iface.pub_ejecutarQry("lotesstock","referencia,candisponible,codalmacen","codlote= '" + seleccionados[i] + "' ","lotesstock");
			if (oDatosLote.result != 1) {				
				MessageBox.warning(sys.translate("Error al crear movimiento de los lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				AQUtil.destroyProgressDialog();
				return;
	  		}   
      	var cantidad = oDatosLote.candisponible;
      	var referencia = oDatosLote.referencia;
      	
      	var oParam = new Object;
      	oParam.idLineaAlb = idLineaAlb;
      	oParam.codLote = codPieza;
      	oParam.cantidad = (-1)*cantidad;
      	oParam.codAlmacenAlb = AQUtil.sqlSelect("albaranescli","codalmacen","idalbaran = " + idAlbaran);
      	oParam.tipoAlb = "VENTA";
      	if(!formem_asignacionpiezasoe.iface.creaMovLote(oParam)) {
      		AQUtil.destroyProgressDialog();		
      		return false;
      	} 
		}
		/*if(!formem_asignacionpiezasoe.iface.totalizaLineaAlbaran(idLineaAlb)) {
			AQUtil.destroyProgressDialog();		
			return false;
     	} */
		AQUtil.destroyProgressDialog();		
	}
}

function oficial_ordernarLineas()
{
	var tdbLC = this.child("tdbLineas");
	var dtbLC = this.mainWidget().child("tdbLineas").tableRecords();
	tdbLC.autoSortColumn = false;
	var hHeader = dtbLC.horizontalHeader();
	hHeader.setClickEnabled(false);
	hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbLC.setSort(["grupo ASC", "ordengrupo ASC"]);
	dtbLC.refresh(AQS.RefreshData);
}
///// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
