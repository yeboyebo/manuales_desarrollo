/***************************************************************************
                 pr_piezasconsumidas.qs  -  description
                             -------------------
    begin                : vie oct 14 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tdbPiezas, ledTrabajador, ledCodOrden, ledCodPieza, lblTrabajador;
	var tbnQuitarPieza;
	var codAlmacen_;

	var posActualPuntoTrabajador;
	var posActualPuntoOrden;
	var posActualPuntoPieza;

  function oficial( context ) { interna( context ); }
	function trabajadorSet() {
		return this.ctx.oficial_trabajadorSet();
	}
	function tbnModificaCantidad_clicked() {
		return this.ctx.oficial_tbnModificaCantidad_clicked();
	}
	function ledCodOrden_returnPressed() {
		return this.ctx.oficial_ledCodOrden_returnPressed();
	}
	function textChangedTrabajador( text ) {
		return this.ctx.oficial_textChangedTrabajador( text );
	}
	function textChangedOrden(text)	{
		return this.ctx.oficial_textChangedOrden(text);
	}
	function textChangedPieza(text)	{
		return this.ctx.oficial_textChangedPieza(text);
	}
	function volverInicio() {
		return this.ctx.oficial_volverInicio();
	}
	function ledCodPieza_returnPressed() {
		return this.ctx.oficial_ledCodPieza_returnPressed();
	}
	function vinculaPiezaOrden(codPieza, codOrden) {
		return this.ctx.oficial_vinculaPiezaOrden(codPieza, codOrden);
	}
	function desVinculaPiezaOrden(codPieza, codOrden) {
		return this.ctx.oficial_desVinculaPiezaOrden(codPieza, codOrden);
	}
	function filtraPiezas() {
		return this.ctx.oficial_filtraPiezas();
	}
	function tbnQuitarPieza_clicked() {
		return this.ctx.oficial_tbnQuitarPieza_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	_i.tdbPiezas = this.child("tdbPiezas");
	_i.ledTrabajador = this.child("ledTrabajador");
	_i.ledCodOrden = this.child("ledCodOrden");
	_i.ledCodPieza = this.child("ledCodPieza");
	_i.lblTrabajador = this.child("lblTrabajador");
	_i.tbnQuitarPieza = this.child("tbnQuitarPieza");

	_i.posActualPuntoTrabajador = -1;
	_i.posActualPuntoOrden = -1;
	_i.posActualPuntoPieza = -1;
	
	_i.codAlmacen_ = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");

	var campos = ["codlote", "referencia", "cantidad", "codordenconsumo"];
	_i.tdbPiezas.setOrderCols(campos);
	_i.tdbPiezas.setReadOnly(true);

	connect(_i.ledTrabajador, "returnPressed()", _i, "trabajadorSet");
	connect(_i.ledCodOrden, "returnPressed()", _i, "ledCodOrden_returnPressed");
	connect(_i.ledCodPieza, "returnPressed()", _i, "ledCodPieza_returnPressed");
	connect(_i.ledTrabajador, "textChanged(QString)", _i, "textChangedTrabajador");
	connect(_i.ledCodPieza, "textChanged(QString)", _i, "textChangedPieza");
	connect(_i.ledCodOrden, "textChanged(QString)", _i, "textChangedOrden");

	connect(_i.tbnQuitarPieza, "clicked()", this, "iface.tbnQuitarPieza_clicked()");
	connect(this.child("tbnModificaCantidad"), "clicked()", this, "iface.tbnModificaCantidad_clicked()");
	

	_i.ledTrabajador.text = "";
	_i.ledCodPieza.text = "";
	_i.ledCodOrden.text = "";
	_i.lblTrabajador.text = "";
	_i.ledTrabajador.setFocus();
	
	_i.filtraPiezas();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnQuitarPieza_clicked()
{
	var _i = this.iface;
	
	var curPieza = _i.tdbPiezas.cursor();

	var codOrden = curPieza.valueBuffer("codordenconsumo");
	if (!codOrden || codOrden == "") {
		MessageBox.warning(sys.translate("Debe indicar la orden de producci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var codPieza = curPieza.valueBuffer("codlote");
	if (!codPieza || codPieza == "") {
		MessageBox.warning(sys.translate("Debe seleccionar la pieza"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var res = MessageBox.information(sys.translate("Va a desvincular la pieza %1 de la orden %2.\n�Est� seguro?").arg(codPieza).arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		return;
	}
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (_i.desVinculaPiezaOrden(codPieza, codOrden)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.warning(sys.translate("Error al desvincular la pieza %1 con la orden %2").arg(codPieza).arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		}
	} catch (e) {
		MessageBox.warning(sys.translate("Error al desvincular la pieza %1 con la orden %2:\n").arg(codPieza).arg(codOrden) + e, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		curT.rollback();
	}
	_i.filtraPiezas();
}

function oficial_filtraPiezas()
{
	var _i = this.iface;
	var codOrden = _i.ledCodOrden.text;
	var filtro = false;
	if (codOrden && codOrden != "") {
		filtro = "codordenconsumo = '" + codOrden + "'";
	}
debug("Filtro = " + filtro);
	_i.tdbPiezas.setFilter(filtro);
	_i.tdbPiezas.refresh();
}

function oficial_ledCodPieza_returnPressed()
{
	var _i = this.iface;
	var codOrden = _i.ledCodOrden.text;
	if (!codOrden || codOrden == "") {
		MessageBox.warning(sys.translate("Debe indicar la orden de producci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var codPieza = _i.ledCodPieza.text;
	if (!codPieza || codPieza == "") {
		MessageBox.warning(sys.translate("Debe indicar el c�digo de pieza"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	try {
		if (_i.vinculaPiezaOrden(codPieza, codOrden)) {
			curT.commit();
		} else {
			curT.rollback();
			MessageBox.warning(sys.translate("Error al vincular la pieza %1 con la orden %2").arg(codPieza).arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		}
	} catch (e) {
		MessageBox.warning(sys.translate("Error al vincular la pieza %1 con la orden %2:\n").arg(codPieza).arg(codOrden) + e, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		curT.rollback();
	}
	_i.filtraPiezas();
}

function oficial_vinculaPiezaOrden(codPieza, codOrden)
{
	var _i = this.iface;
	codOrden = codOrden.toUpperCase();
	if (!AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", "codorden = '" + codOrden + "'")) {
		MessageBox.warning(sys.translate("La orden %1 no existe").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var idProceso = AQUtil.sqlSelect("pr_procesos", "idproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "'");
	if (!idProceso) {
		MessageBox.warning(sys.translate("No se ha encontrado el proceso de producci�n asociado a la orden %1").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}

	codPieza = codPieza.toUpperCase();
	var curPieza = new FLSqlCursor("lotesstock");
	curPieza.select("codlote = '" + codPieza + "' OR codigogit = '" + codPieza + "'");
	if (!curPieza.first()) {
		MessageBox.warning(sys.translate("La pieza %1 no existe").arg(codPieza), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	curPieza.setModeAccess(curPieza.Browse);
	curPieza.refreshBuffer();
	
// 	if (!curPieza.isNull("codordenconsumo")) {
// 		var codOrdenPrevia = curPieza.valueBuffer("codordenconsumo");
// 		MessageBox.warning(sys.translate("La pieza %1 ya est� asociada a la orden %2").arg(codPieza).arg(codOrdenPrevia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 		return false;
// 	}
	var disp = curPieza.valueBuffer("candisponible");
	var consumo = disp;
debug("consumo " + consumo );
	if (!consumo) {
		return false;
	}
	consumo *= -1;
	
	var hoy = new Date();
	var referencia = curPieza.valueBuffer("referencia");
	var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + _i.codAlmacen_ + "'");
	if (!idStock) {
		MessageBox.warning(sys.translate("No se ha encontrado un registro de stock para la referencia %1 y el almac�n %2").arg(referencia).arg(_i.codAlmacen_), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	
	var curMS = new FLSqlCursor("movistock");
	curMS.setModeAccess(curMS.Insert);
	curMS.refreshBuffer();
	curMS.setValueBuffer("referencia", referencia);
	curMS.setValueBuffer("estado", "HECHO");
	curMS.setValueBuffer("cantidad", consumo);
	curMS.setValueBuffer("fechareal", hoy.toString().left(10));
	curMS.setValueBuffer("horareal", hoy.toString().right(8));
	curMS.setValueBuffer("idstock", idStock);
	curMS.setValueBuffer("codlote", curPieza.valueBuffer("codlote"));
	curMS.setValueBuffer("idproceso", idProceso);
	curMS.setValueBuffer("codordenconsumo", codOrden);
	if (!curMS.commitBuffer()) {
		return false;
	}
// 	curPieza.setValueBuffer("codordenconsumo", codOrden);
// 	if (!curPieza.commitBuffer()) {
// 		return false;
// 	}
	return true;
}

function oficial_desVinculaPiezaOrden(codPieza, codOrden)
{
	var _i = this.iface;
	if (!AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", "codorden = '" + codOrden + "'")) {
		MessageBox.warning(sys.translate("La orden %1 no existe").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	if (!AQSql.del("movistock", "codlote = '" + codPieza + "' AND codordenconsumo = '" + codOrden + "'")) {
		MessageBox.warning(sys.translate("Error al eliminar los movimientos de stock asociados a la pieza %1 y a la orden %2").arg(codPieza).arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
// 	var idProceso = AQUtil.sqlSelect("pr_procesos", "idproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "'");
// 	if (!idProceso) {
// 		MessageBox.warning(sys.translate("No se ha encontrado el proceso de producci�n asociado a la orden %1").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 		return false;
// 	}
// 
// 	var curPieza = new FLSqlCursor("lotesstock");
// 	curPieza.select("codlote = '" + codPieza + "'");
// 	if (!curPieza.first()) {
// 		MessageBox.warning(sys.translate("La pieza %1 no existe").arg(codPieza), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 		return false;
// 	}
// 	curPieza.setModeAccess(curPieza.Edit);
// 	curPieza.refreshBuffer();
// 	
// 	if (!AQSql.del("movistock", "codlote = '" + codPieza + "' AND idproceso = " + idProceso)) {
// 		MessageBox.warning(sys.translate("Error al eliminar los movimientos de stock asociados a la pieza %1 y al proceso %2").arg(codPieza).arg(idProceso), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 		return false;
// 	}
// 	curPieza.setNull("codordenconsumo");
// 	if (!curPieza.commitBuffer()) {
// 		return false;
// 	}
// 	return true;
}

function oficial_tbnModificaCantidad_clicked()
{
	var _i = this.iface;
	var curMS = _i.tdbPiezas.cursor();
	var idMov = curMS.valueBuffer("idmovimiento");
	if (!idMov) {
		return;
	}
	var codPieza = curMS.valueBuffer("codlote");
	var disp = AQUtil.sqlSelect("lotesstock", "candisponible", "codlote = '" + codPieza + "'");
	var disp = disp - curMS.valueBuffer("cantidad");
	var consumo = Input.getNumber(sys.translate("Metros consumidos"), disp, 0, 0, disp, sys.translate("Pieza %1").arg(codPieza));
	if (consumo == undefined) {
		return false;
	}
	consumo *= -1;
	if (!AQSql.update("movistock", ["cantidad"], [consumo], "idmovimiento = " + idMov)) {
		MessageBox.warning(sys.translate("Error al modificar el movimiento de stock asociados a la pieza %1").arg(codPieza), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

/** \D
Busca el trabajador en la tabla de trabajadores
\end */
function oficial_trabajadorSet()
{
	var _i = this.iface;
	var nomTrabajador = AQUtil.sqlSelect( "pr_trabajadores", "nombre", "idtrabajador = '" + _i.ledTrabajador.text + "'");
	if (nomTrabajador)  {
		_i.lblTrabajador.text = nomTrabajador;
		_i.ledCodOrden.text = "";
		_i.ledCodPieza.text = "";
		_i.ledCodOrden.setFocus();
	} else {
		_i.lblTrabajador.text = "";
		_i.ledCodOrden.text = "";
		_i.ledCodPieza.text = "";
		_i.ledTrabajador.setFocus();
	}
}

function oficial_ledCodOrden_returnPressed()
{
	var _i = this.iface;
	var codOrden = _i.ledCodOrden.text;
	if (codOrden && codOrden != "") {
		codOrden = codOrden.toUpperCase();
	}
	if (AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", "codorden = '" + codOrden + "'")) {
		_i.ledCodPieza.text = "";
		_i.ledCodPieza.setFocus();
	} else {
		MessageBox.warning(sys.translate("La orden %1 no existe").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		_i.ledCodPieza.text = "";
		_i.ledCodOrden.setFocus();
	}
	_i.filtraPiezas();
}


/** \D
Filtrado del texto de la linea de edici�n de trabajador para trabajar de forma r�pida utilizando solamente el teclado n�merico.
\end */
function oficial_textChangedTrabajador(text)
{
}

/** \D
Filtrado del texto de la linea de edici�n de tareas para trabajar de forma r�pida utilizando solamente el teclado n�merico.
\end */
function oficial_textChangedOrden(text)
{
	var txt = text;
	var _i = this.iface;
	/** \C Al introducir el car�cter '/' al final del texto del campo de tarea, se borra el campo de tarea y el del trabajador, situando el foco en este �ltimo.
	\end */
	if ( txt.endsWith( "/" ) ) {
		_i.volverInicio();
	}
	/** \C Al introducir el car�cter '*' al final del texto del campo de tarea se cambia el contenido actual de este
	campo por la cadena 'TA'. La cadena 'TA' corresponde al prefijo utilizado en los c�digos de tareas.
	\end */
	if ( txt.endsWith( "*" ) ) {
		_i.ledCodOrden.text = "OP";
		_i.ledCodOrden.setFocus();
	}
	/** \C Al introducir el car�cter '.' se reformatea el valor del c�digo de la tareas reemplazando dicho el car�cter "."
	por los ceros "0" necesarios hasta completar el n�mero de d�gitos total, a su vez elimina los caracteres sobrantes cuando se supere el l�mite de d�gitos.
	\end */
	_i.posActualPuntoOrden = flcolaproc.iface.pub_formatearCodigo( _i.ledCodOrden, 10, _i.posActualPuntoOrden );
}

function oficial_textChangedPieza(text)
{
	var txt = text;
	var _i = this.iface;
	/** \C Al introducir el car�cter '/' al final del texto del campo de tarea, se borra el campo de tarea y el del trabajador, situando el foco en este �ltimo.
	\end */
	if ( txt.endsWith( "/" ) ) {
		_i.volverInicio();
	}
	/** \C Al introducir el car�cter '*' al final del texto del campo de tarea se cambia el contenido actual de este
	campo por la cadena 'TA'. La cadena 'TA' corresponde al prefijo utilizado en los c�digos de tareas.
	\end */
	if ( txt.endsWith( "*" ) ) {
		_i.ledCodPieza.text = "PZ";
		_i.ledCodPieza.setFocus();
	}
	/** \C Al introducir el car�cter '.' se reformatea el valor del c�digo de la tareas reemplazando dicho el car�cter "."
	por los ceros "0" necesarios hasta completar el n�mero de d�gitos total, a su vez elimina los caracteres sobrantes cuando se supere el l�mite de d�gitos.
	\end */
	_i.posActualPuntoPieza = flcolaproc.iface.pub_formatearCodigo( _i.ledCodPieza, 10, _i.posActualPuntoPieza );
}

function oficial_volverInicio()
{
	var _i = this.iface;
	_i.lblTrabajador.text = "";
	_i.ledCodOrden.text = "";
	_i.ledCodPieza.text = "";
	_i.ledTrabajador.text = "";
	_i.ledTrabajador.setFocus();
	
	_i.filtraPiezas()
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
