/***************************************************************************
                 em_cortehor.qs  -  description
                             -------------------
    begin                : mar jun 4 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var usuarioActual_;
	var oColorLinea_, codAsigConfAnt_;
	function oficial( context ) { interna( context ); }
	function dameColorLinea(fN, fV, cursor, sel, fT) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, sel, fT);
	}
	function tbnCambiarUsuario_clicked() {
		return this.ctx.oficial_tbnCambiarUsuario_clicked();
	}
	function muestraUsuarioActual() {
		return this.ctx.oficial_muestraUsuarioActual();
	}
  function filtra() {
    return this.ctx.oficial_filtra();
  }
  function filtraPtes() {
    return this.ctx.oficial_filtraPtes();
  }
  function dameFiltro() {
    return this.ctx.oficial_dameFiltro();
  }
  function dameFiltroCortados() {
    return this.ctx.oficial_dameFiltroCortados();
  }
  function recordChoosed() {
    return this.ctx.oficial_recordChoosed();
  }
  function cortaLote(oParam) {
    return this.ctx.oficial_cortaLote(oParam);
  }
  function controlFinTarea(codOrden) {
    return this.ctx.oficial_controlFinTarea(codOrden);
  }
  function tdbLotesCortados_recordChoosed() {
    return this.ctx.oficial_tdbLotesCortados_recordChoosed();
  }
  function tbnBorraFiltro_clicked() {
    return this.ctx.oficial_tbnBorraFiltro_clicked();
  }
  function ledCodOrden_returnPressed() {
    return this.ctx.oficial_ledCodOrden_returnPressed();
  }
  function anchuraCols() {
    return this.ctx.oficial_anchuraCols();
  }
  	function cargaImagen() {
		return this.ctx.oficial_cargaImagen();
	}
	function borraImagen() {
		return this.ctx.oficial_borraImage();
	}
	function pbnImagen_clicked() {
		return this.ctx.oficial_pbnImagen_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_cortaLote(oParam) {
		return this.cortaLote(oParam);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  /*if (sys.nameBD() == "abanq_creaciones") {
    sys.warnMsgBox(sys.translate("Funconalidad s�lo disponible en pruebas"));
    this.close();
    return;
  }*/
	var _i = this.iface;

	connect(this.child("tbnCambiarUsuario"), "clicked()", _i, "tbnCambiarUsuario_clicked");
	connect(this.child("tbnOK"), "clicked()", _i, "recordChoosed");
	connect(this.child("tbnReabrir"), "clicked()", _i, "tdbLotesCortados_recordChoosed");
	connect(this.child("tbnBorraFiltro"), "clicked()", _i, "tbnBorraFiltro_clicked");
	connect(this.child("ledCodOrden"), "returnPressed()", _i, "ledCodOrden_returnPressed");
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "recordChoosed");
	connect(this.child("tdbLotesCortados").cursor(), "recordChoosed()", _i, "tdbLotesCortados_recordChoosed");
	connect(this.child("tableDBRecords"), "currentChanged()", _i, "cargaImagen");
	connect(this.child("pbnImagen"), "clicked()", _i, "pbnImagen_clicked");
	flprodppal.iface.pub_formatoTablaProd(this.mainWidget().child("tdbLotesCortados").tableRecords());
	flprodppal.iface.pub_formatoTablaProd(this.mainWidget().child("tableDBRecords").tableRecords());
	
  _i.anchuraCols();
  _i.filtra();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_dameColorLinea(fN, fV, cursor, sel, fT)
{
	debug("oficial_dameColorLinea");
  var _i = this.iface;
  var codAsigConf = cursor.valueBuffer("codasigconf");
  if (!sel && codAsigConf == _i.codAsigConfAnt_) {
    return _i.oColorLinea_;
  }
  if (!sel) {
    _i.codAsigConfAnt_ = codAsigConf;
	} else {
    _i.codAsigConfAnt_ = -1;
	}
	var color = "";
  if (cursor.valueBuffer("estado") == "Enviada") {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_azul_sel" : "fondo_azul");
  } else {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_gris_sel" : "fondo_gris");
  }
  if (color != "") {
    _i.oColorLinea_ = [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
    return _i.oColorLinea_;
  } else
    _i.codAsigConfAnt_ = -1;
}

function oficial_tbnCambiarUsuario_clicked()
{
	var _i = this.iface;
	
	var f = new FLFormSearchDB("pr_bustrabajador");
	var curU = f.cursor();
	
	f.setMainWidget();
	var idUsuario = f.exec("idtrabajador");

	if (!idUsuario) {
		return;
	}
	_i.usuarioActual_ = idUsuario;
	_i.muestraUsuarioActual();
}

function oficial_muestraUsuarioActual()
{
	var _i = this.iface;
	var usuario;
	if (_i.usuarioActual_) {
		var n = AQUtil.sqlSelect("flusers", "descripcion", "iduser = '" + _i.usuarioActual_ + "'");
		usuario = n + " (" + _i.usuarioActual_ + ")";
	} else {
		usuario = sys.translate("Usuario actual no establecido");
	}
	sys.setObjText(this, "lblUsuario", usuario);
}

function oficial_filtra()
{
  var _i  = this.iface;
  
	_i.filtraPtes();
	
	var fC = _i.dameFiltroCortados();
  this.child("tdbLotesCortados").cursor().setMainFilter(fC);
	this.child("tdbLotesCortados").refresh();
// 	flprodppal.iface.pub_alturaFilas(this.c);
}

function oficial_filtraPtes()
{
	var _i  = this.iface;
  
	var f = _i.dameFiltro();
  this.child("tableDBRecords").cursor().setMainFilter(f);
	this.child("tableDBRecords").refresh();
// 	flprodppal.iface.pub_alturaFilas(this.child("tableDBRecords"));
}

function oficial_dameFiltro()
{
	var   f = "lotesstock.estado = 'PTE' AND pr_tareas.estado = 'PTE'";
  var codProd = this.child("ledCodOrden").text;
	if (codProd && codProd != "") {
		f += (" AND codordenproduccion LIKE '%" + codProd + "%'");
	}
  return f;
}

function oficial_dameFiltroCortados()
{
  var   f = "lotesstock.estado = 'CORTADO' AND pr_ordenesproduccion.estado <> 'TERMINADA'";
	var codProd = this.child("ledCodOrden").text;
	if (codProd && codProd != "") {
		f += (" AND codordenproduccion LIKE '%" + codProd + "%'");
	}
  return f;
}

function oficial_recordChoosed()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  var idUsuario = _i.usuarioActual_;
  if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
  }
	
  var f = new FLFormSearchDB("em_cantidadcortehor");
  var curCCH = f.cursor();
  
  var sesion = flfactalma.iface.pub_dameSesion();
  curCCH.select("sesion = '" + sesion + "'");
  if (curCCH.first()) {
    curCCH.setModeAccess(curCCH.Edit);
  } else {
    curCCH.setModeAccess(curCCH.Insert);
  }
  curCCH.refreshBuffer();
  curCCH.setValueBuffer("sesion", sesion);
  curCCH.setValueBuffer("idusuario", idUsuario);
  curCCH.setValueBuffer("referencia", cursor.valueBuffer("referencia"));
  curCCH.setValueBuffer("canprogramada", cursor.valueBuffer("canprogramada"));
  curCCH.setValueBuffer("cancortada", cursor.valueBuffer("canlote"));
	
  f.setMainWidget();
  idUsuario= f.exec("idusuario");
  if (!idUsuario) {
    return;
  }
  if (!curCCH.commitBuffer()) {
    return;
  }
  
  var oParam = new Object;
  oParam.canCortada = curCCH.valueBuffer("cancortada");
  oParam.idUsuario = idUsuario;
  oParam.codLote = cursor.valueBuffer("codlote");
	oParam.codOrden = cursor.valueBuffer("codordenproduccion");
	oParam.estado = "PTE";
	var codOrden = cursor.valueBuffer("codordenproduccion");
  
  oParam.errorMsg = sys.translate("Error al marcar el lote %1 como cortado").arg(oParam.codLote);
  var f = new Function("oParam", "return formem_cortehor.iface.cortaLote(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  sys.infoMsgBox(sys.translate("El lote %1 ha sido marcado como CORTADO correctamente").arg(oParam.codLote));
    
  this.child("tableDBRecords").refresh();
	this.child("tdbLotesCortados").refresh();
//  sys.warnMsgBox(sys.translate("Cortada %1").arg(oParam.canCortada));
	
	
}

function oficial_controlFinTarea(codOrden)
{
	if (AQUtil.sqlSelect("lotesstock", "codlote", "codordenproduccion = '" + codOrden + "' AND estado <> 'CORTADO'")) {
		return true;
	}
	
	var f = new FLFormSearchDB("em_resumencortehor");
  var curOP = f.cursor();
  
  curOP.select("codorden = '" + codOrden + "'");
  if (!curOP.first()) {
		return false;
	}
	curOP.setModeAccess(curOP.Edit);
  curOP.refreshBuffer();
	
  f.setMainWidget();
  var codOrdenOK = f.exec("codorden");
  if (!codOrdenOK) {
    return false;
  }
  return true;
}

function oficial_cortaLote(oParam)
{
	var _i = this.iface;
  var codLote = oParam.codLote;
  var idUsuario = oParam.idUsuario;
  var canCortada = oParam.canCortada;
	var codOrden = oParam.codOrden;
  
  var hoy = new Date;
  
  var curLote = new FLSqlCursor("lotesstock");
  curLote.select("codlote = '" + codLote + "'");
  if (!curLote.first()) {
    oParam.errorMsg = sys.translate("Error al localizar el lote %1").arg(codLote);
    return false;
  }
  curLote.setModeAccess(curLote.Edit);
  curLote.refreshBuffer();
  curLote.setValueBuffer("canlote", canCortada);
  curLote.setValueBuffer("idusuariocorte", idUsuario);
  curLote.setValueBuffer("fechacorte", hoy.toString().left(10));
  curLote.setValueBuffer("horacorte", hoy.toString().right(8));
  curLote.setValueBuffer("estado", "CORTADO");
	var codOrden = curLote.valueBuffer("codordenproduccion");
  if (!curLote.commitBuffer()) {
    oParam.errorMsg = sys.translate("Error al marcar el lote %1 como CORTADO").arg(codLote);
    return false;
  }
  if (oParam.estado != "CORTADO") {
		AQS.Application_restoreOverrideCursor();
		if (!_i.controlFinTarea(codOrden)) {
			oParam.errorMsg = sys.translate("Error al confirmar lor cortes de la orden %1").arg(codOrden);
			return false;
		}
	}
	if ("revisaAlarmas" in oParam && oParam["revisaAlarmas"]) {
		if (!formem_resumencortehor.iface.pub_gestionAlarmas(codOrden)) {
			return false;
		}
	}
  return true;
}

function oficial_tdbLotesCortados_recordChoosed()
{
	var _i = this.iface;
  var cursor = this.child("tdbLotesCortados").cursor();
	
	var codOrden = cursor.valueBuffer("codordenproduccion");
	if (AQUtil.sqlSelect("pr_ordenesproduccion", "materialconfok", "codorden = '" + codOrden + "'")) {
		sys.warnMsgBox(sys.translate("La orden %1 ya tiene el material preparado. No puede modificar el lote").arg(codOrden));
		return false;
	}
// 	if (AQUtil.sqlSelect("em_alarmasmat", "idalarma", "codorden = '" + codOrden + "'")) {
// 		sys.warnMsgBox(sys.translate("La orden %1 tiene alertas de material. No puede modificar el lote").arg(codOrden));
// 		return false;
// 	}
  
  var idUsuario = _i.usuarioActual_;
  if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return;
		}
		idUsuario = _i.usuarioActual_;
  }
	
  var f = new FLFormSearchDB("em_cantidadcortehor");
  var curCCH = f.cursor();
  
  var sesion = flfactalma.iface.pub_dameSesion();
  curCCH.select("sesion = '" + sesion + "'");
  if (curCCH.first()) {
    curCCH.setModeAccess(curCCH.Edit);
  } else {
    curCCH.setModeAccess(curCCH.Insert);
  }
  curCCH.refreshBuffer();
  curCCH.setValueBuffer("sesion", sesion);
  curCCH.setValueBuffer("idusuario", idUsuario);
  curCCH.setValueBuffer("referencia", cursor.valueBuffer("referencia"));
  curCCH.setValueBuffer("canprogramada", cursor.valueBuffer("canprogramada"));
  curCCH.setValueBuffer("cancortada", cursor.valueBuffer("canlote"));
	
  f.setMainWidget();
  idUsuario= f.exec("idusuario");
  if (!idUsuario) {
    return;
  }
  if (!curCCH.commitBuffer()) {
    return;
  }
  
  var oParam = new Object;
  oParam.canCortada = curCCH.valueBuffer("cancortada");
  oParam.idUsuario = idUsuario;
  oParam.codLote = cursor.valueBuffer("codlote");
	oParam.codOrden = cursor.valueBuffer("codordenproduccion");
	oParam.estado = "CORTADO";
	oParam.revisaAlarmas = true;
  
  oParam.errorMsg = sys.translate("Error al revisar el lote %1 como cortado").arg(oParam.codLote);
  var f = new Function("oParam", "return formem_cortehor.iface.cortaLote(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  sys.infoMsgBox(sys.translate("El lote %1 ha sido revisado correctamente").arg(oParam.codLote));
    
  this.child("tableDBRecords").refresh();
	this.child("tdbLotesCortados").refresh();
}

function oficial_tbnBorraFiltro_clicked()
{
	var _i = this.iface;
	
	this.child("ledCodOrden").text = "";
	this.child("ledCodOrden").setFocus();
	_i.filtra();
}


function oficial_ledCodOrden_returnPressed()
{
	var _i = this.iface;
	_i.filtra();
}

function oficial_anchuraCols()
{
	var oC = [["referencia", 75], ["codordenproduccion", 115], ["idtarea", 110], ["descripcion", 380], ["codtamanoem", 120], ["codcolorem", 150], ["lotesstock.canprogramada", 80], ["lotesstock.canlote", 80]];
	
	for (var c = 0; c < oC.length; c++) {
		this.child("tableDBRecords").setColumnWidth(oC[c][0], oC[c][1]);
		this.child("tdbLotesCortados").setColumnWidth(oC[c][0], oC[c][1]);
	}
	
	var tdbLC = this.child("tdbLotesCortados");
	var dtbLC = this.mainWidget().child("tdbLotesCortados").tableRecords();
	
	tdbLC.autoSortColumn = false;
	var hHeader = dtbLC.horizontalHeader();
  hHeader.setClickEnabled(false);
  hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbLC.setSort(["fechacorte DESC", "horacorte DESC"]);
	dtbLC.refresh(AQS.RefreshData);
}

function oficial_cargaImagen()
{
	var _i = this.iface;
	_i.borraImagen();
	var cursor = this.child("tableDBRecords").cursor();
	var referencia = cursor.valueBuffer("referencia");
	if (referencia == "") {
		_i.borraImagen();
		return;
	}	
	var imagen = AQUtil.sqlSelect("articulos a INNER JOIN em_dibujos d ON a.coddibestamp = d.coddibujoem INNER JOIN em_disenos dis ON d.coddiseno = dis.coddiseno", "COALESCE(dis.urlambiente,dis.urlbajaresolucion)", "a.referencia = '" + referencia + "'", "articulos");
	
	if(!imagen || imagen == ""){
		return;
	}
	debug("////////hace consulta imagen");
	var i = new QImage;
	i.load(imagen);
	var s = this.child("pbnImagen").size;
	var i2 = i.scale(s, AQS.ScaleMin);
	var p = new QPixmap;
	p.convertFromImage(i2);
	//this.child("lblImagen").pixmap = p;
	this.child("pbnImagen").pixmap = p;
}

function oficial_borraImage()
{
	this.child("pbnImagen").pixmap = new QPixmap;
}

function oficial_pbnImagen_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tableDBRecords").cursor();
	var referencia = cursor.valueBuffer("referencia");
	if (referencia == "") {
		_i.borraImagen();
		return;
	}	
	
	var imagenAmbiente, imagenBaja;
	if (referencia == "") {
		_i.borraImagen();
		return;
	}
	
	var qImagenes = new AQSqlQuery;
	qImagenes.setSelect("dis.urlambiente, dis.urlbajaresolucion");
	qImagenes.setFrom("articulos a INNER JOIN em_dibujos d ON a.coddibestamp = d.coddibujoem INNER JOIN em_disenos dis ON d.coddiseno = dis.coddiseno");
	qImagenes.setWhere("a.referencia = '" + referencia + "'"); 			

	if (!qImagenes.exec()){
		return;
	}  
	if(qImagenes.first())
	{
		imagenAmbiente = qImagenes.value("dis.urlambiente");
		imagenBaja = qImagenes.value("dis.urlbajaresolucion");

	}
	if(imagenAmbiente && imagenAmbiente != "") {
		if(File.exists(imagenAmbiente)) {
			sys.openUrl(imagenAmbiente);
			//fleumoesta.iface.pub_abrirURL(imagenAlta);			
		}//else {
		//	sys.warnMsgBox(sys.translate("La imagen en alta resoluci�n no se encuentra en la ubicaci�n %1").arg(imagenAlta));
		//}
	}else if (imagenBaja && imagenBaja != "") {
		if(File.exists(imagenBaja)) {
			sys.openUrl(imagenBaja);
			//fleumoesta.iface.pub_abrirURL(imagenBaja);	
		}//else {
		//	sys.warnMsgBox(sys.translate("La imagen en baja resoluci�n no se encuentra en la ubicaci�n %1").arg(imagenBaja));
		//}
	}else {		
		sys.warnMsgBox(sys.translate("No hay ninguna imagen cargada ni de ambiente  ni de baja resoluci�n."));
	}
	
	
	/*var imagen = AQUtil.sqlSelect("articulos a INNER JOIN em_dibujos d ON a.coddibestamp = d.coddibujoem INNER JOIN em_disenos dis ON d.coddiseno = dis.coddiseno", "dis.urlaltaresolucion", "a.referencia = '" + referencia + "'", "articulos");
	if(!imagen || imagen == "") {
		return;
	}
	sys.openUrl(imagen);	*/
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////