/***************************************************************************
                 em_dividirpiezas.qs  -  description
                             -------------------
    begin                : mar sep 27 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
  function calculateField(fN: String)
  {
    return this.ctx.interna_calculateField(fN);
  }
  function validateForm()
  {
    return this.ctx.interna_validateForm();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  function oficial(context)
  {
    interna(context);
  }
  function ledNumPiezas_textChanged(t) {
		return this.ctx.oficial_ledNumPiezas_textChanged(t);
	}
	function ledLongPieza_textChanged(t) {
		return this.ctx.oficial_ledLongPieza_textChanged(t);
	}
	function pbnAceptar_clicked() {
		return this.ctx.oficial_pbnAceptar_clicked();
	}
	function pbnAceptarMas_clicked() {
		return this.ctx.oficial_pbnAceptarMas_clicked();
	}
	function grabarPiezas() {
		return this.ctx.oficial_grabarPiezas();
	}
	function generaLineasPiezas(c, nP, lP, u) {
		return this.ctx.oficial_generaLineasPiezas(c, nP, lP, u);
	}
	function iniciarValores() {
		return this.ctx.oficial_iniciarValores();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
Este formulario realiza la gestion de los albaranes a clientes.

Los albaranes pueden ser generados de forma manual o a partir de uno o mas pedidos.
\end */
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
	connect(this.child("ledNumPiezas"), "textChanged(QString)", _i, "ledNumPiezas_textChanged");
	connect(this.child("ledLongPieza"), "textChanged(QString)", _i, "ledLongPieza_textChanged");
	connect(this.child("pbnAceptar"), "clicked()", _i, "pbnAceptar_clicked()");
	connect(this.child("pbnAceptarMas"), "clicked()", _i, "pbnAceptarMas_clicked()");
	this.child("pushButtonAccept").close();
	
	_i.iniciarValores();
}

function interna_calculateField(fN)
{
	var valor;
	switch (fN) {
		case "longitud": {
			var nP = this.child("ledNumPiezas").text;
			nP = isNaN(nP) ? 0 : nP;
			var lP = this.child("ledLongPieza").text;
			lP = isNaN(lP) ? 0 : lP;
			valor = nP * lP;
			break;
		}
	}
  return valor;
}

function interna_validateForm()
{
  var cursor = this.cursor();
  return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_ledNumPiezas_textChanged(t)
{
  var _i = this.iface;
	this.child("ledLongitud").text = _i.calculateField("longitud");
}

function oficial_ledLongPieza_textChanged(t)
{
  var _i = this.iface;
	this.child("ledLongitud").text = _i.calculateField("longitud");
}

function oficial_pbnAceptar_clicked()
{
  var _i = this.iface;
  if (!_i.grabarPiezas()) {
		return false;
	}
  this.accept();
}

function oficial_grabarPiezas()
{
  var _i = this.iface;
  var c;
	try {
		c = formSearchem_asignarpiezas.iface.curLineaPedido_;
	} catch (e) {
		c = formem_asignarpiezas.iface.curLineaPedido_;
	}
	c.refreshBuffer();
  var pendiente = c.valueBuffer("pendiente");
	
	var l = this.child("ledLongitud").text;
  l = isNaN(l) ? 0 : l;
  if (l > parseFloat(pendiente)) {
    MessageBox.warning(sys.translate("La cantidad indicada (%1) es mayor que la cantidad pendiente de servir (%2)").arg(l).arg(pendiente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  var nP = this.child("ledNumPiezas").text;
  nP = isNaN(nP) ? 0 : nP;
  var lP = this.child("ledLongPieza").text;
  lP = isNaN(lP) ? 0 : lP;
	var u = this.child("ledUbicacion").text;
  if (!_i.generaLineasPiezas(c, nP, lP, u)) {
    return false;
  }
  var _f = formSearchem_asignarpiezas ? formSearchem_asignarpiezas : formem_asignarpiezas;
  _f.child("tdbLineasPedidosProv").refresh();
	_f.child("tdbPiezas").refresh();
  return true;
}

function oficial_pbnAceptarMas_clicked()
{
	var _i = this.iface;
  if (!_i.grabarPiezas()) {
		return false;
	}
	_i.iniciarValores();
}

function oficial_iniciarValores()
{
	this.child("ledNumPiezas").text = 1;
	this.child("ledLongPieza").text = "";
	this.child("ledNumPiezas").setFocus();
	this.child("ledNumPiezas").selectAll();
	
	var c;
	try {
		c = formSearchem_asignarpiezas.iface.curLineaPedido_;
	} catch (e) {
		c = formem_asignarpiezas.iface.curLineaPedido_;
	}
	var referencia = c.valueBuffer("referencia");
	var codAlmacen = "1";
	var ubicacion = AQUtil.sqlSelect("stocks", "ubicacion", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
	this.child("ledUbicacion").text = ubicacion ? ubicacion : "";	
}

function oficial_generaLineasPiezas(c, nP, lP, ubicacion)
{
debug("oficial_generaLineasPiezas " + ubicacion);
	var _i = this.iface;
  if (nP <= 0) {
    return false;
  }
  
  var curLA = new FLSqlCursor("lineasalbaranesprov");
	var curAlbaran = formRecordalbaranesprov.cursor();
	if (curAlbaran.modeAccess() == curAlbaran.Insert) {
		var curLA2 = formRecordalbaranesprov.child("tdbLineasAlbaranesProv").cursor();
		if (!curLA2.commitBufferCursorRelation()) {
			return false;
		}
	}
	var idAlbaran = curAlbaran.valueBuffer("idalbaran");
	var idLineaPedido = c.valueBuffer("idlinea");
	var referencia = c.valueBuffer("referencia");
	
	/// El movimiento pendiente asociado a la l�nea de pedido se decrementar� (no se borra nunca para poderlo usar si se desalbarana)
	var curMSPte = new FLSqlCursor("movistock");
	curMSPte.select("idlineapp = " + idLineaPedido + " AND estado = 'PTE'");
	if (!curMSPte.first()) {
		MessageBox.warning(sys.translate("scripts", "No se encuentra el movimiento pendiente correspondiente a la l�nea de pedido seleccionada"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	curMSPte.setModeAccess(curMSPte.Edit);
	curMSPte.refreshBuffer();
	var canPendiente = curMSPte.valueBuffer("cantidad");
	
	/// Localizamos o creamos la l�nea de albar�n a la que asociar las piezas
	var idLA;
  curLA.select("idalbaran = " + idAlbaran + " AND idlineapedido = " + c.valueBuffer("idlinea"));
	if (!curLA.first()) {
		curLA.setModeAccess(curLA.Insert);
    curLA.refreshBuffer();
		curLA.setValueBuffer("idalbaran", idAlbaran);
    curLA.setValueBuffer("referencia", referencia);
    curLA.setValueBuffer("descripcion", c.valueBuffer("descripcion"));
    curLA.setValueBuffer("pvpunitario", c.valueBuffer("pvpunitario"));
    curLA.setValueBuffer("codimpuesto", c.valueBuffer("codimpuesto"));
    curLA.setValueBuffer("idlineapedido", c.valueBuffer("idlinea"));
		curLA.setValueBuffer("idpedido", c.valueBuffer("idpedido"));
    curLA.setValueBuffer("iva", c.valueBuffer("iva"));
    curLA.setValueBuffer("recargo", c.valueBuffer("recargo"));
		curLA.setValueBuffer("cantidad", 0);
		curLA.setValueBuffer("pvpsindto", 0);
		curLA.setValueBuffer("pvptotal", 0);
		if (!curLA.commitBuffer()) {
			return false;
		}
		idLA = curLA.valueBuffer("idlinea");
		curLA.select("idlinea = " + idLA);
		if (!curLA.first()) {
debug("!curLA.first()");
			return false;
		}
	}
	curLA.setModeAccess(curLA.Edit);
	curLA.refreshBuffer();
	idLA = curLA.valueBuffer("idlinea");
	
	/// Creamos los movimientos de stock HECHO y sus lotes
	var curMS = new FLSqlCursor("movistock");
	var codLote;
	var oArticulo = new Object();
	oArticulo.referencia = referencia;
	oArticulo.ubicacion = ubicacion;
	oArticulo.codalmacen = curAlbaran.valueBuffer("codalmacen");
	var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + oArticulo.codalmacen + "'");
	if ( !idStock ) {
		idStock = flfactalma.iface.pub_crearStock( oArticulo.codalmacen, oArticulo );
		if ( !idStock ) {
			return false;
		}
	}
	for (var i = 0; i < nP; i++) {
		var codLote = flfactalma.iface.pub_crearLote(oArticulo, lP);
		if (!codLote) {
debug("!codLote");
			return false;
		}
		curMS.setModeAccess(curMS.Insert);
		curMS.refreshBuffer();
		curMS.setValueBuffer("referencia", referencia);
		curMS.setValueBuffer("estado", "HECHO");
		curMS.setValueBuffer("cantidad", lP);
		curMS.setValueBuffer("fechaprev", curMSPte.valueBuffer("fechaprev"));
		curMS.setValueBuffer("fechareal", curAlbaran.valueBuffer("fecha"));
		curMS.setValueBuffer("horareal", curAlbaran.valueBuffer("hora"));
		curMS.setValueBuffer("idstock", idStock);
		curMS.setValueBuffer("idlineapp", curMSPte.valueBuffer("idlineapp"));
		curMS.setValueBuffer("idlineaap", idLA);
		curMS.setValueBuffer("codpartida", curMSPte.valueBuffer("codpartida"));
		curMS.setValueBuffer("codlote", codLote);
		if (!curMS.commitBuffer()) {
debug("!curMS.commitBuffer");
			return false;
		}
		canPendiente -= lP;
	}
	
	/// Actualizamos el movimiento pendiente
	curMSPte.setValueBuffer("cantidad", canPendiente);
	if (!curMSPte.commitBuffer()) {
debug("!curMSPte.commitBuffer");
		return false;
	}
	
	/// Actualizamos la cantidad de la l�nea de albar�n con los nuevos movimientos
	var canLinea = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "idlineaap = " + idLA);
	curLA.setValueBuffer("cantidad", canLinea);
	curLA.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLA));
	curLA.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLA));
	if (!curLA.commitBuffer()) {
debug("!curLA.commitBuffer()");
		return false;
	}
	
	formRecordalbaranesprov.iface.calcularTotales();
	formRecordalbaranesprov.child("tdbLineasAlbaranesProv").refresh();

//   var curLA = formRecordalbaranesprov.child("tdbLineasAlbaranesProv").cursor();
//   for (var i = 0; i < nP; i++) {
//     curLA.setModeAccess(curLA.Insert);
//     curLA.refreshBuffer();
//     curLA.setValueBuffer("referencia", c.valueBuffer("referencia"));
//     curLA.setValueBuffer("descripcion", c.valueBuffer("descripcion"));
//     curLA.setValueBuffer("pvpunitario", c.valueBuffer("pvpunitario"));
//     curLA.setValueBuffer("cantidad", lP);
//     curLA.setValueBuffer("codimpuesto", c.valueBuffer("codimpuesto"));
//     curLA.setValueBuffer("iva", c.valueBuffer("iva"));
//     curLA.setValueBuffer("recargo", c.valueBuffer("recargo"));
//     curLA.setValueBuffer("idlineapedido", c.valueBuffer("idlinea"));
//     curLA.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLA));
//     curLA.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLA));
//     if (!curLA.commitBuffer()) {
//       return false;
//     }
//   }

debug("ok");
  return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
