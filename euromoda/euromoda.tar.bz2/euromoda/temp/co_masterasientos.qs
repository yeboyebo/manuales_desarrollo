
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends renAsientos {
	function euromoda( context ) { renAsientos ( context ); }
	function tbnRecalculaSaldo_clicked() {
		return this.ctx.euromoda_tbnRecalculaSaldo_clicked();
	}
	function renumerarAsientos() {
		return this.ctx.euromoda_renumerarAsientos();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_tbnRecalculaSaldo_clicked()
{
	return true; /// Esperar a Fede
	
	var _i = this.iface;
	_i.__tbnRecalculaSaldo_clicked();
	
	var cursor = this.cursor();
	var codEjercicio = cursor.valueBuffer("codejercicio");
	if (!codEjercicio) {
		return false;
	}
		
	var oDatos = new Object;
	oDatos.fechaDesde = AQUtil.sqlSelect("ejercicios", "fechainicio", "codejercicio = '" + codEjercicio + "'");
	oDatos.numDesde = 0;
	
	var q = new FLSqlQuery();
	q.setSelect("idsubcuenta, codsubcuenta");
	q.setFrom("co_subcuentas");
	q.setWhere("codejercicio = '" + codEjercicio + "'");
	q.setForwardOnly(true);
	if (!q.exec()) {
		return true;
	}
	AQUtil.createProgressDialog(sys.translate("Actualizando saldos..."), q.size());
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(p++);
		AQUtil.setLabelText(sys.translate("Actualizando saldos de subcuenta %1").arg(q.value("codsubcuenta")));
		oDatos.idSubcuenta = q.value("idsubcuenta");
		if (!flcontppal.iface.pub_actualizaSaldoPartidas(false, oDatos)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	MessageBox.information(sys.translate("Saldos actualizados para las partidas del ejercicio %1").arg(codEjercicio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
}

function euromoda_renumerarAsientos()
{
	const _i = this.iface;

	var desEjercicio = AQUtil.sqlSelect("ejercicios", "nombre", "codejercicio = '" + this.iface.ejercicioActual + "'");
	var res = MessageBox.information(sys.translate("Se va a proceder a renumerar todos los asientos del diario correspondientes al ejercicio:\n%1 - %2.\n\n�Desea continuar?").arg(this.iface.ejercicioActual).arg(desEjercicio), MessageBox.No, MessageBox.Yes);

	if (res != MessageBox.Yes)
		return;
	
	var codEjercicio = flfactppal.iface.pub_ejercicioActual();
	var numAsiento = 1;
	var rollback = false;
	var oAsientos = {};
	var numAsientosConcepto = 0;
	
	var curAsientos = new FLSqlCursor("co_asientos");
	curAsientos.setActivatedCommitActions(false);
	curAsientos.select("codejercicio = '" + codEjercicio + "' order by fecha");
	var cursorBloqueado = new FLSqlCursor("co_asientos");

	var i = 0;
	AQUtil.createProgressDialog(sys.translate("Renumerando asientos..."), curAsientos.size());
	AQUtil.setProgress(0);

	var idAsiento;
	
	curAsientos.transaction(false);
		
	while (curAsientos.next()) {
	
		idAsiento = curAsientos.valueBuffer("idasiento");
		
		if (curAsientos.valueBuffer("editable") == true) {
			curAsientos.setModeAccess(curAsientos.Edit);
			curAsientos.refreshBuffer();
			curAsientos.setValueBuffer("numero", numAsiento);
			
			if(!this.iface.masDatosAsiento(curAsientos)) {
				debug("error en el asiento " + idAsiento);
				rollback = true;
				break;
			}
			
			if (!curAsientos.commitBuffer()) {
				debug("error en el asiento " + idAsiento);
				rollback = true;
				break;
			}
			oAsientos[idAsiento] = numAsiento;
			numAsientosConcepto++;
		} else {
			cursorBloqueado.setActivatedCommitActions(false);
			cursorBloqueado.select("idasiento = " + idAsiento);
			cursorBloqueado.first();
			cursorBloqueado.setUnLock("editable", true);

			cursorBloqueado.select("idasiento = " + idAsiento);
			cursorBloqueado.first();
			cursorBloqueado.setModeAccess(curAsientos.Edit);
			cursorBloqueado.refreshBuffer();
			cursorBloqueado.setValueBuffer("numero", numAsiento);
			
			if(!_i.masDatosAsiento(cursorBloqueado)) {
				debug("error en el asiento bloq" + idAsiento);
				rollback = true;
				break;
			}
			
			if (!cursorBloqueado.commitBuffer()) {
				debug("error en el asiento bloq" + idAsiento);
				rollback = true;
				break;
			}

			cursorBloqueado.select("idasiento = " + idAsiento);
			cursorBloqueado.first();
			cursorBloqueado.setUnLock("editable", false);
			
		}

		numAsiento++;
		
		AQUtil.setProgress(i++);
	}
	
	var siguienteAsiento = numAsiento;
	if (!rollback) {
		if (AQUtil.sqlSelect("co_secuencias", "idsecuencia", "codejercicio = '" + this.iface.ejercicioActual + "' AND nombre = 'nasiento' AND valorout IS NOT NULL")) {
			if (!AQUtil.sqlUpdate("co_secuencias", "valorout", siguienteAsiento, "codejercicio = '" + this.iface.ejercicioActual + "' AND nombre = 'nasiento'"))
				rollback = true;
		} else {
			if (!AQUtil.sqlUpdate("co_secuencias", "valor", siguienteAsiento, "codejercicio = '" + this.iface.ejercicioActual + "' AND nombre = 'nasiento'"))
				rollback = true;
		}
	}

	if (rollback)
			curAsientos.rollback();
	else {
		curAsientos.commit();
	}

	AQUtil.destroyProgressDialog();

	_i.tdbRecords.refresh();

	var totalAsientos = AQUtil.sqlSelect("co_asientos", "COUNT(idasiento)", "codejercicio = '" + this.iface.ejercicioActual + "'");
	var ultimoAsiento = AQUtil.sqlSelect("co_asientos", "numero", "codejercicio = '" + this.iface.ejercicioActual + "' ORDER BY numero DESC");
	if (totalAsientos != ultimoAsiento) {
		MessageBox.warning(sys.translate("Ha habido un error en la renumeraci�n:\nEl total de asientos (%1) no coincide con el n�mero del �ltimo asiento (%2).\nVuelva a realizar la renumeraci�n.").arg(totalAsientos).arg(ultimoAsiento), MessageBox.Ok, MessageBox.NoButton);
		return;
	}
	var proxSecuencia;
	if (AQUtil.sqlSelect("co_secuencias", "idsecuencia", "codejercicio = '" + this.iface.ejercicioActual + "' AND nombre = 'nasiento' AND valorout IS NOT NULL")) {
		proxSecuencia = AQUtil.sqlSelect("co_secuencias", "valorout", "codejercicio = '" + this.iface.ejercicioActual + "' AND nombre = 'nasiento'");
	} else {
		proxSecuencia = AQUtil.sqlSelect("co_secuencias", "valor", "codejercicio = '" + this.iface.ejercicioActual + "' AND nombre = 'nasiento'");
	}
	if (proxSecuencia != ++ultimoAsiento) {
		MessageBox.warning(sys.translate("Ha habido un error en la renumeraci�n:\nEl siguiente n�mero de asiento en la secuencia (%1) no coincide con el n�mero del �ltimo asiento m�s uno (%2).\nVuelva a realizar la renumeraci�n.").arg(proxSecuencia).arg(ultimoAsiento), MessageBox.Ok, MessageBox.NoButton);
		return;
	}
	AQUtil.destroyProgressDialog();
	AQUtil.createProgressDialog(sys.translate("Repasando conceptos..."), numAsientosConcepto);
	AQUtil.setProgress(0);
	i = 0;
	/*for(idAsiento in oAsientos){
        debug("idAsiento: " + idAsiento);
		debug("numAsiento = " + oAsientos[idAsiento]);
		var curSaldoPartida = new FLSqlCursor("co_em_saldopartidas");
		curSaldoPartida.select("idpartida1 IN (SELECT idpartida from co_partidas WHERE idasiento = " + idAsiento + ")");
		if(curSaldoPartida.first()){
			debug("asiento: " + idAsiento + " numero: " + oAsientos[idAsiento]);
			curSaldoPartida.setModeAccess(curSaldoPartida.Edit);
			curSaldoPartida.refreshBuffer();

			if(!curSaldoPartida.isNull("idrecibocli")){
				var codigo = AQUtil.sqlSelect("reciboscli", "codigo", "idrecibo = " + curSaldoPartida.valueBuffer("idrecibocli"));
				curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Recibo cliente %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
			}
			else if(!curSaldoPartida.isNull("idreciboprov")){
				var codigo = AQUtil.sqlSelect("recibosprov", "codigo", "idrecibo = " + curSaldoPartida.valueBuffer("idreciboprov"));
				curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Recibo proveedor %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
			}
			else if(!curSaldoPartida.isNull("idanticipocli")){
				var codigo = AQUtil.sqlSelect("anticiposcli", "codigo", "idanticipo = " + curSaldoPartida.valueBuffer("idanticipocli"));
				curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Anticipo cliente %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
			}
			else if(!curSaldoPartida.isNull("idanticipoprov")){
				var codigo = AQUtil.sqlSelect("anticiposprov", "codigo", "idanticipo = " + curSaldoPartida.valueBuffer("idanticipoprov"));
				curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Anticipo proveedor %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
			}
			else if(!curSaldoPartida.isNull("idpartida2")){
				var idAsiento2 = AQUtil.sqlSelect("co_partidas", "idasiento", "idpartida = " + curSaldoPartida.valueBuffer("idpartida2"));
				var qAsiento = new FLSqlQuery;
				qAsiento.setSelect("codejercicio, numero");
				qAsiento.setFrom("co_asientos");
				qAsiento.setWhere("idasiento = " + idAsiento2);
				if (!qAsiento.exec()) {
					return false;
				}
				if (!qAsiento.first()) {
					return false;
				}
				var codEjercicio2 = qAsiento.value("codejercicio");
				var numero2 = qAsiento.value("numero");
				curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Asiento %3/%4").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codEjercicio2).arg(numero2));
			}
			if(!curSaldoPartida.commitBuffer()){
				return false;
			}
		}
		AQUtil.setProgress(i++);
	}*/

    for(idAsiento in oAsientos){
        //debug("idAsiento: " + idAsiento);
        //debug("numAsiento = " + oAsientos[idAsiento]);
        var curSaldoPartida = new FLSqlCursor("co_em_saldopartidas");
        curSaldoPartida.setActivatedCheckIntegrity(false);
        curSaldoPartida.setActivatedCommitActions(false);
        curSaldoPartida.select("idpartida1 IN (SELECT idpartida from co_partidas WHERE idasiento = " + idAsiento + ")");
        while (curSaldoPartida.next()) {

            curSaldoPartida.setModeAccess(curSaldoPartida.Edit);
            curSaldoPartida.refreshBuffer();

            if(!curSaldoPartida.isNull("idrecibocli")){
                var codigo = AQUtil.sqlSelect("reciboscli", "codigo", "idrecibo = " + curSaldoPartida.valueBuffer("idrecibocli"));
                curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Recibo cliente %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
            }
            else if(!curSaldoPartida.isNull("idreciboprov")){
                var codigo = AQUtil.sqlSelect("recibosprov", "codigo", "idrecibo = " + curSaldoPartida.valueBuffer("idreciboprov"));
                curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Recibo proveedor %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
            }
            else if(!curSaldoPartida.isNull("idanticipocli")){
                var codigo = AQUtil.sqlSelect("anticiposcli", "codigo", "idanticipo = " + curSaldoPartida.valueBuffer("idanticipocli"));
                curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Anticipo cliente %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
            }
            else if(!curSaldoPartida.isNull("idanticipoprov")){
                var codigo = AQUtil.sqlSelect("anticiposprov", "codigo", "idanticipo = " + curSaldoPartida.valueBuffer("idanticipoprov"));
                curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Anticipo proveedor %3").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codigo));
            }
            else if(!curSaldoPartida.isNull("idpartida2")){
                var idAsiento2 = AQUtil.sqlSelect("co_partidas", "idasiento", "idpartida = " + curSaldoPartida.valueBuffer("idpartida2"));
                var qAsiento = new FLSqlQuery;
                qAsiento.setSelect("codejercicio, numero");
                qAsiento.setFrom("co_asientos");
                qAsiento.setWhere("idasiento = " + idAsiento2);
                if (!qAsiento.exec()) {
                    return false;
                }
                if (!qAsiento.first()) {
                    return false;
                }
                var codEjercicio2 = qAsiento.value("codejercicio");
                var numero2 = qAsiento.value("numero");

                curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Asiento %3/%4").arg(codEjercicio).arg(oAsientos[idAsiento]).arg(codEjercicio2).arg(numero2));
            }
            if(!curSaldoPartida.commitBuffer()){
                return false;
            }

        }

        
        curSaldoPartida.select("idpartida2 IN (SELECT idpartida from co_partidas WHERE idasiento = " + idAsiento + ")");
        while (curSaldoPartida.next()) {
            curSaldoPartida.setModeAccess(curSaldoPartida.Edit);
            curSaldoPartida.refreshBuffer();

            var idAsiento1 = AQUtil.sqlSelect("co_partidas", "idasiento", "idpartida = " + curSaldoPartida.valueBuffer("idpartida1"));                
                
            var qAsiento = new FLSqlQuery;
            qAsiento.setSelect("codejercicio, numero");
            qAsiento.setFrom("co_asientos");
            qAsiento.setWhere("idasiento = " + idAsiento1);
            if (!qAsiento.exec()) {
                return false;
            }
            if (!qAsiento.first()) {
                return false;
            }
            var codEjercicio1 = qAsiento.value("codejercicio");
            var numero1 = qAsiento.value("numero");          

            curSaldoPartida.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Asiento %3/%4").arg(codEjercicio1).arg(numero1).arg(codEjercicio).arg(oAsientos[idAsiento]));
            
            if(!curSaldoPartida.commitBuffer()){
                return false;
            }
        }
        AQUtil.setProgress(++i);
    }
    AQUtil.destroyProgressDialog();
	MessageBox.information(sys.translate("Renumeraci�n completada correctamente."), MessageBox.Ok, MessageBox.NoButton);
}
//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////