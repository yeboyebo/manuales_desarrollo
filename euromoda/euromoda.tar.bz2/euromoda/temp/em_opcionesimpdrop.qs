/***************************************************************************
                 em_opcionesimpdrop.qs  -  description
                             -------------------
    begin                : mie sep 26 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() {
        return this.ctx.interna_init();
    }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
    function oficial( context ) { interna( context ); }
    function cargarDatos() {
        return this.ctx.oficial_cargarDatos();
    }
    function pushButtonAccept_clicked() {
        return this.ctx.oficial_pushButtonAccept_clicked();
    }
    function comprobacionesFormulario() {
        return this.ctx.oficial_comprobacionesFormulario();
    }
    function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function bChPreCursor(fN, cursor) {
		return this.ctx.oficial_bChPreCursor(fN, cursor);
	}
	function bChCursor(fN, cursor) {
		return this.ctx.oficial_bChCursor(fN, cursor);
	}
	function bChPostCursor(fN, cursor) {
		return this.ctx.oficial_bChPostCursor(fN, cursor);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
    var _i = this.iface;
    var cursor = this.cursor();  
    connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
    disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
    connect(this.child("pushButtonAccept"), "clicked()", this, "iface.pushButtonAccept_clicked");
    if(!cursor.valueBuffer("imprimircant")) {
    	sys.disableObj(this, "fdbCantidad");
    }
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_pushButtonAccept_clicked()
{
    var _i = this.iface;
    if (!_i.comprobacionesFormulario()) {
        return false;
    }
    this.accept();
}

function oficial_comprobacionesFormulario()
{
    var _i = this.iface;
    var cursor = this.cursor();
    var imprimirCant = cursor.valueBuffer("imprimircant");
    var cantidad = cursor.valueBuffer("cantidad");

    if(imprimirCant && (!cantidad || cantidad == 0)) {
    	flfactppal.iface.ponMsgError(sys.translate("Debe informar la cantidad."), "warn", this);
    	return false;
    }   
    return true;
}
function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();

	_i.bChPreCursor(fN, cursor);
	_i.bChCursor(fN, cursor);
	_i.bChPostCursor(fN, cursor);
}

function oficial_bChPreCursor(fN, cursor)
{
}

function oficial_bChCursor(fN, cursor)
{
	var _i = this.iface;

    var impTodos = cursor.valueBuffer("imprimirtodos");
    var impPtes = cursor.valueBuffer("imprimirptes");
    var impCant = cursor.valueBuffer("imprimircant");
    var cantidad = cursor.valueBuffer("cantidad");
    var marcarNoImpreso = cursor.valueBuffer("marcarnoimpreso");

	if (fN == "imprimirtodos" && impTodos) {			
		cursor.setValueBuffer("imprimirptes",false);
		cursor.setValueBuffer("imprimircant",false);
		cursor.setValueBuffer("cantidad","");
		sys.disableObj(this, "fdbCantidad");
		cursor.setValueBuffer("marcarnoimpreso",false);		
	} else if (fN == "imprimirptes" && impPtes) {
		cursor.setValueBuffer("imprimirtodos",false);
		cursor.setValueBuffer("imprimircant",false);
		cursor.setValueBuffer("cantidad","");
		sys.disableObj(this, "fdbCantidad");
		cursor.setValueBuffer("marcarnoimpreso",false);

	} else if (fN == "imprimircant" && impCant) {
		cursor.setValueBuffer("imprimirtodos",false);
		cursor.setValueBuffer("imprimirptes",false);		
		cursor.setValueBuffer("marcarnoimpreso",false);
		sys.enableObj(this, "fdbCantidad");

	} else if (fN == "marcarnoimpreso" && marcarNoImpreso) {
		cursor.setValueBuffer("imprimirtodos",false);
		cursor.setValueBuffer("imprimirptes",false);
		cursor.setValueBuffer("imprimircant",false);
		cursor.setValueBuffer("cantidad","");
		sys.disableObj(this, "fdbCantidad");
	}
}

function oficial_bChPostCursor(fN, cursor)
{

}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
