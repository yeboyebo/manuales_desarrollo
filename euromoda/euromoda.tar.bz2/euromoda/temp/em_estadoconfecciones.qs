/***************************************************************************
                 em_estadoconfecciones.qs  -  description
                             -------------------
    begin                : vie mar 02 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var ultimoColor_;
	var curPedido_;
	function oficial( context ) { interna( context ); } 
	function tbnRefrescar_clicked() {
		return this.ctx.oficial_tbnRefrescar_clicked();
	}
	function dameColorLinea(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, fT, sel);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(this.child("tbnRefrescar"), "clicked()", _i, "tbnRefrescar_clicked");
	
	_i.tbnRefrescar_clicked()
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_tbnRefrescar_clicked()
{
	if (!AQSql.del("em_estadoconfecciones", "")) {
		return false;
	}
	
	var q = new FLSqlQuery;
	q.setSelect("ls.codlote, o.codorden, o.fecha, o.fechaentrega, ls.referencia, a.descripcion, a.codtamanoem, a.codcolorem, ls.canlote, pro.nombre");
	q.setFrom("proveedores pro LEFT OUTER JOIN pr_ordenesproduccion o ON pro.codproveedor = o.codconfeccionista LEFT OUTER JOIN lotesstock ls ON o.codorden = ls.codordenproduccion LEFT OUTER JOIN articulos a ON ls.referencia = a.referencia");
	q.setWhere("o.estado != 'TERMINADA'");
	
	debug(q.sql());
	
	if (!q.exec()) {
		return false;
	}
	AQUtil.createProgressDialog(sys.translate("Cargando estado confecciones..."), q.size());
	var p = 0;
	var cantidad, servida, pendiente, programada, fechaCV, fechaAC, fechaEN;
	var curEC = new FLSqlCursor("em_estadoconfecciones");
	var nombreCliente, codigoPedido, numlineaPedido;

	while (q.next()) {
		AQUtil.setProgress(p++);
		
		nombreCliente = AQUtil.sqlSelect("lotesstock ls LEFT OUTER JOIN movistock ms ON ls.codlote = ms.codlote LEFT OUTER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea LEFT OUTER JOIN pedidoscli p ON lp.idpedido = p.idpedido", "p.nombrecliente", "ls.codlote = '" + q.value("ls.codlote") + "' AND p.nombrecliente <> ''","lotesstock");
		
		codigoPedido = AQUtil.sqlSelect("lotesstock ls LEFT OUTER JOIN movistock ms ON ls.codlote = ms.codlote LEFT OUTER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea LEFT OUTER JOIN pedidoscli p ON lp.idpedido = p.idpedido", "p.codigo", "ls.codlote = '" + q.value("ls.codlote") + "' AND p.nombrecliente <> ''","lotesstock");
		
		numlineaPedido = AQUtil.sqlSelect("lotesstock ls LEFT OUTER JOIN movistock ms ON ls.codlote = ms.codlote LEFT OUTER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea LEFT OUTER JOIN pedidoscli p ON lp.idpedido = p.idpedido", "lp.idlinea", "ls.codlote = '" + q.value("ls.codlote") + "' AND p.nombrecliente <> ''","lotesstock");
		
		servida = AQUtil.sqlSelect("lotesstock ls LEFT OUTER JOIN movistock ms ON ls.codlote = ms.codlote LEFT OUTER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea LEFT OUTER JOIN pedidoscli p ON lp.idpedido = p.idpedido", "lp.totalenalbaran", "ls.codlote = '" + q.value("ls.codlote") + "' AND p.nombrecliente <> ''","lotesstock");
		
		cantidad = q.value("ls.canlote");
		pendiente = cantidad - servida;
		
		fechaCV = AQUtil.sqlSelect("pr_procesos pr INNER JOIN pr_tareas ta ON pr.idproceso = ta.idproceso", "ta.diafin", "pr.tipoobjeto = 'pr_ordenesproduccion' AND pr.idobjeto = '" + q.value("o.codorden") + "' AND ta.idtipotarea = 'CV'","pr_tareas");
		fechaEN = AQUtil.sqlSelect("pr_procesos pr INNER JOIN pr_tareas ta ON pr.idproceso = ta.idproceso", "ta.diafin", "pr.tipoobjeto = 'pr_ordenesproduccion' AND pr.idobjeto = '" + q.value("o.codorden") + "' AND ta.idtipotarea = 'DC'","pr_tareas");
		fechaAC = AQUtil.sqlSelect("pr_procesos pr INNER JOIN pr_tareas ta ON pr.idproceso = ta.idproceso", "ta.diafin", "pr.tipoobjeto = 'pr_ordenesproduccion' AND pr.idobjeto = '" + q.value("o.codorden") + "' AND (ta.idtipotarea = 'J1' OR ta.idtipotarea = 'ACO' OR ta.idtipotarea = 'CH')","pr_tareas");

		curEC.setModeAccess(curEC.Insert);
		curEC.refreshBuffer();
		
		curEC.setValueBuffer("lote", q.value("ls.codlote"));
		curEC.setValueBuffer("orden", q.value("o.codorden"));
		if(codigoPedido){
			curEC.setValueBuffer("numpedido", codigoPedido);
		}
		if(numlineaPedido){
			curEC.setValueBuffer("numlinea", numlineaPedido);
		}
		curEC.setValueBuffer("fechalanzamiento", q.value("o.fecha"));
		curEC.setValueBuffer("fechaservicio", q.value("o.fechaentrega"));
		if(nombreCliente){
			curEC.setValueBuffer("nombrecliente", nombreCliente);
		}
		curEC.setValueBuffer("referencia", q.value("ls.referencia"));
		curEC.setValueBuffer("descripcion", q.value("a.descripcion"));
		curEC.setValueBuffer("codtamanoem", q.value("a.codtamanoem"));
		curEC.setValueBuffer("codcolorem", q.value("a.codcolorem"));
		curEC.setValueBuffer("cantprogramada", cantidad);
		curEC.setValueBuffer("cantpendiente", pendiente);
		curEC.setValueBuffer("fechacortevertical", fechaCV);
		curEC.setValueBuffer("fechaacolchado", fechaAC);
		curEC.setValueBuffer("fechaenvio", fechaEN);
		curEC.setValueBuffer("confeccion", q.value("pro.nombre"));
		
		if (!curEC.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	this.child("tdbEstadoConfecciones").refresh();
	
}

function oficial_dameColorLinea(fN, fV, cursor, fT, sel)
{
	var _i = this.iface;
	
	cursor.refreshBuffer();
	switch(fN) {
		case "lote": {
			if (cursor.valueBuffer("fechaenvio")) {
				_i.ultimoColor_ = "#81F7F3"; ///Azul
			}
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F"; ///Verde
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F"; ///Amarillo
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "orden": {
			if (cursor.valueBuffer("fechaenvio")) {
				_i.ultimoColor_ = "#81F7F3"; ///Azul
			}
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F"; ///Verde
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F"; ///Amarillo
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "numpedido": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "numlinea": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "fechalanzamiento": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "fechaservicio": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "nombrecliente": {
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "referencia": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "descripcion": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "codtamanoem": {
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "codcolorem": {
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "cantprogramada": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "cantpendiente": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "fechacortevertical": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "fechaacolchado": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "fechaenvio": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		case "confeccion": { 
			if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#81F7F3";
			} 
			else if (cursor.valueBuffer("fechaacolchado")) {
				_i.ultimoColor_ = "#81F79F";
			} 
			else if (cursor.valueBuffer("fechacortevertical")) {
				_i.ultimoColor_ = "#FFFF7F";
			} 
			else {
				_i.ultimoColor_ = "";
			}
			break;
		}
		default: {
			return;
		}
	}
	
	if (_i.ultimoColor_ != "") {
		var a:Array = [_i.ultimoColor_, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////