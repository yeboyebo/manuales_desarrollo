
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
  function euromoda(context)
  {
    oficial(context);
  }
  function commonCalculateField(fN, cursor) {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
  var valor;
  switch (fN) {
		case "cancelado": {
      valor = _i.__commonCalculateField(fN, cursor);
      valor = isNaN(valor) ? 0 : valor;
			var partidas = AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idanticipocli = " + cursor.valueBuffer("idanticipo"));
			partidas = isNaN(partidas) ? 0 : partidas;
			partidas = partidas / cursor.valueBuffer("tasaconv");
			valor = parseFloat(valor) + parseFloat(partidas);
			valor = AQUtil.roundFieldValue(valor, "anticiposcli", "cancelado");
      break;
    }
		case "canceladoeuros": {
      valor = _i.__commonCalculateField(fN, cursor);
      valor = isNaN(valor) ? 0 : valor;
			var partidas = AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idanticipocli = " + cursor.valueBuffer("idanticipo"));
			partidas = isNaN(partidas) ? 0 : partidas;
			valor = parseFloat(valor) + parseFloat(partidas);
			valor = AQUtil.roundFieldValue(valor, "anticiposcli", "cancelado");
      break;
    }
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
			break;
		}
  }
  return valor;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
