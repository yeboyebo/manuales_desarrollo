
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
  function euromoda( context ) { oficial ( context ); }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function habilitaComisiones()
  {
    return this.ctx.euromoda_habilitaComisiones();
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();

    _i.habilitaComisiones();
}

function euromoda_habilitaComisiones()
{
  var cursor = this.cursor();
  this.child("fdbPorComision").setDisabled(!cursor.valueBuffer("comisionfija"));
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) { 
  case "comisionfija": {
      _i.habilitaComisiones();
      if (!cursor.valueBuffer("comisionfija")) {
        sys.setObjText(this, "fdbPorComision", "");
      }
      break;
    }
  default: {
      _i.__bufferChanged(fN);
    }
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
