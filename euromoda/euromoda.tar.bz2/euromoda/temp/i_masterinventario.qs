
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var fechaInforme_;
	var totalesInv_;
	function euromoda( context ) { oficial ( context ); }
	function lanzar() {
		return this.ctx.euromoda_lanzar();
	}
	function obtenerParamInforme() {
		return this.ctx.euromoda_obtenerParamInforme();
	}
	function obtenerOrden(nivel, cursor) {
			return this.ctx.euromoda_obtenerOrden(nivel, cursor);
	}
	function crearObjetoTotalesInv() {
			return this.ctx.euromoda_crearObjetoTotalesInv();
	}
	function iniciaTotalInv(nodo, campo) {
			return this.ctx.euromoda_iniciaTotalInv(nodo, campo);
	}
	function dameTotalInv(nodo, campo) {
			return this.ctx.euromoda_dameTotalInv(nodo, campo);
	}
	function costeArticulo(nodo, campo) {
			return this.ctx.euromoda_costeArticulo(nodo, campo);
	}
	function dameCodColor(nodo, campo) {
		return this.ctx.euromoda_dameCodColor(nodo, campo);
	}
	function dameFechaInforme() {
		return this.ctx.euromoda_dameFechaInforme();
	}
	function formateaFechaInforme() {
		return this.ctx.euromoda_formateaFechaInforme();
	}
	function almacenaFechaInforme() {
		return this.ctx.euromoda_almacenaFechaInforme();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_lanzar()
{
	var _i = this.iface;

	_i.almacenaFechaInforme();
	_i.crearObjetoTotalesInv();

	return _i.__lanzar();
}

function euromoda_obtenerParamInforme()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var seleccion= cursor.valueBuffer("id");
	if (!seleccion) {
		return;
	}
	var tipo = cursor.valueBuffer("emtipo");
	var agrupacion = cursor.valueBuffer("agrupacion");
	var necesidad = cursor.valueBuffer("necesidad");
	var ocultar0 = cursor.valueBuffer("emocultar0");
	var sinstock = cursor.valueBuffer("incluirsinstock");

	var paramInforme = flfactinfo.iface.pub_dameParamInforme();

	switch (tipo) {
		case "Informe necesidades": {
			switch (agrupacion) {
				case "Coleccion/Familia": {
					paramInforme.nombreInforme = "i_em_inventario_nec_cf";
					break;
				}
				case "Familia/Coleccion": {
					paramInforme.nombreInforme = "i_em_inventario_nec_fc";
					break;
				}
				case "Familia/Subfamilia": {
					paramInforme.nombreInforme = "i_em_inventario_nec_fs";
					break;
				}
				default: {
					paramInforme.nombreInforme = "i_em_inventario_nec";
				}
			}
			break;
		}
		case "Inventario valorado": {
			switch (agrupacion) {
				case "Coleccion/Familia": {
					paramInforme.nombreInforme = "i_inventarioval_cf";
					break;
				}
				case "Familia/Coleccion": {
					paramInforme.nombreInforme = "i_inventarioval_fc";
					break;
				}
				case "Familia/Subfamilia": {
					paramInforme.nombreInforme = "i_inventarioval_fs";
					break;
				}
				default: {
					paramInforme.nombreInforme = "i_inventarioval";
				}
			}
			break;
		}
		case "Informe necesidades confecci�n": {
			paramInforme.nombreInforme = "i_em_inventario_nec_con";
			break;
		}
		default: {
			paramInforme = _i.__obtenerParamInforme();
		}
	}


	if (tipo == "Informe necesidades" && necesidad && necesidad != "Todos"){
		paramInforme.whereFijo = paramInforme.whereFijo ? paramInforme.whereFijo : "";
		paramInforme.whereFijo += (paramInforme.whereFijo && paramInforme.whereFijo != "") ? " AND " : "";
		switch (necesidad){
			case "No": {
				paramInforme.whereFijo += ("(stocks.necesidad+stocks.prevision) = 0");
				break;
			}
			default: {
				paramInforme.whereFijo += ("(stocks.necesidad+stocks.prevision) > 0");
				break;
			}
		}
	}
	if (tipo == "Informe necesidades" && ocultar0) {
		paramInforme.whereFijo = paramInforme.whereFijo ? paramInforme.whereFijo : "";
		paramInforme.whereFijo += (paramInforme.whereFijo && paramInforme.whereFijo != "") ? " AND " : "";
		paramInforme.whereFijo += "NOT (stocks.cantidad = 0 AND stocks.disponible = 0 AND stocks.reservada = 0 AND stocks.afaltas = 0 AND stocks.pterecibir = 0 AND stocks.disponiblepterecibir = 0 AND stocks.stockmin = 0 AND stocks.necesidad = 0 AND stocks.prevision = 0)";
	}

	if (!cursor.isNull("emdesdecan") && tipo == "Informe necesidades confecci�n") {
		var desde = cursor.valueBuffer("emdesdecan");
		paramInforme.whereFijo = paramInforme.whereFijo ? paramInforme.whereFijo : "";
		paramInforme.whereFijo += (paramInforme.whereFijo && paramInforme.whereFijo != "") ? " AND " : "";
		paramInforme.whereFijo += ("(stocks.cantidad - (stocks.reservada + stocks.reservadapterecibir + stocks.afaltas)) >= " + desde);
	}
	if (!cursor.isNull("emhastacan") && tipo == "Informe necesidades confecci�n") {
		var hasta = cursor.valueBuffer("emhastacan");
		paramInforme.whereFijo = paramInforme.whereFijo ? paramInforme.whereFijo : "";
		paramInforme.whereFijo += (paramInforme.whereFijo && paramInforme.whereFijo != "") ? " AND " : "";
		paramInforme.whereFijo += ("(stocks.cantidad - (stocks.reservada + stocks.reservadapterecibir + stocks.afaltas)) <= " + hasta);
	}

	var filtroEM = formem_filtrosarticulos.iface.pub_construirFiltro(cursor);
	if (filtroEM && filtroEM != "") {
		paramInforme.whereFijo = paramInforme.whereFijo ? paramInforme.whereFijo : "";
		paramInforme.whereFijo += (paramInforme.whereFijo && paramInforme.whereFijo != "") ? " AND " : "";
		paramInforme.whereFijo += filtroEM; ///("stocks.referencia IN (SELECT referencia FROM articulos WHERE " + filtroEM + ")");
	}

	if (tipo == "Inventario" || tipo== "Inventario valorado"){
		if (!sinstock) {
			paramInforme.whereFijo += " AND stocks.cantidad > 0";
		}
	}

	paramInforme.orderBy = "";

	if (paramInforme.nombreInforme == "i_em_inventario_nec_cf" || paramInforme.nombreInforme == "i_inventarioval_cf") {
		paramInforme.orderBy = "almacenes.codalmacen, articulos.codcoleccionem, articulos.codfamilia, articulos.referencia";
	}
	if (paramInforme.nombreInforme == "i_em_inventario_nec_fc" || paramInforme.nombreInforme == "i_inventarioval_fc") {
		paramInforme.orderBy = "almacenes.codalmacen, articulos.codfamilia, articulos.codcoleccionem, articulos.referencia";
	}
	if (paramInforme.nombreInforme == "i_em_inventario_nec_fs" || paramInforme.nombreInforme == "i_inventarioval_fs") {
		paramInforme.orderBy = "almacenes.codalmacen, articulos.codfamilia, articulos.codsubfamilia, articulos.referencia";
	}

	var o= "";
	for (var i = 1; i < 5; i++) {
		o = this.iface.obtenerOrden(i, cursor);
		if (o) {
			if (paramInforme.orderBy == "") {
				paramInforme.orderBy = o;
			} else {
				paramInforme.orderBy += ", " + o;
			}
		}
	}
	return paramInforme;
}

function euromoda_crearObjetoTotalesInv()
{
	var _i = this.iface;
	_i.totalesInv_ = [];
	_i.totalesInv_[0] = 0;
	_i.totalesInv_[1] = 0;
	_i.totalesInv_[2] = 0;
	_i.totalesInv_[3] = 0;
}

function euromoda_iniciaTotalInv(nodo, campo)
{
	var _i = this.iface;
	var nivel = parseInt(nodo.attributeValue("level"));
	_i.totalesInv_[nivel+1] = 0;
	debug("euromoda_iniciaTotalInv ////////////////////////////////////////// " + nivel);
	return nodo.attributeValue(campo);
}

function euromoda_dameTotalInv(nodo, campo)
{
	var _i = this.iface;
	var nivel = campo; //nodo.attributeValue("level");
	debug("dameTotalInv ////////////////////////////////////////// " + nivel + " = " + _i.totalesInv_[nivel]);
	return _i.totalesInv_[nivel];
}

function euromoda_costeArticulo(nodo, campo)
{
	var _i = this.iface;
	var valor;
	debug(valor);
	valor = parseFloat(_i.__costeArticulo(nodo, campo));
	debug(valor);
	if (campo == "total"){
		valor = isNaN(valor) ? 0 : valor;
		var nivel = nodo.attributeValue("level");
		for (n = 0; n <= nivel; n++) {
			_i.totalesInv_[n] += valor;
		}
	}
	debug(valor);
	return valor;
}

function euromoda_obtenerOrden(nivel, cursor)
{
	var _i = this.iface;
	if (nivel < 2) {
		return  _i.__obtenerOrden(nivel, cursor);
	}
	var ret = "";

	var orden = cursor.valueBuffer("orden" + nivel.toString());
	switch(nivel) {
		case 2:
		case 3:
		case 4: {
			switch(orden) {
				case "Referencia": {
					ret += "stocks.referencia";
					break;
				}
				case "Descripci�n": {
					ret += "articulos.descripcion";
					break;
				}
				case "Colecci�n": {
					ret += "articulos.codcoleccionem";
					break;
				}
				case "Tama�o": {
					ret += "articulos.codtamanoem";
					break;
				}
				case "Subfamilia": {
					ret += "articulos.codsubfamilia";
					break;
				}
			}
			break;
		}
	}

	if (ret != "") {
		var tipoOrden= cursor.valueBuffer("tipoorden" + nivel.toString());
		switch(tipoOrden) {
			case "Descendente": {
				ret += " DESC";
				break;
			}
		}
	}
	return ret;
}

function euromoda_dameCodColor(nodo, campo)
{
	var _i = this.iface;

	var colorem = nodo.attributeValue(campo);
	var colorgit = nodo.attributeValue("em_colores.codigogit");

	var color = colorgit != "" ? (colorgit + " " + colorem) : colorem;

	return color;
}

function euromoda_almacenaFechaInforme()
{
	var _i = this.iface;

	_i.fechaInforme_ = new Date();
	_i.formateaFechaInforme();
	var fecha = _i.dameFechaInforme();

	return fecha;
}

function euromoda_dameFechaInforme()
{
	var _i = this.iface;

	return _i.fechaInforme_;
}

function euromoda_formateaFechaInforme()
{
	var _i = this.iface;

	var fecha = _i.fechaInforme_;

	var anio = fecha.getYear();
	var mes = fecha.getMonth();
	var dia = fecha.getDate();
	var hora = fecha.getHours();
	var minuto = fecha.getMinutes();

	var arrayMeses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

	if (hora < 10) {
		hora = "0" + hora;
	}

	if (minuto < 10) {
		minuto = "0" + minuto;
	}

	_i.fechaInforme_ = dia + " de " + arrayMeses[mes-1] + " de " + anio + " - " + hora + ":" + minuto;
	debug("fecha formateada -> "+_i.fechaInforme_);
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
