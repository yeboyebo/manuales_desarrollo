
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {	
	function euromoda( context ) { 
		oficial ( context ); 
	}
	function aceptar() {
		return this.ctx.euromoda_aceptar();
	}
	
}	
//// EUROMODA /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_aceptar()
{
	var _i = this.iface;
	if(_i.aDatosFR.tabla != "lineasalbaranescli") {
		_i.__aceptar();
	}
	
	var tblLineas = this.child("tblLineas");
	var tF = tblLineas.numRows();
	
	var aValores = [];
	var i = 0;
	for (var f = 0; f < tF; f++) {
		if (tblLineas.text(f, _i.colSel) != "X") {
			continue;
		}
		aValores[i] = new Object;
		aValores[i]["idlinea"] = tblLineas.text(f, _i.colLin);
		aValores[i]["cantidad"] = tblLineas.text(f, _i.colRec) * (_i.aDatosFR.signo == "+" ? 1 : -1);
		i++;
	}

	flfacturac.iface.pub_ponSeleccionLineas(aValores);
	formRecordalbaranescli.iface.pub_ponSeleccionValores(aValores);	
	this.accept();
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
