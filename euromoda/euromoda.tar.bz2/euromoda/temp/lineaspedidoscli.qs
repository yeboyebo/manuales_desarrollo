
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod
{
  var aStock, hayRef_;
  var longSubcuenta, bloqueoSubcuenta, ejercicioActual, posActualPuntoSubcuenta;
  var curReserva_, refReserva_;
  var curMS_;
  var tblMMAT_;
  var pestanaActiva_;
  function euromoda(context)
  {
    prod(context);
  }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function cargaDatosStock(cursor)
  {
    return this.ctx.euromoda_cargaDatosStock(cursor);
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function calculateField(fN)
  {
    return this.ctx.euromoda_calculateField(fN);
  }
  function validarProduccion()
  {
    return this.ctx.euromoda_validarProduccion();
  }
  function afterCommitTransaction()
  {
    return this.ctx.euromoda_afterCommitTransaction();
  }
  function commonBufferChanged(fN, miForm)
  {
    return this.ctx.euromoda_commonBufferChanged(fN, miForm);
  }
  function commonCalculateField(fN, cursor)
  {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function dameSubcuentaProducto(cursor)
  {
    return this.ctx.euromoda_dameSubcuentaProducto(cursor);
  }
  function habilitaTipoConcepto(miForm)
  {
    return this.ctx.euromoda_habilitaTipoConcepto(miForm);
  }
  function tbnReservas_clicked()
  {
    return this.ctx.euromoda_tbnReservas_clicked();
  }
  function filtraMSMaterial()
  {
    return this.ctx.euromoda_filtraMSMaterial();
  }
  function modoTexto()
  {
    return this.ctx.euromoda_modoTexto();
  }
  function pbnInsertarPlantillaTexto_clicked()
  {
    return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
  }
  function datosTablaPadre(cursor)
  {
    return this.ctx.euromoda_datosTablaPadre(cursor);
  }
  function pbnStock_clicked()
  {
    return this.ctx.euromoda_pbnStock_clicked();
  }
  function validateForm()
  {
    return this.ctx.euromoda_validateForm();
  }
  function ordenTabulacion()
  {
    return this.ctx.euromoda_ordenTabulacion();
  }
  function controlArticuloProd()
  {
    return this.ctx.euromoda_controlArticuloProd();
  }
  function validaDescatalogado()
  {
    return this.ctx.euromoda_validaDescatalogado();
  }
  function validaRepetidos()
  {
    return this.ctx.euromoda_validaRepetidos();
  }
  function dameFiltroReferencia()
  {
    return this.ctx.euromoda_dameFiltroReferencia();
  }
  	function ledEmArticulo_returnPressed() {
    return this.ctx.euromoda_ledEmArticulo_returnPressed();
  }
	function estableceRefArticulo(ref, miForm) {
    return this.ctx.euromoda_estableceRefArticulo(ref, miForm);
  }
  function precioArticulosCli(codCliente,referencia,fecha) {
  	return this.ctx.euromoda_precioArticulosCli(codCliente,referencia,fecha);
  }
  function commonLedEmArticulo_returnPressed(miForm) {
    return this.ctx.euromoda_commonLedEmArticulo_returnPressed(miForm);
  }
  
  function tdbMoviStockMat_recordChoosed() {
		return this.ctx.euromoda_tdbMoviStockMat_recordChoosed();
	}
	function iniciaTablas() {
		return this.ctx.euromoda_iniciaTablas();
	}
	function tbwLinea_currentChanged(tN) {
		return this.ctx.euromoda_tbwLinea_currentChanged(tN);
	}
	function  tblMovistockMat_clicked(f, c) {
		return this.ctx.euromoda_tblMovistockMat_clicked(f, c);
	}
	function formReady() {
		return this.ctx.euromoda_formReady();
	}    
	function damePrecioArticulo(referencia, codCliente, fecha) {
    return this.ctx.euromoda_damePrecioArticulo(referencia, codCliente, fecha);
  }
	function damePorComision(oDatosComision) {
		return this.ctx.euromoda_damePorComision(oDatosComision);
	}
	function aceptarFormulario() {
  		return this.ctx.euromoda_aceptarFormulario();
  	}
  	function aceptaContinuaFormulario() {
  		return this.ctx.euromoda_aceptaContinuaFormulario();
  	}
  	function habilitarBotonesAceptar() {
  		return this.ctx.euromoda_habilitarBotonesAceptar();
  	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx
{
  function pubEuromoda(context)
  {
    ifaceCtx(context);
  }
  function pub_habilitaTipoConcepto(miForm)
  {
    return this.habilitaTipoConcepto(miForm);
  }
  function pub_dameSubcuentaProducto(cursor)
  {
    return this.dameSubcuentaProducto(cursor);
  }
  function pub_cargaDatosStock(cursor)
  {
    return this.cargaDatosStock(cursor);
  }
  function pub_commonLedEmArticulo_returnPressed(miForm)
  {
    return this.commonLedEmArticulo_returnPressed(miForm)
  }
  function pub_damePrecioArticulo(referencia, codCliente, fecha)
  {
    return this.damePrecioArticulo(referencia, codCliente, fecha);
  }
  function pub_damePorComision(oDatosComision)
  {
    return this.damePorComision(oDatosComision);
  }  
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_validarProduccion()
{
  return true;
}

function euromoda_afterCommitTransaction()
{
  //debug("AFTER guarda");
  //formRecordpedidoscli.iface.guardaPedido();
}

function euromoda_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
  _i.__init();
	var codCliente;
	var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(cursor);
	if (!datosTP) {
		codCliente = false;
	} else {
		codCliente = datosTP["codcliente"];
	}
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",codCliente);
	
  if (cursor.modeAccess() == cursor.Insert) {
		var forzarAfaltas = false;
		var modoFabricacion = "";
		var curRel = cursor.cursorRelation();
		if(curRel) {
			forzarAfaltas = curRel.valueBuffer("forzarafaltas")
			modoFabricacion = curRel.valueBuffer("em_modofabricacion");
			
		} else {
			var idPedido = cursor.valueBuffer("idpedido");
			if(idPedido) {
				forzarAfaltas = AQUtil.sqlSelect("pedidoscli", "forzarafaltas", "idpedido = " + idPedido);
				modoFabricacion = AQUtil.sqlSelect("pedidoscli", "em_modofabricacion", "idpedido = " + idPedido);
				
			}
		}
		cursor.setValueBuffer("forzarafaltas", forzarAfaltas);
		switch(modoFabricacion) {
			case "Forzar a faltas": {
				cursor.setValueBuffer("forzarafaltas", true);
				break;
			}
			case "Agotar disponible de existencias (resto a faltas)": {
				cursor.setValueBuffer("agotarexistencias" , true);
				break
			}
			default: {
				break;
			}
		}
	}

  connect(this.child("pbnStock"), "clicked()", _i, "pbnStock_clicked");
  connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");
  connect(this.child("tbnReservas"), "clicked()", _i, "tbnReservas_clicked");
  connect(this.child("ledEmArticulo"), "returnPressed()", _i, "ledEmArticulo_returnPressed");
  connect(this.child("tbwLinea"), "currentChanged(QString)", _i, "tbwLinea_currentChanged");
  connect(this.child("tblMovistockMat"), "doubleClicked(int, int)", _i, "tblMovistockMat_clicked");

  switch (cursor.modeAccess()) {
    case cursor.Edit: {
      _i.cargaDatosStock(cursor);
      sys.setObjText(this, "lblDisponible", _i.calculateField("lblDisponible"));
      sys.setObjText(this, "pbnStock", _i.calculateField("pbnStock"));
      //this.child("pbnStock").text = _i.calculateField("pbnStock");
      this.child("lblDisponible").paletteForegroundColor = new QColor(_i.calculateField("colordisponible"));
      sys.disableObj(this, "fdbTipoConcepto");
      sys.disableObj(this, "fdbRefCliente");
			this.child("fdbCantidad").setDisabled(false);
      break;
    }
  }

  _i.habilitaTipoConcepto(this);
  _i.modoTexto();

  if (sys.isLoadedModule("flcontppal")) {
    _i.ejercicioActual = flfactppal.iface.pub_ejercicioActual();
    _i.longSubcuenta = AQUtil.sqlSelect("ejercicios", "longsubcuenta", "codejercicio = '" + _i.ejercicioActual + "'");
    _i.bloqueoSubcuenta = false;
    _i.posActualPuntoSubcuenta = -1;
    this.child("fdbIdSubcuenta").setFilter("codejercicio = '" + _i.ejercicioActual + "'");
  }
  try {
    AQS.setTabOrder(this.child("fdbReferencia").obj(), this.child("fdbCantidad").obj());
    AQS.setTabOrder(this.child("fdbCantidad").obj(), this.child("fdbPvpUnitario").obj());
  } catch (e) {}

  this.child("tbnGuardar").close();
	this.child("fdbDescripcion").setAutoCompletionMode(AQS.AlwaysAuto);

  _i.curReserva_ = new FLSqlCursor("stocks");
  _i.curReserva_.setAction("em_reservasstock");
  _i.ordenTabulacion()
  //_i.filtraMSMaterial();
  if (_i.pestanaActiva_ == "materiales") {
	  _i.iniciaTablas();
	}

  	switch (cursor.modeAccess()) {
	case cursor.Insert: {
			this.child("ledEmArticulo").setFocus();
			break;
		}
  }
  
  //connect(this.child("tdbMoviStockMat").cursor(), "recordChoosed()", _i, "tdbMoviStockMat_recordChoosed");

	//Desconectamos el boton aceptar
	if(this.child("pushButtonAccept")){
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	  	connect(this.child("pushButtonAccept"), "clicked()", _i, "aceptarFormulario");
	}

	if(this.child("pushButtonAcceptContinue")){
  		disconnect(this.child("pushButtonAcceptContinue"), "clicked()", this.obj(), "acceptContinue()");
  		connect(this.child("pushButtonAcceptContinue"), "clicked()", _i, "aceptaContinuaFormulario");

  		_i.habilitarBotonesAceptar();
  	}

}

function euromoda_filtraMSMaterial()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtro;
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			filtro = "1 = 2";
			break;
		}
		default: {
			filtro = "idmovproducto IN (SELECT idmovimiento from movistock WHERE idlineapc = " + cursor.valueBuffer("idlinea") + ")";
		}
	}
	return filtro;
	//this.child("tdbMoviStockMat").cursor().setMainFilter(filtro);
}



function euromoda_tbnReservas_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var codAlmacen = cursor.cursorRelation().valueBuffer("codalmacen");
  _i.refReserva_ = cursor.valueBuffer("referencia");

  _i.curReserva_.select("referencia = '" + _i.refReserva_ + "' AND codalmacen = '" + codAlmacen + "'")
  if (!_i.curReserva_.first()) {
    MessageBox.warning(sys.translate("No hay un registro de stock para la referencia y almac�n indicados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return;
  }
  disconnect(_i.curReserva_, "bufferCommited()", this.child("tdbMoviStock"), "refresh()");
  connect(_i.curReserva_, "bufferCommited()", this.child("tdbMoviStock"), "refresh()");
  _i.curReserva_.editRecord();
  return;
}

function euromoda_cargaDatosStock(cursor)
{
  //debug("euromoda_cargaDatosStock");
  var _i = this.iface;
  _i.aStock = new Object();
  _i.aStock.disponible = undefined;
  _i.aStock.disponibleRx = undefined; /// Disponible de lo ya programado
  _i.aStock.disReservar = undefined; /// Disponible m�nimo de los componentes con Reservar = true
  _i.aStock.descatalogado = undefined;
	_i.aStock.aLiquidar = undefined;
	_i.aStock.noStock = true;

  var referencia = cursor.valueBuffer("referencia");
  if (!referencia) {
    return true;
  }
  _i.aStock.noStock = AQUtil.sqlSelect("articulos","nostock","referencia = '" + referencia + "'");
  var curPedido = cursor.cursorRelation();
  if (!curPedido) { /// Aprobaci�n de presupuesto
    curPedido = new FLSqlCursor("pedidoscli");
    curPedido.select("idpedido = " + cursor.valueBuffer("idpedido"));
    if (!curPedido.first()) {
      return false;
    }
    curPedido.setModeAccess(curPedido.Browse);
    curPedido.refreshBuffer();
  }
  var codAlmacen = curPedido.valueBuffer("codalmacen");
	var dis, disRx, descatalogado, aLiquidar; 
	var aDis = flfactppal.iface.pub_ejecutarQry("articulos a INNER JOIN stocks s ON a.referencia = s.referencia", "a.descatalogado,a.fechaliq,s.disponible,s.disponiblepterecibir", "a.referencia = '" + referencia + "' AND s.codalmacen = '" + codAlmacen + "'", "articulos");
	if (aDis.result == 1) {
		dis = aDis["s.disponible"];
		disRx = aDis["s.disponiblepterecibir"];
		descatalogado = aDis["a.descatalogado"];
		aLiquidar = aDis["a.fechaliq"] ? true : false;
	} else {
		dis = 0;
		disRx = 0;
		descatalogado = false;
		aLiquidar = false;
	}
//   var dis = AQUtil.sqlSelect("stocks", "disponible", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
//   var disRx = AQUtil.sqlSelect("stocks", "disponiblepterecibir", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
  dis = dis ? dis : 0;
  disRx = disRx ? disRx : 0;
  var qComp = new FLSqlQuery;
  qComp.setTablesList("articuloscomp,stocks");
  qComp.setSelect("ac.refcomponente, ac.cantidad, ac.factor, s.disponible");
  qComp.setFrom("articuloscomp ac LEFT OUTER JOIN stocks s ON (ac.refcomponente = s.referencia AND s.codalmacen = '" + codAlmacen + "')");
  qComp.setWhere("ac.refcompuesto = '" + referencia + "' AND ac.reservar");
  qComp.setForwardOnly(true);
  if (!qComp.exec()) {
    return false;
  }
  var min = Number.MAX_VALUE, c, f, d, canCompuesto;
  while (qComp.next()) {
    c = qComp.value("ac.cantidad");
    c = c ? c : 1;
    f  = qComp.value("ac.factor");
    f  = f ? f : 1;
    d = qComp.value("s.disponible");
    d = d ? d : 0;
    canCompuesto = d / c / f;
    if (canCompuesto < min) {
      min = canCompuesto;
    }
  }
  min = min == Number.MAX_VALUE ? 0 : min;
  min = Math.floor(min);

  _i.aStock.disponible = dis;
 // debug(".aStock.disponible  " + _i.aStock.disponible);
  _i.aStock.disponibleRx = disRx;
  _i.aStock.disReservar = min;
	_i.aStock.descatalogado = descatalogado;
	_i.aStock.aLiquidar = aLiquidar;
  return true;
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
    case "referencia": {
      _i.__bufferChanged(fN);
      _i.cargaDatosStock(cursor);
			sys.setObjText(this, "fdbDiasServicio", _i.calculateField("diasservicio"));
      sys.setObjText(this, "fdbFechaServicio", _i.calculateField("fechaservicio"));
      sys.setObjText(this, "lblDisponible", _i.calculateField("lblDisponible"));
      sys.setObjText(this, "pbnStock", _i.calculateField("pbnStock"));
      this.child("lblDisponible").paletteForegroundColor = new QColor(_i.calculateField("colordisponible"));
      break;
    }
    case "cantidad": {
      _i.__bufferChanged(fN);
			sys.setObjText(this, "fdbDiasServicio", _i.calculateField("diasservicio"));
      sys.setObjText(this, "fdbFechaServicio", _i.calculateField("fechaservicio"));
      sys.setObjText(this, "lblDisponible", _i.calculateField("lblDisponible"));
      this.child("lblDisponible").paletteForegroundColor = new QColor(_i.calculateField("colordisponible"));
      this.child("lblDisponible").show();
      break;
    }
    case "dtopor": {
      _i.__bufferChanged(fN);
      sys.setObjText(this, "fdbPorComision", _i.calculateField("porcomision"));
      break;
    }
    case "tipoconcepto": {
      _i.__bufferChanged(fN);
      _i.modoTexto();
      break;
    }
    default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
    case "lblDisponible": {
      valor = "";
      if (cursor.valueBuffer("tipoconcepto") == "Texto") {
        break;
      }
      if (!_i.aStock || !("disponible" in _i.aStock)) {
        break;
      }
      if (_i.aStock.disponible && _i.aStock.disponible > 0) {
        valor += sys.translate("Disponible Producto %1").arg(_i.aStock.disponible);
      }
      if (_i.aStock.disponibleRx && _i.aStock.disponibleRx > 0) {
        valor += valor == "" ? "" : ". ";
        valor += sys.translate("Programado %1").arg(_i.aStock.disponibleRx);
      }
      if (_i.aStock.disReservar && _i.aStock.disReservar > 0) {
        valor += valor == "" ? "" : ". ";
        valor += sys.translate("Disponible Componentes %1").arg(_i.aStock.disReservar);
      }
      if (valor == "") {
        valor = sys.translate("No disponible");
      }
      if (_i.aStock.descatalogado) {
				valor = "* " + sys.translate("DESCATALOGADO") + " * " + valor;
			}
			if (_i.aStock.aLiquidar) {
				valor = "* " + sys.translate("A LIQUIDAR") + " * " + valor;
			}
      break;
    }
    case "pbnStock": {
      if (cursor.valueBuffer("tipoconcepto") == "Texto") {
        valor = "";
        break;
      }
      if (!_i.aStock || !("disponible" in _i.aStock)) {
        break;
      }
      valor = sys.translate("En stock: %1. Programado: %2. Stock componentes: %2").arg(_i.aStock.disponible).arg(_i.aStock.disponibleRx).arg(_i.aStock.disReservar);
      break;
    }
    case "colordisponible": {
      if (cursor.valueBuffer("tipoconcepto") == "Texto") {
        valor = "";
        break;
      }
      if (!_i.aStock || !("disponible" in _i.aStock)) {
        break;
      }
      var dP = _i.aStock.disponible ? _i.aStock.disponible : 0;
      var dRx = _i.aStock.disponibleRx ? _i.aStock.disponibleRx : 0;
      var dC = _i.aStock.disReservar ? _i.aStock.disReservar : 0;
      var cantidad = cursor.valueBuffer("cantidad");
      valor = flfactppal.iface.pub_dameColor("tinta_verde");
      if (dP < cantidad) {
        var totalDis = parseFloat(dP) + parseFloat(dRx) + parseFloat(dC);
        if (totalDis < cantidad) {
          valor = "red";
        } else {
          valor = "orange";
        }
      }
      break;
    }
    default: {
      valor = _i.__calculateField(fN);
    }
  }
  return valor;
}

function euromoda_commonBufferChanged(fN, miForm)
{
  var _i = this.iface;
  var cursor = miForm.cursor();
  switch (fN) {
    case "refcliente": {
      sys.setObjText(miForm, "fdbReferencia", _i.commonCalculateField("referencia", cursor));
      if (_i.hayRef_) {
        miForm.child("fdbCantidad").setFocus();
      }
      break;
    }
    case "dtopor": {
      _i.__commonBufferChanged(fN, miForm);
      sys.setObjText(miForm, "fdbPorComision", _i.commonCalculateField("porcomision", cursor));
      break;
    }
    case "referencia": {
      miForm.iface.bloqueoSubcuenta = true;
      sys.setObjText(miForm, "fdbCodSubcuenta", _i.commonCalculateField("codsubcuenta", cursor));
      miForm.iface.bloqueoSubcuenta = false;
      sys.setObjText(miForm, "fdbIdSubcuenta", _i.commonCalculateField("idsubcuenta", cursor));
      _i.__commonBufferChanged(fN, miForm);
      sys.setObjText(miForm, "fdbDescripcion", _i.commonCalculateField("desarticulo", cursor));
      sys.setObjText(miForm, "fdbPorComision", _i.commonCalculateField("porcomision", cursor));
      break;
    }
    case "texto": {
      sys.setObjText(miForm, "fdbDescripcion", _i.commonCalculateField("destexto", cursor));
      break;
    }
    case "codamortizacion": {
      sys.setObjText(miForm, "fdbDescripcion", _i.commonCalculateField("desactivo", cursor));
      sys.setObjText(miForm, "fdbCodSubcuenta", _i.commonCalculateField("codsubcuentaaf", cursor));
      break;
    }
    case "codsubcuenta":
      if (!miForm.iface.bloqueoSubcuenta) {
        miForm.iface.bloqueoSubcuenta = true;
        miForm.iface.posActualPuntoSubcuenta = flcontppal.iface.pub_formatearCodSubcta(miForm, "fdbCodSubcuenta", miForm.iface.longSubcuenta, miForm.iface.posActualPuntoSubcuenta);
        sys.setObjText(miForm, "fdbIdSubcuenta", _i.commonCalculateField("idsubcuenta", cursor));
        miForm.iface.bloqueoSubcuenta = false;
      }
      break;
    case "idsubcuenta": {
      sys.setObjText(miForm, "fdbDescripcion", _i.commonCalculateField("dessubcuenta", cursor));
      sys.setObjText(miForm, "fdbCodImpuesto", _i.commonCalculateField("codimpuestosubcuenta", cursor));
      _i.__commonBufferChanged(fN, miForm);
      break;
    }
    case "tipoconcepto": {
      _i.habilitaTipoConcepto(miForm);
      if (cursor.valueBuffer("tipoconcepto") == "Texto") {
        sys.setObjText(miForm, "fdbCodArancelario", "");
      }
      break;
    }
    case "idlineapedidomarco": {
		  break;
    }
		
    default: {
      _i.__commonBufferChanged(fN, miForm);
    }
  }
}

function euromoda_habilitaTipoConcepto(miForm)
{
  var cursor = miForm.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
    case "Producto": {
      miForm.child("fdbCodAmortizacion").close();
      //       miForm.child("fdbCodAmortizacion").setValue("");
      miForm.child("fdbReferencia").obj().show();
      if (miForm.child("fdbRefCliente")) {
        miForm.child("fdbRefCliente").obj().show();
      }
      miForm.child("fdbReferencia").setFocus();
      miForm.child("fdbCodSubcuenta").setDisabled(true);
      break;
    }
    case "Cuenta": {
      miForm.child("fdbCodAmortizacion").close();
      //       miForm.child("fdbCodAmortizacion").setValue("");
      miForm.child("fdbReferencia").close();
      if (miForm.child("fdbRefCliente")) {
        miForm.child("fdbRefCliente").close();
      }
      miForm.child("fdbReferencia").setValue("");
      miForm.child("fdbCodSubcuenta").setFocus();
      miForm.child("fdbCodSubcuenta").setDisabled(false);
      break;
    }
    case "Activo fijo": {
      miForm.child("fdbCodAmortizacion").obj().show();
      miForm.child("fdbCodAmortizacion").setFocus();
      miForm.child("fdbReferencia").close();
      if (miForm.child("fdbRefCliente")) {
        miForm.child("fdbRefCliente").close();
      }
      miForm.child("fdbReferencia").setValue("");
      miForm.child("fdbCodSubcuenta").setDisabled(true);
      break;
    }
  }
}

function euromoda_damePrecioArticulo(referencia, codCliente, fecha)
{
  var _i = this.iface;
  
  var valor;
  valor = AQUtil.sqlSelect("em_preciosclientes", "pvp", "tipoventa = 'Cliente' AND codventas = '" + codCliente + "' AND referencia = '" + referencia + "'");
  if (valor) {
    return valor;
  }

  valor = AQUtil.sqlSelect("clientes c INNER JOIN em_preciosclientes pc ON  (c.codgrupo = pc.codventas AND pc.tipoventa = 'Grupo precio cliente')", "pc.pvp", "c.codcliente = '" + codCliente +  "' AND pc.referencia = '" + referencia + "'", "clientes,em_preciosclientes");
  //debug("select pc.pvp from clientes c INNER JOIN em_preciosclientes pc ON  (c.codgrupo = pc.codventas AND pc.tipoventa = 'Grupo precio cliente') where c.codcliente = '" + codCliente +  "' AND pc.referencia = '" + referencia + "'");
  if (valor) {
    return valor;
  }
  
  valor = _i.precioArticulosCli(codCliente, referencia, fecha);
  if (valor != "no encontrado") {
    return valor;
  }
  valor = AQUtil.sqlSelect("articulos", "pvp", "referencia = '" + referencia + "'");
  return valor;
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "referencia": {
			_i.hayRef_ = false;
			valor = AQUtil.sqlSelect("articulos", "referencia", "aliasart = '" + cursor.valueBuffer("refcliente") + "'");
			if (valor) {
				_i.hayRef_ = true;
			}
			break;
		}
		case "pvpunitario": {
			var datosTP = this.iface.datosTablaPadre(cursor);
			if (!datosTP) {
				return false;
			}
			var codCliente = datosTP["codcliente"];
			var referencia = cursor.valueBuffer("referencia");
			var fecha = datosTP["fecha"];

			valor = _i.damePrecioArticulo(referencia, codCliente, fecha);
			break;
		}
		/*case "porcomision": {
			var referencia = cursor.valueBuffer("referencia");
			var dtoPor = parseFloat(cursor.valueBuffer("dtopor"));
			dtoPor = isNaN(dtoPor) ? 0 : dtoPor;
			valor = 0;
			/// C�lculo de si el art�culo tiene comisi�n o no, y si la tiene cu�l es
			var dCom = flfactppal.iface.pub_ejecutarQry("articulos INNER JOIN em_gamas ON articulos.em_codgama = em_gamas.em_codgama LEFT OUTER JOIN em_comisionesgama ON (em_gamas.em_codgama = em_comisionesgama.em_codgama AND em_comisionesgama.pordescuento <= " + dtoPor + ")", "articulos.em_codgama,em_gamas.sincomision,em_comisionesgama.porcomision", "articulos.referencia = '" + referencia + "' ORDER BY  em_comisionesgama.pordescuento DESC", "articulos");
			var sinComision = false;
			var comision = 0;
			if (dCom.result == 1) {
				var codGama = dCom["articulos.em_codgama"];
				if (codGama && codGama != "")  {
					var sinC = dCom["em_gamas.sincomision"];
					if (sinC) {
						sinComision = sinC;
					} else {
						valor = dCom["em_comisionesgama.porcomision"];
						valor = isNaN(valor) ? 0 : valor;
					}
				} else {
					sinComision = true;
				}
			} else {
				sinComision = true;
			}
			if (sinComision) {
				break;
			}
			/// Si el art�culo tiene comisi�n prevalecen los datos de comisi�n fija de agente y cliente
			var datosTP = _i.datosTablaPadre(cursor);
			if (!datosTP) {
				return false;
			}
			var dAgen = flfactppal.iface.pub_ejecutarQry("agentes", "comisionfija,porcomision", "codagente = '" + datosTP["codagente"] + "'");
			if (dAgen.result == 1) {
				if (dAgen["comisionfija"]) {
					valor = dAgen["porcomision"];
					break;
				}
			}
			var dCli = flfactppal.iface.pub_ejecutarQry("clientes", "comisionfija,porcomision", "codcliente = '" + datosTP["codcliente"] + "'");
			if (dCli.result == 1) {
				if (dCli["comisionfija"]) {
					valor = dCli["porcomision"];
					break;
				}
			}
			break;
		}*/
		case "porcomision": {
			var datosTP = _i.datosTablaPadre(cursor);
			if (!datosTP) {
				return false;
			}
			var oDatosComision = new Object;
			oDatosComision.referencia = cursor.valueBuffer("referencia");
			oDatosComision.dtoPor = parseFloat(cursor.valueBuffer("dtopor"));
			oDatosComision.codAgente = datosTP["codagente"];
			oDatosComision.codCliente = datosTP["codcliente"]
			valor = _i.damePorComision(oDatosComision);
			break;
		}
		case "diasservicio": {
			//debug("\n\n\nDIAS SERVICIO**********************************");
			if (cursor.valueBuffer("tipoconcepto") == "Texto") {
				valor = "";
				break;
			}
			//debug("DIAS SERVICIO 1");
			if (!_i.aStock || !("disponible" in _i.aStock)) {
				break;
			}
			//debug("DIAS SERVICIO 2");
			var dP = _i.aStock.disponible ? _i.aStock.disponible : 0;
			var dRx = _i.aStock.disponibleRx ? _i.aStock.disponibleRx : 0;
			var dC = _i.aStock.disReservar ? _i.aStock.disReservar : 0;
			var totalDis = parseFloat(dP) + parseFloat(dRx) + parseFloat(dC);
			var cantidad = cursor.valueBuffer("cantidad");

			if(_i.aStock.noStock) {
				valor = 0;
			} else if (cantidad <= dP) {
				valor = 0;
			} else if (cantidad < totalDis) {
				valor = 7;
			} else {
				valor = 20;
			}
			//debug("dias: "+valor+"****************************\n\n");
			break;
		}
		case "fechaservicio": {
			if (cursor.valueBuffer("tipoconcepto") == "Texto") {
				valor = "";
				break;
			}
			var diasServicio = cursor.valueBuffer("diasservicio");
			if (isNaN(diasServicio)) {
				valor = "";
				break;
			}
			valor = new Date;
			valor = AQUtil.addDays(valor, diasServicio);
			break;
		}
		case "destexto": {
			valor = "";
			var t = cursor.valueBuffer("texto");
			if (t && t != "") {
				var posRC = t.find("\n");
				if (posRC >= 0) {
					valor = t.left(posRC) + "...";
				} else {
					valor = t;
				}
			}
			break;
		}
		case "desactivo": {
			valor = AQUtil.sqlSelect("co_amortizaciones", "elemento", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
			break;
		}
		case "desarticulo": {
			valor = AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + cursor.valueBuffer("referencia") + "'");
			//       valor = AQUtil.sqlSelect("articulos", "descripcion || (CASE WHEN codtamanoem IS NULL THEN '' ELSE (' ' || codtamanoem) END) || (CASE WHEN codcolorem IS NULL THEN '' ELSE (' ' || codcolorem) END)", "referencia = '" + cursor.valueBuffer("referencia") + "'");
			break;
		}
		case "dessubcuenta": {
			valor = AQUtil.sqlSelect("co_subcuentas", "descripcion", "idsubcuenta = '" + cursor.valueBuffer("idsubcuenta") + "'");
			break;
		}
		case "codsubcuenta": {
			valor = _i.dameSubcuentaProducto(cursor);
			break;
		}
		case "codsubcuentaaf": {
			var codAF = cursor.valueBuffer("codamortizacion");
			if (!codAF || codAF == "") {
				valor = "";
			} else {
				valor = AQUtil.sqlSelect("co_amortizaciones a INNER JOIN co_gruposcontablesamo g ON a.codgrupocontableamo = g.codgrupo", "g.codsubcuentagan", "a.codamortizacion = '" + codAF + "'", "co_amortizaciones,co_gruposcontablesamo");
			}
			break;
		}
		case "idsubcuenta": {
			var datosTP = this.iface.datosTablaPadre(cursor);
			if (!datosTP) {
				return false;
			}
			var codEjercicio = datosTP.codejercicio;
			var codSubcuenta: String = cursor.valueBuffer("codsubcuenta");
			if (!codSubcuenta || codSubcuenta == "") {
				valor = ""; //pineboo 21-08-2019
				break;
			}
			var idsubcuenta: Number = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
			if (!idsubcuenta)
				valor = "";
			else
				valor = idsubcuenta;
			break;
		}
		case "dtopor": {
			valor = _i.__commonCalculateField(fN, cursor);

			//       var datosTP = _i.datosTablaPadre(cursor);
			//       if (!datosTP) {
			//         return false;
			//       }
			//       valor = AQUtil.sqlSelect("clientes", "pordtoesp", "codcliente = '" + datosTP.codcliente + "'");
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
		case "codimpuestosubcuenta": {
			valor = AQUtil.sqlSelect("co_subcuentas", "codimpuesto", "idsubcuenta = " + cursor.valueBuffer("idsubcuenta"));
			break;
		}
		case "codimpuesto": {
			valor = AQUtil.sqlSelect("articulos", "codimpuesto", "referencia = '" + cursor.valueBuffer("referencia") + "'");
			break;
		}
		case "idlineapedidomarco": {
			valor = undefined;
			break;
		}
		case "codpedidomarco": {
			valor = undefined;
			break;
		}
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function euromoda_dameSubcuentaProducto(cursor)
{
  var valor;
  var tabla = cursor.table();
  var datosTP: Array = this.iface.datosTablaPadre(cursor);
  if (!datosTP) {
    return false;
  }
  var codCliente = datosTP["codcliente"];
  var deAbono = false;
  if (tabla == "lineasfacturascli") {
    var cR = cursor.cursorRelation();
    if (cR) {
      deAbono = cR.valueBuffer("deabono");
    } else {
      deAbono = AQUtil.sqlSelect("facturascli", "deabono", "idfactura = " + cursor.valueBuffer("idfactura"));
    }
  }
  var gCNegocio = AQUtil.sqlSelect("clientes", "codgrupocontableneg", "codcliente = '" + codCliente  + "'");
  var referencia = cursor.valueBuffer("referencia");
  if (!referencia || referencia == "") {
    valor = "";
  } else {
    if (deAbono) {
      valor = AQUtil.sqlSelect("articulos a INNER JOIN gruposcontablesproneg g ON a.codgrupocontablepro = g.codgrupocontablepro", "g.codsubcuentadven", "referencia = '" + referencia + "' AND g.codgrupocontableneg = '" + gCNegocio + "'", "articulos,gruposcontablesproneg");
    } else {
      valor = AQUtil.sqlSelect("articulos a INNER JOIN gruposcontablesproneg g ON a.codgrupocontablepro = g.codgrupocontablepro", "g.codsubcuentaven", "referencia = '" + referencia + "' AND g.codgrupocontableneg = '" + gCNegocio + "'", "articulos,gruposcontablesproneg");
    }
  }
  return valor;
}

function euromoda_modoTexto()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
    case "Texto": {
      this.child("fdbReferencia").setValue("");
      this.child("fdbCantidad").setValue(0);
      this.child("fdbPvpUnitario").setValue(0);
      this.child("fdbCodImpuesto").setValue("");
      this.child("groupBox7").enabled = false;
      this.child("groupBox8").enabled = false;
      this.child("groupBox9").enabled = false;
      this.child("groupBox10").enabled = false;
      this.child("tbwLinea").setTabEnabled("texto", true);
      this.child("tbwLinea").showPage("texto");
      this.child("fdbTexto").setFocus();
      break;
    }
    default: {
      this.child("groupBox7").enabled = true;
      this.child("groupBox8").enabled = true;
      this.child("groupBox9").enabled = true;
      this.child("groupBox10").enabled = true;
      this.child("tbwLinea").showPage("movimientos");
      this.child("tbwLinea").setTabEnabled("texto", false);
      this.child("fdbTexto").setValue("");
      break;
    }
  }
}
function euromoda_pbnInsertarPlantillaTexto_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbTexto").setValue(texto);
}

function euromoda_datosTablaPadre(cursor)
{
  var cx;
  try {
    cx = cursor.connectionName();
  } catch (e) {
    cx = "";
  }
	//debug("cx: "+cx);
  var datos = new Object;
  switch (cursor.table()) {
    case "lineaspresupuestoscli": {
      datos.where = "idpresupuesto = " + cursor.valueBuffer("idpresupuesto");
      datos.tabla = "presupuestoscli";
      break;
    }
    case "lineaspedidoscli": {
      datos.where = "idpedido = " + cursor.valueBuffer("idpedido");
      datos.tabla = "pedidoscli";
      break;
    }
    case "lineasalbaranescli": {
      datos.where = "idalbaran = " + cursor.valueBuffer("idalbaran");
      datos.tabla = "albaranescli";
      break;
    }
    case "lineasfacturascli": {
      datos.where = "idfactura = " + cursor.valueBuffer("idfactura");
      datos.tabla = "facturascli";
      break;
    }
    case "tpv_lineascomanda": {
      datos.where = "idtpv_comanda = " + cursor.valueBuffer("idtpv_comanda");
      datos.tabla = "tpv_comandas";
      break;
    }
  }
  var curRel: FLSqlCursor = cursor.cursorRelation();
  if (curRel && curRel.table() == datos.tabla) {
    switch (cursor.table()) {
      case "tpv_lineascomanda": {
        datos["tasaconv"] = 1;
        datos["codserie"] = false;
        datos["porcomision"] = 0;
        datos["codagente"] = false;
        datos["codejercicio"] = false;
				datos["em_autorizadocostes"] = false;
				datos["pordtoesp"] = 0;				
				datos["recfinanciero"] = 0;		
        break;
      }
      default: {
        datos["tasaconv"] = curRel.valueBuffer("tasaconv");
        datos["codserie"] = curRel.valueBuffer("codserie");
        datos["porcomision"] = curRel.valueBuffer("porcomision");
        datos["codagente"] = curRel.valueBuffer("codagente");
        datos["codejercicio"] = curRel.valueBuffer("codejercicio");
        datos["codgrupoivaneg"] = curRel.valueBuffer("codgrupoivaneg");
				datos["em_autorizadocostes"] = curRel.valueBuffer("em_autorizadocostes");
				datos["pordtoesp"] = curRel.valueBuffer("pordtoesp");
				datos["recfinanciero"] = curRel.valueBuffer("recfinanciero");
      }
    }
    datos["codcliente"] = curRel.valueBuffer("codcliente");
    datos["fecha"] = curRel.valueBuffer("fecha");
  } else {
    var qryDatos = new FLSqlQuery("", cx);
    qryDatos.setTablesList(datos.tabla);
    switch (cursor.table()) {
      case "tpv_lineascomanda": {
        qryDatos.setSelect("codcliente, fecha");
        break;
      }
      default: {
				if(cx == "CX_DA") {
					qryDatos.setSelect("tasaconv, codcliente, fecha, codserie, porcomision, codagente, codejercicio, codgrupoivaneg,pordtoesp, recfinanciero");
				} else {
					qryDatos.setSelect("tasaconv, codcliente, fecha, codserie, porcomision, codagente, codejercicio, codgrupoivaneg, em_autorizadocostes, pordtoesp, recfinanciero");	
				}
				
      }
    }

    qryDatos.setFrom(datos.tabla);
    qryDatos.setWhere(datos.where);
    qryDatos.setForwardOnly(true);
    if (!qryDatos.exec()) {
      return false;
    }
    if (!qryDatos.first()) {
      return false;
    }
    switch (cursor.table()) {
      case "tpv_lineascomanda": {
        datos["tasaconv"] = 1;
        datos["codserie"] = false;
        datos["porcomision"] = 0;
        datos["codagente"] = false;
        datos["codejercicio"] = false;
				datos["em_autorizadocostes"] = false;				
				datos["pordtoesp"] = 0;				
				datos["recfinanciero"] = 0;	
        break;
      }
      default: {
        datos["tasaconv"] = qryDatos.value("tasaconv");
        datos["codserie"] = qryDatos.value("codserie");
        datos["porcomision"] = qryDatos.value("porcomision");
        datos["codagente"] = qryDatos.value("codagente");
        datos["codejercicio"] = qryDatos.value("codejercicio");
        datos["codgrupoivaneg"] = qryDatos.value("codgrupoivaneg");
				if(cx == "CX_DA") {
					datos["em_autorizadocostes"] = false;
				} else {
					datos["em_autorizadocostes"] = qryDatos.value("em_autorizadocostes");				
				}
				datos["pordtoesp"] = qryDatos.value("pordtoesp");
				datos["recfinanciero"] = qryDatos.value("recfinanciero");
      }
    }
    datos["codcliente"] = qryDatos.value("codcliente");
    datos["fecha"] = qryDatos.value("fecha");
  }
  return datos;
}

function euromoda_pbnStock_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var curStock = new FLSqlCursor("stocks");
  curStock.select("referencia = '" + cursor.valueBuffer("referencia") + "' AND codalmacen = '" + cursor.cursorRelation().valueBuffer("codalmacen") + "'");
  if (!curStock.first()) {
    MessageBox.warning(sys.translate("No hay un registro de stock para la referencia y almac�n indicados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  curStock.editRecord();
}

function euromoda_validateForm()
{
  var _i = this.iface;
  var cursor = this.cursor();

	var oParamLin = new Object;
	oParamLin.cursor = cursor;
	oParamLin.ignorarAvisos = false;
	oParamLin.forzarReg = false;
	oParamLin.ignorarCalculoInsert = false; 


  if (!_i.__validateForm()) {
		_i.habilitarBotonesAceptar();
    return false;
  }
  if (!flfacturac.iface.pub_validaIvaLinea(cursor)) {
		_i.habilitarBotonesAceptar();
    return false;
  }
  if (!_i.validaDescatalogado()) {
		_i.habilitarBotonesAceptar();
    return false;
  }
  if (!_i.validaRepetidos()) {
		_i.habilitarBotonesAceptar();
		return false;
	}
	if(!formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin)) {
  		_i.habilitarBotonesAceptar();
    return false;
  }
  return true;
}

function euromoda_validaRepetidos()
{
	var _i = this.iface;
  var cursor = this.cursor();
  var referencia  = cursor.valueBuffer("referencia");
	if (referencia) {
		var numLinea = AQUtil.sqlSelect("lineaspedidoscli", "numlinea", "idpedido = " + cursor.valueBuffer("idpedido") + " AND referencia = '" + referencia + "' AND idlinea <> " + cursor.valueBuffer("idlinea"));
		if (numLinea) {
			var res = MessageBox.warning(sys.translate("Ya existe una l�nea de pedido (n� %1) con esta referencia. �Desea continuar?").arg(numLinea), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
			if (res != MessageBox.Yes) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_validaDescatalogado()
{
	var _i = this.iface;
  var cursor = this.cursor();
  
	if (!_i.aStock) {
		return true;
	}
	if (!_i.aStock.descatalogado && !_i.aStock.aLiquidar) {
		return true;
	}
	var disTotal = (isNaN(_i.aStock.disponibleRx) ? 0 : parseFloat(_i.aStock.disponibleRx)) + (isNaN(_i.aStock.disponible) ? 0 : parseFloat(_i.aStock.disponible));
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			if (cursor.valueBuffer("cantidad") > disTotal) {
				sys.warnMsgBox(sys.translate("El art�culo est� descatalogado o a liquidar y la cantidad es superior a la cantidad disponible en stock"));
				return false;
			}
			break;
		}
		case cursor.Edit: {
			if ((cursor.valueBuffer("cantidad") - cursor.valueBufferCopy("cantidad")) > disTotal) {
				sys.warnMsgBox(sys.translate("El art�culo est� descatalogado o a liquidar y la cantidad es superior a la cantidad disponible en stock"));
				return false;
			}
			break;
		}
	}
	return true;
}

function euromoda_ordenTabulacion()
{
	var controles = ["fdbReferencia", "fdbDescripcion", "fdbCantidad", "fdbPvpUnitario"];
	for (var i = 0; i < controles.length - 1; i++) {
		if (this.child(controles[i]) && this.child(controles[i + 1])) {
			AQS.setTabOrder(this.child(controles[i]).obj(), this.child(controles[i + 1]).obj());
		}
	}
}

function euromoda_controlArticuloProd()
{
	return true;
}

function euromoda_dameFiltroReferencia()
{
	var _i = this.iface;
// 	var f = _i.__dameFiltroReferencia();
	var f = "NOT debaja";
	return f;
}

/*function euromoda_ledEmArticulo_returnPressed()
{
	var _i = this.iface;
	
	var a = this.child("ledEmArticulo").text;
	if (!a || a == "") {
		return;
	}
	if (a.toString().startsWith(".")) {
		var barcode = a.toString().right(a.length - 1);
		if (barcode.length != 6) {
			sys.warnMsgBox(sys.translate("El dato de barcode debe contener 6 caracteres"));
			return;
		}
		var q = new AQSqlQuery;
		q.setSelect("referencia, codbarras, descripcion, codtamanoem, codcolorem");
		q.setFrom("articulos");
		q.setWhere("codbarras LIKE '%" + barcode + "' ORDER BY codbarras");
		if (!q.exec()) {
			return;
		}
		if (q.size() < 1) {
			sys.warnMsgBox(sys.translate("No hay ning�n c�digo de barras que finalice con el valor %1").arg(barcode));
		} else if (q.size() == 1) {
			if (!q.first()) {
				return false;
			}
			_i.estableceRefArticulo(q.value("referencia"));
		} else {
			var aOps = new Array;
			var aRefs = new Array;
			while (q.next()) {
				aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("codbarras")).arg(q.value("referencia")).arg(q.value("descripcion")).arg(q.value("codtamanoem")).arg(q.value("codcolorem")));
				aRefs.push(q.value("referencia"));
			}
			var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
			if (o >= 0) {
				_i.estableceRefArticulo(aRefs[o]);
			}
		}
	} else if (a.toString().startsWith("*")) {
			var referenciaAst;
			var datosTP = this.iface.datosTablaPadre(this.cursor());
		  	if (!datosTP) {
		  		return false;
			}
		 	var codCliente = datosTP["codcliente"];
		  	var referenciaCli = a.toString().right(a.length - 1);
		      
			var q = new AQSqlQuery;
			q.setSelect("art.referencia, art.codbarras, art.descripcion, art.codtamanoem, art.codcolorem");
			q.setFrom("articulos art INNER JOIN em_articuloscli artcli ON art.referencia = artcli.referencia ");
			q.setWhere("artcli.codcliente = '" + codCliente + "' and artcli.referenciacliente = '" + referenciaCli + "'");
			
			if (!q.exec()) {
				return;
			}
			if (q.size() < 1) {
				referenciaAst = "no encontrada";
			} else if (q.size() == 1) {
				if (!q.first()) {
					return false;
				}
				debug("referencia encontrada 1");
				_i.estableceRefArticulo(q.value("art.referencia"));
			} else {
				var aOps = new Array;
				var aRefs = new Array;
				while (q.next()) {
					aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("art.codbarras")).arg(q.value("art.referencia")).arg(q.value("art.descripcion")).arg(q.value("art.codtamanoem")).arg(q.value("art.codcolorem")));
					aRefs.push(q.value("art.referencia"));
				}
				var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
				if (o >= 0) {
					debug("referencia encontrada 1 lista");
					_i.estableceRefArticulo(aRefs[o]);
				}
			}
			if (referenciaAst == "no encontrada") {
				//buscamos por cliente factura
				var codClienteFra = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente='" + codCliente + "'");
				debug("codClienteFra: "+codClienteFra);
				if(codClienteFra && codClienteFra != "") {
					var q = new AQSqlQuery;
					q.setSelect("art.referencia, art.codbarras, art.descripcion, art.codtamanoem, art.codcolorem");
					q.setFrom("articulos art INNER JOIN em_articuloscli artcli ON art.referencia = artcli.referencia ");
					q.setWhere("artcli.codcliente = '" + codClienteFra + "' and artcli.referenciacliente = '" + referenciaCli + "'");
					
					if (!q.exec()) {
						return;
					}
					if (q.size() < 1) {
						referenciaAst = "no encontrada";
					} else if (q.size() == 1) {
						if (!q.first()) {
							return false;
						}
						referenciaAst = "";
						debug("referencia encontrada 2");
						_i.estableceRefArticulo(q.value("art.referencia"));
					} else {
						var aOps = new Array;
						var aRefs = new Array;
						while (q.next()) {
							aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("art.codbarras")).arg(q.value("art.referencia")).arg(q.value("art.descripcion")).arg(q.value("art.codtamanoem")).arg(q.value("art.codcolorem")));
							aRefs.push(q.value("art.referencia"));
						}
						var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
						if (o >= 0) {
							referenciaAst = ""
							debug("referencia encontrada 2 lista");
							_i.estableceRefArticulo(aRefs[o]);
						}
					}			
				}			
			}
			if (referenciaAst == "no encontrada") {			
				//buscamos por version antigua refcliente (campo aliasart de articulos)
				var q = new AQSqlQuery;
				q.setSelect("art.referencia, art.codbarras, art.descripcion, art.codtamanoem, art.codcolorem");
				q.setFrom("articulos art ");
				q.setWhere("art.aliasart = '" + referenciaCli + "'");			
				if (!q.exec()) {
					return;
				}
				if (q.size() < 1) {
					referenciaAst = "no encontrada";
				} else if (q.size() == 1) {
					if (!q.first()) {
						return false;
					}
					referenciaAst = "";
					debug("referencia encontrada 3");
					_i.estableceRefArticulo(q.value("art.referencia"));
				} else {
					var aOps = new Array;
					var aRefs = new Array;
					while (q.next()) {
						aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("art.codbarras")).arg(q.value("art.referencia")).arg(q.value("art.descripcion")).arg(q.value("art.codtamanoem")).arg(q.value("art.codcolorem")));
						aRefs.push(q.value("art.referencia"));
					}
					var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
					if (o >= 0) {
						referenciaAst = ""
						debug("referencia encontrada 3 lista");
						_i.estableceRefArticulo(aRefs[o]);
					}
				}			
			}     
			if (referenciaAst == "no encontrada") {			
				sys.warnMsgBox(sys.translate("No existe la referencia de cliente %1").arg(referenciaCli));
			}	
	} else {
		var ref = AQUtil.sqlSelect("articulos", "referencia", "UPPER(referencia) = '" + a.toString().toUpperCase() + "'");
		if (!ref || ref == "") {
			sys.warnMsgBox(sys.translate("No hay ning�n art�culo con la referencia %1").arg(a));
			return false;
		}
		_i.estableceRefArticulo(ref);
	}
}*/
function euromoda_ledEmArticulo_returnPressed()
{
	var _i = this.iface;
	_i.commonLedEmArticulo_returnPressed(this);
}
function euromoda_estableceRefArticulo(ref,miForm)
{

	sys.setObjText(miForm, "fdbReferencia", ref);
	miForm.child("fdbCantidad").setFocus();
	miForm.child("ledEmArticulo").text = "";
}
function euromoda_precioArticulosCli(codCliente,referencia,fecha)
{
	var valor ="no encontrado";
	var q = new AQSqlQuery;	
	q.setSelect("his.pvpeuromoda");
	q.setFrom("em_articuloscli artcli LEFT OUTER JOIN em_articulosclihis his ON artcli.id=his.idarticuloscli");
	q.setWhere("artcli.codcliente='" + codCliente + "' and artcli.referencia='" + referencia + "' and his.fechavalidez >= '" + fecha + "' order by his.fechavalidez asc limit 1");	
	if (!q.exec()){
		return ;
	}  
	if (q.first())
	{
	     valor = q.value("his.pvpeuromoda");	
	     //debug("Precio articuloscli");
	}	
	if(valor == "no encontrado") {
		var codClienteFra = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente='" + codCliente + "'");
		//debug("codClienteFra: "+codClienteFra);
		if(codClienteFra && codClienteFra != "") {
			var qcf = new AQSqlQuery;	
			qcf.setSelect("his.pvpeuromoda");
			qcf.setFrom("em_articuloscli artcli LEFT OUTER JOIN em_articulosclihis his ON artcli.id=his.idarticuloscli");
			qcf.setWhere("artcli.codcliente='" + codClienteFra + "' and artcli.referencia='" + referencia + "' and his.fechavalidez >= '" + fecha + "' order by his.fechavalidez asc limit 1");	
			if (!qcf.exec()){
				return ;
			}  
			if (qcf.first())
			{
	   		valor = qcf.value("his.pvpeuromoda");	
	   		//debug("Precio articuloscli cliente factura");
			}		
		
		}
		
	}
	return valor;
}
function euromoda_commonLedEmArticulo_returnPressed(miForm)
{
	var _i = this.iface;
	var cursor = miForm.cursor();
	var a = miForm.child("ledEmArticulo").text;
	if (!a || a == "") {
		return;
	}
	if (a.toString().startsWith(".")) {
		var barcode = a.toString().right(a.length - 1);
		if (barcode.length != 6) {
			sys.warnMsgBox(sys.translate("El dato de barcode debe contener 6 caracteres"));
			return;
		}
		var q = new AQSqlQuery;
		q.setSelect("referencia, codbarras, descripcion, codtamanoem, codcolorem");
		q.setFrom("articulos");
		q.setWhere("codbarras LIKE '%" + barcode + "' ORDER BY codbarras");
		if (!q.exec()) {
			return;
		}
		if (q.size() < 1) {
			sys.warnMsgBox(sys.translate("No hay ning�n c�digo de barras que finalice con el valor %1").arg(barcode));
		} else if (q.size() == 1) {
			if (!q.first()) {
				return false;
			}
			_i.estableceRefArticulo(q.value("referencia"),miForm);
		} else {
			var aOps = new Array;
			var aRefs = new Array;
			while (q.next()) {
				aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("codbarras")).arg(q.value("referencia")).arg(q.value("descripcion")).arg(q.value("codtamanoem")).arg(q.value("codcolorem")));
				aRefs.push(q.value("referencia"));
			}
			var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
			if (o >= 0) {
				_i.estableceRefArticulo(aRefs[o],miForm);
			}
		}
	} else if (a.toString().startsWith("*")) {
			var referenciaAst;
			var datosTP = _i.datosTablaPadre(miForm.cursor());
		  	if (!datosTP) {
		  		return false;
			}
		 	var codCliente = datosTP["codcliente"];
		  	var referenciaCli = a.toString().right(a.length - 1);
		      
			var q = new AQSqlQuery;
			q.setSelect("art.referencia, art.codbarras, art.descripcion, art.codtamanoem, art.codcolorem");
			q.setFrom("articulos art INNER JOIN em_articuloscli artcli ON art.referencia = artcli.referencia ");
			q.setWhere("artcli.codcliente = '" + codCliente + "' and artcli.referenciacliente = '" + referenciaCli + "'");
			
			if (!q.exec()) {
				return;
			}
			if (q.size() < 1) {
				referenciaAst = "no encontrada";
			} else if (q.size() == 1) {
				if (!q.first()) {
					return false;
				}
				//debug("referencia encontrada 1");
				_i.estableceRefArticulo(q.value("art.referencia"),miForm);
			} else {
				var aOps = new Array;
				var aRefs = new Array;
				while (q.next()) {
					aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("art.codbarras")).arg(q.value("art.referencia")).arg(q.value("art.descripcion")).arg(q.value("art.codtamanoem")).arg(q.value("art.codcolorem")));
					aRefs.push(q.value("art.referencia"));
				}
				var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
				if (o >= 0) {
					//debug("referencia encontrada 1 lista");
					_i.estableceRefArticulo(aRefs[o],miForm);
				}
			}
			if (referenciaAst == "no encontrada") {
				//buscamos por cliente factura
				var codClienteFra = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente='" + codCliente + "'");
				//debug("codClienteFra: "+codClienteFra);
				if(codClienteFra && codClienteFra != "") {
					var q = new AQSqlQuery;
					q.setSelect("art.referencia, art.codbarras, art.descripcion, art.codtamanoem, art.codcolorem");
					q.setFrom("articulos art INNER JOIN em_articuloscli artcli ON art.referencia = artcli.referencia ");
					q.setWhere("artcli.codcliente = '" + codClienteFra + "' and artcli.referenciacliente = '" + referenciaCli + "'");
					
					if (!q.exec()) {
						return;
					}
					if (q.size() < 1) {
						referenciaAst = "no encontrada";
					} else if (q.size() == 1) {
						if (!q.first()) {
							return false;
						}
						referenciaAst = "";
						//debug("referencia encontrada 2");
						_i.estableceRefArticulo(q.value("art.referencia"),miForm);
					} else {
						var aOps = new Array;
						var aRefs = new Array;
						while (q.next()) {
							aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("art.codbarras")).arg(q.value("art.referencia")).arg(q.value("art.descripcion")).arg(q.value("art.codtamanoem")).arg(q.value("art.codcolorem")));
							aRefs.push(q.value("art.referencia"));
						}
						var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
						if (o >= 0) {
							referenciaAst = ""
							//debug("referencia encontrada 2 lista");
							_i.estableceRefArticulo(aRefs[o],miForm);
						}
					}			
				}			
			}
			if (referenciaAst == "no encontrada") {			
				//buscamos por version antigua refcliente (campo aliasart de articulos)
				var q = new AQSqlQuery;
				q.setSelect("art.referencia, art.codbarras, art.descripcion, art.codtamanoem, art.codcolorem");
				q.setFrom("articulos art ");
				q.setWhere("art.aliasart = '" + referenciaCli + "'");			
				if (!q.exec()) {
					return;
				}
				if (q.size() < 1) {
					referenciaAst = "no encontrada";
				} else if (q.size() == 1) {
					if (!q.first()) {
						return false;
					}
					referenciaAst = "";
					//debug("referencia encontrada 3");
					_i.estableceRefArticulo(q.value("art.referencia"),miForm);
				} else {
					var aOps = new Array;
					var aRefs = new Array;
					while (q.next()) {
						aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("art.codbarras")).arg(q.value("art.referencia")).arg(q.value("art.descripcion")).arg(q.value("art.codtamanoem")).arg(q.value("art.codcolorem")));
						aRefs.push(q.value("art.referencia"));
					}
					var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
					if (o >= 0) {
						referenciaAst = ""
						//debug("referencia encontrada 3 lista");
						_i.estableceRefArticulo(aRefs[o],miForm);
					}
				}			
			}     
			if (referenciaAst == "no encontrada") {			
				sys.warnMsgBox(sys.translate("No existe la referencia de cliente %1").arg(referenciaCli));
			}	
	} else {
		var ref = AQUtil.sqlSelect("articulos", "referencia", "UPPER(referencia) = '" + a.toString().toUpperCase() + "'");
		if (!ref || ref == "") {
			sys.warnMsgBox(sys.translate("No hay ning�n art�culo con la referencia %1").arg(a));
			return false;
		}
		_i.estableceRefArticulo(ref,miForm);
	}

}
function euromoda_tdbMoviStockMat_recordChoosed()
{
	var _i = this.iface;
	var cursor = this.child("tdbMoviStockMat").cursor();
	
	if (_i.curMS_) {		
		_i.curMS_ = undefined;
	}
	
	_i.curMS_ = new FLSqlCursor("movistock");
	_i.curMS_.setAction("movistock");
	_i.curMS_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
	if (!_i.curMS_.first()) {
		return false;
	}
	_i.curMS_.browseRecord();	
}
function euromoda_iniciaTablas()
{
	var _i = this.iface;	
	var tMmat = this.child("tblMovistockMat");	
	var filtro = _i.filtraMSMaterial();

	_i.tblMMAT_ = flfactppal.iface.pub_dameObjetoTabla(this.child("tblMovistockMat"));
	
	var q = new AQSqlQuery;	
	q.setSelect("movistock.idmovimiento, movistock.referencia, articulos.descripcion, movistock.cantidad, movistock.reservaex, movistock.reservapr, movistock.reservaaf, movistock.concepto, articulos.codsubfamilia, articulos.codtamanoem, articulos.codcolorem, articulos.coddibestamp, articulos.codcoleccionem, stocks.codalmacen, movistock.idmovproducto");
	q.setFrom("movistock LEFT OUTER JOIN articulos ON movistock.referencia = articulos.referencia LEFT OUTER JOIN stocks ON movistock.idstock = stocks.idstock");
	q.setWhere(filtro + " ORDER BY movistock.referencia");	
	
	_i.tblMMAT_.setQuery(q);	
	_i.tblMMAT_.setColumnWidth("movistock.referencia", 70);
	_i.tblMMAT_.setColumnWidth("articulos.descripcion", 400);
	_i.tblMMAT_.setColumnWidth("movistock.reservaex", 100);
	_i.tblMMAT_.setColumnWidth("movistock.reservapr", 100);
	_i.tblMMAT_.setColumnWidth("movistock.concepto", 400);
	_i.tblMMAT_.setColumnWidth("articulos.codsubfamilia", 70);
	_i.tblMMAT_.setColumnWidth("articulos.codtamanoem", 120);
	_i.tblMMAT_.setColumnWidth("articulos.codcolorem", 100);
	_i.tblMMAT_.setColumnWidth("articulos.codcoleccionem", 80);
	_i.tblMMAT_.setColumnWidth("stocks.codalmacen", 80);
	_i.tblMMAT_.refresh();
	
}
function euromoda_tbwLinea_currentChanged(tN)
{
	var _i = this.iface;
	_i.pestanaActiva_ = tN;
	switch (tN) {
	case "materiales": {
			_i.iniciaTablas();
			break;
		}
	}

}
function euromoda_tblMovistockMat_clicked(f, c)
{
  var _i = this.iface;
  //var idMovimiento = _i.tblMMAT_.text(f, c);
  var idMovimiento = _i.tblMMAT_.cellValue(f, "movistock.idmovimiento");
  
  
  var curMS = new FLSqlCursor("movistock");
  curMS.select("idmovimiento = " + idMovimiento);
  if (!curMS.first()) {
    return;
  }
  curMS.browseRecord();
}

function euromoda_formReady()
{
	var _i = this.iface;
	
	_i.__formReady();
	
	/*var cursor = this.cursor();
	if (cursor.modeAccess() == cursor.Insert) {
		var curRel = cursor.cursorRelation();
		cursor.setValueBuffer("forzarafaltas", curRel.valueBuffer("forzarafaltas"));
	}*/
}

function euromoda_damePorComision(oDatosComision)
{
	var _i = this.iface;
	var valor = 0;
	var referencia = oDatosComision.referencia;
	var dtoPor = oDatosComision.dtoPor;
	var codAgente = oDatosComision.codAgente;
	var codCliente = oDatosComision.codCliente;
	dtoPor = isNaN(dtoPor) ? 0 : dtoPor;	
	/// C�lculo de si el art�culo tiene comisi�n o no, y si la tiene cu�l es
	var dCom = flfactppal.iface.pub_ejecutarQry("articulos INNER JOIN em_gamas ON articulos.em_codgama = em_gamas.em_codgama LEFT OUTER JOIN em_comisionesgama ON (em_gamas.em_codgama = em_comisionesgama.em_codgama AND em_comisionesgama.pordescuento <= " + dtoPor + ")", "articulos.em_codgama,em_gamas.sincomision,em_comisionesgama.porcomision", "articulos.referencia = '" + referencia + "' ORDER BY  em_comisionesgama.pordescuento DESC", "articulos");
	var sinComision = false;
	var comision = 0;
	if (dCom.result == 1) {
		var codGama = dCom["articulos.em_codgama"];
		if (codGama && codGama != "")  {
			var sinC = dCom["em_gamas.sincomision"];
			if (sinC) {
				sinComision = sinC;
			} else {
				valor = dCom["em_comisionesgama.porcomision"];
				valor = isNaN(valor) ? 0 : valor;
			}
		} else {
			sinComision = true;
		}
	} else {
		sinComision = true;
	}
	if (sinComision) {
		return valor;
	}
	/// Si el art�culo tiene comisi�n prevalecen los datos de comisi�n fija de agente y cliente
	var dAgen = flfactppal.iface.pub_ejecutarQry("agentes", "comisionfija,porcomision", "codagente = '" + codAgente + "'");
	if (dAgen.result == 1) {
		if (dAgen["comisionfija"]) {
			valor = dAgen["porcomision"];
			return valor;
		}
	}
	var dCli = flfactppal.iface.pub_ejecutarQry("clientes", "comisionfija,porcomision", "codcliente = '" + codCliente + "'");
	if (dCli.result == 1) {
		if (dCli["comisionfija"]) {
			valor = dCli["porcomision"];
			return valor;
		}
	}
	return valor;		
}

function euromoda_aceptarFormulario()
{
	var _i = this.iface;	
	this.child("pushButtonAccept").setDisabled(true);
	this.obj().accept();
}

function euromoda_aceptaContinuaFormulario()
{
	var _i = this.iface;	
	this.child("pushButtonAcceptContinue").setDisabled(true);
	this.obj().acceptContinue();
}

function euromoda_habilitarBotonesAceptar()
{
	this.child("pushButtonAccept").setDisabled(false);
	this.child("pushButtonAcceptContinue").setDisabled(false);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
