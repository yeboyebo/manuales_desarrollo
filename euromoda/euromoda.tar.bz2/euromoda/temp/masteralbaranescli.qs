
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	var curP_, pK_;
	var proforma_;
  function euromoda( context ) { prod ( context ); }
  function datosFactura(curAlbaran, where, datosAgrupacion) {
    return this.ctx.euromoda_datosFactura(curAlbaran, where, datosAgrupacion);
  }
  function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function datosDirFactura(curAlbaran, where, datosAgrupacion) {
    return this.ctx.euromoda_datosDirFactura(curAlbaran, where, datosAgrupacion);
  }
  function totalizaAlbaranDist(curAlbaran)
  {
    return this.ctx.euromoda_totalizaAlbaranDist(curAlbaran);
  }
  function generarFactura(where, curAlbaran, datosAgrupacion)
  {
    return this.ctx.euromoda_generarFactura(where, curAlbaran, datosAgrupacion);
  }
  function controlPedidoYaFacturado(where)
  {
    return this.ctx.euromoda_controlPedidoYaFacturado(where);
  }
  function datosLineaFactura(curLineaAlbaran)
  {
    return this.ctx.euromoda_datosLineaFactura(curLineaAlbaran);
  }
  function totalesFactura():Boolean {
    return this.ctx.euromoda_totalesFactura();
  }
  function imprimeTrans() {
    return this.ctx.euromoda_imprimeTrans();
  }
  function imprimirAlbaranTrans(codigo, idAlbaran) {
  	return this.ctx.euromoda_imprimirAlbaranTrans(codigo, idAlbaran);
  }
  function exportaExcel(consulta) {
    return this.ctx.euromoda_exportaExcel(consulta);
  }
  function exportaExcel_clicked() {
    return this.ctx.euromoda_exportaExcel_clicked();
  }
  function imprimeEtiquetas() {
    return this.ctx.euromoda_imprimeEtiquetas();
  }
  function imprimirEtiquetasAlbaran(idAlbaran) {
  	return this.ctx.euromoda_imprimirEtiquetasAlbaran(idAlbaran);
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function dameParamInformeTrans() {
    return this.ctx.euromoda_dameParamInformeTrans();
  }
  function imprimir(codAlbaran) {
    return this.ctx.euromoda_imprimir(codAlbaran);
  }
  function tbnImprimirMembrete_clicked() {
    return this.ctx.euromoda_tbnImprimirMembrete_clicked();
  }
  function copiaCampoDist(nombreCampo, curA, curB, campoInformado) {
    return this.ctx.euromoda_copiaCampoDist(nombreCampo, curA, curB, campoInformado);
  }
  function dameParamInforme(idAlbaran) {
    return this.ctx.euromoda_dameParamInforme(idAlbaran);
  }
  function dameSelectLineasAlbaran(idAlbaran, idFactura) {
    return this.ctx.euromoda_dameSelectLineasAlbaran(idAlbaran, idFactura);
  }
  function dameColor(fN, fV, cursor, fT, sel) {
    return this.ctx.euromoda_dameColor(fN, fV, cursor, fT, sel);
  }
  function distribucionCompleta(curA) {
    return this.ctx.euromoda_distribucionCompleta(curA);
  }
  function imprimePackingList() {
    return this.ctx.euromoda_imprimePackingList();
  }
  function dameArrayLineasDist(cursor) {
    return this.ctx.euromoda_dameArrayLineasDist(cursor);
  }
  function tbnFiltro_clicked() {
		return this.ctx.euromoda_tbnFiltro_clicked();
	}
	function tbnQuitarFiltro_clicked() {
		return this.ctx.euromoda_tbnQuitarFiltro_clicked();
	}
	function toolButtomInsert_clicked() {
		return this.ctx.euromoda_toolButtomInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.euromoda_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.euromoda_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.euromoda_toolButtonZoom_clicked();
	}
	function toolButtonCopy_clicked() {
		return this.ctx.euromoda_toolButtonCopy_clicked();
	}
	function curP_bufferCommited() {
		return this.ctx.euromoda_curP_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tableDBRecords_recordChoosed() {
		return this.ctx.euromoda_tableDBRecords_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function toolButtonPrintProf_clicked() {
		return this.ctx.euromoda_toolButtonPrintProf_clicked();
	}
	function generarFacturaDropshiping(where, curAlbaran, datosAgrupacion){
		return this.ctx.euromoda_generarFacturaDropshiping(where, curAlbaran, datosAgrupacion);
	}
	function creaLineasDropshipping(idFactura,where){
		return this.ctx.euromoda_creaLineasDropshipping(idFactura,where);
	}
	function groupByAgrupacion(cursor) {
		return this.ctx.euromoda_groupByAgrupacion(cursor);
	}
	function selectAgrupacion(cursor) {
		return this.ctx.euromoda_selectAgrupacion(cursor);
	}
	function dameDatosAgrupacionPedidos(curAgruparPedidos) {
		return this.ctx.euromoda_dameDatosAgrupacionPedidos(curAgruparPedidos);
	}
	function masWhereAlbaran(qryAgruparPedidos, curAgruparPedidos) {
		return this.ctx.euromoda_masWhereAlbaran(qryAgruparPedidos, curAgruparPedidos);
	}
	function distribuyeEjercicio(cursor) {
    	return this.ctx.euromoda_distribuyeEjercicio(cursor);
  	}
  	function tbnExportarCan_clicked() {
  		return this.ctx.euromoda_tbnExportarCan_clicked();
  	}
  	function tbnExportarDatos_clicked() {
  		return this.ctx.euromoda_tbnExportarDatos_clicked();
  	}
  	function exportarCanCSV(cursor) {
  		return this.ctx.euromoda_exportarCanCSV(cursor);
  	}
  	function exportarDatosCSV(cursor, filtro) {
  		return this.ctx.euromoda_exportarDatosCSV(cursor, filtro);
  	}
  	function datosFicheroExportar(tipoFichero, cursor) {
		return this.ctx.euromoda_datosFicheroExportar(tipoFichero, cursor);
	}
	function dameNombreFichero(tipoFichero, cursor) {
		return this.ctx.euromoda_dameNombreFichero(tipoFichero, cursor);
	}
	function dameCabecera(tipoFichero, separador, codificacion) {
		return this.ctx.euromoda_dameCabecera(tipoFichero, separador, codificacion);
	}
	function formateaImporte(importe, curO) {
		return this.ctx.euromoda_formateaImporte(importe, curO);
	}
	function formateaCantidad(cantidad, curO) {
		return this.ctx.euromoda_formateaCantidad(cantidad, curO);
	}
	function trataSimboloDecimal(valor, curO) {
		return this.ctx.euromoda_trataSimboloDecimal(valor, curO);
	}
	function trataMillares(valor, curO) {
		return this.ctx.euromoda_trataMillares(valor, curO);
	}
	function dameSelectExportDatos(cursor) {
		return this.ctx.euromoda_dameSelectExportDatos(cursor);
	}
	function dameFromExporDatos(cursor) {
		return this.ctx.euromoda_dameFromExporDatos(cursor);
	}
	function dameWhereExporDatos(cursor, filtro) {
		return this.ctx.euromoda_dameWhereExporDatos(cursor, filtro);
	}
	function exportarDatosDistCSV(cursor, filtro) {
		return this.ctx.euromoda_exportarDatosDistCSV(cursor, filtro);
	}
	function dameSelectExportDatosDist(cursor) {
		return this.ctx.euromoda_dameSelectExportDatosDist(cursor);
	}
	function dameFromExporDatosDist(cursor) {
		return this.ctx.euromoda_dameFromExporDatosDist(cursor);
	}
	function dameWhereExporDatosDist(cursor, filtro) {
		return this.ctx.euromoda_dameWhereExporDatosDist(cursor, filtro);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_datosLineaFactura(curLineaAlbaran)
{
  var _i = this.iface;
  if (!_i.__datosLineaFactura(curLineaAlbaran)) {
    return false;
  }

	if (curLineaAlbaran.valueBuffer("tipoconcepto") != "Texto") {
		var codSubcuenta = curLineaAlbaran.valueBuffer("codsubcuenta");
		if (codSubcuenta) {
			_i.curLineaFactura.setValueBuffer("codsubcuenta", codSubcuenta);
			if (curLineaAlbaran.valueBuffer("idsubcuenta")) {
				_i.curLineaFactura.setValueBuffer("idsubcuenta", curLineaAlbaran.valueBuffer("idsubcuenta"));
			}
		} else {
			var codEjercicio = AQUtil.sqlSelect("facturascli", "codejercicio", "idfactura = " + _i.curLineaFactura.valueBuffer("idfactura"));
			codSubcuenta = formRecordlineaspedidoscli.iface.pub_dameSubcuentaProducto(_i.curLineaFactura);
			if (codSubcuenta) {
				_i.curLineaFactura.setValueBuffer("codsubcuenta", codSubcuenta);
				var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
				if (idSubcuenta) {
					_i.curLineaFactura.setValueBuffer("idsubcuenta", idSubcuenta);
				}
			}
		}
		if (!codSubcuenta || codSubcuenta == "" || codSubcuenta == 0) {
			MessageBox.warning(sys.translate("Error a facturar la l�nea %1. No se ha encontrado la subcuenta de ventas asociada al producto, activo o cuenta").arg(curLineaAlbaran.valueBuffer("numlinea")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}

		//debug("referencia " + curLineaAlbaran.valueBuffer("referencia") + " SCTA  " + codSubcuenta);
	}

  var codArancelario = curLineaAlbaran.valueBuffer("codarancelario")
  if (!codArancelario || codArancelario == "") {
		codArancelario = AQUtil.sqlSelect("articulos", "codarancelario", "referencia = '" + curLineaAlbaran.valueBuffer("referencia") + "'");
	}
  _i.curLineaFactura.setValueBuffer("codarancelario", codArancelario);
  _i.curLineaFactura.setValueBuffer("tipoconcepto", curLineaAlbaran.valueBuffer("tipoconcepto"));
  _i.curLineaFactura.setValueBuffer("texto", curLineaAlbaran.valueBuffer("texto"));
	_i.curLineaFactura.setValueBuffer("codamortizacion", curLineaAlbaran.valueBuffer("codamortizacion"));
	_i.curLineaFactura.setValueBuffer("refcliente", curLineaAlbaran.valueBuffer("refcliente"));
	_i.curLineaFactura.setValueBuffer("codtamanoem", curLineaAlbaran.valueBuffer("codtamanoem"));
	_i.curLineaFactura.setValueBuffer("codcolorem", curLineaAlbaran.valueBuffer("codcolorem"));

	if (_i.curFactura.valueBuffer("deabono")) {
		_i.curLineaFactura.setValueBuffer("iva", curLineaAlbaran.valueBuffer("iva"));
		_i.curLineaFactura.setValueBuffer("recargo", curLineaAlbaran.valueBuffer("recargo"));
	}


	if(curLineaAlbaran.valueBuffer("tipoconcepto") == "Producto") {		
		//21-01-2019 Que vaya por separado el coste y el margen a la hora de evaluar si se recalcula o se copia.
		var costeProd = false;
		var margenProd = false;	
		if(curLineaAlbaran.valueBuffer("em_costeprod") && curLineaAlbaran.valueBuffer("em_costeprod") != "" && !curLineaAlbaran.isNull("em_costeprod")) {
			_i.curLineaFactura.setValueBuffer("em_costeprod", curLineaAlbaran.valueBuffer("em_costeprod"));
			_i.curLineaFactura.setValueBuffer("em_fechacosteprod", curLineaAlbaran.valueBuffer("em_fechacosteprod"));
			_i.curLineaFactura.setValueBuffer("em_horacosteprod", curLineaAlbaran.valueBuffer("em_horacosteprod"));
		} else {
			costeProd = true;
		}	
		if(curLineaAlbaran.valueBuffer("em_margenprod") && curLineaAlbaran.valueBuffer("em_margenprod") != "" && !curLineaAlbaran.isNull("em_margenprod")) {
			_i.curLineaFactura.setValueBuffer("em_margenprod", curLineaAlbaran.valueBuffer("em_margenprod"));
			_i.curLineaFactura.setValueBuffer("em_fechamargenprod", curLineaAlbaran.valueBuffer("em_fechamargenprod"));
			_i.curLineaFactura.setValueBuffer("em_horamargenprod", curLineaAlbaran.valueBuffer("em_horamargenprod"));
		} else {
			margenProd = true;
		}
		if(costeProd || margenProd) {					
			var oParamLin = new Object;
			oParamLin.cursor = _i.curLineaFactura;
			oParamLin.ignorarAvisos = true;
			oParamLin.forzarReg = false;
			oParamLin.ignorarCalculoInsert = false; 
			var codCliente;
			var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(_i.curLineaFactura);
			if (!datosTP) {
				codCliente = false;
			} else {
				codCliente = datosTP["codcliente"];
			}
			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",codCliente);	
			formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);	

		} else {
			_i.curLineaFactura.setValueBuffer("em_estadocostes", curLineaAlbaran.valueBuffer("em_estadocostes"));
			_i.curLineaFactura.setValueBuffer("em_politicacostes", curLineaAlbaran.valueBuffer("em_politicacostes"));
			_i.curLineaFactura.setValueBuffer("em_motivocostes", curLineaAlbaran.valueBuffer("em_motivocostes"));
			_i.curLineaFactura.setValueBuffer("em_alarmaoff", curLineaAlbaran.valueBuffer("em_alarmaoff"));
		}

	}

  return true;
}


function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
  var valor;
	var cx; try { cx = cursor.connectionName();} catch(e) { cx = ""; }

  switch (fN) {
  case "pordtoesp_fp": {
      valor = AQUtil.sqlSelect("formaspago", "pordtoesp", "codpago = '" + cursor.valueBuffer("codpago") + "'");
      valor = parseFloat(AQUtil.roundFieldValue(valor, "albaranescli", "pordtoesp"));
      break;
    }
  case "tipoportes": {
      var codCliente = cursor.valueBuffer("codcliente");
      if (codCliente) {
        valor = AQUtil.sqlSelect("clientes", "tipoportes", "codcliente = '" + codCliente + "'");
      }
      break;
    }
  case "dirfacturacion": {
	  valor = formpresupuestoscli.iface.pub_commonCalculateField(fN, cursor);
      break;
    }
    case "codserie": {
			if (cursor.modeAccess() != cursor.Insert && !(cursor.modeAccess() == cursor.Edit && cursor.valueBuffer("estadogit") < 2 && (sys.nameBD().find("creaciones") >= 0 || sys.nameBD().find("euromoda") >= 0))) {
        MessageBox.warning(sys.translate("Est� tratando de cambiar la serie de un albar�n cuyo c�digo ya ha sido generado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
        return cursor.valueBuffer("codserie");
      }
      if (cursor.valueBuffer("deabono")) {
        valor = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli gc ON c.codgrupocontablecli = gc.codgrupo", "gc.codserieabo", "c.codcliente = '" + cursor.valueBuffer("codcliente") + "'", "clientes");
      } else {
        valor = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli gc ON c.codgrupocontablecli = gc.codgrupo", "gc.codseriefac", "c.codcliente = '" + cursor.valueBuffer("codcliente") + "'", "clientes");
      }
      break;
    }
		default: {
      valor = _i.__commonCalculateField(fN, cursor);
      break;
    }
  }
  return valor;
}

function euromoda_datosFactura(curAlbaran, where, datosAgrupacion)
{
	var _i = this.iface;
	if (!_i.__datosFactura(curAlbaran, where, datosAgrupacion)) {
		return false;
	}
	var codDropshipping = curAlbaran.valueBuffer("em_coddropshipping");

	_i.curFactura.setValueBuffer("em_codpago", curAlbaran.valueBuffer("em_codpago"));
	_i.curFactura.setValueBuffer("codagencia", curAlbaran.valueBuffer("codagencia"));
	_i.curFactura.setValueBuffer("docexterno", curAlbaran.valueBuffer("docexterno"));
	_i.curFactura.setValueBuffer("departamento", curAlbaran.valueBuffer("departamento"));
	_i.curFactura.setValueBuffer("pobincoterm", curAlbaran.valueBuffer("pobincoterm"));
	_i.curFactura.setValueBuffer("em_deabono", curAlbaran.valueBuffer("deabono"));	

	var distinAutorizados = AQUtil.sqlSelect("albaranescli", "count(distinct(em_autorizadocostes))", where);	

	if(distinAutorizados > 1) {
		_i.curFactura.setValueBuffer("em_autorizadocostes", false);	
	} else {
		_i.curFactura.setValueBuffer("em_autorizadocostes", curAlbaran.valueBuffer("em_autorizadocostes"));
	}

	_i.curFactura.setValueBuffer("em_estadocostes", curAlbaran.valueBuffer("em_estadocostes"));
	_i.curFactura.setValueBuffer("em_politicacostes", curAlbaran.valueBuffer("em_politicacostes"));
	_i.curFactura.setValueBuffer("em_motivocostes", curAlbaran.valueBuffer("em_motivocostes"));


	/*
	if (datosAgrupacion) {
		if("optFechaValor" in datosAgrupacion && datosAgrupacion.optFechaValor == "Agrupar por fecha valor") {
			_i.curFactura.setValueBuffer("fechavalor", curAlbaran.valueBuffer("fechavalor"));
		} 
	} */
	//Cambiado por #EUR #H1384 #T2 Propagaci�n de fecha valor de pedido a albar�n y de albar�n a factura de cliente
	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	if (datosAgrupacion) {
		if("optFechaValor" in datosAgrupacion && datosAgrupacion.optFechaValor == "Agrupar por fecha valor") {
			_i.curFactura.setValueBuffer("fechavalor", curAlbaran.valueBuffer("fechavalor"));
		} 
	}else {
		_i.curFactura.setValueBuffer("fechavalor", curAlbaran.valueBuffer("fechavalor"));	
	}	
	//////////////////////////////////////////////////////////////////////////////////////////////////////
  	var codCliente = curAlbaran.valueBuffer("codcliente");
  	var codClienteFac = curAlbaran.valueBuffer("codclientefac");
  	if(codDropshipping && codDropshipping != ""){
  		//debug("codcliente: " + codCliente);
  		_i.curFactura.setValueBuffer("em_coddropshipping", codDropshipping);
  		codCliente = AQUtil.sqlSelect("em_dropshipping", "codcliente", "codigo = '" + codDropshipping + "'");
  		codClienteFac = "";
  		//debug("codcliente2: " + codCliente);
  	}
  	if (codCliente || codClienteFac) {
    	if (!codClienteFac || codClienteFac == "") {
      		codClienteFac = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente = '" + codCliente + "'");
    	}
		var q = new FLSqlQuery;
		q.setSelect("c.nombre, c.cifnif, dc.id, dc.direccion, dc.codpostal, dc.ciudad, dc.provincia, dc.codpais");
		q.setFrom("clientes c INNER JOIN dirclientes dc ON (c.codcliente = dc.codcliente AND dc.domfacturacion)");
		q.setForwardOnly(true);
    	if (codClienteFac) {
    		//debug("codclientefac: " + codClienteFac);
      		q.setWhere("c.codcliente = '" + codClienteFac + "'");
      		if (!q.exec()) {
        		return false;
      		}
      		if (!q.first()) {
        		sys.warnMsgBox(sys.translate("Error al obtener los datos y direcci�n de facturaci�n del cliente de facturaci�n %1").arg(codClienteFac));
        		return false;
      		}
      		with (_i.curFactura) {
		        setValueBuffer("codcliente", codClienteFac);
		        setValueBuffer("cifnif", q.value("c.cifnif"));
		        setValueBuffer("nombrecliente", q.value("c.nombre"));
		        setValueBuffer("coddir", q.value("dc.id"));
		        setValueBuffer("direccion", q.value("dc.direccion"));
		        setValueBuffer("codpostal", q.value("dc.codpostal"));
		        setValueBuffer("ciudad", q.value("dc.ciudad"));
		        setValueBuffer("provincia", q.value("dc.provincia"));
		        setValueBuffer("codpais", q.value("dc.codpais"));
			}
    	} 
    	else {
    		//debug("codcliente: " + codCliente);
			q.setWhere("c.codcliente = '" + codCliente + "'");
			if (!q.exec()) {
				return false;
			}
			if (!q.first()) {
        		sys.warnMsgBox(sys.translate("Error al obtener los datos y direcci�n de facturaci�n del cliente de facturaci�n %1").arg(codClienteFac));
        		return false;
      		}
      		with (_i.curFactura) {
      			setValueBuffer("nombrecliente", q.value("c.nombre"));
		        setValueBuffer("coddir", q.value("dc.id"));
		        setValueBuffer("direccion", q.value("dc.direccion"));
		        setValueBuffer("codpostal", q.value("dc.codpostal"));
		        setValueBuffer("ciudad", q.value("dc.ciudad"));
		        setValueBuffer("provincia", q.value("dc.provincia"));
		        setValueBuffer("codpais", q.value("dc.codpais"));
			}
		}
  	}
  	with (_i.curFactura) {
  		if(curAlbaran.valueBuffer("coddir") && curAlbaran.valueBuffer("coddir") != ""){
			setValueBuffer("coddire", curAlbaran.valueBuffer("coddir"));
			setValueBuffer("direccione", curAlbaran.valueBuffer("direccion"));
			setValueBuffer("codpostale", curAlbaran.valueBuffer("codpostal"));
			setValueBuffer("ciudade", curAlbaran.valueBuffer("ciudad"));
			setValueBuffer("provinciae", curAlbaran.valueBuffer("provincia"));
			setValueBuffer("codpaise", curAlbaran.valueBuffer("codpais"));
		}
	}
  return true;
}

function euromoda_datosDirFactura(curAlbaran, where, datosAgrupacion)
{
  var _i = this.iface;
  var codCliente = curAlbaran.valueBuffer("codcliente");
  if (codCliente) {
    var codClienteFac = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente = '" + codCliente + "'");
    if (codClienteFac) {
      return true;
    }
  }
  return _i.__datosDirFactura(curAlbaran, where, datosAgrupacion);
}

function euromoda_totalizaAlbaranDist(curAlbaran)
{
  with(curAlbaran) {
    setValueBuffer("netosindtoesp", formalbaranescli.iface.pub_commonCalculateField("netosindtoesp", this));
    setValueBuffer("dtoesp", formalbaranescli.iface.pub_commonCalculateField("dtoesp", this));
    setValueBuffer("neto", formalbaranescli.iface.pub_commonCalculateField("neto", this));
    setValueBuffer("totaliva", formalbaranescli.iface.pub_commonCalculateField("totaliva", this));
    setValueBuffer("totalirpf", formalbaranescli.iface.pub_commonCalculateField("totalirpf", this));
    setValueBuffer("totalrecargo", formalbaranescli.iface.pub_commonCalculateField("totalrecargo", this));
    setValueBuffer("total", formalbaranescli.iface.pub_commonCalculateField("total", this));
    setValueBuffer("totaleuros", formalbaranescli.iface.pub_commonCalculateField("totaleuros", this));
  }
  return true;
}

function euromoda_generarFactura(where, curAlbaran, datosAgrupacion)
{
	var _i = this.iface;
	_i.msg_ = "";
	var codCliente = curAlbaran.valueBuffer("codcliente");
	var codDropshipping = curAlbaran.valueBuffer("em_coddropshipping");
	var idFactura;
	//debug("codDropshipping " + codDropshipping);
	
	if (codCliente && codCliente != "") {
		if (!flfacturac.iface.pub_controlBloqueoCliente(codCliente, "Facturar")) {
			return false;
		}
	}
	if (!_i.controlPedidoYaFacturado(where)) {
		return false;
	}
	//debug("dropshiping " + codDropshipping);
	if (codDropshipping && codDropshipping != "") {
		idFactura = _i.generarFacturaDropshiping(where,curAlbaran, datosAgrupacion);
	} 
	else {
		idFactura = _i.__generarFactura(where, curAlbaran, datosAgrupacion)
	}
	if (!idFactura) {
		return false;
	}
  	return idFactura;
}

function euromoda_controlPedidoYaFacturado(where)
{
	if (AQUtil.sqlSelect("albaranescli", "idalbaran", where + " AND idalbaran IN (select idalbaran FROM lineasalbaranescli la INNER JOIN pedidoscli p ON la.idpedido = p.idpedido WHERE la.idalbaran = albaranescli.idalbaran AND p.idfactura <> 0)")) {
		sys.warnMsgBox(sys.translate("Alguno de los pedidos de los que proviene el albar�n ya est� facturado."));
		return false;
	}
	return true;
}

/** \D Informa los datos de una factura referentes a totales (I.V.A., neto, etc.)
@return	True si el c�lculo se realiza correctamente, false en caso contrario
\end */
function euromoda_totalesFactura():Boolean
{
	  var _i = this.iface;
	if (!_i.__totalesFactura()) {
		return false;
	}
	_i.curFactura.setValueBuffer("bultos", formfacturascli.iface.pub_commonCalculateField("bultos", _i.curFactura));
	_i.curFactura.setValueBuffer("volumen", formfacturascli.iface.pub_commonCalculateField("volumen", _i.curFactura));
	_i.curFactura.setValueBuffer("pesoneto", formfacturascli.iface.pub_commonCalculateField("pesoneto", _i.curFactura));
	_i.curFactura.setValueBuffer("pesobruto", formfacturascli.iface.pub_commonCalculateField("pesobruto", _i.curFactura));

	formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",_i.curFactura.valueBuffer("codcliente"));	
	if(!formRecordpresupuestoscli.iface.pub_evaluarCostesCab(_i.curFactura)) {
		return false;
	}
	

	return true;
}

function euromoda_init()
{
  	var _i = this.iface;
  	_i.__init();
  	_i.pedirDatosAdicionales_ = false;
  	connect(this.child("tbnEtiquetas"), "clicked()", _i, "imprimeEtiquetas");
	connect(this.child("tbnAlbaranTrans"), "clicked()", _i, "imprimeTrans");
	connect(this.child("tbnExcel"), "clicked()", _i, "exportaExcel_clicked()");
  	connect(this.child("tbnImprimirMembrete"), "clicked()", _i, "tbnImprimirMembrete_clicked");
  	connect(this.child("tbnPackingList"), "clicked()", _i, "imprimePackingList");
	connect(this.child("tbnFiltro"), "clicked()", _i, "tbnFiltro_clicked");
	connect(this.child("tbnQuitarFiltro"), "clicked()", _i, "tbnQuitarFiltro_clicked");
	
	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	connect(this.child("toolButtonCopy"), "clicked()", _i, "toolButtonCopy_clicked");
	
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tableDBRecords_recordChoosed");
	connect(this.child("toolButtonPrintProf"), "clicked()", _i, "toolButtonPrintProf_clicked");

	connect(this.child("tbnExportarCan"), "clicked()", _i, "tbnExportarCan_clicked");
	connect(this.child("tbnExportarDatos"), "clicked()", _i, "tbnExportarDatos_clicked");
}

function euromoda_imprimeEtiquetas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idAlbaran = cursor.valueBuffer("idalbaran");
	if (!idAlbaran) {
		return false;
	}
	
	_i.imprimirEtiquetasAlbaran(idAlbaran);
}

function euromoda_imprimirEtiquetasAlbaran(idAlbaran)
{
	var _i = this.iface;	
	var normal = true, reparto = false;
	var idAlbaranComp = AQUtil.sqlSelect("albaranescli", "idalbarancomp", "idalbaran = " + idAlbaran);
	if (idAlbaranComp) {
		var d = new Dialog;
		d.okButtonText = sys.translate("Aceptar");
		d.cancelButtonText = sys.translate("Cancelar");
	
		var chkA = new CheckBox;
		chkA.text = sys.translate("Imprimir etiquetas");
		chkA.checked = true;
		
		var chkB = new CheckBox;
		chkB.text = sys.translate("Imprimir etiquetas de reparto");
		chkB.checked = true;
		
		d.add(chkA);
		d.add(chkB);
		
		if (!d.exec()) {
			return false;
		}
		normal = chkA.checked;
		reparto = chkB.checked;
	}
	if (!normal && !reparto) {
		return;
	}

	var nombreCx;
	if (reparto) {
		if (!flfacturac.iface.pub_conectarDA()) {
			return;
		}
		nombreCx = flfacturac.iface.pub_conexionDA();
	}
	
	oParam = new Object;
	oParam.rptViewer = new FLReportViewer();
	var append, display, pageBreak = true;
	if (normal) {
		oParam.append = false;
		oParam.pageBreak = false;
		oParam.display = !reparto;
		
		var q = new FLSqlQuery("i_eti_albaranescli");
		q.setWhere("albaranescli.idalbaran = " + idAlbaran);
		formi_albaranescli.iface.pub_lanzaEtiquetas(q, oParam);
	}
	if (reparto) {
		oParam.append = normal;
		oParam.pageBreak = normal;
		oParam.display = true;
		
		var q = new FLSqlQuery("i_eti_albaranescli", nombreCx);
		q.setWhere("albaranescli.idalbaran = " + idAlbaranComp);
		formi_albaranescli.iface.pub_lanzaEtiquetas(q, oParam);
	}
}

function euromoda_exportaExcel_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idAlbaran = cursor.valueBuffer("idalbaran");

	var q = new FLSqlQuery;
	q.setSelect("la.idalbaran, ms.cantidad, ms.referencia, art.aliasart, la.descripcion, t.descripcion, c.descripcion");

	q.setFrom("lineasalbaranescli la INNER JOIN movistock ms ON la.idlinea = ms.idlineaac INNER JOIN articulos art ON ms.referencia = art.referencia INNER JOIN em_tamanos t ON art.codtamanoem = t.codtamanoem INNER JOIN em_colores c ON art.codcolorem = c.codcolorem");

	q.setWhere("la.idalbaran = '" + idAlbaran + "'");

	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	//debug(q.sql());
	_i.exportaExcel(q);
}

function euromoda_exportaExcel(consulta)
{
	var cursor = this.cursor();
	var idAlbaran = cursor.valueBuffer("idalbaran");

// Estilos para poner a las celdas
	var centerStyle = new AQOdsStyle(AQS.ODS_ALIGN_CENTER);
  var titleCellStyle = new AQOdsStyle(AQS.ODS_ALIGN_CENTER |
                                  AQS.ODS_TEXT_BOLD);
  var tSep = new AQOdsStyle(AQS.ODS_BORDER_TOP);
  var bSep = new AQOdsStyle(AQS.ODS_BORDER_BOTTOM);
  var rSep = new AQOdsStyle(AQS.ODS_BORDER_RIGHT);
  var lSep = new AQOdsStyle(AQS.ODS_BORDER_LEFT);
  var lAlig = new AQOdsStyle(AQS.ODS_ALIGN_LEFT);
  var rAlig = new AQOdsStyle(AQS.ODS_ALIGN_RIGHT);

	// Creaci�n del archivo ods.
	var odsGen = new AQOdsGenerator;
  var spreadsheet = new AQOdsSpreadSheet(odsGen);
  var sheet = new AQOdsSheet(spreadsheet, "Packing List");

	// Cabecera para las columnas.
  var row = new AQOdsRow(sheet);
  row.addBgColor(new AQOdsColor(225,223,223)) // color de fondo para toda la fila
  row.opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn(lSep).opIn("METROS")
  .opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn("REFERENCIA")
  .opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn("REF. CLIENTE")
  .opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn("DESCRIPCION")
  .opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn("TAMA�O")
  .opIn(titleCellStyle).opIn(tSep).opIn(rSep).opIn("COLOR");
  row.close();

	var i = 0; // Variable para colorear de gris las filas pares.
	while(consulta.next()){

		var row2 = new AQOdsRow(sheet);

		// Coloreo la fila por comodidad visual.
			if ( i % 2 == 0){
				row2.addBgColor(new AQOdsColor(228,228,228))
			}
			else{
				row2.addBgColor(new AQOdsColor(255,255,255))
			}

		var paisEmpresa = flfactppal.iface.pub_valorDefectoEmpresa("codpais");
		var paisCliente = AQUtil.sqlSelect("dirclientes", "codpais", "codcliente = '" + cursor.valueBuffer("codcliente") + "' AND domfacturacion IS true");
		var descripcion;
		if(paisCliente && paisCliente != "" && paisCliente != paisEmpresa){
			descripcion = AQUtil.sqlSelect("traducciones", "traduccion", "idcampo = '" + consulta.value("ms.referencia") + "' AND campo = 'descripcion'");
			if(!descripcion){
				descripcion = consulta.value("la.descripcion");
			}
		}
		else {
			descripcion = consulta.value("la.descripcion");
		}

		row2.opIn(lAlig).opIn(rSep).opIn(consulta.value("ms.cantidad")*(-1))
		.opIn(centerStyle).opIn(rSep).opIn(consulta.value("ms.referencia"))
		.opIn(centerStyle).opIn(rSep).opIn(consulta.value("art.aliasart"))
		.opIn(centerStyle).opIn(rSep).opIn(descripcion)
		.opIn(centerStyle).opIn(rSep).opIn(consulta.value("t.descripcion"))
		.opIn(centerStyle).opIn(rSep).opIn(lSep).opIn(consulta.value("c.descripcion"));

		row2.close();
		i++;
	}

	var row= new AQOdsRow(sheet);
	row.opIn(tSep).opIn("",5);
	row.close();

  sheet.close();
  spreadsheet.close();

	//Nombre del archivo.
  var odsFileName = Dir.home + "/packing_list_"+ idAlbaran +".ods";
  odsFileName = Dir.cleanDirPath(odsFileName);
  odsFileName = Dir.convertSeparators(odsFileName);
	// Funci�n que crea "f�sicamente" el archivo con la configuraci�n y datos introducidos anteriormente.
  odsGen.generateOds(odsFileName);
  MessageBox.information("Fichero generado en " + odsFileName);
	// Abrir archivo.
  sys.openUrl("file://" + odsFileName);

}

function euromoda_imprimePackingList()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codigo = cursor.valueBuffer("codigo");
	if (!codigo) {
		return;
	}

  var oParam = flfactinfo.iface.pub_dameParamInforme();
  if (!oParam) {
    return;
  }
	var paisEmpresa = flfactppal.iface.pub_valorDefectoEmpresa("codpais");
//debug("///////////////////// empresa" + paisEmpresa);
	var paisAlbaran = AQUtil.sqlSelect("albaranescli", "codpais", "codigo = '" + codigo + "'");
//debug("///////////////////// albaran" + paisAlbaran);
	if(paisAlbaran && paisAlbaran != "" && paisAlbaran != paisEmpresa){
//debug("///////////////////// internacional");
			oParam.nombreInforme = "i_albaranescli_packing_int";
	}
	else {
//debug("///////////////////// nacional");
		oParam.nombreInforme = "i_albaranescli_packing";
	}

  var curImprimir = new FLSqlCursor("i_albaranescli");
  curImprimir.setModeAccess(curImprimir.Insert);
  curImprimir.refreshBuffer();
  curImprimir.setValueBuffer("descripcion", "temp");
  curImprimir.setValueBuffer("d_albaranescli_codigo", codigo);
  curImprimir.setValueBuffer("h_albaranescli_codigo", codigo);

  flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
}

function euromoda_imprimeTrans()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var codigo = cursor.valueBuffer("codigo");
  if (!codigo) {
    return;
  }


	var idAlbaran = cursor.valueBuffer("idalbaran");
	if (!idAlbaran) {
		return;
	}

	_i.imprimirAlbaranTrans(codigo, idAlbaran)
}

function euromoda_imprimirAlbaranTrans(codigo, idAlbaran)
{
	var _i = this.iface;

  if (parseFloat(AQUtil.sqlSelect("em_2albaranes", "COUNT(*)", "true")) != 2) {
		var cur2a = new FLSqlCursor("em_2albaranes");
		for (var i = 0; i < 2; i++) {
			cur2a.setModeAccess(cur2a.Insert);
			cur2a.refreshBuffer();
			cur2a.commitBuffer();
		}
	}

  var oParam = _i.dameParamInformeTrans();
  if (!oParam) {
    return;
  }
	var normal = true, reparto = false;
	var idAlbaranComp = AQUtil.sqlSelect("albaranescli", "idalbarancomp", "idalbaran = " + idAlbaran);
	if (idAlbaranComp) {
		var d = new Dialog;
		d.okButtonText = sys.translate("Aceptar");
		d.cancelButtonText = sys.translate("Cancelar");
		
		var chkA = new CheckBox;
		chkA.text = sys.translate("Imprimir albar�n para transportista");
		chkA.checked = true;
		
		var chkB = new CheckBox;
		chkB.text = sys.translate("Imprimir albar�n de reparto para transportista");
		chkB.checked = true;
		
		d.add(chkA);
		d.add(chkB);
		
		if (!d.exec()) {
			return false;
		}
		normal = chkA.checked;
		reparto = chkB.checked;
	}
	if (!normal && !reparto) {
		return;
	}
	
	var nombreCx;
	if (reparto) {
		if (!flfacturac.iface.pub_conectarDA()) {
			return;
		}
		nombreCx = flfacturac.iface.pub_conexionDA();
	}
	
	var curImprimir: FLSqlCursor = new FLSqlCursor("i_albaranescli");
  curImprimir.setModeAccess(curImprimir.Insert);
  curImprimir.refreshBuffer();
  curImprimir.setValueBuffer("descripcion", "temp");
  curImprimir.setValueBuffer("d_albaranescli_codigo", codigo);
  curImprimir.setValueBuffer("h_albaranescli_codigo", codigo);
  
	oParam.rptViewer = new FLReportViewer();
	var append, display, pageBreak = true;
	if (normal) {
		oParam.append = false;
		oParam.pageBreak = false;
		oParam.display = !reparto;
		flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
	}
	if (reparto) {
		flfactinfo.iface.pub_ponerMembrete(false);
		oParam.append = normal;
		oParam.pageBreak = normal;
		oParam.display = true;
		oParam.nombreCx = nombreCx;
		flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
	}
}

function euromoda_dameParamInformeTrans()
{
  var oParam = flfactinfo.iface.pub_dameParamInforme();
  oParam.nombreInforme = "i_albaranescli_trans";
	oParam.nombreReport = "i_albaranescli_trans";
  return oParam;
}

function euromoda_tbnImprimirMembrete_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAlbaran = cursor.valueBuffer("codigo");
	flfactinfo.iface.pub_ponerMembrete(true);

  _i.imprimir();
	flfactinfo.iface.pub_ponerMembrete(false);
}

function euromoda_imprimir(codAlbaran)
{
	var _i = this.iface;

	var membrete = flfactinfo.iface.pub_dameMembrete();

	var idAlbaran, codigo;
	if (codAlbaran) {
		codigo = codAlbaran;
		idAlbaran = AQUtil.sqlSelect("albaranescli", "idalbaran", "codigo = '" + codigo + "'");
	} else {
		var cursor = this.cursor();
		if (!cursor.isValid()) {
			return;
		}
		codigo = this.cursor().valueBuffer("codigo");
		idAlbaran = this.cursor().valueBuffer("idalbaran");
	}
	if (!idAlbaran) {
		return;
	}


	var idAlbaranComp = AQUtil.sqlSelect("albaranescli", "idalbarancomp", "idalbaran = " + idAlbaran);
	if (!idAlbaranComp) {
    return _i.__imprimir(codAlbaran);
	}
	var d = new Dialog;
	d.okButtonText = sys.translate("Aceptar");
	d.cancelButtonText = sys.translate("Cancelar");
	
	var chkA = new CheckBox;
	chkA.text = sys.translate("Imprimir albar�n");
	chkA.checked = true;
	
	var chkB = new CheckBox;
	chkB.text = sys.translate("Imprimir albar�n de reparto");
	chkB.checked = true;
	
	d.add(chkA);
	d.add(chkB);
	
	if (!d.exec()) {
		return false;
	}
	if (!chkA.checked && !chkB.checked) {
		return;
	}
	
	var oParam = this.iface.dameParamInforme(idAlbaran);
	if (!oParam) {
		return;
	}

	var curImprimir = new FLSqlCursor("i_albaranescli");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_albaranescli_codigo", codigo);
	curImprimir.setValueBuffer("h_albaranescli_codigo", codigo);

  
	var nombreCx;
	if (chkB.checked) {
		if (!flfacturac.iface.pub_conectarDA()) {
			return;
		}
		nombreCx = flfacturac.iface.pub_conexionDA();
	}
	
	oParam.rptViewer = new FLReportViewer();
	var append, display, pageBreak = true;
  
	if (chkA.checked) {
		oParam.append = false;
		oParam.pageBreak = false;
		oParam.display = !chkB.checked;
		flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
	}
	if (chkB.checked) {
		flfactinfo.iface.pub_ponerMembrete(false);
		oParam.append = chkA.checked;
		oParam.pageBreak = chkA.checked;
		oParam.display = true;
		oParam.nombreCx = nombreCx;
		flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);

	}
  
}

function euromoda_copiaCampoDist(nombreCampo, curA, curB, campoInformado)
{
  var _i = this.iface;
  if (campoInformado[nombreCampo]) {
    return true;
  }
  var valor;
  var nulo = false;

  switch (curA.table()) {
    case "albaranescli": {
      switch (nombreCampo) {
        case "coddir": {
          nulo = true;
          break;
        }
				case "bultos": {
					valor = curA.valueBuffer("bultosreparto");
					break;
				}
				case "pesobruto": {
					valor = curA.valueBuffer("pesobrutoreparto");
					break;
				}
				case "volumen": {
					valor = curA.valueBuffer("volumenreparto");
					break;
				}
				default: {
          return _i.__copiaCampoDist(nombreCampo, curA, curB, campoInformado);
				}
      }
      break;
    }
    case "lineasalbaranescli": {
      switch (nombreCampo) {
        case "codimpuesto": {
          valor = "NO IVA";
          break;
        }
        case "iva":
				case "recargo": {
          valor = 0;
          break;
        }
				case "idsubcuenta": {
					return true;
					break;
				}
        default: {
          return _i.__copiaCampoDist(nombreCampo, curA, curB, campoInformado);
				}
      }
    }
  }
  if (nulo) {
    curB.setNull(nombreCampo);
  } else {
    curB.setValueBuffer(nombreCampo, valor);
  }
  campoInformado[nombreCampo] = true;

  return true;
}

function euromoda_dameParamInforme(idAlbaran)
{
	
	var _i = this.iface;
  var nombreInforme = '';
  var paisEmpresa = flfactppal.iface.pub_valorDefectoEmpresa("codpais");
  var paisAlbaran = AQUtil.sqlSelect("albaranescli", "codpais", "idalbaran = '" + idAlbaran + "'");
 

  if(paisAlbaran && paisAlbaran != "" && paisAlbaran != paisEmpresa)
    nombreInforme = "i_albaranescli_int";
  else
   nombreInforme = "i_albaranescli";


  var oParam = _i.__dameParamInforme(idAlbaran);
  oParam.whereFijo = "NOT (lineasalbaranescli.candistribuida <> 0 AND lineasalbaranescli.canfactura = 0 AND lineasalbaranescli.tipoconcepto = 'Producto')";
  oParam.nombreInforme = 'i_albaranescli';
  oParam.nombreReport = nombreInforme;
  return oParam;
}

function euromoda_dameSelectLineasAlbaran(idAlbaran, idFactura)
{
	var s = "idalbaran = " + idAlbaran + " AND NOT (lineasalbaranescli.candistribuida <> 0 AND lineasalbaranescli.canfactura = 0 AND lineasalbaranescli.tipoconcepto = 'Producto') ORDER BY numlinea";
	return s;
}

function euromoda_dameColor(fN, fV, cursor, fT, sel)
{
	var color = "";
	switch (fN) {
		case "codigo": {
			if (cursor.valueBuffer("idfactura")) {
				color = flfactppal.iface.pub_dameColor("fondo_facturado");
			}
			break;
		}
		default: {
			return;
		}
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}

function euromoda_distribucionCompleta(curA)
{
	var _i = this.iface;
	var idA = curA.valueBuffer("idalbaran");
	if (AQUtil.sqlSelect("lineasalbaranescli", "idlinea", "idalbaran = " + idA + " AND canfactura <> 0 AND tipoconcepto <> 'Texto'")) {
		return false;
	}
	return true;
}

function euromoda_dameArrayLineasDist(cursor)
{
  var _i = this.iface;
  var idAlbaran = cursor.valueBuffer("idalbaran");
  if (!idAlbaran) {
    return false;
  }

  var f = new FLFormSearchDB("distribuiralbaranescli");
  f.setMainWidget();
  var curAlb = f.cursor();
  curAlb.select("idalbaran = " + idAlbaran);
  if (!curAlb.first()) {
    return false;
  }
  curAlb.setModeAccess(curAlb.Edit);
  curAlb.refreshBuffer();

  if (!f.exec("idalbaran")) {
		sys.warnMsgBox(sys.translate("Ha cancelado el reparto.\nRecuerde que el albar�n %1 est� por repartir").arg(curAlb.valueBuffer("codigo")));
    return false;
  }
  if (!curAlb.commitBuffer()) {
		return false;
	}
  return _i.aLineasDist_;
}

function euromoda_tbnQuitarFiltro_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var fBase = _i.filtroTabla();
	cursor.setMainFilter(fBase);

	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_tbnFiltro_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();

	var f = new FLFormSearchDB("em_filtroalbaranescli");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);

	f.setMainWidget();

	var filtro = f.exec("filtro");
//debug("filtro " + filtro);
	if (!filtro) {
		filtro = "1 = 1";
	}
	var fBase = _i.filtroTabla();

	if (filtro) {
		curF.commitBuffer();
		cursor.setMainFilter(fBase + " AND " + filtro);
	} else {
		cursor.setMainFilter(fBase);
	}

	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_tableDBRecords_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEdit_clicked();
}

function euromoda_toolButtomInsert_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");

}

function euromoda_toolButtonEdit_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDelete_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoom_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}

function euromoda_toolButtonCopy_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("copy");
}

function euromoda_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (_i.curP_) {
		disconnect(_i.curP_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curP_, "commited()", _i, "curP_bufferCommited");
		_i.curP_ = undefined;
	}
	
	_i.curP_ = new FLSqlCursor("albaranescli");
	_i.curP_.setAction("albaranescli");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curP_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curP_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curP_, "commited()", _i, "curP_bufferCommited");
			_i.curP_.insertRecord();
			break;
		}
		case "edit": {
			connect(_i.curP_, "commited()", _i, "refrescaTabla");
			_i.curP_.editRecord();
			break;
		}
		case "del": {
			this.child("tableDBRecords").deleteRecord();
			break;
		}
		case "browse": {	
			_i.curP_.browseRecord();
			break;
		}
		case "copy": {
			this.child("tableDBRecords").copyRecord(); // Deber�amos llamar a curP_.copyRecord, pero no est� publicado
			break;
		}
	}
}

function euromoda_refrescaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.refresh()
}

function euromoda_curP_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	} 
	
	var dtbLC = this.mainWidget().child("tableDBRecords").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);

	var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);
	
	var oParams = [];
	oParams.fN = "codigo";
	oParams.valor = _i.pK_;
	oParams.cursor = cursor;
	oParams.tipoOrden = asc
	oParams.objTabla = this.child("tableDBRecords");

	var pos = flfacturac.iface.pub_buscaPosEnCursor(oParams);
	if (pos == -1) {
		debug("No encontrado");
		return false;
	}
	cursor.seek(pos);
	cursor.refresh();
}

function euromoda_toolButtonPrintProf_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAlbaran = cursor.valueBuffer("codigo");
	_i.proforma_ = true;
	_i.imprimir();
	_i.proforma_ = false;
	

}

function euromoda_generarFacturaDropshiping(where, curAlbaran, datosAgrupacion)
{
	var _i = this.iface;

	if (!_i.curFactura)
		_i.curFactura = new FLSqlCursor("facturascli");

	_i.curFactura.setModeAccess(_i.curFactura.Insert);
	_i.curFactura.refreshBuffer();

	if (!_i.datosFactura(curAlbaran, where, datosAgrupacion))
	{
		return false;
	}

	if (!_i.curFactura.commitBuffer())
	{
		return false;
	}

	var idFactura = _i.curFactura.valueBuffer("idfactura");
	//debug("FACTURA = " + idFactura);
	//debug("where: "+where);
	if(datosAgrupacion && datosAgrupacion != "") {
		//debug("\n\n*********datosagrupacion ok")
	} else {
		where = "albaranescli."+where;
		//debug("\n\n*********datosagrupacion no ok")
	}
	_i.creaLineasDropshipping(idFactura,where);

	_i.curFactura.select("idfactura = " + idFactura);
	if (_i.curFactura.first())
	{
		_i.curFactura.setModeAccess(_i.curFactura.Edit);
		_i.curFactura.refreshBuffer();

		if (!_i.totalesFactura())
	  		return false;

		if (_i.curFactura.commitBuffer() == false)
	  		return false;
	}
	if (!_i.validarFactura(idFactura))
	{
		return false;
	}

	var curAlbaranes = new FLSqlCursor("albaranescli");

	curAlbaranes.select(where);
	while (curAlbaranes.next())
	{
	curAlbaranes.setModeAccess(curAlbaranes.Edit);
	curAlbaranes.refreshBuffer();
	if (!curAlbaranes.valueBuffer("ptefactura")) {
	  var codFacturaAlb = AQUtil.sqlSelect("facturascli", "codigo", "idfactura = " + curAlbaranes.valueBuffer("idfactura"));
	  MessageBox.warning(sys.translate("Error al facturar el albar�n %1. Este albar�n ya est� facturado en la factura %2").arg(curAlbaranes.valueBuffer("codigo")).arg(codFacturaAlb), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	  return false;
	}
	curAlbaranes.setValueBuffer("idfactura", idFactura);
	curAlbaranes.setValueBuffer("ptefactura", false);
	if (!curAlbaranes.commitBuffer()) {
	  return false;
	}
	}
	return idFactura;
}

function euromoda_creaLineasDropshipping(idFactura,where)
{
	var _i = this.iface;


	
	var qryLineasDrop =  new FLSqlQuery;

	qryLineasDrop.setSelect("lineasalbaranescli.referencia,SUM(lineasalbaranescli.cantidad),lineasalbaranescli.pvpunitario,lineasalbaranescli.tipoconcepto, lineasalbaranescli.codsubcuenta, lineasalbaranescli.idsubcuenta, lineasalbaranescli.descripcion, lineasalbaranescli.codimpuesto, lineasalbaranescli.iva, lineasalbaranescli.recargo, lineasalbaranescli.dtolineal, lineasalbaranescli.dtopor, lineasalbaranescli.irpf,lineasalbaranescli.porcomision,lineasalbaranescli.codarancelario, lineasalbaranescli.texto,lineasalbaranescli.codamortizacion,lineasalbaranescli.refcliente,lineasalbaranescli.codtamanoem,lineasalbaranescli.codcolorem, albaranescli.codcliente");
	qryLineasDrop.setFrom("lineasalbaranescli inner join albaranescli on lineasalbaranescli.idalbaran = albaranescli.idalbaran");
	qryLineasDrop.setWhere(where + " GROUP BY lineasalbaranescli.referencia, lineasalbaranescli.pvpunitario,lineasalbaranescli.tipoconcepto,lineasalbaranescli.codsubcuenta, lineasalbaranescli.idsubcuenta, lineasalbaranescli.descripcion, lineasalbaranescli.codimpuesto, lineasalbaranescli.iva, lineasalbaranescli.recargo, lineasalbaranescli.dtolineal, lineasalbaranescli.dtopor, lineasalbaranescli.irpf,lineasalbaranescli.porcomision,lineasalbaranescli.codarancelario, lineasalbaranescli.texto,lineasalbaranescli.codamortizacion,lineasalbaranescli.refcliente,lineasalbaranescli.codtamanoem,lineasalbaranescli.codcolorem, albaranescli.codcliente ORDER BY referencia");

	if(!qryLineasDrop.exec()){
		return false;
	}

	var curLineasFact = new FLSqlCursor("lineasfacturascli");
	var numLinea = 1;

	while (qryLineasDrop.next())
	{
		curLineasFact.setModeAccess(curLineasFact.Insert);		
		curLineasFact.refreshBuffer();
		curLineasFact.setValueBuffer("numlinea", numLinea);
		curLineasFact.setValueBuffer("idfactura", idFactura);
		curLineasFact.setValueBuffer("referencia", qryLineasDrop.value("lineasalbaranescli.referencia"));
		curLineasFact.setValueBuffer("descripcion", qryLineasDrop.value("lineasalbaranescli.descripcion"));
		curLineasFact.setValueBuffer("pvpunitario", qryLineasDrop.value("lineasalbaranescli.pvpunitario"));
		curLineasFact.setValueBuffer("cantidad", qryLineasDrop.value("SUM(lineasalbaranescli.cantidad)"));

		curLineasFact.setValueBuffer("cantidad", qryLineasDrop.value("SUM(lineasalbaranescli.cantidad)"));

		var codImpuesto = qryLineasDrop.value("lineasalbaranescli.codimpuesto");
    	curLineasFact.setValueBuffer("codimpuesto", codImpuesto);

    	if (!qryLineasDrop.value("lineasalbaranescli.iva")) {
      		curLineasFact.setNull("iva");
    	} else {
 	     	iva = qryLineasDrop.value("lineasalbaranescli.iva");
      		if (iva != 0 && codImpuesto && codImpuesto != "") {
        		iva = formRecordlineaspedidoscli.iface.pub_commonCalculateField("iva", curLineasFact); /// Para cambio de IVA seg�n fechas
      		}
      		curLineasFact.setValueBuffer("iva", iva);
    	}
    	if (!qryLineasDrop.value("lineasalbaranescli.recargo")) {
      		curLineasFact.setNull("recargo");
    	} else {
      		recargo =qryLineasDrop.value("lineasalbaranescli.recargo");
      		if (recargo != 0 && codImpuesto && codImpuesto != "") {
        		recargo = formRecordlineaspedidoscli.iface.pub_commonCalculateField("recargo", curLineasFact); /// Para cambio de IVA seg�n fechas
      		}
      		curLineasFact.setValueBuffer("recargo", recargo);
    	}
	    curLineasFact.setValueBuffer("irpf", qryLineasDrop.value("lineasalbaranescli.irpf"));
	    curLineasFact.setValueBuffer("dtolineal",qryLineasDrop.value("lineasalbaranescli.dtolineal"));
	    curLineasFact.setValueBuffer("dtopor", qryLineasDrop.value("lineasalbaranescli.dtopor"));
	    curLineasFact.setValueBuffer("porcomision", qryLineasDrop.value("lineasalbaranescli.porcomision"));
		curLineasFact.setValueBuffer("pvpsindto", formRecordlineaspedidoscli.iface.pub_commonCalculateField("pvpsindto", curLineasFact));
		curLineasFact.setValueBuffer("pvptotal", formRecordlineaspedidoscli.iface.pub_commonCalculateField("pvptotal", curLineasFact));

		if (qryLineasDrop.value("lineasalbaranescli.tipoconcepto") != "Texto") {
			var codSubcuenta = qryLineasDrop.value("lineasalbaranescli.codsubcuenta");
			if (codSubcuenta) {
				curLineasFact.setValueBuffer("codsubcuenta", codSubcuenta);
				if (qryLineasDrop.value("lineasalbaranescli.idsubcuenta")) {
					curLineasFact.setValueBuffer("idsubcuenta", qryLineasDrop.value("lineasalbaranescli.idsubcuenta"));
				}
			} else {
				var codEjercicio = AQUtil.sqlSelect("facturascli", "codejercicio", "idfactura = " + curLineasFact.valueBuffer("idfactura"));
				codSubcuenta = formRecordlineaspedidoscli.iface.pub_dameSubcuentaProducto(curLineasFact);
				if (codSubcuenta) {
					curLineasFact.setValueBuffer("codsubcuenta", codSubcuenta);
					var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
					if (idSubcuenta) {
						curLineasFact.setValueBuffer("idsubcuenta", idSubcuenta);
					}
				}
			}
			if (!codSubcuenta || codSubcuenta == "" || codSubcuenta == 0) {
				MessageBox.warning(sys.translate("Error a facturar la l�nea %1. No se ha encontrado la subcuenta de ventas asociada al producto, activo o cuenta").arg(numLineea), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
			}			
		}		
		var codArancelario =  qryLineasDrop.value("lineasalbaranescli.codarancelario")
		if (!codArancelario || codArancelario == "") {
			codArancelario = AQUtil.sqlSelect("articulos", "codarancelario", "referencia = '" + qryLineasDrop.value("lineasalbaranescli.referencia") + "'");
		}
		curLineasFact.setValueBuffer("codarancelario", codArancelario);
		curLineasFact.setValueBuffer("tipoconcepto", qryLineasDrop.value("lineasalbaranescli.tipoconcepto"));
		curLineasFact.setValueBuffer("texto", qryLineasDrop.value("lineasalbaranescli.texto"));
		curLineasFact.setValueBuffer("codamortizacion", qryLineasDrop.value("lineasalbaranescli.codamortizacion"));
		curLineasFact.setValueBuffer("refcliente", qryLineasDrop.value("lineasalbaranescli.refcliente"));
		curLineasFact.setValueBuffer("codtamanoem", qryLineasDrop.value("lineasalbaranescli.codtamanoem"));
		curLineasFact.setValueBuffer("codcolorem", qryLineasDrop.value("lineasalbaranescli.codcolorem"));

		if (qryLineasDrop.value("lineasalbaranescli.tipoconcepto") == "Producto") {	
			//para dropshipping siempre vamos a recalcular			
			var oParamLin = new Object;
			oParamLin.cursor = curLineasFact;
			oParamLin.ignorarAvisos = true;
			oParamLin.forzarReg = false;
			oParamLin.ignorarCalculoInsert = false; 			
			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",qryLineasDrop.value("albaranescli.codcliente"));	
			formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);	
		}


		if (!curLineasFact.commitBuffer()) {
	  		return false;
		}
		numLinea++;
	}
	return true;

}
	
function euromoda_groupByAgrupacion(cursor)
{
	var _i = this.iface;
	var groupBy = _i.__groupByAgrupacion(cursor);
	var optFechaValor = cursor.valueBuffer("em_optfechavalor");
	if(optFechaValor == "Agrupar por fecha valor") {
		groupBy +=",fechavalor";
	}
	return groupBy;
}
	
function euromoda_selectAgrupacion(cursor)
{
	var _i = this.iface;
	var sSelect = _i.__selectAgrupacion(cursor);
	var optFechaValor = cursor.valueBuffer("em_optfechavalor");
	if(optFechaValor == "Agrupar por fecha valor") {
		sSelect +=",fechavalor";
	}
	return sSelect;
}

	
	
function euromoda_dameDatosAgrupacionPedidos(curAgruparPedidos)
{
	var _i = this.iface;
	var res = _i.__dameDatosAgrupacionPedidos(curAgruparPedidos);
	if (!res) {
		return false;
	}	
	res["optFechaValor"] = curAgruparPedidos.valueBuffer("em_optfechavalor");
	return res;
}	

function euromoda_masWhereAlbaran(qryAgruparPedidos, curAgruparPedidos)
{
	var _i = this.iface;
	var where = _i.__masWhereAlbaran(qryAgruparPedidos);

	var optFechaValor = curAgruparPedidos.valueBuffer("em_optfechavalor");
	
	if(optFechaValor == "Agrupar por fecha valor") {
		var fechaValor = qryAgruparPedidos.value("fechavalor");
		if(!fechaValor || fechaValor == "") {
			where += " AND fechavalor is null";
		}  else {
			where += " AND fechavalor = '" + fechaValor + "'";
		}
	}
	return where;
}

function euromoda_distribuyeEjercicio(cursor)
{
	var _i = this.iface;
	
	if(!_i.__distribuyeEjercicio(cursor)) {
		return false;
	}
	formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",cursor.valueBuffer("codcliente"));
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("albaranescli",cursor.valueBuffer("codcliente"));

	var idAlbaran = cursor.valueBuffer("idalbaran");
	cursor.select("idalbaran = " + idAlbaran);
	if (!cursor.first()) {
		return; 
	}
	cursor.setModeAccess(cursor.Edit);
    cursor.refreshBuffer();
	if(!formRecordpresupuestoscli.iface.evaluarCostesCab(cursor)) { 
		return false;
	}
	if(!cursor.commitBuffer()) {
		return false;
	}
	return true;
}

function euromoda_tbnExportarCan_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(!_i.exportarCanCSV(cursor)){
		return false;
	}
	return true;

}

function euromoda_exportarCanCSV(cursor)
{
	var _i = this.iface;
	var tipoFichero = "Cantidades_Articulos";
	var curO = _i.datosFicheroExportar(tipoFichero, cursor);	
	if(!curO) {
		return false;
	}	
	var separador = curO.valueBuffer("separador");
	if(separador == "Espacio") {
		separador = " ";
	} else if(separador == "Tabulador")  {
		separador = "\t";
	}
	var idAlbaran = cursor.valueBuffer("idalbaran");
	var codificacion = curO.valueBuffer("codificacion"); 
	var codAlbaran = cursor.valueBuffer("codigo"); 

	var ruta = FileDialog.getExistingDirectory(sys.translate(""), sys.translate("Ruta para guardar el fichero"));
	if(!ruta || ruta == "" || ruta == "undefined") {
		formUI.ponMsgWarn(sys.translate("Debe seleccionar una ruta v�lida. Se cancela el proceso."));
		return false;
	}

	if (AQUtil.getOS() == "WIN32" && ruta.right(1) != "/") {
		ruta += "/";
	}

	var nombreFichero = ruta + curO.valueBuffer("nombrefichero");

	var fichero = new File(nombreFichero);
	fichero.open(File.WriteOnly);	

	if(curO.valueBuffer("expcabecera")) {
		var cabecera = _i.dameCabecera(tipoFichero, separador, codificacion);
		fichero.writeLine(cabecera);		
	}
	var linea;
	var q = new AQSqlQuery;	
	q.setSelect("l.referencia, a.codbarras,a.em_costeprod,l.cantidad");
	q.setFrom("lineasalbaranescli l INNER JOIN articulos a ON l.referencia = a.referencia");
	q.setWhere("l.idalbaran = " + idAlbaran + " ORDER BY numlinea"); 				
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		linea = "";
		linea = codAlbaran;
		linea += separador;
		linea += q.value("a.codbarras");
		linea += separador;
		linea += _i.formateaImporte(q.value("a.em_costeprod"), curO);
		linea += separador;
		linea += _i.formateaCantidad(parseFloat(q.value("l.cantidad")), curO);
		linea = linea.replace("\n","");

		/*if(codificacion == "UTF8") {
			linea = AQUtil.utf8(linea);
		} else {
			linea = sys.toUnicode(linea, "UTF-8");			
		}*/
		if(codificacion == "UTF8") {
			linea = sys.fromUnicode(linea, "utf8");		
		} else {
			linea = sys.fromUnicode(linea, "ISO-8859-1");
		}	


		fichero.writeLine(linea);
	}	

	fichero.close();
	formUI.ponMsgInfo(sys.translate("Fichero %1 generado correctamente").arg(fichero.name));	
	return true;
}

function euromoda_tbnExportarDatos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(!_i.exportarDatosCSV(cursor, false)){
		return false;
	}
	return true;

}

function euromoda_exportarDatosCSVooo(cursor)
{
	var _i = this.iface;
	var tipoFichero = "Maestro_Articulos";
	var curO = _i.datosFicheroExportar(tipoFichero, cursor);	
	if(!curO) {
		return false;
	}	
	var separador = curO.valueBuffer("separador");
	if(separador == "Espacio") {
		separador = " ";
	} else if(separador == "Tabulador")  {
		separador = "\t";
	}
	var idAlbaran = cursor.valueBuffer("idalbaran");
	var codificacion = curO.valueBuffer("codificacion");

	var ruta = FileDialog.getExistingDirectory(sys.translate(""), sys.translate("Ruta para guardar el fichero"));
	if(!ruta || ruta == "" || ruta == "undefined") {
		formUI.ponMsgWarn(sys.translate("Debe seleccionar una ruta v�lida. Se cancela el proceso."));
		return false;
	}

	if (AQUtil.getOS() == "WIN32" && ruta.right(1) != "/") {
		ruta += "/";
	}

	var nombreFichero = ruta + curO.valueBuffer("nombrefichero");

	var fichero = new File(nombreFichero);
	fichero.open(File.WriteOnly);	

	if(curO.valueBuffer("expcabecera")) {
		var cabecera = _i.dameCabecera(tipoFichero, separador, codificacion);
		fichero.writeLine(cabecera);		
	}
	var linea;
	var descripcion = "";
	var codTamano = "";
	var codColor = "";
	var codColeccion = "";
	var descColeccion = "";
	var codFamilia = "";
	var descFamilia = "";
	var codSubfamilia = "";	
	var descSubfamilia = "";
	var dibujo = "";

	var q = new AQSqlQuery;	
	q.setSelect("a.codcoleccionem,c.descripcion, a.codbarras, a.descripcion, a.codtamanoem, a.codcolorem, a.em_costeprod, a.referencia, a.codfamilia, f.descripcion, a.codsubfamilia, s.descripcion, a.emdibujo");
	q.setFrom("lineasalbaranescli l INNER JOIN articulos a ON l.referencia = a.referencia LEFT OUTER JOIN em_colecciones c ON c.codcoleccionem = a.codcoleccionem INNER JOIN familias f ON f.codfamilia = a.codfamilia INNER JOIN subfamilias s ON s.codsubfamilia = a.codsubfamilia");
	q.setWhere("l.idalbaran = " + idAlbaran + " ORDER BY numlinea"); 				
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		linea = "";
		codColeccion = q.value("a.codcoleccionem");
		descColeccion = q.value("c.descripcion"); 
		linea = codColeccion + " - " + descColeccion;
		linea += separador;
		linea += q.value("a.codbarras");
		linea += separador;
		descripcion = q.value("a.descripcion");
		codTamano = q.value("a.codtamanoem");
		if(!codTamano) {
			codTamano = "";
		}
		codColor = q.value("a.codcolorem");
		if(!codColor) {
			codColor = "";
		}
		descripcion = descripcion + " - " + codTamano + " - " + codColor; 
		linea += descripcion;
		linea += separador;		
		linea += _i.formateaImporte(q.value("a.em_costeprod"), curO);
		linea += separador;
		linea += q.value("a.referencia");	
		linea += separador;
		codFamilia = q.value("a.codfamilia");
		if(!codFamilia) {
			codFamilia = "";
		}
		descFamilia = q.value("f.descripcion");
		if(!descFamilia) {
			descFamilia = "";
		}
		codFamilia = codFamilia + " - " + descFamilia;
		linea += codFamilia;
		linea += separador;
		codSubfamilia = q.value("a.codsubfamilia");
		if(!codSubfamilia) {
			codSubfamilia = "";
		}
		descSubfamilia = q.value("s.descripcion");
		if(!descSubfamilia) {
			descSubfamilia = "";
		}
		codSubfamilia = codSubfamilia + " - " + descSubfamilia;
		linea += codSubfamilia;
		linea += separador;
		dibujo = q.value("a.emdibujo");
		if(!dibujo) {
			dibujo = "";
		}
		linea += dibujo;
		linea += separador;
		linea += codTamano;
		linea += separador;
		linea += codColor;
		linea = linea.replace("\n","");

		/*if(codificacion == "UTF8") {
			linea = AQUtil.utf8(linea);
		} else {
			linea = sys.toUnicode(linea, "UTF-8");			
		}		*/

		if(codificacion == "UTF8") {
			linea = sys.fromUnicode(linea, "utf8");		
		} else {
			linea = sys.fromUnicode(linea, "ISO-8859-1");
		}		
		fichero.writeLine(linea);

	}

	fichero.close();
	formUI.ponMsgInfo(sys.translate("Fichero %1 generado correctamente").arg(fichero.name));	
	return true;


}

function euromoda_exportarDatosCSV(cursor, filtro)
{
	var _i = this.iface;
	var tipoFichero = "Maestro_Articulos";
	var curO = _i.datosFicheroExportar(tipoFichero, cursor);	
	if(!curO) {
		return false;
	}	
	var separador = curO.valueBuffer("separador");
	if(separador == "Espacio") {
		separador = " ";
	} else if(separador == "Tabulador")  {
		separador = "\t";
	}
	//var idAlbaran = cursor.valueBuffer("idalbaran");
	var codificacion = curO.valueBuffer("codificacion");

	var ruta = FileDialog.getExistingDirectory(sys.translate(""), sys.translate("Ruta para guardar el fichero"));
	if(!ruta || ruta == "" || ruta == "undefined") {
		formUI.ponMsgWarn(sys.translate("Debe seleccionar una ruta v�lida. Se cancela el proceso."));
		return false;
	}

	if (AQUtil.getOS() == "WIN32" && ruta.right(1) != "/") {
		ruta += "/";
	}

	var nombreFichero = ruta + curO.valueBuffer("nombrefichero");

	var fichero = new File(nombreFichero);
	fichero.open(File.WriteOnly);	

	if(curO.valueBuffer("expcabecera")) {
		var cabecera = _i.dameCabecera(tipoFichero, separador, codificacion);
		fichero.writeLine(cabecera);		
	}
	var linea;
	var descripcion = "";
	var codTamano = "";
	var codColor = "";
	var codColeccion = "";
	var descColeccion = "";
	var codFamilia = "";
	var descFamilia = "";
	var codSubfamilia = "";	
	var descSubfamilia = "";
	var dibujo = "";

	var q = new AQSqlQuery;	
	q.setSelect(_i.dameSelectExportDatos(cursor));
	q.setFrom(_i.dameFromExporDatos(cursor));
	q.setWhere(_i.dameWhereExporDatos(cursor, filtro)); 				
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		linea = "";
		codColeccion = q.value(0);
		descColeccion = q.value(1); 
		linea = codColeccion + " - " + descColeccion;
		linea += separador;
		linea += q.value(2);
		linea += separador;
		descripcion = q.value(3);
		codTamano = q.value(4);
		if(!codTamano) {
			codTamano = "";
		}
		codColor = q.value(5);
		if(!codColor) {
			codColor = "";
		}
		descripcion = descripcion + " - " + codTamano + " - " + codColor; 
		linea += descripcion;
		linea += separador;		
		linea += _i.formateaImporte(q.value(6), curO);
		linea += separador;
		linea += q.value(7);	
		linea += separador;
		codFamilia = q.value(8);
		if(!codFamilia) {
			codFamilia = "";
		}
		descFamilia = q.value(9);
		if(!descFamilia) {
			descFamilia = "";
		}
		codFamilia = codFamilia + " - " + descFamilia;
		linea += codFamilia;
		linea += separador;
		codSubfamilia = q.value(10);
		if(!codSubfamilia) {
			codSubfamilia = "";
		}
		descSubfamilia = q.value(11);
		if(!descSubfamilia) {
			descSubfamilia = "";
		}
		codSubfamilia = codSubfamilia + " - " + descSubfamilia;
		linea += codSubfamilia;
		linea += separador;
		dibujo = q.value(12);
		if(!dibujo) {
			dibujo = "";
		}
		linea += dibujo;
		linea += separador;
		linea += codTamano;
		linea += separador;
		linea += codColor;
		linea = linea.replace("\n","");

		/*if(codificacion == "UTF8") {
			linea = AQUtil.utf8(linea);
		} else {
			linea = sys.toUnicode(linea, "UTF-8");			
		}		*/

		if(codificacion == "UTF8") {
			linea = sys.fromUnicode(linea, "utf8");		
		} else {
			linea = sys.fromUnicode(linea, "ISO-8859-1");
		}		
		fichero.writeLine(linea);

	}

	fichero.close();
	formUI.ponMsgInfo(sys.translate("Fichero %1 generado correctamente").arg(fichero.name));	
	return true;
}

function euromoda_datosFicheroExportar(tipoFichero, cursor)
{
	var _i = this.iface;



	var codCliente = "";
	var codProveedor = "";
	var documento = "";
	var codificacion = "ANSI";
	var separador = ";";
	var simboloDecimal = ".";
	var expCabecera = true;
	var impDecimales = true;
	var numDecimalesImp = 2;
	var cantSinDecimales = true;
	var conMillares = false;
	var nombreFichero = "";

	var f = new FLFormSearchDB("em_datosfichexpcli");
  	var curO = f.cursor();
  	curO.setModeAccess(curO.Insert);
  	curO.refreshBuffer();


  	if(cursor.action() != "v_stocksext") {	
		if(tipoFichero == "Cantidades_Articulos" || tipoFichero == "Maestro_Articulos") {
			codCliente = cursor.valueBuffer("codcliente");
		 	documento = cursor.valueBuffer("codigo");
			var fecha = cursor.valueBuffer("fecha");

			var q = new AQSqlQuery;	
			q.setSelect("codificacion,separador,simbolodecimal,expcabecera,impdecimales,numdecimalesimp,cantsindecimales,conmillares");
			q.setFrom("em_ficherosexpcli");
			q.setWhere("codcliente = '" + codCliente + "' and tipofichero = '" + tipoFichero + "'"); 				
			if (!q.exec()){
				return;
			}  
			if(q.first())
			{
		
				codificacion = q.value("codificacion");
				separador = q.value("separador");
				simboloDecimal = q.value("simbolodecimal");
				expCabecera = q.value("expcabecera");
				impDecimales = q.value("impdecimales");
				numDecimalesImp = q.value("numdecimalesimp");
				cantSinDecimales = q.value("cantsindecimales");
				conMillares = q.value("conmillares");			
			}					
		} else if(tipoFichero == "Orden_Distribucion_A_Euromoda") {
			codProveedor = cursor.valueBuffer("codproveedor");
		 	documento = cursor.valueBuffer("codigo");
			var fecha = cursor.valueBuffer("fecha");

			var q = new AQSqlQuery;	
			q.setSelect("codificacion,separador,simbolodecimal,expcabecera,impdecimales,numdecimalesimp,cantsindecimales,conmillares");
			q.setFrom("em_ficherosexpprov");
			q.setWhere("codproveedor = '" + codProveedor + "' and tipofichero = '" + tipoFichero + "'"); 				
			if (!q.exec()){
				return;
			}  
			if(q.first())
			{
		
				codificacion = q.value("codificacion");
				separador = q.value("separador");
				simboloDecimal = q.value("simbolodecimal");
				expCabecera = q.value("expcabecera");
				impDecimales = q.value("impdecimales");
				numDecimalesImp = q.value("numdecimalesimp");
				cantSinDecimales = q.value("cantsindecimales");
				conMillares = q.value("conmillares");			
			}	
		}
	}
	nombreFichero = _i.dameNombreFichero(tipoFichero, cursor);
	curO.setValueBuffer("tipofichero",tipoFichero);
  	curO.setValueBuffer("codcliente",codCliente);
  	curO.setValueBuffer("codproveedor",codProveedor);
  	curO.setValueBuffer("documento",documento);
  	curO.setValueBuffer("codificacion",codificacion);
  	curO.setValueBuffer("separador",separador);
  	curO.setValueBuffer("simbolodecimal",simboloDecimal);
  	curO.setValueBuffer("expcabecera",expCabecera);
  	curO.setValueBuffer("impdecimales",impDecimales);
  	curO.setValueBuffer("numdecimalesimp",numDecimalesImp);
  	curO.setValueBuffer("cantsindecimales",cantSinDecimales);
  	curO.setValueBuffer("conmillares",conMillares);
  	curO.setValueBuffer("nombrefichero",nombreFichero);

  	f.setMainWidget();
   	f.exec();
  	if (!f.accepted()) {   		
        return false;
    }
    return curO;
}

function euromoda_dameNombreFichero(tipoFichero, cursor)
{
	var hoy = new Date();
	var hora = hoy.toString().right(8);
	var nombreFichero = "";
	if(tipoFichero == "Cantidades_Articulos") {
		var codigo = cursor.valueBuffer("codigo");
		nombreFichero = codigo + "_" + formSTR.reemplazar(hoy.toString().left(10),"-","") + "_" + formSTR.reemplazar(hora,":","") + "_cantidades.csv";

	} else if(tipoFichero == "Maestro_Articulos") {
		var codigo = cursor.valueBuffer("codigo");
		if(codigo && codigo != "" && codigo != "undefined") {
			nombreFichero = nombreFichero + codigo + "_";
		}
		nombreFichero = nombreFichero + formSTR.reemplazar(hoy.toString().left(10),"-","") + "_" + formSTR.reemplazar(hora,":","") + "_articulos.csv";

	} else if(tipoFichero == "Orden_Distribucion_A_Euromoda") {
		var codigo = cursor.valueBuffer("codigo");
		nombreFichero = codigo + "_" + formSTR.reemplazar(hoy.toString().left(10),"-","") + "_" + formSTR.reemplazar(hora,":","") + ".csv";
	}
	return nombreFichero;
}

function euromoda_dameCabecera(tipoFichero, separador, codificacion)
{
	var cabecera = "";
	if(tipoFichero == "Cantidades_Articulos") {
		cabecera = "Referencia Entrada" + separador + "EAN"+ separador + "Valor Unitario" + separador + "Unidades";
	} else 	if(tipoFichero == "Maestro_Articulos") {
		cabecera = "Marca" + separador + "EAN"+ separador + "Descripci�n del art�culo" + separador + "Valor Unitario"+ separador + "Referencia"+ separador + "Familia"+ separador + "Subfamilia"+ separador + "Dise�o"+ separador + "Tama�o"+ separador + "Color";
	} else if(tipoFichero == "Orden_Distribucion_A_Euromoda") {
		cabecera = "Pedido" + separador + "Referencia Destinatario" + separador + "C�digo Cliente" + separador + "Nombre Destinatario" + separador + "Direcci�n Destinatario" + separador + "C.P. Destinatario" + separador + "Poblaci�n Destinatario" + separador + "Provincia" + separador + "Pa�s" + separador + "Tel�fono" + separador + "Email" + separador + "EAN" + separador + "Descripci�n" + separador + "Fecha Servicio" + separador + "Unidades" + separador + "Observaciones" + separador + "Valor Mercanc�a";
	}

	if(codificacion == "UTF8") {
		cabecera = sys.fromUnicode(cabecera, "utf8");		
	} else {
		cabecera = sys.fromUnicode(cabecera, "ISO-8859-1");
	}	
	return cabecera;
}

function euromoda_formateaImporte(importe, curO)
{
	var _i = this.iface;
	var valor = importe;
	var impDecimales = curO.valueBuffer("impdecimales");
	var numDecimalesImp = curO.valueBuffer("numdecimalesimp");
	if(impDecimales) {
		if(!numDecimalesImp || numDecimalesImp == "") {
			numDecimalesImp = 0;
		}
		valor = formUTIL.redondeaDecimales(importe, numDecimalesImp);
		valor = _i.trataSimboloDecimal(valor, curO);
	} else {
		var aValor = importe.toString().split(".");
		valor = parseInt(aValor[0]);
	}
	valor = _i.trataMillares(valor, curO)
	return valor;
}

function euromoda_formateaCantidad(cantidad, curO)
{
	var _i = this.iface;
	var valor = cantidad;
	var sinDecimales = curO.valueBuffer("cantsindecimales");
	var numDecimalesImp = curO.valueBuffer("numdecimalesimp");
	if(sinDecimales) {		
		var aValor = cantidad.toString().split(".");
		valor = parseInt(aValor[0]);
	} else {
		if(numDecimalesImp && numDecimalesImp != "") {
			valor = formUTIL.redondeaDecimales(cantidad, numDecimalesImp);			 
		}		
		valor = _i.trataSimboloDecimal(valor, curO);
	}
	valor = _i.trataMillares(valor, curO);
	return valor;
}

function euromoda_trataSimboloDecimal(valor, curO)
{

	var numDecimalesImp = curO.valueBuffer("numdecimalesimp");
	var aValor = valor.toString().split(".");
	var numCeros = 0;
	if(aValor.length == 1) {
		valor = valor.toString();
		valor = valor + ".";
		numCeros = numDecimalesImp;
	} else {
		numCeros = numDecimalesImp - aValor[1].length;
		if(numCeros < 0) {
			valor = aValor[0] +".";
			for(var i=0;i<numDecimalesImp;i++) {
				valor += aValor[1].charAt(i);
			}
		}
	}
	if(numCeros > 0) {	
		for(i=0;i<numCeros;i++) {
			valor = valor + "0";
		}	
	}	
	return valor;
}

function euromoda_trataMillares(valor, curO)
{
	var conMillares = curO.valueBuffer("conmillares"); 
	var simboloDecimal = curO.valueBuffer("simbolodecimal");
	var conMillares = curO.valueBuffer("conmillares"); 
	var simboloMiles;
	if(simboloDecimal == ",") {
		simboloMiles = ".";
	} else {
		simboloMiles = ",";
	}
	if(conMillares) {			
		valor = AQUtil.formatoMiles(valor);
		if(simboloDecimal == ".") {
			valor = formSTR.reemplazoAXB(valor.toString(), simboloDecimal, simboloMiles);
		} 
	} else {
		if(simboloDecimal == ",") {
			valor = formSTR.reemplazoAXB(valor.toString(), simboloDecimal, simboloMiles);
		} 
	}
	return valor;

}

function euromoda_dameSelectExportDatos(cursor)
{
	var sSelect = "";
	if(cursor.table() == "albaranescli" || cursor.table() == "pedidoscli") {
		sSelect = "a.codcoleccionem,c.descripcion, a.codbarras, a.descripcion, a.codtamanoem, a.codcolorem, a.em_costeprod, a.referencia, a.codfamilia, f.descripcion, a.codsubfamilia, s.descripcion, a.emdibujo";
	} else if(cursor.table() == "v_stocksext") {
		sSelect = "v_stocksext.codcoleccionem, v_stocksext.desccol, v_stocksext.codbarras, v_stocksext.articulo, v_stocksext.codtamanoem, v_stocksext.codcolorem, v_stocksext.em_costeprod, v_stocksext.referencia, v_stocksext.codfamilia, v_stocksext.descfam, v_stocksext.codsubfamilia, v_stocksext.descsubfam, v_stocksext.emdibujo"
	}
	return sSelect;
	
}

function euromoda_dameFromExporDatos(cursor)
{
	var sFrom = "";
	if(cursor.table() == "albaranescli") {
		sFrom = "lineasalbaranescli l INNER JOIN articulos a ON l.referencia = a.referencia LEFT OUTER JOIN em_colecciones c ON c.codcoleccionem = a.codcoleccionem INNER JOIN familias f ON f.codfamilia = a.codfamilia INNER JOIN subfamilias s ON s.codsubfamilia = a.codsubfamilia";
	} else if(cursor.table() == "pedidoscli") {
		sFrom = "lineaspedidoscli l INNER JOIN articulos a ON l.referencia = a.referencia LEFT OUTER JOIN em_colecciones c ON c.codcoleccionem = a.codcoleccionem INNER JOIN familias f ON f.codfamilia = a.codfamilia INNER JOIN subfamilias s ON s.codsubfamilia = a.codsubfamilia";
	} else if(cursor.table() == "v_stocksext") {
		sFrom = "v_stocksext";
	}
	return sFrom;
		
}

function euromoda_dameWhereExporDatos(cursor, filtro)
{
	var sWhere = "";
	if(cursor.table() == "albaranescli") {
		sWhere = "l.idalbaran = " + cursor.valueBuffer("idalbaran") + " ORDER BY numlinea";
	} else if(cursor.table() == "pedidoscli") {
		sWhere = "l.idpedido = " + cursor.valueBuffer("idpedido") + " ORDER BY numlinea";
	} else if(cursor.table() == "v_stocksext") {
		debug("Main filter: " +cursor.mainFilter());
		if(filtro && filtro != "" && filtro != "undefined") {
			sWhere = filtro;
		} else {
			sWhere = cursor.mainFilter();	
		}		
	}
	if(!sWhere || sWhere == "") {
		sWhere = "1=1";
	}

	return sWhere;
		
}

function euromoda_exportarDatosDistCSV(cursor, filtro)
{
	var _i = this.iface;
	var tipoFichero = "Orden_Distribucion_A_Euromoda";
	var curO = _i.datosFicheroExportar(tipoFichero, cursor);	
	if(!curO) {
		return false;
	}	
	var separador = curO.valueBuffer("separador");
	if(separador == "Espacio") {
		separador = " ";
	} else if(separador == "Tabulador")  {
		separador = "\t";
	}
	var codificacion = curO.valueBuffer("codificacion");

	var ruta = FileDialog.getExistingDirectory(sys.translate(""), sys.translate("Ruta para guardar el fichero"));
	if(!ruta || ruta == "" || ruta == "undefined") {
		formUI.ponMsgWarn(sys.translate("Debe seleccionar una ruta v�lida. Se cancela el proceso."));
		return false;
	}

	if (AQUtil.getOS() == "WIN32" && ruta.right(1) != "/") {
		ruta += "/";
	}

	var nombreFichero = ruta + curO.valueBuffer("nombrefichero");

	var fichero = new File(nombreFichero);
	fichero.open(File.WriteOnly);	

	if(curO.valueBuffer("expcabecera")) {
		var cabecera = _i.dameCabecera(tipoFichero, separador, codificacion);
		fichero.writeLine(cabecera);		
	}

	var linea;
	var codigo = "";
	var numProveedor = "";
	var codProveedor = "";
	var nombreAlm = "";
	var empresaAlm = "";
	var dirAlm = "";
	var codPostalAlm = "";
	var poblacionAlm = "";	
	var provinciaAlm = "";
	var codPaisAlm = "";
	var telefonoAlm = "";
	var emailEmp = "";
	var EAN = "";
	var descripcion = "";
	var fechaEntrada = "";
	var cantidad = "";
	var observaciones = "";
	var codAlmacen = "";
	var referencia = "";
	var numLinea = 0;

	var valorMercancia = AQUtil.sqlSelect("lineaspedidosprov l INNER JOIN articulos a ON l.referencia = a.referencia","SUM(a.em_costeprod*l.cantidad)","l.idpedido = " + cursor.valueBuffer("idpedido"),"lineaspedidosprov");

	debug("idpedido: "+cursor.valueBuffer("idpedido"));
	if(!valorMercancia || valorMercancia == "") {
		valorMercancia = "";
	} else {
		valorMercancia = _i.formateaImporte(valorMercancia, curO);
	}

	var q = new AQSqlQuery;	
	q.setSelect(_i.dameSelectExportDatosDist(cursor));
	q.setFrom(_i.dameFromExporDatosDist(cursor));
	q.setWhere(_i.dameWhereExporDatosDist(cursor, filtro)); 				
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		codigo = q.value(0);
		numProveedor = q.value(1); 
		if(!numProveedor || numProveedor == "") {
			numProveedor = "";
		}

		codProveedor = q.value(2);
		if(!codProveedor || codProveedor == "") {
			codProveedor = "";
		}
		codAlmacen = q.value(3);
		nombreAlm = q.value(4);
		if(!nombreAlm || nombreAlm == "") {
			formUI.ponMsgWarn(sys.translate("El nombre del almacen destino %1 es un dato obligatorio.\nSe cancela la importaci�n.").arg(codAlmacen));
			return false;
		}
		empresaAlm = q.value(5);
		if(!empresaAlm || empresaAlm == "") {
			formUI.ponMsgWarn(sys.translate("La empresa del almacen destino %1 es un dato obligatorio.\nSe cancela la importaci�n.").arg(codAlmacen));
			return false;
		}
		dirAlm = q.value(6);
		if(!dirAlm || dirAlm == "") {
			formUI.ponMsgWarn(sys.translate("La direcci�n del almacen destino %1 es un dato obligatorio.\nSe cancela la importaci�n.").arg(codAlmacen));
			return false;
		}
		codPostalAlm = q.value(7);
		if(!codPostalAlm || codPostalAlm == "") {
			formUI.ponMsgWarn(sys.translate("El c�digo postal del almacen destino %1 es un dato obligatorio.\nSe cancela la importaci�n.").arg(codAlmacen));
			return false;
		}
		poblacionAlm = q.value(8);				
		if(!poblacionAlm || poblacionAlm == "") {
			formUI.ponMsgWarn(sys.translate("La poblaci�n del almacen destino %1 es un dato obligatorio.\nSe cancela la importaci�n.").arg(codAlmacen));
			return false;
		}
		provinciaAlm = q.value(9);				
		if(!provinciaAlm || provinciaAlm == "") {
			formUI.ponMsgWarn(sys.translate("La provinciaAlm del almacen destino %1 es un dato obligatorio.\nSe cancela la importaci�n.").arg(codAlmacen));
			return false;
		}
		codPaisAlm = q.value(10);
		if(!codPaisAlm || codPaisAlm == "") {
			formUI.ponMsgWarn(sys.translate("El pa�s del almacen destino %1 es un dato obligatorio.\nSe cancela la importaci�n.").arg(codAlmacen));
			return false;
		}
		telefonoAlm = q.value(11);
		if(!telefonoAlm || telefonoAlm == "") {
			telefonoAlm = "";
		}
		emailEmp = q.value(12); 
		if(!emailEmp || emailEmp == "") {
			emailEmp = "";
		}
		numLinea = q.value(18);
		referencia = q.value(13); 
		EAN = q.value(14);
		if(!EAN || EAN == "") {
			formUI.ponMsgWarn(sys.translate("L�nea del pedido %1, el c�digo de barras de la referencia %2 es un dato obligatorio.\nSe cancela la importaci�n.").arg(numLinea).arg(referencia));
			return false;
		}
		descripcion = q.value(15); 
		if(!descripcion || descripcion == "") {
			descripcion = "";
		}
		fechaEntrada = q.value(16); 
		if(!fechaEntrada || fechaEntrada == "") {
			fechaEntrada = "";
		} else {
			fechaEntrada =  AQUtil.dateAMDtoDMA(fechaEntrada.toString());
			fechaEntrada = formSTR.reemplazar(fechaEntrada,"-","/")
		}
		cantidad = _i.formateaCantidad(parseFloat(q.value(17)), curO);
		observaciones = q.value(19); 
		if(!observaciones || observaciones == "") {
			observaciones = "";
		}
		observaciones = formSTR.reemplazar(observaciones,"\n"," ");
		observaciones = formSTR.reemplazar(observaciones,"\r"," ");

		linea = "";
		linea += codigo;
		linea += separador;	 
		linea += numProveedor;
		linea += separador;
		linea += codProveedor;
		linea += separador;
		linea += nombreAlm + "-" + empresaAlm;
		linea += separador;
		linea += dirAlm;
		linea += separador;
		linea += codPostalAlm;
		linea += separador;
		linea += poblacionAlm;
		linea += separador;
		linea += provinciaAlm;
		linea += separador;
		linea += codPaisAlm;
		linea += separador;
		linea += telefonoAlm;
		linea += separador;
		linea += emailEmp;
		linea += separador;
		linea += EAN;
		linea += separador;
		linea += descripcion;
		linea += separador;
		linea += fechaEntrada;
		linea += separador;
		linea += cantidad;
		linea += separador;
		linea += observaciones;
		linea += separador;
		linea += valorMercancia;
		linea = linea.replace("\n","");

		if(codificacion == "UTF8") {
			linea = sys.fromUnicode(linea, "utf8");		
		} else {
			linea = sys.fromUnicode(linea, "ISO-8859-1");
		}		
		fichero.writeLine(linea);
	}

	fichero.close();
	formUI.ponMsgInfo(sys.translate("Fichero %1 generado correctamente").arg(fichero.name));	
	return true;
}


function euromoda_dameSelectExportDatosDist(cursor)
{
	var sSelect = "";
	if(cursor.table() == "pedidosprov") {
		sSelect = "p.codigo, p.numproveedor, p.codproveedor, p.codalmacen, al.nombre, al.empresa, al.direccion, al.codpostal, al.poblacion, al.provincia, al.codpais, al.telefono, e.email, l.referencia, a.codbarras, l.descripcion, p.fechaentrada, l.cantidad, l.numlinea, regexp_replace(p.observaciones, '\r\n', '','g')";
	}
	return sSelect;
	
}

function euromoda_dameFromExporDatosDist(cursor)
{
	var sFrom = "";
	if(cursor.table() == "pedidosprov") {
		sFrom = "pedidosprov p INNER JOIN lineaspedidosprov l ON l.idpedido = p.idpedido INNER JOIN almacenes al ON al.codalmacen = p.codalmacen INNER JOIN articulos a ON a.referencia = l.referencia INNER JOIN ejercicios ej ON p.codejercicio = ej.codejercicio INNER JOIN empresa e ON e.id = ej.idempresa";
	} 
	return sFrom;		
}

function euromoda_dameWhereExporDatosDist(cursor, filtro)
{
	var sWhere = "";
	if(cursor.table() == "pedidosprov") {
		sWhere = "l.idpedido = " + cursor.valueBuffer("idpedido") + " ORDER BY numlinea";
	}
	return sWhere;		
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
