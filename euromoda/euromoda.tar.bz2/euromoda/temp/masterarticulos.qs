
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	var curEmAcabadosArt_;
	function euromoda( context ) { prod ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
  function tbnCrearPlantilla_clicked() {
    return this.ctx.euromoda_tbnCrearPlantilla_clicked();
  }
  function crearPlantilla(oParam) {
    return this.ctx.euromoda_crearPlantilla(oParam);
  }
  function tbnFiltroFamilia_clicked() {
		return this.ctx.euromoda_tbnFiltroFamilia_clicked();
	}
	function tbnQuitarFiltro_clicked() {
		return this.ctx.euromoda_tbnQuitarFiltro_clicked();
	}
	function filtroTodos() {
		return this.ctx.euromoda_filtroTodos();
	}
	function ordenaCols() {
		return this.ctx.euromoda_ordenaCols();
	}
	function controlBusqueda() {
		return this.ctx.euromoda_controlBusqueda();
	}
	function filtroDefecto() {
		return this.ctx.euromoda_filtroDefecto();
	}
	function preloadMainFilter() {
		return this.ctx.euromoda_preloadMainFilter();
	}
	function copiarAnexosArticulo(refOriginal, refNueva) {
		return this.ctx.euromoda_copiarAnexosArticulo(refOriginal, refNueva);
	}
	function copiarTablaAcabadosArt(refOriginal, nuevaReferencia) {		
		return this.ctx.euromoda_copiarTablaAcabadosArt(refOriginal, nuevaReferencia);
	}
	function datosAcabadosArt(cursorOrigen,campo) {
		return this.ctx.euromoda_datosAcabadosArt(cursorOrigen,campo);
	}
	/*function ordenaColsValMercado() {
		return this.ctx.euromoda_ordenaColsValMercado();
	}
	function dameOrdenColsValMercado() {
		return this.ctx.euromoda_dameOrdenColsValMercado();
	}
	function ocultaBarraBotones() {
		return this.ctx.euromoda_ocultaBarraBotones();
	}*/
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.controlBusqueda();

	_i.__init();
	
	var cursor = this.cursor();
	if (cursor.action() == "em_selarticulosrefcliente") {
		this.child("tableDBRecords").putFirstCol("aliasart");
		this.child("tableDBRecords").refresh();
	} else {
		_i.ordenaCols();
	}
	/*if (cursor.action() == "em_valoresmercadoprin" ) {
		_i.ocultaBarraBotones();
		_i.ordenaColsValMercado();
				
  	}*/
	
  connect(this.child("tbnQuitarFiltro"), "clicked()", this, "iface.tbnQuitarFiltro_clicked");
  connect(this.child("tbnCrearPlantilla"), "clicked()", _i, "tbnCrearPlantilla_clicked");

	_i.tbnQuitarFiltro_clicked();
	
}

function euromoda_controlBusqueda()
{
	var t = this.mainWidget().parentWidget().rtti();
// 	debug("Esto es un " + t);
	if (t != "FormSearchDB") {
		return true;
	}
	sys.runObjMethod(this, "tableDBRecords", "setOnlyTable", true);
// 	this.child("tableDBRecords").setOnlyTable(true);
	if (this.child("barraBotones")) {
		this.child("barraBotones").close();
	}
}

function euromoda_ordenaCols()
{
	var oC;
	var t = this.mainWidget().parentWidget().rtti();
	if (t == "FormSearchDB") {
		oC = ["descripcion", "referencia", "codtamanoem", "emcolorgit", "codcolorem", "coddibestamp", "emdibujo", "pvp"];
	} else {
		oC = ["referencia", "descripcion", "codtamanoem", "emcolorgit", "codcolorem", "coddibestamp", "emdibujo", "pvp"];
	}
	
	var oCAncho = [["emcolorgit", 30]];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tableDBRecords").setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
	this.child("tableDBRecords").setOrderCols(oC);
}

function euromoda_tbnCrearPlantilla_clicked()
{
  var cursor = this.cursor();
  
  /// Validar que el art�culo seleccionado sea un producto
  
  var res = MessageBox.warning(sys.translate("Va a crear una plantilla en base al producto %1 - %2.\n�Est� seguro?").arg(cursor.valueBuffer("referencia")).arg(cursor.valueBuffer("descripcion")), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
  if (res != MessageBox.Yes) {
    return;
  }
  
  var oParam = new Object;
  oParam.errorMsg = sys.translate("Error al generar la plantilla");
  oParam.curArticulo = cursor;
  var f = new Function("oParam", "return formarticulos.iface.crearPlantilla(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  var curP = new FLSqlCursor("em_plantillasprod");
  curP.select("idplantilla = " + oParam.idPlantilla);
  if (!curP.first()) {
    return false;
  }
  curP.editRecord();
}

function euromoda_crearPlantilla(oParam)
{
  var curA = oParam.curArticulo;

	/*06-03-2018 pedir datos antes de copia*/


	var f = new FLFormSearchDB("em_plantillasprodnueva");
	var curP = f.cursor();
  curP.setModeAccess(curP.Insert);
  curP.refreshBuffer();
	curP.setValueBuffer("codcoleccionem",curA.valueBuffer("codcoleccionem"));
  curP.setValueBuffer("codsubfamilia", curA.valueBuffer("codsubfamilia"));
  curP.setValueBuffer("codtamanoem", curA.valueBuffer("codtamanoem"));
	curP.setValueBuffer("codcolorem",curA.valueBuffer("codcolorem"));	

	f.setMainWidget();

	var id = f.exec("idplantilla");
	if(!id){
		return false
	}

	curP.setValueBuffer("desccoleccion", AQUtil.sqlSelect("em_colecciones","descripcion","codcoleccionem = '" + curP.valueBuffer("codcoleccionem") + "'"));
  curP.setValueBuffer("nombre", formRecordem_plantillasprod.iface.pub_commonCalculateField("nombre", curP));

  if (!curP.commitBuffer()) {
    return false;
  }
	debug("id: "+id);
	
	var referencia = curA.valueBuffer("referencia");
	//var curP = new FLSqlCursor("em_plantillasprod");	
	//curP.setModeAccess(curP.Insert);	
	//curP.refreshBuffer();
	
	//curP.setValueBuffer("codsubfamilia", curA.valueBuffer("codsubfamilia")); 
	//curP.setValueBuffer("codtamanoem", curA.valueBuffer("codtamanoem")); 	
	//curP.setValueBuffer("codcolorem", curA.valueBuffer("codcolorem")); 
	//curP.setValueBuffer("codcoleccionem", curA.valueBuffer("codcoleccionem"));
	//curP.setValueBuffer("desccoleccion", AQUtil.sqlSelect("em_colecciones","descripcion","codcoleccionem = '" + curP.valueBuffer("codcoleccionem") + "'"));
	//curP.setValueBuffer("nombre", formRecordem_plantillasprod.iface.pub_commonCalculateField("nombre", curP));
	//if (!curP.commitBuffer()) {
	//	debug("2");
	//	return false;
	//}
  oParam.idPlantilla = curP.valueBuffer("idplantilla");
  
  var q = new FLSqlQuery;
	q.setSelect("ac.em_codcomponente, ac.componente, ac.orden, ac.refcomponente, ac.desccomponente, ac.codtamanoem, ac.codcolorem, ac.cantidad, ac.largo, ac.ancho, ac.alto, ac.piezasancho, ac.factor, ac.reservar, ac.codunidad, ac.idseccion, ac.observaciones, a.codsubfamilia, ac.componormal, ac.anchopiezatej");
  q.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia");
	//q.setWhere("refcompuesto = '" + referencia + "' AND ac.em_codcomponente IS NOT NULL");/// Is not null a�adido para usar plantillas �nicamente como gu�a de tama�os
	q.setWhere("refcompuesto = '" + referencia + "'") //4-12-2017 quito el is not null para #H0903 P0011B Plantillas de Producto
  if (!q.exec()) {
    return false;
  }
  var curL = new FLSqlCursor("em_lineasplantillaprod");
	var reservado;
  while (q.next()) {
		reservado = q.value("ac.reservar");
    curL.setModeAccess(curL.Insert);
    curL.refreshBuffer();
		curL.setValueBuffer("codcoleccionplan", curP.valueBuffer("codcoleccionem"));
		curL.setValueBuffer("codsubfamiliaplan", curP.valueBuffer("codsubfamilia"));
		curL.setValueBuffer("codtamanoplan", curP.valueBuffer("codtamanoem"));
		curL.setValueBuffer("codcolorplan", curP.valueBuffer("codcolorem"));
		curL.setValueBuffer("nombreplan", curP.valueBuffer("nombre"));


		curL.setValueBuffer("tipo", "Fijo");
    curL.setValueBuffer("idplantilla", oParam.idPlantilla);
		if(q.value("ac.em_codcomponente") && q.value("ac.em_codcomponente") != "") {
    curL.setValueBuffer("emcodcomponente", q.value("ac.em_codcomponente"));
		}
		if(q.value("ac.componente") && q.value("ac.componente") != "") {
    curL.setValueBuffer("componente", q.value("ac.componente"));
		}		
    curL.setValueBuffer("orden", q.value("ac.orden"));
		//if (!reservado) {
			curL.setValueBuffer("refcomponente", q.value("ac.refcomponente"));
			curL.setValueBuffer("desccomponente", q.value("ac.desccomponente"));
			curL.setValueBuffer("codsubfamilia", q.value("a.codsubfamilia"));
		//}
		curL.setValueBuffer("codtamanocont", q.value("ac.codtamanoem"));
		curL.setValueBuffer("codtamanopanot", q.value("ac.codtamanoem"));
//     curL.setValueBuffer("codcolorem", AQUtil.sqlSelect("articulos", "codcolorem", "referencia = '" + q.value("ac.refcomponente") + "'"));
    curL.setValueBuffer("cantidad", q.value("ac.cantidad"));
    curL.setValueBuffer("largo", q.value("ac.largo"));
    curL.setValueBuffer("ancho", q.value("ac.ancho"));
    curL.setValueBuffer("alto", q.value("ac.alto"));
    curL.setValueBuffer("piezasancho", q.value("ac.piezasancho"));
    curL.setValueBuffer("factor", q.value("ac.factor"));
    curL.setValueBuffer("reservar", reservado);
    curL.setValueBuffer("codunidad", q.value("ac.codunidad"));
    curL.setValueBuffer("idseccion", q.value("ac.idseccion"));
    curL.setValueBuffer("observaciones", q.value("ac.observaciones"));
		curL.setValueBuffer("codcolorem", q.value("ac.codcolorem"));
		curL.setValueBuffer("componormal", q.value("ac.componormal"));
		curL.setValueBuffer("anchopiezatej", q.value("ac.anchopiezatej"));
		
		if (!curL.commitBuffer()) {
			debug("3");
      return false;
    }
  }
	debug("1. true");
  return true;
}

function euromoda_preloadMainFilter()
{
  var _i = this.iface;
	var cursor = this.cursor();
	var filtro = _i.filtroDefecto();
	var fBase = _i.filtroTodos();
	filtro = fBase != "" ? (fBase + " AND " + filtro) : filtro;
	debug("filtro2: "+filtro);
	return filtro;
}

function euromoda_tbnQuitarFiltro_clicked()
{
	var _i = this.iface;
	
	var filtro = _i.preloadMainFilter();
	
	this.cursor().setMainFilter(filtro);
	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_filtroTodos()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var f = "";
	if (cursor.action() == "em_fichatecnica") {
		f = "fabricado";
	}
	return f;
}

 function euromoda_tbnFiltroFamilia_clicked()
 {
	var _i = this.iface;
	var cursor = this.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();
	var usuario = sys.nameUser();
	
	var f = new FLFormSearchDB("em_filtrosarticulos");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);
	curF.setValueBuffer("accion", cursor.action());	
	f.setMainWidget();
	
	var filtro;
	if (!f.exec("id")) {
		filtro = _i.filtroDefecto();
	} else {
		filtro = curF.valueBuffer("filtro");
	}
	var fBase = _i.filtroTodos();
	filtro = fBase != "" ? (fBase + " AND " + filtro) : filtro;
	if (filtro) {
		curF.commitBuffer();
		cursor.setMainFilter(filtro);
	} else {
		cursor.setMainFilter("");
	}

	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_filtroDefecto()
{
	var cursor = this.cursor();
	var filtro = "";
	if(cursor.action() && cursor.action() == "em_articuloscomp_bus") {
		filtro = this.cursor().mainFilter();
		if(filtro && filtro != "") {
			filtro += " AND NOT debaja"; 
		} else {
			filtro = "NOT debaja"
		}
	} else {
		filtro = "NOT debaja";
	}
	debug("filtro: "+filtro);
	return filtro;
}

function euromoda_copiarAnexosArticulo(refOriginal, refNueva)
{
	var _i = this.iface;

	if(!_i.__copiarAnexosArticulo(refOriginal, refNueva)) {
		return false;
	}	
	if (!_i.copiarTablaAcabadosArt(refOriginal, refNueva)) {
		return false;
	}	
	return true;
}

function euromoda_copiarTablaAcabadosArt(refOriginal, nuevaReferencia)
{
	var _i = this.iface;

	if (!_i.curEmAcabadosArt_) {
 		_i.curEmAcabadosArt_ = new FLSqlCursor("em_acabadosart");
	}
	
	var campos = AQUtil.nombreCampos("em_acabadosart");
	var totalCampos = campos[0];

	var idAcabadoArtNuevo, idAcabadoArtOrigen;
	var curEmAcabadosArtOrigen = new FLSqlCursor("em_acabadosart");
	curEmAcabadosArtOrigen.select("referencia = '" + refOriginal + "'");
	while (curEmAcabadosArtOrigen.next()) {
		_i.curEmAcabadosArt_.setModeAccess(_i.curEmAcabadosArt_.Insert);
		_i.curEmAcabadosArt_.refreshBuffer();
		_i.curEmAcabadosArt_.setValueBuffer("referencia", nuevaReferencia);
	
		for (var i = 1; i <= totalCampos; i++) {
			if (!_i.datosAcabadosArt(curEmAcabadosArtOrigen, campos[i])) {
				return false;
			}
		}

		if (!_i.curEmAcabadosArt_.commitBuffer()) {
			return false;
		}		
	}

	return true;
}

function euromoda_datosAcabadosArt(cursorOrigen,campo)
{
	var _i = this.iface;
	if (!campo || campo == "") {
		return false;
	}
	switch (campo) {
		case "id":
		case "referencia": {
			return true;
			break;
		}
		default: {
			if (cursorOrigen.isNull(campo)) {
				_i.curEmAcabadosArt_.setNull(campo);
			} else {
				_i.curEmAcabadosArt_.setValueBuffer(campo, cursorOrigen.valueBuffer(campo));
			}
		}
	}
	return true;
}

/*function euromoda_ordenaColsValMercado()
{
	var _i = this.iface;
	var oC = _i.dameOrdenColsValMercado();
	
	this.child("tableDBRecords").setOrderCols(oC);	
	this.child("tableDBRecords").refresh();
}

function euromoda_dameOrdenColsValMercado()
{
	var _i = this.iface;
	var oC = ["referencia", "descripcion", "codtamanoem", "emcolorgit", "codcolorem", "coddibestamp", "emdibujo", "codbarras", "codfamilia", "codsubfamilia", "em_fechavalmercado", "em_valmercado", "em_unidmercado", "em_observacionesvm", "idusuarioalta", "fechaalta", "horaalta", "idusuariomod", "fechamod", "horamod"];
	return oC;
}

function euromoda_ocultaBarraBotones()
{
	var _i = this.iface;
	this.child("toolButtonInsert").close();
	this.child("toolButtonEdit").close();
	this.child("toolButtonDelete").close();
	this.child("toolButtonZoom").close();
	this.child("toolButtonCopy").close();
	this.child("tbnFiltroFamilia").close();
	this.child("tbnQuitarFiltro").close();
	this.child("tbnCrearPlantilla").close();
	this.child("tbnActualizarVariable").close();

}*/
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
