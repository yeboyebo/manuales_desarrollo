/***************************************************************************
                 em_ficherosexpcli.qs  -  description
                             -------------------
    begin                : lun feb 3 2020
    copyright            : (C) 2020 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function validateForm():Boolean {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
    function oficial( context ) { interna( context ); }
   	function cargaCombos(cursor) {
        return this.ctx.oficial_cargaCombos(cursor);
    }
	function bufferChanged(fN:String) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function bChPreCursor(fN, cursor) {
        return this.ctx.oficial_bChPreCursor(fN, cursor);
    }
    function bChCursor(fN, cursor) {
        return this.ctx.oficial_bChCursor(fN, cursor);
    }
    function bChPostCursor(fN, cursor) {
        return this.ctx.oficial_bChPostCursor(fN, cursor);
    }
   	function validateCursor(cursor) {
        return this.ctx.oficial_validateCursor(cursor);
    }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	_i.cargaCombos(cursor);
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
    if(!_i.validateCursor(cursor)) {
        return false;
    }
    return true;

}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_cargaCombos(cursor)
{
    var _i = this.iface;
    var simboloDecimal= "."	;
    if (cursor.modeAccess() != cursor.Insert) {
    	simboloDecimal = cursor.valueBuffer("simbolodecimal");
	}
	this.child("cbSimboloDecimal").currentText = simboloDecimal;

	var separador= ";";
    if (cursor.modeAccess() != cursor.Insert) {
    	separador = cursor.valueBuffer("separador");
	}
	this.child("cbSeparador").currentText = separador;

    return true;
}
function oficial_bufferChanged(fN:String)
{
    var _i = this.iface;
    var cursor = this.cursor();

    _i.bChPreCursor(fN, cursor);
    _i.bChCursor(fN, cursor);
    _i.bChPostCursor(fN, cursor);
}

function oficial_bChPreCursor(fN, cursor)
{
    var _i = this.iface;


    switch (fN) {
        default: {
            break;
        }
    }
}

function oficial_bChCursor(fN, cursor)
{
    var _i = this.iface;
    var _fP = flfactppal.iface;

    switch (fN) {
        default: {
            break;
        }
    }
}

function oficial_bChPostCursor(fN, cursor)
{
    var _i = this.iface;

    switch (fN) {
        default: {
            break;
        }
    }
}

function oficial_validateCursor(cursor)
{
    var _i = this.iface;
    var _fP = flfactppal.iface;
   	cursor.setValueBuffer("simbolodecimal",this.child("cbSimboloDecimal").currentText);
   	cursor.setValueBuffer("separador",this.child("cbSeparador").currentText);

    return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
