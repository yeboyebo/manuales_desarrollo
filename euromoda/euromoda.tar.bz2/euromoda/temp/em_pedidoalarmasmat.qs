/***************************************************************************
                 em_pedidoalarmasmat.qs  -  description
                             -------------------
    begin                : mie jun 4 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var listaAlarmas_, erroresMail_;
	var cIDA, cREF, cDES, cORP, cCAN, cSEL, cCPE;
	var clrNoSel, clrSel;
	var correo_;
	function oficial( context ) { interna( context ); }
	function cargaTabla() {
		return this.ctx.oficial_cargaTabla();
	}
	function iniciarTabla() {
		return this.ctx.oficial_iniciarTabla();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function tblLineas_clicked(f, c) {
		return this.ctx.oficial_tblLineas_clicked(f, c);
	}
	function colSelClicked(f) {
		return this.ctx.oficial_colSelClicked(f);
	}
	function colores() {
		return this.ctx.oficial_colores();
	}
	function creaPedidoMat(oParam) {
		return this.ctx.oficial_creaPedidoMat(oParam);
	}
	function gestionDocPedido(oParam) {
		return this.ctx.oficial_gestionDocPedido(oParam);
	}
	function enviarMail(datosMail) {
		return this.ctx.oficial_enviarMail(datosMail);
	}
	function statusChanged(msg, code) {
		return this.ctx.oficial_statusChanged(msg, code);
	}
	function enviaPedidoEmail(oParam) {
		return this.ctx.oficial_enviaPedidoEmail(oParam);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_enviaPedidoEmail(oParam) {
		return this.enviaPedidoEmail(oParam)
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	
	_i.colores();
	
	this.child("pushButtonAccept").close();
	this.child("pushButtonCancel").close();
	
	connect(this.child("tbnAceptar"), "clicked()", _i, "pushButtonAccept_clicked");
  connect(this.child("tbnCancelar"), "clicked()", this.child("pushButtonCancel"), "animateClick()");
	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
  connect(this.child("tblLineas"), "clicked(int, int)", _i, "tblLineas_clicked");
	
  
	_i.iniciarTabla();
	_i.cargaTabla();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciarTabla()
{
  var _i = this.iface;

	var c = 0, cH = [];
  _i.cIDA = c++;
  _i.cREF = c++;
  _i.cDES = c++;
	_i.cORP = c++;
  _i.cCAN = c++;
	_i.cSEL = c++;
  _i.cCPE = c++;

  cH[_i.cIDA] = sys.translate("Id.Alarma");
  cH[_i.cREF] = sys.translate("Art�culo");
  cH[_i.cDES] = sys.translate("Descripci�n");
	cH[_i.cORP] = sys.translate("O.Prod.");
  cH[_i.cCAN] = sys.translate("Cantidad");
	cH[_i.cSEL] = sys.translate("Sel.");
  cH[_i.cCPE] = sys.translate("A Pedir");
  
  var t = this.child("tblLineas");
  t.setNumCols(c);
	t.hideColumn(_i.cIDA);
  t.setColumnWidth(_i.cREF, 60);
  t.setColumnWidth(_i.cDES, 300);
	t.setColumnWidth(_i.cORP, 80);
  t.setColumnWidth(_i.cCAN, 60);
  t.setColumnWidth(_i.cSEL, 50);
  t.setColumnWidth(_i.cCPE, 60);
	
	t.setColumnReadOnly(_i.cIDA, true);
	t.setColumnReadOnly(_i.cREF, true);
	t.setColumnReadOnly(_i.cDES, true);
	t.setColumnReadOnly(_i.cORP, true);
	t.setColumnReadOnly(_i.cCAN, true);
	t.setColumnReadOnly(_i.cSEL, true);

  t.setColumnLabels("*", cH.join("*"));
}

function oficial_cargaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var t = this.child("tblLineas");
	
	var q = new AQSqlQuery;
	q.setSelect("am.idalarma, am.referencia, am.articulo, am.codorden, am.canpendiente");
	q.setFrom("em_alarmasmat am");
	q.setWhere("am.tipogestion = 'Pendiente'");
	if (!q.exec()) {
		return false;
	}
	var f = 0;
	while (q.next()) {
		t.insertRows(f);
		t.setCellBackgroundColor(f, _i.cSEL, _i.clrNoSel);
		t.setText(f, _i.cIDA, q.value("am.idalarma"));
		t.setText(f, _i.cREF, q.value("am.referencia"));
		t.setText(f, _i.cDES, q.value("am.articulo"));
		t.setText(f, _i.cORP, q.value("am.codorden"));
		t.setText(f, _i.cCAN, q.value("am.canpendiente"));
		t.setText(f, _i.cSEL, " ");
		t.setRowReadOnly(f, true);
		f++;
	}
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var oParam = new Object;
  oParam.errorMsg = sys.translate("Error al generar el pedido de materiales");

  var f = new Function("oParam", "return formem_pedidoalarmasmat.iface.creaPedidoMat(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  _i.gestionDocPedido(oParam);
  this.accept();
}

function oficial_gestionDocPedido(oParam)
{
	var _i = this.iface;
	
	var codPedido = oParam.codPedido;
	var res = MessageBox.information(sys.translate("Pedido %1 generado. �Desea imprimirlo?").arg(oParam.codPedido), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res == MessageBox.Yes) {
		formpedidosprov.iface.pub_imprimir(oParam.codPedido);
	}
	
	var codProvInterno = flfactppal.iface.pub_valorDefectoEmpresa("codprovinternolam");
	var codProveedor = oParam.codProveedor;
	var enviar = true;
	if (codProvInterno != codProveedor) {
		res = MessageBox.information(sys.translate("�Desea enviar el pedido %1 por email a %2?").arg(oParam.codPedido).arg(oParam.nombreProv), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			envair = false;
		}
	}
	if (!enviar) {
		return true;
	}
	if (!_i.enviaPedidoEmail(oParam)) {
		return false;
	}
	return true;
}

function oficial_enviaPedidoEmail(oParam)
{
	var _i = this.iface;
	
	var codProveedor = oParam.codProveedor;
	var codPedido = oParam.codPedido;
	
	var email = AQUtil.sqlSelect("proveedores", "email", "codproveedor = '" + codProveedor + "'");
	if (!email) {
		sys.warnMsgBox(sys.translate("El proveedor %1 no tiene email asociado").arg(oParam.nombreProv));
		return true;
	}
	
	var oParam = flfactinfo.iface.pub_dameParamInforme();
  var cursor = new FLSqlCursor("i_pedidosprov");
  cursor.setModeAccess(cursor.Insert);
  cursor.refreshBuffer();
  cursor.setValueBuffer("d_pedidosprov_codigo", codPedido);
  cursor.setValueBuffer("h_pedidosprov_codigo", codPedido);
  oParam.nombreInforme = "i_pedidosprov";
  oParam.datosPdf = new Object;
  oParam.datosPdf.pdf = true;
  oParam.datosPdf.ruta = Dir.home + "/" + "PL_" + codPedido + ".pdf";

  flfactinfo.iface.pub_lanzaInforme(cursor, oParam);
	
	var emailUsuario = AQUtil.sqlSelect("usuarios", "email", "idusuario = '" + sys.nameUser() + "'");
	email += emailUsuario ? ("," + emailUsuario) : "";

  var datosMail = [];
  datosMail["subject"] = sys.translate("Pedido l�minas %1").arg(codPedido);
  datosMail["body"] = sys.translate("Le adjuntamos pedido de l�minas PL-" + codPedido + ".PDF a servir urgente.");
  datosMail["from"] = flfactppal.iface.pub_valorDefecto("usuariosmtp");
  datosMail["to"] = email;
  datosMail["attach"] = [oParam.datosPdf.ruta];
  
 debug("EMAIL VA_______________________________");
debug("subject " + datosMail["subject"] );
debug("body " + datosMail["body"] );
debug("from " + datosMail["from"] );
debug("to " + datosMail["to"] );
debug("attach " + datosMail["attach"]);

  _i.enviarMail(datosMail);
	
	return true;
}

function oficial_enviarMail(datosMail)
{
	var _i = this.iface;
	if(!datosMail)
		return false;

	if(!datosMail.to || datosMail.to == "")
		return;

	var arrayTo = datosMail.to.split(",");
	
	var curSmtp = new FLSqlCursor("factppal_general");
	curSmtp.select("1 = 1");
	if (!curSmtp.first()) {
		return false;
	}
	
	var vB = curSmtp.valueBuffer;
	
	_i.correo_ = new AQSmtpClient;  
	connect(_i.correo_, "statusChanged(QString, int)", _i, "statusChanged()");

	_i.correo_.setMailServer(vB("hostsmtp"));
		
	//** Se puede usar SSL/TLS por el puerto 587
	//** _i.correo_.setPort(587);  
	//** _i.correo_.setConnectionType(AQS.SmtpTlsConnection);
	
	//** O solamente SSL por el puerto 465
	_i.correo_.setPort(vB("puertosmtp"));
	switch (vB("tipocxsmtp")) {
		case "SSL": {
			_i.correo_.setConnectionType(AQS.SmtpSslConnection);  
			break;
		}
		case "TLS": {
			_i.correo_.setConnectionType(AQS.SmtpTlsConnection);
			break;
		}
		default: {
			return false;
		}
	}
		
	switch (vB("tipoautsmtp")) {
		case "Plain": {
			_i.correo_.setAuthMethod(AQS.SmtpAuthPlain);
			break;
		}
		case "Login": {
			_i.correo_.setAuthMethod(AQS.SmtpAuthLogin);
			break;
		}
		default: {
			return false;
		}
	}
	//** Tambien se puede usar el m�todo Login
	//** Algunos servidores s�lo soportan Login
	//** GMail soporta los dos Plain y Login
	//** _i.correo_.setAuthMethod(AQS.SmtpAuthLogin);

	_i.correo_.setUser(vB("usuariosmtp"));  
	_i.correo_.setPassword(vB("passwordsmtp"));  

	try {
		_i.correo_.setMimeType("text/plain");
		_i.correo_.setBody(datosMail.body);
// 			_i.correo_.addTextPart(datosMail.body, "text/plain");
	} catch (e) {
		_i.correo_.setBody(datosMail.body);
	}
	_i.correo_.setFrom(datosMail.from);
	_i.correo_.setTo(datosMail.to);
	_i.correo_.setSubject(datosMail.subject);
	if ("attach" in datosMail) {
		///_i.correo_.addAttachment(datosMail.attach);
		for (var i = 0; i < datosMail.attach.length; i++) {
			_i.correo_.addAttachment(datosMail.attach[i]);
		}
	}
	_i.erroresMail_ = 0;
	_i.correo_.startSend();

	
	return true;
}

function oficial_statusChanged(msg, code)
{
	var _i = this.iface;
	if (!_i.listaAlarmas_) {
		return;
	}
	switch(code) {
		case AQS.SmtpSendOk: {
			if (!AQSql.update("em_alarmasmat", ["email"], ["OK"], "idalarma IN (" + _i.listaAlarmas_ + ")")) {
				sys.warnMsgBox(sys.translate("El email se ha enviado correctamente pero no se ha podido marcar las alarmas como email enviado"));
				return false;
			}
			sys.infoMsgBox(sys.translate("Email enviado correctamente"));
			break;
		}
		case AQS.SmtpError:
		case AQS.SmtpMxDnsError:
		case AQS.SmtpSocketError:
		case AQS.SmtpAttachError:
		case AQS.SmtpServerError:
		case AQS.SmtpClientError: {
			if (_i.erroresMail_ == 0) {
				_i.erroresMail_++;
				_i.correo_.startSend();
				return;
			}
			var bdMsg = (msg && msg != "") ? msg.left(200) : "";
			if (!AQSql.update("em_alarmasmat", ["email", "erroremail"], ["Error", bdMsg], "idalarma IN (" + _i.listaAlarmas_ + ")")) {
				return false;
			}
			sys.errorMsgBox(sys.translate("Error al enviar el email al proveedor"));
			break;
		}
	}
  debug("STATUS CHANGED " + msg + " :  " + code);
}

function oficial_creaPedidoMat(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.listaAlarmas_ = "";
	
	var t = this.child("tblLineas");
	var nF = t.numRows();
	
	var hoy = new Date;
  var fecha = hoy.toString();
	var idProvincia;
  
	var codProveedor = cursor.valueBuffer("codproveedor");
  if (!codProveedor) {
		oParam.errorMsg = sys.translate("Debe indicar el proveedor");
    return false;
  }
  var nombreProv = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'");
	if (!codProveedor) {
    oParam.errorMsg = sys.translate("El proveedor %1 no existe").arg(codProveedor);
    return false;
  }
  var codAlmacen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
  if (!codAlmacen) {
    oParam.errorMsg = sys.translate("Error al obtener el almac�n por defecto de la empresa")
    return false;
  }
  var codEjercicio = flfactppal.iface.pub_ejercicioActual();
  var datosDoc = flfacturac.iface.pub_datosDocFacturacion(fecha, codEjercicio, "pedidosprov");
  if (!datosDoc.ok) {
    return false;
  }
  if (datosDoc.modificaciones) {
    codEjercicio = datosDoc.codEjercicio;
    fecha = datosDoc.fecha;
  }
  
  var qDir = new FLSqlQuery;
  qDir.setSelect("direccion, codpostal, ciudad, idprovincia, provincia, codpais");
  qDir.setFrom("dirproveedores");
  qDir.setWhere("codproveedor = '" + codProveedor + "' AND direccionppal");
  qDir.setForwardOnly(true);
  if (!qDir.exec()) {
    return false;
  }
  if (!qDir.first()) {
    MessageBox.warning(sys.translate("Error al obtener la direcci�n del proveedor %1").arg(nombreProv), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  
  var curP = new FLSqlCursor("pedidosprov");
  curP.setModeAccess(curP.Insert);
  curP.refreshBuffer();
  curP.setValueBuffer("fecha", fecha);
	curP.setValueBuffer("fechaentrada", fecha);
	curP.setValueBuffer("hora", hoy.toString().left(8));
  curP.setValueBuffer("nombre", nombreProv);
  curP.setValueBuffer("cifnif", AQUtil.sqlSelect("proveedores", "cifnif", "codproveedor = '" + codProveedor + "'"));
  curP.setValueBuffer("codproveedor", codProveedor);
  curP.setValueBuffer("coddivisa", flfactppal.iface.pub_valorDefectoEmpresa("coddivisa"));
  curP.setValueBuffer("codpago", AQUtil.sqlSelect("proveedores", "codpago", "codproveedor = '" + codProveedor + "'"));
  curP.setValueBuffer("codalmacen", codAlmacen);
  curP.setValueBuffer("tasaconv", 1);
  curP.setValueBuffer("codejercicio", codEjercicio);
	curP.setValueBuffer("codgrupoivaneg", AQUtil.sqlSelect("proveedores", "codgrupoivaneg", "codproveedor = '" + codProveedor + "'"));
  curP.setValueBuffer("codserie", AQUtil.sqlSelect("proveedores", "codserie", "codproveedor = '" + codProveedor + "'"));
	
	curP.setValueBuffer("direccione", qDir.value("direccion"));
  curP.setValueBuffer("codpostale", qDir.value("codpostal"));
  curP.setValueBuffer("ciudade", qDir.value("ciudad"));
  idProvincia = qDir.value("idprovincia");
  if (idProvincia) {
    curP.setValueBuffer("idprovinciae", idProvincia);
  }
  curP.setValueBuffer("provinciae", qDir.value("provincia"));
  curP.setValueBuffer("codpaise", qDir.value("codpais"));
	
  if (!curP.commitBuffer()) {
    return false;
  }
  var codPedido = curP.valueBuffer("codigo");
  var idPedido = curP.valueBuffer("idpedido");
  var referencia, cantidad, idLinea, idAlarma;
	var curLinea = new FLSqlCursor("lineaspedidosprov");
  var totalAlarmas = 0;
	for (var f = 0; f < nF; f++) {
		if (t.text(f, _i.cSEL) != "X") {
			continue;
		}
		totalAlarmas++;
		idAlarma = t.text(f, _i.cIDA);
		referencia = t.text(f, _i.cREF);
		cantidad = t.text(f, _i.cCPE);
		
		curLinea.select("idpedido = " + idPedido + " AND referencia = '" + referencia + "'");
		if (curLinea.first()) {
			curLinea.setModeAccess(curLinea.Edit);
			curLinea.refreshBuffer();
			curLinea.setValueBuffer("cantidad", curLinea.valueBuffer("cantidad") + parseFloat(cantidad));
		} else {
			curLinea.setModeAccess(curLinea.Insert);
			curLinea.refreshBuffer();
			curLinea.setValueBuffer("idpedido", idPedido);
			curLinea.setValueBuffer("referencia", referencia);
			curLinea.setValueBuffer("descripcion", formRecordlineaspedidosprov.iface.pub_commonCalculateField("desarticulo", curLinea));
			curLinea.setValueBuffer("codtamanoem", AQUtil.sqlSelect("articulos", "codtamanoem", "referencia = '" + referencia + "'"));
			curLinea.setValueBuffer("codcolorem", AQUtil.sqlSelect("articulos", "codcolorem", "referencia = '" + referencia + "'"));
			curLinea.setValueBuffer("cantidad", cantidad);
			curLinea.setValueBuffer("pvpunitario", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpunitario", curLinea));
			curLinea.setValueBuffer("codimpuesto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("codimpuesto", curLinea));
			curLinea.setValueBuffer("iva", formRecordlineaspedidosprov.iface.pub_commonCalculateField("iva", curLinea));
			curLinea.setValueBuffer("numlinea",formRecordlineaspedidosprov.iface.pub_commonCalculateField("numlinea", curLinea));
		}
		curLinea.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLinea));
		curLinea.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLinea));
		idLinea = curLinea.valueBuffer("idlinea");
		if (!curLinea.commitBuffer()) {
			return false;
		}
		if (!AQSql.update("em_alarmasmat", ["tipogestion", "documento", "idpedido", "codproveedor", "nombreproveedor", "idlineapp"], ["Pedido", codPedido, idPedido, codProveedor, nombreProv, idLinea], "idalarma = " + idAlarma)) {
			return false;
		}
		_i.listaAlarmas_ += (_i.listaAlarmas_ != "") ? ", " : "";
		_i.listaAlarmas_ += idAlarma.toString();
	}
	if (totalAlarmas == 0) {
		oParam.errorMsg = sys.translate("No ha incluido ninguna l�nea en el pedido");
    return false;
	}
  
  curP.select("idpedido = " + idPedido);
  if (!curP.first()) {
    return false;
  }
  with (curP) {
    setModeAccess(curP.Edit);
    refreshBuffer();
    setValueBuffer("netosindtoesp", formpedidosprov.iface.pub_commonCalculateField("netosindtoesp", this));
    setValueBuffer("dtoesp", formpedidosprov.iface.pub_commonCalculateField("dtoesp", this));
    setValueBuffer("neto", formpedidosprov.iface.pub_commonCalculateField("neto", this));
    setValueBuffer("totaliva", formpedidosprov.iface.pub_commonCalculateField("totaliva", this));
    setValueBuffer("totalirpf", formpedidosprov.iface.pub_commonCalculateField("totalirpf", this));
    setValueBuffer("totalrecargo", formpedidosprov.iface.pub_commonCalculateField("totalrecargo", this));
    setValueBuffer("total", formpedidosprov.iface.pub_commonCalculateField("total", this));
    setValueBuffer("totaleuros", formpedidosprov.iface.pub_commonCalculateField("totaleuros", this));
  }
  if (!curP.commitBuffer()) {
    return false;
  }
  oParam.codPedido = codPedido;
  oParam.codProveedor = codProveedor;
	oParam.nombreProv = nombreProv;
  return true;
}

function oficial_tblLineas_clicked(f, c)
{
  var _i = this.iface;
	switch (c) {
		case _i.cSEL: {
			_i.colSelClicked(f);
			break;
		}
  }
}

function oficial_colSelClicked(f)
{
	var _i = this.iface;
	var t = this.child("tblLineas");
	
  var c = _i.cSEL;
  if (t.text(f, c) == " ") {
    t.setText(f, c, "X");
		t.setText(f, _i.cCPE, t.text(f, _i.cCAN));
  } else {
		t.setText(f, c, "X");
		t.setText(f, c, " ");
		t.setText(f, _i.cCPE, "");
  }

  if (t.text(f, c) == "X") {
    t.setCellBackgroundColor(f, c, _i.clrSel);
		t.setRowReadOnly(f, false);
  } else {
    t.setCellBackgroundColor(f, c, _i.clrNoSel);
		t.setRowReadOnly(f, true);
  }
	return true;
}

function oficial_colores()
{
  var _i = this.iface;
	var _dC = flfactppal.iface.pub_dameColor;
	
  _i.clrNoSel = new Color(_dC("fondo_rojo"));
  _i.clrSel = new Color(_dC("fondo_verde"));
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
