/***************************************************************************
                 em_buspedcli.qs  -  description
                             -------------------
    begin                : lun abr 26 2004
    copyright            : (C) 2004 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration  oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna(context); }
	function tbnFiltroClientes_clicked() {
		return this.ctx.oficial_tbnFiltroClientes_clicked();
	}
	function tbnQuitarFiltro_clicked() {
		return this.ctx.oficial_tbnQuitarFiltro_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
Este es el formulario maestro de pedidos a cliente.
\end */
function interna_init()
{
	var _i = this.iface;
	
	connect(this.child("tbnFiltroClientes"), "clicked()", _i, "tbnFiltroClientes_clicked");
	connect(this.child("tbnQuitarFiltro"), "clicked()", _i, "tbnQuitarFiltro_clicked");
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnQuitarFiltro_clicked()
{
	var _i = this.iface;
	this.cursor().setMainFilter("");
	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function oficial_tbnFiltroClientes_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();

	var f = new FLFormSearchDB("em_filtrosclientes");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);
	curF.setValueBuffer("tabla", "pedidoscli");

	f.setMainWidget();

	var filtro = f.exec("filtro");
	if (!filtro) {
		filtro = "1 = 1";
	}
debug("filtro " + filtro);
	if (filtro) {
		curF.commitBuffer();
		cursor.setMainFilter(filtro);
	} else {
		cursor.setMainFilter("");
	}

	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////