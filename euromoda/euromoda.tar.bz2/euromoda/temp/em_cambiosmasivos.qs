/***************************************************************************
                 em_cambiosmasivos.qs  -  description
                             -------------------
    begin                : mie nov 23 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function calculateField(fN) {
		return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  var modo_, filtro_;
  var cambiarMargen_, cambiarCostes_, cambiarGeneral_, modoTabla_;
  function oficial( context ) { interna( context ); } 
  function habilitaPorModo()
  {
    return this.ctx.oficial_habilitaPorModo();
  }
  function cambiaModo(m)
  {
    return this.ctx.oficial_cambiaModo(m);
  }
  function busca() {
    return this.ctx.oficial_busca();
  }
  function cambia() {
    return this.ctx.oficial_cambia();
  }
  function cancela() {
    return this.ctx.oficial_cancela();
  }
  function refresca() {
    return this.ctx.oficial_refresca();
  }
  function bufferChanged(fN) {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function habilitaCambios() {
    return this.ctx.oficial_habilitaCambios();
  }
  function tbnLimpiarFiltro_clicked() {
    return this.ctx.oficial_tbnLimpiarFiltro_clicked();
  }
  function habilitaChecks() {
  	return this.ctx.oficial_habilitaChecks();
  }
  function habilitaCostes() {
  	return this.ctx.oficial_habilitaCostes();
  }
  function ordenaCols() {
  	return this.ctx.oficial_ordenaCols();
  }
  function habilitaCamposCostesProd() {
  	return this.ctx.oficial_habilitaCamposCostesProd();
  }
/*	function tbnTodosSel_clicked() {
		return this.ctx.oficial_tbnTodosSel_clicked();
	}
	function tbnNingunoSel_clicked() {
		return this.ctx.oficial_tbnNingunoSel_clicked();
	}*/
  	function habilitaAumentoCoste() {
		return this.ctx.oficial_habilitaAumentoCoste();
	}
	function habilitaDisminuirCoste() {
		return this.ctx.oficial_habilitaDisminuirCoste();
	}
	function habilitaAumentoMargen() {
		return this.ctx.oficial_habilitaAumentoMargen();
	}
	function habilitaDisminuirMargen() {
		return this.ctx.oficial_habilitaDisminuirMargen();
	}
	function procesaModoTabla(modo) {
		return this.ctx.oficial_procesaModoTabla(modo);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.cambiarMargen_ = false;
	_i.cambiarCostes_ = false;
	_i.ordenaCols();
	_i.habilitaChecks();
	connect(this.child("pbnBuscar"), "clicked()", _i, "busca");
	connect(this.child("pbnAplicar"), "clicked()", _i, "cambia");
	connect(this.child("pbnCancelar"), "clicked()", _i, "cancela");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");

/*	connect(this.child("tbnTodosSel"), "clicked()", this, "iface.tbnTodosSel_clicked()");
	connect(this.child("tbnNingunoSel"), "clicked()", this, "iface.tbnNingunoSel_clicked()");*/

	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
	connect(this.child("btgModo"), "clicked(int)", _i, "procesaModoTabla");

	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			_i.procesaModoTabla(0);
			sys.setObjText(this, "fdbIdUsuario", sys.nameUser());
			sys.setObjText(this, "fdbCodAlmacen", flfactppal.iface.pub_valorDefectoEmpresa("codalmacen"));
			_i.cambiaModo("BUS");
			_i.filtro_ = "1=2";
			_i.refresca();
			break;
		}
		case cursor.Edit: {			
			_i.procesaModoTabla(0);
			_i.busca();
			break;
		}
	}


}

function interna_calculateField(fN)
{

	var _i = this.iface;
	var cursor = this.cursor();
	var valor;

	switch (fN) {
		case "codfamiliac": {
			var codSubfamiliaC = cursor.valueBuffer("codsubfamiliac");
			if(codSubfamiliaC && codSubfamiliaC != "") {
				valor = AQUtil.sqlSelect("subfamilias", "codfamilia",  "codsubfamilia= '" + codSubfamiliaC + "'");	
			} else {
				valor = cursor.valueBuffer("codfamiliac");
			}			
			break;
		}
		default: {
			valor = "";
			break;
		}
	}

	return valor;
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_habilitaCambios()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var usuario = sys.nameUser();
	
	var aCampos = ["fdbCStockMin","fdbStockMin","fdbCodAlmacen","fdbAlmacen","fdbDescatalogado","fdbFechaDes","fdbDeBaja","fdbFechaBaja","fdbALiquidar","fdbFechaLiq","fdbGama","fdbDesGama","fdbCodColeccionEMNuevo","fdbDesColeccion","fdbColeccionPpal","fdbCodFamiliaC","fdbDesFamilia","fdbClonarTamSub","fdbCodSubfamiliaC","fdbdescsubfamilia","fdbCambiarDescArt"];


	var q = new AQSqlQuery;	
	q.setSelect("em_cambiarmasivogen");
	q.setFrom("usuarios");
	q.setWhere("idusuario = '" + usuario + "'");	
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		_i.cambiarGeneral_ = q.value("em_cambiarmasivogen");				
	}

	if(_i.cambiarGeneral_) {

		this.child("fdbStockMin").setDisabled(cursor.valueBuffer("cstockmin") != "S�");
		this.child("fdbCodAlmacen").setDisabled(cursor.valueBuffer("cstockmin") != "S�");
		this.child("fdbFechaDes").setDisabled(cursor.valueBuffer("descatalogado") != "S�");
		this.child("fdbFechaBaja").setDisabled(cursor.valueBuffer("debaja") != "S�");
		this.child("fdbFechaLiq").setDisabled(cursor.valueBuffer("aliquidar") != "S�");
	} else {
		for(var i =0; i<aCampos.length; i++) {
			this.child(aCampos[i]).setDisabled(true);
		}
	}
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "cstockmin": {
			if (cursor.valueBuffer("cstockmin") != "S�") {
				this.child("fdbStockMin").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "descatalogado": {
			if (cursor.valueBuffer("descatalogado") == "S�") {
				this.child("fdbFechaDes").setValue(cursor.valueBuffer("fecha"));
			} else {
				this.child("fdbFechaDes").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "debaja": {
			if (cursor.valueBuffer("debaja") == "S�") {
				this.child("fdbFechaBaja").setValue(cursor.valueBuffer("fecha"));
			} else {
				this.child("fdbFechaBaja").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "aliquidar": {
			if (cursor.valueBuffer("aliquidar") == "S�") {
				this.child("fdbFechaLiq").setValue(cursor.valueBuffer("fecha"));
			} else {
				this.child("fdbFechaLiq").setValue("NULL");
			}
			_i.habilitaCambios();
			break;
		}
		case "coddibestamp":{
			cursor.setValueBuffer("dibujos", cursor.valueBuffer("coddibestamp"));
			break;
		}
		case "codsubfamiliac": {
			if(cursor.valueBuffer("codsubfamiliac") != "") {
				cursor.setValueBuffer("codfamiliac",_i.calculateField("codfamiliac"));	
			}			
			_i.habilitaChecks();
			break;
		}		
		case "cambiarcostes": 
		case "eliminarcostes": 
		case "eliminarmargenes": 
		case "em_tipocoste":
		case "em_tipomargen": {
			_i.habilitaCostes();
			break;
		}
		case "aumentarcoste": {
			_i.habilitaAumentoCoste();
			break;
		}
		case "disminuircoste": {
			_i.habilitaDisminuirCoste();
			break;
		}
		case "aumentarmargen":{
			_i.habilitaAumentoMargen();
			break;
		}
		case "disminuirmargen": {
			_i.habilitaDisminuirMargen();
			break;
		}
	}
  
}

function oficial_habilitaChecks()
{
	var cursor = this.cursor();
	var codSubfamiliaC = cursor.valueBuffer("codsubfamiliac");
	if(codSubfamiliaC && codSubfamiliaC != "") {
		this.child("fdbClonarTamSub").setDisabled(false);
	} else {
		this.child("fdbClonarTamSub").setValue(false);
		this.child("fdbClonarTamSub").setDisabled(true);
	}
} 

function oficial_cambiaModo(m)
{
  var _i = this.iface;
  _i.modo_ = m;
  _i.habilitaPorModo();  
}

function oficial_habilitaPorModo()
{
  var _i = this.iface;
  switch (_i.modo_) {
  case "BUS": {
      this.child("gbxBus").enabled = true;
      this.child("gbxAct").enabled = false;
      break;
    }
  case "ACT": {
      this.child("gbxBus").setEnabled(false);
      this.child("gbxAct").setEnabled(true);
      _i.habilitaCambios();
      _i.habilitaCamposCostesProd();
      _i.habilitaCostes();


      break;
    }
  }
}

function oficial_busca()
{ 
  var _i = this.iface;
  var cursor = this.cursor();
	
// 	var f = "";
//   var codFamilia = cursor.valueBuffer("codfamilia");
//   if (codFamilia && codFamilia != "") {
//     f += f != "" ? " AND " : "";
//     f += "codfamilia = '" + codFamilia + "'";
//   }
//   var codSubfamilia = cursor.valueBuffer("codsubfamilia");
//   if (codSubfamilia && codSubfamilia != "") {
//     f += f != "" ? " AND " : "";
//     f += "codsubfamilia = '" + codSubfamilia + "'";
//   }
//   var codColeccion = cursor.valueBuffer("codcoleccionem");
//   if (codColeccion && codColeccion != "") {
//     f += f != "" ? " AND " : "";
//     f += "codcoleccionem = '" + codColeccion + "'";
//   }
  this.child("tdbArticulos").clearChecked();
  _i.filtro_ = formem_filtrosarticulos.iface.pub_construirFiltro(cursor);
  if(!_i.filtro_ || _i.filtro_ == "") {
  	_i.filtro_ = "1=1";
  }
  _i.refresca();
  _i.cambiaModo("ACT");
}

function oficial_refresca()
{
  var _i = this.iface;
  this.child("tdbArticulos").cursor().setMainFilter(_i.filtro_);
  this.child("tdbArticulos").refresh();
}

function oficial_cambia()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var avisoDescripcion = false;
	var cambiarCostes = cursor.valueBuffer("cambiarcostes");

	if(_i.cambiarGeneral_) {		
		if (!cursor.isNull("stockmin") && cursor.valueBuffer("stockmin") != "" && cursor.isNull("codalmacen")) {
			sys.warnMsgBox(sys.translate("Para establecer un nuevo stock m�nimo debe indicar el almac�n asociado"));
			return;
		}
	} else {
		if(!cambiarCostes) {
			return true;
		}
	}


	
	var eliminarCostes  = cursor.valueBuffer("eliminarcostes");
	var eliminarMargenes  = cursor.valueBuffer("eliminarmargenes");
	var costeProd = cursor.valueBuffer("em_costeprod");
	var margenProd = cursor.valueBuffer("em_margenprod");
	var observProd = cursor.valueBuffer("em_observcosteprod");
	var observMargen = cursor.valueBuffer("em_observmargenprod");
	var tipoCostes = cursor.valueBuffer("em_tipocoste");
	var tipoMargen = cursor.valueBuffer("em_tipomargen");
	var aumentarCostes = cursor.valueBuffer("aumentarcoste");
	var porAumCoste = cursor.valueBuffer("poraumcoste");
	var disminuirCostes = cursor.valueBuffer("disminuircoste");	
	var porDismCoste = cursor.valueBuffer("pordismcoste"); 
	var aumentarMargen = cursor.valueBuffer("aumentarmargen");
	var porAumMargen = cursor.valueBuffer("poraummargen");
	var disminuirMargen = cursor.valueBuffer("disminuirmargen");
	var porDismMargen = cursor.valueBuffer("pordismmargen");
	var costeActual;
	var costeNuevo;
	var margenActual;
	var margenNuevo;
	var cambioCoste = false;
	var cambioMargen = false;
	var aSel = this.child("tdbArticulos").primarysKeysChecked();
	//debug("filtro: "+_i.filtro_);

	var curA = new FLSqlCursor("articulos");
	//curA.select(_i.filtro_);
	if(_i.modoTabla_ == "Todos") {
		var res = flfactppal.iface.preguntaMsg(sys.translate("Se van a realizar los cambios a todas las referencias que se muestran.\n�Desea continuar?"),"info",this,MessageBox.Yes, MessageBox.No);  
		if (res != MessageBox.Yes) {
			return;
		}
		curA.select(_i.filtro_);

	} else if(_i.modoTabla_ == "Incluir") {
		var res = flfactppal.iface.preguntaMsg(sys.translate("Est� en modo INCLUIR, se van a realizar los cambios a las referencias marcadas.\n�Desea continuar?"),"info",this,MessageBox.Yes, MessageBox.No);  
		if (res != MessageBox.Yes) {
			return;
		}
		//debug("modo incluir: referencia IN ('"+aSel.join("','") + "')");
		curA.select("referencia IN ('"+aSel.join("','") + "')");	
	} else {
		var res = flfactppal.iface.preguntaMsg(sys.translate("Est� en modo EXCLUIR, se van a realizar los cambios a las referencias NO marcadas.\n�Desea continuar?"),"info",this,MessageBox.Yes, MessageBox.No);  
		if (res != MessageBox.Yes) {
			return;
		}		
		//debug("modo excluir: "+_i.filtro_ + " AND referencia NOT IN ('"+aSel.join("','") + "')");
		curA.select(_i.filtro_ + " AND referencia NOT IN ('"+aSel.join("','") + "')");	
	}
	
	AQUtil.createProgressDialog(sys.translate("Cambiando art�culos"), curA.size());
	var a = 0;
	var cambios = 0;
	var contCambio = false;
	var referencia;
	var codAlmacen = cursor.valueBuffer("codalmacen");
	while (curA.next()) {
		AQUtil.setProgress(a++);
		curA.setModeAccess(curA.Edit);
		curA.refreshBuffer();
		referencia = curA.valueBuffer("referencia");
		contCambio = false;
		if(_i.cambiarGeneral_) {
			if (!cursor.isNull("stockmin")) {
				if (!AQSql.update("stocks", ["stockmin"], [cursor.valueBuffer("stockmin")], "codalmacen = '" + codAlmacen + "' AND referencia = '" + referencia + "'")) {
					return false;
				}
				if(!contCambio) {
					contCambio = true;
					cambios++;
				}
			}
			switch (cursor.valueBuffer("descatalogado")) {
				case "S�": {
					curA.setValueBuffer("descatalogado", true);
					curA.setValueBuffer("idusuariodes", cursor.valueBuffer("idusuario"));
					curA.setValueBuffer("fechades", cursor.valueBuffer("fecha"));
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
					break;
				}
				case "No": {
					curA.setValueBuffer("descatalogado", false);
					curA.setNull("idusuariodes");
					curA.setNull("fechades");
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
					break;
				}
			}
			switch (cursor.valueBuffer("debaja")) {
				case "S�": {
					curA.setValueBuffer("debaja", true);
					curA.setValueBuffer("idusuariobaja", cursor.valueBuffer("idusuario"));
					curA.setValueBuffer("fechabaja", cursor.valueBuffer("fecha"));
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
					break;
				}
				case "No": {
					curA.setValueBuffer("debaja", false);
					curA.setNull("idusuariobaja");
					curA.setNull("fechabaja");
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
					break;
				}
			}
			switch (cursor.valueBuffer("aliquidar")) {
				case "S�": {
					curA.setValueBuffer("fechaliq", cursor.valueBuffer("fecha"));
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
					break;
				}
				case "No": {
					curA.setNull("fechaliq");
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
					break;
				}
			}
			if (cursor.valueBuffer("em_codgama")) {
				curA.setValueBuffer("em_codgama", cursor.valueBuffer("em_codgama"));
				if(!contCambio) {
					contCambio = true;
					cambios++;
				}
			}
			var codColeccion = cursor.valueBuffer("codcoleccionemnuevo");
			var ppal = cursor.valueBuffer("coleccionppal");;
			if (codColeccion) {
				if (!AQUtil.sqlSelect("em_coleccionesart", "idcoleccionart", "referencia = '" + referencia + "' AND codcoleccionem = '" + codColeccion + "'")) {
					if (!AQUtil.sqlSelect("em_coleccionesart", "idcoleccionart", "referencia = '" + referencia + "'")) {
						ppal = true;
					}
					if (!AQSql.insert("em_coleccionesart", ["referencia", "codcoleccionem", "descripcion", "principal"], [referencia, codColeccion, AQUtil.sqlSelect("em_colecciones", "descripcion", "codcoleccionem = '" + codColeccion + "'"), ppal])) {
						return false;
					}
				}
				if (ppal) {
					if (!AQSql.update("em_coleccionesart", ["principal"], [false], "referencia = '" + referencia + "'")) {
						return false;
					}
					if (!AQSql.update("em_coleccionesart", ["principal"], [true], "referencia = '" + referencia + "' AND codcoleccionem = '" + codColeccion + "'")) {
						return false;
					}
				}
				if (ppal) {
					curA.setValueBuffer("codcoleccionem", codColeccion);
					curA.setValueBuffer("descoleccion", AQUtil.sqlSelect("em_colecciones","descripcion","codcoleccionem = '" + codColeccion + "'"));
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
				}
			}
			var codFamiliaC = cursor.valueBuffer("codfamiliac");
			var codSubfamiliaC = cursor.valueBuffer("codsubfamiliac"); 
			var clonarTamSub = cursor.valueBuffer("clonartamsub");		
			var codSubfamiliaArt = curA.valueBuffer("codsubfamilia");
			
			if(codFamiliaC && codFamiliaC != "") {
				if(!codSubfamiliaC || codSubfamiliaC == "") {	
					
					var codFamiliaArt = AQUtil.sqlSelect("subfamilias","codfamilia","codsubfamilia = '" + codSubfamiliaArt + "'");
					
					
					if(codFamiliaArt != codFamiliaC) {
						flfactppal.iface.ponMsgError(sys.translate("Revise si la subfamilia %1 deber�a ser de la nueva familia %2. No se aplicar� el cambio al art�culo %3: La subfamilia %4 no pertenece a la nueva familia").arg(codSubfamiliaArt).arg(codFamiliaC).arg(referencia).arg(codSubfamiliaArt),"warn",this);				
						continue;
					}
				} 	
				curA.setValueBuffer("codfamilia", codFamiliaC);	
				if(!contCambio) {
					contCambio = true;
					cambios++;
				}		
			}

			var tamaArticulo = curA.valueBuffer("codtamanoem");
			var codEmbalaje = AQUtil.sqlSelect("em_tamanossubfam","em_codtipoemb","codsubfamilia = '" + codSubfamiliaArt + "' and codtamanoem = '" + tamaArticulo + "'");
			var hayTamSubfam = AQUtil.sqlSelect("em_tamanossubfam","idtamanosubfam","codsubfamilia = '" + codSubfamiliaC + "' and codtamanoem = '" + tamaArticulo + "'");
			if(codSubfamiliaC && codSubfamiliaC != "") {			
				if(clonarTamSub) {
					if(codSubfamiliaC && codSubfamiliaC != "") {
						curA.setValueBuffer("codsubfamilia", codSubfamiliaC);
						if(!contCambio) {
							contCambio = true;
							cambios++;
						}							
					}	
					if(!hayTamSubfam) {
						
						if(!AQUtil.execSql("INSERT INTO em_tamanossubfam (codsubfamilia,codtamanoem,em_codtipoemb,orden,unidadesemb) SELECT '" + codSubfamiliaC + "',codtamanoem,em_codtipoemb,orden,unidadesemb FROM em_tamanossubfam WHERE codsubfamilia = '" + codSubfamiliaArt + "' and codtamanoem = '" + tamaArticulo + "'")) {
							return false;
						}
						
					}
				} else {
					if(!hayTamSubfam) {
						var res = flfactppal.iface.preguntaMsg(sys.translate("Hemos revisado el tama�o %1 y embalaje %2 para la subfamilia nueva y NO EXISTE, y no ha marcado clonar tama�os, ESTO PUEDE CAUSAR PROBLEMAS.\n�Confirma que realmente quiere cambiar la subfamilia/familia del art�culo %3 �s� o no?").arg(tamaArticulo).arg(codEmbalaje).arg(referencia),"info",this,MessageBox.Yes, MessageBox.No);  
						if (res != MessageBox.Yes) {
							return;
						}
						flfactppal.iface.ponMsgError(sys.translate("Despu�s debe revisar el tam�ao %1 y EMBALAJE %2 para a subfamilia nueva en el art�culo %3 ya que no existe y no ha marcado clonar tama�os").arg(tamaArticulo).arg(codEmbalaje).arg(referencia),"warn",this);		
					}
					if(codSubfamiliaC && codSubfamiliaC != "") {
						curA.setValueBuffer("codsubfamilia", codSubfamiliaC);
						if(!contCambio) {
							contCambio = true;
							cambios++;
						}	
					}		
				}
			}
			var cambiarDescArt = cursor.valueBuffer("cambiardescart");
			if(cambiarDescArt) {
				
					curA.setValueBuffer("descripcion", formRecordarticulos.iface.calculaDescripcion(curA));
					if(!contCambio) {
						contCambio = true;
						cambios++;
					}
				
			} else {
				
				if(codSubfamiliaC && codSubfamiliaC != "") {
					var descSubFamA = AQUtil.sqlSelect("subfamilias","descripcion","codsubfamilia = '" + codSubfamiliaArt + "'");
					var descSubFamC = AQUtil.sqlSelect("subfamilias","descripcion","codsubfamilia = '" + codSubfamiliaC + "'");
					if(descSubFamA != descSubFamC) {
						avisoDescripcion = true;
					}
				}
			}		
		}
		//ANTES DE CAMBIO 10-04-2019
		/*if(cambiarCostes) {			
			if(eliminarCostes) {
				curA.setNull("em_costeprod");				
				curA.setNull("em_observcosteprod");				
			} else {
				if(costeProd && costeProd != "") {
					curA.setValueBuffer("em_costeprod",costeProd);						
				}
				if(observProd && observProd != "") {
					curA.setValueBuffer("em_observcosteprod",observProd);
				}
			}
			if (eliminarMargenes) {
				curA.setNull("em_margenprod");
				curA.setNull("em_observmargenprod");
			} else {
				if(margenProd && margenProd != "") {
					curA.setValueBuffer("em_margenprod",margenProd);
				}
				if(observMargen && observMargen != "") {
					curA.setValueBuffer("em_observmargenprod",observMargen);
				}
			}
		}*/	

	/*var tipoCostes = cursor.valueBuffer("em_tipocoste");
	var tipoMargen = cursor.valueBuffer("em_tipomargen");
	var aumentarCostes = cursor.valueBuffer("aumentarcoste");
	var porAumCoste = cursor.valueBuffer("poraumcoste");
	var disminuirCostes = cursor.valueBuffer("disminuircoste");	
	var porDismCoste = cursor.valueBuffer("pordismcoste"); 
	var aumentarMargen = cursor.valueBuffer("aumentarmargen");
	var porAumMargen = cursor.valueBuffer("poraummargen");
	var disminuirMargen = cursor.valueBuffer("disminuirmargen");
	var porDismMargen = cursor.valueBuffer("pordismmargen");*/
		cambioCoste = false;
		cambioMargen = false;
		if(cambiarCostes) {			
			if(eliminarCostes) {
				curA.setNull("em_costeprod");				
				curA.setNull("em_observcosteprod");		
				cambioCoste = true;		
			} else {
				if(tipoCostes == "Manual") {
					if(costeProd && costeProd != "") {
						curA.setValueBuffer("em_costeprod",costeProd);		
						cambioCoste = true;					
					}
					if(observProd && observProd != "") {
						curA.setValueBuffer("em_observcosteprod",observProd);
						cambioCoste = true;	
					}
					curA.setValueBuffer("em_tipocoste",tipoCostes);
					if(aumentarCostes) {
						if(curA.valueBuffer("em_tipocoste") == "Manual") {
							costeActual = curA.valueBuffer("em_costeprod");
							costeNuevo = costeActual*(1+porAumCoste/100);
							curA.setValueBuffer("em_costeprod",costeNuevo);		
							cambioCoste = true;	
						}	
					} else if(disminuirCostes) {
						if(curA.valueBuffer("em_tipocoste") == "Manual") {
							costeActual = curA.valueBuffer("em_costeprod");
							costeNuevo = costeActual*(1-porDismCoste/100);
							curA.setValueBuffer("em_costeprod",costeNuevo);		
							cambioCoste = true;	
						}
					}
					cambioCoste = true;	
				} else if(tipoCostes=="Heredado") {										
					var oCostes = formRecordarticulos.iface.dameCosteProd(curA, true);					
					if(oCostes) {
					 	if("coste" in oCostes && oCostes["coste"]) {							
							costeNuevo = oCostes["coste"];							
							if(oCostes["coste"]) {				
								//debug("origenCoste: "+oCostes["origenCoste"]);				
								debug("fechaCoste: "+oCostes["fechaCoste"]);
								debug("horaCoste: "+oCostes["horaCoste"].toString().right(8));
								curA.setValueBuffer("em_costeprod",costeNuevo);							
								curA.setValueBuffer("em_observcosteprod",oCostes["observCoste"]);
								curA.setValueBuffer("em_fechacosteprod",oCostes["fechaCoste"]);
								curA.setValueBuffer("em_horacosteprod",oCostes["horaCoste"].toString().right(8));
								curA.setValueBuffer("em_idusuariocosteprod",oCostes["idUsuarioCoste"]);
								curA.setValueBuffer("em_origencoste",oCostes["origenCoste"]);								
							} 	
						}	
					}
					cambioCoste = true;	
					curA.setValueBuffer("em_tipocoste",tipoCostes);					
				} else {
					if(aumentarCostes) {
						if(curA.valueBuffer("em_tipocoste") == "Manual") {
							costeActual = curA.valueBuffer("em_costeprod");
							costeNuevo = costeActual*(1+porAumCoste/100);
							curA.setValueBuffer("em_costeprod",costeNuevo);		
							cambioCoste = true;	
						}	
					} else if(disminuirCostes) {
						if(curA.valueBuffer("em_tipocoste") == "Manual") {
							costeActual = curA.valueBuffer("em_costeprod");
							costeNuevo = costeActual*(1-porDismCoste/100);
							curA.setValueBuffer("em_costeprod",costeNuevo);		
							cambioCoste = true;	
						}
					}
				}

			}
			if (eliminarMargenes) {
				curA.setNull("em_margenprod");
				curA.setNull("em_observmargenprod");
				cambioMargen = true;
			} else {
				if(tipoMargen == "Manual") {
					if(margenProd && margenProd != "") {
						curA.setValueBuffer("em_margenprod",margenProd);					
						cambioMargen = true;
					}
					if(observMargen && observMargen != "") {
						curA.setValueBuffer("em_observmargenprod",observMargen);
						cambioMargen = true;
					}
					curA.setValueBuffer("em_tipomargen",tipoMargen);
					if(aumentarMargen) {
						if(curA.valueBuffer("em_tipomargen") == "Manual") {							
							margenActual = curA.valueBuffer("em_margenprod");
							margenNuevo = margenActual*(1+porAumMargen/100);
							curA.setValueBuffer("em_margenprod",margenNuevo);			
							cambioMargen = true;
						}
					} else if(disminuirMargen) {
						if(curA.valueBuffer("em_tipomargen") == "Manual") {
							margenActual = curA.valueBuffer("em_margenprod");
							margenNuevo = margenActual*(1-porDismMargen/100);
							curA.setValueBuffer("em_margenprod",margenNuevo);	
							cambioMargen = true;
						}
					}
					cambioMargen = true;
				} else if(tipoMargen=="Heredado") {
					var oMargen = formRecordarticulos.iface.dameMargenProd(curA, true);					
					if(oMargen) {
					 	if("margen" in oMargen && oMargen["margen"]) {							
							margenNuevo = oMargen["margen"];							
							if(oMargen["margen"]) {								
								curA.setValueBuffer("em_margenprod",margenNuevo);							
								curA.setValueBuffer("em_observmargenprod",oMargen["observMargen"]);
								curA.setValueBuffer("em_fechamargenprod",oMargen["fechaMargen"]);
								curA.setValueBuffer("em_horamargenprod",oMargen["horaMargen"].toString().right(8));
								curA.setValueBuffer("em_idusuariomargenprod",oMargen["idUsuarioMargen"]);
								curA.setValueBuffer("em_origenmargen",oMargen["origenMargen"]);		
								
							} 	
						}	
					}	
					curA.setValueBuffer("em_tipomargen",tipoMargen);
					cambioMargen = true;
				} else {
					if(aumentarMargen) {
						if(curA.valueBuffer("em_tipomargen") == "Manual") {							
							margenActual = curA.valueBuffer("em_margenprod");
							margenNuevo = margenActual*(1+porAumMargen/100);
							curA.setValueBuffer("em_margenprod",margenNuevo);			
							cambioMargen = true;
						}
					} else if(disminuirMargen) {
						if(curA.valueBuffer("em_tipomargen") == "Manual") {
							margenActual = curA.valueBuffer("em_margenprod");
							margenNuevo = margenActual*(1-porDismMargen/100);
							curA.setValueBuffer("em_margenprod",margenNuevo);	
							cambioMargen = true;
						}
					}
				}
			}
		}
		if (!curA.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		if(cambioCoste || cambioMargen) {
			if(!contCambio) {
				contCambio = true;
				cambios++;
			}
			if(!formRecordarticulos.iface.ponDatosLogCostes("articulos", curA)) {
				return false;
			}
		}
		//cambios++;
	}

	if(avisoDescripcion) {
		flfactppal.iface.ponMsgError(sys.translate("La descripci�n de la subfamilia nueva no coincide con la vieja y no ha marcado cambiar descripcion de art�culos,\nrevise si lo debe de hacer m�s tarde"),"warn",this);
	}
	avisoDescripcion = false;

	AQUtil.destroyProgressDialog();
	if(cambios >0) {
		MessageBox.information(sys.translate("%1 Art�culos cambiados").arg(cambios), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");	
	}
	
	this.child("tdbArticulos").refresh();
}

function oficial_cancela()
{
  var _i = this.iface;
  _i.cambiaModo("BUS");
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	formem_filtrosarticulos.iface.pub_limpiarFiltro(this);
}

function oficial_habilitaCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var cambiarCostes = cursor.valueBuffer("cambiarcostes");
	if(!cambiarCostes) {
		this.child("fdbEliminarCostes").setValue(false);
		this.child("fdbEliminarCostes").setDisabled(true);
		this.child("fdbEliminarMargenes").setValue(false);
		this.child("fdbEliminarMargenes").setDisabled(true);
		this.child("fdbEmCosteProd").setValue("");
		this.child("fdbEmCosteProd").setDisabled(true);
		this.child("fdbEmMargenProd").setValue("");
		this.child("fdbEmMargenProd").setDisabled(true);
		this.child("fdbEmObservCosteProd").setValue("");
		this.child("fdbEmObservCosteProd").setDisabled(true);		
		this.child("fdbEmObservMargenProd").setValue("");
		this.child("fdbEmObservMargenProd").setDisabled(true);

		this.child("fdbEmTipoCosteProd").setValue("No cambiar");
		this.child("fdbEmTipoCosteProd").setDisabled(true);
		this.child("fdbAumentarCoste").setValue(false);
		this.child("fdbAumentarCoste").setDisabled(true);
		this.child("fdbPorAumCoste").setValue("");
		this.child("fdbPorAumCoste").setDisabled(true);
		this.child("fdbDisminuirCoste").setValue(false);
		this.child("fdbDisminuirCoste").setDisabled(true);	
		this.child("fdbPorDismCoste").setValue("");
		this.child("fdbPorDismCoste").setDisabled(true);	


		this.child("fdbEmTipoMargen").setValue("No cambiar");
		this.child("fdbEmTipoMargen").setDisabled(true);
		this.child("fdbAumentarMargen").setValue(false);
		this.child("fdbAumentarMargen").setDisabled(true);
		this.child("fdbPorAumMargen").setValue("");
		this.child("fdbPorAumMargen").setDisabled(true);
		this.child("fdbDisminuirMargen").setValue(false);
		this.child("fdbDisminuirMargen").setDisabled(true);	
		this.child("fdbPorDismMargen").setValue("");
		this.child("fdbPorDismMargen").setDisabled(true);	
		

	} else {
		var eliminarCostes = cursor.valueBuffer("eliminarcostes");
		var eliminarMargenes = cursor.valueBuffer("eliminarmargenes");
		var tipoCostes = cursor.valueBuffer("em_tipocoste");
		var tipoMargen = cursor.valueBuffer("em_tipomargen");
		var costeProd = cursor.valueBuffer("em_costeprod");
		var margenProd = cursor.valueBuffer("em_margenprod");
		if(_i.cambiarCostes_) {
			this.child("fdbEliminarCostes").setDisabled(false);
			if(eliminarCostes) {
				this.child("fdbEmCosteProd").setValue("");
				this.child("fdbEmCosteProd").setDisabled(true);
				this.child("fdbEmObservCosteProd").setValue("");
				this.child("fdbEmObservCosteProd").setDisabled(true);	

				this.child("fdbEmTipoCosteProd").setValue("No cambiar");
				this.child("fdbEmTipoCosteProd").setDisabled(true);
				this.child("fdbAumentarCoste").setValue(false);
				this.child("fdbAumentarCoste").setDisabled(true);
				this.child("fdbPorAumCoste").setValue("");
				this.child("fdbPorAumCoste").setDisabled(true);
				this.child("fdbDisminuirCoste").setValue(false);
				this.child("fdbDisminuirCoste").setDisabled(true);	
				this.child("fdbPorDismCoste").setValue("");
				this.child("fdbPorDismCoste").setDisabled(true);

			} else {
				if(tipoCostes == "Manual") {
					this.child("fdbEmCosteProd").setDisabled(false);			
					this.child("fdbEmObservCosteProd").setDisabled(false);	
					if(costeProd && costeProd != "") {						
						this.child("fdbAumentarCoste").setValue(false);				
						this.child("fdbAumentarCoste").setDisabled(true);
						this.child("fdbPorAumCoste").setValue("");
						this.child("fdbPorAumCoste").setDisabled(true);
						this.child("fdbDisminuirCoste").setValue(false);
						this.child("fdbDisminuirCoste").setDisabled(true);
						this.child("fdbPorDismCoste").setValue("");
						this.child("fdbPorDismCoste").setDisabled(true);
					}
				} else if (tipoCostes == "Heredado") {
					this.child("fdbAumentarCoste").setValue(false);
					this.child("fdbAumentarCoste").setDisabled(true);		
					this.child("fdbPorAumCoste").setValue("");
					this.child("fdbPorAumCoste").setDisabled(true);
					this.child("fdbDisminuirCoste").setValue(false);
					this.child("fdbDisminuirCoste").setDisabled(true);
					this.child("fdbPorDismCoste").setValue("");
					this.child("fdbPorDismCoste").setDisabled(true);
					this.child("fdbEmCosteProd").setValue("");
					this.child("fdbEmCosteProd").setDisabled(true);		
					this.child("fdbEmObservCosteProd").setValue("");	
					this.child("fdbEmObservCosteProd").setDisabled(true);	
				} else  {
					this.child("fdbAumentarCoste").setDisabled(false);		
					//this.child("fdbPorAumCoste").setDisabled(false);
					this.child("fdbDisminuirCoste").setDisabled(false);
					//this.child("fdbPorDismCoste").setDisabled(false);
					this.child("fdbEmCosteProd").setValue("");
					this.child("fdbEmCosteProd").setDisabled(true);		
					this.child("fdbEmObservCosteProd").setValue("");	
					this.child("fdbEmObservCosteProd").setDisabled(true);	
				}
				
				this.child("fdbEmTipoCosteProd").setDisabled(false);
			}	
		} else {
			this.child("fdbEliminarCostes").setDisabled(true);
			this.child("fdbEmCosteProd").setDisabled(true);
			this.child("fdbEmObservCosteProd").setDisabled(true);
			this.child("fdbEmTipoCosteProd").setDisabled(true);			
			this.child("fdbAumentarCoste").setDisabled(true);		
			this.child("fdbPorAumCoste").setDisabled(true);
			this.child("fdbDisminuirCoste").setDisabled(true);
			this.child("fdbPorDismCoste").setDisabled(true);	
		}
		if(_i.cambiarMargen_) {
			this.child("fdbEliminarMargenes").setDisabled(false);	
			if(eliminarMargenes) {
				this.child("fdbEmMargenProd").setValue("");
				this.child("fdbEmMargenProd").setDisabled(true);
				this.child("fdbEmObservMargenProd").setValue("");
				this.child("fdbEmObservMargenProd").setDisabled(true);
				this.child("fdbEmTipoMargen").setValue("No cambiar");
				this.child("fdbEmTipoMargen").setDisabled(true);
				this.child("fdbAumentarMargen").setValue(false);
				this.child("fdbAumentarMargen").setDisabled(true);
				this.child("fdbPorAumMargen").setValue("");
				this.child("fdbPorAumMargen").setDisabled(true);
				this.child("fdbDisminuirMargen").setValue(false);
				this.child("fdbDisminuirMargen").setDisabled(true);	
				this.child("fdbPorDismMargen").setValue("");
				this.child("fdbPorDismMargen").setDisabled(true);
			} else {
				if(tipoMargen == "Manual") {
					this.child("fdbEmMargenProd").setDisabled(false);
					this.child("fdbEmObservMargenProd").setDisabled(false);	
					if(margenProd && margenProd != "") {						
						this.child("fdbAumentarMargen").setValue(false);
						this.child("fdbAumentarMargen").setDisabled(true);
						this.child("fdbPorAumMargen").setValue("");		
						this.child("fdbPorAumMargen").setDisabled(true);	
						this.child("fdbDisminuirMargen").setValue(false);				
						this.child("fdbDisminuirMargen").setDisabled(true);
						this.child("fdbPorDismMargen").setValue("");
						this.child("fdbPorDismMargen").setDisabled(true);
					}
				} else if(tipoMargen == "Heredado") {
					this.child("fdbAumentarMargen").setValue(false);
					this.child("fdbAumentarMargen").setDisabled(true);	
					this.child("fdbPorAumMargen").setValue("");	
					this.child("fdbPorAumMargen").setDisabled(true);
					this.child("fdbDisminuirMargen").setValue(false);
					this.child("fdbDisminuirMargen").setDisabled(true);
					this.child("fdbPorDismMargen").setValue("");
					this.child("fdbPorDismMargen").setDisabled(true);
					this.child("fdbEmMargenProd").setValue("");
					this.child("fdbEmMargenProd").setDisabled(true);		
					this.child("fdbEmObservMargenProd").setValue("");
					this.child("fdbEmObservMargenProd").setDisabled(true);	
				} else {

					this.child("fdbAumentarMargen").setDisabled(false);		
					//this.child("fdbPorAumMargen").setDisabled(false);
					this.child("fdbDisminuirMargen").setDisabled(false);
					//this.child("fdbPorDismMargen").setDisabled(false);
					this.child("fdbEmMargenProd").setValue("");
					this.child("fdbEmMargenProd").setDisabled(true);		
					this.child("fdbEmObservMargenProd").setValue("");	
					this.child("fdbEmObservMargenProd").setDisabled(true);	

				}
				this.child("fdbEmTipoMargen").setDisabled(false);
			}
		} else {
			this.child("fdbEliminarMargenes").setDisabled(true);
			this.child("fdbEmMargenProd").setDisabled(true);
			this.child("fdbEmObservMargenProd").setDisabled(true);
			this.child("fdbEmTipoMargen").setDisabled(true);
			this.child("fdbAumentarMargen").setDisabled(true);
			this.child("fdbPorAumMargen").setDisabled(true);
			this.child("fdbDisminuirMargen").setDisabled(true);	
			this.child("fdbPorDismMargen").setDisabled(true);	
		}

	}

}

function oficial_ordenaCols()
{
	var cursor = this.cursor();
	var oCAncho = [["em_costeprod", 110],["em_margenprod", 120], ["em_fechacosteprod", 115], ["em_horacosteprod", 110], ["em_idusuariocosteprod", 120], ["em_observcosteprod", 170], ["em_observmargenprod", 175],["em_fechamargenprod", 120], ["em_horamargenprod", 115], ["em_idusuariomargenprod", 125]];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tdbArticulos").setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
	var oC = ["referencia", "descripcion", "codtamanoem", "emcolorgit", "codcolorem","pvp","em_costeprod","em_observcosteprod","em_margenprod", "em_observmargenprod","em_tipocoste","em_tipomargen","codimpuesto","codfamilia","secompra","sevende","variable","codbarras","tipocodbarras","imagen"];			
	this.child("tdbArticulos").setOrderCols(oC);
}

function oficial_habilitaCamposCostesProd()
{
	var _i = this.iface;
	var usuario = sys.nameUser();
	
	var q = new AQSqlQuery;	
	q.setSelect("em_cambiarmargenesprod,em_cambiarcostesprod");
	q.setFrom("usuarios");
	q.setWhere("idusuario = '" + usuario + "'");	
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		_i.cambiarMargen_ = q.value("em_cambiarmargenesprod");
		_i.cambiarCostes_ = q.value("em_cambiarcostesprod");		
	}

	if(!_i.cambiarCostes_ && !_i.cambiarMargen_) {
		this.child("fdbCambiarCostes").setDisabled(true);
	} else {
		this.child("fdbCambiarCostes").setDisabled(false);
		if(_i.cambiarCostes_) {
			this.child("fdbEliminarCostes").setDisabled(false);
			this.child("fdbEmCosteProd").setDisabled(false);
			this.child("fdbEmObservCosteProd").setDisabled(false);	
		} else {
			this.child("fdbEliminarCostes").setDisabled(true);
			this.child("fdbEmCosteProd").setDisabled(true);
			this.child("fdbEmObservCosteProd").setDisabled(true);
		}

		if(_i.cambiarMargen_) {			
			this.child("fdbEliminarMargenes").setDisabled(false);
			this.child("fdbEmMargenProd").setDisabled(false);
			this.child("fdbEmObservMargenProd").setDisabled(false);
		} else {
			this.child("fdbEliminarMargenes").setDisabled(true);
			this.child("fdbEmMargenProd").setDisabled(true);
			this.child("fdbEmObservMargenProd").setDisabled(true);
		}
	}

}

function oficial_habilitaAumentoCoste()
{
	
	var _i = this.iface;
	var cursor = this.cursor(); 
	var aumentarCostes = cursor.valueBuffer("aumentarcoste");	
	var disminuirCostes = cursor.valueBuffer("disminuircoste");		

	if(aumentarCostes) {
		if(disminuirCostes) {
			this.child("fdbDisminuirCoste").setValue(false);
			this.child("fdbPorDismCoste").setValue("");
		}
		this.child("fdbPorAumCoste").setDisabled(false);
		this.child("fdbEmCosteProd").setDisabled(true);
		this.child("fdbEmCosteProd").setValue("");
				
	} else {		
		this.child("fdbPorAumCoste").setDisabled(true);
		this.child("fdbPorAumCoste").setValue("");
		this.child("fdbEmCosteProd").setDisabled(false);
	}
}

function oficial_habilitaDisminuirCoste()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	var aumentarCostes = cursor.valueBuffer("aumentarcoste");	
	var disminuirCostes = cursor.valueBuffer("disminuircoste");		

	if(disminuirCostes) {
		if(aumentarCostes) {
			this.child("fdbAumentarCoste").setValue(false);	
			this.child("fdbPorAumCoste").setValue("");						
		}		
		this.child("fdbPorDismCoste").setDisabled(false);
		this.child("fdbEmCosteProd").setDisabled(true);
		this.child("fdbEmCosteProd").setValue("");					
	} else {
		this.child("fdbPorDismCoste").setDisabled(true);
		this.child("fdbPorDismCoste").setValue("");
		this.child("fdbEmCosteProd").setDisabled(false);
	}
}

function oficial_habilitaAumentoMargen()
{
	
	var _i = this.iface;
	var cursor = this.cursor();	
	var aumentarMargen = cursor.valueBuffer("aumentarmargen");	
	var disminuirMargen = cursor.valueBuffer("disminuirmargen");	

	if(aumentarMargen) {
		if(disminuirMargen) {
			this.child("fdbDisminuirMargen").setValue(false);
			this.child("fdbPorDismMargen").setValue("");
		}
		this.child("fdbPorAumMargen").setDisabled(false);	
		this.child("fdbEmMargenProd").setDisabled(true);
		this.child("fdbEmMargenProd").setValue("");			
	} else {
		this.child("fdbPorAumMargen").setDisabled(true);
		this.child("fdbPorAumMargen").setValue("");
		this.child("fdbEmMargenProd").setDisabled(false);
	}
}

function oficial_habilitaDisminuirMargen()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var aumentarMargen = cursor.valueBuffer("aumentarmargen");	
	var disminuirMargen = cursor.valueBuffer("disminuirmargen");	

	if(disminuirMargen) {
		if(aumentarMargen) {
			this.child("fdbAumentarMargen").setValue(false);	
			this.child("fdbPorAumMargen").setValue("");						
		}		
		this.child("fdbPorDismMargen").setDisabled(false);	
		this.child("fdbEmMargenProd").setDisabled(true);
		this.child("fdbEmMargenProd").setValue("");						
	} else {
		this.child("fdbPorDismMargen").setDisabled(true);
		this.child("fdbPorDismMargen").setValue("");
		this.child("fdbEmMargenProd").setDisabled(false);
	}

}

/*function oficial_tbnTodosSel_clicked()
{
	var _i = this.iface;	
	var filtro = "";
	if(_i.filtro_ == "") {
		filtro = "1=1"
	} else {
		filtro = _i.filtro_;
	}
	filtro += " order by referencia";

	var qryArt = new AQSqlQuery;	
	qryArt.setSelect("referencia");
	qryArt.setFrom("articulos");
	qryArt.setWhere(filtro);	
	if (!qryArt.exec()) {
		return false;
	}
	
	while (qryArt.next()) {
		
		this.child("tdbArticulos").setPrimaryKeyChecked(qryArt.value("referencia"), true);
	}
	
	this.child("tdbArticulos").refresh();
}


function oficial_tbnNingunoSel_clicked()
{
	this.child("tdbArticulos").clearChecked();
	this.child("tdbArticulos").refresh();
}*/
function oficial_procesaModoTabla(modo)
{
	var _i = this.iface;
	//debug("modo: "+modo);
	if (modo == 0) {
		_i.modoTabla_ = "Todos";		
		this.child("lblModo1").close();
		this.child("lblModo2").close();
		this.child("lblModo3").close();		
		this.child("lblIncluir").close();
		this.child("lblExcluir").close();
		this.child("lblExcluir2").close();
		this.child("lblTodos").show();
		this.child("tdbArticulos").clearChecked();
		this.child("tdbArticulos").setCheckColumnEnabled(false);		
		

	} else if(modo == 1) {
		_i.modoTabla_ = "Incluir";
		this.child("lblExcluir").close();
		this.child("lblExcluir2").close();
		this.child("lblTodos").close();
		this.child("lblModo1").show();
		this.child("lblModo2").show();
		this.child("lblModo3").show();		
		this.child("lblIncluir").show();		
		//this.child("tdbArticulos").setCheckColumnEnabled(false);
		//this.child("tdbArticulos").refresh(true, false);
		this.child("tdbArticulos").setCheckColumnEnabled(true);
		//this.child("tdbArticulos").setAliasCheckColumn("Incluir");		
	}else if (modo == 2) {
		_i.modoTabla_ = "Excluir";	
		this.child("lblIncluir").close();
		this.child("lblTodos").close();
		this.child("lblModo1").show();
		this.child("lblModo2").show();
		this.child("lblModo3").show();	
		this.child("lblExcluir").show();
		this.child("lblExcluir2").show();
		//this.child("tdbArticulos").setCheckColumnEnabled(false);	
		//this.child("tdbArticulos").refresh(true, false);
		this.child("tdbArticulos").setCheckColumnEnabled(true);
		//this.child("tdbArticulos").setAliasCheckColumn("Excluir");		
	}
	this.child("tdbArticulos").refresh(true, false);
	_i.ordenaCols();
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
