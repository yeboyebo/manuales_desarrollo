/***************************************************************************
                 em_coordinados.qs  -  description
                             -------------------
    begin                : mar nov 28 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN:String):String { return this.ctx.interna_calculateField(fN); }
	function validateForm() {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); } 	
	function aplicaFiltrosCampos() {
		return this.ctx.oficial_aplicaFiltrosCampos();
	}
	function dameFiltroColorDib() {
		return this.ctx.oficial_dameFiltroColorDib();
	}
	function dameFiltroColorCoord() {
		return this.ctx.oficial_dameFiltroColorCoord();
	}
	function dameFiltroFamilia() {
		return this.ctx.oficial_dameFiltroFamilia();
	}
	function dameFiltroSubFamilia() {
		return this.ctx.oficial_dameFiltroSubFamilia();
	}
	function dameFiltroTamanio() {
		return this.ctx.oficial_dameFiltroTamanio();
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function validaCampos() {
		return this.ctx.oficial_validaCampos();
	}
	function validaColorDib() {
		return this.ctx.oficial_validaColorDib();
	}
	function validaColorCoord() {
		return this.ctx.oficial_validaColorCoord();
	}
	function validaFamilia() {
		return this.ctx.oficial_validaFamilia();
	}
	function validaSubFamilia() {
		return this.ctx.oficial_validaSubFamilia();
	}
	function validaTamanio() {
		return this.ctx.oficial_validaTamanio();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El valor de --stockfis-- se calcula autom�ticamente para cada art�culo como la suma de existencias del art�culo en todos los almacenes.
\end */
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	
	_i.aplicaFiltrosCampos();
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			this.child("fdbCodDiseno").setValue(_i.calculateField("coddiseno"));
			cursor.setValueBuffer("numlinea",_i.calculateField("numlinea"));
			break;
		}
	}

	var etiquetas = [["fdbColorDib","Color principal a coordinar"],["fdbCodCoord","Dibujo coordinado"],["fdbColorCoord","Color coordinado"],["fdbCodColeccionEM","Colecci�n"],["fdbCodFamilia","Familia"],["fdbCodSubfamilia","Subfamilia"]];

	for(i=0; i<etiquetas.length;i++) {
		debug("\n\ncampo: "+etiquetas[i][0]);
		debug("etiqueta: "+etiquetas[i][1]);
		this.child(etiquetas[i][0]).setFieldAlias(etiquetas[i][1]);
	}

	

}

function interna_calculateField(fN)
{
	var cursor = this.cursor();
	var _i = this.iface;
	switch ( fN ) {
		case "coddiseno": {
			valor = AQUtil.sqlSelect("em_dibujos","coddiseno","coddibujoem = '" + cursor.valueBuffer("coddibujoem") + "'");
			if(!valor || valor == 0) {
				valor = "";
			}
			break;
		}
		case "numlinea": {
			var codDibujo = cursor.valueBuffer("coddibujoem");
			valor = parseInt(AQUtil.sqlSelect("em_coordinados", "numlinea", "coddibujoem = '" + codDibujo  + "' ORDER BY numlinea DESC"));
			if (isNaN(valor)) {
				valor = 0;
			}
			valor++;
			break;
		}
	}
	return valor; 
}

function interna_validateForm()
{
	var _i = this.iface;
	if(!_i.validaCampos()) {
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{	
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "codcoord": {
			var codCoord = cursor.valueBuffer("codcoord");
			if(!codCoord || codCoord == "") {
				this.child("fdbDibujoCoord").setValue("");	
			}
			var filtroColorCoord = _i.dameFiltroColorCoord();
			this.child("fdbColorCoord").setFilter(filtroColorCoord);
			break;
		}
		case "codsubfamilia": {
			var codSubfamilia = cursor.valueBuffer("codsubfamilia");
			if(!codSubfamilia || codSubfamilia == "") {
				this.child("fdbdescsubfamilia").setValue("");	
			}
			var filtroTamanio = _i.dameFiltroTamanio();			
			this.child("fdbCodTamanoEm").setFilter(filtroTamanio);	
			break;
		}
		case "codcoleccion": {
			var codColeccion = cursor.valueBuffer("codcoleccion");
			if(!codColeccion || codColeccion == "") {
				this.child("fdbDesColeccionEM").setValue("");	
			}			
		}
		case "codfamilia": {
			var codFamilia = cursor.valueBuffer("codfamilia");
			if(!codFamilia || codFamilia == "") {
				this.child("fdbDesFamilia").setValue("");	
			}				
		}
	}
}
function oficial_aplicaFiltrosCampos()
{
	var _i  = this.iface;

	var filtroColorDib = _i.dameFiltroColorDib();
	this.child("fdbColorDib").setFilter(filtroColorDib);

	var filtroColorCoord = _i.dameFiltroColorCoord();
	this.child("fdbColorCoord").setFilter(filtroColorCoord);

	var filtroFamilia = _i.dameFiltroFamilia();
	this.child("fdbCodFamilia").setFilter(filtroFamilia);

	var filtroSubFamilia = _i.dameFiltroSubFamilia();
	this.child("fdbCodSubfamilia").setFilter(filtroSubFamilia);

	var filtroTamanio = _i.dameFiltroTamanio();			
	this.child("fdbCodTamanoEm").setFilter(filtroTamanio);
}

function oficial_dameFiltroColorDib()
{
	var _i = this.iface;	
	//Debe ser uno de los colores asociados al dibujo de cabecera.	
	var filtro = "1=2"
	var cursor = this.cursor();	
	var codDibujoCab = cursor.valueBuffer("coddibujoem");		
	
	if(codDibujoCab && codDibujoCab != "") {
	 	filtro = "codcolorem IN (SELECT codcolorem from em_dibujoscolor where coddibujoem = '" + codDibujoCab + "')";
	}
	debug("filtro: "+filtro);
	return filtro;
}

function oficial_dameFiltroColorCoord()
{
	var _i = this.iface;	
	//Debe ser uno de los colores asociados al dibujo coordinado.	
	var filtro = "1=2"
	var cursor = this.cursor();	
	var codDibujoCoord = cursor.valueBuffer("codcoord");	
	if(codDibujoCoord && codDibujoCoord != "") {
	 	filtro = "codcolorem IN (SELECT codcolorem from em_dibujoscolor where coddibujoem = '" + codDibujoCoord + "')";
	}	
	return filtro;
}

function oficial_dameFiltroFamilia()
{
	var _i = this.iface;	
	//Debe ser uno de los colores asociados al dibujo de cabecera.	
	var filtro = "1=2"
	var cursor = this.cursor();	
	var codDibujoCab = cursor.valueBuffer("coddibujoem");		
	
	if(codDibujoCab && codDibujoCab != "") {
	 	filtro = "codfamilia IN (SELECT f.codfamilia from em_dibujossubfam sf inner join subfamilias f on f.codsubfamilia = sf.codsubfamilia where sf.coddibujoem = '" + codDibujoCab + "')";
	}	
	return filtro;
}

function oficial_dameFiltroSubFamilia()
{
	var _i = this.iface;	
	//Debe ser uno de los colores asociados al dibujo de cabecera.	
	var filtro = "1=2"
	var cursor = this.cursor();	
	var codDibujoCab = cursor.valueBuffer("coddibujoem");		
	
	if(codDibujoCab && codDibujoCab != "") {
	 	filtro = "codsubfamilia IN (SELECT codsubfamilia from em_dibujossubfam where coddibujoem = '" + codDibujoCab + "')";
	}	
	return filtro;
}

function oficial_dameFiltroTamanio()
{
	var _i = this.iface;	
	//Debe ser uno de los colores asociados al dibujo de cabecera.	
	var filtro = "1=1"
	var cursor = this.cursor();	
	var codSubFamilia = cursor.valueBuffer("codsubfamilia");		
	var codDibujo = cursor.valueBuffer("coddibujoem");
	if(codSubFamilia && codSubFamilia != "") {	 	
		filtro = "codtamanoem IN (select d.codtamanoem from em_dibujostamsub d inner join em_tamanossubfam t on t.codtamanoem=d.codtamanoem and t.codsubfamilia = d.codsubfamilia where d.codsubfamilia = '" + codSubFamilia + "' and d.coddibujoem = '" + codDibujo + "') and codsubfamilia = '" + codSubFamilia + "'";		
	}
	debug("filtro: "+filtro);
	return filtro;
}

function oficial_validaCampos()
{
	var _i = this.iface;

	if(!_i.validaColorDib()) {
		return false;
	}
	if(!_i.validaColorCoord()) {
		return false;
	}
	if(!_i.validaFamilia()) {
		return false;
	}
	if(!_i.validaSubFamilia()) {
		return false;
	}	
	if(!_i.validaTamanio()) {
		return false;
	}	

	return true;
}

function oficial_validaColorDib()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var colorDibujo = cursor.valueBuffer("colordib");			
	if(colorDibujo && colorDibujo != "") {	 	
		var codDibujoCab = cursor.valueBuffer("coddibujoem");
		if(codDibujoCab && codDibujoCab != "") {	
			if(!AQUtil.sqlSelect("em_dibujoscolor", "codcolorem", "codcolorem = '" + colorDibujo + "' AND coddibujoem = '" + codDibujoCab + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("El color principal debe ser uno de los colores asociados al dibujo de cabecera."),"warn",this);
				return false;
			}	 		
		}
	}
	return true;
}

function oficial_validaColorCoord()
{
	var _i = this.iface;
	var cursor = this.cursor();	

	var colorCoord = cursor.valueBuffer("colorcoord");			
	if(colorCoord && colorCoord != "") {		 	
		var codDibujoCoord = cursor.valueBuffer("codcoord");
		if(codDibujoCoord && codDibujoCoord != "") {	
			if(!AQUtil.sqlSelect("em_dibujoscolor", "codcolorem", "codcolorem = '" + colorCoord + "' AND coddibujoem = '" + codDibujoCoord + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("El color coordinado debe ser uno de los colores asociados al dibujo coordinado."),"warn",this);
				return false;
			}	 		
		}
	
	}
	return true;
}


function oficial_validaFamilia()
{
	//Si la familia seleccionada no est� asociada a ninguna de las subfamilias asociadas al dibujo de cabecera, se muestra el aviso: Ha seleccionado una FAMILIA que no forma parte del dibujo todav�a, puede continuar, pero revise que es correcto.
	var _i = this.iface;
	var cursor = this.cursor();	
	var codFamilia = cursor.valueBuffer("codfamilia");
	if(codFamilia && codFamilia != "") {

		var codDibujoCab = cursor.valueBuffer("coddibujoem");			
		if(codDibujoCab && codDibujoCab != "") {
	 		
			if(!AQUtil.sqlSelect("em_dibujossubfam sf inner join subfamilias f on f.codsubfamilia = sf.codsubfamilia", "codfamilia", "sf.coddibujoem = '" + codDibujoCab + "' and f.codfamilia = '" + codFamilia + "'","em_dibujossubfam,subfamilias")) {
				flfactppal.iface.ponMsgError(sys.translate("Ha seleccionado una FAMILIA que no forma parte del dibujo todav�a, puede continuar, pero revise que es correcto."),"info",this);
			}	 		
		}
	}
	return true;
}

function oficial_validaSubFamilia()
{
	//Si la familia seleccionada no est� asociada a ninguna de las subfamilias asociadas al dibujo de cabecera, se muestra el aviso: Ha seleccionado una FAMILIA que no forma parte del dibujo todav�a, puede continuar, pero revise que es correcto.
	var _i = this.iface;
	var cursor = this.cursor();	
	var codSubFamilia = cursor.valueBuffer("codsubfamilia");
	if(codSubFamilia && codSubFamilia != "") {

		var codDibujoCab = cursor.valueBuffer("coddibujoem");			
		if(codDibujoCab && codDibujoCab != "") {
	 		
			if(!AQUtil.sqlSelect("em_dibujossubfam", "codsubfamilia", "coddibujoem = '" + codDibujoCab + "' and codsubfamilia = '" + codSubFamilia + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Ha seleccionado una SUBFAMILIA que no forma parte del dibujo todav�a, puede continuar, pero revise que es correcto."),"info",this);
			}	 		
		}
	}
	return true;
}

function oficial_validaTamanio()
{
	var _i = this.iface;	
	var cursor = this.cursor();	
	var codSubFamilia = cursor.valueBuffer("codsubfamilia");		
	var codDibujo = cursor.valueBuffer("coddibujoem");
	var codTamanio = cursor.valueBuffer("codtamanoem");
	if(codTamanio && codTamanio != "") {	 	
		if(codSubFamilia && codSubFamilia != "") {
			if(!AQUtil.sqlSelect("em_dibujostamsub d inner join em_tamanossubfam t on t.codtamanoem=d.codtamanoem and t.codsubfamilia = d.codsubfamilia","d.codtamanoem","d.codsubfamilia = '" + codSubFamilia + "' and d.coddibujoem = '" + codDibujo + "' and d.codtamanoem = '" + codTamanio + "'","em_dibujostamsub,em_tamanossubfam")) {
				flfactppal.iface.ponMsgError(sys.translate("El tamanio no pertenece a la subfamilia del dibujo."),"warn",this);
				return false;
			}

			 
		}	
	}
	return true;
}



//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////