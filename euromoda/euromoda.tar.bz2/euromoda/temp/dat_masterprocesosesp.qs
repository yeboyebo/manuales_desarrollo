
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
  var aUsuarios_;
  var aTamanos_, aTEmbalaje_, aColores_, aRutas_, aProv_;
  var curL_, curMS_;

  function euromoda(context)
  {
    oficial(context);
  }
  function informarRutasProcesos()
  {
    return this.ctx.euromoda_informarRutasProcesos();
  }
  function ejecutarFuncion()
  {
    return this.ctx.euromoda_ejecutarFuncion();
  }
  function valorRuta(indice, valor)
  {
    return this.ctx.euromoda_valorRuta(indice, valor);
  }
  function dameLoginUsuaro(n)
  {
    return this.ctx.euromoda_dameLoginUsuaro(n);
  }
  function provGit2Nav(codProv)
  {
    return this.ctx.euromoda_provGit2Nav(codProv);
  }
  function crearRegStocks()
  {
    return this.ctx.euromoda_crearRegStocks();
  }
  function procesarPedidos()
  {
    return this.ctx.euromoda_procesarPedidos();
  }
  function creaLoteStock(curStock, cantidad, fechaReg)
  {
    return this.ctx.euromoda_creaLoteStock(curStock, cantidad, fechaReg);
  }
  function dameCodLote(prefijo)
  {
    return this.ctx.euromoda_dameCodLote(prefijo);
  }
  function dameArrayTamanos(i)
  {
    return this.ctx.euromoda_dameArrayTamanos(i);
  }
  function dameArrayTEmbalaje(i)
  {
    return this.ctx.euromoda_dameArrayTEmbalaje(i);
  }
  function dameArrayColor(i)
  {
    return this.ctx.euromoda_dameArrayColor(i);
  }
  function crearMovPiezas()
  {
    return this.ctx.euromoda_crearMovPiezas();
  }
  function actualizarCodProveedorEnDocumentos()
  {
    this.ctx.euromoda_actualizarCodProveedorEnDocumentos();
  }
  function actualizarDocsFacturacion(tabla, tablaLineas, campoID, msg)
  {
    this.ctx.euromoda_actualizarDocsFacturacion(tabla, tablaLineas, campoID, msg);
  }
  function actualizarAlbaranes()
  {
    this.ctx.euromoda_actualizarAlbaranes();
  }
  function actualizarFacturas()
  {
    this.ctx.euromoda_actualizarFacturas();
  }
  function actualizarAmortizaciones()
  {
    this.ctx.euromoda_actualizarAmortizaciones();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_informarRutasProcesos()
{
  var aR = [["", ""], ["PT-CV-CHM-AUX-DC-CO-AN", "PT-CO-DC"],
            ["PT-CV-CHJ24-AUX-DC-CO-AN", "PT-CO-DC"],
            ["PT-CV-CHJ1-AUX-DC-CO-AN", "PT-J1-DC"],
            ["PT-CV-AV1Y2-AUX-DC-CO-AN", "PT-ACE-DC"],
            ["PT-CV-CHJ1-CHJ2Y4-AUX-DC-CO-AN", "PT-CO-DC"],
            ["PT- CV-AM2-AUX-DC-CO-AN", "PT-ACO-DC"],
            ["PT-CV-CHJ234-AUX-DC-CO-AN", "PT-CO-DC"],
            ["PT-AM1Y3-AUX-DC-AN", "PT-ACO-DC"],
            ["PT-CHMC-AUX-DC-CO-AN", "PT-CO-DC"],
            ["PT-AUX-DC-CO-AN", "PT-DC"],
            ["PT-CV-CHMC-CHJ2Y4-AUX-DC-CO-AN", "PT-CO-DC"],
            ["PT-CV-AM3-AUX-DC-AN", "PT-CO-DC"],
            ["PT-CV-CH24-AUX-DC-CO-AEX", "PT-CO-DC"],
            ["PT-CV-CHMC-CHJ2Y4-AUX-DC-CO-AEX", "PT-CO-DC"],
            ["PT-CV-CH2Y4+3-AUX-DC-CO-AEX", "PT-CO-DC"],
            ["PT-CV-CHM-AUX-DC-CO-AEX", "PT-CO-DC"],
            ["PT-CV-CHJ1-AUX-DC-CO-AEX", "PT-J1-DC"],
            ["PT-AV1y2-CV-CHJ24-AUX-DC-CO-AEX", "PT-ACE-DC"],
            ["PT-AM1-CV-CH-AUX-DC-CO-AEX", "PT-ACO-DC"],
            ["PT-AM1-AUX-DC-CO-AEX", "PT-ACO-DC"],
            ["PT-AM1-CV-CHJ2Y4-AUX-DC-CO-AEX", "PT-ACO-DC"],
            ["PT-AV1Y2-AUX-DC-CO-AEX", "PT-ACE-DC"],
            ["PT-CV-AM2-AUX-DC-CO-AEX", "PT-ACO-DC"],
            ["PT-CV-AM3-AUX-DC-CO-AEX", "PT-ACO-DC"],
            ["PT-CV-CHJ1-CHJ2Y4-AUX-DC-CO-AEX", "PT-CO-DC"],
            ["AUX-DC-CO-AN", "PT-J1-DC"],
            ["AUX-DC-AN", "PT-DC"]];
  /**
  Ruta 1: PT-ACE-DC = Preparacion Tejido - Acolchado Cerrado - Distribuci�n a Confecciones
  Ruta 2: PT-ACO-DC = Preparacion Tejido - Acolchado Continuo - Distribuci�n a Confecciones
  Ruta 3: PT-CO-DC = Preparacion Tejido - Corte - Distribuci�n a Confecciones
  Ruta 4: PT-J1-DC = Preparacion Tejido - Jofesa1 - Distribuci�n a Confecciones
  Ruta 5: PT-DC = Preparacion Tejido - Distribuci�n a Confecciones
  */

  var idRuta;
  var curArt = new FLSqlCursor("articulos");
  curArt.setForwardOnly(true);
  curArt.setActivatedCommitActions(false);
  curArt.setActivatedCheckIntegrity(false);
  curArt.select("em_idruta IS NOT NULL");
  AQUtil.createProgressDialog(sys.translate("Actualizando rutas..."), curArt.size());
  var p = 0;
  while (curArt.next()) {
    AQUtil.setProgress(p++);
    curArt.setModeAccess(curArt.Edit);
    curArt.refreshBuffer();
    idRuta = curArt.valueBuffer("em_idruta");
    curArt.setValueBuffer("em_ruta", aR[idRuta][0]);
    curArt.setValueBuffer("fabricado", true);
    curArt.setValueBuffer("tipostock", "Lotes");
    curArt.setValueBuffer("secompra", false);
    curArt.setValueBuffer("idtipoproceso", aR[idRuta][1]);
    if (!curArt.commitBuffer()) {
      AQUtil.destroyProgressDialog();
      MessageBox.warning(sys.translate("Error al actualizar la ruta para el art�culo %1").arg(curArt.valueBuffer("referencia")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }
  AQUtil.destroyProgressDialog();
  MessageBox.information(sys.translate("Proceso completado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
  return true;
}

function euromoda_valorRuta(indice, valor)
{
  if (!indice) {
    return "";
  }
  var _i = this.iface;
  if (!_i.aRutas_) {
    _i.aRutas_ = [["", ""], ["PT-CV-CHM-AUX-DC-CO-AN", "PT-CO-DC"],
                  ["PT-CV-CHJ24-AUX-DC-CO-AN", "PT-CO-DC"],
                  ["PT-CV-CHJ1-AUX-DC-CO-AN", "PT-J1-DC"],
                  ["PT-CV-AV1Y2-AUX-DC-CO-AN", "PT-ACE-DC"],
                  ["PT-CV-CHJ1-CHJ2Y4-AUX-DC-CO-AN", "PT-CO-DC"],
                  ["PT- CV-AM2-AUX-DC-CO-AN", "PT-ACO-DC"],
                  ["PT-CV-CHJ234-AUX-DC-CO-AN", "PT-CO-DC"],
                  ["PT-AM1Y3-AUX-DC-AN", "PT-ACO-DC"],
                  ["PT-CHMC-AUX-DC-CO-AN", "PT-CO-DC"],
                  ["PT-AUX-DC-CO-AN", "PT-DC"],
                  ["PT-CV-CHMC-CHJ2Y4-AUX-DC-CO-AN", "PT-CO-DC"],
                  ["PT-CV-AM3-AUX-DC-AN", "PT-CO-DC"],
                  ["PT-CV-CH24-AUX-DC-CO-AEX", "PT-CO-DC"],
                  ["PT-CV-CHMC-CHJ2Y4-AUX-DC-CO-AEX", "PT-CO-DC"],
                  ["PT-CV-CH2Y4+3-AUX-DC-CO-AEX", "PT-CO-DC"],
                  ["PT-CV-CHM-AUX-DC-CO-AEX", "PT-CO-DC"],
                  ["PT-CV-CHJ1-AUX-DC-CO-AEX", "PT-J1-DC"],
                  ["PT-AV1y2-CV-CHJ24-AUX-DC-CO-AEX", "PT-ACE-DC"],
                  ["PT-AM1-CV-CH-AUX-DC-CO-AEX", "PT-ACO-DC"],
                  ["PT-AM1-AUX-DC-CO-AEX", "PT-ACO-DC"],
                  ["PT-AM1-CV-CHJ2Y4-AUX-DC-CO-AEX", "PT-ACO-DC"],
                  ["PT-AV1Y2-AUX-DC-CO-AEX", "PT-ACE-DC"],
                  ["PT-CV-AM2-AUX-DC-CO-AEX", "PT-ACO-DC"],
                  ["PT-CV-AM3-AUX-DC-CO-AEX", "PT-ACO-DC"],
                  ["PT-CV-CHJ1-CHJ2Y4-AUX-DC-CO-AEX", "PT-CO-DC"],
                  ["AUX-DC-CO-AN", "PT-J1-DC"],
                  ["AUX-DC-AN", "PT-DC"]];
  }
  return valor == "ruta" ? _i.aRutas_[indice][0] : _i.aRutas_[indice][1];
}

function euromoda_ejecutarFuncion()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var funcion = cursor.valueBuffer("funcion");

  switch (funcion) {
    case "informarRutasProcesos": {
      if (!_i.informarRutasProcesos()) {
        return false;
      }
      break;
    }
    case "crearRegStocks": {
      if (!_i.crearRegStocks()) {
        return false;
      }
      break;
    }
    case "procesarPedidos": {
      if (!_i.procesarPedidos()) {
        return false;
      }
    }
    case "crearMovPiezas": {
      if (!_i.crearMovPiezas()) {
        return false;
      }
      break;
    }
    case "actualizarCodProveedorDocs": {
      _i.actualizarCodProveedorEnDocumentos();
      return true;
    }
    case "actualizarAlbaranes": {
      _i.actualizarAlbaranes();
      return true;
    }
    case "actualizarFacturas": {
      _i.actualizarFacturas();
      return true;
    }
    case "actualizarAmortizaciones": {
      _i.actualizarAmortizaciones();
      return true;
    }
    default: {
      if (!_i.__ejecutarFuncion()) {
        return false;
      }
    }
  }
  return true;
}

function euromoda_crearMovPiezas()
{
  var _i = this.iface;
  var hoy = new Date;
  var hora = hoy.toString().right(8);

  var q = new FLSqlQuery();
  q.setTablesList("lotesstock");
  q.setSelect("codlote, referencia, canlote, codalmacen, msalidas");
  q.setFrom("lotesstock");
  q.setWhere("(codlote LIKE 'PZ%' OR codlote LIKE 'PT%') AND codalmacen IS NOT NULL");
  q.setForwardOnly(true);
  if (!q.exec()) {
    return false;
  }
  AQUtil.createProgressDialog(sys.translate("Creando movimientos para piezas"), q.size());

  _i.curMS_ = new FLSqlCursor("movistock");
  _i.curMS_.setActivatedCommitActions(false);
  _i.curMS_.setActivatedCheckIntegrity(false);

  var curMS = _i.curMS_;
  var idStock, referencia, codAlmacen, codLote, paso = 0;
  while (q.next()) {
    AQUtil.setProgress(paso++);
    referencia = q.value("referencia");
    codAlmacen = q.value("codalmacen");
    codLote = q.value("codlote");

    curMS.select("codlote = '" + codLote + "' AND regularizacion");
    if (curMS.first()) {
      curMS.setModeAccess(curMS.Edit);
      curMS.refreshBuffer();
    } else {
      curMS.setModeAccess(curMS.Insert);
      curMS.refreshBuffer();
      curMS.setValueBuffer("referencia", referencia);
      curMS.setValueBuffer("codlote", codLote);
      curMS.setValueBuffer("regularizacion", true);
      curMS.setValueBuffer("estado", "HECHO");
			curMS.setValueBuffer("concepto", "Migraci�n inicial");
      idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
      if (!idStock) {
        var oA = new Object;
        oA.referencia = referencia;
        idStock = flfactalma.iface.pub_crearStock(codAlmacen, oA);
      }
      curMS.setValueBuffer("idstock", idStock);
    }
    curMS.setValueBuffer("cantidad", q.value("canlote"));
    curMS.setValueBuffer("fechareal", hoy);
    curMS.setValueBuffer("horareal", hora);
		curMS.setValueBuffer("concepto", sys.translate("Migraci�n inicial"));
    if (!curMS.commitBuffer()) {
      AQUtil.destroyProgressDialog();
      return false;
    }
    
    /// Movimiento de salida
		var mSalidas = q.value("msalidas");
		if (mSalidas && mSalidas != 0) {
			mSalidas *= -1;
			curMS.setModeAccess(curMS.Insert);
			curMS.refreshBuffer();
			curMS.setValueBuffer("referencia", referencia);
			curMS.setValueBuffer("codlote", codLote);
			curMS.setValueBuffer("regularizacion", true);
			curMS.setValueBuffer("estado", "HECHO");
			curMS.setValueBuffer("concepto", "Migraci�n inicial");
			idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
			if (!idStock) {
				var oA = new Object;
				oA.referencia = referencia;
				idStock = flfactalma.iface.pub_crearStock(codAlmacen, oA);
			}
			curMS.setValueBuffer("idstock", idStock);
			curMS.setValueBuffer("cantidad", mSalidas);
			curMS.setValueBuffer("fechareal", hoy);
			curMS.setValueBuffer("horareal", hora);
			curMS.setValueBuffer("concepto", sys.translate("Migraci�n inicial"));
    	if (!curMS.commitBuffer()) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
  }
  AQUtil.destroyProgressDialog();
  return true;
}

function euromoda_procesarPedidos()
{
  var _i = this.iface;
  var paso = 0;
  var curLP = new FLSqlCursor("lineaspedidoscli");
  curLP.select("1 = 1");
  AQUtil.createProgressDialog(sys.translate("Procesando pedidos de cliente"), curLP.size());
  while (curLP.next()) {
    debug("paso " + paso);
    AQUtil.setProgress(paso++);
    curLP.setModeAccess(curLP.Edit);
    curLP.refreshBuffer();
    if (!flfactalma.iface.borrarEstructura(curLP)) {
      AQUtil.destroyProgressDialog();
      MessageBox.warning(sys.translate("Error 1 al procesar la l�nea %1").arg(curLP.valueBuffer("idlinea")));
      return false;
    }
    if (!flfactalma.iface.generarEstructura(curLP)) {
      AQUtil.destroyProgressDialog();
      MessageBox.warning(sys.translate("Error 2 al procesar la l�nea %1").arg(curLP.valueBuffer("idlinea")));
      return false;
    }
  }
  AQUtil.destroyProgressDialog();
  MessageBox.information(sys.translate("Proceso completado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
}

function euromoda_crearRegStocks()
{
  var _i = this.iface;
  var curStock = new FLSqlCursor("stocks");
  var curRS = new FLSqlCursor("lineasregstocks");
  curRS.setActivatedCommitActions(false);
  curRS.setActivatedCheckIntegrity(false);
  curStock.setActivatedCommitActions(false);
  curStock.setActivatedCheckIntegrity(false);

  var hoy = new Date;
  var fechaReg = "2012-03-01";
  var hora = hoy.toString().right(8);
  var cantidad, idStock, paso = 0;
  var motivo = sys.translate("Migraci�n inicial");
  curStock.select("1 = 1");
  AQUtil.createProgressDialog(sys.translate("Creando regularizaciones de stock"), curStock.size());

  var referencia;
  while (curStock.next()) {
    AQUtil.setProgress(paso++);
    curStock.setModeAccess(curStock.Edit);
    curStock.refreshBuffer();
    referencia = curStock.valueBuffer("referencia");
    cantidad = curStock.valueBuffer("cantidad");
    if (cantidad == 0) {
      continue;
    }
    idStock = curStock.valueBuffer("idstock");//pineboo 21-08-2019
    if (cantidad > 0) {
			curStock.setValueBuffer("disponible", cantidad);
		} else {
			curStock.setValueBuffer("afaltas", cantidad * -1);
		}
//     if (AQUtil.sqlSelect("articulos", "em_tipoarticulo", "referencia = '" + referencia + "' AND tipostock = 'Lotes'") == "Producto") {
//       if (!_i.creaLoteStock(curStock, cantidad, fechaReg)) {
//         AQUtil.destroyProgressDialog();
//         return false;
//       }
//     } else {
      curRS.setModeAccess(curRS.Insert);
      curRS.refreshBuffer();
      curRS.setValueBuffer("idstock", idStock);
      curRS.setValueBuffer("fecha", fechaReg);
      curRS.setValueBuffer("hora", hora);
      curRS.setValueBuffer("cantidadini", 0);
      curRS.setValueBuffer("cantidadfin", cantidad);
      curRS.setValueBuffer("motivo", motivo);
      if (!curRS.commitBuffer()) {
        AQUtil.destroyProgressDialog();
        return false;
      }
      curStock.setValueBuffer("fechaultreg", fechaReg);
      curStock.setValueBuffer("horaultreg", hora);
      curStock.setValueBuffer("cantidadultreg", cantidad);
//     }
    if (!curStock.commitBuffer()) {
      AQUtil.destroyProgressDialog();
      return false;
    }
  }
  AQUtil.destroyProgressDialog();
  return true;
}

function euromoda_creaLoteStock(curStock, cantidad, fechaReg)
{
  var _i = this.iface;
  var codLote;
  var hoy = new Date;
  var ahora = hoy.toString().right(8);
  var referencia = curStock.valueBuffer("referencia");
  var codAlmacen = curStock.valueBuffer("codalmacen");
  debug("euromoda_creaLoteStock + " + referencia + " + " + codAlmacen);
  var idStock = curStock.valueBuffer("idstock");
  if (!_i.curL_) {
    _i.curL_ = new FLSqlCursor("lotesstock");
    _i.curL_.setActivatedCommitActions(false);
    _i.curL_.setActivatedCheckIntegrity(false);
  }
  var curL = _i.curL_;
  curL.select("referencia = '" + curStock.valueBuffer("referencia") + "' AND codalmacen = '" + codAlmacen + "' AND codlote LIKE 'MI%'");
  if (!curL.first()) {
    codLote = _i.dameCodLote("MI");
    curL.setModeAccess(curL.Insert);
    curL.refreshBuffer();
    curL.setValueBuffer("codlote", codLote);
    curL.setValueBuffer("referencia", referencia);
    curL.setValueBuffer("codalmacen", codAlmacen);
    curL.setValueBuffer("estado", "TERMINADO");
    curL.setValueBuffer("crearterminado", true);
  } else {
    curL.setModeAccess(curL.Edit);
    curL.refreshBuffer();
    codLote = curL.valueBuffer("codlote");
  }
  curL.setValueBuffer("canlote", cantidad);
  curL.setValueBuffer("cantotal", cantidad);
  curL.setValueBuffer("candisponible", cantidad);
  if (!curL.commitBuffer()) {
    return false;
  }
  debug("codLote = " + codLote);
  if (!_i.curMS_) {
    _i.curMS_ = new FLSqlCursor("movistock");
    _i.curMS_.setActivatedCommitActions(false);
    _i.curMS_.setActivatedCheckIntegrity(false);
  }
  var curMS = _i.curMS_;
  curMS.select("codlote = '" + codLote + "' AND regularizacion");
  if (curMS.first()) {
    curMS.setModeAccess(curMS.Edit);
    curMS.refreshBuffer();
  } else {
    curMS.setModeAccess(curMS.Insert);
    curMS.refreshBuffer();
    curMS.setValueBuffer("referencia", referencia);
    curMS.setValueBuffer("codlote", codLote);
    curMS.setValueBuffer("regularizacion", true);
    curMS.setValueBuffer("estado", "HECHO");
    curMS.setValueBuffer("idstock", idStock);
		curMS.setValueBuffer("concepto", "Migraci�n inicial");
  }
  curMS.setValueBuffer("cantidad", cantidad);
  curMS.setValueBuffer("fechareal", fechaReg);
  curMS.setValueBuffer("horareal", ahora);
  if (!curMS.commitBuffer()) {
    return false;
  }
  return true;
}

function euromoda_dameCodLote(prefijo)
{
  var util = new FLUtil;
  var ultimoLote: Number = util.sqlSelect("secuenciaslotes", "valor", "prefijo = '" + prefijo + "'");

  if (!ultimoLote) {
    var idUltimo = util.sqlSelect("lotesstock", "codlote", "codlote LIKE '" + prefijo + "%' ORDER BY codlote DESC");
    ultimoLote = idUltimo ? parseFloat(idUltimo.right(8)) : 0;
    ultimoLote += 1;
    AQSql.insert("secuenciaslotes", ["prefijo", "valor"], [prefijo, ultimoLote]);
  } else {
    ultimoLote += 1;
    AQSql.update("secuenciaslotes", ["valor"], [ultimoLote], "prefijo = '" + prefijo + "'");
  }
  var id = prefijo + flfacturac.iface.pub_cerosIzquierda((ultimoLote).toString(), 8);
  return id;
}

function euromoda_dameLoginUsuaro(n)
{
  var _i = this.iface;
  if (!_i.aUsuarios_) {
    _i.aUsuarios_ = new Object;
    _i.aUsuarios_["24"] = "ITEM";
    _i.aUsuarios_["87"] = "ADMIN";
    _i.aUsuarios_["155"] = "MIGUEL";
    _i.aUsuarios_["156"] = "HELENA";
    _i.aUsuarios_["157"] = "JOSETE";
    _i.aUsuarios_["158"] = "DANI";
    _i.aUsuarios_["159"] = "LUIS";
    _i.aUsuarios_["160"] = "JUANJO BENEYTO";
    _i.aUsuarios_["161"] = "VICENTE BALDO";
    _i.aUsuarios_["162"] = "GONZALO CASTELLO";
    _i.aUsuarios_["163"] = "SOFIA";
    _i.aUsuarios_["164"] = "JUAN IVAN";
    _i.aUsuarios_["165"] = "MARIA JOSE";
    _i.aUsuarios_["166"] = "ESPE AGULLO";
    _i.aUsuarios_["168"] = "PACO HURTADO";
    _i.aUsuarios_["169"] = "ANTONIO";
    _i.aUsuarios_["170"] = "MERCHE";
    _i.aUsuarios_["171"] = "SALOME";
    _i.aUsuarios_["172"] = "PEPE";
    _i.aUsuarios_["173"] = "OSCAR";
    _i.aUsuarios_["183"] = "Xelo";
    _i.aUsuarios_["178"] = "ESTHER";
    _i.aUsuarios_["179"] = "TIBI";
    _i.aUsuarios_["180"] = "JAVIER BENEYTO";
    _i.aUsuarios_["181"] = "RAFA PENADES";
    _i.aUsuarios_["182"] = "PILI";
    _i.aUsuarios_["184"] = "SONIA";
    _i.aUsuarios_["185"] = "PEPE PEREZ";
    _i.aUsuarios_["186"] = "JUANJO VICEDO";
    _i.aUsuarios_["187"] = "NURIA";
    _i.aUsuarios_["188"] = "ALEX";
    _i.aUsuarios_["189"] = "ANA";
    _i.aUsuarios_["190"] = "MARI";
    _i.aUsuarios_["191"] = "sandra";
    _i.aUsuarios_["192"] = "ISABEL";
    _i.aUsuarios_["193"] = "M Carmen";
    _i.aUsuarios_["194"] = "FRAN";
  }
  if (n in _i.aUsuarios_) {
    return _i.aUsuarios_[n].toLowerCase();
  } else {
    return "ITEM";
  }
}

function euromoda_provGit2Nav(codProv)
{
  var _i = this.iface;
  if (!_i.aProv_) {
    _i.aProv_ = new Object;
    _i.aProv_["1"] = "1";
    _i.aProv_["2"] = "685";
    _i.aProv_["3"] = "485";
    _i.aProv_["4"] = "664";
    _i.aProv_["5"] = "5";
    _i.aProv_["6"] = "6";
    _i.aProv_["7"] = "7";
    _i.aProv_["8"] = "490";
    _i.aProv_["9"] = "";
    _i.aProv_["10"] = "233";
    _i.aProv_["11"] = "302";
    _i.aProv_["12"] = "491";
    _i.aProv_["13"] = "1171";
    _i.aProv_["14"] = "891";
    _i.aProv_["15"] = "832";
    _i.aProv_["16"] = "552";
    _i.aProv_["17"] = "525";
    _i.aProv_["18"] = "409";
    _i.aProv_["19"] = "19";
    _i.aProv_["20"] = "566";
    _i.aProv_["21"] = "1154";
    _i.aProv_["22"] = "471";
    _i.aProv_["23"] = "512";
    _i.aProv_["24"] = "134";
    _i.aProv_["25"] = "255";
    _i.aProv_["26"] = "";
    _i.aProv_["27"] = "15";
    _i.aProv_["28"] = "781";
    _i.aProv_["29"] = "274";
    _i.aProv_["30"] = "707";
    _i.aProv_["31"] = "105";
    _i.aProv_["32"] = "284";
    _i.aProv_["33"] = "303";
    _i.aProv_["34"] = "862";
    _i.aProv_["35"] = "852";
    _i.aProv_["36"] = "582";
    _i.aProv_["37"] = "669";
    _i.aProv_["38"] = "836";
    _i.aProv_["39"] = "247";
    _i.aProv_["40"] = "572";
    _i.aProv_["41"] = "309";
    _i.aProv_["42"] = "136";
    _i.aProv_["43"] = "295";
    _i.aProv_["44"] = "38";
    _i.aProv_["45"] = "76";
    _i.aProv_["46"] = "254";
    _i.aProv_["47"] = "124";
    _i.aProv_["48"] = "1282";
    _i.aProv_["49"] = "1191";
    _i.aProv_["50"] = "309";
    _i.aProv_["51"] = "94";
    _i.aProv_["52"] = "402";
    _i.aProv_["53"] = "306";
    _i.aProv_["54"] = "82";
    _i.aProv_["55"] = "1277";
    _i.aProv_["56"] = "56";
    _i.aProv_["57"] = "299";
    _i.aProv_["58"] = "835";
    _i.aProv_["59"] = "291";
    _i.aProv_["60"] = "264";
    _i.aProv_["61"] = "1117";
    _i.aProv_["62"] = "881";
    _i.aProv_["63"] = "1302";
    _i.aProv_["65"] = "1306";
    _i.aProv_["66"] = "133";
    _i.aProv_["67"] = "1305";
    _i.aProv_["69"] = "1418";
    _i.aProv_["70"] = "60";
    _i.aProv_["71"] = "915";
    _i.aProv_["72"] = "1173";
    _i.aProv_["73"] = "433";
    _i.aProv_["74"] = "1196";
    _i.aProv_["75"] = "75";
    _i.aProv_["76"] = "1198";
    _i.aProv_["77"] = "553";
    _i.aProv_["78"] = "";
    _i.aProv_["79"] = "77";
    _i.aProv_["80"] = "80";
    _i.aProv_["81"] = "916";
    _i.aProv_["83"] = "466";
    _i.aProv_["84"] = "";
    _i.aProv_["85"] = "911";
    _i.aProv_["86"] = "573";
    _i.aProv_["87"] = "1327";
    _i.aProv_["88"] = "66";
    _i.aProv_["89"] = "935";
    _i.aProv_["90"] = "64";
    _i.aProv_["92"] = "1179";
    _i.aProv_["93"] = "1106";
    _i.aProv_["95"] = "928";
    _i.aProv_["96"] = "411";
    _i.aProv_["97"] = "716";
    _i.aProv_["98"] = "880";
    _i.aProv_["99"] = "549";
    _i.aProv_["100"] = "413";
    _i.aProv_["101"] = "750";
    _i.aProv_["102"] = "412";
    _i.aProv_["103"] = "588";
    _i.aProv_["104"] = "1330";
    _i.aProv_["105"] = "1306";
    _i.aProv_["106"] = "1331";
    _i.aProv_["107"] = "408";
    _i.aProv_["108"] = "1322";
    _i.aProv_["109"] = "1329";
    _i.aProv_["110"] = "1333";
    _i.aProv_["111"] = "1332";
    _i.aProv_["112"] = "436";
    _i.aProv_["113"] = "946";
    _i.aProv_["114"] = "941";
    _i.aProv_["115"] = "941";
    _i.aProv_["116"] = "";
    _i.aProv_["119"] = "289";
    _i.aProv_["120"] = "479";
    _i.aProv_["121"] = "";
    _i.aProv_["122"] = "724";
    _i.aProv_["123"] = "956";
    _i.aProv_["124"] = "307";
    _i.aProv_["125"] = "293";
    _i.aProv_["126"] = "";
    _i.aProv_["127"] = "78";
    _i.aProv_["128"] = "288";
    _i.aProv_["129"] = "1337";
    _i.aProv_["130"] = "414";
    _i.aProv_["131"] = "297";
    _i.aProv_["132"] = "546";
    _i.aProv_["133"] = "258";
    _i.aProv_["135"] = "405";
    _i.aProv_["136"] = "1194";
    _i.aProv_["137"] = "549";
    _i.aProv_["138"] = "1303";
    _i.aProv_["139"] = "312";
    _i.aProv_["140"] = "1338";
    _i.aProv_["141"] = "1004";
    _i.aProv_["142"] = "269";
    _i.aProv_["143"] = "269";
    _i.aProv_["144"] = "1340";
    _i.aProv_["145"] = "300";
    _i.aProv_["146"] = "1343";
    _i.aProv_["148"] = "1341";
    _i.aProv_["149"] = "48";
    _i.aProv_["150"] = "132";
    _i.aProv_["151"] = "22";
    _i.aProv_["152"] = "1342";
    _i.aProv_["153"] = "1213";
    _i.aProv_["154"] = "1034";
    _i.aProv_["155"] = "1031";
    _i.aProv_["156"] = "1037";
    _i.aProv_["158"] = "1102";
    _i.aProv_["159"] = "1344";
    _i.aProv_["160"] = "1101";
    _i.aProv_["164"] = "1106";
    _i.aProv_["165"] = "1345";
    _i.aProv_["166"] = "1109";
    _i.aProv_["167"] = "1111";
    _i.aProv_["168"] = "1044";
    _i.aProv_["170"] = "1112";
    _i.aProv_["172"] = "81";
    _i.aProv_["173"] = "986";
    _i.aProv_["175"] = "1116";
    _i.aProv_["176"] = "1114";
    _i.aProv_["177"] = "767";
    _i.aProv_["178"] = "418";
    _i.aProv_["179"] = "1056";
    _i.aProv_["180"] = "";
    _i.aProv_["181"] = "181";
    _i.aProv_["182"] = "";
    _i.aProv_["184"] = "1348";
    _i.aProv_["185"] = "235";
    _i.aProv_["186"] = "1069";
    _i.aProv_["188"] = "1353";
    _i.aProv_["189"] = "1164";
    _i.aProv_["191"] = "1074";
    _i.aProv_["193"] = "141";
    _i.aProv_["194"] = "1354";
    _i.aProv_["195"] = "1078";
    _i.aProv_["196"] = "1125";
    _i.aProv_["197"] = "631";
    _i.aProv_["198"] = "579";
    _i.aProv_["199"] = "633";
    _i.aProv_["201"] = "1356";
    _i.aProv_["202"] = "1360";
    _i.aProv_["203"] = "144";
    _i.aProv_["205"] = "1357";
    _i.aProv_["206"] = "408";
    _i.aProv_["207"] = "421";
    _i.aProv_["208"] = "1363";
    _i.aProv_["209"] = "420";
    _i.aProv_["210"] = "1362";
    _i.aProv_["211"] = "1363";
    _i.aProv_["213"] = "1139";
    _i.aProv_["214"] = "1295";
    _i.aProv_["215"] = "1365";
    _i.aProv_["216"] = "1367";
    _i.aProv_["217"] = "14";
    _i.aProv_["218"] = "1339";
    _i.aProv_["219"] = "1366";
    _i.aProv_["220"] = "422";
    _i.aProv_["221"] = "468";
    _i.aProv_["222"] = "1116";
    _i.aProv_["223"] = "1368";
    _i.aProv_["224"] = "1364";
    _i.aProv_["225"] = "135";
    _i.aProv_["227"] = "1304";
    _i.aProv_["228"] = "5";
    _i.aProv_["229"] = "229";
    _i.aProv_["230"] = "62";
    _i.aProv_["232"] = "424";
    _i.aProv_["233"] = "1369";
    _i.aProv_["234"] = "1256";
    _i.aProv_["235"] = "1371";
    _i.aProv_["239"] = "1370";
    _i.aProv_["240"] = "1373";
    _i.aProv_["241"] = "1145";
    _i.aProv_["242"] = "511";
    _i.aProv_["243"] = "79";
    _i.aProv_["244"] = "125";
    _i.aProv_["245"] = "59";
    _i.aProv_["246"] = "1264";
    _i.aProv_["247"] = "58";
    _i.aProv_["248"] = "95";
    _i.aProv_["249"] = "1372";
    _i.aProv_["252"] = "774";
    _i.aProv_["253"] = "1096";
    _i.aProv_["256"] = "1375";
    _i.aProv_["258"] = "1325";
    _i.aProv_["259"] = "899";
    _i.aProv_["260"] = "426";
    _i.aProv_["261"] = "1149";
    _i.aProv_["265"] = "1376";
    _i.aProv_["266"] = "1374";
    _i.aProv_["269"] = "635";
    _i.aProv_["270"] = "";
    _i.aProv_["271"] = "1378";
    _i.aProv_["272"] = "1152";
    _i.aProv_["273"] = "489";
    _i.aProv_["274"] = "427";
    _i.aProv_["275"] = "96";
    _i.aProv_["276"] = "567";
    _i.aProv_["277"] = "277";
    _i.aProv_["278"] = "1380";
    _i.aProv_["279"] = "1167";
    _i.aProv_["280"] = "1381";
    _i.aProv_["282"] = "428";
    _i.aProv_["283"] = "429";
    _i.aProv_["284"] = "715";
    _i.aProv_["285"] = "1382";
    _i.aProv_["305"] = "305";
    _i.aProv_["421"] = "421";
    _i.aProv_["422"] = "422";
    _i.aProv_["423"] = "423";
    _i.aProv_["9999"] = "9999";
  }
  var provNav = ""
  if (codProv in _i.aProv_) {
    if (_i.aProv_[codProv] != "") {
      provNav = flfactppal.iface.pub_cerosIzquierda(_i.aProv_[codProv], 6);
    }
  }
  return provNav;
}



function euromoda_dameArrayTamanos(i)
{
  var _i = this.iface;
  if (!_i.aTamanos_) {
    _i.aTamanos_ = [];
    var q = new FLSqlQuery;
    q.setSelect("codigogit, codtamanoem");
    q.setFrom("em_tamanos");
    q.setWhere("");
    q.setForwardOnly(true);
    if (!q.exec()) {
      return false;
    }
    while (q.next()) {
      _i.aTamanos_[q.value("codigogit")] = q.value("codtamanoem");
    }
  }

  return _i.aTamanos_[i];
}

function euromoda_dameArrayTEmbalaje(i)
{
  var _i = this.iface;
  if (!_i.aTEmbalaje_) {
    _i.aTEmbalaje_ = [];
    var q = new FLSqlQuery;
    q.setSelect("codigogit, em_codtipoemb");
    q.setFrom("em_tiposemb");
    q.setWhere("");
    q.setForwardOnly(true);
    if (!q.exec()) {
      return false;
    }
    while (q.next()) {
      _i.aTEmbalaje_[q.value("codigogit")] = q.value("em_codtipoemb");
    }
  }

  return _i.aTEmbalaje_[i];
}

function euromoda_dameArrayColor(i)
{
  var _i = this.iface;
  if (!_i.aColores_) {
    _i.aColores_ = [];
    var q = new FLSqlQuery;
    q.setSelect("codigogit, codcolorem");
    q.setFrom("em_colores");
    q.setWhere("");
    q.setForwardOnly(true);
    if (!q.exec()) {
      return false;
    }
    while (q.next()) {
      _i.aColores_[q.value("codigogit")] = q.value("codcolorem");
    }
  }

  return _i.aColores_[i];
}

function euromoda_actualizarCodProveedorEnDocumentos()
{
  var step = 0;
  var qry = new AQSqlQuery;

  // Facturas de proveedores
  qry.setSelect("idfactura,codproveedor,cifnif");
  qry.setFrom("facturasprov");
  if (qry.exec()) {
    AQUtil.createProgressDialog(sys.translate("Actualizando Facturas Proveedores"),
                                qry.size());
    while (qry.next()) {
      var idFactura = qry.value(0);
      var codProv = qry.value(1);
      var cifNif = qry.value(2);
      var newCodProv = AQUtil.sqlSelect("proveedores", "codproveedor",
                                        "cifnif='" + cifNif + "'");
      if (newCodProv != false && newCodProv != codProv) {
        AQUtil.execSql("update facturasprov set codproveedor='" + newCodProv +
                       "' where idfactura=" + idFactura);
      }
      AQUtil.setProgress(step++);
    }
    AQUtil.destroyProgressDialog();
  }

  // Recibos de proveedores
  step = 0;
  qry.setSelect("idrecibo,codproveedor,cifnif");
  qry.setFrom("recibosprov");
  if (qry.exec()) {
    AQUtil.createProgressDialog(sys.translate("Actualizando Recibos Proveedores"),
                                qry.size());
    while (qry.next()) {
      var idRec = qry.value(0);
      var codProv = qry.value(1);
      var cifNif = qry.value(2);
      var newCodProv = AQUtil.sqlSelect("proveedores", "codproveedor",
                                        "cifnif='" + cifNif + "'");
      if (newCodProv != false && newCodProv != codProv) {
        AQUtil.execSql("update recibosprov set codproveedor='" + newCodProv +
                       "' where idrecibo=" + idRec);
      }
      AQUtil.setProgress(step++);
    }
    AQUtil.destroyProgressDialog();
  }

  sys.infoMsgBox(sys.translate("Proceso terminado"));
}

function euromoda_actualizarDocsFacturacion(tabla, tablaLineas, campoID, msg)
{
  var curTabla = new AQSqlCursor(tabla);
  var q = new AQSqlQuery();
  q.setTablesList(tablaLineas);
  q.setFrom(tablaLineas);

  curTabla.setActivatedCommitActions(false);
  var codEjercicio = fldatosppal.iface.pub_ejercicioDefecto();
  curTabla.select("codejercicio = '" + codEjercicio + "'");

  AQUtil.createProgressDialog(sys.translate("Procesando ") + msg + "...", curTabla.size());
  AQUtil.setProgress(1);

  var paso = 0;
  var netoSinDto = 0;
  var porDto = 0;
  var dto = 0;
  var totalIva = 0;
  var totalRec = 0;
  var neto = 0;
  var total = 0;

  while (curTabla.next()) {
    curTabla.setModeAccess(AQSql.Edit);
    curTabla.refreshBuffer();

    porDto = parseFloat(curTabla.valueBuffer("pordtoesp"));

    q.setSelect("SUM(pvptotal)," +
                "SUM((pvptotal * iva * (100 - " + porDto + ")) / 100 / 100)," +
                "SUM((pvptotal * recargo * (100 - " + porDto + ")) / 100 / 100)");
    q.setWhere(campoID + " = " + curTabla.valueBuffer(campoID))
    if (!q.exec())
      continue;
    if (!q.first())
      continue;

    netoSinDto = parseFloat(AQUtil.roundFieldValue(q.value(0), tabla, "netosindtoesp"));
    totalIva = parseFloat(AQUtil.roundFieldValue(q.value(1), tabla, "totaliva"));
    totalRec = parseFloat(AQUtil.roundFieldValue(q.value(2), tabla, "totalrecargo"));
    dto = parseFloat(AQUtil.roundFieldValue(netoSinDto * porDto / 100.0, tabla, "dtoesp"));
    neto = parseFloat(AQUtil.roundFieldValue(netoSinDto - dto, tabla, "neto"));

    curTabla.setValueBuffer("netosindtoesp", netoSinDto);
    curTabla.setValueBuffer("dtoesp", dto);
    curTabla.setValueBuffer("neto", neto);
    curTabla.setValueBuffer("totaliva", totalIva);
    curTabla.setValueBuffer("totalrecargo", totalRec);

    total = parseFloat(AQUtil.roundFieldValue(neto + totalIva + totalRec, tabla, "total"));

    curTabla.setValueBuffer("total", total);
    curTabla.setValueBuffer("totaleuros",
                            total * parseFloat(curTabla.valueBuffer("tasaconv")));

    curTabla.commitBuffer();

    AQUtil.setProgress(++paso);
  }

  AQUtil.destroyProgressDialog();
  curTabla.setActivatedCommitActions(true);
}

function euromoda_actualizarAlbaranes()
{
  var _i = this.iface;

  _i.actualizarDocsFacturacion("albaranescli", "lineasalbaranescli",
                               "idalbaran", sys.translate("Albaranes de Cliente"));

  sys.infoMsgBox(sys.translate("Proceso finalizado"));
}

function euromoda_actualizarFacturas()
{
  var _i = this.iface;

  _i.actualizarDocsFacturacion("facturascli", "lineasfacturascli",
                               "idfactura", sys.translate("Facturas de Cliente"));

  var paso = 0;
  var cur = new AQSqlCursor("facturascli");
  cur.setActivatedCommitActions(false);
  var codEjercicio = fldatosppal.iface.pub_ejercicioDefecto();
  cur.select("codejercicio = '" + codEjercicio + "'");

  AQUtil.createProgressDialog(sys.translate("Procesando Fecha Valor..."), cur.size());
  AQUtil.setProgress(1);

  while (cur.next()) {
    if (!cur.bufferIsNull("fechavalor"))
      continue;

    cur.setModeAccess(AQSql.Edit);
    cur.refreshBuffer();
    cur.setValueBuffer("fechavalor", cur.valueBuffer("fecha"));
    cur.commitBuffer();

    AQUtil.setProgress(++paso);
  }

  AQUtil.destroyProgressDialog();
  cur.setActivatedCommitActions(true);

  sys.infoMsgBox(sys.translate("Proceso finalizado"));
}

function euromoda_actualizarAmortizaciones()
{
  var _i = this.iface;

  AQUtil.execSql("update co_dotaciones c set acumulado=COALESCE((select sum(importe) " +
                 "from co_dotaciones d where d.fecha<c.fecha and d.codamortizacion = " +
                 "c.codamortizacion),0) + c.importe");

  AQUtil.execSql("update co_dotaciones c set resto=((select valoramortizable from " +
                 "co_amortizaciones where codamortizacion=c.codamortizacion)-c.acumulado)");

  AQUtil.execSql("update co_dotaciones c set porcentaje=(c.importe/(select " +
                 "valoramortizable from co_amortizaciones where codamortizacion = " +
                 "c.codamortizacion)*100)");

  AQUtil.execSql("update co_amortizaciones a set totalamortizado=COALESCE((select " +
                 "sum(importe) from co_dotaciones d where d.codamortizacion=a.codamortizacion),0)");

  AQUtil.execSql("update co_amortizaciones set pendiente=valoramortizable-totalamortizado");

  AQUtil.execSql("update co_amortizaciones set estado='Terminada' where pendiente<=0.001 and pendiente>=-0.001");
  AQUtil.execSql("update co_amortizaciones set pendiente=0 where pendiente<=0.001 and pendiente>=-0.001");
  AQUtil.execSql("update co_dotaciones set resto=0 where resto<=0.001 and resto>=-0.001");
  
  sys.infoMsgBox(sys.translate("Proceso finalizado"));
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

