
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends numLineaProv {
	var curP_, pK_;

  	function euromoda( context ) { numLineaProv ( context ); }
  	function init() {
		return this.ctx.euromoda_init()
	}
	function datosLineaFactura(curLineaAlbaran)
  	{
		return this.ctx.euromoda_datosLineaFactura(curLineaAlbaran);
  	}
  	function commonCalculateField(fN, cursor) {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
  	}
  	function datosFactura(curAlbaran, where, datosAgrupacion) {
		return this.ctx.euromoda_datosFactura(curAlbaran, where, datosAgrupacion);
  	}
  	function generarFactura(where, curAlbaran, datosAgrupacion) {
		return this.ctx.euromoda_generarFactura(where, curAlbaran, datosAgrupacion);
  	}
  	function toolButtomInsert_clicked() {
		return this.ctx.euromoda_toolButtomInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.euromoda_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.euromoda_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.euromoda_toolButtonZoom_clicked();
	}
	function toolButtonCopy_clicked() {
		return this.ctx.euromoda_toolButtonCopy_clicked();
	}
	function curP_bufferCommited() {
		return this.ctx.euromoda_curP_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tableDBRecords_recordChoosed() {
		return this.ctx.euromoda_tableDBRecords_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function treliminaAlbaran(oParam) {
		return this.ctx.euromoda_treliminaAlbaran(oParam);
	}
	function actualizaLotesStock(idAlbaran) {
		return this.ctx.euromoda_actualizaLotesStock(idAlbaran);
	}
	function eliminaAlbaran(cursor) {
		return this.ctx.euromoda_eliminaAlbaran(cursor);
	}
	function desacabarTramos(idAlbaran) {
		return this.ctx.euromoda_desacabarTramos(idAlbaran);
	}
	function imprimir(codAlbaran) {
		return this.ctx.euromoda_imprimir(codAlbaran);
	}
	function eliminarObservAlb(idAlbaran) {
		return this.ctx.euromoda_eliminarObservAlb(idAlbaran);
	}
	function acabadosAlb(idAlbaran, observaciones) {
		return this.ctx.euromoda_acabadosAlb(idAlbaran, observaciones);
	}
	function compruebaBobinaRoll(idAlbaran) {
		return this.ctx.euromoda_compruebaBobinaRoll(idAlbaran);
	}
	function eliminaBobPrlPedidos(idAlbaran) {
		return this.ctx.euromoda_eliminaBobPrlPedidos(idAlbaran);
	}
	function actualizaTramosPed(idAlbaran) {
		return this.ctx.euromoda_actualizaTramosPed(idAlbaran);
	}
	function eliminaTransferencia(idAlbaran) {
		return this.ctx.euromoda_eliminaTransferencia(idAlbaran);
	}
	function tbnAbrirCerrar_clicked() {
		return this.ctx.euromoda_tbnAbrirCerrar_clicked();
  	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_datosLineaFactura(curLineaAlbaran)
{
  var _i = this.iface;
  if (!_i.__datosLineaFactura(curLineaAlbaran)) {
    return false;
  }
	
  var codEjercicio = AQUtil.sqlSelect("facturascli", "codejercicio", "idfactura = " + _i.curLineaFactura.valueBuffer("idfactura"));
  var codSubcuenta = formRecordlineasfacturasprov.iface.pub_dameSubcuentaProducto(_i.curLineaFactura);
  if (codSubcuenta) {
    _i.curLineaFactura.setValueBuffer("codsubcuenta", codSubcuenta);
    var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
    if (idSubcuenta) {
      _i.curLineaFactura.setValueBuffer("idsubcuenta", idSubcuenta);
    }
  }
  
  _i.curLineaFactura.setValueBuffer("tipoconcepto", curLineaAlbaran.valueBuffer("tipoconcepto"));
  _i.curLineaFactura.setValueBuffer("texto", curLineaAlbaran.valueBuffer("texto"));
	_i.curLineaFactura.setValueBuffer("codtamanoem", curLineaAlbaran.valueBuffer("codtamanoem"));
	_i.curLineaFactura.setValueBuffer("codcolorem", curLineaAlbaran.valueBuffer("codcolorem"));
  return true;
}

function euromoda_commonCalculateField(fN, cursor)
{
  var _i = this.iface;
  var valor;

  switch (fN) {
  case "codserie": {
      valor = AQUtil.sqlSelect("proveedores p INNER JOIN gruposcontablesprov gp ON p.codgrupocontableprov = gp.codgrupo", "gp.codseriefac", "p.codproveedor = '" + cursor.valueBuffer("codproveedor") + "'", "proveedores");
      break;
    }
	default: {
      valor = _i.__commonCalculateField(fN, cursor);
      break;
    }
  }
  return valor;
}

function euromoda_datosFactura(curAlbaran, where, datosAgrupacion)
{
  var _i = this.iface;
  if (!_i.__datosFactura(curAlbaran, where, datosAgrupacion)) {
    return false;
  }
  
  var numProveedor = Input.getText(sys.translate("scripts", "C�digo proveedor factura de %1").arg(curAlbaran.valueBuffer("nombre")));
	if (!numProveedor) {
		return false;
	}
	with (_i.curFactura) {
    setValueBuffer("em_codpago", curAlbaran.valueBuffer("em_codpago"));
		setValueBuffer("numproveedor", numProveedor);
  }  
  return true;
}

function euromoda_generarFactura(where, curAlbaran, datosAgrupacion)
{
  var _i = this.iface;
	var codProveedor = curAlbaran.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
      return false;
    }
  }
  if (!_i.__generarFactura(where, curAlbaran, datosAgrupacion)) {
    return false;
  }
  return true;
}

function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	_i.pedirDatosAdicionales_ = false;
	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	connect(this.child("toolButtonCopy"), "clicked()", _i, "toolButtonCopy_clicked");
	
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tableDBRecords_recordChoosed");
	connect(this.child("tbnAbrirCerrar"), "clicked()", _i, "tbnAbrirCerrar_clicked");
}

function euromoda_tableDBRecords_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEdit_clicked();
}

function euromoda_toolButtomInsert_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");

}

function euromoda_toolButtonEdit_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDelete_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoom_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}

function euromoda_toolButtonCopy_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("copy");
}

function euromoda_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (_i.curP_) {
		disconnect(_i.curP_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curP_, "commited()", _i, "curP_bufferCommited");
		_i.curP_ = undefined;
	}
	
	_i.curP_ = new FLSqlCursor("albaranesprov");
	_i.curP_.setAction("albaranesprov");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curP_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curP_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curP_, "commited()", _i, "curP_bufferCommited");
			_i.curP_.insertRecord();
			break;
		}
		case "edit": {
			connect(_i.curP_, "commited()", _i, "refrescaTabla");
			_i.curP_.editRecord();
			break;
		}
		case "del": {
			if (!cursor.valueBuffer("acabados")) {
				this.child("tableDBRecords").deleteRecord();				
			} else  {				
  				var res = MessageBox.information(sys.translate("El registro activo ser� borrado. �Est� seguro?"), MessageBox.Yes, MessageBox.No);
				if (res != MessageBox.Yes) {
					return;
				}
  				var oParam = new Object;
				oParam.errorMsg = sys.translate("Error al eliminar el albar�n de acabados.");
				oParam.cursor = cursor;
				var f = new Function("oParam", "return formalbaranesprov.iface.treliminaAlbaran(oParam)");
				if (!sys.runTransaction(f, oParam)) {							
					return false;
				}		
			
			}
			break;
		}
		case "browse": {	
			_i.curP_.browseRecord();
			break;
		}
		case "copy": {
			this.child("tableDBRecords").copyRecord(); // Deber�amos llamar a curP_.copyRecord, pero no est� publicado
			break;
		}
	}
}

function euromoda_refrescaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.refresh()
}

function euromoda_curP_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	this.child("tableDBRecords").refresh();
	var dtbLC = this.mainWidget().child("tableDBRecords").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);
	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);

	var oParams = [];
	oParams.fN = "codigo";
	oParams.valor = _i.pK_;
	oParams.cursor = cursor;
	oParams.tipoOrden = asc
	oParams.objTabla = this.child("tableDBRecords");

	var pos = flfacturac.iface.pub_buscaPosEnCursor(oParams);
	if (pos == -1) {
		debug("No encontrado");
		return false;
	}
	cursor.seek(pos);
	cursor.refresh()
}

function euromoda_treliminaAlbaran(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;
	var idAlbaran = cursor.valueBuffer("idAlbaran");
	if(!_i.compruebaBobinaRoll(idAlbaran)) {
		sys.warnMsgBox(sys.translate("No se puede eliminar el albar�n ya que la/s bobina/s incluidas se han rollado o est�n roll�ndose."));
		return false;	
	}
	if(!_i.eliminaBobPrlPedidos(idAlbaran)) {
		return false;
	}
	if(!_i.actualizaLotesStock(idAlbaran)) {
		return false;
	}
	if(!_i.desacabarTramos(idAlbaran)) {
		return false;
	}	
	if(!_i.eliminaTransferencia(idAlbaran)) {		
		return false;
	}

	if(!formem_albaranaracabados.iface.revisaStock(idAlbaran)) {
		return false;
	}	
	if(!_i.actualizaTramosPed(idAlbaran)) {
		return false;
	}
	if(!_i.eliminaAlbaran(cursor)) {
		return false;
	}
	return true;	
}

function euromoda_actualizaLotesStock(idAlbaran)
{
	var q = new AQSqlQuery;
	q.setSelect("idlinea");
	q.setFrom("lineasalbaranesprov");
	q.setWhere("idalbaran = "+ idAlbaran);
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idLinea = q.value("idlinea");
		var curLotes = new FLSqlCursor("lotesstock");		
		curLotes.setActivatedCommitActions(false);
  		curLotes.select("idlinea = " + idLinea);
  		while (curLotes.next()) {
		
	  		curLotes.setModeAccess(curLotes.Edit);
	  		curLotes.refreshBuffer(); 
	  		curLotes.setNull("idlinea");  		
		   if (!curLotes.commitBuffer()) {		   	
		   	return false;
		 	}
		 }
	}	
	return true;
}

function euromoda_desacabarTramos(idAlbaran)
{
	debug("\n\neuromoda_desacabarTramos");
	var q = new AQSqlQuery;	
	q.setSelect("em_tramostejido.idtramo,em_tramostejido.codpartida,em_tramostejido.codbobinaaca, em_tramostejido.codbobinaprl, em_tramostejido.codbobinareo");
	q.setFrom("em_tramostejido INNER JOIN albaranesprov ON em_tramostejido.idalbaranprov = albaranesprov.idalbaran");
	q.setWhere("em_tramostejido.idalbaranprov = '" + idAlbaran + "' order by em_tramostejido.caninicio desc"); 			 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idTramoA = q.value("em_tramostejido.idtramo");
		var codPartidaA = q.value("em_tramostejido.codpartida");
		var codBobinaAca = q.value("em_tramostejido.codbobinaaca");
		var codBobinaPR = q.value("em_tramostejido.codbobinaprl");
		var codBobinaREO = q.value("em_tramostejido.codbobinareo");
		
		debug("codBobinaREO: "+codBobinaREO+"\n\n");
		formem_albaranaracabados.iface.desAcabaTramo(idTramoA, codPartidaA, codBobinaPR, codBobinaAca, codBobinaREO);		
	}	
	return true;
}


function euromoda_eliminaAlbaran(cursor)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idAlbaran = cursor.valueBuffer("idalbaran");
	if (idAlbaran == "" ) 
	{		
		sys.warnMsgBox(sys.translate("No hay ning�n registro seleccionado."));
		return false;
	}
	connect(_i.curP_, "bufferCommited()", _i, "refrescaTabla");
	_i.curP_.setModeAccess(_i.curP_.Del);
	_i.curP_.refreshBuffer();
	if(!_i.curP_.commitBuffer()) {
		sys.warnMsgBox(sys.translate("Se ha producido un error al borrar el registro activo."));
		return false;
	}	
	return true;
}

function euromoda_acabadosAlb(idAlbaran, observaciones)
{
  var qLineaAP = new AQSqlQuery;
  qLineaAP.setSelect("idlinea");
  qLineaAP.setFrom("lineasalbaranesprov");
  qLineaAP.setWhere("idalbaran = " + idAlbaran + " ORDER BY idlinea desc");
  if (!qLineaAP.exec()) {
    return false;
  }
  if (!qLineaAP.first()) {
    return false;
  }
  var ultimaLinea = qLineaAP.value("idlinea"); 
  var sObservaciones = observaciones.split("\n");

  var tam = sObservaciones.length;
  if (tam == 1 && sObservaciones[0] == "") {
    tam = 0;
  }
  var cursorAcabados = new FLSqlCursor("em_acabadosalbprov");
  var linea = "------------------------------------------------------------------------------------------------------";
  var saltoLinea = "\n";
  var numAcabados = AQUtil.sqlSelect("em_acabadosalbprov", "count (*)", "em_codacabado is not null and idalbaran = " + idAlbaran);
  if (numAcabados > 0) {
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
    cursorAcabados.setValueBuffer("idlinea", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", linea);
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
    cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", " Acabados");
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    if (tam == 0) {
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
      cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", linea);
      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
    }
  }
  if (tam > 0) {
    if (numAcabados > 0) {
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
      cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", linea);
      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
      cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", saltoLinea);
      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
    }


    for (i = tam - 1; i >= 0; i--) {
      cursorAcabados.setModeAccess(cursorAcabados.Insert);
      cursorAcabados.refreshBuffer();
      cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
      cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
      cursorAcabados.setValueBuffer("observacion", sObservaciones[i]);

      if (!cursorAcabados.commitBuffer()) {
        return false;
      }
    }

    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
    cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", linea);
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
    cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", " Observaciones");
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
    cursorAcabados.setModeAccess(cursorAcabados.Insert);
    cursorAcabados.refreshBuffer();
    cursorAcabados.setValueBuffer("idalbaran", idAlbaran);
    cursorAcabados.setValueBuffer("idlineaalbaran", ultimaLinea);
    cursorAcabados.setValueBuffer("observacion", linea);
    if (!cursorAcabados.commitBuffer()) {
      return false;
    }
  }



  cursorAcabados.setModeAccess(cursorAcabados.Edit);
  AQUtil.sqlUpdate("em_acabadosalbprov", "idlineaalbaran", ultimaLinea, "idalbaran = " + idAlbaran);

  return true;

}

function euromoda_imprimir(codAlbaran)
{
  var _i = this.iface; 
  var idAlbaran, codigo, observaciones, observacionesAuto;
  if (codAlbaran) {
    codigo = codAlbaran;
    idAlbaran = AQUtil.sqlSelect("albaranesprov", "idalbaran", "codigo = '" + codigo + "'");    
    observacionesAuto = AQUtil.sqlSelect("albaranesprov", "em_obsacabadoauto", "codigo = '" + codigo + "'");
    if(!observacionesAuto) {
	observacionesAuto = "";
    }

  } else {
    if (this.child("tableDBRecords")) {
      this.child("tableDBRecords").refresh();
    }
    var cursor = this.cursor();
    if (!cursor.isValid()) {
      return;
    }
    codigo = cursor.valueBuffer("codigo");
    idAlbaran = cursor.valueBuffer("idalbaran");    
    observacionesAuto = cursor.valueBuffer("em_obsacabadoauto");
  }
  if (!idAlbaran) {
    return;
  } 
  _i.acabadosAlb(idAlbaran, observacionesAuto);

  var oParam = this.iface.dameParamInforme(idAlbaran);
  if (!oParam) {
    return;
  }
  var curImprimir = new FLSqlCursor("i_albaranesprov");
  curImprimir.setModeAccess(curImprimir.Insert);
  curImprimir.refreshBuffer();
  curImprimir.setValueBuffer("descripcion", "temp");
  curImprimir.setValueBuffer("d_albaranesprov_codigo", codigo);
  curImprimir.setValueBuffer("h_albaranesprov_codigo", codigo);
  flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);

  _i.eliminarObservAlb(idAlbaran);

}

function euromoda_eliminarObservAlb(idAlbaran)
{
  AQUtil.sqlDelete("em_acabadosalbprov", "em_codacabado is null and idalbaran = " + idAlbaran);
}

function euromoda_compruebaBobinaRoll(idAlbaran)
{
	
	var q = new AQSqlQuery;	
	q.setSelect("distinct(codbobina)");
	//q.setFrom("em_bobinas");
	q.setFrom("em_tramostejido");
	q.setWhere("idalbaranprov = "+ idAlbaran); 
	debug("sql: "+q.sql());			
	if (!q.exec()){
	
		return;
	}  
	while(q.next())
	{

		var codBobina = q.value("distinct(codbobina)");	
		var numMaq = AQUtil.sqlSelect("em_maquinasroll", "count(*)", "codbobinaactual='" + codBobina +"'");
		if(numMaq > 0) {			
			return false;			
		}		
		var numTrm = AQUtil.sqlSelect("em_tramostejido", "COUNT(*)", "codbobinaroll='" + codBobina +"' and codbobina is null and idalbaranprov = " + idAlbaran);
		if(numTrm > 0) {			
			return false;			
		}		
		
	}	

	return true;
}

function euromoda_eliminaBobPrlPedidos(idAlbaran)
{
	debug("euromoda_eliminaBobPrlPedidos");
	var _i = this.iface;
	var idPedido = AQUtil.sqlSelect("lineasalbaranesprov", "idpedido", "idalbaran = " + idAlbaran);
	
	var q = new AQSqlQuery;	
	q.setSelect("distinct(codbobinaprl)");
	q.setFrom("em_tramostejido");
	q.setWhere("idalbaranprov = " + idAlbaran); 			
	if (!q.exec()){
		return;
	}  
	debug("**************sql: "+q.sql());
	while(q.next())
	{
		var codBobina = q.value("distinct(codbobinaprl)");
		
		if(!fleumoesta.iface.pub_eliminaBobPrlPedidos(codBobina, idPedido)) {
			return false;
		}				
	}	
	return true;
}

function euromoda_actualizaTramosPed(idAlbaran)
{
	debug("euromoda_actualizaTramosPed");
	var _i = this.iface;
	
	if (!AQUtil.execSql("UPDATE em_tramostejido SET idalbaranprov = NULL WHERE idalbaranprov = " + idAlbaran)) {
		return false;
	}
	return true;

}

function euromoda_eliminaTransferencia(idAlbaran)
{
	debug("euromoda_eliminaTransferencia");
	var curT = new FLSqlCursor("em_transstockaca");
	curT.select("idalbacabado = "+ idAlbaran);
	if (curT.first()) {
		curT.setModeAccess(curT.Del);
   	curT.refreshBuffer();  
   	if(!curT.commitBuffer()) {
   		return false;
   	}
	}	
	return true; 
}

/*function euromoda_eliminaTransferencia(idAlbaran)
{
	debug("\n\n\neuromoda_eliminaTransferencia: "+idAlbaran);
	var q = new AQSqlQuery;	
	q.setSelect("tt.codpartidaorigen");
	q.setFrom("em_tramostejido tt");
	q.setWhere("tt.idalbaranprov= " + idAlbaran + " "); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var codPartida = q.value("tt.codpartidaorigen");
		
		debug("codpartida: "+codPartida);
		if (!AQUtil.execSql("DELETE FROM movistock WHERE codlote = '" + codPartida + "' and emidtramo is null")) {
			return false;
		}		
	}
	return true;
}*/

function euromoda_tbnAbrirCerrar_clicked()
{
	var cursor = this.cursor();

	var idAlbaran = cursor.valueBuffer("idalbaran");
	if (!idAlbaran) {
		formUI.ponMsgWarn(sys.translate("No hay ning�n albar�n seleccionado"));
		return false;
	}
	var codAlbaran = cursor.valueBuffer("codigo");

	var cerrar = true;
	
	if (!cursor.isNull("idfactura") && cursor.valueBuffer("idfactura")) {
		formUI.ponMsgWarn(sys.translate("El albar�n ya est� facturado"));		
		return false;
	}
	var res = false;
	var editable = cursor.valueBuffer("ptefactura")
	if (editable) {
		var ret = formUI.preguntaMsg(sys.translate("Se va a cerrar el albar�n %1 y no podr� facturarse.\n�Desea continuar?").arg(codAlbaran),"info",this,MessageBox.Yes, MessageBox.No); 
 		if(ret != MessageBox.Yes) {
 			return false;
 		}	
	} else {
		var ret = formUI.preguntaMsg(sys.translate("Se va a reabrir el albar�n %1.\n�Desea continuar?").arg(codAlbaran),"info",this,MessageBox.Yes, MessageBox.No); 
 		if(ret != MessageBox.Yes) {
 			return false;
 		}	
	}
	cursor.setUnLock("ptefactura", !editable);
	this.child("tableDBRecords").refresh();
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
