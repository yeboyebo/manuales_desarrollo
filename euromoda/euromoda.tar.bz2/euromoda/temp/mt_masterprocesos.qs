
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends num_lineaprov {
	var batchOn_;
	var oCorreo_;
	function euromoda( context ) { num_lineaprov ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function emCargaVencimientos(oParam) {
		return this.ctx.euromoda_emCargaVencimientos(oParam);
	}
	function emEstadosRemesaProv(oParam) {
		return this.ctx.euromoda_emEstadosRemesaProv(oParam);
	}
	function emDepuraTamanosSubfamilia(oParam) {
		return this.ctx.euromoda_emDepuraTamanosSubfamilia(oParam);
	}
	function emDepuraTamanos(oParam) {
		return this.ctx.euromoda_emDepuraTamanos(oParam);
	}
	function emProcesaPedidosMigCli(oParam) {
		return this.ctx.euromoda_emProcesaPedidosMigCli(oParam);
	}
	function emProcesaPedidosMigProv(oParam) {
		return this.ctx.euromoda_emProcesaPedidosMigProv(oParam);
	}
	function emProcesaPedidosMarco(oParam) {
		return this.ctx.euromoda_emProcesaPedidosMarco(oParam);
	}
	function emRestaMetrosPieza(oParam) {
		return this.ctx.euromoda_emRestaMetrosPieza(oParam);
	}/**
	function emProcesaStocksPtes(oParam) {
		return this.ctx.euromoda_emProcesaStocksPtes(oParam);
	}*/
	function emCreaRegStocksCero(oParam) {
		return this.ctx.euromoda_emCreaRegStocksCero(oParam);
	}
	function emBorrarOrdenes() {
		return this.ctx.euromoda_emBorrarOrdenes();
	}
	function emBorrarReservas2Ordenes() {
		return this.ctx.euromoda_emBorrarReservas2Ordenes();
	}
	function emMovimientosOFFaPTE() {
		return this.ctx.euromoda_emMovimientosOFFaPTE();
	}
	function emCorrigeTamanosem_dibujostamsub() {
		return this.ctx.euromoda_emCorrigeTamanosem_dibujostamsub();
	}
	function emRevisarReservasXCliente() {
		return this.ctx.euromoda_emRevisarReservasXCliente();
	}
	function emRevisarConceptosMovistock() {
		return this.ctx.euromoda_emRevisarConceptosMovistock();
	}
	function emRevisarReservas() {
		return this.ctx.euromoda_emRevisarReservas();
	}
	function revisaReservasProducto(referencia) {
		return this.ctx.euromoda_revisaReservasProducto(referencia);
	}
	function emRevisaPedProvCerradosXPartidas() {
		return this.ctx.euromoda_emRevisaPedProvCerradosXPartidas();
	}
	function emRevisaPedProvMermaXPartidas() {
		return this.ctx.euromoda_emRevisaPedProvMermaXPartidas();
	}
	function emCreaMovMerma0PedCli() {
		return this.ctx.euromoda_emCreaMovMerma0PedCli();
	}
	function emRevisaMermaPartidas() {
		return this.ctx.euromoda_emRevisaMermaPartidas();
	}
	function emRevisaTotalesPartidas() {
		return this.ctx.euromoda_emRevisaTotalesPartidas();
	}
	function emRevisaTotalesPiezas() {
		return this.ctx.euromoda_emRevisaTotalesPiezas();
	}
	function emRevisaFechaServicioPedPte(idPedidoPar) {
		return this.ctx.euromoda_emRevisaFechaServicioPedPte(idPedidoPar);
	}
	function calculaFechaServicioPedido(idPedido) {
		return this.ctx.euromoda_calculaFechaServicioPedido(idPedido);
	}
	function emActualizaIdArticuloCompMovimientos() {
		return this.ctx.euromoda_emActualizaIdArticuloCompMovimientos();
	}
	function emCompruebaSaldoProv(codProveedor) {
		return this.ctx.euromoda_emCompruebaSaldoProv(codProveedor);
	}
	function compSaldoFacturasProv(codProveedor, listaS) {
		return this.ctx.euromoda_compSaldoFacturasProv(codProveedor, listaS);
	}
	function compSaldoAnticiposProv(codProveedor, listaS) {
		return this.ctx.euromoda_compSaldoAnticiposProv(codProveedor, listaS);
	}
	function compSaldoReciboProv(qR, listaS) {
		return this.ctx.euromoda_compSaldoReciboProv(qR, listaS);
	}
	function compSaldoFacturaProv(qF, listaS) {
		return this.ctx.euromoda_compSaldoFacturaProv(qF, listaS);
	}
	function emActualizaLotesAsignacion27() {
		return this.ctx.euromoda_emActualizaLotesAsignacion27();
	}
	function compSaldoPagosDevolProv(qR, listaS) {
		return this.ctx.euromoda_compSaldoPagosDevolProv(qR, listaS);
	}
	function compSaldoPartidasProv(codProveedor, listaS) {
		return this.ctx.euromoda_compSaldoPartidasProv(codProveedor, listaS);
	}
	function compSaldoPartidaProv(qSP, listaS, codProveedor) {
		return this.ctx.euromoda_compSaldoPartidaProv(qSP, listaS, codProveedor);
	}
	function lanzaPedidosAsignacion(oParam) {
		return this.ctx.euromoda_lanzaPedidosAsignacion(oParam);
	}
	function enviaOrdenes(oParam) {
		return this.ctx.euromoda_enviaOrdenes(oParam);
	}
	function emRevisaReservasTejidoPrev(oParam) {
		return this.ctx.euromoda_emRevisaReservasTejidoPrev(oParam);
	}
	function emRevisaReservasLPAFaltas(oParam) {
		return this.ctx.euromoda_emRevisaReservasLPAFaltas(oParam);
	}
	
	function ejecutaFuncionDefecto(funcion) {
		return this.ctx.euromoda_ejecutaFuncionDefecto(funcion);
	}
	function revisaEanInternos(oParam) {
		return this.ctx.euromoda_revisaEanInternos(oParam);
	}
	function emCompruebaReservasPedidos(oParam) {
		return this.ctx.euromoda_emCompruebaReservasPedidos(oParam);
	}
	function emBuscaOrdenesIncorrectas(oParam) {
		return this.ctx.euromoda_emBuscaOrdenesIncorrectas(oParam);
	}
	function emCargaFactoresFT(oParam) {
		return this.ctx.euromoda_emCargaFactoresFT(oParam);
	}
	function calculaMetrosOPSeccion(oParam) {
		return this.ctx.euromoda_calculaMetrosOPSeccion(oParam);
	}
	function emBuscaOrdenesDoblePteRx(oParam) {
		return this.ctx.euromoda_emBuscaOrdenesDoblePteRx(oParam);
	}
	function emBuscaOrdenesDobleExistencia(oParam) {
		return this.ctx.euromoda_emBuscaOrdenesDobleExistencia(oParam);
	}
	function emBuscaMovimientosSinPadre(oParam) {
		return this.ctx.euromoda_emBuscaMovimientosSinPadre(oParam);
	}
	function emBuscaMovimientosSinMovProducto(oParam) {
		return this.ctx.euromoda_emBuscaMovimientosSinMovProducto(oParam);
	}
	function emBuscaMoviCompSinFaltas(oParam) {
		return this.ctx.euromoda_emBuscaMoviCompSinFaltas(oParam);
	}
	function emDiagnostico(oParam) {
		return this.ctx.euromoda_emDiagnostico(oParam);
	}
	function enviaCorreo(mensaje, asunto) {
		return this.ctx.euromoda_enviaCorreo(mensaje, asunto);
	}
	function statusChanged(msg, code) {
		return this.ctx.euromoda_statusChanged(msg, code);
	}
	function emBuscaStockReservaExMal(oParam) {
		return this.ctx.euromoda_emBuscaStockReservaExMal(oParam);
	}
	function emBuscaStocksAFaltasMal(oParam) {
		return this.ctx.euromoda_emBuscaStocksAFaltasMal(oParam);
	}
	function emBuscaMoviPedServidos(oParam) {
		return this.ctx.euromoda_emBuscaMoviPedServidos(oParam);
	}
	function emBuscaPartidasMal(oParam) {
		return this.ctx.euromoda_emBuscaPartidasMal(oParam);
	}
	function emRehacerMovimientosOE(oParam) {
		return this.ctx.euromoda_emRehacerMovimientosOE(oParam);
	}	
	function emRehacerMovimientosPC(oParam) {
		return this.ctx.euromoda_emRehacerMovimientosPC(oParam);
	}
	function cambiaStocksMovTramoLote(oParam) {
		return this.ctx.euromoda_cambiaStocksMovTramoLote(oParam);
	}
	function creaMovimientosTPPE(oParam) {
		return this.ctx.euromoda_creaMovimientosTPPE(oParam);
	}
	function emBorraReservasTejidoOFF(oParam) {
		return this.ctx.euromoda_emBorraReservasTejidoOFF(oParam);
	}
	function cambiaIdStockMovTramoLote(oParam) {
		return this.ctx.euromoda_cambiaIdStockMovTramoLote(oParam);
	}
	function regeneraMovsLinEst(oParam) {
		return this.ctx.euromoda_regeneraMovsLinEst(oParam);
	}	
	function emArreglaCantNegaOE(oParam) {
		return this.ctx.euromoda_emArreglaCantNegaOE(oParam);
	}
	function emArreglaLotesNeg(oParam) {
		return this.ctx.euromoda_emArreglaLotesNeg(oParam);
	}
	function lineaEstCalc(oParam) {
		return this.ctx.euromoda_lineaEstCalc(oParam);
	}
	function calculaReservadaOE(oParam) {
		return this.ctx.euromoda_calculaReservadaOE(oParam);
	}
	function arreglaLineaEstCalc(codOrden) {
		return this.ctx.euromoda_arreglaLineaEstCalc(codOrden);
	}
	function emBuscaCtasCambianProv(oParam) {
		return this.ctx.euromoda_emBuscaCtasCambianProv(oParam);	
	}
	function emBuscaTramosEstMal(oParam) {
		return this.ctx.euromoda_emBuscaTramosEstMal(oParam);	
	}
	function emBuscaLineasEstMal(oParam) {
		return this.ctx.euromoda_emBuscaLineasEstMal(oParam);	
	}
	function emPedidosImporteMal(oParam) {
		return this.ctx.euromoda_emPedidosImporteMal(oParam);
	}
	function emLotesSinStock(oParam) {
		return this.ctx.euromoda_emLotesSinStock(oParam);
	}
	function emRecibosDecimalesMal(oParam) {
		return this.ctx.euromoda_emRecibosDecimalesMal(oParam);
	}
	function emRecibosEmitidosAcero(oParam) {
		return this.ctx.euromoda_emRecibosEmitidosAcero(oParam);
	}
	function emRecibosCompEmi(oParam) {
		return this.ctx.euromoda_emRecibosCompEmi(oParam);	
	}
	function emCantResMayorMov(oParam) {
		return this.ctx.euromoda_emCantResMayorMov(oParam);	
	}	
	function dameVistas() {
		return this.ctx.euromoda_dameVistas();
	}
	function emActualizaCamposColasOrdenesProd(oParam) {
		return this.ctx.euromoda_emActualizaCamposColasOrdenesProd(oParam);
	}
	function regeTodosReserPedidos(oParam) {
		return this.ctx.euromoda_regeTodosReserPedidos(oParam);
	}
	function regeneraReservasPedido(oParam) {
		return this.ctx.euromoda_regeneraReservasPedido(oParam);
	}
	function emBuscaOrdCantEstJose(oParam) {
		return this.ctx.euromoda_emBuscaOrdCantEstJose(oParam);
	}
	function emBuscaOrdTramoLineaDis(oParam) {
		return this.ctx.euromoda_emBuscaOrdTramoLineaDis(oParam);
	}
	function emOrdTramoLineaDis(oParam) {
		return this.ctx.euromoda_emOrdTramoLineaDis(oParam);
	}
	function emBuscaLinTramoRefDis(oParam) {
		return this.ctx.euromoda_emBuscaLinTramoRefDis(oParam);
	}	
	function emBuscaMovPteRecMal(oParam) {
		return this.ctx.euromoda_emBuscaMovPteRecMal(oParam);
	}
	function emBuscaStosksRepetidos(oParam) {
		return this.ctx.euromoda_emBuscaStosksRepetidos(oParam);
	}
	function emBuscaMovPteRecMalSilent(oParam) {
		return this.ctx.euromoda_emBuscaMovPteRecMalSilent(oParam);
	}	
	function emBuscaStockNegResPosSilent(oParam) {
		return this.ctx.euromoda_emBuscaStockNegResPosSilent(oParam);
	}
	function emBuscaStockNegResPos(oParam) {
		return this.ctx.euromoda_emBuscaStockNegResPos(oParam)
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();

	/// A�adido en oficial: _i.funciones.push(["emProcesaStocksPtes", "Procesa stocks pendientes de totalizar"]);
// 	_i.funciones.push(["emCargaVencimientos", "Recalcula y asocia los vencimientos a las facturas de cliente desde el 01-07-2012"]);
// 	_i.funciones.push(["emEstadosRemesaProv", "Recalcula el estado de las remesas de proveedor"]);
// 	_i.funciones.push(["emDepuraTamanosSubfamilia", "Depura tama�os repetidos por migraci�n para subfamilias"]);
// 	_i.funciones.push(["emDepuraTamanos", "Depura tama�os repetidos por migraci�n"]);
// 	_i.funciones.push(["emProcesaPedidosMigCli", "Procesa pedidos de cliente migrados"]);
// 	_i.funciones.push(["emProcesaPedidosMigProv", "Procesa pedidos de proveedor migrados"]);
// 	_i.funciones.push(["emProcesaPedidosMarco", "Procesa pedidos marco"]);
// 	_i.funciones.push(["emRestaMetrosPieza", "Resta metros de pieza"]);
// 	_i.funciones.push(["emCreaRegStocksCero", "Crea regularizaciones de stock a cero"]);
// 	_i.funciones.push(["emBorrarOrdenes", "Borra las �rdenes de producci�n indicadas. Deben estar PTEs (formato O1-O2)"]);
// 	_i.funciones.push(["emBorrarReservas2Ordenes", "Borra movimientos de reserva duplicados para �rdenes en distribuci�n"]);
// 	_i.funciones.push(["emMovimientosOFFaPTE", "Pasa movimientos OFF a PTE para �rdenes en estado PTE"]);
// 	_i.funciones.push(["emCorrigeTamanosem_dibujostamsub", "Cambia los c�digos de tama�o por valores que existen en la tabla de tama�os"]);
// 	_i.funciones.push(["emRevisarReservasXCliente", "Revisa la distribuci�n de las reservas en pedidos de cliente por fecha cliente"]);
// 	_i.funciones.push(["emRevisarConceptosMovistock", "Recalcula el campo concepto de los movimientos de stock"]);
// 	_i.funciones.push(["emRevisarReservas", "Recalcula las reservas en lotes pendientes y movimientos pendientes a faltas"]);
// 	_i.funciones.push(["emRevisaPedProvCerradosXPartidas", "Recalcula el estado cerrado de l�neas de pedidos prov con movimientos de merma asociados"]);
// 	_i.funciones.push(["emRevisaPedProvMermaXPartidas", "Recalcula la cantidad pendiente de los movimientos de merma con cantidad 0 correspondientes a l�neas de pedido que tienen pendiente de servir"]);
	_i.funciones.push(["emCreaMovMerma0PedCli", "Crea movimientos de merma 0 para poder calcular metros distribuidos en 28 casos"]);
	_i.funciones.push(["emRevisaMermaPartidas", "Revisa metros distribuidos y merma de todos los lotes LIKE PT%"]);
	_i.funciones.push(["emRevisaTotalesPartidas", "Revisa totales, metros distribuidos y merma de todos los lotes LIKE PT%"]);
	_i.funciones.push(["emRevisaTotalesPiezas", "Revisa totales, metros distribuidos y merma de todos los lotes LIKE PZ%"]);
	_i.funciones.push(["emRevisarConceptosMovistock", "Recalcula el campo concepto de los movimientos de stock"]);
	_i.funciones.push(["emRevisaFechaServicioPedPte", "Revisa la fecha de servicio de los pedidos de cliente pendientes"]);
	_i.funciones.push(["emActualizaIdArticuloCompMovimientos", "Informa el campo idarticulocomp en movistocks para aquellos movimientos que tienen asociado un movimiento de producto"]);
	_i.funciones.push(["emCompruebaSaldoProv", "Busca la causa de un descuadre en el saldo contable - facturaci�n del proveedor"]);
	_i.funciones.push(["emActualizaLotesAsignacion27", "Revisa movimientos stock lotes asignaci�n 27"]);
	_i.funciones.push(["lanzaPedidosAsignacion", "Lanza los pedidos a proveedor asociados a una lista de asignaciones"]);	
	_i.funciones.push(["emRevisaReservasTejidoPrev", "Revisa reservas de tejido preparado"]);
	_i.funciones.push(["emRevisaReservasLPAFaltas", "Revisa reservas de l�neas de pedido de cliente a faltas"]);		
	_i.funciones.push(["revisaEanInternos", "Revisa los EAN de art�culos asociados a familias de tipo EAN Interno"]);	
	_i.funciones.push(["emCompruebaReservasPedidos", "Comprueba reservas de pedidos a faltas que no han reservado materiales"]);
	_i.funciones.push(["emBuscaOrdenesIncorrectas", "Busca �rdenes con dos pedidos asociados"]);
	_i.funciones.push(["emBuscaOrdenesDoblePteRx", "Busca �rdenes con dos movimientos de pendiente de recibir por lote"]);
	_i.funciones.push(["emBuscaOrdenesDobleExistencia", "Busca �rdenes con dos movimientos de existencias por lote"]);
	_i.funciones.push(["emBuscaMovimientosSinPadre", "Busca movimientos sin objeto que los justifique"]);
	_i.funciones.push(["emBuscaMovimientosSinMovProducto", "Busca movimientos de consumo sin movimiento de material que los justifique"]);
	_i.funciones.push(["emBuscaMoviCompSinFaltas", "Busca movimientos de composici�n asociados a movimientos de producto sin faltas"]);
	_i.funciones.push(["emBuscaStockReservaExMal", "Busca stocks con reservas de existencias superiores a las existencias f�sicas"]);
	_i.funciones.push(["emBuscaStocksAFaltasMal", "Busca stocks con a faltas no coincidentes con la suma de sus movimientos"]);
	_i.funciones.push(["emBuscaMoviPedServidos", "Busca movimientos pendientes asociados a l�neas de pedido ya servidas"]);
	_i.funciones.push(["emBuscaPartidasMal", "Busca partidas contables incoherentes"]);
	_i.funciones.push(["emDiagnostico", "Diagn�stico general Euromoda"]);
	_i.funciones.push(["emRehacerMovimientosOE", "Rehacer movimientos de OE"]);
	_i.funciones.push(["emRehacerMovimientosPC", "Rehacer movimientos de Pedidos de cliente"]);
	_i.funciones.push(["cambiaStocksMovTramoLote", "Cambiar de idstock los movimientos asociados a tramos y que no coinciden con el almac�n del lote"]);
	_i.funciones.push(["creaMovimientosTPPE", "Regenerar movimientos TPPE"]);
	_i.funciones.push(["emBorraReservasTejidoOFF", "Borra la cadena de reservas de tejido de movimientos en estado OFF"]);
	_i.funciones.push(["cambiaIdStockMovTramoLote", "Cambiar idstock de los movimientos asociados a tramos del almac�n 58 por el almac�n 1"]);
	_i.funciones.push(["regeneraMovsLinEst", "Regenera movimientos l�neas de estampaci�n"]);
	_i.funciones.push(["emArreglaCantNegaOE", "Revisar cantidades negativas en OE"]);
	_i.funciones.push(["emArreglaLotesNeg", "Revisar cantidades negativas en partidas"]);
	_i.funciones.push(["lineaEstCalc", "Arregla idlineaestcalc"]);	
	_i.funciones.push(["calculaReservadaOE", "Calcula reservadaOE de stock"]);
	_i.funciones.push(["emBuscaCtasCambianProv", "Busca cuentas con tipo especial PROVEE que hayan cambiado"]);
	_i.funciones.push(["emBuscaTramosEstMal", "Busca �rdenes de estampaci�n cuya cantidad estampada es distinta de la suma de cantidad estampada de los tramos"]);
	_i.funciones.push(["emBuscaLineasEstMal", "Busca �rdenes de estampaci�n cuya cantidad estampada es distinta de la suma de cantidad estampada de las l�neas"]);
	_i.funciones.push(["emPedidosImporteMal", "Busca pedidos cuya suma de importe de las l�neas no coincida con el importe de la cabecera"]);
	_i.funciones.push(["emLotesSinStock", "Busca lotes cuya referencia-almacen no exista en stocks."]);
	_i.funciones.push(["emRecibosDecimalesMal", "Busca recibos con m�s de dos decimales en sus importes."]);
	_i.funciones.push(["emRecibosEmitidosAcero", "Busca recibos emitidos con importe a cero"]);
	_i.funciones.push(["emRecibosCompEmi", "Busca recibos compensados con un recibo emitido"]);
	_i.funciones.push(["emCantResMayorMov", "Busca movimientos con cantidad reservada mayor que la cantidad"]);	
	_i.funciones.push(["emCargaFactoresFT", "Informa los campos de piezas por ancho y cms por pieza en art�culos"]);
	_i.funciones.push(["calculaMetrosOPSeccion", "Informa los campos de metros en OP indicando seccion"]);	
	_i.funciones.push(["emActualizaCamposColasOrdenesProd", "Calcula los valores de agrupaci�n. acabados, etc. asociados a las colas de producci�n"]);
	_i.funciones.push(["regeTodosReserPedidos", "Regenerar reservas de todos los pedidos"]);
	_i.funciones.push(["regeneraReservasPedido", "Regenerar reservas de un pedido"]);	
	_i.funciones.push(["emBuscaOrdCantEstJose", "Busca ordenes en la que la cantidad estampada de la linea es distinta a la suma de sus tramos (J)"]);	
	_i.funciones.push(["emBuscaOrdTramoLineaDis", "Busca �rdenes en las que la orden de la l�nea y de los tramos no coinciden"]);	
	_i.funciones.push(["emOrdTramoLineaDis", "Ver y arreglar si la orden del tramo y de la l�nea coincide"]);	
	_i.funciones.push(["emBuscaLinTramoRefDis", "Busca l�neas que coincidiendo la orden de la linea y el tramo, las referencias de tramo y linea no coinciden"]);	
	_i.funciones.push(["emBuscaMovPteRecMal", "Busca Stocks que no coincide su pendiente de recibir con la suma de sus movimientos"]);
	_i.funciones.push(["emBuscaStosksRepetidos", "Busca en stocks registros repetidos para la misma referencia y mismo almac�n"]);
	_i.funciones.push(["emBuscaMovPteRecMalSilent", "Silent Busca Stocks que no coincide su pendiente de recibir con la suma de sus movimientos"]);
	_i.funciones.push(["emBuscaStockNegResPos", "Busca Stocks negativos con reservas positivas."]);
	_i.funciones.push(["emBuscaStockNegResPosSilent", "Silent Busca Stocks negativos con reservas positivas."]);
}

// function euromoda_ejecutarFuncion()
// {
// 	var _i = this.iface;
// 	var funcion = this.cursor().valueBuffer( "funcion" ).toString();
//
//
// 	switch ( funcion ) {
// 		case "emProcesaPedidosMigCli": {
// 			var res:Object = MessageBox.information(sys.translate("�Seguro que desea ejecutar esta funci�n?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
// 			if (res != MessageBox.Yes)
// 				return;
//
// 			_i.emProcesaPedidosMigCli();
// 			break;
// 		}
// 		default: {
// 			_i.__ejecutarFuncion();
// 		}
// 	}
// }


function euromoda_emCargaVencimientos(oParam)
{
	var codFactura = Input.getText(sys.translate("Factura (0 para todas)"));
	if (!codFactura) {
		return;
	}
	if (codFactura == "0") {
		var res = MessageBox.warning(sys.translate("Va a recalcular los vencimientos de las facturas de cliente desde el 01-07-2012\n�Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	var curFactura = new FLSqlCursor("facturascli");
	if (codFactura != "0") {
		curFactura.select("codigo = '" + codFactura + "'");
	} else {
		curFactura.select("fecha >= '2012-07-01'");
	}
	var vencimientos, idFactura, editable;
	var curF = new FLSqlCursor("facturascli");
	curF.setActivatedCommitActions(false);
	curF.setActivatedCheckIntegrity(false);

	AQUtil.createProgressDialog(sys.translate("Calculando vencimientos"), curFactura.size());
	var p = 0;
	while (curFactura.next()) {
		AQUtil.setProgress(p++);
		curFactura.setModeAccess(curFactura.Browse);
		curFactura.refreshBuffer();

		vencimientos = formfacturascli.iface.pub_commonCalculateField("em_vencimientos", curFactura);

		idFactura = curFactura.valueBuffer("idfactura");
		curF.select("idfactura = " + idFactura);
		if (!curF.first()) {
			debug("1");
			AQUtil.destroyProgressDialog();
			return false;
		}
		editable = curF.valueBuffer("editable");
		if (!editable) {
			curF.setUnLock("editable", true);
			curF.select("idfactura = " + idFactura);
			if (!curF.first()) {
				debug("2");
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
		curF.setModeAccess(curFactura.Edit);
		curF.refreshBuffer();
		curF.setValueBuffer("em_vencimientos", vencimientos);
		if (!curF.commitBuffer()) {
			debug("3");
			AQUtil.destroyProgressDialog();
			return false;
		}
		if (!editable) {
			curF.select("idfactura = " + idFactura);
			if (!curF.first()) {
				debug("4");
				AQUtil.destroyProgressDialog();
				return false;
			}
			curF.setUnLock("editable", false);
		}
	}

	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emEstadosRemesaProv(oParam)
{
	var _rP = formRecordremesasprov.iface;
	_rP.pagoIndirecto_ = AQUtil.sqlSelect("factteso_general", "pagoindirectoprov", "1 = 1");
	_rP.pagoDiferido_ = flfactteso.iface.pub_valorDefectoTesoreria("pagodiferidoprov");

	var curR = new FLSqlCursor("remesasprov");
	curR.select("1 = 1");

	AQUtil.createProgressDialog(sys.translate("Revisando remesas"), curR.size());
	var p = 0;
	while (curR.next()) {
		curR.setModeAccess(curR.Edit);
		curR.refreshBuffer();
		AQUtil.setProgress(p++);
		AQUtil.setLabelText(sys.translate("Revisando remesa %1").arg(curR.valueBuffer("idremesa")));
		curR.setValueBuffer("estado", _rP.pub_commonCalculateField("estado", curR));
		if (!curR.commitBuffer()) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
	}
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	return true;
}

function euromoda_emDepuraTamanosSubfamilia(oParam)
{
	var q = new FLSqlQuery;
	q.setSelect("codtamanoem, codsubfamilia, count(*)");
	q.setFrom("em_tamanossubfam");
	q.setWhere("1 = 1 GROUP BY codtamanoem, codsubfamilia HAVING COUNT(*) > 1");
	if (!q.exec()) {
		return false;
	}
	var curTS = new FLSqlCursor("em_tamanossubfam");
	curTS.setActivatedCheckIntegrity(false);
	while (q.next()) {
		curTS.select("codtamanoem = '" + q.value("codtamanoem") + "' AND codsubfamilia = '" + q.value("codsubfamilia") + "'");
		if (curTS.first()) {
			curTS.setModeAccess(curTS.Del);
debug("Borrando " + "codtamanoem = '" + q.value("codtamanoem") + "' AND codsubfamilia = '" + q.value("codsubfamilia") + "'");
			if (!curTS.commitBuffer()) {
				return false;
			}
		}
	}
	q.setSelect("codtamanoem, codsubfamilia");
	q.setFrom("em_tamanossubfam");
	q.setWhere("codtamanoem LIKE '%.'");
	if (!q.exec()) {
		return false;
	}
	while (q.next()) {
		curTS.select("codtamanoem = '" + q.value("codtamanoem") + "' AND codsubfamilia = '" + q.value("codsubfamilia") + "'");
		if (curTS.first()) {
			curTS.setModeAccess(curTS.Del);
debug("Borrando " + "codtamanoem = '" + q.value("codtamanoem") + "' AND codsubfamilia = '" + q.value("codsubfamilia") + "'");
			if (!curTS.commitBuffer()) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_emDepuraTamanos(oParam)
{
	var q = new FLSqlQuery;
	q.setSelect("codtamanoem, codigogit");
	q.setFrom("em_tamanos");
	q.setWhere("1 = 1 ORDER BY codigogit");
	if (!q.exec()) {
		return false;
	}
// 	var curTS = new FLSqlCursor("em_tamanossubfam");
// 	curTS.setActivatedCheckIntegrity(false);
	AQUtil.createProgressDialog(sys.translate("Revisando tama�os"), q.size());
	var codGitAnt = false, codGit, codTamanoAnt = false, codTamanoAnt;
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(p++);
		codTamano = q.value("codtamanoem");
		AQUtil.setLabelText(sys.translate("Revisando tama�o %1").arg(codTamano));
		codGit = q.value("codigogit");
		if (codGit != codGitAnt) {
			codGitAnt = codGit;
			codTamanoAnt = codTamano;
			continue;
		}
		if (!AQUtil.execSql("UPDATE articulos SET codtamanoem = '" + codTamanoAnt + "' WHERE codtamanoem = '" + codTamano + "'")) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		if (!AQUtil.execSql("UPDATE articuloscomp SET codtamanoem = '" + codTamanoAnt + "' WHERE codtamanoem = '" + codTamano + "'")) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		if (!AQUtil.execSql("UPDATE em_tamanossubfam SET codtamanoem = '" + codTamanoAnt + "' WHERE codtamanoem = '" + codTamano + "'")) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		if (!AQUtil.execSql("UPDATE em_plantillasprod SET codtamanoem = '" + codTamanoAnt + "' WHERE codtamanoem = '" + codTamano + "'")) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		if (!AQUtil.execSql("UPDATE em_lineasplantillaprod SET codtamanoem = '" + codTamanoAnt + "' WHERE codtamanoem = '" + codTamano + "'")) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		if (!AQUtil.execSql("DELETE FROM em_tamanos WHERE codtamanoem = '" + codTamano + "'")) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
	}
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	return true;
}

function euromoda_emProcesaPedidosMigCli(oParam)
{
debug("va");
	var curT = new FLSqlCursor("empresa");
	var curP = new FLSqlCursor("pedidoscli");
	curP.setActivatedCommitActions(false);
	var curP2 = new FLSqlCursor("pedidoscli");
	curP2.setActivatedCommitActions(false);
	curP.select("codserie = 'Z' AND codcliente IS NOT NULL ORDER BY fechaservicio");
	AQUtil.createProgressDialog(sys.translate("Procesando pedidos"), curP.size());
	var p = 0;
	var codCliente, numero;
	var qC = new AQSqlQuery;
	qC.setSelect("c.nombre, c.cifnif, c.codgrupoivaneg, c.codpago, c.em_codpago, c.coddivisa, c.codclientefac, c.incoterm, c.pobincoterm, d.id, d.direccion, d.codpostal, d.ciudad, d.idprovincia, d.provincia, d.codpais");
	qC.setFrom("clientes c LEFT OUTER JOIN dirclientes d ON c.codcliente = d.codcliente AND d.domfacturacion");
	var curL = new FLSqlCursor("lineaspedidoscli");
	var fCalculaCampo = formRecordlineaspedidoscli.iface.pub_commonCalculateField;
debug("va1");
	var idPedido, servido;
// 	if (curP.first()) {
	while (curP.next()) {
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		AQUtil.setProgress(p++);
		codCliente = curP.valueBuffer("codcliente");
		qC.setWhere("c.codcliente = '" + codCliente + "'");
		if (!qC.exec()) {
			debug("FALLO 234");
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		if (!qC.first()) {
			debug("No encuentra cliente " + codCliente);
			debug("FALLO 12");
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		curP.setValueBuffer("nombrecliente", qC.value("c.nombre"));
		curP.setValueBuffer("cifnif", qC.value("c.cifnif"));
		curP.setValueBuffer("coddivisa", qC.value("c.coddivisa"));
		curP.setValueBuffer("codpago", qC.value("c.codpago"));
		curP.setValueBuffer("em_codpago", qC.value("c.em_codpago"));
		curP.setValueBuffer("codclientefac", qC.value("c.codclientefac"));
		curP.setValueBuffer("incoterm", qC.value("c.incoterm"));
		curP.setValueBuffer("pobincoterm", qC.value("c.pobincoterm"));
		curP.setValueBuffer("codgrupoivaneg", qC.value("c.codgrupoivaneg"));
		if (qC.value("d.direccion")) {
			curP.setValueBuffer("direccion", qC.value("d.direccion"));
			curP.setValueBuffer("codpostal", qC.value("d.codpostal"));
			curP.setValueBuffer("ciudad", qC.value("d.ciudad"));
			curP.setValueBuffer("idprovincia", qC.value("d.idprovincia"));
			curP.setValueBuffer("provincia", qC.value("d.provincia"));
			curP.setValueBuffer("codpais", qC.value("d.codpais"));
		}
		curP.setValueBuffer("tasaconv", AQUtil.sqlSelect("divisas", "tasaconv", "coddivisa = '" + curP.valueBuffer("coddivisa") + "'"));
		curP.setValueBuffer("codserie", AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli gc ON c.codgrupocontablecli = gc.codgrupo", "gc.codseriefac", "c.codcliente = '" + curP.valueBuffer("codcliente") + "'", "clientes"));
		numero = flfacturac.iface.siguienteNumero(curP.valueBuffer("codserie"), curP.valueBuffer("codejercicio"), "npedidocli");
		if (!numero) {
			debug("FALLO 30");
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		curP.setValueBuffer("numero", numero);
		curP.setValueBuffer("codigo", formpedidoscli.iface.pub_commonCalculateField("codigo", curP));
		idPedido = curP.valueBuffer("idpedido");
		if (!curP.commitBuffer()) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			debug("FALLO 31");
			return false;
		}

		curL.select("idpedido = " + idPedido);
debug("pedido = " + curP.valueBuffer("codigo") + " idpedido " + idPedido);
		while (curL.next()) {
			curL.setModeAccess(curL.Edit);
			curL.refreshBuffer();
debug("linea " + curL.valueBuffer("numlinea"));
			curL.setValueBuffer("tipoconcepto", "Producto");
			curL.setValueBuffer("descripcion", fCalculaCampo("desarticulo", curL));
			curL.setValueBuffer("pvpunitario", fCalculaCampo("pvpunitario", curL));
			curL.setValueBuffer("dtopor", fCalculaCampo("dtopor", curL));
			curL.setValueBuffer("pvpsindto", fCalculaCampo("pvpsindto", curL));
			curL.setValueBuffer("pvptotal", fCalculaCampo("pvptotal", curL));
			curL.setValueBuffer("porcomision", fCalculaCampo("porcomision", curL));
			curL.setValueBuffer("codarancelario", AQUtil.sqlSelect("articulos", "codarancelario", "referencia = '" + curL.valueBuffer("referencia") + "'"));
			curL.setValueBuffer("refcliente", AQUtil.sqlSelect("articulos", "aliasart", "referencia = '" + curL.valueBuffer("referencia") + "'"));
			curL.setValueBuffer("codimpuesto", fCalculaCampo("codimpuesto", curL));
			curL.setValueBuffer("iva", fCalculaCampo("iva", curL));
			curL.setValueBuffer("recargo", fCalculaCampo("recargo", curL));
			curL.setValueBuffer("cerrada", false);
			if (!curL.commitBuffer()) {
				return false;
			}
		}
		curP2.select("idpedido = " + idPedido);
		if (!curP2.first()) {
			debug("FALLO 32");
			return false;
		}
		curP2.setModeAccess(curP2.Edit);
		curP2.refreshBuffer();
		formpresupuestoscli.iface.curPedido = curP2;

		servido = flfacturac.iface.obtenerEstadoPedidoCli(idPedido);

		if (!formpresupuestoscli.iface.totalesPedido()) {
			return false;
		}
		curP2.setValueBuffer("servido", servido);
		if (!curP2.commitBuffer()) {
			debug("FALLO 34");
			return false;
		}
// 		curT.commit();
// 		curT.transaction(false);
// 		curP.select("codserie = 'Z' AND codcliente IS NOT NULL ORDER BY fechaservicio");
	}
debug("Todo OK");
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	return true;
}

function euromoda_emProcesaPedidosMigProv(oParam)
{
debug("va");
	if (!AQUtil.execSql("UPDATE pedidosprov SET editable = true WHERE codserie = 'Z'")) {
		return false;
	}
	var curP = new FLSqlCursor("pedidosprov");
	curP.setActivatedCommitActions(false);
	var curP2 = new FLSqlCursor("pedidosprov");
	curP2.setActivatedCommitActions(false);
	curP.select("codserie = 'Z' AND codproveedor IS NOT NULL ORDER BY fecha");
	AQUtil.createProgressDialog(sys.translate("Procesando pedidos de proveedor"), curP.size());
	var p = 0;
	var codProveedor, numero;
	var qC = new AQSqlQuery;
	qC.setSelect("p.nombre, p.cifnif, p.codgrupoivaneg, p.codpago, p.em_codpago, p.coddivisa");
	qC.setFrom("proveedores p");
	var curL = new FLSqlCursor("lineaspedidosprov");
	var fCalculaCampo = formRecordlineaspedidosprov.iface.pub_commonCalculateField;
debug("va1");
	var idPedido, servido;
// 	if (curP.first()) {
	while (curP.next()) {
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		AQUtil.setProgress(p++);
		codProveedor = curP.valueBuffer("codproveedor");
		qC.setWhere("p.codproveedor = '" + codProveedor + "'");
		if (!qC.exec()) {
			debug("FALLO 234");
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		if (!qC.first()) {
			debug("No encuentra el proveedor " + codProveedor);
			debug("FALLO 12");
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
		curP.setValueBuffer("nombre", qC.value("p.nombre"));
		curP.setValueBuffer("cifnif", qC.value("p.cifnif"));
		curP.setValueBuffer("coddivisa", qC.value("p.coddivisa"));
		curP.setValueBuffer("codpago", qC.value("p.codpago"));
		curP.setValueBuffer("em_codpago", qC.value("p.em_codpago"));
		curP.setValueBuffer("codgrupoivaneg", qC.value("p.codgrupoivaneg"));
// 		if (qC.value("d.direccion")) {
// 			curP.setValueBuffer("direccion", qC.value("d.direccion"));
// 			curP.setValueBuffer("codpostal", qC.value("d.codpostal"));
// 			curP.setValueBuffer("ciudad", qC.value("d.ciudad"));
// 			curP.setValueBuffer("idprovincia", qC.value("d.idprovincia"));
// 			curP.setValueBuffer("provincia", qC.value("d.provincia"));
// 			curP.setValueBuffer("codpais", qC.value("d.codpais"));
// 		}
		curP.setValueBuffer("tasaconv", AQUtil.sqlSelect("divisas", "tasaconv", "coddivisa = '" + curP.valueBuffer("coddivisa") + "'"));
		curP.setValueBuffer("codserie", AQUtil.sqlSelect("proveedores p INNER JOIN gruposcontablesprov gp ON p.codgrupocontableprov = gp.codgrupo", "gp.codseriefac", "p.codproveedor = '" + curP.valueBuffer("codproveedor") + "'", "proveedores"));
		codGit = curP.valueBuffer("codigo");
		/// Los pedidos de orden de producci�n no obtienen un c�digo AbanQ
		if (!(codGit.startsWith("400/") || codGit.startsWith("800/") || codGit.startsWith("850/"))) {
			numero = flfacturac.iface.siguienteNumero(curP.valueBuffer("codserie"), curP.valueBuffer("codejercicio"), "npedidoprov");
			if (!numero) {
				debug("FALLO 30");
				sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
				return false;
			}
			curP.setValueBuffer("numero", numero);
			curP.setValueBuffer("codigo", formpedidosprov.iface.pub_commonCalculateField("codigo", curP));
		}
		idPedido = curP.valueBuffer("idpedido");
		if (!curP.commitBuffer()) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			debug("FALLO 31");
			return false;
		}

		curL.select("idpedido = " + idPedido);
debug("pedido = " + curP.valueBuffer("codigo") + " idpedido " + idPedido);
		while (curL.next()) {
			curL.setModeAccess(curL.Edit);
			curL.refreshBuffer();
debug("linea " + curL.valueBuffer("idlinea"));
			curL.setValueBuffer("tipoconcepto", "Producto");
			curL.setValueBuffer("descripcion", fCalculaCampo("desarticulo", curL));
// 			curL.setValueBuffer("pvpunitario", fCalculaCampo("pvpunitario", curL));
// 			curL.setValueBuffer("dtopor", fCalculaCampo("dtopor", curL));
// 			curL.setValueBuffer("pvpsindto", fCalculaCampo("pvpsindto", curL));
// 			curL.setValueBuffer("pvptotal", fCalculaCampo("pvptotal", curL));
			curL.setValueBuffer("codimpuesto", fCalculaCampo("codimpuesto", curL));
			curL.setValueBuffer("iva", fCalculaCampo("iva", curL));
			curL.setValueBuffer("recargo", fCalculaCampo("recargo", curL));
			curL.setValueBuffer("cerrada", false);
			if (!curL.commitBuffer()) {
				return false;
			}
		}
		curP2.select("idpedido = " + idPedido);
		if (!curP2.first()) {
			debug("FALLO 32");
			return false;
		}
		curP2.setModeAccess(curP2.Edit);
		curP2.refreshBuffer();

		servido = flfacturac.iface.obtenerEstadoPedidoProv(idPedido);
		with (curP2) {
			setValueBuffer("neto", formpedidosprov.iface.pub_commonCalculateField("neto", this));
			setValueBuffer("totaliva", formpedidosprov.iface.pub_commonCalculateField("totaliva", this));
			setValueBuffer("totalirpf", formpedidosprov.iface.pub_commonCalculateField("totalirpf", this));
			setValueBuffer("totalrecargo", formpedidosprov.iface.pub_commonCalculateField("totalrecargo", this));
			setValueBuffer("total", formpedidosprov.iface.pub_commonCalculateField("total", this));
			setValueBuffer("totaleuros", formpedidosprov.iface.pub_commonCalculateField("totaleuros", this));
			setValueBuffer("servido", servido);
		}
// 		formpresupuestoscli.iface.curPedido = curP2;
// 		if (!formpresupuestoscli.iface.totalesPedido()) {
// 			return false;
// 		}
		if (!curP2.commitBuffer()) {
			debug("FALLO 34");
			return false;
		}
	}
debug("Todo OK");
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	return true;
}


function euromoda_emProcesaPedidosMarco(oParam)
{
	var curP = new FLSqlCursor("pedidosmarcocli");
	curP.select("1 = 1");
	AQUtil.createProgressDialog(sys.translate("Procesando pedidos marco"), curP.size());
	var p = 0;
	while (curP.next()) {
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		AQUtil.setProgress(p++);
		curP.setValueBuffer("emestado", "Pendiente");
		if (!curP.commitBuffer()) {
			debug("FALLO 34");
			return false;
		}
	}
debug("Todo OK");
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	return true;
}

function euromoda_emRestaMetrosPieza(oParam)
{
	var param = Input.getText("Pieza;Metros");
	if (!param) {
		return false;
	}
	var xml = flfactalma.iface.pub_rpcRestaMetrosPieza(param);
	sys.infoMsgBox(xml);
	return true;
}
/**
function euromoda_emProcesaStocksPtes(oParam)
{
	var q = new FLSqlQuery;
	q.setSelect("idusuario");
	q.setFrom("stocksptes");
	q.setWhere("1 = 1 GROUP BY idusuario");
	if (!q.exec()) {
		return false;
	}
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Procesando stocks"), q.size());
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(p++);
		if (!flfactalma.iface.procesaStocks(q.value("idusuario"))) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();

	return true;
}*/

function euromoda_emCreaRegStocksCero()
{
	var curStock = new FLSqlCursor("stocks");
	curStock.select("codalmacen = '1' AND fechaultreg IS NULL");
	var curRS = new FLSqlCursor("lineasregstocks");
	curRS.setActivatedCommitActions(false);
	var fechaReg = "2012-03-29";
	var motivo = sys.translate("Migraci�n inicial de cantidades 0");
	var hoy = new Date;
  var hora = hoy.toString().right(8);
  AQUtil.createProgressDialog(sys.translate("Creando regularizaciones de stock"), curStock.size());
	var paso = 0, referencia, cantidad, idStock;
	while (curStock.next()) {
		AQUtil.setProgress(paso++);
    curStock.setModeAccess(curStock.Edit);
    curStock.refreshBuffer();
    referencia = curStock.valueBuffer("referencia");
    cantidad = 0;
    idStock = curStock.valueBuffer("idstock");//pineboo 21-08-2019
		curRS.setModeAccess(curRS.Insert);
		curRS.refreshBuffer();
		curRS.setValueBuffer("idstock", idStock);
		curRS.setValueBuffer("fecha", fechaReg);
		curRS.setValueBuffer("hora", hora);
		curRS.setValueBuffer("cantidadini", 0);
		curRS.setValueBuffer("cantidadfin", cantidad);
		curRS.setValueBuffer("motivo", motivo);
		if (!curRS.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		curStock.setValueBuffer("fechaultreg", fechaReg);
		curStock.setValueBuffer("horaultreg", hora);
		curStock.setValueBuffer("cantidadultreg", cantidad);
		curStock.setValueBuffer("cantidad", formRecordregstocks.iface.pub_commonCalculateField("cantidad", curStock));
		curStock.setValueBuffer("pterecibir", formRecordregstocks.iface.pub_commonCalculateField("pterecibir", curStock));
		curStock.setValueBuffer("prevision", formRecordregstocks.iface.pub_commonCalculateField("prevision", curStock));
		if (!flfactalma.iface.pub_calculaReservasStock(curStock)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
    if (!curStock.commitBuffer()) {
      AQUtil.destroyProgressDialog();
      return false;
    }
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emBorrarOrdenes()
{
	var ordenes = Input.getText(sys.translate("Desde-Hasta"));
	if (!ordenes) {
		return false;
	}
	var aO = ordenes.split("-");
	if (!aO || aO.length != 2) {
		return false;
	}
	var o1 = "OP" + flfactppal.iface.pub_cerosIzquierda(aO[0], 8);
	var o2 = "OP" + flfactppal.iface.pub_cerosIzquierda(aO[1], 8);

	var curOrdenes = new FLSqlCursor("pr_ordenesproduccion");
	curOrdenes.select("codorden >= '" + o1 + "' AND codorden <= '" + o2 + "'");
	AQUtil.createProgressDialog(sys.translate("Creando regularizaciones de stock"), curOrdenes.size());
	while (curOrdenes.next()) {
		AQUtil.setProgress(paso++);
    if (!formpr_ordenesproduccion.iface.borrarOrden(curOrdenes.valueBuffer("codorden"))) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emBorrarReservas2Ordenes()
{
	var curOrdenes = new FLSqlCursor("pr_ordenesproduccion");
	var curMoviStock = new FLSqlCursor("movistock");
	var idProceso, codOrden;
	curOrdenes.select("codconfeccionista IS NOT NULL");
	AQUtil.createProgressDialog(sys.translate("Depurando reservas de stock"), curOrdenes.size());
	var paso = 0;
	while (curOrdenes.next()) {
		curOrdenes.setModeAccess(curOrdenes.Edit);
		curOrdenes.refreshBuffer();
		codOrden = curOrdenes.valueBuffer("codorden");
		AQUtil.setProgress(paso++);
		if (!AQUtil.sqlSelect("pedidosprov", "idpedido", "codordenprod = '" + codOrden + "'")) {
			continue;
		}

		idProceso = AQUtil.sqlSelect("pr_procesos", "idproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "'");
		if (!idProceso) {
			sys.warnMsgBox(sys.translate("Error al localizar el proceso de producci�n asociado a la orden %1").arg(codOrden));
			return false;
		}
		curMoviStock.select("idproceso = " + idProceso + " AND estado = 'PTE'");
		while (curMoviStock.next()) {
			curMoviStock.setModeAccess(curMoviStock.Del);
			curMoviStock.refreshBuffer();
			if (!curMoviStock.commitBuffer()) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emMovimientosOFFaPTE()
{
	var q = new AQSqlQuery;
	q.setSelect("ms.idmovimiento");
	q.setFrom("pr_ordenesproduccion o INNER JOIN lotesstock ls ON o.codorden = ls.codordenproduccion INNER JOIN movistock ms ON ls.codlote = ms.codloteprod");
	q.setWhere("o.estado = 'PTE' AND ms.estado = 'OFF'");
	if (!q.exec()) {
		return false;
	}
	var curMS = new FLSqlCursor("movistock");
	AQUtil.createProgressDialog(sys.translate("Cambiando estado de movimientos"), q.size());
	var paso = 0, idMov;
	while (q.next()) {
		AQUtil.setProgress(++paso);
		idMov = q.value("ms.idmovimiento");
		curMS.select("idmovimiento = " + idMov);
		if (!curMS.first()) {
			AQUtil.destroyProgressDialog();
			debug("Movimiento " + idMov + " no encontrado");
			return false;
		}
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		curMS.setValueBuffer("estado", "PTE");
		if (!curMS.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			debug("Commit movimiento " + idMov + " ha fallado");
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emCorrigeTamanosem_dibujostamsub()
{
	var q = new AQSqlQuery;
	q.setSelect("dts.codtamanoem");
	q.setFrom("em_dibujostamsub dts LEFT OUTER JOIN em_tamanos t ON dts.codtamanoem = t.codtamanoem");
	q.setWhere("t.codtamanoem IS NULL");
	if (!q.exec()) {
		return false;
	}
	AQUtil.createProgressDialog(sys.translate("Corrigiendo tama�os"), q.size());
	var paso = 0, tam, tam2, tamU;
	while (q.next()) {
		tamU = false;
		AQUtil.setProgress(++paso);
		tam = q.value("dts.codtamanoem");
		if (tam.endsWith(".")) {
			tam2 = tam.left(tam.length - 1);
			while (tam2.endsWith(".") && tam2.length > 1) {
				tam2 = tam2.left(tam2.length - 1);
			}
		} else {
			tam2 = tam + ".";
		}
		tamU = AQUtil.sqlSelect("em_tamanos", "codtamanoem", "UPPER(codtamanoem) = '" + tam2.toUpperCase() + "'")
		if (tamU) {
			if (!AQUtil.execSql("UPDATE em_dibujostamsub SET codtamanoem = '" + tamU + "' WHERE codtamanoem = '" + tam + "'")) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		} else {
			tamU = AQUtil.sqlSelect("em_tamanos", "codtamanoem", "UPPER(codtamanoem) = '" + tam.toUpperCase() + "'")
			if (tamU) {
				if (!AQUtil.execSql("UPDATE em_dibujostamsub SET codtamanoem = '" + tamU + "' WHERE codtamanoem = '" + tam + "'")) {
					AQUtil.destroyProgressDialog();
					return false;
				}
			}
		}
		if (!tamU) {
			debug("Salta tama�o " + tam);
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emActualizaTotalEnAlbaran()
{
	var q = new AQSqlQuery;
	q.setSelect("dts.codtamanoem");
	q.setFrom("em_dibujostamsub dts LEFT OUTER JOIN em_tamanos t ON dts.codtamanoem = t.codtamanoem");
	q.setWhere("t.codtamanoem IS NULL");
	if (!q.exec()) {
		return false;
	}
	AQUtil.createProgressDialog(sys.translate("Corrigiendo tama�os"), q.size());
	var paso = 0, tam, tam2, tamU;
	while (q.next()) {
		tamU = false;
		AQUtil.setProgress(++paso);
		tam = q.value("dts.codtamanoem");
		if (tam.endsWith(".")) {
			tam2 = tam.left(tam.length - 1);
			while (tam2.endsWith(".") && tam2.length > 1) {
				tam2 = tam2.left(tam2.length - 1);
			}
		} else {
			tam2 = tam + ".";
		}
		tamU = AQUtil.sqlSelect("em_tamanos", "codtamanoem", "UPPER(codtamanoem) = '" + tam2.toUpperCase() + "'")
		if (tamU) {
			if (!AQUtil.execSql("UPDATE em_dibujostamsub SET codtamanoem = '" + tamU + "' WHERE codtamanoem = '" + tam + "'")) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		} else {
			tamU = AQUtil.sqlSelect("em_tamanos", "codtamanoem", "UPPER(codtamanoem) = '" + tam.toUpperCase() + "'")
			if (tamU) {
				if (!AQUtil.execSql("UPDATE em_dibujostamsub SET codtamanoem = '" + tamU + "' WHERE codtamanoem = '" + tam + "'")) {
					AQUtil.destroyProgressDialog();
					return false;
				}
			}
		}
		if (!tamU) {
			debug("Salta tama�o " + tam);
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisarReservasXCliente()
{
	var q = new AQSqlQuery;
	q.setSelect("p.codcliente, ms.idstock, COUNT(*)");
	q.setFrom("movistock ms INNER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido");
	q.setWhere("ms.estado = 'PTE' AND ms.cantidad < 0 GROUP BY p.codcliente, ms.idstock");
	if (!q.exec()) {
		return false;
	}
	AQUtil.createProgressDialog(sys.translate("Revisando reservas"), q.size());
	var paso = 0;
	while (q.next()) {
		AQUtil.setProgress(++paso);
		if (q.value("COUNT(*)") == 1) {
			continue;
		}
		if (!flfactalma.iface.distribuyeStockPteClientes(q.value("ms.idstock"), q.value("p.codcliente"))) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisarConceptosMovistock()
{
	var res = MessageBox.information(sys.translate("�S�lo conceptos vac�os?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
	var w = res == MessageBox.Yes ? "concepto IS NULL" : "";
	
	var curMS = new FLSqlCursor("movistock");
	curMS.setActivatedCheckIntegrity(false);
	curMS.setActivatedCommitActions(false);
	curMS.select(w);
	AQUtil.createProgressDialog(sys.translate("Revisando conceptos"), curMS.size());
	var paso = 0, concepto, datosC;
	while (curMS.next()) {
		concepto = undefined;
		AQUtil.setProgress(++paso);
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();

		if (!curMS.isNull("idlineapc")) {
			datosC = flfactppal.iface.pub_ejecutarQry("lineaspedidoscli lp INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido", "p.codigo,p.nombrecliente", "lp.idlinea = " + curMS.valueBuffer("idlineapc"), "lineaspedidoscli");
			if (datosC.result == 1) {
				concepto = sys.translate("Pedido cliente %1 %2").arg(datosC["p.codigo"]).arg(datosC["p.nombrecliente"]);
			}
		}
		else if (!curMS.isNull("idlineapp")) {
			datosC = flfactppal.iface.pub_ejecutarQry("lineaspedidosprov lp INNER JOIN pedidosprov p ON lp.idpedido = p.idpedido", "p.codigo,p.nombre", "lp.idlinea = " + curMS.valueBuffer("idlineapp"), "lineaspedidosprov");
			if (datosC.result == 1) {
				concepto = sys.translate("Pedido proveedor %1 %2").arg(datosC["p.codigo"]).arg(datosC["p.nombre"]);
			}
		}
		else if (!curMS.isNull("idlineaap")) {
			datosC = flfactppal.iface.pub_ejecutarQry("lineasalbaranesprov la INNER JOIN albaranesprov a ON la.idalbaran = a.idalbaran", "a.codigo,a.nombre", "la.idlinea = " + curMS.valueBuffer("idlineaap"), "lineasalbaranesprov");
			if (datosC.result == 1) {
				concepto = sys.translate("Albar�n proveedor %1 %2").arg(datosC["a.codigo"]).arg(datosC["a.nombre"]);
			}
		}
		else if (!curMS.isNull("idlineaac")) {
			datosC = flfactppal.iface.pub_ejecutarQry("lineasalbaranescli la INNER JOIN albaranescli a ON la.idalbaran = a.idalbaran", "a.codigo,a.nombrecliente", "la.idlinea = " + curMS.valueBuffer("idlineaac"), "lineasalbaranescli");
			if (datosC.result == 1) {
				concepto = sys.translate("Albar�n cliente %1 %2").arg(datosC["a.codigo"]).arg(datosC["a.nombrecliente"]);
			}
		}
		else if (!curMS.isNull("codloteprod")) {
			datosC = flfactppal.iface.pub_ejecutarQry("lotesstock ls", "ls.codordenproduccion,ls.codlote", "ls.codlote = '" + curMS.valueBuffer("codloteprod") + "'", "lotesstock");
			if (datosC.result == 1) {
				concepto = sys.translate("Consumo en la orden %1 para el lote %2").arg(datosC["ls.codordenproduccion"]).arg(datosC["ls.codlote"]);
			}
		}
		else if (!curMS.isNull("codlote") && curMS.valueBuffer("codlote").startsWith("PZ") && curMS.valueBuffer("cantidad") < 0 && curMS.valueBuffer("estado") == "HECHO") {
				concepto = sys.translate("Consumo por pistola de pieza %1").arg(curMS.valueBuffer("codlote"));
		}
		else if (!curMS.isNull("idmovproducto") && curMS.valueBuffer("estado") == "PTE") {
			datosC = flfactppal.iface.pub_ejecutarQry("movistock ms INNER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido", "p.codigo,p.nombrecliente", "ms.idmovimiento = " + curMS.valueBuffer("idmovproducto"), "movistock");
			if (datosC.result == 1) {
				concepto = sys.translate("Consumo previsto pedido cliente %1 %2").arg(datosC["p.codigo"]).arg(datosC["p.nombrecliente"]);
			}
		}
		else  if (!curMS.isNull("em_codtraspaso")) {
			concepto = sys.translate("Traspaso stock %1").arg(curMS.valueBuffer("em_codtraspaso"));
		}
		else if (!curMS.isNull("idlineapm")) {
			datosC = flfactppal.iface.pub_ejecutarQry("lineaspedidomarcocli lp INNER JOIN pedidosmarcocli p ON lp.codpedidomarco = p.codpedidomarco", "p.codpedidomarco,p.nombrecliente", "lp.idlinea = " + curMS.valueBuffer("idlineapm"), "lineaspedidomarcocli");
			if (datosC.result == 1) {
				concepto = sys.translate("Pedido marco cliente %1 %2").arg(datosC["p.codpedidomarco"]).arg(datosC["p.nombrecliente"]);
			}
		}
		else if (!curMS.isNull("idmovproducto") && curMS.valueBuffer("estado") == "PREV") {
			datosC = flfactppal.iface.pub_ejecutarQry("movistock ms INNER JOIN lineaspedidomarcocli lp ON ms.idlineapm = lp.idlinea INNER JOIN pedidosmarcocli p ON lp.codpedidomarco = p.codpedidomarco", "p.codpedidomarco,p.nombrecliente", "ms.idmovimiento = " + curMS.valueBuffer("idmovproducto"), "movistock");
			if (datosC.result == 1) {
				concepto = sys.translate("Consumo previsto pedido marco cliente %1 %2").arg(datosC["p.codpedidomarco"]).arg(datosC["p.nombrecliente"]);
			}
		}
		else if (!curMS.isNull("idproceso") && curMS.valueBuffer("codlote").startsWith("PD")) {
			datosC = flfactppal.iface.pub_ejecutarQry("pr_procesos pr", "pr.idobjeto", "pr.idproceso = " + curMS.valueBuffer("idproceso"), "pr_procesos");
			if (datosC.result == 1) {
				concepto = sys.translate("Orden producci�n %1").arg(datosC["pr.idobjeto"]);
			}
		}
		else if (!curMS.isNull("idlineats")) {
			datosC = flfactppal.iface.pub_ejecutarQry("lineastransstock l inner join transstock t on l.idtrans = t.idtrans", "t.idtrans,t.codalmaorigen,t.codalmadestino,l.codpartida", "l.idlinea = " + curMS.valueBuffer("idlineats"), "lineastransstock");
			if (datosC.result == 1) {
				concepto = sys.translate("Transferencia %1 desde %2 hasta %3.").arg(datosC["t.idtrans"]).arg(datosC["t.codalmaorigen"]).arg(datosC["t.codalmadestino"]);
				if (datosC["l.codpartida"] && datosC["l.codpartida"] != "") {
					concepto += " " + sys.translate("Partida origen %1").arg(datosC["l.codpartida"]);
				}
			}
		}

		if (!concepto) {
			continue;
		}
debug("Concepto " + concepto);
		curMS.setValueBuffer("concepto", concepto);
		if (!curMS.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}


function euromoda_emRevisarReservas()
{
	var _i = this.iface;
	var q = new AQSqlQuery;
	q.setSelect("referencia");
	q.setFrom("articulos");
	q.setWhere("em_tipoarticulo = 'Producto'");
	if (!q.exec()) {
		return false;
	}
	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando art�culos"), q.size());
	while (q.next()) {
		AQUtil.setProgress(++p);
		if (!_i.revisaReservasProducto(q.value("referencia"))) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_revisaReservasProducto(referencia)
{
	var _i = this.iface;
	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("referencia = '" + referencia + "' AND estado = 'PTE' AND codordenproduccion IS NOT NULL");
	var codLote, referencia, cantidad, codConfec, codAlmaCon;
	var codAlmaEuro = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
	while (curLote.next()) {
		curLote.setModeAccess(curLote.Browse);
		curLote.refreshBuffer();
		codLote = curLote.valueBuffer("codlote");

// 		if (!formpr_generarordenesprodem.iface.pub_creaConsumosFT(curLote)) {
// 	  	return false;
// 		}

		if (!AQSql.del("movistock", "codloteprod = '" + codLote + "'")) {
			return false;
		}

		referencia = curLote.valueBuffer("referencia");
		cantidad = curLote.valueBuffer("canlote");

		if (!cantidad || isNaN(cantidad)) {
			cantidad = 0;
		}

		codConfec = AQUtil.quickSqlSelect("pr_ordenesproduccion", "codconfeccionista", "codorden = '" + curLote.valueBuffer("codordenproduccion") + "'");
		/// Cambia los movimientos pendientes de los lotes de la orden al stock del almac�n del confeccionista
		codAlmaCon;
		if (!codConfec || codConfec == "") {
			codAlmaCon = codAlmaEuro;
		} else {
			codAlmaCon = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codConfec + "'");
		}
		if (!codAlmaCon) {
			MessageBox.warning(sys.translate("El confeccionista %1 no tiene almac�n asociado").arg(codConfec), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}

		var l = curLote.valueBuffer;
		if (!flfactalma.iface.pub_generaConsumosProducto(referencia, cantidad, false, codLote, codAlmaCon, false)) {
			return false;
		}




	}

	var curMS = new FLSqlCursor("movistock");
	curMS.select("referencia = '" + referencia + "' AND estado = 'PTE' AND reservaaf <> 0");
	while (curMS.next()) {
		if (!flfactalma.iface.borraReservasMSAFaltas(curMS, true)) {
			return false;
		}
		if (!flfactalma.iface.creaReservasMSAFaltas(curMS)) {
			return false;
		}
	}
	return true;
}

function euromoda_emRevisaPedProvCerradosXPartidas()
{
	var _i = this.iface;
	var curMS = new FLSqlCursor("movistock");
	curMS.select("idlineapp IS NOT NULL AND em_merma AND codpartida IS NOT NULL");
	var idPedido, p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando movimientos con merma"), curMS.size());
	while (curMS.next()) {
		AQUtil.setProgress(++p);
		if (AQUtil.quickSqlSelect("lineaspedidosprov", "cerrada", "idlinea = " + curMS.valueBuffer("idlineapp"))) {
			continue;
		}
		curMS.setModeAccess(curMS.Browse);
		curMS.refreshBuffer();
		if (!flfactalma.iface.controlLineaPedidoProvMerma(curMS)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		idPedido = AQUtil.sqlSelect("lineaspedidosprov", "idpedido", "idlinea = " + curMS.valueBuffer("idlineapp"));
		if (!flfacturac.iface.pub_actualizarEstadoPedidoProv(idPedido)) {
			AQUtil.destroyProgressDialog();
			return;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisaPedProvMermaXPartidas()
{
	var _i = this.iface;
	var q = new AQSqlQuery;
	q.setSelect("lp.idlinea");
	q.setFrom("movistock ms inner join lineaspedidosprov lp on ms.idlineapp = lp.idlinea inner join pedidosprov p on lp.idpedido = p.idpedido");
	q.setWhere("ms.em_merma and ms.cantidad = 0 and lp.cantidad - lp.totalenalbaran <> 0");
	if (!q.exec()) {
		return false;
	}
	var curLP = new FLSqlCursor("lineaspedidosprov");
	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando movimientos con merma"), q.size());
	while (q.next()) {
debug("procesando l�nea " + q.value("lp.idlinea"));
		AQUtil.setProgress(++p);
		curLP.select("idlinea = " + q.value("lp.idlinea"));
		if (!curLP.first()) {
			debug("!first()");
			AQUtil.destroyProgressDialog();
			return false;
		}
		curLP.setModeAccess(curLP.Browse);
		curLP.refreshBuffer();
		if (!flfactalma.iface.recalcularMovPartidasPtesPP(curLP)) {
			debug("!recalcularMovPartidasPtesPP()");
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emCreaMovMerma0PedCli()
{
	var _i = this.iface;
	var q = new AQSqlQuery;
	q.setSelect("p.codigo, lp.idlinea, p.nombre, lp.referencia, lp.codpartida, lp.cantidad, p.codalmacen");
	q.setFrom("lineaspedidosprov lp left outer join movistock ms on lp.idlinea = ms.idlineapp inner join pedidosprov p ON lp.idpedido = p.idpedido");
	q.setWhere("lp.codpartida is not null and ms.idmovimiento is null");
	if (!q.exec()) {
		return false;
	}
	var curMS = new FLSqlCursor("movistock");
	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Generando movimientos con merma"), q.size());
	while (q.next()) {
		AQUtil.setProgress(++p);
debug(q.value("p.codigo") + " l�nea " + q.value("lp.idlinea"));
		curMS.setModeAccess(curMS.Insert);
		curMS.refreshBuffer();
		curMS.setValueBuffer("referencia", q.value("lp.referencia"));
		curMS.setValueBuffer("estado", "PTE");
		curMS.setValueBuffer("cantidad", 0);
		curMS.setValueBuffer("concepto", sys.translate("Pedido proveedor %1").arg(q.value("p.codigo")));
		curMS.setValueBuffer("canpedida", q.value("lp.cantidad"));
		curMS.setValueBuffer("idstock", AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + q.value("lp.referencia") + "' AND codalmacen = '" + q.value("p.codalmacen") + "'"));
		curMS.setValueBuffer("idlineapp", q.value("lp.idlinea"));
    curMS.setValueBuffer("codpartida", q.value("lp.codpartida"));
		curMS.setValueBuffer("em_merma", true);
    if (!curMS.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisaMermaPartidas()
{
	var _i = this.iface;
	var curP = new FLSqlCursor("lotesstock");
	curP.select("codlote LIKE 'PT%'");
	curP.setActivatedCommitActions(false);

	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando merma de lotes"), curP.size());
	while (curP.next()) {
		AQUtil.setProgress(++p);
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		curP.setValueBuffer("mdistribuidos", formRecordlotesstock.iface.pub_commonCalculateField("mdistribuidos", curP));
		curP.setValueBuffer("mptedist", formRecordlotesstock.iface.pub_commonCalculateField("mptedist", curP));
		curP.setValueBuffer("mmerma", formRecordlotesstock.iface.pub_commonCalculateField("mmerma", curP));
		curP.setValueBuffer("mpterec", formRecordlotesstock.iface.pub_commonCalculateField("mpterec", curP));
		curP.setValueBuffer("pormerma", formRecordlotesstock.iface.pub_commonCalculateField("pormerma", curP));
		curP.setValueBuffer("canusada", formRecordlotesstock.iface.pub_commonCalculateField("canusada", curP));
		curP.setValueBuffer("candisponible", formRecordlotesstock.iface.pub_commonCalculateField("candisponible", curP));
		if (!curP.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisaTotalesPartidas()
{
	var _i = this.iface;
	var curP = new FLSqlCursor("lotesstock");
	curP.select("codlote LIKE 'PT%'");
	curP.setActivatedCommitActions(false);

	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando totales de partidas"), curP.size());
	while (curP.next()) {
		AQUtil.setProgress(++p);
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		curP.setValueBuffer("cantotal", formRecordlotesstock.iface.pub_commonCalculateField("cantotal", curP));
		curP.setValueBuffer("mdistribuidos", formRecordlotesstock.iface.pub_commonCalculateField("mdistribuidos", curP));
		curP.setValueBuffer("mmerma", formRecordlotesstock.iface.pub_commonCalculateField("mmerma", curP));
		curP.setValueBuffer("mpterec", formRecordlotesstock.iface.pub_commonCalculateField("mpterec", curP));
		curP.setValueBuffer("pormerma", formRecordlotesstock.iface.pub_commonCalculateField("pormerma", curP));
		curP.setValueBuffer("canusada", formRecordlotesstock.iface.pub_commonCalculateField("canusada", curP));
		curP.setValueBuffer("candisponible", formRecordlotesstock.iface.pub_commonCalculateField("candisponible", curP));
		curP.setValueBuffer("mptedist", formRecordlotesstock.iface.pub_commonCalculateField("mptedist", curP));
		if (!curP.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisaTotalesPiezas()
{
	var _i = this.iface;
	var curP = new FLSqlCursor("lotesstock");
	curP.select("codlote LIKE 'PZ%'");
	curP.setActivatedCommitActions(false);

	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando totales de piezas"), curP.size());
	while (curP.next()) {
		AQUtil.setProgress(++p);
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		curP.setValueBuffer("cantotal", formRecordlotesstock.iface.pub_commonCalculateField("cantotal", curP));
		curP.setValueBuffer("mdistribuidos", formRecordlotesstock.iface.pub_commonCalculateField("mdistribuidos", curP));
		curP.setValueBuffer("mptedist", formRecordlotesstock.iface.pub_commonCalculateField("mptedist", curP));
		curP.setValueBuffer("mmerma", formRecordlotesstock.iface.pub_commonCalculateField("mmerma", curP));
		curP.setValueBuffer("mpterec", formRecordlotesstock.iface.pub_commonCalculateField("mpterec", curP));
		curP.setValueBuffer("pormerma", formRecordlotesstock.iface.pub_commonCalculateField("pormerma", curP));
		curP.setValueBuffer("canusada", formRecordlotesstock.iface.pub_commonCalculateField("canusada", curP));
		curP.setValueBuffer("candisponible", formRecordlotesstock.iface.pub_commonCalculateField("candisponible", curP));
		if (!curP.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

/*
function euromoda_emRevisaTotalesPiezas()
{
	var _i = this.iface;
	var curP = new FLSqlCursor("lotesstock");
	curP.select("codlote LIKE 'PZ%'");
// 	curP.setActivatedCommitActions(false);

	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando totales de piezas"), curP.size());
	while (curP.next()) {
		AQUtil.setProgress(++p);
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		curP.setValueBuffer("cantotal", formRecordlotesstock.iface.pub_commonCalculateField("cantotal", curP));
		curP.setValueBuffer("canusada", formRecordlotesstock.iface.pub_commonCalculateField("canusada", curP));
		curP.setValueBuffer("candisponible", formRecordlotesstock.iface.pub_commonCalculateField("candisponible", curP));
		curP.setValueBuffer("msalidas", formRecordlotesstock.iface.pub_commonCalculateField("msalidas", curP));
		if (!curP.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}
*/

function euromoda_emRevisaFechaServicioPedPte(oParam)
{
	var _i = this.iface;
	
	var w = "idPedidoPar" in oParam ? (" AND p.idpedido = " + oParam.idPedidoPar) : " AND p.servido = 'No'";
	var idPedidoAnt = undefined, idPedido;
	var hoy = new Date;
	var q = new AQSqlQuery;
	/// Ojo lp.diasservicio siempre la primera para que no falle el isnull
	q.setSelect("lp.diasservicio, p.idpedido, p.fecha, lp.idlinea, lp.cantidad, lp.totalenalbaran, lp.servidogit, lp.fechaservicio, SUM(ms.reservaex), SUM(ms.reservapr), SUM(ms.reservaaf), SUM(mat.reservaaf + mat.reservapr)");
	q.setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido LEFT OUTER JOIN movistock ms ON lp.idlinea = ms.idlineapc LEFT OUTER JOIN movistock mat ON ms.idmovimiento = mat.idmovproducto LEFT OUTER JOIN articuloscomp ac ON (ms.referencia = ac.refcompuesto AND mat.referencia = ac.refcomponente AND ac.reservar)");
	q.setWhere("lp.cantidad - lp.totalenalbaran - lp.servidogit > 0 AND NOT lp.cerrada " + w + " GROUP BY p.idpedido, p.fecha, lp.idlinea, lp.cantidad, lp.totalenalbaran, lp.servidogit, lp.fechaservicio, lp.diasservicio ORDER BY idpedido");
	if (!q.exec()) {
		return false;
	}
	var f, fechaDesde, fechaProg, dias, cantidad, totalEnAlbaran, servidoGit, reservadoEx, reservadoPr, reservadoAf, materialAf, fechaServicio, fechaPedido, diasServicio;
	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando fechas de servicio"), q.size());
	while (q.next()) {
		AQUtil.setProgress(++p);
		diasServicio = q.value("lp.diasservicio");
		fechaPedido = q.value("p.fecha");
		cantidad = q.value("lp.cantidad");
		totalEnAlbaran = q.value("lp.totalenalbaran");
		servidoGit = q.value("lp.servidogit");
		reservadoEx = q.value("SUM(ms.reservaex)");
		reservadoPr = q.value("SUM(ms.reservapr)");
		reservadoAf = q.value("SUM(ms.reservaaf)");
		materialAf = q.value("SUM(mat.reservaaf + mat.reservapr)");
		fechaServicio = q.value("lp.fechaservicio");
		cantidad = isNaN(cantidad) ? 0 : cantidad;
		totalEnAlbaran = isNaN(totalEnAlbaran) ? 0 : totalEnAlbaran;
		servidoGit = isNaN(servidoGit) ? 0 : servidoGit;
		reservadoEx = isNaN(reservadoEx) ? 0 : reservadoEx;
		reservadoPr = isNaN(reservadoPr) ? 0 : reservadoPr;
		reservadoAf = isNaN(reservadoAf) ? 0 : reservadoAf;
		materialAf = isNaN(materialAf) ? 0 : materialAf;
		cantidad -= (parseFloat(totalEnAlbaran) + parseFloat(servidoGit));
debug("idlinea " + q.value("lp.idlinea") + " reservadoEx " + reservadoEx + " reservadoPr " + reservadoPr + " reservadoAf " + reservadoAf + " materialAf " + materialAf + " cantidad " + cantidad);
		
		idPedido = q.value("p.idpedido");
		if (idPedido != idPedidoAnt && idPedidoAnt != undefined) {
			if (!_i.calculaFechaServicioPedido(idPedidoAnt)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
		f = q.isNull(0) ? fechaPedido : new Date;
		idPedidoAnt = idPedido;
		if (cantidad <= reservadoEx) {
			dias = 0;
		} else if (cantidad <= (parseFloat(reservadoEx) + parseFloat(reservadoPr))) {
			fechaProg = AQUtil.sqlSelect("em_lineaspedlote lpl INNER JOIN pr_ordenesproduccion op ON lpl.codorden = op.codorden", "MAX(op.fecha)", "idlineapc = " + q.value("lp.idlinea"), "em_lineaspedlote");
debug("select MAX(op.fecha) from em_lineaspedlote lpl INNER JOIN pr_ordenesproduccion op ON lpl.codorden = op.codorden where idlineapc = " + q.value("lp.idlinea"));
			if (fechaProg) {
				f = fechaProg;
			}
			dias = 7
		} else if (materialAf == 0) {
			dias = 7;
		} else {
			dias = 20;
		}
		if (dias != diasServicio || q.isNull(0)) {
			f = AQUtil.addDays(f, dias);
			if (!AQUtil.execSql("UPDATE lineaspedidoscli SET fechaservicio = '" + f.toString() + "', diasservicio = " + dias + " WHERE idlinea = " + q.value("lp.idlinea"))) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
	}
	if (idPedidoAnt != undefined) {
		if (!_i.calculaFechaServicioPedido(idPedidoAnt)) {
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_calculaFechaServicioPedido(idPedido)
{
	var _i = this.iface;
	
	var curP = new FLSqlCursor("pedidoscli");
	curP.setActivatedCommitActions(false);
	curP.setActivatedCheckIntegrity(false);
	curP.select("idpedido = " + idPedido);
	if (!curP.first()) {
		return false;
	}
	
	var curMS = new FLSqlCursor("movistock");
	curMS.setActivatedCommitActions(false);
	curMS.setActivatedCheckIntegrity(false);
	
	var idPedido = curP.valueBuffer("idpedido");
	var idStock;
	
	curP.setModeAccess(curP.Edit);
	curP.refreshBuffer();
	var fSAnt = curP.valueBuffer("fechaservicio");
	var fServ = formpedidoscli.iface.pub_commonCalculateField("fechaservicio", curP);
	if (fSAnt != fServ) {
		curP.setValueBuffer("fechaservicio", fServ);
		if (!curP.commitBuffer()) {
			return false;
		}
		curMS.select("idlineapc IN (SELECT idlinea FROM lineaspedidoscli WHERE idpedido = " + idPedido + ") AND estado = 'PTE'");
		while (curMS.next()) {
			curMS.setModeAccess(curMS.Edit);
			curMS.refreshBuffer();
			curMS.setValueBuffer("fechaprev", fServ);
			idStock = curMS.valueBuffer("idstock");
			if (!curMS.commitBuffer()) {
				return false;
			}
			if (!flfactalma.iface.pub_revisarReservasStock(idStock)) {
				return false;
			}
		}
	}
	
	return true;	
}

function euromoda_emActualizaIdArticuloCompMovimientos()
{
	var _i = this.iface;
	var curMS = new FLSqlCursor("movistock");
	curMS.select("idmovproducto IS NOT NULL");
	curMS.setActivatedCommitActions(false);
	curMS.setActivatedCheckIntegrity(false);

	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Revisando movimientos"), curMS.size());
	while (curMS.next()) {
		AQUtil.setProgress(++p);
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		curMS.setValueBuffer("idarticulocomp", AQUtil.quickSqlSelect("movistock ms INNER JOIN articuloscomp ap ON (ms.referencia = ap.refcompuesto AND ap.refcomponente = '" + curMS.valueBuffer("referencia") + "')", "ap.id", "ms.idmovimiento = " + curMS.valueBuffer("idmovproducto"), "articuloscomp"));
		if (!curMS.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emActualizaLotesAsignacion27()
{
	var _i = this.iface;
	
	var p = 0;
	
	var codAsig = Input.getText("Asignaci�n");
	var q = new AQSqlQuery;
	q.setSelect("ls.codlote");
	q.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion");
	q.setWhere("op.codasigconf = '" + codAsig + "'");
	if (!q.exec()) {
		return false;
	}
debug(q.sql());
	AQUtil.createProgressDialog(sys.translate("Revisando lotes"), q.size());
	var curLote = new FLSqlCursor("lotesstock");
	while (q.next()) {
		AQUtil.setProgress(++p);
		curLote.select("codlote = '" + q.value("ls.codlote") + "'");
		if (!curLote.first()) {
			return false;
		}
		
		var referencia, cantidad;
		var codLote = curLote.valueBuffer("codlote");
		if (!AQSql.del("movistock", "codloteprod = '" + codLote + "'")) {
			return false;
		}
		referencia = curLote.valueBuffer("referencia");
		cantidad = curLote.valueBuffer("canlote");
		if (!cantidad || isNaN(cantidad) || cantidad == 0) {
			cantidad = 0;
		}
		var l = curLote.valueBuffer;
		if (!flfactalma.iface.pub_generaConsumosProducto(referencia, cantidad, false, codLote, l("codalmacen"), false)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emCompruebaSaldoProv(codProveedor)
{
	var _i = this.iface;
	codProveedor = Input.getText("Proveedor");
//	codProveedor = "105862";
	
	var codGrupo = AQUtil.sqlSelect("proveedores", "codgrupocontableprov", "codproveedor = '" + codProveedor + "'");
	var listaS = formRecordproveedores.iface.pub_dameListaSubcuentas(codGrupo);
	
	if (!_i.compSaldoFacturasProv(codProveedor, listaS)) {
		return false;
	}
	if (!_i.compSaldoAnticiposProv(codProveedor, listaS)) {
		return false;
	}
	if (!_i.compSaldoPartidasProv(codProveedor, listaS)) {
		return false;
	}
	return true;
}

function euromoda_compSaldoFacturasProv(codProveedor, listaS)
{
	var _i = this.iface;
	
	var qF = new AQSqlQuery;
	qF.setSelect("f.idfactura, f.totaleuros, f.codigo, f.codejercicio, f.idasiento, f.codproveedor");
	qF.setFrom("facturasprov f");
	qF.setWhere("f.codproveedor = '" + codProveedor + "' AND NOT f.nogenerarasiento");
	if (!qF.exec()) {
		return false;
	}
	var qR = new AQSqlQuery;
	qR.setSelect("r.idrecibo, r.importeeuros, r.estado, r.codigo, r.idanticipo, r.idrecibocomp, r.codproveedor, r.em_idsaldopartida");
	qR.setFrom("recibosprov r");
	
	var total, totalR, idFactura, codFactura, codEjercicio;
	while (qF.next()) {
		total = qF.value("f.totaleuros");
		idFactura = qF.value("f.idfactura");
		codFactura = qF.value("f.codigo");
		codEjercicio = qF.value("f.codejercicio");
		if (parseInt(codEjercicio) >= 2012) {
			totalR = AQUtil.sqlSelect("recibosprov", "SUM(importeeuros)", "idfactura = " + idFactura);
			if (Math.abs(total - totalR) > 0.01) {
				sys.warnMsgBox(sys.translate("La suma de recibos no coincide con el total de factura para la factura %1").arg(codFactura));
				return false;
			}
			if (!_i.compSaldoFacturaProv(qF, listaS)) {
				return false;
			}
			qR.setWhere("r.idfactura = " + idFactura);
			if (!qR.exec()) {
				return false;
			}
			while (qR.next()) {
				if (!_i.compSaldoReciboProv(qR, listaS)) {
					return false;
				}
			}
		}
		debug("Factura " + codFactura + " OK");
	}
	return true;
}

function euromoda_compSaldoAnticiposProv(codProveedor, listaS)
{
	var _i = this.iface;
	
	var qF = new AQSqlQuery;
	qF.setSelect("a.idanticipo, a.importe, a.codigo, a.cancelado, a.pendiente, a.idasiento, a.importeeuros, a.pendienteeuros");
	qF.setFrom("anticiposprov a");
	qF.setWhere("a.codproveedor = '" + codProveedor + "'");
	if (!qF.exec()) {
		return false;
	}
	var idAnticipo, importe, totalR, codAnticipo, cancelado, pendiente, totalP, total, saldoP, idAsiento;
	while (qF.next()) {
		idAnticipo = qF.value("a.idanticipo");
		idAsiento = qF.value("a.idasiento");
		importe = qF.value("a.importeeuros");
		pendiente = qF.value("a.pendienteeuros");
		cancelado = importe - pendiente;
		
// 		if (importe != parseFloat(cancelado) + parseFloat(pendiente)) {
// 			sys.warnMsgBox(sys.translate("Pendiente + Cancelado != Importe para el anticipo %1").arg(codAnticipo));
// 			return false;
// 		}
		codAnticipo = qF.value("a.codigo");
		totalR = AQUtil.sqlSelect("recibosprov", "SUM(importeeuros)", "idanticipo = " + idAnticipo + " AND estado = 'Pagado'");
		totalP = AQUtil.sqlSelect("co_em_saldopartidas sp INNER JOIN co_partidas p ON sp.idpartida1 = p.idpartida", "SUM(sp.importe)", "sp.idanticipoprov = " + idAnticipo + " AND sp.codproveedor = '" + codProveedor + "' AND p.codproveedor = '" + codProveedor + "'", "co_partidas");
		totalR = isNaN(totalR) ? 0 : totalR;
		totalP = isNaN(totalP) ? 0 : totalP;
		total = parseFloat(totalR) + parseFloat(totalP * -1);
if (codAnticipo == "2014000091") { debug(" _____________________________________________________________________________________ANTICIPO " + codAnticipo + " importe " + importe +" pendiente " + pendiente + " cancelado " + cancelado + " totalR " + totalR + " totalP " + totalP + " Math " + Math.abs(cancelado - total)); }
		if (Math.abs(cancelado - total) > 0.01) {
			sys.warnMsgBox(sys.translate("La suma de recibos no coincide con el importe del anticipo %1").arg(codAnticipo));
			return true;
		}
		saldoP = AQUtil.sqlSelect("co_partidas", "SUM(debe-haber)", "idasiento = " + idAsiento + " AND codsubcuenta IN (" + listaS + ") AND codproveedor = '" + codProveedor + "'");
		saldoP = isNaN(saldoP) ? 0 : saldoP;
		if (Math.abs(saldoP - importe) > 0.01) {
			sys.warnMsgBox(sys.translate("La partida de proveedor no es coherente con el anticipo %1").arg(codAnticipo));
			return true;
		}
		debug("Anticipo " + codAnticipo + " OK");
	}
	return true;
}

function euromoda_compSaldoPartidasProv(codProveedor, listaS)
{
	var _i = this.iface;
	
	var qF = new AQSqlQuery;
	qF.setSelect("p.idpartida, p.debe-p.haber, a.idasiento, p.importependiente, p.importependientemig, a.codejercicio");
	qF.setFrom("co_partidas p LEFT OUTER JOIN co_asientos a ON p.idasiento = a.idasiento");
	qF.setWhere("p.codproveedor = '" + codProveedor + "' AND p.codsubcuenta IN (" + listaS + ")");
	if (!qF.exec()) {
		return false;
	}
	var idPartida, saldoP, idAsiento, totalP, totalN, totalSP, canceladoP, importePteMig, importePte, autoP, codEjercicio;
	var qSP = new AQSqlQuery;
	qSP.setSelect("sp.idanticipoprov, sp.idreciboprov, sp.idpartida2, sp.idpartida1, sp.importe");
	qSP.setFrom("co_em_saldopartidas sp");
	
	while (qF.next()) {
		codEjercicio = parseFloat(qF.value("a.codejercicio"));
		idPartida = qF.value("p.idpartida");
		idAsiento = qF.value("a.idasiento");
		saldoP = qF.value("p.debe-p.haber");
		importePte = qF.value("p.importependiente");
		importePteMig = qF.value("p.importependientemig");
		importePte = isNaN(importePte) ? 0 : importePte;
		importePteMig = isNaN(importePteMig) ? 0 : importePteMig;
		canceladoP = importePteMig - importePte;
		totalP = AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idpartida1 = " + idPartida + " AND codproveedor = '" + codProveedor + "'", "co_partidas");
		totalP = isNaN(totalP) ? 0 : totalP;
		totalN = AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idpartida2 = " + idPartida + " AND codproveedor = '" + codProveedor + "'", "co_partidas");
		totalN = isNaN(totalN) ? 0 : totalN;
		totalSP = totalP - totalN;
		totalSP = isNaN(totalSP) ? 0 : totalSP;
debug("totalSP " + totalSP + " = canceladoP " + canceladoP);
		if (Math.abs(canceladoP - totalSP) > 0.01) {
			sys.warnMsgBox(sys.translate("La suma de saldos de partida no coincide con el importe cancelado de la partida %1").arg(idPartida));
			return false;
		}
		qSP.setWhere("sp.idpartida1 = " + idPartida);
		if (!qSP.exec()) {
			return false;
		}
// 		autoP = false; Parece que hay casos de migraci�n en 2012
// 		if (AQUtil.sqlSelect("facturasprov", "idfactura", "idasiento = " + idAsiento)) {
// 			autoP = true;
// 		} else if (AQUtil.sqlSelect("pagosdevolprov", "idpagodevol", "idasiento = " + idAsiento)) {
// 			autoP = true;
// 		} else if (AQUtil.sqlSelect("anticiposprov", "idanticipo", "idasiento = " + idAsiento)) {
// 			autoP = true;
// 		} else if (AQUtil.sqlSelect("ejercicios", "codejercicio", "idasientocierre = " + idAsiento + " OR idasientoapertura = " + idAsiento)) {
// 			autoP = true;
// 		}
// 		if (autoP && importePteMig != 0 && codEjercicio >= 2012) {
// 			sys.warnMsgBox(sys.translate("La partida autom�tica %1 tiene un saldo inicial %1").arg(idPartida));
// 			return false;
// 		} else if (!autoP && importePteMig != saldoP && codEjercicio >= 2012) {
// 			sys.warnMsgBox(sys.translate("La partida manual %1 tiene un saldo inicial distinto a su saldo").arg(idPartida));
// 			return false;
// 		}
		while (qSP.next()) {
			if (!_i.compSaldoPartidaProv(qSP, listaS, codProveedor)) {
				return false;
			}
		}
		debug("Partida " + idPartida + " OK");
	}
	return true;
}

function euromoda_compSaldoPartidaProv(qSP, listaS, codProveedor)
{
	var _i = this.iface;
	
	var idPartida1 = qSP.value("sp.idpartida1"); 
	var idRecibo = qSP.value("sp.idreciboprov");
	var idAnticipo = qSP.value("sp.idanticipoprov");
	var idPartida = qSP.value("sp.idpartida2");
	var importe = qSP.value("sp.importe");
	
	idRecibo = idRecibo && idRecibo != "" && idRecibo != 0 ? idRecibo : false;
	idAnticipo = idAnticipo && idAnticipo != "" && idAnticipo != 0 ? idAnticipo : false;
	idPartida = idPartida && idPartida != "" && idPartida != 0 ? idPartida : false;
	
	if (idRecibo) {
		if (idAnticipo || idPartida) {
			sys.warnMsgBox(sys.translate("La partida %1 est� asociada a m�s de un documento").arg(idPartida1));
			return true;
		}
debug("idRecibo " + idRecibo);
debug("codProveedor " + codProveedor);
debug("importe " + importe);
		if (!AQUtil.sqlSelect("recibosprov", "idrecibo", "idrecibo = " + idRecibo + " AND codproveedor = '" + codProveedor + "' AND estado = 'Pagado' AND importe = " + importe)) {
			sys.warnMsgBox(sys.translate("El recibo asociado a la partida %1 no existe o no es coherente con ella").arg(idPartida1));
			return true;
		}
	} else if (idAnticipo) {
		if (idRecibo || idPartida) {
			sys.warnMsgBox(sys.translate("La partida %1 est� asociada a m�s de un documento").arg(idPartida1));
			return true;
		}
		if (!AQUtil.sqlSelect("anticiposprov", "idanticipo", "idanticipo = " + idAnticipo + " AND codproveedor = '" + codProveedor + "'")) {
			sys.warnMsgBox(sys.translate("El anticipo asociado a la partida %1 no existe o no es coherente con ella").arg(idPartida1));
			return true;
		}
	} else if (idPartida) {
		if (idRecibo || idAnticipo) {
			sys.warnMsgBox(sys.translate("La partida %1 est� asociada a m�s de un documento").arg(idPartida1));
			return true;
		}
		if (!AQUtil.sqlSelect("co_partidas", "idpartida", "idpartida = " + idPartida + " AND codproveedor = '" + codProveedor + "'")) {
			sys.warnMsgBox(sys.translate("La partida2 asociada a la partida %1 no existe o no es coherente con ella").arg(idPartida1));
			return true;
		}
	} else {
		sys.warnMsgBox(sys.translate("La partida1 %1 tiene un registro de saldo no asociado con ning�n documento").arg(idPartida1));
		return true;
	}
	return true;
}

function euromoda_compSaldoFacturaProv(qF, listaS)
{
	var _i = this.iface;
	
	var idFactura = qF.value("f.idfactura");
	var idAsiento = qF.value("f.idasiento");
	var codFactura = qF.value("f.codigo");
	var total = qF.value("f.totaleuros");
	var saldoF = AQUtil.sqlSelect("co_partidas", "SUM(haber-debe)", "idasiento = " + idAsiento + " AND codsubcuenta IN (" + listaS + ")");
	saldoF = isNaN(saldoF) ? 0 : saldoF;
	if (Math.abs(total - saldoF) > 0.01) {
		sys.warnMsgBox(sys.translate("Las partidas de proveedor de la factura %1 no coinciden con el total").arg(codFactura));
		return true;
	}
	return true;
}

function euromoda_compSaldoReciboProv(qR, listaS)
{
	var _i = this.iface;
	var idAnticipo = qR.value("r.idanticipo");
	var idSaldoP = qR.value("r.em_idsaldopartida");
	var idRecibo = qR.value("r.idrecibo");
	var importe = AQUtil.roundFieldValue(qR.value("r.importeeuros"), "recibosprov", "importeeuros");
	var codRecibo = qR.value("r.codigo");
	var estado = qR.value("r.estado");
	var codProveedor = qR.value("r.codproveedor");
	idAnticipo = idAnticipo && idAnticipo != "" && idAnticipo != 0 ? idAnticipo : false;
	
debug("idRecibo " + idRecibo + " codRecibo " + codRecibo);
	switch (estado) {
		case "Pagado": {
			if (idAnticipo) {
				if (!AQUtil.sqlSelect("anticiposprov", "idanticipo", "idanticipo = " + idAnticipo + " AND codproveedor = '" + codProveedor + "'")) {
					sys.warnMsgBox(sys.translate("El recibo %1 no est� ligado correctamente a su anticipo").arg(codRecibo));
					return true;
				}
				break;
			} else if (idSaldoP) {
				if (!AQUtil.sqlSelect("co_em_saldopartidas sp INNER JOIN co_partidas p ON sp.idpartida1 = p.idpartida", "sp.idsaldo", "sp.idsaldo = " + idSaldoP + " AND sp.codproveedor = '" + codProveedor + "' AND p.codproveedor = '" + codProveedor + "' AND sp.importe = " + importe + " AND p.codsubcuenta IN (" + listaS + ")", "co_partidas")) {
					sys.warnMsgBox(sys.translate("El recibo %1 no est� ligado correctamente a su partida").arg(codRecibo));
					return true;
				}
				break;
			}
			var numPagos = AQUtil.sqlSelect("pagosdevolprov", "COUNT(*)", "idrecibo = " + idRecibo + " AND tipo = 'Pago'");
			numPagos = isNaN(numPagos) ? 0 : numPagos;
			var numDevol = AQUtil.sqlSelect("pagosdevolprov", "COUNT(*)", "idrecibo = " + idRecibo + " AND tipo = 'Devoluci�n'");
			numDevol = isNaN(numDevol) ? 0 : numDevol;
debug("idRecibo " + idRecibo + " numPagos " + numPagos + " numDevol " + numDevol);
			if ((numPagos - numDevol) != 1) {
				sys.warnMsgBox(sys.translate("Pagos y devoluciones incorrectos para el recibo %1").arg(codRecibo));
				return true;
			}
			if (numPagos > 0) {
				if (!_i.compSaldoPagosDevolProv(qR, listaS)) {
					return false;
				}
			}
			break;
		}
		case "Remesado": {
			if (idAnticipo) {
				sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Remesado pero tiene asociado un anticipo").arg(codRecibo));
				return true;
			} else if (idSaldoP) {
				sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Remesado pero tiene asociado una partida").arg(codRecibo));
				return true;
			} else {
				if (AQUtil.sqlSelect("pagosdevolprov", "idasiento", "idrecibo = " + idRecibo)) {
					sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Remesado pero tiene asientos de pagos asociados").arg(codRecibo));
					return true;
				}
			}
			break;
		}
		case "Compensado": {
			if (idAnticipo) {
				sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Compensado pero tiene asociado un anticipo").arg(codRecibo));
				return true;
			} else if (idSaldoP) {
				sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Compensado pero tiene asociado una partida").arg(codRecibo));
				return true;
			} else {
				var importeN = importe * -1;
				var idReciboComp = qR.value("r.idrecibocomp");
				if (!AQUtil.sqlSelect("recibosprov", "idrecibo", "idrecibo = " + idReciboComp + " AND idrecibocomp = " + idRecibo + " AND importe = " + importeN)) {
					sys.warnMsgBox(sys.translate("Error al comprobar el recibo compensado %1").arg(codRecibo));
					return true;
				}
			}
			break;
		}
		case "Emitido": {
			if (idAnticipo) {
				sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Emitido pero tiene asociado un anticipo").arg(codRecibo));
				return true;
			} else if (idSaldoP) {
				sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Emitido pero tiene asociado una partida").arg(codRecibo));
				return true;
			} else {
				if (AQUtil.sqlSelect("pagosdevolprov", "idpagodevol", "idrecibo = " + idRecibo)) {
					sys.warnMsgBox(sys.translate("El recibo %1 tiene estado Emitido pero tiene pagos asociados").arg(codRecibo));
					return true;
				}
			}
			break;
		}
		default: {
			sys.warnMsgBox(sys.translate("Estado %1 no tratado para el recibo %2").arg(estado).arg(codRecibo));
			return true;
		}
	}
	return true;
}

function euromoda_compSaldoPagosDevolProv(qR, listaS)
{
debug("euromoda_compSaldoPagosDevolProv");
	var _i = this.iface;
	var idRecibo = qR.value("r.idrecibo");
	var codProveedor = qR.value("r.codproveedor");
	var importe = AQUtil.roundFieldValue(qR.value("r.importeeuros"), "recibosprov", "importeeuros");
	var codRecibo = qR.value("r.codigo");
	
	var qPD = new AQSqlQuery();
	qPD.setSelect("pd.tipo, p.debe-p.haber");
	qPD.setFrom("pagosdevolprov pd INNER JOIN co_partidas p ON pd.idasiento = p.idasiento");
	qPD.setWhere("pd.idrecibo = " + idRecibo + " AND p.codsubcuenta IN (" + listaS + ") AND p.codproveedor = '" + codProveedor + "'");
	if (!qPD.exec()) {
		return false;
	}
debug(qPD.sql());
	var saldo, tipo;
	while(qPD.next()) {
		tipo = qPD.value("pd.tipo");
		saldo = qPD.value("p.debe-p.haber");
		saldo = isNaN(saldo) ? 0 : saldo;
		debug(saldo + " = " + importe);
		switch (tipo) {
			case "Pago": {
				if (saldo != importe) {
					sys.warnMsgBox(sys.translate("Error al comprobar el pago del recibo %1").arg(codRecibo));
					continue;
				}
				break;
			}
			case "Devoluci�n": {
				sys.warnMsgBox(sys.translate("Error al comprobar la devoluci�n del recibo %1 (por programar)").arg(codRecibo));
				continue;
				break;
			}
		}
	}
	return true;
}

function euromoda_lanzaPedidosAsignacion(oParam)
{
	var _i = this.iface;
	var lista = Input.getText("Lista de asignaciones separadas por comas");
	if (!lista) {
		return false;
	}
	aLista = lista.split(",");
	
	var codAsignacion;
	AQUtil.createProgressDialog(sys.translate("Generando pedidos"), aLista.length);
	var paso = 0;
	var oParamF = new Object;
	for (var i = 0; i < aLista.length; i++) {
		AQUtil.setProgress(p++);
		codAsignacion = flfactppal.iface.pub_cerosIzquierda(aLista[i], 8);
		AQUtil.setLabelText(sys.translate("Generando pedidos para la asignaci�n %1").arg(codAsignacion));
		oParamF.errorMsg = sys.translate("Error al generar los pedidos asociados a la asignaci�n %1").arg(codAsignacion);
		oParamF.codAsigConf = codAsignacion;
		if (!_i.enviaOrdenes(oParamF)) {
			AQUtil.destroyProgressDialog();
			sys.errorMsgBox(oParamF.errorMsg);
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_enviaOrdenes(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAsigConf = oParam.codAsigConf;
	
	var oParamPC = new Object;
	oParamPC.codPedido = false;

	var curO = new FLSqlCursor("pr_ordenesproduccion");
	curO.select("codasigconf = '" + codAsigConf + "'");
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Enviando �rdenes"), curO.size());
	while (curO.next()) {
		curO.setModeAccess(curO.Edit);
		curO.refreshBuffer();
		curO.setValueBuffer("materialconfok", true);
		oParamPC.codOrden = curO.valueBuffer("codorden");
		if (!formem_districonf.iface.pub_creaPedidoConf(oParamPC)) {
			oParam.errorMsg = sys.translate("Error al enviar la orden").arg(oParamPC.codOrden);
			return false;
		}
		if (!curO.commitBuffer()) {
			oParam.errorMsg = sys.translate("Error al marcar el material listo de la orden").arg(oParamPC.codOrden);
			return false;
		}
	}
	if (!AQSql.update("em_asignacionesconf", ["estado"], ["Enviada"], "codasigconf = '" + codAsigConf + "'")) {
		return false;
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisaReservasLPAFaltas(oParam)
{
	var _i = this.iface;
	var _f = flfactalma.iface;
	
	var curMS = new FLSqlCursor("movistock");
	curMS.select("idlineapc IS NOT NULL AND reservaaf > 0");
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Revisando l�neas de pedido"), curMS.size());

	var p = 0;
	while (curMS.next()) {
		AQUtil.setProgress(++p);
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		if (!_f.borraReservasMSAFaltas(curMS, true)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		if (!_f.creaReservasMSAFaltas(curMS)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		if (!_f.calculaReservasStockDerivadas(curMS.valueBuffer("idstock"), 0, 0)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	if (!_f.procesaStocks(sys.nameUser())) {
		AQUtil.destroyProgressDialog();
			return false;
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emRevisaReservasTejidoPrev(oParam)
{
	var _i = this.iface;

	var w = "";
	if ("codSubfamilia" in oParam) {
		w += " AND m1.codsubfamiliatp = '" + oParam.codSubfamilia + "'";
	}

	var q = new AQSqlQuery;
	q.setSelect("m1.idmovimiento,m1.idstock");
	q.setFrom("movistock m1 LEFT OUTER JOIN movistock m2 ON m1.idmovimiento = m2.idmovtejidoprep LEFT OUTER JOIN movistock m0 ON m1.idmovtejidoprep = m0.idmovimiento")
	//q.setWhere("m1.codsubfamiliatp IS NOT NULL AND m1.reservaaf > 0 AND m0.idmovimiento IS NULL AND m2.idmovimiento IS NOT NULL " + w + "  ORDER BY m1.idmovimiento");
	q.setWhere("m1.codsubfamiliatp IS NOT NULL AND m1.reservaaf > 0 AND m0.idmovimiento IS NULL  " + w + "  ORDER BY m1.idmovimiento"); 
	if (!q.exec()) {
		return false;
	}
	debug(q.sql());
	
	var curMS = new FLSqlCursor("movistock");
	var idMovimiento, canMov = 0;
	while (q.next()) {
		idMovimiento = q.value("m1.idmovimiento");
debug("Movimiento " + idMovimiento);
		curMS.select("idmovimiento = " + idMovimiento);
		if (!curMS.first()) {
			oParam.errorMsg = sys.translate("No se ha encontrado el movimiento %1").arg(idMovimiento);
			debug(oParam.errorMsg);
			return false;
		}
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		curMS.setValueBuffer("codsubfamiliatp", AQUtil.sqlSelect("articulos", "codsubfamilia", "referencia = '" + curMS.valueBuffer("referencia") + "'"));
		
		if (!flfactalma.iface.borraMovTejidoPrep(curMS)) {
			oParam.errorMsg = sys.translate("Error al eliminar las reservas de tejido para el movimiento %1").arg(idMovimiento);
			debug(oParam.errorMsg);
			return "ERROR";
		}
		
		if (!curMS.commitBuffer()) {
			return false;
		}
		
		if (!flfactalma.iface.creaMovTejidoPrep(curMS)) {
			oParam.errorMsg = sys.translate("Error al crear las reservas de tejido para el movimiento %1").arg(idMovimiento);
			debug(oParam.errorMsg);
			return false;
		}
		if (!flfactalma.iface.calculaReservasStockTP(q.value("m1.idstock"))) {
			return false;
		}
		canMov++;
	}
	oParam.canReservas = canMov;
	debug("Revisados " + canMov + " movimientos");
	return true;
}

function euromoda_ejecutaFuncionDefecto(funcion)
{
	var _i = this.iface;
	
	switch ( funcion ) {
		case "emRevisaReservasTejidoPrev": {
				_i.batchOn_ = true;
				if (!_i.__ejecutaFuncionDefecto(funcion)) {
					_i.batchOn_ = false;
					return false;
				}
				_i.batchOn_ = false;
				break;
		}
		default: {
			if (!_i.__ejecutaFuncionDefecto(funcion)) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_revisaEanInternos(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var curA = new FLSqlCursor("articulos");
	curA.setActivatedCheckIntegrity(false);
	curA.setActivatedCommitActions(false);
	curA.select("codfamilia IN (SELECT codfamilia FROM familias WHERE tipoean = 'Interno')");
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Revisando EANs internos"), curA.size());
	var ean;
	var p = 0;
	while (curA.next()) {
		AQUtil.setProgress(++p);
		curA.setModeAccess(curA.Edit);
		curA.refreshBuffer();
		ean = flfactalma.iface.calculaCodBarras(curA);
		curA.setValueBuffer("codbarras", ean);
		if (!curA.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			oParam.errorMsg = sys.translate("Error al procesar el art�culo %1").arg(curA.valueBuffer("referencia"));
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emCompruebaReservasPedidos(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("ms.idmovimiento, p.codigo, l.numlinea, l.referencia, l.descripcion");
	q.setFrom(" pedidoscli p inner join lineaspedidoscli l on p.idpedido = l.idpedido inner join movistock ms on l.idlinea = ms.idlineapc left outer join movistock ms2 on ms.idmovimiento = ms2.idmovproducto");
	q.setWhere("ms.reservaaf > 0 and ms2.idmovimiento is null and p.codejercicio >= '2013' and l.referencia in (select refcompuesto from articuloscomp) ORDER BY p.codigo, l.numlinea");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var nLineas = q.size();
	if (nLineas == 0) {
		sys.warnMsgBox(sys.translate("No hay pedidos que revisar"));
		return true;
	}
	var dialog = new Dialog;
	dialog.caption = sys.translate("Revisar reservas de materiales en pedidos");
    dialog.okButtonText = sys.translate("Aceptar");
    dialog.cancelButtonText = sys.translate("Cancelar");
    
    var chkExcel = new CheckBox;
    chkExcel.text = sys.translate("Exportar a excel (%1 casos)").arg(nLineas);
    dialog.add( chkExcel );
    
    var chkCorregir = new CheckBox;
    chkCorregir.text = sys.translate("Corregir");
    dialog.add( chkCorregir );
    
    if(!dialog.exec() ) {
    	return true;
    }
    if (chkExcel.checked) {
    	var oPE = flfactppal.iface.pub_dameParamExcel();
    	oPE.nombreFichero = "tmpPedARevisar";
		oPE.tabla = undefined;
		oPE.nombreColumnas = ["Movimiento", "Pedido", "L�nea", "Referencia", "Descripci�n"];
		oPE.titulo = sys.translate("L�neas de pedido con materiales a revisar");
		oPE.consulta = q;
		oPE.array = undefined;
		oPE.tipoColumna = ["int", "string", "string", "string", "string"];
		flfactppal.iface.pub_exportarConsultaExcel(oPE);
    }
    if (!chkCorregir.checked) {
    	return true;
	}
	
	var curMS = new FLSqlCursor("movistock");
	AQUtil.createProgressDialog(sys.translate("Regenerando reservas"), q.size());
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(++p);
		AQUtil.setLabelText(sys.translate("Procesando %1 L�nea %2: %3 - %4").arg(q.value("p.codigo")).arg(q.value("l.numlinea")).arg(q.value("l.referencia")).arg(q.value("l.descripcion")));
		curMS.select("idmovimiento = " + q.value("ms.idmovimiento"));
		if (!curMS.first()) {
			AQUtil.destroyProgressDialog();
			oParam.errorMsg = sys.translate("Error al buscar el movimiento %1").arg(q.value("ms.idmovimiento"));
			return false;
		}
		curMS.setModeAccess(curMS.Browse);
		curMS.refreshBuffer();
		if (!flfactalma.iface.revisaReservasMSAFaltas(curMS)) {
			AQUtil.destroyProgressDialog();
			oParam.errorMsg = sys.translate("Error al recalcular las reservas del movimiento %1").arg(q.value("ms.idmovimiento"));
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_emCargaFactoresFT(oParam)
{
	var curA = new FLSqlCursor("articulos");
	curA.select("em_tipoarticulo = 'Producto' AND em_prendasxancho = 0 AND em_cmsxprenda =0");
	AQUtil.createProgressDialog(sys.translate("Informando factores FT"), curA.size());
	var p = 0;
	while (curA.next()) {
		AQUtil.setProgress(++p);
		curA.setModeAccess(curA.Edit);
		curA.refreshBuffer();
		formRecordarticulos.iface.calculaFactoresFT(curA, true);
		if (!curA.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_calculaMetrosOPSeccion(oParam)
{
	var _i = this.iface;
	var codSeccion = Input.getText(sys.translate("Introduce el c�digo de secci�n:"));
	if (!codSeccion || codSeccion =="") {
		return;
	}
	var q = new AQSqlQuery;
	q.setSelect("codorden");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("totalmetros = 0 and estado ='PTE' and em_codmodooper IN (select codmodooper from em_modosoperacion where codseccion ='" + codSeccion + "')");

	if (!q.exec()) {			
		return false;
	}
	debug("q1: "+q.sql());
	while (q.next()) 
	{
		var codOrden = q.value("codorden");
		debug("codOrden en 1: "+codOrden);
		var qLote = new FLSqlQuery;
		qLote.setSelect("l.referencia, l.canlote");
		qLote.setFrom("lotesstock l");
		qLote.setWhere("l.codordenproduccion = '" + codOrden + "'");
		debug("qLote en 1: "+qLote.sql());
		if (!qLote.exec()) {			
			return false;
		}
		var referencia, cantidad;
		var totalMetros = 0;
		var metros = 0;

		while (qLote.next()) {
		
			
			cantidad = qLote.value("l.canlote");		 						
			referencia = qLote.value("l.referencia");
			metros = formRecordarticulos.iface.prendasAMetros(referencia, cantidad);
			if(!metros) {
				metros = 0;
			}
			totalMetros = parseFloat(totalMetros) + parseFloat(metros);      

		}
		if (!AQUtil.execSql("UPDATE pr_ordenesproduccion set totalmetros = " + totalMetros + ", metrosptes = " + totalMetros + " WHERE codorden = '" + codOrden + "'")) {
			return false;
		}

	}


	var q = new AQSqlQuery;
	q.setSelect("codorden");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("totalmetros = 0 and estado ='PTE' and codsubfamilia in (select codsubfamilia from subfamilias where em_codseccion ='" + codSeccion + "')");
	if (!q.exec()) {			
		return false;
	}	
	debug("q2: "+q.sql());
	while (q.next()) 
	{
		var codOrden = q.value("codorden");
		var qLote = new FLSqlQuery;
		qLote.setSelect("l.referencia, l.canlote");
		qLote.setFrom("lotesstock l");
		qLote.setWhere("l.codordenproduccion = '" + codOrden + "'");
		if (!qLote.exec()) {			
			return false;
		}
		var referencia, cantidad;
		var totalMetros = 0;
		var metros = 0;

		while (qLote.next()) {
		
			
			cantidad = qLote.value("l.canlote");		 						
			referencia = qLote.value("l.referencia");
			metros = formRecordarticulos.iface.prendasAMetros(referencia, cantidad);
			if(!metros) {
				metros = 0;
			}
			totalMetros = parseFloat(totalMetros) + parseFloat(metros);      

		}
		if (!AQUtil.execSql("UPDATE pr_ordenesproduccion set totalmetros = " + totalMetros + ", metrosptes = " + totalMetros + " WHERE codorden = '" + codOrden + "'")) {
			return false;
		}

	}
	return true;

}


function euromoda_emBuscaOrdenesIncorrectas(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("op.codorden, COUNT(*)");
	q.setFrom("pr_ordenesproduccion op INNER JOIN pr_procesos p ON p.tipoobjeto = 'pr_ordenesproduccion' AND p.idobjeto = op.codorden");
	q.setWhere("1 = 1 GROUP BY op.codorden HAVING COUNT(*) > 1");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var borrar;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		borrar = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		borrar = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando �rdenes"), q.size());
	}
	while (q.next()) {
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		var idProceso = AQUtil.sqlSelect("pr_procesos", "idproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + q.value("op.codorden") + "' AND estado IN ('PTE', 'OFF')");
		if (!idProceso) {
			continue; // Solo contamos y borramos procesos pendientes
		}
		if (borrar) {
			if (!AQSql.del("movistock", "idproceso = " + idProceso)) {
				AQUtil.destroyProgressDialog();
				sys.warnMsgBox(sys.translate("Error al borrar los movimientos asociados al proceso %1").arg(idProceso));
				return false;
			}
			if (!AQSql.del("pr_procesos", "idproceso = " + idProceso)) {
				AQUtil.destroyProgressDialog();
				sys.warnMsgBox(sys.translate("Error al borrar el proceso %1").arg(idProceso));
				return false;
			}
		}
		lista.push("     "+q.value("op.codorden"));
		//if (p > 0) { break; }
	}
	var msg = lista.length > 0 ? sys.translate("HAY ERRORES: �rdenes con dos procesos:\n%1").arg(lista.join("\n")) : sys.translate("OK: No hay �rdenes con dos procesos");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	return true;
}

function euromoda_emBuscaOrdenesDoblePteRx(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("op.codorden,op.fecha, ls.codlote,ms.idmovimiento, ms.idstock, ms.estado, mslp.estado, msla.estado, ms2.estado, ms.cantidad, mslp.cantidad, msla.cantidad, ms2.cantidad");
	q.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion INNER JOIN movistock ms ON ls.codlote = ms.codlote LEFT OUTER JOIN pedidosprov pp ON op.codorden = pp.codordenprod  AND pp.codproveedor = op.codconfeccionista LEFT OUTER JOIN lineaspedidosprov lp ON pp.idpedido = lp.idpedido AND lp.referencia = ls.referencia LEFT OUTER JOIN movistock mslp ON lp.idlinea = mslp.idlineapp AND mslp.idmovimiento <> ms.idmovimiento LEFT OUTER JOIN albaranesprov ap ON op.codorden = ap.codordenprod AND ap.codproveedor = op.codconfeccionista LEFT OUTER JOIN lineasalbaranesprov la ON ap.idalbaran = la.idalbaran AND la.referencia = ls.referencia LEFT OUTER JOIN movistock msla ON la.idlinea = msla.idlineaap AND msla.idmovimiento <> ms.idmovimiento LEFT OUTER JOIN movistock ms2 ON ls.codlote = ms2.codlote AND ms.idmovimiento <> ms2.idmovimiento AND ms2.idlineaap IS NULL AND ms2.idlineapp IS NULL ");
	q.setWhere("ms.estado IS NOT NULL AND ms.idlineapp IS NULL AND ms.idlineaap IS NULL AND ((mslp.estado IS NOT NULL) OR (msla.estado IS NOT NULL) OR (ms2.estado IS NOT NULL)) AND NOT ms.regularizacion ORDER BY op.codorden, ls.codlote");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var borrar;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		borrar = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		borrar = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando �rdenes"), q.size());
	}
	var codLoteAnt = undefined;
	var borrados = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Lote %1 - Orden %2").arg(q.value("ls.codlote")).arg(q.value("op.codorden")));
		if (borrar) {
			if (q.value("ls.codlote") == codLoteAnt) {
				continue; /// Caso para el que hay dos procesos asociados a la orden y esta no ha comenzado (ms.estado y ms2.estado existen). Evita borrar ambos movimientos
			}
			var idMovimiento = q.value("ms.idmovimiento");
			if (!AQSql.del("movistock", "idmovimiento = " + idMovimiento)) {
				AQUtil.destroyProgressDialog();
				sys.warnMsgBox(sys.translate("Error al borrar el movimiento asociado al lote %1").arg(q.value("ls.codlote")));
				return false;
			}
			formregstocks.iface.revisarStock("idstock = " + q.value("ms.idstock"));
			borrados++;
			/* Solo para pruebas
			if (borrados > 4) {
				AQUtil.destroyProgressDialog();
				return true;
			}
			*/
		}
		codLoteAnt = q.value("ls.codlote");
		//if (p > 0) { break; }
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: �rdenes con dos movimientos de pte recibir:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay �rdenes con dos movimientos de pte recibir");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaMovimientosSinPadre(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("ms.idmovimiento, ms.referencia,  ms.cantidad, ms.idstock, ms.concepto, ms.fechaprev");
	q.setFrom("movistock ms left outer join lineaspedidosprov lp on ms.idlineapp = lp.idlinea");
	q.setWhere("ms.idlineapp is not null and lp.idlinea is null");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var borrar;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		borrar = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		borrar = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando movimientos"), q.size());
	}
	var borrados = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Movimiento %1 - Fecha %2 - Referencia %3 - Cantidad %4 - Concepto %5").arg(q.value("ms.idmovimiento").toString()).arg(AQUtil.dateAMDtoDMA(q.value("ms.fechaprev"))).arg(q.value("ms.referencia")).arg(q.value("ms.cantidad")).arg(q.value("ms.concepto")));
		if (borrar) {
			var idMovimiento = q.value("ms.idmovimiento");
			if (!AQSql.del("movistock", "idmovimiento = " + idMovimiento)) {
				AQUtil.destroyProgressDialog();
				sys.warnMsgBox(sys.translate("Error al borrar el movimiento asociado al lote %1").arg(q.value("ls.codlote")));
				return false;
			}
			formregstocks.iface.revisarStock("idstock = " + q.value("ms.idstock"));
			borrados++;
			/* Solo para pruebas
			if (borrados > 0) {
				AQUtil.destroyProgressDialog();
				return true;
			}
			*/
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Movimientos de pedido proveedor sin l�nea asociada:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay movimientos de pedido proveedor sin l�nea asociada");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaMovimientosSinMovProducto(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("ms.idmovimiento, ms.referencia,  ms.cantidad, ms.idstock, ms.concepto, ms.fechaprev");
	q.setFrom("movistock ms left outer join movistock msp on ms.idmovproducto = msp.idmovimiento");
	q.setWhere("ms.idmovproducto is not null and msp.idmovimiento is null");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var borrar;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		borrar = true;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		borrar = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando movimientos"), q.size());
	}
	var borrados = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Movimiento %1 - Fecha %2 - Referencia %3 - Cantidad %4 - Concepto %5").arg(q.value("ms.idmovimiento").toString()).arg(AQUtil.dateAMDtoDMA(q.value("ms.fechaprev"))).arg(q.value("ms.referencia")).arg(q.value("ms.cantidad")).arg(q.value("ms.concepto")));
		if (borrar) {
			var idMovimiento = q.value("ms.idmovimiento");
			if (!AQSql.del("movistock", "idmovimiento = " + idMovimiento)) {
				AQUtil.destroyProgressDialog();
				sys.warnMsgBox(sys.translate("Error al borrar el movimiento asociado al lote %1").arg(q.value("ls.codlote")));
				return false;
			}
			formregstocks.iface.revisarStock("idstock = " + q.value("ms.idstock"));
			borrados++;
			/* Solo para pruebas
			if (borrados > 0) {
				AQUtil.destroyProgressDialog();
				return true;
			}
			*/
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: emBuscaMovimientosSinMovProducto - Movimientos material sin movimiento de producto asociado:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay Movimientos material sin movimiento de producto asociado");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaPartidasMal(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("a.numero, a.codejercicio, p.codsubcuenta, p.idpartida");
	q.setFrom("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento");
	q.setWhere("p.idsubcuenta is NULL AND p.codsubcuenta IS NOT NULL AND (debe <> 0 OR haber <> 0) ORDER BY a.codejercicio, a.numero");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando partidas"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Asiento  %1 - Ejercicio %2 - Subcuenta %3 - Id Partida %4").arg(q.value("a.numero")).arg(q.value("a.codejercicio")).arg(q.value("p.codsubcuenta")).arg(q.value("p.idpartida").toString()));
		if (corregir) {
		    var idSubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codejercicio = '" + q.value("a.codejercicio") + "' AND codsubcuenta = '" + q.value("p.codsubcuenta") + "'");
            if (idSubcuenta) {			
			    if (!AQUtil.execSql("UPDATE co_partidas SET idsubcuenta = " + idSubcuenta + " WHERE idpartida = " + q.value("p.idpartida"))) {
			        return false;
			    }
    			corregidos++;
			    /* Solo para pruebas 
			    if (corregidos > 0) {
				    AQUtil.destroyProgressDialog();
				    return true;
			    }
			    */
		    } else {
		        sys.warnMsgBox(sys.translate("No se ha podido obtener la subcuenta para el c�digo %1 y el ejercicio %2").arg(q.value("p.codsubcuenta")).arg(q.value("a.codejercicio")));
		    }
		}
	}
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Partidas con idsubcuenta no informado:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay partidas contables con problemas");
	
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaStocksAFaltasMal(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("s.idstock, s.codalmacen, s.referencia, s.afaltas, sum(ms.reservaaf)");
	q.setFrom("stocks s left outer join movistock ms on s.idstock = ms.idstock and ms.estado = 'PTE' and ms.em_merma is not null and ms.em_merma <> true");
	q.setWhere("1=1 group by s.idstock, s.codalmacen, s.referencia, s.afaltas having (abs(s.afaltas - sum(ms.reservaaf))) > 0.1 OR (s.afaltas<>0 AND sum(ms.reservaaf) IS NULL)");
	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = true;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando stocks"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Stock  %1 - Almac�n %2 - Referencia %3 - Total AF %4 - Suma AF %5").arg(q.value("s.idstock")).arg(q.value("s.codalmacen")).arg(q.value("s.referencia")).arg(q.value("s.afaltas")).arg(q.value("sum(ms.reservaaf)")));
		if (corregir) {
			var idStock = q.value("s.idstock");
			formregstocks.iface.revisarStock("idstock = " + idStock);
			corregidos++;
			/* Solo para pruebas 
			if (corregidos > 0) {
				AQUtil.destroyProgressDialog();
				return true;
			}
			*/
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Stocks con A faltas distinto de la suma de movimientos con reserva a faltas:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay stocks con A faltas distinto de la suma de movimientos con reserva a faltas");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaStockReservaExMal(oParam)
{
	var q = new AQSqlQuery;
	/*q.setSelect("s.idstock, s.referencia, s.codalmacen, s.reservada, SUM(ms.reservaex)");
	q.setFrom("stocks s INNER JOIN movistock ms ON s.idstock = ms.idstock");
	q.setWhere("ms.estado = 'PTE' AND ms.cantidad < 0 AND s.cantidad >= 0 AND NOT ms.em_merma GROUP BY s.idstock, s.referencia, s.codalmacen, s.reservada, s.cantidad having ABS(SUM(ms.reservaex) - s.reservada) > 0.1");*/
	
	q.setSelect("s.idstock, s.referencia, s.codalmacen, s.reservada, SUM(ms.reservaex)");
	q.setFrom("stocks s LEFT OUTER JOIN movistock ms ON s.idstock = ms.idstock and ms.estado = 'PTE' AND ms.cantidad < 0 and NOT ms.em_merma");
	q.setWhere("s.cantidad >= 0 GROUP BY s.idstock, s.referencia, s.codalmacen, s.reservada, s.cantidad having ABS(SUM(ms.reservaex) - s.reservada) > 0.1 or (SUM(ms.reservaex) is null and s.reservada <> 0)");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = true;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando stocks"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Stock  %1 - Almac�n %2 - Referencia %3 - Cantidad en stock %4 - Reserva Ex %5").arg(q.value("s.idstock")).arg(q.value("s.codalmacen")).arg(q.value("s.referencia")).arg(q.value("s.reservada")).arg(q.value("SUM(ms.reservaex)")));
		if (corregir) {
			var idStock = q.value("s.idstock");
			formregstocks.iface.revisarStock("idstock = " + idStock);
			corregidos++;
			/* Solo para pruebas 
			if (corregidos > 0) {
				AQUtil.destroyProgressDialog();
				return true;
			}
			*/
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Stocks con reserva de existencias superior a las existencias reales:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay stocks con reserva de existencias superior a las existencias reales");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaMoviPedServidos(oParam)
{
	var q = new AQSqlQuery;

	q.setSelect("p.fecha, p.codigo, lp.numlinea, ms.idmovimiento, lp.idlinea");
	q.setFrom("pedidoscli p inner join lineaspedidoscli lp on p.idpedido = lp.idpedido inner join movistock ms on lp.idlinea = ms.idlineapc");
	q.setWhere("(not lp.cerrada or lp.cerrada is null) and lp.cantidad <= lp.totalenalbaran and ms.cantidad < 0 and ms.estado = 'PTE'");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando stocks"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Pedido  %1 - L�nea %2 - Fecha %3 - Movimiento %4").arg(q.value("p.codigo")).arg(q.value("lp.numlinea")).arg(AQUtil.dateAMDtoDMA(q.value("p.fecha"))).arg(q.value("ms.idmovimiento").toString()));
		if (corregir) {
			var idLinea = q.value("lp.idlinea");
			var curLP = new FLSqlCursor("lineaspedidoscli");
			curLP.select("idlinea = " + idLinea);
			if (curLP.first()) {
				curLP.setModeAccess(curLP.Edit);
				curLP.refreshBuffer();
				if (!flfactalma.iface.borrarEstructura(curLP)) {
					return false;
				}
				if (!flfactalma.iface.generarEstructura(curLP)) {
					return false;
				}
			}
			corregidos++;
			/* Solo para pruebas 
			if (corregidos > 0) {
				AQUtil.destroyProgressDialog();
				return true;
			}
			*/
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Movimientos asociados a pedidos servidos:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay movimientos asociados a pedidos servidos");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaMoviCompSinFaltas(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("ms.idmovimiento, ms.referencia,  ms.cantidad, ms.idstock, ms.concepto, ms.fechaprev");
	q.setFrom("movistock ms INNER JOIN movistock msp on ms.idmovproducto = msp.idmovimiento");
	q.setWhere("ms.idmovproducto is not null and msp.idmovimiento is NOT null AND msp.reservaaf = 0");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var borrar;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		borrar = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		borrar = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando movimientos"), q.size());
	}
	var borrados = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Movimiento %1 - Fecha %2 - Referencia %3 - Cantidad %4 - Concepto %5").arg(q.value("ms.idmovimiento").toString()).arg(AQUtil.dateAMDtoDMA(q.value("ms.fechaprev"))).arg(q.value("ms.referencia")).arg(q.value("ms.cantidad")).arg(q.value("ms.concepto")));
		if (borrar) {
			var idMovimiento = q.value("ms.idmovimiento");
			if (!AQSql.del("movistock", "idmovimiento = " + idMovimiento)) {
				AQUtil.destroyProgressDialog();
				sys.warnMsgBox(sys.translate("Error al borrar el movimiento asociado al lote %1").arg(q.value("ls.codlote")));
				return false;
			}
			formregstocks.iface.revisarStock("idstock = " + q.value("ms.idstock"));
			borrados++;
			/* Solo para pruebas
			if (borrados > 0) {
				AQUtil.destroyProgressDialog();
				return true;
			}
			*/
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Movimientos de reserva de material asociados a movimientos sin faltas:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay movimientos de reserva de material asociados a movimientos sin faltas");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;
}

function euromoda_emBuscaOrdenesDobleExistencia(oParam)
{
	var q = new AQSqlQuery;
	q.setSelect("op.codorden, ls.codlote, ms.idmovimiento");
	q.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion INNER JOIN movistock ms ON ls.codlote = ms.codlote INNER JOIN albaranesprov ap ON op.codorden = ap.codordenprod AND op.codconfeccionista = ap.codproveedor INNER JOIN lineasalbaranesprov la ON ap.idalbaran = la.idalbaran AND la.referencia = ls.referencia INNER JOIN movistock msla ON la.idlinea = msla.idlineaap AND msla.idmovimiento <> ms.idmovimiento");
	q.setWhere("ms.estado = 'HECHO' AND msla.estado = 'HECHO' AND msla.cantidad >= ms.cantidad AND msla.codlote IS NULL AND ms.idlineaap IS NULL ORDER BY op.codorden");
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
debug(q.sql());
	var lista = [];
	var p = 0;
	var opt = ["Buscar", "Buscar y corregir"];
	var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
	var borrar = (o == opt[1]);
	AQUtil.createProgressDialog(sys.translate("Revisando �rdenes"), q.size());
	while (q.next()) {
		p++;
		AQUtil.setProgress(p);
		lista.push(sys.translate("Lote %1 - Orden %2").arg(q.value("ls.codlote")).arg(q.value("op.codorden")));
		if (borrar) {
			var idMovimiento = q.value("ms.idmovimiento");
			if (!AQSql.del("movistock", "idmovimiento = " + idMovimiento)) {
				AQUtil.destroyProgressDialog();
				sys.warnMsgBox(sys.translate("Error al borrar el movimiento asociado al lote %1").arg(q.value("ls.codlote")));
				return false;
			}
		}
		//if (p > 0) { break; }
	}
	AQUtil.destroyProgressDialog();
	sys.infoMsgBox(sys.translate("�rdenes con dos movimientos de existencias:\n%1").arg(lista.join("\n")));
	
	return true;
}

function euromoda_emDiagnostico(oParam)
{
debug("emDiagnostico");
	var _i = this.iface;
	var silent = (oParam == "SILENT");
	
	var oP = {
		silent : true
	};
	var diagnostico = "OK";
	var asunto = sys.translate("Diagn�stico Euromoda");
	var lista2Procesos = _i.emBuscaOrdenesIncorrectas(oP);
	if(lista2Procesos.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var lista2PteRx = _i.emBuscaOrdenesDoblePteRx(oP);
	if(lista2PteRx.left(2) != "OK") {
		diagnostico =  sys.translate("KO");
	}
	var listaMSSinPadre = _i.emBuscaMovimientosSinPadre(oP);
	if(listaMSSinPadre.left(2) != "OK") {
		diagnostico =  sys.translate("KO");
	}
	var listaMSSinMSproducto = _i.emBuscaMovimientosSinMovProducto(oP);
	if(listaMSSinMSproducto.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaMSCompSinFaltas = _i.emBuscaMoviCompSinFaltas(oP);
	if(listaMSCompSinFaltas.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaMSReservaExMal = _i.emBuscaStockReservaExMal(oP);
	if(listaMSReservaExMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaStocksAFaltasMal = _i.emBuscaStocksAFaltasMal(oP);
	if(listaStocksAFaltasMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaMSPedidosServidos = _i.emBuscaMoviPedServidos(oP);
	if(listaMSPedidosServidos.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaPartidasMal = _i.emBuscaPartidasMal(oP);
	if(listaPartidasMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaCtasCambianProv = _i.emBuscaCtasCambianProv(oP);
	if(listaCtasCambianProv.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaTramosEstMal = _i.emBuscaTramosEstMal(oP);
	if(listaTramosEstMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaLineasEstMal = _i.emBuscaLineasEstMal(oP);
	if(listaLineasEstMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaPedImpMal = _i.emPedidosImporteMal(oP);
	if(listaPedImpMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}	
	var listaLotesMal = _i.emLotesSinStock(oP)
	if(listaLotesMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaRecDecMal = _i.emRecibosDecimalesMal(oP)
	if(listaRecDecMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}	
	var listaRecEmiCero = _i.emRecibosEmitidosAcero(oP)
	if(listaRecEmiCero.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaRecCompEmi = _i.emRecibosCompEmi(oP)
	if(listaRecCompEmi.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}		
	var listaCantResMayorMov = _i.emCantResMayorMov(oP)
	if(listaCantResMayorMov.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}
	var listaOrdCantEstJose = _i.emBuscaOrdCantEstJose(oP);
	if(listaOrdCantEstJose.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}

	var listaOrdTramoLineaDis = _i.emBuscaOrdTramoLineaDis(oP);
	if(listaOrdTramoLineaDis.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}

	var listaLinTramoRefDis = _i.emBuscaLinTramoRefDis(oP)
	if(listaLinTramoRefDis.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}

	var listaMovPteRecMal = _i.emBuscaMovPteRecMal(oP)
	if(listaMovPteRecMal.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}

	var listaStosksRepetidos = _i.emBuscaStosksRepetidos(oP)
	if(listaStosksRepetidos.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}

	var listaStockNegResPos = _i.emBuscaStockNegResPos(oP)
	if(listaStockNegResPos.left(2) != "OK") {
		 diagnostico =  sys.translate("KO");
	}

	

	if(diagnostico == "KO") {
		asunto += " "+diagnostico+" REVISAR";
	}	
	var msg = lista2Procesos + "\n" + lista2PteRx + "\n" + listaMSSinPadre + "\n" + listaMSSinMSproducto + "\n" + listaMSCompSinFaltas + "\n"  + listaMSReservaExMal + "\n" + listaStocksAFaltasMal + "\n" + listaMSPedidosServidos + "\n"  + listaPartidasMal + "\n"  + listaCtasCambianProv + "\n"  + listaTramosEstMal + "\n"  + listaLineasEstMal + "\n" + listaPedImpMal + "\n" + listaLotesMal + "\n" + listaRecDecMal + "\n" + listaRecEmiCero + "\n" + listaRecCompEmi + "\n" + listaCantResMayorMov + "\n" + listaOrdCantEstJose + "\n" + listaOrdTramoLineaDis + "\n" + listaLinTramoRefDis + "\n" + listaMovPteRecMal + "\n" + listaStosksRepetidos + "\n" + listaStockNegResPos;
	debug(msg);
	if (!silent) {
		sys.infoMsgBox(msg);
	}

	_i.enviaCorreo(msg, asunto);
	return true;
}

function euromoda_enviaCorreo(mensaje, asunto)
{
debug("enviaCorreo");
	var _i = this.iface;

	
	
	var curSmtp = new FLSqlCursor("factppal_general");
	curSmtp.select("1 = 1");
	if (!curSmtp.first()) {
	debug("!first())");
		return false;
	}
	
	var vB = curSmtp.valueBuffer;
	
	_i.oCorreo_ = new AQSmtpClient;  
	var oCorreo = _i.oCorreo_;  
	connect(oCorreo, "statusChanged(QString, int)", _i, "statusChanged()");

	oCorreo.setMailServer(vB("hostsmtp"));
		
	oCorreo.setPort(vB("puertosmtp"));
	switch (vB("tipocxsmtp")) {
		case "SSL": {
			oCorreo.setConnectionType(AQS.SmtpSslConnection);  
			break;
		}
		case "TLS": {
			oCorreo.setConnectionType(AQS.SmtpTlsConnection);
			break;
		}
		default: {
			return false;
		}
	}
		
	switch (vB("tipoautsmtp")) {
		case "Plain": {
			oCorreo.setAuthMethod(AQS.SmtpAuthPlain);
			break;
		}
		case "Login": {
			oCorreo.setAuthMethod(AQS.SmtpAuthLogin);
			break;
		}
		default: {
			return false;
		}
	}
	//** Tambien se puede usar el m�todo Login
	//** Algunos servidores s�lo soportan Login
	//** GMail soporta los dos Plain y Login
	//** _i.correo_.setAuthMethod(AQS.SmtpAuthLogin);

	oCorreo.setUser("vigilancia.yeboyebo@gmail.com");  
	oCorreo.setPassword("zadgxfrqyprzfxqd");  
	

	try {
		oCorreo.setMimeType("text/plain");
		oCorreo.setBody(mensaje);
	} catch (e) {
		oCorreo.setBody(mensaje);
	}
	var rutaF = Dir.home + "/dummyfile.txt";
	File.write(rutaF, "Hola");
	
	oCorreo.setFrom("vigilancia.yeboyebo@gmail.com");
	oCorreo.setTo("antonio@yeboyebo.es,pozuelo@yeboyebo.es");
	oCorreo.setSubject(asunto);
	oCorreo.addAttachment(rutaF);

	oCorreo.startSend();
	var d1 = new Date;
	var d2 = new Date;
	while (false && d2.getTime() - d1.getTime() < 10000) {
		sys.processEvents();
		d2 = undefined;
		d2 = new Date;
	}
	debug("se ha enviado");
	return true;
}

function euromoda_statusChanged(msg, code)
{
	var _i = this.iface;
	switch(code) {
		case AQS.SmtpSendOk: {
			//sys.infoMsgBox(sys.translate("Email enviado correctamente"));
			break;
		}
		case AQS.SmtpError:
		case AQS.SmtpMxDnsError:
		case AQS.SmtpSocketError:
		case AQS.SmtpAttachError:
		case AQS.SmtpServerError:
		case AQS.SmtpClientError: {
			//sys.errorMsgBox(sys.translate("Error al enviar el email al proveedor %1 %2").arg(code).arg(msg));
			break;
		}
	}
  debug("STATUS CHANGED " + msg + " :  " + code);
}

function euromoda_emRehacerMovimientosOE(oParam)
{
	
	var _i = this.iface;
	var oLista = [];
	var where = "";
	var i =0;
	var lista = Input.getText("Lista de ordenes separadas por comas");
	if (lista == "") {
		where = "1=1";
	} else {
		oLista = lista.split(",");
		lista = "'" + oLista.join("', '") + "'";			
		debug("lista: "+lista);
		where = "codordenest in ("+lista+")";
	}
	debug("where: "+where);
	var curLE = new FLSqlCursor("em_lineasordenest");
	curLE.select(where);
	while (curLE.next()) {
		debug("*********************************");
		debug("i: "+i);
		debug("codOrden: "+curLE.valueBuffer("codordenest"));
		debug("idlinea: "+curLE.valueBuffer("idlinea"));
		
		curLE.setModeAccess(curLE.Edit);
		curLE.refreshBuffer();
		if (!fleumoesta.iface.borraMovsLineaEst(curLE)) {
			return false;
		}
		if (!fleumoesta.iface.generaMovsLineaEst(curLE)) {
			return false;
		}
		if (!flfactalma.iface.pub_reservasConsumoEstampacion(curLE.valueBuffer("idlinea"))) {
			return false;
		}
		i++;
		debug("*********************************");
	}
	debug("Revisadas " + i +" l�neas de ordenes de estampaci�n");
	return true;
	
	
}

function euromoda_emRehacerMovimientosPC(oParam)
{
	
	var _i = this.iface;
	var oLista = [];
	var where = "";
	var i =0;
	var k=0;
	var lista = Input.getText("Lista de pedidos separados por comas");
	if (lista == "") {
		where = "1=1";
	} else {
		oLista = lista.split(",");
		lista = "'" + oLista.join("', '") + "'";			
		debug("lista: "+lista);
		where = "codigo in ("+lista+")";
	}
	
	var q = new AQSqlQuery;	
	q.setSelect("idpedido, codigo");
	q.setFrom("pedidoscli");
	q.setWhere(where); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		debug("******************************************************************************************************");
		var idPedido = q.value("idpedido");
		var codPedido = q.value("codigo");	
		debug("codpedido: "+codPedido+" idPedido: "+idPedido);
		var curLP = new FLSqlCursor("lineaspedidoscli");
		curLP.select("idpedido = " +idPedido);
		while (curLP.next()) {
			debug("*********************************");					
			curLP.setModeAccess(curLP.Edit);
			curLP.refreshBuffer();
			debug("k: "+k);
			debug("codpedido: "+codPedido);
			debug("idlineapedido: "+curLP.valueBuffer("idlinea"));			
			
			if (!flfactalma.iface.borrarEstructura(curLP)) {
				return false;
			}
			if (!flfactalma.iface.generarEstructura(curLP)) {
				return false;
			}		
			
			k++;
			
			debug("*********************************");
		}
		i++;			
	}	
	debug("Revisados " + i +" pedidos y " + k + "l�neas de pedidos");
	debug("******************************************************************************************************");
	return true;
	
	
}

function euromoda_cambiaStocksMovTramoLote(oParam)
{
	var _i = this.iface;

	var q = new AQSqlQuery;
	q.setSelect("ms.idmovimiento, ls.codalmacen, s.idstock, ms.idstock");
	q.setFrom("movistock ms INNER JOIN lotesstock ls ON ms.codlote = ls.codlote INNER JOIN stocks s ON ls.codalmacen = s.codalmacen and ls.referencia = s.referencia");
	q.setWhere("ms.emidtramo IS NOT NULL AND ms.idstock <> s.idstock AND ms.referencia = s.referencia");
	if (!q.exec()) {
		return false;
	}
	debug(q.sql());

	AQUtil.createProgressDialog(sys.translate("Revisando movimientos"), q.size());
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(++p);
		AQUtil.execSql("UPDATE movistock SET idstock = " + q.value("s.idstock") + " WHERE idmovimiento = " + q.value("ms.idmovimiento"));
	}
	AQUtil.destroyProgressDialog();

	return true;
}

function euromoda_creaMovimientosTPPE(oParam)
{
	var _i = this.iface;
	var q = new AQSqlQuery;
	q.setSelect("codpartidappe");
	q.setFrom("em_tramostejido");
	q.setWhere("1=1 group by codpartidappe");
	if (!q.exec()) {
		return false;
	}
	debug(q.sql());

	AQUtil.createProgressDialog(sys.translate("Revisando movimientos"), q.size());
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(++p);
		var codPartidaPPE = q.value("codpartidappe");
		//var idTramo = AQUtil.sqlSelect("em_tramostejido","idtramo","codpartida = '" + codPartidaPPE + "' ");
		if(!codPartidaPPE || codPartidaPPE == "") {
			continue;
		}
		
		var curTT = new FLSqlCursor("em_tramostejido");
  		curTT.select("codpartida = '" + codPartidaPPE + "' ");
  		if (!curTT.first()) {
			return false;
  		}
  		curTT.setModeAccess(curTT.Edit);
  		curTT.refreshBuffer(); 
  		if(!fleumoesta.iface.borraMovsTramoTejido(curTT)) {
  			return false;
  		}
  		if(!fleumoesta.iface.generaMovsTramoTejido(curTT)) {
  			return false;
  		}		
	}
	AQUtil.destroyProgressDialog();

	return true;

}

function euromoda_emBorraReservasTejidoOFF(oParam)
{
	var _i = this.iface;

	//select count(*) from movistock ms inner join movistock mp on ms.idmovtejidoprep = mp.idmovimiento where mp.estado = 'OFF';

	var q = new AQSqlQuery;
	q.setSelect("mp.idmovimiento");
	q.setFrom("movistock ms inner join movistock mp on ms.idmovtejidoprep = mp.idmovimiento");
	q.setWhere("mp.estado = 'OFF'");
	if (!q.exec()) {
		return false;
	}
	debug(q.sql());

	AQUtil.createProgressDialog(sys.translate("Revisando movimientos"), q.size());
	var p = 0, idMovimiento;
	var curMS = new FLSqlCursor("movistock");
	while (q.next()) {
		AQUtil.setProgress(++p);
		idMovimiento = q.value("mp.idmovimiento");
		curMS.select("idmovimiento = " + idMovimiento);
		if (!curMS.first()) {
			AQUtil.destroyProgressDialog();
			debug("Movimiento no encontrado " + idMovimiento);
			return false;
		}
		curMS.setModeAccess(curMS.Edit);
		curMS.refreshBuffer();
		if (!curMS.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			debug("CommitBuffer falla para movimiento " + idMovimiento);
			return false;
		}
	}
	AQUtil.destroyProgressDialog();

	return true;

}

function euromoda_emArreglaCantNegaOE(oParam)
{
	var _i = this.iface;

	var curLE = new FLSqlCursor("em_lineasordenest");
  	curLE.select("canpendiente < 0");
	while (curLE.next()) {
		curLE.setModeAccess(curLE.Edit);
  		curLE.refreshBuffer(); 
  		curLE.setValueBuffer("canpendiente",0);
  		if(!curLE.commitBuffer()) {
  			return false;
  		}
	
	}
	return true;
}

function euromoda_emArreglaLotesNeg(oParam)
{
	var idTramo = Input.getText(sys.translate("IdTramo del tramo estampado err�neo"));
	if (!idTramo) {
		return;
	}
  	var curTT = new FLSqlCursor("em_tramostejido");
  	curTT.select("idtramo = " + idTramo);
  	if (!curTT.first()) {
		return false;
  	}
  	curTT.setModeAccess(curTT.Edit);
  	curTT.refreshBuffer(); 
  	var codPartidaPPE = curTT.valueBuffer("codpartidappe");
  	var codBobinaPPE = curTT.valueBuffer("codbobinappe");
  	var canTramo = curTT.valueBuffer("cantotal");
  	var codPartidaDes = AQUtil.sqlSelect("lotesstock","codlote","codbobina = '" + codBobinaPPE + "'");
  	var canDisponible = AQUtil.sqlSelect("lotesstock","candisponible","codlote = '" +codPartidaDes + "'");
  	var idTramoPPE = AQUtil.sqlSelect("em_tramostejido","idtramo","codbobina = '" + codBobinaPPE + "'");
  	
  	debug("codPartidaPPE: "+codPartidaPPE);
  	debug("codBobinaPPE: "+codBobinaPPE);
  	debug("canTramo: "+canTramo);
  	debug("codPartidaDes: "+codPartidaDes);
  	debug("canDisponible: "+canDisponible);
  	debug("idTramoPPE: "+idTramoPPE);
  	
  	if(canDisponible < canTramo) {
  		
		debug("cantidad a regularizar: "+canTramo);
		if(!formem_estampacion.iface.regulTramosPartida(idTramoPPE, canTramo)) {
			return false;
		}
		if(!formem_estampacion.iface.regulPartida(codPartidaDes, canTramo)) {
			return false;
		}	
	}
  	
  	curTT.setValueBuffer("codpartidappe",codPartidaDes);
  	curTT.setValueBuffer("idtramoorigen",idTramoPPE);

 	if (!curTT.commitBuffer()) {
      return false;
 	}
 	return true;
	
}
function euromoda_lineaEstCalc(oParam)
{
	var _i = this.iface;
	var codOrden = Input.getText(sys.translate("C�digo de la OE o escribir TODAS para todas las ordenes"));
	if (!codOrden) {
		return;
	}
	
	if(codOrden == "TODAS") {	
		
		var _i = this.iface;
		var q = new AQSqlQuery;
		q.setSelect("oe.codordenest, oe.cantestampada, SUM(tt.cantotal)");
		q.setFrom("em_ordenesestampacion oe inner join em_lineasordenest loe on oe.codordenest=loe.codordenest inner join em_tramostejido tt on tt.idlineaestcalc = loe.idlinea");
		q.setWhere("oe.codordenest <> 'OE00000361' AND oe.codordenest <>'OE00000252'  GROUP BY oe.codordenest, oe.cantestampada having  abs(oe.cantestampada-SUM(tt.cantotal))>0.01 order by oe.codordenest");		
		if (!q.exec()) {
			return false;
		}
		debug(q.sql());		
		AQUtil.createProgressDialog(sys.translate("Revisando �rdenes de estampaci�n"), q.size());
		var p = 0;
		while (q.next()) {
			AQUtil.setProgress(++p);
			var codOrden = q.value("oe.codordenest");
			_i.arreglaLineaEstCalc(codOrden);
		}
		AQUtil.destroyProgressDialog();
	} else {
		_i.arreglaLineaEstCalc(codOrden);
	
	}	
	return true;
}
function euromoda_arreglaLineaEstCalc(codOrden)
{

	if (!AQUtil.execSql("UPDATE em_tramostejido SET idlineaestcalc = NULL WHERE codordenest = '"+ codOrden + "'")) {
		return false;
	}
	
	var cont = 1;
	var q = new AQSqlQuery;	
	q.setSelect("idtramo,idtramoorigen,idlineaest");
	q.setFrom("em_tramostejido");
	q.setWhere("codordenest = '" + codOrden + "' and idlineaest is not null"); 			
	debug("sql: "+q.sql());
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idTramoOrigen = q.value("idtramoorigen");
		var idTramo  = q.value("idtramo");
		var idLineaEst = q.value("idlineaest");
		var encontrado = false;
		debug("idTramoOrigen: "+idTramoOrigen);
		debug("idTramo: "+idTramo);
		debug("idLineaEst: "+idLineaEst);
		while(!encontrado) {
			cont++;
			var estado = AQUtil.sqlSelect("em_bobinas left outer join em_tramostejido on em_bobinas.codbobina=em_tramostejido.codbobina","estado","idtramo = " + idTramoOrigen,"em_bobinas");
			debug("estado: "+estado);
			if(estado == "PARA ESTAMPAR") {
				encontrado = true;
			} else {				
				idTramo = idTramoOrigen;
				idTramoOrigen = AQUtil.sqlSelect("em_tramostejido","idtramoorigen","idtramo = "+idTramo);
				encontrado = false;
			}	
		}
		debug("ACTUALIZA IDTRAMO: "+idTramo+" con la linea: "+idLineaEst);
		if (!AQUtil.execSql("UPDATE em_tramostejido SET idlineaestcalc = " + idLineaEst + " WHERE idtramo = "+ idTramo )) {
			return false;
		}
		
		fleumoesta.iface.totalizaLineaEst(idLineaEst);

	}	
	return true;	
}
function euromoda_calculaReservadaOE(oParam)
{
	var cont = 1;
	var q = new AQSqlQuery;	
	q.setSelect("stocks.idstock, SUM(mt.reservaex)");
	q.setFrom("stocks inner join movistock mt ON stocks.idstock = mt.idstock INNER JOIN movistock me ON me.idmovimiento = mt.idmovtejidopadre ");
	q.setWhere("me.emidlineaest is not null GROUP BY stocks.idstock"); 			
	debug("sql: "+q.sql());
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idStock = q.value("stocks.idstock");
		var aReservadaOE  = q.value("SUM(mt.reservaex)");

		if (!AQUtil.execSql("UPDATE stocks SET em_reservadaoe = " + aReservadaOE + " WHERE idstock = "+ idStock )) {
			return false;
		}
		cont++;
	}	
	sys.infoMsgBox(sys.translate("Se han actualizado %1 stocks").arg(cont));

	return true;	
}
function euromoda_emBuscaCtasCambianProv(oParam)
{

	var arrayCuentas = ["400","4000","40000","4004","40040","410","4100","41000","41001","411","412","414","4180","4190","523","5230","52300"];	
	var listaCuentas = "'" + arrayCuentas.join("', '") + "'";
	
	var q = new AQSqlQuery;	
	q.setSelect("codejercicio, codcuenta,idcuenta,idcuentaesp");
	q.setFrom("co_cuentas");
	q.setWhere("codcuenta in ("+listaCuentas+") and (idcuentaesp<>'PROVEE' OR idcuentaesp is null OR idcuentaesp='') order by codejercicio, codcuenta");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando cuentas"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Ejercicio  %1 - Cuenta %2 - Tipo especial %3").arg(q.value("codejercicio")).arg(q.value("codcuenta")).arg(q.value("idcuentaesp")));
		if (corregir) {
			var idCuenta = q.value("idcuenta");
			if (!AQUtil.execSql("UPDATE co_cuentas SET idcuentaesp = 'PROVEE' WHERE idcuenta = "+ idCuenta)) {
				return false;
			}
			corregidos++;
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Cuentas que no tienen el tipo especial PROVEE y deber�an de tenerlo. Comprobar:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay cuentas cuentas sin el tipo especial que deber�a de tenerlo");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

}
function euromoda_emBuscaTramosEstMal(oParam)
{	
	
	var q = new AQSqlQuery;	
	q.setSelect("oe.codordenest, oe.cantestampada, SUM(tt.cantotal)");
	q.setFrom("em_ordenesestampacion oe inner join em_lineasordenest loe on oe.codordenest=loe.codordenest inner join em_tramostejido tt on tt.idlineaestcalc = loe.idlinea");
	q.setWhere("oe.codordenest NOT IN ('OE00000361','OE00000252','OE00005803','OE00004498','OE00004499','OE00004604','OE00005784','OE00005785','OE00006426')  GROUP BY oe.codordenest, oe.cantestampada having  abs(oe.cantestampada-SUM(tt.cantotal))>0.01 order by oe.codordenest");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;

	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando �rdenes"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Orden  %1 - Cantidad estampada orden %2 - Suma cantidad estampada de los tramos %3").arg(q.value("oe.codordenest")).arg(q.value("oe.cantestampada")).arg(q.value("SUM(tt.cantotal)")));
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: �rdenes que no coinciden la cantidad estampada con la suma de la cantidad estampada de sus tramos:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay �rdenes donde la suma de la cantidad estampada de los tramos no coincida con la cantidad estampada de las �rdenes");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

}

function euromoda_emBuscaLineasEstMal(oParam)
{		
	var q = new AQSqlQuery;	
	q.setSelect("oe.codordenest, oe.cantestampada, SUM(loe.canestampada)");
	q.setFrom("em_ordenesestampacion oe inner join em_lineasordenest loe on oe.codordenest=loe.codordenest");
	q.setWhere("1=1 GROUP BY oe.codordenest, oe.cantestampada having abs(oe.cantestampada-SUM(loe.canestampada))>0.01  order by oe.codordenest");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;

	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando �rdenes"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Orden  %1 - Cantidad estampada orden %2 - Suma cantidad estampada de los tramos %3").arg(q.value("oe.codordenest")).arg(q.value("oe.cantestampada")).arg(q.value("SUM(loe.canestampada)")));
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: �rdenes que no coinciden la cantidad estampada con la suma de la cantidad estampada de sus l�neas:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay �rdenes donde la suma de la cantidad estampada de las l�neas no coincida con la cantidad estampada de las �rdenes");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

}

function euromoda_emPedidosImporteMal(oParam)
{
	var q = new AQSqlQuery;		
	q.setSelect("cab.idpedido, cab.codigo, cab.netosindtoesp,  SUM(lin.pvptotal), cab.netosindtoesp-SUM(lin.pvptotal)");
	q.setFrom("pedidoscli cab inner join lineaspedidoscli lin on cab.idpedido=lin.idpedido");
	q.setWhere("1=1 GROUP BY cab.idpedido, cab.codigo, cab.netosindtoesp having (abs(cab.netosindtoesp-SUM(lin.pvptotal)))>0.1");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;

	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando pedidos"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     IdPedido %1 - C�digo Pedido %2 - Importe cabecera %3 - Suma importe de las l�neas %4 - Diferencia %5").arg(q.value("cab.idpedido")).arg(q.value("cab.codigo")).arg(q.value("cab.netosindtoesp")).arg(q.value("SUM(lin.pvptotal)")).arg(q.value("cab.netosindtoesp-SUM(lin.pvptotal)")));
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Pedidos en los que no coinciden la suma de los importes de la l�neas con el importe de la cabecera:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay pedidos en los que la suma del importe de la l�nea no coincida con el importe de la cabecera");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

	
}

function euromoda_emLotesSinStock(oParam)
{
	var q = new AQSqlQuery;		
	q.setSelect("l.referencia,l.codalmacen,l.codlote");
	q.setFrom("lotesstock l left outer join stocks s on l.referencia=s.referencia and l.codalmacen=s.codalmacen");
	q.setWhere("(l.referencia is null or s.referencia is null) GROUP BY l.referencia,l.codalmacen,l.codlote order by l.referencia,l.codalmacen,l.codlote");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando lotes"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Referencia %1 - Almac�n %2 - Lote  %3").arg(q.value("l.referencia")).arg(q.value("l.codalmacen")).arg(q.value("l.codlote")));
		if (corregir) {
			var referencia = q.value("l.referencia");
			var codAlmacen = q.value("l.codalmacen");
			var idStock;
			idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
			if ( !idStock ) {
				var oArticulo = new Object;
				oArticulo["referencia"] = referencia;
				idStock = flfactalma.iface.pub_crearStock( codAlmacen, oArticulo );
				if ( !idStock ) {
					return false;
				}
				formregstocks.iface.revisarStock("idstock = " + idStock);
			}
			
			corregidos++;
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Lotes creados en un almac�n cuya referencia-almac�n no exista en stocks. Comprobar:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay lotes que est�n creados en un almac�n y su referencia-almac�n no exista en stocks");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

	
}

function euromoda_emRecibosDecimalesMal(oParam)
{
	var q = new AQSqlQuery;		
	q.setSelect("idrecibo,importe,importeeuros,importesingd");
	q.setFrom("reciboscli");
	q.setWhere("(length(substr(cast(importe AS varchar),position('.' in cast(importe AS varchar) ))) >3 and substring(substr(cast(importe AS varchar),position('.' in cast(importe AS varchar) )),1,1) ='.') or(length(substr(cast(importeeuros AS varchar),position('.' in cast(importeeuros AS varchar) ))) >3 and substring(substr(cast(importeeuros AS varchar),position('.' in cast(importeeuros AS varchar) )),1,1) ='.') or (length(substr(cast(importesingd AS varchar),position('.' in cast(importesingd AS varchar) ))) >3 and substring(substr(cast(importesingd AS varchar),position('.' in cast(importesingd AS varchar) )),1,1) ='.') group by idrecibo,importe,importeeuros,importesingd order by idrecibo,importe,importeeuros,importesingd");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando recibos"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Recibo %1 - Importe %2 - Importeeuros %3 - Importesingd %4").arg(q.value("idrecibo")).arg(q.value("importe")).arg(q.value("importeeuros")).arg(q.value("importesingd")));
		if (corregir) {
			var idRecibo = q.value("idrecibo");
			
			if (!AQUtil.execSql("UPDATE reciboscli SET importe=round(cast (importe as numeric),2), importesingd=round(cast (importesingd as numeric),2), importeeuros=round(cast (importeeuros as numeric),2) WHERE idrecibo = "+ idRecibo )) {
				return false;
			}
			corregidos++;
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Recibos que tienen m�s de dos decimales en sus importes. Comprobar:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay recibos con m�s de dos decimiales en sus importes.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

}

function euromoda_emRecibosEmitidosAcero(oParam)
{
	var q = new AQSqlQuery;		
	q.setSelect("codigo, idrecibo");
	q.setFrom("reciboscli");
	q.setWhere("importe=0 and estado ='Emitido' order by codigo");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;

	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando recibos"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     C�digo recibo %1 - IdRecibo %2").arg(q.value("codigo")).arg(q.value("idrecibo")));
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Recibos en estado emitido con importe a cero:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay recibos en estado emitido con importe a cero.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

	
}

function euromoda_emRecibosCompEmi(oParam)
{
	var q = new AQSqlQuery;		
	q.setSelect("a.idrecibo,a.codigo,b.idrecibo,b.codigo");
	q.setFrom("recibosprov a inner join recibosprov b on a.idrecibocomp=b.idrecibo");
	q.setWhere("a.estado='Emitido' and b.estado='Compensado' order by a.codigo");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;

	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando recibos"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     C�digo recibo %1 - IdRecibo %2 en estado Emitido - C�digo recibo %3 - IdRecibo %4 en estado Compensado").arg(q.value("a.codigo")).arg(q.value("a.idrecibo")).arg(q.value("b.codigo")).arg(q.value("b.idrecibo")));
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Recibos en estado Compensado con un recibo en estado Emitido:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay recibos en estado Compensado con un recibo en estado Emitido.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

	
}

function euromoda_emCantResMayorMov(oParam)
{

	var q = new AQSqlQuery;		
	q.setSelect("referencia,codlote, cantidad, enreserva, idmovimiento,concepto");
	q.setFrom("movistock");
	q.setWhere("estado = 'PTE' and cantidad > 0 and enreserva > cantidad order by concepto");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;

	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando reservas"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		var concepto = q.value("concepto");
		var codOrden = concepto.right(10);
		lista.push(sys.translate("     OP %1 - Cantidad %2 - En reserva %3 - Referencia %4 - Codlote %5 - Idmovimiento %6").arg(codOrden).arg(q.value("cantidad")).arg(q.value("enreserva")).arg(q.value("referencia")).arg(q.value("codlote")).arg(q.value("idmovimiento").toString()));
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Movimientos cantidad reservada mayor que la cantidad:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay movimientos con cantidad reservada mayor a la cantidad.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

	
}
function euromoda_dameVistas()
{
	var _i = this.iface;
	var vistas = _i.__dameVistas();
	vistas.push(["v_registroest", "SELECT em_tramostejido.idtramo, em_lineasordenest.codordenest, em_turnosusuario.codmaquinaest, em_tramostejido.referencia, em_tramostejido.articulo, em_tramostejido.cantotal,em_tramostejido.consumo, em_tramostejido.codpartida, em_tramostejido.codpartidappe, lotppe.referencia as refppe, em_tramostejido.codbobinappe, em_tramostejido.soporteppe, em_tramostejido.codbobinaest, em_tramostejido.soporteest, pr_trabajadores.idtrabajador AS operarioest, pr_trabajadores.nombre AS nombreest, em_tramostejido.fecha AS fechaest, em_tramostejido.horadesde AS horadesdeest, em_tramostejido.horahasta AS horahastaest, em_tramostejido.codbobinavap, em_tramostejido.soportevap, em_tramostejido.fechavap, em_tramostejido.horadesdevap, em_tramostejido.codbobinaaca, em_tramostejido.soporteaca, em_tramostejido.codbobinaprl, em_tramostejido.soporteprl, turnoroll.codmaquinaroll, trabroll.idtrabajador AS operarioroll, trabroll.nombre AS nombreroll, em_tramostejido.fecharoll, em_tramostejido.horadesderoll, em_tramostejido.horahastaroll, em_tramostejido.codbobinaroll, em_tramostejido.soporteroll, em_tramostejido.saldo, em_tiposinciest.codigo AS codinciest, em_tiposinciest.descripcion AS desctipoinciest, em_tramostejido.codincisaldo, em_incidensaldos.descripcion AS descsaldo, lotesstock.codalmacen, em_tramostejido.canusada, em_tramostejido.candisponible, em_tramostejido.merma, em_tramostejido.canmerma, em_tramostejido.cancelado, em_tramostejido.cancancelada, em_tramostejido.contadorini, em_tramostejido.contadorfin FROM ((((((((em_tramostejido JOIN em_lineasordenest ON ((em_tramostejido.idlineaest = em_lineasordenest.idlinea))) LEFT JOIN em_turnosusuario ON ((em_tramostejido.idturnousuario = em_turnosusuario.id))) LEFT JOIN pr_trabajadores ON (((em_turnosusuario.idtrabajador)::text = (pr_trabajadores.idtrabajador)::text))) LEFT JOIN em_turnosusuario turnoroll ON ((em_tramostejido.idturnousuarioroll = turnoroll.id))) LEFT JOIN pr_trabajadores trabroll ON (((turnoroll.idtrabajador)::text = (trabroll.idtrabajador)::text))) LEFT JOIN lotesstock ON (((lotesstock.codlote)::text = (em_tramostejido.codpartida)::text))) LEFT JOIN em_incidensaldos ON (((em_tramostejido.codincisaldo)::text = (em_incidensaldos.codigo)::text))) LEFT JOIN em_tiposinciest ON (((em_tiposinciest.codigo)::text = (em_tramostejido.codmotivoinci)::text)) LEFT OUTER JOIN lotesstock lotppe ON em_tramostejido.codpartidappe = lotppe.codlote );"]);

	vistas.push(["v_stocksext", "SELECT stocks.idstock, stocks.codalmacen, stocks.nombre, stocks.articulo, stocks.referencia, stocks.cantidad, stocks.disponible, stocks.reservada, stocks.reservadapterecibir, stocks.disponiblepterecibir, stocks.reservadaprod, stocks.afaltas, stocks.pterecibir, stocks.necesidad, stocks.fechaultreg, stocks.horaultreg, stocks.cantidadultreg, stocks.stockmin, stocks.stockmax, stocks.prevision, stocks.ubicacion, stocks.codtamanoem, stocks.emcolorgit, stocks.codcolorem, stocks.coddibestamp, stocks.emdibujo, stocks.idsincro, stocks.fechaultmov, stocks.horaultmov, stocks.codbarras, articulos.codfamilia, familias.descripcion AS descfam, articulos.codsubfamilia, subfamilias.descripcion AS descsubfam, articulos.codcoleccionem, em_colecciones.descripcion AS desccol, articulos.debaja, articulos.fechaliq, articulos.descatalogado, articulos.aliasart, almacenes.em_tipoalmacen, almacenes.em_relalmacen, almacenes.em_actalmacen, almacenes.em_deposito, almacenes.em_tipodeposito, almacenes.em_duaalmacen, almacenes.em_grupoalmacen, almacenes.em_tmercaalmacen, almacenes.em_caractalmacen, almacenes.em_grupoinvent, stocks.em_fechaultventaalm, stocks.em_fechaultcompraalm, articulos.em_fechaultventa, articulos.em_fechaultcompra, articulos.em_costeprod FROM (((((stocks LEFT JOIN articulos ON (((stocks.referencia)::text = (articulos.referencia)::text))) LEFT JOIN familias ON (((articulos.codfamilia)::text = (familias.codfamilia)::text))) LEFT JOIN subfamilias ON (((articulos.codsubfamilia)::text = (subfamilias.codsubfamilia)::text))) LEFT JOIN em_colecciones ON (((articulos.codcoleccionem)::text = (em_colecciones.codcoleccionem)::text))) LEFT JOIN almacenes ON (((stocks.codalmacen)::text = (almacenes.codalmacen)::text)))"]);
	
	vistas.push(["v_cola_acabados", "SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text  WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_acabados_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.pedidoacabador, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, b.codpedidoprov, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p  WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_rollado","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_rollado_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.pedidoacabador, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_vaporizador","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision  GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_vaporizador_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.pedidoacabador, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, ''::character varying(20) AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_colas","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar   FROM ( ( ( SELECT '1. COLA DE ESTAMPACION'::character varying(50) AS cola, oes.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, ''::character varying(10) AS bobina_estamp, ''::character varying(10) AS bobina_cola, ''::character varying(10) AS soporte, ''::character varying(10) AS ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(ln.canpendiente)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar  FROM em_lineasordenest ln            LEFT JOIN em_ordenesestampacion oes ON oes.codordenest::text = ln.codordenest::text WHERE ln.canpendiente > 0::double precision  GROUP BY oes.codordenest, oes.estado, oes.codmaquinaest, oes.fecha, oes.fechaentrega, oes.descripcion, oes.canaestampar, oes.canpendiente  UNION  SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr                         LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision  GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p  WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_colas_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.pedidoacabador, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM (((SELECT '1. COLA DE ESTAMPACION'::character varying(50) AS cola, oes.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, ''::character varying(10) AS bobina_estamp, ''::character varying(10) AS bobina_cola, ''::character varying(10) AS soporte, ''::character varying(20) AS pedidoacabador, ''::character varying(10) AS ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(ln.canpendiente)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar   FROM em_lineasordenest ln LEFT JOIN em_ordenesestampacion oes ON oes.codordenest::text = ln.codordenest::text  WHERE ln.canpendiente > 0::double precision GROUP BY oes.codordenest, oes.estado, oes.codmaquinaest, oes.fecha, oes.fechaentrega, oes.descripcion, oes.canaestampar, oes.canpendiente UNION SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, '' AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar  FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar         FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text        WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_estampacion_por_digital","SELECT          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END   ORDER BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END DESC"]);
	
	vistas.push(["v_estampacion_por_oe_dias","SELECT reg.codordenest AS orden_estamp,          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY reg.codordenest,  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END   ORDER BY reg.codordenest DESC,  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END"]);
	
	vistas.push(["v_estampacion_por_operario","SELECT          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, reg.nombreest AS operario, tu.codturno AS turno, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea    LEFT JOIN em_turnosusuario tu ON tt.idturnousuario = tu.id    LEFT JOIN em_turnos tn ON tn.codturno::text = tu.codturno::text   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END, tn.horadesde, tu.codturno, reg.nombreest   ORDER BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END DESC, tn.horadesde, tu.codturno, reg.nombreest"]);
	
	vistas.push(["v_estampacion_por_orden","SELECT          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, reg.codordenest AS orden_estamp, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END, reg.codordenest   ORDER BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END DESC, reg.codordenest"]);
	
	vistas.push(["v_lotesstock","select lotesstock.*, articulos.codfamilia, familias.descripcion as descfamilia, articulos.codsubfamilia, subfamilias.descripcion as descsubfamilia,articulos.codcoleccionem, em_colecciones.descripcion as descoleccion,articulos.coddibestamp,em_dibujos.descripcion as emdibujo, articulos.descatalogado, articulos.debaja,articulos.fechaliq  from lotesstock left outer join articulos on lotesstock.referencia = articulos.referencia left outer join familias on articulos.codfamilia = familias.codfamilia left outer join subfamilias on articulos.codsubfamilia = subfamilias.codsubfamilia left outer join em_colecciones on articulos.codcoleccionem = em_colecciones.codcoleccionem left outer join em_dibujos on articulos.coddibestamp = em_dibujos.coddibujoem"]);	

	vistas.push(["v_coordinados","SELECT DISTINCT art.coddibestamp,art.emdibujo,art.codcolorem as colordib, art2.coddibestamp as dibcoord, dib2.descripcion as descdibcoord, FT.codcolorem as colorcoord, ft.componormal as componente, art.codcoleccionem as coleccion, col.descripcion, art.codfamilia as famcod, f.descripcion as famdesc, art.codsubfamilia as subfamcod, sf.descripcion as subfamdesc,art.codtamanoem as tamano, dib.coddiseno FROM articulos art INNER JOIN articuloscomp ft ON ft.refcompuesto = art.referencia INNER JOIN articulos art2 ON art2.referencia = ft.refcomponente AND (art2.coddibestamp IS NOT NULL) AND ART2.CODDIBESTAMP <> ART.CODDIBESTAMP INNER JOIN subfamilias sf ON sf.codsubfamilia = art.codsubfamilia INNER JOIN familias f ON f.codfamilia = art.codfamilia left outer join em_colecciones col on art.codcoleccionem=col.codcoleccionem LEFT OUTER JOIN em_dibujos dib on dib.coddibujoem = art.coddibestamp LEFT OUTER JOIN em_dibujos dib2 ON dib2.coddibujoem = art2.coddibestamp WHERE 1=1 ORDER BY art.coddibestamp, art.codcolorem, art2.coddibestamp, dib2.descripcion, FT.codcolorem, ft.componormal, art2.coddibestamp, FT.codcolorem, art.codcoleccionem, art.codfamilia, art.codsubfamilia"]);

	vistas.push(["v_movistockart","SELECT m.*, art.descripcion as descripcionart, art.codtamanoem as codtamanoemart, art.codcolorem as codcoloremart FROM movistock m inner join articulos art on m.referencia = art.referencia WHERE 1=1 "]);

	vistas.push(["v_valoresmercado","SELECT val.id,art.referencia, art.descripcion, art.codtamanoem, art.emcolorgit,art.codcolorem,art.emdibujo,art.codbarras, art.codfamilia, fam.descripcion as descfam, art.codsubfamilia, subfam.descripcion as descsubfam, val.em_fechavalmercado, val.em_valmercado, val.em_coddivisamercado, val.em_unidmercado,val.em_valmercadoeur,val.em_tasaconvmercado, val.em_cantidad, val.em_tipomercado, val.em_nombremercado, val.codproveedor, prov.nombre as nombreprov, val.em_observaciones, val.idusuarioalta, val.fechaalta, val.horaalta, val.idusuariomod, val.fechamod, val.horamod FROM articulos art INNER JOIN familias fam ON art.codfamilia = fam.codfamilia INNER JOIN subfamilias subfam ON art.codsubfamilia = subfam.codsubfamilia INNER JOIN em_valoresmercado val ON art.referencia = val.referencia LEFT OUTER JOIN proveedores prov ON prov.codproveedor = val.codproveedor WHERE art.em_controlvalmercado order by art.referencia, val.em_fechavalmercado"]);


	vistas.push(["v_reservalotetej","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is not null and op.estado IN ('PTE','EN CURSO') AND NOT op.em_confirmada"]);

	vistas.push(["v_reservaloteall","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where op.estado IN ('PTE','EN CURSO') AND NOT op.em_confirmada"]);

	vistas.push(["v_reservalotenotej","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,ac.componormal as componormal,mt.referencia as refcompo, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripcioncompo, mt.cantidad*(-1) as cantidadcompo,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstockcompo from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is null and op.estado IN ('PTE','EN CURSO') AND NOT op.em_confirmada"]);

	vistas.push(["v_reservalotetejconf","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is not null and op.estado IN ('PTE','EN CURSO') AND op.em_confirmada"]);

	vistas.push(["v_reservaloteallconf","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where op.estado IN ('PTE','EN CURSO') AND op.em_confirmada"]);

	vistas.push(["v_reservalotenotejconf","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,ac.componormal as componormal,mt.referencia as refcompo, (at.descripcion||' '||at.codtamanoem||' '||at.codcolorem) as descripcioncompo, mt.cantidad*(-1) as cantidadcompo,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstockcompo from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is null and op.estado IN ('PTE','EN CURSO') AND op.em_confirmada"]);

	vistas.push(["v_reservalotetejcola","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is not null and ((op.estado IN ('PTE','EN CURSO')) OR (op.codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE'))) AND op.em_confirmada  AND em_codmaquinacol IS NOT NULL"]);

	vistas.push(["v_reservaloteallcola","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where ((op.estado IN ('PTE','EN CURSO')) OR (op.codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE'))) AND op.em_confirmada  AND em_codmaquinacol IS NOT NULL"]);

	vistas.push(["v_reservalotetejcolab","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is not null and op.estado IN ('PTE','EN CURSO') AND op.em_confirmada  AND em_codmaquinacol IS NOT NULL"]);

	vistas.push(["v_reservaloteallcolab","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,COALESCE(ac.componormal,ac.componente) as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||COALESCE(at.codtamanoem,'')||' '||COALESCE(at.codcolorem,'')) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where op.estado IN ('PTE','EN CURSO') AND op.em_confirmada  AND em_codmaquinacol IS NOT NULL"]);

	vistas.push(["v_stocksart","SELECT s.idstock as idstock, s.codalmacen as codalmacen, s.referencia as referencia, (art.descripcion||' '||COALESCE(art.codtamanoem,'')||' '||COALESCE(art.codcolorem,'')) as descripciontejido, s.cantidad as cantidad, s.reservada as reservada, s.disponible as disponible, s.pterecibir as pterecibir, s.disponiblepterecibir as disponiblepterecibir, s.afaltas as afaltas FROM stocks s inner join articulos art on s.referencia = art.referencia WHERE 1=1 "]);
	
	vistas.push(["v_ordenesptes","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,ac.componormal as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||at.codtamanoem||' '||at.codcolorem) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is not null and op.estado IN ('PTE','EN CURSO') AND NOT op.em_confirmada"]);


	//vistas.push(["v_piezasrollbob","SELECT  tr.codbobinapiezaroll AS codbobinapiezaroll,lt.codordenproduccion,op.emobservaciones AS observacionesop,rel.codlote AS codlote,lt.referencia as prenda,lt.articulo as descprenda, case when rep.idlineaest is null then lt.canprogramada else rlp.cantidad end as cantprendapro,case when lt.horacorte is null then 0 else lt.canlote end as cantprendacort, lt.cantotal as cantprendafab,loe.codordenest AS codordenest,b.codbobina AS codbobina, b.estado AS estadobobina,tr.idtramo AS idtramo,ltpz.cantotal AS cantotallote,ltpz.candisponible AS candisponiblelote,tr.codpartida AS codpartida,tr.codbobinaroll AS codbobinaroll,tr.codbobinaest,loe.referencia as reftejido,loe.tejido AS desctejido,loe.cantidad as cantidad,loe.canestampada,loe.canencurso,loe.estado as estadooe,rep.idlineapc AS idlineapc,pd.codigo AS codpedido, pd.codcliente AS codcliente,pd.nombrecliente AS nombrecliente,pd.docexterno AS docexterno,pd.fechasalida as fechacliente,pd.fechaservicio AS fechaservicio from em_tramostejido tr left join em_bobinas b on b.codbobina=tr.codbobina left join em_reservasestpedido rep on rep.idlineaest=tr.idlineaest left join em_reservaslotepedido rlp on rlp.idlineapc=rep.idlineapc left join em_reservasestlote rel on tr.idlineaest=rel.idlineaest AND rlp.codlote=rel.codlote left join lotesstock lt on lt.codlote=rel.codlote left join em_lineasordenest loe on loe.idlinea=tr.idlineaest left join lotesstock ltpz on ltpz.codlote=tr.codpartida left join pr_ordenesproduccion op on op.codorden=lt.codordenproduccion left join lineaspedidoscli lp on lp.idlinea=rep.idlineapc left join pedidoscli pd on pd.idpedido=lp.idpedido where tr.espieza and tr.cantotal>0  group by lt.codordenproduccion,op.emobservaciones,rel.codlote,lt.referencia,lt.articulo, case when rep.idlineaest is null then lt.canprogramada else rlp.cantidad end,case when lt.horacorte is null then 0 else lt.canlote end,lt.cantotal, loe.codordenest, b.codbobina, b.estado, tr.idtramo, ltpz.cantotal,ltpz.candisponible,tr.codpartida, tr.codbobinaroll,tr.codbobinaest,loe.referencia,loe.tejido, loe.cantidad,loe.canestampada,loe.canencurso,loe.estado,rep.idlineapc, pd.codigo, pd.codcliente,pd.nombrecliente,pd.docexterno, pd.fechasalida,pd.fechaservicio,tr.codbobinapiezaroll"]);

	vistas.push(["v_piezasrollbob","SELECT  tr.codbobinapiezaroll AS codbobinapiezaroll,lt.codordenproduccion,op.emobservaciones AS observacionesop,lt.codlote AS codlote,lt.referencia as prenda,lt.articulo as descprenda, case when rep.idlineaest is null then lt.canprogramada else rlp.cantidad end as cantprendapro,case when lt.horacorte is null then 0 else lt.canlote end as cantprendacort, lt.cantotal as cantprendafab,loe.codordenest AS codordenest,b.codbobina AS codbobina, b.estado AS estadobobina,tr.idtramo AS idtramo,ltpz.cantotal AS cantotallote,ltpz.candisponible AS candisponiblelote,tr.codpartida AS codpartida,tr.codbobinaroll AS codbobinaroll,tr.codbobinaest,loe.referencia as reftejido,loe.tejido AS desctejido,loe.cantidad as cantidad,loe.canestampada,loe.canencurso,loe.estado as estadooe,rep.idlineapc AS idlineapc,pd.codigo AS codpedido, pd.codcliente AS codcliente,pd.nombrecliente AS nombrecliente,pd.docexterno AS docexterno,pd.fechasalida as fechacliente,pd.fechaservicio AS fechaservicio from em_tramostejido tr LEFT JOIN em_bobinas b ON b.codbobina = tr.codbobina LEFT JOIN em_reservasestpedido rep ON rep.idlineaest = tr.idlineaest LEFT JOIN em_reservasestlote rel ON tr.idlineaest = rel.idlineaest LEFT JOIN lotesstock lt ON lt.codlote = rel.codlote LEFT JOIN em_reservaslotepedido rlp ON rlp.idlineapc = rep.idlineapc AND rlp.codlote = lt.codlote LEFT JOIN em_lineasordenest loe ON loe.idlinea = tr.idlineaest LEFT JOIN lotesstock ltpz ON ltpz.codlote = tr.codpartida LEFT JOIN pr_ordenesproduccion op ON op.codorden = lt.codordenproduccion LEFT JOIN lineaspedidoscli lp ON lp.idlinea = rep.idlineapc LEFT JOIN pedidoscli pd ON pd.idpedido = lp.idpedido where tr.espieza and tr.cantotal>0  group by lt.codordenproduccion,op.emobservaciones,lt.codlote,lt.referencia,lt.articulo, case when rep.idlineaest is null then lt.canprogramada else rlp.cantidad end,case when lt.horacorte is null then 0 else lt.canlote end,lt.cantotal, loe.codordenest, b.codbobina, b.estado, tr.idtramo, ltpz.cantotal,ltpz.candisponible,tr.codpartida, tr.codbobinaroll,tr.codbobinaest,loe.referencia,loe.tejido, loe.cantidad,loe.canestampada,loe.canencurso,loe.estado,rep.idlineapc, pd.codigo, pd.codcliente,pd.nombrecliente,pd.docexterno, pd.fechasalida,pd.fechaservicio,tr.codbobinapiezaroll"]);

	//vistas.push(["v_logcostesmargenes","SELECT idlog,gridasociado,idplantilla,codfamilia,codsubfamilia,codtamanoem, referencia, fechahis,horahis,usuariohis, em_fechacosteprod,em_horacosteprod,round(cast(em_costeprod as numeric),6) AS em_costeprod, em_idusuariocosteprod, em_observcosteprod, round(cast(em_margenprod as numeric),2) AS em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod, em_tipocoste,em_origencoste,em_tipomargen, em_origenmargen,em_actcostes,em_activarcostesher,em_actmargenes, em_activarmargenher FROM em_logcostesmargenes WHERE 1=1 "]);

	vistas.push(["v_logcostesmargenes","SELECT idlog,gridasociado,idplantilla,codfamilia,codsubfamilia,codtamanoem, referencia, fechahis,horahis,usuariohis, em_fechacosteprod,em_horacosteprod,em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_margenprod, em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod, em_tipocoste,em_origencoste,em_tipomargen, em_origenmargen,em_actcostes,em_activarcostesher,em_actmargenes, em_activarmargenher FROM em_logcostesmargenes WHERE 1=1 "]);

	//vistas.push(["v_articuloslog","SELECT referencia, descripcion, codtamanoem, codcolorem, codfamilia, codsubfamilia, round(cast(em_costeprod as numeric),2) AS em_costeprod, round(cast(em_margenprod as numeric),2) AS em_margenprod, idaltamasiva, codaltamasiva FROM articulos WHERE 1=1 "]);
	vistas.push(["v_articuloslog","SELECT referencia, descripcion, codtamanoem, codcolorem, codfamilia, codsubfamilia, em_costeprod, em_margenprod, idaltamasiva, codaltamasiva, em_origencoste, em_origenmargen FROM articulos WHERE 1=1 "]);

	vistas.push(["v_origencostemargen","SELECT art.referencia,art.descripcion,art.codfamilia,art.codsubfamilia,art.codtamanoem,art.codcolorem,art.codcoleccionem, c.codcoleccionplan codcoleccion_alternativa,art.em_tipocoste,art.em_tipomargen, CASE WHEN art.em_tipocoste='Manual' THEN 'articulo' WHEN art.em_tipocoste='Heredado' AND pc.em_costeprod IS NOT NULL THEN 'plantilla' WHEN art.em_tipocoste='Heredado' AND pca.em_costeprod IS NOT NULL THEN 'plantilla alternativa' WHEN art.em_tipocoste='Heredado' AND tsf.em_costeprod IS NOT NULL THEN 'tama�os por subfamilia' WHEN art.em_tipocoste='Heredado' AND sf.em_costeprod IS NOT NULL THEN 'subfamilia' ELSE NULL END AS origencoste, CASE WHEN art.em_tipocoste='Manual' THEN art.em_observcosteprod WHEN art.em_tipocoste='Heredado' AND pc.em_costeprod IS NOT NULL THEN pc.em_observcosteprod WHEN art.em_tipocoste='Heredado' AND pca.em_costeprod IS NOT NULL THEN pca.em_observcosteprod WHEN art.em_tipocoste='Heredado' AND tsf.em_costeprod IS NOT NULL THEN tsf.em_observcosteprod WHEN art.em_tipocoste='Heredado' AND sf.em_costeprod IS NOT NULL THEN sf.em_observcosteprod ELSE NULL END AS observcosteori, art.em_observcosteprod AS observcostearticulo, CASE WHEN art.em_tipocoste='Manual' THEN art.em_costeprod WHEN art.em_tipocoste='Heredado' AND pc.em_costeprod IS NOT NULL THEN pc.em_costeprod WHEN art.em_tipocoste='Heredado' AND pca.em_costeprod IS NOT NULL THEN pca.em_costeprod WHEN art.em_tipocoste='Heredado' AND tsf.em_costeprod IS NOT NULL THEN tsf.em_costeprod WHEN art.em_tipocoste='Heredado' AND sf.em_costeprod IS NOT NULL THEN sf.em_costeprod ELSE NULL END AS costeorigen, art.em_costeprod AS costearticulo, CASE WHEN art.em_tipomargen='Manual' THEN 'articulo' WHEN art.em_tipomargen='Heredado' AND pc.em_margenprod IS NOT NULL THEN 'plantilla' WHEN art.em_tipomargen='Heredado' AND pca.em_margenprod IS NOT NULL THEN 'plantilla alternativa' WHEN art.em_tipomargen='Heredado' AND tsf.em_margenprod IS NOT NULL THEN 'tama�os por subfamilia' WHEN art.em_tipomargen='Heredado' AND sf.em_margenprod IS NOT NULL THEN 'subfamilia' WHEN art.em_tipomargen='Heredado' AND f.em_margenprod IS NOT NULL THEN 'familia' ELSE NULL END AS origenmargen, CASE WHEN art.em_tipomargen='Manual' THEN art.em_observmargenprod WHEN art.em_tipomargen='Heredado' AND pc.em_margenprod IS NOT NULL THEN pc.em_observmargenprod WHEN art.em_tipomargen='Heredado' AND pca.em_margenprod IS NOT NULL THEN pca.em_observmargenprod WHEN art.em_tipomargen='Heredado' AND tsf.em_margenprod IS NOT NULL THEN tsf.em_observmargenprod WHEN art.em_tipomargen='Heredado' AND sf.em_margenprod IS NOT NULL THEN sf.em_observmargenprod WHEN art.em_tipomargen='Heredado' AND f.em_margenprod IS NOT NULL THEN f.em_observmargenprod ELSE NULL END AS observmargenori,  art.em_observmargenprod AS observmargenarticulo, CASE WHEN art.em_tipomargen='Manual' THEN art.em_margenprod WHEN art.em_tipomargen='Heredado' AND pc.em_margenprod IS NOT NULL THEN pc.em_margenprod WHEN art.em_tipomargen='Heredado' AND pca.em_margenprod IS NOT NULL THEN pca.em_margenprod WHEN art.em_tipomargen='Heredado' AND tsf.em_margenprod IS NOT NULL THEN tsf.em_margenprod WHEN art.em_tipomargen='Heredado' AND sf.em_margenprod IS NOT NULL THEN sf.em_margenprod WHEN art.em_tipomargen='Heredado' AND f.em_margenprod IS NOT NULL THEN f.em_margenprod ELSE NULL END AS margenorigen, art.em_margenprod AS margenarticulo FROM articulos art LEFT OUTER JOIN em_colecciones c ON art.codcoleccionem=c.codcoleccionem LEFT OUTER JOIN em_plantillasprod pc ON art.codsubfamilia=pc.codsubfamilia AND c.codcoleccionem=pc.codcoleccionem AND art.codtamanoem=pc.codtamanoem AND art.codcolorem=pc.codcolorem LEFT OUTER JOIN em_plantillasprod pca ON art.codsubfamilia=pca.codsubfamilia AND pca.codcoleccionem=c.codcoleccionplan AND art.codtamanoem=pca.codtamanoem AND art.codcolorem=pca.codcolorem LEFT OUTER JOIN subfamilias sf ON art.codsubfamilia=sf.codsubfamilia LEFT OUTER JOIN em_tamanossubfam tsf ON sf.codsubfamilia=tsf.codsubfamilia AND art.codtamanoem=tsf.codtamanoem LEFT OUTER JOIN familias f ON art.codfamilia=f.codfamilia WHERE 1=1"]);

	vistas.push(["v_origenherenciaman","SELECT art.referencia,art.descripcion,art.codfamilia,art.codsubfamilia,art.codtamanoem,art.codcolorem,art.codcoleccionem, c.codcoleccionplan codcoleccion_alternativa,art.em_tipocoste,art.em_tipomargen, CASE WHEN art.em_tipocoste='Manual' AND pc.em_costeprod IS NOT NULL THEN 'plantilla' WHEN art.em_tipocoste='Manual' AND pca.em_costeprod IS NOT NULL THEN 'plantilla alternativa' WHEN art.em_tipocoste='Manual' AND tsf.em_costeprod IS NOT NULL THEN 'tama�os por subfamilia' WHEN art.em_tipocoste='Manual' AND sf.em_costeprod IS NOT NULL THEN 'subfamilia' ELSE NULL END AS origencoste, CASE WHEN art.em_tipocoste='Manual' AND pc.em_costeprod IS NOT NULL THEN pc.em_observcosteprod WHEN art.em_tipocoste='Manual' AND pca.em_costeprod IS NOT NULL THEN pca.em_observcosteprod WHEN art.em_tipocoste='Manual' AND tsf.em_costeprod IS NOT NULL THEN tsf.em_observcosteprod WHEN art.em_tipocoste='Manual' AND sf.em_costeprod IS NOT NULL THEN sf.em_observcosteprod ELSE NULL END AS observcosteori, art.em_observcosteprod AS observcostearticulo, CASE WHEN art.em_tipocoste='Manual' AND pc.em_costeprod IS NOT NULL THEN pc.em_costeprod WHEN art.em_tipocoste='Manual' AND pca.em_costeprod IS NOT NULL THEN pca.em_costeprod WHEN art.em_tipocoste='Manual' AND tsf.em_costeprod IS NOT NULL THEN tsf.em_costeprod WHEN art.em_tipocoste='Manual' AND sf.em_costeprod IS NOT NULL THEN sf.em_costeprod ELSE NULL END AS costeorigen, art.em_costeprod AS costearticulo, CASE WHEN art.em_tipomargen='Manual' AND pc.em_margenprod IS NOT NULL THEN 'plantilla' WHEN art.em_tipomargen='Manual' AND pca.em_margenprod IS NOT NULL THEN 'plantilla alternativa' WHEN art.em_tipomargen='Manual' AND tsf.em_margenprod IS NOT NULL THEN 'tama�os por subfamilia' WHEN art.em_tipomargen='Manual' AND sf.em_margenprod IS NOT NULL THEN 'subfamilia' WHEN art.em_tipomargen='Manual' AND f.em_margenprod IS NOT NULL THEN 'familia' ELSE NULL END AS origenmargen, CASE WHEN art.em_tipomargen='Manual' AND pc.em_margenprod IS NOT NULL THEN pc.em_observmargenprod WHEN art.em_tipomargen='Manual' AND pca.em_margenprod IS NOT NULL THEN pca.em_observmargenprod WHEN art.em_tipomargen='Manual' AND tsf.em_margenprod IS NOT NULL THEN tsf.em_observmargenprod WHEN art.em_tipomargen='Manual' AND sf.em_margenprod IS NOT NULL THEN sf.em_observmargenprod WHEN art.em_tipomargen='Manual' AND f.em_margenprod IS NOT NULL THEN f.em_observmargenprod ELSE NULL END AS observmargenori,  art.em_observmargenprod AS observmargenarticulo, CASE WHEN art.em_tipomargen='Manual' AND pc.em_margenprod IS NOT NULL THEN pc.em_margenprod WHEN art.em_tipomargen='Manual' AND pca.em_margenprod IS NOT NULL THEN pca.em_margenprod WHEN art.em_tipomargen='Manual' AND tsf.em_margenprod IS NOT NULL THEN tsf.em_margenprod WHEN art.em_tipomargen='Manual' AND sf.em_margenprod IS NOT NULL THEN sf.em_margenprod WHEN art.em_tipomargen='Manual' AND f.em_margenprod IS NOT NULL THEN f.em_margenprod ELSE NULL END AS margenorigen, art.em_margenprod AS margenarticulo FROM articulos art LEFT OUTER JOIN em_colecciones c ON art.codcoleccionem=c.codcoleccionem LEFT OUTER JOIN em_plantillasprod pc ON art.codsubfamilia=pc.codsubfamilia AND c.codcoleccionem=pc.codcoleccionem AND art.codtamanoem=pc.codtamanoem AND art.codcolorem=pc.codcolorem LEFT OUTER JOIN em_plantillasprod pca ON art.codsubfamilia=pca.codsubfamilia AND pca.codcoleccionem=c.codcoleccionplan AND art.codtamanoem=pca.codtamanoem AND art.codcolorem=pca.codcolorem LEFT OUTER JOIN subfamilias sf ON art.codsubfamilia=sf.codsubfamilia LEFT OUTER JOIN em_tamanossubfam tsf ON sf.codsubfamilia=tsf.codsubfamilia AND art.codtamanoem=tsf.codtamanoem LEFT OUTER JOIN familias f ON art.codfamilia=f.codfamilia WHERE 1=1"]);

	vistas.push(["v_movistocklot","SELECT m.*, op.codcliente,COALESCE(op.nombrecliente,'') || CASE COALESCE(op.nombrecliente,'') WHEN '' THEN '' ELSE CASE COALESCE(cli.nombre,'') WHEN '' THEN '' ELSE ' - ' END END ||  COALESCE(cli.nombre,'')  AS nombrecliente, COALESCE(op.emobservaciones,'') AS emobservaciones FROM movistock m LEFT OUTER JOIN lotesstock l ON m.codloteprod = l.codlote LEFT OUTER JOIN pr_ordenesproduccion op ON op.codorden = l.codordenproduccion LEFT OUTER JOIN clientes cli ON cli.codcliente = op.codcliente WHERE 1=1"]);

	vistas.push(["v_lineasinventarios","(SELECT inventarios.codinventario,inventarios.codalmacen,inventarios.fecha,inventarios.hora,inventarios.observaciones,inventarios.fechaalta,inventarios.horaalta,inventarios.idusuarioalta,inventarios.idusuariomod,inventarios.fechamod,inventarios.horamod,lineasregstocks.referencia, lineasregstocks.desarticulo,lineasregstocks.cantidadini,lineasregstocks.cantidadfin,lineasregstocks.motivo,'' as codlote,articulos.codtamanoem,articulos.codcolorem,em_disenos.codseriediseno, almacenes.nombre, lineasregstocks.fechamod as fechamodlin, lineasregstocks.horamod as horamodlin, lineasregstocks.fecha as fechamov, lineasregstocks.hora as horamov FROM inventarios INNER JOIN lineasregstocks on inventarios.codinventario = lineasregstocks.codinventario INNER JOIN articulos on lineasregstocks.referencia = articulos.referencia LEFT OUTER JOIN em_dibujos ON articulos.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno INNER JOIN almacenes ON inventarios.codalmacen = almacenes.codalmacen WHERE 1=1) UNION (SELECT inventarios.codinventario,inventarios.codalmacen,inventarios.fecha,inventarios.hora,inventarios.observaciones,inventarios.fechaalta,inventarios.horaalta,inventarios.idusuarioalta,inventarios.idusuariomod,inventarios.fechamod,inventarios.horamod,articulos.referencia,articulos.descripcion,reglotestock.actual,reglotestock.nueva,reglotestock.motivo,reglotestock.codlote,articulos.codtamanoem,articulos.codcolorem,em_disenos.codseriediseno, almacenes.nombre, reglotestock.fechamod as fechamodlin, reglotestock.horamod as horamodlin, reglotestock.fecha as fechamov, reglotestock.hora as horamov FROM inventarios INNER JOIN reglotestock on inventarios.codinventario = reglotestock.codinventario INNER JOIN lotesstock on reglotestock.codlote = lotesstock.codlote INNER JOIN articulos on lotesstock.referencia = articulos.referencia LEFT OUTER JOIN em_dibujos ON articulos.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno INNER JOIN almacenes ON inventarios.codalmacen = almacenes.codalmacen WHERE 1=1)"]);

	vistas.push(["v_lineasinventariosid","SELECT ROW_NUMBER() OVER (ORDER BY fechamov,horamov,fechamodlin,horamodlin) as idlin,* FROM v_lineasinventarios WHERE 1=1"]);

	vistas.push(["v_albaranescdb","select a.idalbaran,p.codigo as codpedido,p.em_coddropshipping,ds.pedidoprivalia,p.servido,p.emcatservicio, (SELECT 100*(SUM(lineaspedidoscli.totalenalbaran)/SUM(lineaspedidoscli.cantidad)) FROM lineaspedidoscli where lineaspedidoscli.idpedido = p.idpedido) as porcserv,a.codigo as codalbaran ,a.nombrecliente,a.docexterno,a.descripciondir,MAX(ds.tracking) as tracking,a.codpostal,a.ciudad,a.codagencia,a.bultos,a.desbultos,a.volumen,a.observaciones,a.obstransporte,a.ptefactura,a.fecha,a.cifnif,a.total,a.codcliente,a.coddivisa,a.numero,a.codserie,a.neto,a.porcomision,a.totaleuros,a.totaliva,a.irpf,a.totalirpf,a.totalrecargo,a.codpago,a.em_codpago,a.codagente,a.codalmacen,a.codalmadeposito,a.tipodeposito,a.coddir,a.direccion,a.provincia,a.apartado,a.codpais,a.codejercicio,a.tasaconv,a.recfinanciero,a.netosindtoesp,a.pordtoesp,a.dtoesp,a.idintrastat,a.codprovincia,a.codcondicionentrega,a.codnaturaleza,a.codmodotransporte,a.codpuerto,a.codregimen,a.nointrastat,a.hora,a.pesobruto,a.pesoneto,a.palets,a.em_codtipoemb,a.valorado,a.departamento,a.codclientefac,a.idalbarancomp,a.codliquidacion,a.incoterm,a.pobincoterm,a.fechavalor,a.tipoportes,a.codgrupoivaneg,a.ediactivo,a.fechatrasedi,a.estadogit,a.codigogit,a.codtipoembalajepaleedi,a.deabono,a.bultosreparto,a.pesobrutoreparto,a.volumenreparto,a.idusuarioalta,a.fechaalta,a.horaalta,a.idusuariomod,a.fechamod,a.em_idimpnoctalia,a.em_idalbaranabono,a.em_codigoabono,a.emcodenviodrop,a.horamod,a.em_autorizadocostes,a.em_estadocostes,a.em_politicacostes,a.em_motivocostes,a.em_globalneto,a.em_globalcostes,a.em_globalmargenes,a.em_netovscostes,a.em_netovsmargenes,a.em_idpedalbcdb, p.idpedido from pedidoscli p INNER JOIN lineaspedidoscli lp ON lp.idpedido = p.idpedido INNER JOIN lineasalbaranescli la ON la.idlineapedido = lp.idlinea INNER JOIN albaranescli a ON a.idalbaran=la.idalbaran LEFT OUTER JOIN em_cargadropshipping ds ON ds.idpedido = p.idpedido where a.em_idpedalbcdb is not null GROUP BY a.idalbaran,p.codigo,p.em_coddropshipping,ds.pedidoprivalia,p.servido,p.emcatservicio,a.codigo,a.nombrecliente,a.docexterno,a.codpostal,a.ciudad,a.codagencia,a.bultos,a.desbultos,a.volumen,a.observaciones,a.obstransporte,a.ptefactura,a.fecha,a.cifnif,a.total,a.codcliente,a.coddivisa,a.numero,a.codserie,a.neto,a.porcomision,a.totaleuros,a.totaliva,a.irpf,a.totalirpf,a.totalrecargo,a.codpago,a.em_codpago,a.codagente,a.codalmacen,a.codalmadeposito,a.tipodeposito,a.coddir,a.descripciondir,a.direccion,a.provincia,a.apartado,a.codpais,a.codejercicio,a.tasaconv,a.recfinanciero,a.netosindtoesp,a.pordtoesp,a.dtoesp,a.idintrastat,a.codprovincia,a.codcondicionentrega,a.codnaturaleza,a.codmodotransporte,a.codpuerto,a.codregimen,a.nointrastat,a.hora,a.pesobruto,a.pesoneto,a.palets,a.em_codtipoemb,a.valorado,a.departamento,a.codclientefac,a.idalbarancomp,a.codliquidacion,a.incoterm,a.pobincoterm,a.fechavalor,a.tipoportes,a.codgrupoivaneg,a.ediactivo,a.fechatrasedi,a.estadogit,a.codigogit,a.codtipoembalajepaleedi,a.deabono,a.emcatservicio,a.bultosreparto,a.pesobrutoreparto,a.volumenreparto,a.idusuarioalta,a.fechaalta,a.horaalta,a.idusuariomod,a.fechamod,a.em_idimpnoctalia,a.em_idalbaranabono,a.em_codigoabono,a.emcodenviodrop,a.horamod,a.em_autorizadocostes,a.em_estadocostes,a.em_politicacostes,a.em_motivocostes,a.em_globalneto,a.em_globalcostes,a.em_globalmargenes,a.em_netovscostes,a.em_netovsmargenes,a.em_idpedalbcdb, p.idpedido"]);

	vistas.push(["v_articulosxubicacion","SELECT a.id,a.referencia,a.em_ubialternativa,u.em_ubinave,u.em_ubipasillo,u.em_ubiestante,u.em_ubialtura,a.actual FROM em_articulosxubicacion a INNER JOIN em_ubicaciones u ON a.em_ubialternativa = u.em_codubicacion WHERE 1=1"]);

	vistas.push(["v_lotesxubicacion","SELECT l.id,l.codlote,l.em_ubialternativa,u.em_ubinave,u.em_ubipasillo,u.em_ubiestante,u.em_ubialtura,l.actual FROM em_lotesxubicacion l INNER JOIN em_ubicaciones u ON l.em_ubialternativa = u.em_codubicacion WHERE 1=1"]);

	vistas.push(["v_oppiezasroll","SELECT distinct lt.codordenproduccion,bob.codbobina,bob.estado FROM em_tramostejido t INNER JOIN em_reservasestlote rel ON t.idlineaest = rel.idlineaest INNER JOIN lotesstock lt ON lt.codlote = rel.codlote INNER JOIN em_bobinas bob ON t.codbobinapiezaroll = bob.codbobina"]);

	vistas.push(["v_ordenesprod_alag","SELECT pr_ordenesproduccion.codorden,pr_ordenesproduccion.fecha,pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.dibujo,pr_ordenesproduccion.nombrecliente,subfamilias.descripcion as subfamdesc,articulos.referencia,articulos.codbarras,articulos.descripcion as articulodesc,em_tamanos.descripcion as tamano,em_colores.descripcion as color,em_colores.codigogit,SUM(movistock.cantidad*-1) as cantidad,array_to_string(array_agg(distinct articuloscomp.orden),',') as orden,array_to_string(array_agg(distinct articuloscomp.idseccion),',') as idseccion,array_to_string(array_agg(distinct pr_ordenesproduccion.emobservaciones),',') as observaciones,array_to_string(array_agg(distinct articuloscomp.componente),',') as componente,array_to_string(array_agg(distinct articuloscomp.componormal),',') as componormal,array_to_string(array_agg(distinct em_disenos.codseriediseno),',') as codseriediseno, pr_ordenesproduccion.codpedidocli,array_to_string(array_agg(distinct articuloscomp.ancho),',') as ancho FROM pr_ordenesproduccion INNER JOIN pr_procesos ON (pr_procesos.tipoobjeto='pr_ordenesproduccion' AND pr_ordenesproduccion.codorden = pr_procesos.idobjeto) INNER JOIN lotesstock ON pr_ordenesproduccion.codorden = lotesstock.codordenproduccion LEFT OUTER JOIN movistock ON lotesstock.codlote = movistock.codloteprod LEFT OUTER JOIN articuloscomp ON (movistock.idarticulocomp = articuloscomp.id) LEFT OUTER JOIN articulos ON (movistock.referencia = articulos.referencia) LEFT OUTER JOIN em_tamanos ON (articulos.codtamanoem = em_tamanos.codtamanoem) LEFT OUTER JOIN em_colores ON (articulos.codcolorem = em_colores.codcolorem) LEFT OUTER JOIN em_dibujos ON articulos.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno LEFT OUTER JOIN subfamilias ON articulos.codsubfamilia= subfamilias.codsubfamilia WHERE (articuloscomp.idseccion = '9' OR articuloscomp.id IS NULL)  GROUP BY subfamilias.descripcion,pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, articulos.referencia, articulos.codbarras, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion,em_colores.codigogit, articulos.referencia, pr_ordenesproduccion.codpedidocli ORDER BY pr_ordenesproduccion.codorden,subfamilias.descripcion,articulos.descripcion, articulos.referencia"]);

	vistas.push(["v_albaranescliest","select cab.codalmacen,cab.codagente,cab.codserie,cab.tipodeposito,cab.codejercicio,cab.idalbaran,cab.fecha,cab.codigo,cab.codcliente,lin.referencia,lin.dtopor,lin.pvpunitario,lin.pvptotal,(lin.pvptotal * (100 - cab.pordtoesp) / 100),lin.cantidad,(round(cast((lin.pvptotal * (100 - cab.pordtoesp) / 100) as numeric),2)) as totallinea, (round(cast((lin.pvpsindto*lin.dtopor/100)*-1 as numeric),2)) as dtolin from albaranescli cab inner join lineasalbaranescli lin on cab.idalbaran = lin.idalbaran"]);

	vistas.push(["v_facturascliest","select cab.codalmacen,cab.codagente, cab.codserie, cab.codejercicio,cab.idfactura, cab.fecha,cab.codigo,cab.codcliente, lin.referencia,lin.dtopor, lin.pvpunitario,lin.pvptotal,(lin.pvptotal * (100 - cab.pordtoesp) / 100),lin.cantidad,(round(cast((lin.pvptotal * (100 - cab.pordtoesp) / 100) as numeric),2)) as totallinea, (round(cast((lin.pvpsindto*lin.dtopor/100)*-1 as numeric),2)) as dtolin from facturascli cab inner join lineasfacturascli lin on cab.idfactura = lin.idfactura"]);

	return vistas;
}
/*
function euromoda_creaVistas(oParam)
{
	var _i = this.iface;
	
	var vistas = [];
	
	
	vistas.push(["v_registroest", "SELECT em_tramostejido.idtramo, em_lineasordenest.codordenest, em_turnosusuario.codmaquinaest, em_tramostejido.referencia, em_tramostejido.articulo, em_tramostejido.cantotal,em_tramostejido.consumo, em_tramostejido.codpartida, em_tramostejido.codpartidappe, lotppe.referencia as refppe, em_tramostejido.codbobinappe, em_tramostejido.soporteppe, em_tramostejido.codbobinaest, em_tramostejido.soporteest, pr_trabajadores.idtrabajador AS operarioest, pr_trabajadores.nombre AS nombreest, em_tramostejido.fecha AS fechaest, em_tramostejido.horadesde AS horadesdeest, em_tramostejido.horahasta AS horahastaest, em_tramostejido.codbobinavap, em_tramostejido.soportevap, em_tramostejido.fechavap, em_tramostejido.horadesdevap, em_tramostejido.codbobinaaca, em_tramostejido.soporteaca, em_tramostejido.codbobinaprl, em_tramostejido.soporteprl, turnoroll.codmaquinaroll, trabroll.idtrabajador AS operarioroll, trabroll.nombre AS nombreroll, em_tramostejido.fecharoll, em_tramostejido.horadesderoll, em_tramostejido.horahastaroll, em_tramostejido.codbobinaroll, em_tramostejido.soporteroll, em_tramostejido.saldo, em_tiposinciest.codigo AS codinciest, em_tiposinciest.descripcion AS desctipoinciest, em_tramostejido.codincisaldo, em_incidensaldos.descripcion AS descsaldo, lotesstock.codalmacen, em_tramostejido.canusada, em_tramostejido.candisponible, em_tramostejido.merma, em_tramostejido.canmerma, em_tramostejido.cancelado, em_tramostejido.cancancelada, em_tramostejido.contadorini, em_tramostejido.contadorfin FROM ((((((((em_tramostejido JOIN em_lineasordenest ON ((em_tramostejido.idlineaest = em_lineasordenest.idlinea))) LEFT JOIN em_turnosusuario ON ((em_tramostejido.idturnousuario = em_turnosusuario.id))) LEFT JOIN pr_trabajadores ON (((em_turnosusuario.idtrabajador)::text = (pr_trabajadores.idtrabajador)::text))) LEFT JOIN em_turnosusuario turnoroll ON ((em_tramostejido.idturnousuarioroll = turnoroll.id))) LEFT JOIN pr_trabajadores trabroll ON (((turnoroll.idtrabajador)::text = (trabroll.idtrabajador)::text))) LEFT JOIN lotesstock ON (((lotesstock.codlote)::text = (em_tramostejido.codpartida)::text))) LEFT JOIN em_incidensaldos ON (((em_tramostejido.codincisaldo)::text = (em_incidensaldos.codigo)::text))) LEFT JOIN em_tiposinciest ON (((em_tiposinciest.codigo)::text = (em_tramostejido.codmotivoinci)::text)) LEFT OUTER JOIN lotesstock lotppe ON em_tramostejido.codpartidappe = lotppe.codlote );"]);
	
	vistas.push(["v_stocksext", "SELECT stocks.idstock, stocks.codalmacen, stocks.nombre, stocks.articulo, stocks.referencia, stocks.cantidad, stocks.disponible, stocks.reservada, stocks.reservadapterecibir, stocks.disponiblepterecibir, stocks.reservadaprod, stocks.afaltas, stocks.pterecibir, stocks.necesidad, stocks.fechaultreg, stocks.horaultreg, stocks.cantidadultreg, stocks.stockmin, stocks.stockmax, stocks.prevision, stocks.ubicacion, stocks.codtamanoem, stocks.emcolorgit, stocks.codcolorem, stocks.coddibestamp, stocks.emdibujo, stocks.idsincro, stocks.fechaultmov, stocks.horaultmov, stocks.codbarras, articulos.codfamilia, familias.descripcion AS descfam, articulos.codsubfamilia, subfamilias.descripcion AS descsubfam, articulos.codcoleccionem, em_colecciones.descripcion AS desccol, articulos.debaja, articulos.fechaliq, articulos.descatalogado, articulos.aliasart, almacenes.em_tipoalmacen, almacenes.em_relalmacen, almacenes.em_actalmacen, almacenes.em_deposito, almacenes.em_tipodeposito, almacenes.em_duaalmacen, almacenes.em_grupoalmacen, almacenes.em_tmercaalmacen, almacenes.em_caractalmacen, almacenes.em_grupoinvent, stocks.em_fechaultventaalm, stocks.em_fechaultcompraalm, articulos.em_fechaultventa, articulos.em_fechaultcompra  FROM (((((stocks LEFT JOIN articulos ON (((stocks.referencia)::text = (articulos.referencia)::text))) LEFT JOIN familias ON (((articulos.codfamilia)::text = (familias.codfamilia)::text))) LEFT JOIN subfamilias ON (((articulos.codsubfamilia)::text = (subfamilias.codsubfamilia)::text))) LEFT JOIN em_colecciones ON (((articulos.codcoleccionem)::text = (em_colecciones.codcoleccionem)::text))) LEFT JOIN almacenes ON (((stocks.codalmacen)::text = (almacenes.codalmacen)::text)))"]);
	
	vistas.push(["v_cola_acabados", "SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text  WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_acabados_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.pedidoacabador, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, b.codpedidoprov, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p  WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_rollado","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_rollado_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.pedidoacabador, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_vaporizador","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision  GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_cola_vaporizador_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.pedidoacabador, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM ( SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, ''::character varying(20) AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_colas","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar   FROM ( ( ( SELECT '1. COLA DE ESTAMPACION'::character varying(50) AS cola, oes.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, ''::character varying(10) AS bobina_estamp, ''::character varying(10) AS bobina_cola, ''::character varying(10) AS soporte, ''::character varying(10) AS ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(ln.canpendiente)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar  FROM em_lineasordenest ln            LEFT JOIN em_ordenesestampacion oes ON oes.codordenest::text = ln.codordenest::text WHERE ln.canpendiente > 0::double precision  GROUP BY oes.codordenest, oes.estado, oes.codmaquinaest, oes.fecha, oes.fechaentrega, oes.descripcion, oes.canaestampar, oes.canpendiente  UNION  SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr                         LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision  GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p  WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_colas_fr","SELECT p.cola, p.oe, p.estado, p.maquina, p.bobina_estamp, p.bobina_cola, p.soporte, p.pedidoacabador, p.ubicacion, p.descripcion, p.cursada, p.fechaentrega, p.mtrs_cola, p.total_mtrs_oe, p.pdte_estampar FROM (((SELECT '1. COLA DE ESTAMPACION'::character varying(50) AS cola, oes.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, ''::character varying(10) AS bobina_estamp, ''::character varying(10) AS bobina_cola, ''::character varying(10) AS soporte, ''::character varying(20) AS pedidoacabador, ''::character varying(10) AS ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(ln.canpendiente)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar   FROM em_lineasordenest ln LEFT JOIN em_ordenesestampacion oes ON oes.codordenest::text = ln.codordenest::text  WHERE ln.canpendiente > 0::double precision GROUP BY oes.codordenest, oes.estado, oes.codmaquinaest, oes.fecha, oes.fechaentrega, oes.descripcion, oes.canaestampar, oes.canpendiente UNION SELECT '2.Cola Vaporizador'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaest AS bobina_cola, b.soporteactual::character varying(20) AS soporte, '' AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar  FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaest::text = b.codbobina::text WHERE vr.codbobinavap IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '3.Cola Acabados'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaaca AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar         FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaaca::text = b.codbobina::text WHERE vr.codbobinavap IS NOT NULL AND vr.codbobinaprl IS NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaaca, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) UNION SELECT '4.Cola Rollado'::character varying(50) AS cola, vr.codordenest AS oe, oes.estado, oes.codmaquinaest AS maquina, vr.codbobinaest AS bobina_estamp, vr.codbobinaprl AS bobina_cola, b.soporteactual::character varying(20) AS soporte, b.codpedidoprov AS pedidoacabador, b.ubicacion, oes.descripcion, oes.fecha AS cursada, oes.fechaentrega, round(sum(vr.candisponible)::numeric, 2) AS mtrs_cola, round(oes.canaestampar::numeric, 2) AS total_mtrs_oe, round(oes.canpendiente::numeric, 2) AS pdte_estampar FROM v_registroest vr LEFT JOIN em_ordenesestampacion oes ON vr.codordenest::text = oes.codordenest::text LEFT JOIN em_bobinas b ON vr.codbobinaprl::text = b.codbobina::text        WHERE vr.codbobinaprl IS NOT NULL AND vr.operarioroll IS NULL AND vr.candisponible > 0::double precision GROUP BY vr.codordenest, oes.estado, oes.codmaquinaest, vr.codbobinaest, vr.codbobinaprl, oes.fecha, oes.fechaentrega, b.soporteactual::character varying(20), b.codpedidoprov, b.ubicacion, oes.descripcion, oes.canaestampar, oes.canpendiente) p WHERE p.estado::text !~~ 'TERMINADA'::text ORDER BY p.fechaentrega, p.oe, p.cursada, p.bobina_estamp, p.bobina_cola"]);
	
	vistas.push(["v_estampacion_por_digital","SELECT          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END   ORDER BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END DESC"]);
	
	vistas.push(["v_estampacion_por_oe_dias","SELECT reg.codordenest AS orden_estamp,          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY reg.codordenest,  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END   ORDER BY reg.codordenest DESC,  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END"]);
	
	vistas.push(["v_estampacion_por_operario","SELECT          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, reg.nombreest AS operario, tu.codturno AS turno, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea    LEFT JOIN em_turnosusuario tu ON tt.idturnousuario = tu.id    LEFT JOIN em_turnos tn ON tn.codturno::text = tu.codturno::text   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END, tn.horadesde, tu.codturno, reg.nombreest   ORDER BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END DESC, tn.horadesde, tu.codturno, reg.nombreest"]);
	
	vistas.push(["v_estampacion_por_orden","SELECT          CASE             WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest             ELSE reg.fechaest - 1         END AS dia_turnos6_6, reg.codordenest AS orden_estamp, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg01_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg02_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS dg03_mts, round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL01'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL02'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) + round(sum(         CASE             WHEN reg.codmaquinaest::text = 'DIGITAL03'::text THEN reg.cantotal             ELSE 0::double precision         END)::numeric, 2) AS total_dgs    FROM v_registroest reg    JOIN em_tramostejido tt ON reg.idtramo = tt.idtramo    JOIN em_lineasordenest lo ON tt.idlineaest = lo.idlinea   WHERE tt.codpartida::text ~~ 'TT%'::text   GROUP BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END, reg.codordenest   ORDER BY  CASE     WHEN reg.horadesdeest > '05:59:59'::time without time zone THEN reg.fechaest     ELSE reg.fechaest - 1 END DESC, reg.codordenest"]);
	
	vistas.push(["v_lotesstock","select lotesstock.*, articulos.codfamilia, familias.descripcion as descfamilia, articulos.codsubfamilia, subfamilias.descripcion as descsubfamilia,articulos.codcoleccionem, em_colecciones.descripcion as descoleccion,articulos.coddibestamp,em_dibujos.descripcion as emdibujo from lotesstock left outer join articulos on lotesstock.referencia = articulos.referencia left outer join familias on articulos.codfamilia = familias.codfamilia left outer join subfamilias on articulos.codsubfamilia = subfamilias.codsubfamilia left outer join em_colecciones on articulos.codcoleccionem = em_colecciones.codcoleccionem left outer join em_dibujos on articulos.coddibestamp = em_dibujos.coddibujoem"]);	
	
	vistas.push(["v_coordinados","SELECT DISTINCT art.coddibestamp,art.emdibujo,art.codcolorem as colordib, art2.coddibestamp as dibcoord, dib2.descripcion as descdibcoord, FT.codcolorem as colorcoord, ft.componormal as componente, art.codcoleccionem as coleccion, col.descripcion, art.codfamilia as famcod, f.descripcion as famdesc, art.codsubfamilia as subfamcod, sf.descripcion as subfamdesc,art.codtamanoem as tamano, dib.coddiseno FROM articulos art INNER JOIN articuloscomp ft ON ft.refcompuesto = art.referencia INNER JOIN articulos art2 ON art2.referencia = ft.refcomponente AND (art2.coddibestamp IS NOT NULL) AND ART2.CODDIBESTAMP <> ART.CODDIBESTAMP INNER JOIN subfamilias sf ON sf.codsubfamilia = art.codsubfamilia INNER JOIN familias f ON f.codfamilia = art.codfamilia left outer join em_colecciones col on art.codcoleccionem=col.codcoleccionem LEFT OUTER JOIN em_dibujos dib on dib.coddibujoem = art.coddibestamp LEFT OUTER JOIN em_dibujos dib2 ON dib2.coddibujoem = art2.coddibestamp WHERE 1=1 ORDER BY art.coddibestamp, art.codcolorem, art2.coddibestamp, dib2.descripcion, FT.codcolorem, ft.componormal, art2.coddibestamp, FT.codcolorem, art.codcoleccionem, art.codfamilia, art.codsubfamilia"]);
	
	vistas.push(["v_movistockart","SELECT m.*, art.descripcion as descripcionart, art.codtamanoem as codtamanoemart, art.codcolorem as codcoloremart FROM movistock m inner join articulos art on m.referencia = art.referencia WHERE 1=1 "]);
	
	vistas.push(["v_valoresmercado","SELECT val.id,art.referencia, art.descripcion, art.codtamanoem, art.emcolorgit,art.codcolorem,art.emdibujo,art.codbarras, art.codfamilia, fam.descripcion as descfam, art.codsubfamilia, subfam.descripcion as descsubfam, val.em_fechavalmercado, val.em_valmercado, val.em_coddivisamercado, val.em_unidmercado,val.em_valmercadoeur,val.em_tasaconvmercado, val.em_cantidad, val.em_tipomercado, val.em_nombremercado, val.codproveedor, prov.nombre as nombreprov, val.em_observaciones, val.idusuarioalta, val.fechaalta, val.horaalta, val.idusuariomod, val.fechamod, val.horamod FROM articulos art INNER JOIN familias fam ON art.codfamilia = fam.codfamilia INNER JOIN subfamilias subfam ON art.codsubfamilia = subfam.codsubfamilia INNER JOIN em_valoresmercado val ON art.referencia = val.referencia LEFT OUTER JOIN proveedores prov ON prov.codproveedor = val.codproveedor WHERE art.em_controlvalmercado order by art.referencia, val.em_fechavalmercado"]);


	vistas.push(["v_reservalotetej","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,ac.componormal as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||at.codtamanoem||' '||at.codcolorem) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is not null and op.estado IN ('PTE','EN CURSO') AND NOT op.em_confirmada"]);

	vistas.push(["v_stocksart","SELECT s.idstock as idstock, s.codalmacen as codalmacen, s.referencia as referencia, (art.descripcion||' '||art.codtamanoem||' '||art.codcolorem) as descripciontejido, s.cantidad as cantidad, s.reservada as reservada, s.disponible as disponible, s.pterecibir as pterecibir, s.disponiblepterecibir as disponiblepterecibir, s.afaltas as afaltas FROM stocks s inner join articulos art on s.referencia = art.referencia WHERE 1=1 "]);
	
	vistas.push(["v_ordenesptes","SELECT l.codordenproduccion as codorden,l.codlote as codlote, m.referencia as referencia, m.cantidad as cantidad,(a.descripcion||' '||a.codtamanoem||' '||a.codcolorem) as descripcion,ac.componormal as tipotejido,mt.referencia as reftejido, (at.descripcion||' '||at.codtamanoem||' '||at.codcolorem) as descripciontejido, mt.cantidad*(-1) as cantidadtejido,mt.reservaex as reservaex,mt.reservapr as reservapr, mt.reservaaf as reservaaf, mt.idmovimiento as idmovimiento, mt.idstock as idstocktej from movistock m inner join lotesstock l on m.codlote=l.codlote inner join movistock mt on mt.codloteprod = l.codlote inner join articulos a on m.referencia=a.referencia left outer join articuloscomp ac on ac.id=mt.idarticulocomp inner join articulos at on at.referencia=mt.referencia inner join pr_ordenesproduccion op on op.codorden = l.codordenproduccion where mt.codsubfamiliatp is not null and op.estado IN ('PTE','EN CURSO') AND NOT op.em_confirmada"]);




	vistas.push(["v_piezasrollbob","SELECT  tr.codbobinapiezaroll AS codbobinapiezaroll,lt.codordenproduccion,op.emobservaciones AS observacionesop,lt.codlote AS codlote,lt.referencia as prenda,lt.articulo as descprenda, case when rep.idlineaest is null then lt.canprogramada else rlp.cantidad end as cantprendapro,case when lt.horacorte is null then 0 else lt.canlote end as cantprendacort, lt.cantotal as cantprendafab,loe.codordenest AS codordenest,b.codbobina AS codbobina, b.estado AS estadobobina,tr.idtramo AS idtramo,ltpz.cantotal AS cantotallote,ltpz.candisponible AS candisponiblelote,tr.codpartida AS codpartida,tr.codbobinaroll AS codbobinaroll,tr.codbobinaest,loe.referencia as reftejido,loe.tejido AS desctejido,loe.cantidad as cantidad,loe.canestampada,loe.canencurso,loe.estado as estadooe,rep.idlineapc AS idlineapc,pd.codigo AS codpedido, pd.codcliente AS codcliente,pd.nombrecliente AS nombrecliente,pd.docexterno AS docexterno,pd.fechasalida as fechacliente,pd.fechaservicio AS fechaservicio from em_tramostejido tr LEFT JOIN em_bobinas b ON b.codbobina = tr.codbobina LEFT JOIN em_reservasestpedido rep ON rep.idlineaest = tr.idlineaest LEFT JOIN em_reservasestlote rel ON tr.idlineaest = rel.idlineaest LEFT JOIN lotesstock lt ON lt.codlote = rel.codlote LEFT JOIN em_reservaslotepedido rlp ON rlp.idlineapc = rep.idlineapc AND rlp.codlote = lt.codlote LEFT JOIN em_lineasordenest loe ON loe.idlinea = tr.idlineaest LEFT JOIN lotesstock ltpz ON ltpz.codlote = tr.codpartida LEFT JOIN pr_ordenesproduccion op ON op.codorden = lt.codordenproduccion LEFT JOIN lineaspedidoscli lp ON lp.idlinea = rep.idlineapc LEFT JOIN pedidoscli pd ON pd.idpedido = lp.idpedido where tr.espieza and tr.cantotal>0  group by lt.codordenproduccion,op.emobservaciones,lt.codlote,lt.referencia,lt.articulo, case when rep.idlineaest is null then lt.canprogramada else rlp.cantidad end,case when lt.horacorte is null then 0 else lt.canlote end,lt.cantotal, loe.codordenest, b.codbobina, b.estado, tr.idtramo, ltpz.cantotal,ltpz.candisponible,tr.codpartida, tr.codbobinaroll,tr.codbobinaest,loe.referencia,loe.tejido, loe.cantidad,loe.canestampada,loe.canencurso,loe.estado,rep.idlineapc, pd.codigo, pd.codcliente,pd.nombrecliente,pd.docexterno, pd.fechasalida,pd.fechaservicio,tr.codbobinapiezaroll"]);



	
	for (i = 0; i < vistas.length; i++) {	
		var nombre = vistas [i][0];	
		var tipo = AQUtil.quickSqlSelect("information_schema.tables","table_type","table_name = '" + nombre + "'");
		debug("tipo: "+tipo);	
		if(tipo && tipo !="") {
			if(tipo == "VIEW") {			
				if (!AQUtil.execSql("DROP VIEW IF EXISTS " + vistas [i][0] + " CASCADE")) {
					sys.warnMsgBox(sys.translate("Error eliminando la tabla %1").arg(vistas [i][0]));
					return false;
				}
			
			} else {
				if (!AQUtil.execSql("DROP TABLE IF EXISTS " + vistas [i][0])) {
					sys.warnMsgBox(sys.translate("Error eliminando la tabla %1").arg(vistas [i][0]));
					return false;
				}
			
			}		
		}
		if (!AQUtil.execSql("CREATE VIEW " + vistas[i][0] + " AS " + vistas[i][1])) {
			sys.warnMsgBox(sys.translate("Error creando la vista %1").arg(vistas [i][0]));
			return false;
		}
	} 	
	
	return true;
}*/

function euromoda_emActualizaCamposColasOrdenesProd(oParam)
{
	var _gOP = formpr_generarordenesprodem.iface;

	var codOrdenParam;
	if ("codorden" in oParam) {
		codOrdenParam = oParam["codorden"];
	} else {
	 	codOrdenParam = Input.getText(sys.translate("Orden a actualizar"))
	}
	var where;
	if (!codOrdenParam || codOrdenParam == "") {
		var res = MessageBox.warning(sys.translate("Va a actualizar los campos de colas de �rdenes para todas las �rdenes con estado PTE o EN CURSO.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
		if (res != MessageBox.Yes) {
			return true;
		}
		where = "estado IN ('PTE', 'EN CURSO') AND em_codgruposeccion IS NULL";
	} else {
		where = "codorden = '" + codOrdenParam + "'";
	}
	var curO = new FLSqlCursor("pr_ordenesproduccion");
	curO.select(where);

	var qLote = new FLSqlQuery;
	qLote.setSelect("codlote, canlote, referencia, estado, canlote-cantotal");
	qLote.setFrom("lotesstock");
	qLote.setForwardOnly(true);

	var qG = new FLSqlQuery;
	qG.setSelect("op.codorden, COALESCE(s.em_codmodooper, f.em_codmodooper)");
	qG.setFrom("pr_ordenesproduccion op INNER JOIN subfamilias s ON op.codsubfamilia = s.codsubfamilia INNER JOIN familias f ON s.codfamilia = f.codfamilia");

	AQUtil.createProgressDialog(sys.translate("Actualizando �rdenes"), curO.size());
	var p = 0, codOrden, referencia, totalMetros, cantidad, estado, metros, codModoOperacion;
	while (curO.next()) {
		AQUtil.setProgress(p++);
		curO.setModeAccess(curO.Browse);
		curO.refreshBuffer();

		codOrden = curO.valueBuffer("codorden");
		totalMetros = 0;

		if(!_gOP.agruparOrdenes("codorden = '" + codOrden + "'")) {
			if (codOrdenParam && codOrdenParam != "") {
				AQUtil.destroyProgressDialog();
		    	sys.warnMsgBox(sys.translate("No se ha podido crear el grupo asociado a la orden %1").arg(codOrden));
				return false
			} else {
				continue;
			}
		}
		
		qG.setWhere("op.codorden = '" + codOrden + "' ORDER BY COALESCE(s.em_codmodooper, f.em_codmodooper), op.codorden");
		if (qG.exec() && qG.first()) {
			codModoOperacion = qG.value(1);
			if (codModoOperacion && codModoOperacion != "") {
				if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_codmodooper = '" + codModoOperacion + "' WHERE codorden = '" + codOrden + "'")) {
					return false;
				}
			}
		}

		var oAdicionales = _gOP.cargaObjetoAdicionales(codOrden);

		qLote.setWhere("codordenproduccion = '" + codOrden + "'");
		if (!qLote.exec()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		while (qLote.next()) {
			referencia = qLote.value("referencia");
			estado = qLote.value("estado");
			cantidad = 0;
			if (estado == "PTE") {
				cantidad = qLote.value("canlote-cantotal");
				if (cantidad < 0) {
					cantidad = 0;
				}
			}
			//debug("oficial_lanzaProcesos 3");
			metros = formRecordarticulos.iface.prendasAMetros(referencia, cantidad);
			if (!metros) {
				metros = 0;
			}
			totalMetros = parseFloat(totalMetros) + parseFloat(metros);

			_gOP.gramajesOrdenesProd(oAdicionales, referencia);
		}
		oAdicionales.totalMetros = totalMetros;
		if(!_gOP.calculaAdicionalesRet(oAdicionales)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		if (!formem_puestoprod.iface.calculaCantidadPte(codOrden)) {
			debug("!calculaCantidadPte");
			return false;
		}
	}
	AQUtil.destroyProgressDialog();

	return true;
}

function euromoda_regeTodosReserPedidos(oParam)
{
	var _i = this.iface;

	//select distinct p.codigo,p.idpedido from pedidoscli p inner join lineaspedidoscli lp on p.idpedido = lp.idpedido inner join movistock mp on lp.idlinea = mp.idlineapc inner join movistock mr on 
	
	var q = new AQSqlQuery;	
	q.setSelect("p.idpedido");
	q.setFrom("pedidoscli p inner join lineaspedidoscli lp on p.idpedido = lp.idpedido inner join movistock mp on lp.idlinea = mp.idlineapc inner join movistock mr on mp.idmovimiento = mr.idmovproducto");
	q.setWhere("p.servido = 'No' group by p.idpedido"); 
	if (!q.exec()){
		return;
	}  
	AQUtil.createProgressDialog(sys.translate("Actualizando �rdenes"), q.size());
	var p = 0;
	while(q.next())
	{	
		AQUtil.setProgress(p++);
		var idPedido = q.value("p.idpedido");
		var oParamPed = new Object;
		oParamPed.idPedido = idPedido;
		if(!_i.regeneraReservasPedido(oParamPed)) {
			AQUtil.destroyProgressDialog();
			return false;
		}	
	}	 
	AQUtil.destroyProgressDialog();
	return true;
}

function euromoda_regeneraReservasPedido(oParam)
{
	var _i = this.iface;
	var idPedidoReser;
	

	if ("idPedido" in oParam) {
		idPedidoReser = oParam.idPedido;
	} else {
		var codPedido = Input.getText(sys.translate("C�digo de pedido a actualizar"));
		if(!codPedido || codPedido =="") {
			return false;
		}
		idPedidoReser = AQUtil.sqlSelect("pedidoscli","idpedido","codigo = '" + codPedido + "'");
	}

	if(!idPedidoReser || idPedidoReser == "") {
		return false;
	}

	/*var q = new AQSqlQuery;	
	q.setSelect("m.idstock");
	q.setFrom("lineaspedidoscli lp inner join movistock m on m.idlineapc = lp.idlinea");
	q.setWhere("idpedido = " + idPedidoReser); 	
	debug("query mov: "+q.sql());		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idStock = q.value("m.idstock");		

		var curStock = new FLSqlCursor("stocks");
		curStock.select("idstock = " +idStock);
		curStock.setModeAccess(curStock.Edit);
  		curStock.refreshBuffer(); 
  		if(!curStock.first()) {
  			return false;
  		}  		
		if (!flfactalma.iface.pub_calculaReservasStock(curStock, true)) {			
			return false;
		}
		
	}*/

	var q = new AQSqlQuery;	
	q.setSelect("lp.cantidad,lp.idlinea");
	q.setFrom("lineaspedidoscli lp");
	q.setWhere("idpedido = " + idPedidoReser); 	
	debug("query mov: "+q.sql());		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var cantidad = q.value("lp.cantidad");	
		var cantidadN = parseInt(cantidad) + 1;
		var idLinea = q.value("lp.idlinea");		

		var curLinPed = new FLSqlCursor("lineaspedidoscli");
		curLinPed.select("idlinea = " +idLinea);
		curLinPed.setModeAccess(curLinPed.Edit);
  		curLinPed.refreshBuffer(); 
  		if(!curLinPed.first()) {
  			return false;
  		}  		
  		curLinPed.setValueBuffer("cantidad",cantidadN);
  		if(!curLinPed.commitBuffer()) {
  			return false;
  		}
  		curLinPed.select("idlinea = " +idLinea);
		curLinPed.setModeAccess(curLinPed.Edit);
  		curLinPed.refreshBuffer(); 
  		if(!curLinPed.first()) {
  			return false;
  		}  		
  		curLinPed.setValueBuffer("cantidad",cantidad);
  		if(!curLinPed.commitBuffer()) {
  			return false;
  		}
		
	}


	return true;
}

function euromoda_emBuscaOrdCantEstJose(oParam)
{
	var _i = this.iface;

	var q = new AQSqlQuery;	
	q.setSelect("ln.codordenest,oe.estado, ln.idlinea,ln.referencia,ln.canestampada, sum(tt.cantotal), ln.canestampada-sum(tt.cantotal), CASE SUM(tt.cantotal) WHEN 0 then 0 else  ln.canestampada/sum(tt.cantotal) end as dif_factor");
	q.setFrom("em_lineasordenest ln inner join em_tramostejido tt on ln.idlinea=tt.idlineaest inner join em_ordenesestampacion oe on oe.codordenest=ln.codordenest");
	q.setWhere("oe.estado<>'TERMINADA' and oe.estado<>'CANCELADA' AND idlineaest is not null and tt.codpartida like 'TT%' and ln.codordenest <> 'OE00017051' group by ln.codordenest,oe.estado,ln.idlinea,ln.referencia,ln.canestampada having (ln.canestampada-sum(tt.cantotal))>1  order by ln.codordenest,oe.estado, ln.idlinea,ln.referencia");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;

	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando �rdenes"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Orden  %1 - Estado orden %2 - Idlinea %3 - Referencia %4 - Cant.Est.Lin. %5 - Cant.Tramos %6 - Diferencia %7").arg(q.value("ln.codordenest")).arg(q.value("oe.estado")).arg(q.value("ln.idlinea")).arg(q.value("ln.referencia")).arg(q.value("ln.canestampada")).arg(q.value("sum(tt.cantotal)")).arg(q.value(7)));
	}

	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Ordenes en las que la cantidad estampada de la l�nea es distinta a la suma de sus tramos (JOSE):\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay �rdenes donde la la cantidad estampada de la l�nea es distinta a la suma de sus tramos (JOSE)");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	
	return true;

}

function euromoda_emOrdTramoLineaDis(oParam)
{
	var _i = this.iface;
	var codigo = Input.getText(sys.translate("C�digo de la OE o escribir TODAS para todas las OE"));
	if (!codigo) {
		return;
	}
	oParam.codOrdenest = codigo;
	if(!_i.emBuscaOrdTramoLineaDis(oParam)) {
		return false;
	}
 
	return true;
}

function euromoda_emBuscaOrdTramoLineaDis(oParam)
{
	var _i = this.iface;

/*select tr.idlineaest, tr.codordenest as codordentramo,
tr.referencia,ln.codordenest as codordenlinea,ln.referencia
from em_tramostejido tr
inner join em_lineasordenest ln on ln.idlinea=tr.idlineaest
where (tr.codordenest<>ln.codordenest)*/
	var where = "tr.codordenest<>ln.codordenest";
	if("codOrdenest" in oParam) {
		if(oParam.codOrdenest != "TODAS") {
			where += " and (tr.codordenest = '" + oParam.codOrdenest + "' OR ln.codordenest = '" + oParam.codOrdenest + "')"
		}
	} 

	var q = new AQSqlQuery;	
	q.setSelect("tr.codordenest,ln.codordenest");
	q.setFrom("em_tramostejido tr inner join em_lineasordenest ln on (ln.idlinea=tr.idlineaest or ln.idlinea = tr.idlineaestcalc)");
	q.setWhere(where + " group by tr.codordenest,ln.codordenest");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando �rdenes de estampaci�n"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     Orden en l�nea %1 - Orden en tramo %2").arg(q.value("ln.codordenest")).arg(q.value("tr.codordenest")));
		if (corregir) {
			var codOrdenTR = q.value("tr.codordenest");
			var codOrdenLN = q.value("ln.codordenest");

			var qA = new AQSqlQuery;	
			qA.setSelect("tr.idlineaest, tr.codordenest as codordentramo,tr.referencia,ln.codordenest as codordenlinea,ln.referencia, tr.idtramo");
			qA.setFrom("em_tramostejido tr inner join em_lineasordenest ln on ln.idlinea=tr.idlineaest");
			qA.setWhere("tr.codordenest = '" + codOrdenTR + "' and ln.codordenest = '" + codOrdenLN + "'");	
			debug(qA.sql());
			if (!qA.exec()) {
				return false;
			}
			while (qA.next()) {
				if (!AQUtil.execSql("UPDATE em_tramostejido SET codordenest = '" + codOrdenLN + "' WHERE idtramo = " + qA.value("tr.idtramo") )) {
					return false;
				}
			}

			var qA = new AQSqlQuery;	
			qA.setSelect("tr.idlineaestcalc, tr.codordenest as codordentramo,tr.referencia,ln.codordenest as codordenlinea,ln.referencia, tr.idtramo");
			qA.setFrom("em_tramostejido tr inner join em_lineasordenest ln on ln.idlinea=tr.idlineaestcalc");
			qA.setWhere("tr.codordenest = '" + codOrdenTR + "' and ln.codordenest = '" + codOrdenLN + "'");	
			debug(qA.sql());
			if (!qA.exec()) {
				return false;
			}
			while (qA.next()) {
				if (!AQUtil.execSql("UPDATE em_tramostejido SET codordenest = '" + codOrdenLN + "' WHERE idtramo = " + qA.value("tr.idtramo") )) {
					return false;
				}
			}

			var qA = new AQSqlQuery;	
			qA.setSelect("idtramo");
			qA.setFrom("em_tramostejido");
			qA.setWhere("(idlineaestcalc = 0 or idlineaestcalc is null) and idlineaest is null and codordenest = '" + codOrdenTR + "' and codbobina =codbobinaaca and referencia not in (select referencia from em_lineasordenest where codordenest ='" + codOrdenTR + "')");	
			debug(qA.sql());
			if (!qA.exec()) {
				return false;
			}
			while (qA.next()) {
				if (!AQUtil.execSql("UPDATE em_tramostejido SET codordenest = '" + codOrdenLN + "' WHERE idtramo = " + qA.value("idtramo") )) {
					return false;
				}
			}		

			corregidos++;
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: OE que tienen en su l�nea un cod.orden distinto al cod.orden de su tramo. Comprobar:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay OE que tienen en su l�nea un cod.orden distinto al cod.orden de su tramo.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	return true;
}

function euromoda_emBuscaLinTramoRefDis(oParam)
{
	var _i = this.iface;



	//Casos que coincidiendo la orden de la l�nea y el tramo las referencias de tramo y linea no coinciden

	/*select tr.idtramo,tr.idlineaest, tr.codordenest as codordentramo,tr.referencia,ln.codordenest as codordenlinea,ln.referencia
	from em_tramostejido tr
	inner join em_lineasordenest ln on ln.idlinea=tr.idlineaest
	where (tr.referencia<>ln.referencia)*/

	var where = "tr.referencia<>ln.referencia";
	/*if("codOrdenest" in oParam) {
		if(oParam.codOrdenest != "TODAS") {
			where += " and (tr.codordenest = '" + oParam.codOrdenest + "' OR ln.codordenest = '" + oParam.codOrdenest + "')"
		}
	} */

	var q = new AQSqlQuery;	
	q.setSelect("tr.idtramo,tr.idlineaest, tr.codordenest,tr.referencia,ln.codordenest,ln.referencia");
	q.setFrom("em_tramostejido tr inner join em_lineasordenest ln on ln.idlinea=tr.idlineaest");
	q.setWhere(where);	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	/*if (silent) {
		corregir = false;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}*/
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando l�neas y tramos de estampaci�n"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     IDTRAMO %1 - IDLINEAEST en tramo %2 - CODORDENEST en tramo %3 - REFERENCIA en tramo %4 - CODORDENEST en linea %5 - REFERENCIA en %6 ").arg(q.value("tr.idtramo")).arg(q.value("tr.idlineaest")).arg(q.value("tr.codordenest")).arg(q.value("tr.referencia")).arg(q.value("ln.codordenest")).arg(q.value("ln.referencia")));		
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Lineas que coincidiendo la orden de la linea y el tramo, las referencias de tramo y linea no coinciden:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay lineas que coincidiendo la orden de la linea y el tramo, las referencias de tramo y linea no coinciden.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	return true;
}

function euromoda_emBuscaMovPteRecMalSilent(oParam)
{
	var _i = this.iface;
	var oP = {
		silent : true
	};

	if(!_i.emBuscaMovPteRecMal(oP)) {
		debug("se va por false");
		return false;
	}
	debug("se va por true");
	return true;
}

function euromoda_emBuscaMovPteRecMal(oParam)
{
	var _i = this.iface;

	var codFamiliaCrudo = flfactalma.iface.dameFamCrudo();
	var codFamiliaTPPE = flfactalma.iface.dameFamTPPE();
	var codFamiliaEst = flfactalma.iface.dameFamEstampado();

	var codFamiliasEx = codFamiliaCrudo  + "," + codFamiliaTPPE + "," + codFamiliaEst;

	var codSubfamCrudo = flfactalma.iface.dameSubfamCrudo();
	var codSubfamGen = flfactalma.iface.dameSubfamEstampadoGen();
	var codSubfamEst = flfactalma.iface.dameSubfamEstampado();
	var codSubfamLam = flfactalma.iface.dameSubfamLaminas();

	var codSFamiliasEx = codSubfamCrudo  + "," + codSubfamGen + "," + codSubfamEst + "," + codSubfamLam;		

	var idUsuario = "stockdiferido";
	var tipoA = "PTE_RECIBIR";
	var valorSql = "NULL";

	//var where = "a.codfamilia not in (" + codFamiliasEx + ") AND a.codsubfamilia not in (" + codSFamiliasEx + ")";	
	var where = "1=1";
	var groupBy = "s.idstock,s.referencia,s.codalmacen,s.pterecibir, s.reservadapterecibir";

	/*SELECT st.idstock,
    st.codalmacen,
    st.referencia,
    st.articulo,
    st.pterecibir,
    st.reservadapterecibir,
    round(sum(COALESCE(mv2.cantidad, 0::double precision))::numeric, 2) AS ptes_recibir_reales,
    round(sum(COALESCE(stp.idstocksptes, 0::bigint)), 2) AS num_idstocksptes
   	FROM stocks st
     LEFT JOIN movistock mv2 ON st.idstock = mv2.idstock AND mv2.cantidad > 0::double precision AND mv2.estado::text = 'PTE'::text AND NOT mv2.em_merma
     LEFT JOIN ( SELECT stocksptes.idstock,
            count(*) AS idstocksptes
           FROM stocksptes
          GROUP BY stocksptes.idstock) stp ON st.idstock = stp.idstock
  	GROUP BY st.idstock, st.codalmacen, st.referencia, st.articulo, st.pterecibir, st.reservadapterecibir
	HAVING st.pterecibir <> sum(round(COALESCE(mv2.cantidad, 0::double precision)::numeric, 2))::double precision AND sum(COALESCE(stp.idstocksptes, 0::bigint)) = 0::numeric;*/


	var q = new AQSqlQuery;	
	q.setSelect("s.idstock,s.referencia,s.codalmacen,SUM(ms.cantidad),s.pterecibir, s.reservadapterecibir");
	q.setFrom("stocks s LEFT OUTER join movistock ms on s.idstock = ms.idstock and estado = 'PTE' and ms.cantidad > 0 and not em_merma INNER JOIN articulos a on a.referencia = s.referencia");
	q.setWhere(where + " group by s.idstock,s.referencia,s.codalmacen,s.pterecibir HAVING COALESCE(SUM(round(ms.cantidad::numeric,2)),0)  <> s.pterecibir");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = true;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando movimientos con Pte. Recibir Mal"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		lista.push(sys.translate("     IdStock %1 - Referencia %2 - Cod.Almacen %3 - Pte.Recibir.Real SUM(ms.cantidad) %4 - Pte.RecibirStock %5 - Reservada Pte. Recibir %6").arg(q.value("s.idstock")).arg(q.value("s.referencia")).arg(q.value("s.codalmacen")).arg(q.value("SUM(ms.cantidad)")).arg(q.value("s.pterecibir")).arg(q.value("s.reservadapterecibir")));
		if (corregir) {
			if (!AQUtil.execSql("INSERT INTO stocksptes (idstock, idusuario, tipoactualizacion, fecha, timestamp, codsubfamiliatp) VALUES (" + q.value("s.idstock") + ", '" + idUsuario + "', '" + tipoA + "', CURRENT_DATE, CURRENT_TIMESTAMP, " + valorSql + ")")) {
				return false;
			}
			corregidos++;
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Stocks que no coincide su pendiente de recibir con la suma de sus movimientos. Comprobar:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay Stocks que no coincide su pendiente de recibir con la suma de sus movimientos");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	return true;
}

function euromoda_emBuscaStosksRepetidos(oParam)
{
	var _i = this.iface;

	var q = new AQSqlQuery;	
	q.setSelect("referencia, codalmacen, count(*)");
	q.setFrom("stocks");
	q.setWhere("1=1 group by referencia, codalmacen HAVING(count(*)) > 1");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando stocks repetidos"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}
		var referencia = q.value("referencia");
		var codAlmacen = q.value("codalmacen");
		var numRepeticiones = q.value("count(*)");
		lista.push(sys.translate("     Referencia %1 - Cod.Almacen %2 - N� repeticiones %3").arg(referencia).arg(codAlmacen).arg(numRepeticiones))
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Referencias repetidas para el mismo c�digo y almac�n. Comprobar:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay Referencias repetidas para el mismo c�digo y almac�n.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	return true;
}

function euromoda_emBuscaStockNegResPosSilent(oParam)
{
	var _i = this.iface;
	var oP = {
		silent : true
	};

	if(!_i.emBuscaStockNegResPos(oP)) {
		debug("se va por false");
		return false;
	}
	debug("se va por true");
	return true;
}

function euromoda_emBuscaStockNegResPos(oParam)
{
	var _i = this.iface;
	var valorSql = "NULL";
	var idUsuario = "stockdiferido";
/*SELECT stocks.idstock,
    stocks.codalmacen,
    stocks.referencia,
    stocks.articulo,
    stocks.codtamanoem AS tamano,
    stocks.codcolorem AS color,
    stocks.cantidad,
    stocks.reservada,
    stocks.disponible,
    stocks.pterecibir,
    stocks.reservadapterecibir,
    stocks.disponiblepterecibir,
    stocks.afaltas,
    stocks.fechaultmov
   FROM stocks
  WHERE stocks.cantidad <= 0::double precision AND stocks.reservada > 0::double precision;
*/

	var q = new AQSqlQuery;	
	q.setSelect("stocks.idstock,stocks.codalmacen,stocks.referencia,stocks.articulo,stocks.codtamanoem AS tamano,stocks.codcolorem AS color,stocks.cantidad,stocks.reservada,    stocks.disponible,stocks.pterecibir,stocks.reservadapterecibir,stocks.disponiblepterecibir,stocks.afaltas,stocks.fechaultmov");
	q.setFrom("stocks");
	q.setWhere("stocks.cantidad <= 0 AND stocks.reservada > 0");	
	debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var lista = [];
	var p = 0;
	var corregir;
	var silent = oParam && "silent" in oParam;
	if (silent) {
		corregir = true;
	} else {
		var opt = ["Buscar", "Buscar y corregir"];
		var o = Input.getItem(sys.translate("Vamos a "), opt, opt[0]);
		corregir = (o == opt[1]);
	}
	if (!silent) {
		AQUtil.createProgressDialog(sys.translate("Revisando stocks negativos con reservas positivas"), q.size());
	}
	var corregidos = 0, casos = 0;
	while (q.next()) {
		casos++;
		p++;
		if (!silent) {
			AQUtil.setProgress(p);
		}

		// - Cantidad %4 - Reservada %5 - Disponible %6 - Pte.Recibir %7 - Reservada Pte.Recibir %8 - Disponible Pte.Recibir %9 - A Faltas %10 - Fecha Ult.Mov %11
		// .arg(q.value("stocks.cantidad")).arg(q.value("stocks.reservada")).arg(q.value("stocks.disponible")).arg(q.value("stocks.pterecibir")).arg(q.value("stocks.reservadapterecibir")).arg(q.value("stocks.disponiblepterecibir")).arg(q.value("stocks.afaltas")).arg(q.value("stocks.fechaultmov"))


		lista.push(sys.translate("     IdStock %1 - Referencia %2 - Cod.Almacen %3 - Cantidad %4 - Reservada %5").arg(q.value("stocks.idstock")).arg(q.value("stocks.referencia")).arg(q.value("stocks.codalmacen")).arg(q.value("stocks.cantidad")).arg(q.value("stocks.reservada")));

		if (corregir) {
			/*if (!AQUtil.execSql("INSERT INTO stocksptes (idstock, idusuario, tipoactualizacion, fecha, timestamp, codsubfamiliatp) VALUES (" + q.value("stocks.idstock") + ", '" + idUsuario + "', 'PTE_SERVIR', CURRENT_DATE, CURRENT_TIMESTAMP, " + valorSql + ")")) {
				return false;
			}
			if (!AQUtil.execSql("INSERT INTO stocksptes (idstock, idusuario, tipoactualizacion, fecha, timestamp, codsubfamiliatp) VALUES (" + q.value("stocks.idstock") + ", '" + idUsuario + "', 'STOCK_FISICO', CURRENT_DATE, CURRENT_TIMESTAMP, " + valorSql + ")")) {
				return false;
			}

			var qC = new AQSqlQuery;	
			qC.setSelect("s.idstock");
			qC.setFrom("articuloscomp ac inner join stocks s ON s.referencia = ac.refcomponente and s.codalmacen = '" + q.value("stocks.codalmacen") + "'");
			qC.setWhere("ac.refcompuesto = '" + q.value("stocks.referencia") + "' GROUP BY s.idstock");	
			debug(qC.sql());
			if (!qC.exec()) {
				return false;
			}
			while (qC.next()) {
				debug("se supone que inserta");
				if (!AQUtil.execSql("INSERT INTO stocksptes (idstock, idusuario, tipoactualizacion, fecha, timestamp, codsubfamiliatp) VALUES (" + qC.value("s.idstock") + ", '" + idUsuario + "', 'PTE_SERVIR', CURRENT_DATE, CURRENT_TIMESTAMP, " + valorSql + ")")) {
					return false;
				}

			}*/

			
			var fecha = flfactppal.iface.dameFechaActual();
			var hora = flfactppal.iface.dameHoraActual();
			debug("fecha: "+fecha);
			debug("hora: "+hora);
			var curReg = new FLSqlCursor("lineasregstocks");		
			curReg.setModeAccess(curReg.Insert);
			curReg.refreshBuffer();
			curReg.setValueBuffer("cantidadini", q.value("stocks.cantidad"));
			curReg.setValueBuffer("cantidadfin", 0);
			curReg.setValueBuffer("fecha", fecha);
			curReg.setValueBuffer("hora", hora);
			curReg.setValueBuffer("em_idusuario", sys.nameUser());
			curReg.setValueBuffer("idstock", q.value("stocks.idstock"));
			curReg.setValueBuffer("ptecalculo", true);
			curReg.setValueBuffer("sincronizado", false);	
			if(!curReg.commitBuffer()) {
				debug("error al insertar")
			}
			var idLineaReg = curReg.valueBuffer("id");

			curReg.setModeAccess(curReg.Del);
			curReg.refreshBuffer();
			if(!curReg.commitBuffer()) {
				debug("error al borrar");
			}
			corregidos++;
		}
	}
	
	var msg = lista.length > 0 ? sys.translate("HAY %1 ERRORES: Stocks negaticos con reservas positivas. Comprobar:\n%2").arg(casos).arg(lista.join("\n")) : sys.translate("OK: No hay Stocks negativos con reservas positivas.");
	if (silent) {
		return msg;
	} else {
		AQUtil.destroyProgressDialog();
		sys.infoMsgBox(msg);
	} 
	return true;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
