var form = this;
/***************************************************************************
                 em_impalbnoc.qs  -  description
                             -------------------
    begin                : mar oct 28 2014
    copyright            : (C) 2014 by YeboYebo S.L.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{	
   var curAlbaran_, curLineaAlb_;
	var importado_, generado_;
	function oficial(context) {
		interna(context);
  	} 
	function tbnBuscarFichero_clicked() {
		return this.ctx.oficial_tbnBuscarFichero_clicked();	
	}
	function tbnCargarLineas_clicked() {
		return this.ctx.oficial_tbnCargarLineas_clicked();	
	}
	function tbnGenerarAlbaranes_clicked() {
		return this.ctx.oficial_tbnGenerarAlbaranes_clicked();
	}
	function pbnGenerarFactura_clicked() {
		return this.ctx.oficial_pbnGenerarFactura_clicked();
	}
	function crearAlbaran(idImportacion, codCliente, codAlmacen, fecha) {
		return this.ctx.oficial_crearAlbaran(idImportacion, codCliente, codAlmacen, fecha);
	}
	function crearCabAlbaran(idImportacion,codAlmacen, fecha) {
		return this.ctx.oficial_crearCabAlbaran(idImportacion,codAlmacen, fecha);
	}
	function crearLineasAlbaran(idImportacion, codCliente, idAlbaran, codAlmacen, fecha) {
		return this.ctx.oficial_crearLineasAlbaran(idImportacion, codCliente, idAlbaran,  codAlmacen, fecha);
	}
	function crearLineaAlbaran(oParam) {
		return this.ctx.oficial_crearLineaAlbaran(oParam);
	}
	function prevalidacionLineas(oParamLin, codCliente) {
		return this.ctx.oficial_prevalidacionLineas(oParamLin, codCliente);
	}
	function colorError(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_colorError(fN, fV, cursor, fT, sel);
	}
	function labelError() {
		return this.ctx.oficial_labelError();
	}
	function quitaEspacios(s) {
		return this.ctx.oficial_quitaEspacios(s);
	}
	function calcularTotales() {
	     return this.ctx.oficial_calcularTotales();
	}
	function habilitaImportado() {
		return this.ctx.oficial_habilitaImportado();
	}
	function habilitaGenerado() {
		return this.ctx.oficial_habilitaGenerado();
	}
	function estaImportado() {
		return this.ctx.oficial_estaImportado();
	}
	/*function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}*/
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
Este formulario realiza la gestion de los albaranes a clientes.

Los albaranes pueden ser generados de forma manual o a partir de uno o mas pedidos.
\end */
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();  
  
	connect(this.child("tbnBuscarFichero"), "clicked()", _i, "tbnBuscarFichero_clicked");
	connect(this.child("tbnCargarLineas"), "clicked()", _i, "tbnCargarLineas_clicked");
	connect(this.child("tbnGenerarAlbaranes"), "clicked()", _i, "tbnGenerarAlbaranes_clicked");
	connect(this.child("pbnGenerarFactura"), "clicked()", _i, "pbnGenerarFactura_clicked");
	connect(this.child("tdbLineas"), "currentChanged()", _i, "labelError");
	//connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");
	_i.estaImportado();	
	_i.habilitaImportado();
	_i.habilitaGenerado();
	
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnBuscarFichero_clicked()
{
	var _i = this.iface;	
	var f = FileDialog.getOpenFileName("*.txt");
	if (!f) {
		return;
	}
	sys.setObjText(this, "fdbNombreFichero", f);
}

function oficial_tbnCargarLineas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codClienteImp = cursor.valueBuffer("codcliente");
	var codClienteFra;
	var idImportacion = cursor.valueBuffer("idimportacion");
	var numReg = AQUtil.sqlSelect("em_lineasimpalbnoc", "COUNT(*)", "idimportacion=" + idImportacion );
	if(numReg && numReg != 0) {
		var res = MessageBox.information(sys.translate("Ya hay datos cargados en las l�neas, estos datos se eliminar�n �Desea continuar?"), MessageBox.Yes, MessageBox.No)
		if (res != MessageBox.Yes) {
			return;
		}
		AQUtil.sqlDelete("em_lineasimpalbnoc", "idimportacion=" + idImportacion);
	}
	f = cursor.valueBuffer("nombrefichero");
	var sep= ";";	
	var file = new File(f);
  	try {
  		file.open(File.ReadOnly);
  	} catch(e) {
    	sys.warnMsgBox(sys.translate("Error al abrir el fichero:\n%1").arg(f));
		return false;
  	}
	
	var steps = 0;
	var step = 0;
  	while (!file.eof) {
 		file.readLine();
    	++steps;
  	}	
	debug("Pasos: "+steps);
  	file.close();
  	file.open(File.ReadOnly);

	AQUtil.createProgressDialog(sys.translate("Cargando datos"), steps);	
  	while (!file.eof) {
		AQUtil.setProgress(step+1);		
   	var line = file.readLine();	
		if (!line) {
			AQUtil.destroyProgressDialog();
			sys.warnMsgBox(sys.translate("Error al leer la l��nea %1:\n%2").arg(step).arg(line));
			return false;
		}
		
		var clave = line.substring(0,2);
		if (clave == "01") {
			//cabecera
			var proveedor = line.substring(2,12);
			var fechaEnvio = line.substring(12,20);
			if(fechaEnvio.length != 8) {
			     sys.warnMsgBox(sys.translate("Error al leer la fecha de env�o en la l�nea ").arg(line));
			     return false;
			}
			
			fechaEnvio = fechaEnvio.substring(0,4)+"-"+fechaEnvio.substring(4,6)+"-"+fechaEnvio.substring(6,8);
			
			cursor.setValueBuffer("proveedor",proveedor);
			cursor.setValueBuffer("fechaenvio",fechaEnvio);
			if(!cursor.commitBuffer()) {
	     		return false;
			}

		} else if (clave == "02") {
		 	var oParamLin = new Object();
			oParamLin.centro = _i.quitaEspacios(line.substring(2,6));			 
			oParamLin.codAlmacen = _i.quitaEspacios(line.substring(6,10));
			oParamLin.codBarras = _i.quitaEspacios(line.substring(10,28));
			oParamLin.movimiento = _i.quitaEspacios(line.substring(28,32));
			oParamLin.tipoMovimiento = _i.quitaEspacios(line.substring(32,33));
			oParamLin.fecha = _i.quitaEspacios(line.substring(33,41));
			oParamLin.hora = _i.quitaEspacios(line.substring(41,47));
			oParamLin.cantidad = _i.quitaEspacios(line.substring(47,60));
			oParamLin.unidad = _i.quitaEspacios(line.substring(60,63));
			oParamLin.importe = _i.quitaEspacios(line.substring(63,76));
			oParamLin.divisa = _i.quitaEspacios(line.substring(76,81));
			var referencia = AQUtil.sqlSelect("articulos", "referencia", "codbarras='" + oParamLin.codBarras + "'");

			var codCliente = AQUtil.sqlSelect("clientes", "codcliente", "em_codalmacliente = '" + oParamLin.codAlmacen + "' ");
			var codClienteFac = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente = '" + codCliente + "' ");
			//var tipoError = _i.prevalidacionLineas(oParamLin, codClienteImp);
			var tipoError = _i.prevalidacionLineas(oParamLin, codClienteFac);

			var curLineas = new FLSqlCursor("em_lineasimpalbnoc");
			curLineas.setModeAccess(curLineas.Insert);
	 		curLineas.refreshBuffer(); 			
			curLineas.setValueBuffer("idimportacion",idImportacion);
			curLineas.setValueBuffer("codcentro",oParamLin.centro);
			curLineas.setValueBuffer("codalmacen",oParamLin.codAlmacen);
			curLineas.setValueBuffer("codbarras",oParamLin.codBarras);
			curLineas.setValueBuffer("movimiento",oParamLin.movimiento);
			curLineas.setValueBuffer("tipomovimiento",oParamLin.tipoMovimiento);
			
			if (tipoError.indexOf("6") == -1) {
			     var fecha = oParamLin.fecha;
			     fecha = fecha.substring(0,4)+"-"+fecha.substring(4,6)+"-"+fecha.substring(6,8);
			     curLineas.setValueBuffer("fecha",fecha);
					//var pvpNoctalia = formRecordem_imppednoc.iface.pub_damePVPNoctalia(codClienteImp, referencia, fecha);
					var pvpNoctalia = formRecordem_imppednoc.iface.pub_damePVPNoctalia(codClienteFac, referencia, fecha);
					curLineas.setValueBuffer("importecalc",pvpNoctalia*oParamLin.cantidad);
			}
			if (tipoError.indexOf("7") == -1) {
			     var hora = oParamLin.hora;
			     hora = hora.substring(0,2)+":"+hora.substring(2,4)+":"+hora.substring(4,6);
			     curLineas.setValueBuffer("hora",hora);
			}
			curLineas.setValueBuffer("cantidad",oParamLin.cantidad);
			curLineas.setValueBuffer("unidad",oParamLin.unidad);			
			curLineas.setValueBuffer("importe",oParamLin.importe);
			curLineas.setValueBuffer("divisa",oParamLin.divisa);
			curLineas.setValueBuffer("numlinea",step+1);
			curLineas.setValueBuffer("tipoerror",tipoError);
			if (!curLineas.commitBuffer()) {
				return false;
	 		}

		} else {
			//error
		}
		
		++step;
	}		
  	AQUtil.destroyProgressDialog();	
	
	this.child("tdbLineas").refresh();
  	return true;

	
}

function oficial_tbnGenerarAlbaranes_clicked()
{
	var _i = this.iface;	
	var i = 1;
	var cursor = this.cursor();
	var idImportacion = cursor.valueBuffer("idimportacion");	
	//var codClienteImp = cursor.valueBuffer("codcliente");
	
	var fecha = cursor.valueBuffer("fecha");
	var almaAlb = [];
	var q = new AQSqlQuery;	
	q.setSelect("codalmacen");
	q.setFrom("em_lineasimpalbnoc");
	//q.setWhere("idimportacion = " + idImportacion + " and tipoerror ='' and tipomovimiento='S' group by codalmacen" );			
	q.setWhere("idimportacion = " + idImportacion + " and tipoerror ='' order by numlinea " );
	if (!q.exec()){
		return;
	}  
	AQUtil.createProgressDialog(sys.translate("Generando albaranes..."), q.size());
	while(q.next())
	{
		AQUtil.setProgress(i);
		var codAlmacen = q.value("codalmacen");
		if (codAlmacen in almaAlb) {
			continue;
		}
		almaAlb[codAlmacen] = codAlmacen;
		var codCliente = AQUtil.sqlSelect("clientes", "codcliente", "em_codalmacliente = '" + codAlmacen + "' ");
		var codClienteFac = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente = '" + codCliente + "' ");
		//var codAlbaran = _i.crearAlbaran(idImportacion, codClienteImp, codAlmacen, fecha);
		var codAlbaran = _i.crearAlbaran(idImportacion, codClienteFac, codAlmacen, fecha);
		debug ("Albar�n creado: "+codAlbaran);
		i++;
	}
	AQUtil.destroyProgressDialog();
	var numAlbaranes = i-1;
	if(numAlbaranes == 0) {
		sys.infoMsgBox(sys.translate("No se ha generado ning�n albar�n."));
	} else {
		var mensaje = numAlbaranes == 1 ? sys.translate("Se ha generado 1 albar�n.") : sys.translate("Se han generado %1 albaranes.").arg(numAlbaranes);
		sys.infoMsgBox(mensaje);
		_i.estaImportado();	
		_i.habilitaImportado();	
		this.child("tbwFT").showPage("albaranes");
		this.child("tdbAlbaranes").refresh();
	}
}
function oficial_crearAlbaran(idImportacion, codCliente, codAlmacen, fecha)
{
	var _i = this.iface;
	
	if (!_i.curAlbaran_) {
    _i.curAlbaran_ = new FLSqlCursor("albaranescli");
	}
  	_i.curAlbaran_.setModeAccess(_i.curAlbaran_.Insert);
  	_i.curAlbaran_.refreshBuffer(); 
  	if (!_i.crearCabAlbaran(idImportacion,codAlmacen, fecha)) {
  		return false;
  	}
  	if (!_i.curAlbaran_.commitBuffer()) {
  		return false;
	}
	var idAlbaran = _i.curAlbaran_.valueBuffer("idalbaran");
 	if (!_i.crearLineasAlbaran(idImportacion, codCliente, idAlbaran, codAlmacen, fecha)) {
		return false;
	}
	_i.curAlbaran_.select("idalbaran = " + idAlbaran);
  	if (!_i.curAlbaran_.first()) {
		return res;
  	}
	_i.curAlbaran_.setModeAccess(_i.curAlbaran_.Edit);
	_i.curAlbaran_.refreshBuffer();
	
	if (!_i.calcularTotales()) {
		return false;
  	}
  	if (!_i.curAlbaran_.commitBuffer()) {
		return false;
  	}
	var codAlbaran = _i.curAlbaran_.valueBuffer("codigo");
  	return codAlbaran;
}

function oficial_crearCabAlbaran(idImportacion,codAlmacen, fecha)
{
	var _i = this.iface;
	_i.curAlbaran_.setValueBuffer("fecha", fecha);
	_i.curAlbaran_.setValueBuffer("hora", new Date().toString().right(8));
	var qCli = new AQSqlQuery;	
	qCli.setSelect("cli.codcliente, cli.nombre, cli.cifnif, cli.coddivisa, cli.codpago, cli.codagente, cli.codclientefac, cli.codgrupoivaneg, cli.em_codpago, cli.codalmadeposito ");
	qCli.setFrom("clientes cli ");
	qCli.setWhere("em_codalmacliente = '" + codAlmacen + "' "); 			
	if (!qCli.exec()){
		return;
	}  
	if(!qCli.first())
	{			
		return false;	
	 }
	debug("cliente: "+qCli.value("cli.codcliente"));
	_i.curAlbaran_.setValueBuffer("codcliente", qCli.value("cli.codcliente"));
	_i.curAlbaran_.setValueBuffer("nombrecliente", qCli.value("cli.nombre"));
	_i.curAlbaran_.setValueBuffer("cifnif", qCli.value("cli.cifnif"));
	_i.curAlbaran_.setValueBuffer("coddivisa", qCli.value("cli.coddivisa"));
	_i.curAlbaran_.setValueBuffer("codserie", formalbaranescli.iface.pub_commonCalculateField("codserie", _i.curAlbaran_));
	_i.curAlbaran_.setValueBuffer("codpago", qCli.value("cli.codpago"));
_i.curAlbaran_.setValueBuffer("em_codpago", qCli.value("cli.em_codpago"));
	_i.curAlbaran_.setValueBuffer("codagente", qCli.value("cli.codagente"));
	_i.curAlbaran_.setValueBuffer("codalmacen", qCli.value("cli.codalmadeposito"));
	_i.curAlbaran_.setValueBuffer("tipodeposito", "Venta dep�sito");

	var codDir = formalbaranescli.iface.pub_commonCalculateField("coddir", _i.curAlbaran_);
	var qDir = new AQSqlQuery;	
	qDir.setSelect("dir.direccion, dir.codpostal, dir.ciudad, dir.idprovincia,dir.apartado, dir.codpais, dir.descripcion");
	qDir.setFrom("dirclientes dir ");
	qDir.setWhere("dir.id = " + codDir); 			
	if (!qDir.exec()){
		return;
	}  
	if(!qDir.first())
	{			
		return false;	
	}
	_i.curAlbaran_.setValueBuffer("coddir", codDir);
	_i.curAlbaran_.setValueBuffer("irpf", formalbaranescli.iface.pub_commonCalculateField("irpf", _i.curAlbaran_));
	_i.curAlbaran_.setValueBuffer("descripciondir", qDir.value("dir.descripcion"));
	_i.curAlbaran_.setValueBuffer("direccion", qDir.value("dir.direccion"));
	_i.curAlbaran_.setValueBuffer("codpostal", qDir.value("dir.codpostal"));
	_i.curAlbaran_.setValueBuffer("ciudad", qDir.value("dir.ciudad"));
	if (qDir.value("dir.idprovincia") != 0 ) {
		_i.curAlbaran_.setValueBuffer("idprovincia", qDir.value("dir.idprovincia"));
	} 
	_i.curAlbaran_.setValueBuffer("provincia", qDir.value("dir.provincia"));
	_i.curAlbaran_.setValueBuffer("apartado", qDir.value("dir.apartado"));
	_i.curAlbaran_.setValueBuffer("codpais", formalbaranescli.iface.pub_commonCalculateField("codpais", _i.curAlbaran_));
	_i.curAlbaran_.setValueBuffer("codejercicio",flfactppal.iface.pub_ejercicioActual());
	_i.curAlbaran_.setValueBuffer("tasaconv",AQUtil.sqlSelect("divisas", "tasaconv", "coddivisa = '" + qCli.value("cli.coddivisa") + "'"));
	_i.curAlbaran_.setValueBuffer("codclientefac", qCli.value("cli.codclientefac"));
	_i.curAlbaran_.setValueBuffer("codgrupoivaneg", qCli.value("cli.codgrupoivaneg"));
	
	_i.curAlbaran_.setValueBuffer("em_idimpnoctalia", idImportacion );
	
	 return true;


}
function oficial_crearLineasAlbaran(idImportacion, codCliente, idAlbaran, codAlmacen, fecha)
{
	var _i = this.iface;
	var contLineas = 1;
	if (!_i.curLineaAlb_) {
		_i.curLineaAlb_ = new FLSqlCursor("lineasalbaranescli");
	}

	//la referencia que tengo en la excel es refcliente, el barcode si que es barcode de la referencia, tengo que sacar la referencia de em_articuloscli donde el cliente sea codCliente y la refcliente sea la referencia de la excel

	var qLin = new AQSqlQuery;	
	qLin.setSelect("codbarras, codcentro, cantidad, importe, fecha, hora, movimiento");
	qLin.setFrom("em_lineasimpalbnoc ");
	qLin.setWhere("idimportacion = " + idImportacion + " and codalmacen = '" + codAlmacen + "' and tipoerror ='' order by numlinea" );					
	if (!qLin.exec()){
		return;
	}  
	while(qLin.next())
	{
	     debug("Linea: "+contLineas); 
		_i.curLineaAlb_.setModeAccess(_i.curLineaAlb_.Insert);
    	_i.curLineaAlb_.refreshBuffer();
    	_i.curLineaAlb_.setValueBuffer("idalbaran", idAlbaran);

		var oParam = new Object();	
		oParam.fecha = qLin.value("fecha");
		oParam.hora = qLin.value("hora");			
		oParam.tipoConcepto  = "Texto";
		oParam.codAlmacen = codAlmacen;
		oParam.movimiento = qLin.value("movimiento");
    	if (!_i.crearLineaAlbaran(oParam)) {
      	return false;
   	 }
    	if (!_i.curLineaAlb_.commitBuffer()) {
      	return false;
    	}
		_i.curLineaAlb_.setModeAccess(_i.curLineaAlb_.Insert);
    	_i.curLineaAlb_.refreshBuffer();
    	_i.curLineaAlb_.setValueBuffer("idalbaran", idAlbaran);

		var oParam = new Object();
		oParam.codBarras = qLin.value("codbarras");
		oParam.referencia = AQUtil.sqlSelect("articulos", "referencia", "codbarras='" + oParam.codBarras + "'");

		oParam.cantidad = qLin.value("cantidad");
		oParam.fecha = qLin.value("fecha");
		oParam.codCliente = codCliente;		
		oParam.tipoConcepto  = "Producto";
		oParam.movimiento = qLin.value("movimiento");
    	if (!_i.crearLineaAlbaran(oParam)) {
      	return false;
   	 }
    	if (!_i.curLineaAlb_.commitBuffer()) {
      	return false;
    	}		
	}
	return true;
}
function oficial_crearLineaAlbaran(oParam)
{
	var _i = this.iface;
	var tipoConcepto = oParam.tipoConcepto;
	_i.curLineaAlb_.setValueBuffer("numlinea", formRecordlineasalbaranescli.iface.pub_commonCalculateField("numlinea", _i.curLineaAlb_));
	
	if(tipoConcepto == "Producto") {
		var qArt = new AQSqlQuery;	
		qArt.setSelect("art.codtamanoem, art.codcolorem, art.descripcion ");
		qArt.setFrom("articulos art");
		qArt.setWhere("referencia = '" + oParam.referencia + "' "); 			
		if (!qArt.exec()){
			return;
		}  
		if(!qArt.first())
		{			
			return false;	
		}
	  	var iva;
	  	var recargo;
	  	
		_i.curLineaAlb_.setValueBuffer("referencia",oParam.referencia);	
		_i.curLineaAlb_.setValueBuffer("descripcion",AQUtil.sqlSelect("em_articuloscli", "descripcioncliente", "referencia = '" + oParam.referencia + "' and codcliente = '" + oParam.codCliente + "'"));
		_i.curLineaAlb_.setValueBuffer("codtamanoem", qArt.value("art.codtamanoem"));
		_i.curLineaAlb_.setValueBuffer("codcolorem", qArt.value("art.codcolorem"));
		if (oParam.movimiento.toUpperCase()== "653" || oParam.movimiento.toUpperCase()== "602K") {
			_i.curLineaAlb_.setValueBuffer("cantidad", oParam.cantidad*(-1));	
		} else {
			_i.curLineaAlb_.setValueBuffer("cantidad", oParam.cantidad);
		}
	  	_i.curLineaAlb_.setValueBuffer("canfactura", formRecordlineasalbaranescli.iface.pub_commonCalculateField("canfactura", _i.curLineaAlb_));
		_i.curLineaAlb_.setValueBuffer("pvpunitario",formRecordem_imppednoc.iface.pub_damePVPNoctalia(oParam.codCliente, oParam.referencia, oParam.fecha)); 	 	
		_i.curLineaAlb_.setValueBuffer("pvpsindto",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvpsindto", _i.curLineaAlb_));
		_i.curLineaAlb_.setValueBuffer("pvptotal",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvptotal", _i.curLineaAlb_));
		_i.curLineaAlb_.setValueBuffer("dtolineal",formRecordlineasalbaranescli.iface.pub_commonCalculateField("dtolineal", _i.curLineaAlb_));
		_i.curLineaAlb_.setValueBuffer("dtopor",formRecordlineasalbaranescli.iface.pub_commonCalculateField("dtopor", _i.curLineaAlb_));	 
	
		_i.curLineaAlb_.setValueBuffer("codimpuesto",formRecordlineasalbaranescli.iface.pub_commonCalculateField("codimpuesto", _i.curLineaAlb_));
		_i.curLineaAlb_.setValueBuffer("iva",formRecordlineasalbaranescli.iface.pub_commonCalculateField("iva", _i.curLineaAlb_));
		_i.curLineaAlb_.setValueBuffer("recargo", formRecordlineasalbaranescli.iface.pub_commonCalculateField("recargo", _i.curLineaAlb_));

		_i.curLineaAlb_.setValueBuffer("tipoconcepto","Producto");
		_i.curLineaAlb_.setValueBuffer("codsubcuenta",formRecordlineasalbaranescli.iface.pub_commonCalculateField("codsubcuenta", _i.curLineaAlb_));
		_i.curLineaAlb_.setValueBuffer("idsubcuenta",formRecordlineasalbaranescli.iface.pub_commonCalculateField("idsubcuenta", _i.curLineaAlb_));
	} else  {
		var fecha = AQUtil.dateAMDtoDMA(oParam.fecha.toString().left(10));
		var regExp = new RegExp("-");
		regExp.global = true;
		fecha = fecha.replace(regExp,"/");
		var hora = oParam.hora.toString().right(8);
		var descripcion;
		if (oParam.movimiento.toUpperCase()== "653" || oParam.movimiento.toUpperCase()== "602K") {
			descripcion = "Devol.: ALM. " + oParam.codAlmacen + ". DIA: " + fecha +" - " + hora;
		} else {
			descripcion = "Venta: ALM. " + oParam.codAlmacen + ". DIA: " + fecha +" - " + hora;
		}
		_i.curLineaAlb_.setValueBuffer("descripcion",descripcion);
		_i.curLineaAlb_.setValueBuffer("texto",descripcion);
		_i.curLineaAlb_.setValueBuffer("cantidad", 0);	
		_i.curLineaAlb_.setValueBuffer("canfactura",0);
		_i.curLineaAlb_.setValueBuffer("pvpunitario",0);
		_i.curLineaAlb_.setValueBuffer("pvpsindto",0);
		_i.curLineaAlb_.setValueBuffer("pvptotal",0);
		_i.curLineaAlb_.setValueBuffer("dtolineal",0);
		_i.curLineaAlb_.setValueBuffer("dtopor",0);
		_i.curLineaAlb_.setValueBuffer("recargo",0);
		_i.curLineaAlb_.setValueBuffer("tipoconcepto","Texto");
			

	}

  return true;
}
function oficial_prevalidacionLineas(oParamLin, codCliente)
{
	var _i = this.iface;
	var tipoError = "";
	var centro = oParamLin.centro;
	var codAlmacen = oParamLin.codAlmacen;
	var codBarras = oParamLin.codBarras;
	var movimiento = oParamLin.movimiento;
	var tipoMovimiento = oParamLin.tipoMovimiento;
	var fecha = oParamLin.fecha;
	var hora = oParamLin.hora;
	var unidad = oParamLin.unidad;
	var importe = oParamLin.importe;
	var divisa = oParamLin.divisa;
	var cantidad = oParamLin.cantidad;
	var referenciaBC,referencia;
	
	
	//centro	
	if (centro == "") {  
		tipoError = "1";
	}

	// codAlmacen
	if (codAlmacen == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "2";
 	} else if (!AQUtil.sqlSelect("clientes", "codalmadeposito", "em_codalmacliente ='" + codAlmacen + "'")) {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "23";
	} else {
		var codCliente = AQUtil.sqlSelect("clientes", "codcliente", "em_codalmacliente ='" + codAlmacen + "'"); 
		if (!codCliente || codCliente == "") {
			tipoError += tipoError == "" ? "" : "|";
			tipoError += "21";
		}else {
			var codDir = AQUtil.sqlSelect("dirclientes", "id", "codcliente = '" + codCliente + "' AND domenvio = 'true'");	
			if (!codDir || codDir == "") {
				tipoError += tipoError == "" ? "" : "|";
				tipoError += "22";
					  
			}
		}
	}
 

	// codBarras
	if (codBarras == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "3";
 	} else {
		referenciaBC = AQUtil.sqlSelect("articulos", "referencia", "codbarras ='" + codBarras + "'"); 
		if (!referenciaBC || referenciaBC == "") {
			tipoError += tipoError == "" ? "" : "|";
			tipoError += "31";
		}
	}
	//movimiento
	if (movimiento == "" || (movimiento.toUpperCase() != "601K" && movimiento.toUpperCase() != "653" && movimiento.toUpperCase() != "602K")) {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "4";
 	}
	
	//tipoMovimiento
	if (tipoMovimiento == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "5";
 	}
	//fecha
	if (fecha == "" || fecha.length != 8) {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "6";
 	}

	//hora
	if (hora == "" || hora.length != 6) {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "7";
 	}
	//unidad
	if (unidad == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "8";
 	}
	//importe
	if (importe == 0) {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "9";
 	}
	//divisa
	if (divisa == "") {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "10";
 	}

	//cantidad
	if (cantidad == 0) {
		tipoError += tipoError == "" ? "" : "|";
		tipoError += "11";
 	}
	
	return tipoError;

}
function oficial_colorError(fN, fV, cursor, fT, sel)
{
	var _i = this.iface;
	var tipoErrores = cursor.valueBuffer("tipoerror");
	var tipoError = tipoErrores.split("|");
	var color = "";	
	for (var i = 0; i < tipoError.length; i++) {		
		switch (tipoError[i]) {
			case "1": {
				if(fN == "codcentro") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "2":
			case "21": 
			case "22":
			case "23": {
				if(fN == "codalmacen") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "3":
			case "31": {
				if(fN == "codbarras") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "4": {
				if(fN == "movimiento") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "5": {
				if(fN == "tipomovimiento") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "6": {
				if(fN == "fecha") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "7": {
				if(fN == "hora") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "8": {
				if(fN == "unidad") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "9": {
				if(fN == "importe") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "10": {
				if(fN == "divisa") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			case "11": {
				if(fN == "cantidad") {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
				}
				break;
			}
			default: {
				//color = flfactppal.iface.pub_dameColor("fondo_blanco");
			}

		}
	}
  	
  	if (color != "") {
		var a = [color, "#000000", "SolidPattern", "SolidPattern"];
    	return a;
  	}
}
function oficial_labelError()
{
	var cursor = this.child("tdbLineas").cursor();
	var tipoErrores = cursor.valueBuffer("tipoerror");
	if (!tipoErrores || tipoErrores == "") {
		this.child("lblerrores").setText("");
		return;
	}
	var tipoError = tipoErrores.split("|");
	var labelError = "";
	for (var i = 0; i < tipoError.length; i++) {		
		switch (tipoError[i]) {
			case "1": {				
				labelError = "C�digo de centro vac�o.";
				break;
			}
			case "2": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "C�digo de almac�n vac�o.";				
				break;
			}
			case "21": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "No se ha encontrado c�digo de cliente para el almac�n " + cursor.valueBuffer("codalmacen") +".";								
				break;
			}
			case "22": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "No se ha encontrado direcci�n de env�o para cliente del almac�n " + cursor.valueBuffer("codalmacen") +".";								
				break;
			}
			case "23": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "No existe almac�n de dep�sito para el c�digo de almacen " + cursor.valueBuffer("codalmacen") +".";								
				break;
			}
			case "3": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "C�digo de barras vac�o.";				
				break;
			}
			case "31": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "No existe ninguna referencia para el c�digo de barras " + cursor.valueBuffer("codbarras")+ ".";				
				break;
			}
			case "4": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "S�lamente se importan los movimientos 601K, los 653 y los 602K.";				
				break;
			}
			case "5": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Tipo movimiento vac�o o incorrecto.";				
				break;
			}
			case "6": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Fecha incorrecta.";				
				break;
			}
			case "7": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Hora incorrecta.";				
				break;
			}
			case "8": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Unidad vac�a.";				
				break;
			}
			case "9": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Importe a cero.";				
				break;
			}
			case "10": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Divisa vac�a.";				
				break;
			}
			case "11": {
				labelError += labelError == "" ? "" : "\n";
				labelError += "Cantidad a cero.";				
				break;
			}
		}
	}	
	this.child("lblerrores").setText(labelError);
	
}
function oficial_quitaEspacios(s)
{
	var n = "", c;
	for (var i = 0; i < s.length; i++) {
		c = s.charAt(i);
		n += c != " " ? c : "";
	}
	return n;
}
function oficial_calcularTotales()	
{
	var _i = this.iface;
	_i.curAlbaran_.setValueBuffer("netosindtoesp", formalbaranescli.iface.pub_commonCalculateField("netosindtoesp", _i.curAlbaran_));
	_i.curAlbaran_.setValueBuffer("neto", formalbaranescli.iface.pub_commonCalculateField("neto", _i.curAlbaran_));	
	_i.curAlbaran_.setValueBuffer("totaliva", formalbaranescli.iface.pub_commonCalculateField("totaliva", _i.curAlbaran_));
	_i.curAlbaran_.setValueBuffer("totalrecargo", formalbaranescli.iface.pub_commonCalculateField("totalrecargo", _i.curAlbaran_));
	_i.curAlbaran_.setValueBuffer("totalirpf", formalbaranescli.iface.pub_commonCalculateField("totalirpf", _i.curAlbaran_));	
	_i.curAlbaran_.setValueBuffer("total", formalbaranescli.iface.pub_commonCalculateField("total", _i.curAlbaran_));
	
	return true;
}
function oficial_pbnGenerarFactura_clicked()
{
	var _i = this.iface;
	var i = 1;
	var cursor = this.cursor();
	var idImportacion = cursor.valueBuffer("idimportacion");
	var qAlbCen = new AQSqlQuery;	
	qAlbCen.setSelect("cli.em_centrocliente");
	qAlbCen.setFrom("albaranescli albcli INNER JOIN clientes cli ON albcli.codcliente = cli.codcliente");
	qAlbCen.setWhere("albcli.em_idimpnoctalia = " + idImportacion + " group by cli.em_centrocliente order by cli.em_centrocliente " );					
	if (!qAlbCen.exec()){
		return;
	}  
	AQUtil.createProgressDialog(sys.translate("Generando facturas..."), qAlbCen.size());
	while(qAlbCen.next())
	{
		AQUtil.setProgress(i);
		var codCentro = qAlbCen.value("cli.em_centrocliente");
		var albaranes = "";
		var where = "";
		var idAlbaranCursor = "";
		var qAlb = new AQSqlQuery;	
		qAlb.setSelect("cli.codclientefac, albcli.idalbaran");
		qAlb.setFrom("albaranescli albcli INNER JOIN clientes cli ON albcli.codcliente = cli.codcliente");
		qAlb.setWhere("albcli.em_idimpnoctalia = " + idImportacion + " and cli.em_centrocliente = '" + codCentro + "'" );					
		if (!qAlb.exec()){
			return;
		}  
		
		while(qAlb.next())
		{
			var idAlbaran = qAlb.value("albcli.idalbaran");
			debug("idAlbaran: "+ idAlbaran);
			if(idAlbaranCursor == "") {			
				idAlbaranCursor = idAlbaran;
			}		
			albaranes += albaranes == "" ? "" : ",";
			albaranes += "'" + idAlbaran + "'";								
						 		
		}
		
		where = " idalbaran IN (" + albaranes + ")";

		if (where && where != "") {
			var curAlbaran = new FLSqlCursor("albaranescli");
			curAlbaran.select("idalbaran = " + idAlbaranCursor);
  			if (!curAlbaran.first()) {
				return false;
  			}
			curAlbaran.setModeAccess(curAlbaran.Edit);
			curAlbaran.refreshBuffer();
			var idFactura = formalbaranescli.iface.generarFactura(where, curAlbaran); 	
			debug("idFActura: "+idFactura);
			var curFactura = new FLSqlCursor("facturascli");
			curFactura.select("idfactura = " + idFactura);
  			if (!curFactura.first()) {
				return false;
  			}
			curFactura.setModeAccess(curFactura.Edit);
			curFactura.refreshBuffer();
			curFactura.setValueBuffer("em_idimpnoctalia", idImportacion);
    		if (!curFactura.commitBuffer()) {
      		return false;
    		}	
			
		}	
		i++;
	}
	AQUtil.destroyProgressDialog();
	var numFacturas = AQUtil.sqlSelect("facturascli", "count(*)", "em_idimpnoctalia=" + idImportacion);
	if(numFacturas == 0) {
		sys.infoMsgBox(sys.translate("No se ha generado ninguna facturascli."));
	} else {
		var mensaje = numFacturas == 1 ? sys.translate("Se ha generado 1 factura.") : sys.translate("Se han generado %1 facturas.").arg(numFacturas);
		sys.infoMsgBox(mensaje);
		_i.estaImportado();
		_i.habilitaGenerado();
		this.child("tbwFT").showPage("facturas");
		this.child("tdbFacturas").refresh();
	}
}
function oficial_habilitaImportado()
{
	var _i = this.iface;	
 	if(_i.importado_) {
		this.child("tbnBuscarFichero").setEnabled(false);
		this.child("tbnCargarLineas").setEnabled(false);
		this.child("tbnGenerarAlbaranes").setEnabled(false);
		this.child("pbnGenerarFactura").setEnabled(true);
		sys.setObjText(this, "lblImportado", "Albaranes importados");

	} else {
		this.child("tbnBuscarFichero").setEnabled(true);
		this.child("tbnCargarLineas").setEnabled(true);
		this.child("tbnGenerarAlbaranes").setEnabled(true);
		this.child("pbnGenerarFactura").setEnabled(false);
		sys.setObjText(this, "lblImportado", "");
	}
}
function oficial_habilitaGenerado()
{
	var _i = this.iface;
 	if(_i.generado_) {
		this.child("pbnGenerarFactura").setEnabled(false);
		sys.setObjText(this, "lblGenerado", "Facturas generadas");
	} else {
		this.child("pbnGenerarFactura").setEnabled(true);
		sys.setObjText(this, "lblGenerado", "");
	}
}
function oficial_estaImportado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idImportacion = cursor.valueBuffer("idimportacion");
	var numAlbaranes = AQUtil.sqlSelect("albaranescli", "count(*)", "em_idimpnoctalia=" + idImportacion );	
	if(numAlbaranes && numAlbaranes !=0) {
		_i.importado_ = true;
	}else {
		_i.importado_ = false;	
	}
	var numFacturas = AQUtil.sqlSelect("facturascli", "count(*)", "em_idimpnoctalia=" + idImportacion );	
	if(numFacturas && numFacturas !=0) {
		_i.generado_ = true;
	}else {
		_i.generado_ = false;	
	}
}
/*function oficial_bufferChanged(fN) 
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "importadoalb": {
			_i.habilitaImportado();
      break;
    }
		case "generadofac": {
			_i.habilitaGenerado();
      break;
    }

	}
}*/
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
