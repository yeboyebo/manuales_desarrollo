/***************************************************************************
                         em_masteredialbaranescli.qs
                             -------------------
    begin                : lun jun 25 2012
    copyright            : (C) 2003-2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  var cur_;
  var pbGenEdi_;
  var pbGenEdiNoc_;
  function oficial(context)
  {
    interna(context);
  }
  function genEdi()
  {
    this.ctx.oficial_genEdi();
  }
  function genEdiEmbalajes(codEsquema, where, fileName)
  {
    return this.ctx.oficial_genEdiEmbalajes(codEsquema, where, fileName);
  }
  function digitoControl(str)
  {
    return this.ctx.oficial_digitoControl(str);
  }
  function buildWhere()
  {
    return this.ctx.oficial_buildWhere();
  }
  function genEdiNoc() {
	 return this.ctx.oficial_genEdiNoc();
  }
  function genEdiEmbalajesALC(codEsquema, where, fileName) {
  	return this.ctx.oficial_genEdiEmbalajesALC(codEsquema, where, fileName);
  }
  function comprobarUnidesEnvio(where) {
  	return this.ctx.oficial_comprobarUnidesEnvio(where);
  }
  function genEdiEmbalajesCON(codEsquema, where, fileName) {
  	return this.ctx.oficial_genEdiEmbalajesCON(codEsquema, where, fileName);
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;

  _i.cur_ = this.cursor();
  _i.pbGenEdi_ = this.child("pbGenEdi");

  connect(_i.pbGenEdi_, "clicked()", _i, "genEdi()");

  _i.pbGenEdiNoc_ = this.child("pbGenEdiNoc");

  connect(_i.pbGenEdiNoc_, "clicked()", _i, "genEdiNoc()");
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_genEdi()
{
	var _i = this.iface;

	if (!_i.cur_.isValid()) {
		sys.errorMsgBox(sys.translate("Debe seleccionar un registro"));
		return;
	}

	var mensaje = _i.cur_.valueBuffer("codmensaje");	
	var where = _i.buildWhere();	
	
	if(mensaje.left(3) == "ALC") {
		var mensaje = _i.comprobarUnidesEnvio(where);
		if(mensaje != "") {
			mensaje += "\n�Desea generar el fichero?";
			var res = MessageBox.information(mensaje, MessageBox.Yes, MessageBox.No)
			if (res != MessageBox.Yes) {
				return true;
			}	
		
		}
	}
	
	var ediIface = formedi_esquemas.iface;
	
	/*var msg = sys.translate("Proceso finalizado") + "\n\n";	
	msg += ediIface.pub_genEdiFile("CABALB", where) + "\n";
	msg += _i.genEdiEmbalajes("EMBALB", where) + "\n";
	msg += ediIface.pub_genEdiFile("LINALB", where) + "\n";
	sys.infoMsgBox(msg);*/
	
	var msg = sys.translate("Proceso finalizado") + "\n\n";	
	
	var q = new AQSqlQuery;	
	q.setSelect("codesquema,nombrefichero");
	q.setFrom("edi_esquemas");
	q.setWhere("codmensaje = '" + mensaje + "' order by orden ASC"); 			
	debug("sql: "+q.sql());
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var codEsquema = q.value("codesquema");
		var nombreFichero = q.value("nombrefichero");

		debug("codEsquema: "+codEsquema);
		debug("codEsquemaleft6: "+codEsquema.left(6));
		if(codEsquema.left(6) == "EMBALB") {
			if(mensaje.left(3) == "ALC") {
				msg += _i.genEdiEmbalajesALC(codEsquema, where, nombreFichero) + "\n";
			} else if(mensaje.left(3) == "CON") {
				msg += _i.genEdiEmbalajesCON(codEsquema, where, nombreFichero) + "\n";
			} else {
				msg += _i.genEdiEmbalajes(codEsquema, where, nombreFichero) + "\n";
			}
		} else {
			msg += ediIface.pub_genEdiFile(codEsquema, where, nombreFichero) + "\n";			
		}
	}
	sys.infoMsgBox(msg);
	
}

function oficial_genEdiEmbalajes(codEsquema, where, fileName)
{
  var _i = this.iface;

  var qry = new AQSqlQuery;
  qry.setSelect("idalbaran,palets,codtipoembalajepaleedi,codigo");
  qry.setFrom("albaranescli inner join clientes on albaranescli.codcliente=clientes.codcliente");
  qry.setOrderBy("codigo");
  qry.setWhere(where);

  if (!qry.exec()) {
    var msg = "genEdiEmbalajes: ";
    msg += sys.translate("ERROR: Fall� la consulta");
    msg += '\n' + qry.sql();
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var cur = new FLSqlCursor("edi_esquemas");
  cur.select("codesquema='" + codEsquema + "'");
  cur.first();
  if (!cur.isValid()) {
    var msg = sys.translate("ERROR: No existe el esquema ") + codEsquema;
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var codEmpEAN = AQUtil.sqlSelect("empresa", "codedi", "1=1");

  var ediIface = formedi_esquemas.iface;
  var objEdi = ediIface.pub_objEdiFromRec(cur);
  var fields = ediIface.pub_fieldsEdiFromRec(cur);

  var p = 0;
  var txt = "";

  AQUtil.createProgressDialog(sys.translate("Procesando..."), qry.size());
  AQUtil.setProgress(1);

  while (qry.next()) {
    var numEmb = 1;
    var idAlb = qry.value(0);
    var numPalets = qry.value(1);
    var codAlb = qry.value(3);

    if (!numPalets) {
      var msg = sys.translate("ERROR: El n� Palets debe ser mayor de 0 en albar�n ") + codAlb;
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    var qryBultos = new AQSqlQuery;
    qryBultos.setSelect("numpale");
    qryBultos.setFrom("em_lineaspacking");
    qryBultos.setWhere("idalbaran=" + idAlb);
    qryBultos.setOrderBy("numlineapacking");

    if (!qryBultos.exec()) {
      var msg = "genEdiEmbalajes: ";
      msg += sys.translate("ERROR: Fall� la consulta");
      msg += '\n' + qryBultos.sql();
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    if (qryBultos.size() == 0 || !qryBultos.last()) {
      var msg = sys.translate("ERROR: Debe generarse un packing list en albar�n ") + codAlb;
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    var lastNumPalet = qryBultos.value(0);
    if (numPalets != lastNumPalet) {
      var msg = sys.translate("ERROR: N� palets de cabecera %1, pero el �ltimo n� palet en l�neas es %2, en albar�n ") + codAlb;
      //sys.errorPopup(msg.arg(numPalets).arg(lastNumPalet));
      debug(msg.arg(numPalets).arg(lastNumPalet));
      return msg.arg(numPalets).arg(lastNumPalet);
    }

    var indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
    txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
    txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
    txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
    txt += ediIface.pub_formatValueEdi(numPalets, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
    indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
    txt += ediIface.pub_formatValueEdi(qry.value(2), fields[indentPos], objEdi);

    txt += flfactppal.iface.pub_espaciosDerecha("", 582);

    txt += "\r\n";
	debug("numPalets: "+numPalets);
    for (var i = 1; i <= numPalets; ++i) {
      ++numEmb;

      indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
      txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
      txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
      txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
      txt += ediIface.pub_formatValueEdi("1", fields[indentPos], objEdi);

      var numBultos = AQUtil.sqlSelect("em_lineaspacking", "sum(numbultos)",
                                       "idalbaran=" + idAlb + " and numpale=" + i);
      indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
      var numBultosStr = ediIface.pub_formatValueEdi(numBultos, fields[indentPos], objEdi);
      txt += numBultosStr;

      indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
      txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
      indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
      txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

      var tipoEmb = AQUtil.sqlSelect("em_lineaspacking", "codtipoembalajeedi",
                                     "idalbaran=" + idAlb + " and numpale=" + i);
      indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
      var tipoEmbStr = ediIface.pub_formatValueEdi(tipoEmb, fields[indentPos], objEdi);
      txt += tipoEmbStr;

      txt += flfactppal.iface.pub_espaciosDerecha("", 447);
      txt += tipoEmbStr;
      txt += numBultosStr;
      txt += flfactppal.iface.pub_espaciosDerecha("", 117);

      txt += "\r\n";

      var qryBultos = new AQSqlQuery;
      qryBultos.setSelect("em_lineaspacking.codtipoembalajeedi,em_detallelineapacking.idlineadetalle");
      qryBultos.setFrom("em_lineaspacking inner join em_detallelineapacking on " +
                        "em_lineaspacking.idlinea_packing=em_detallelineapacking.idlinea_packing");
      qryBultos.setWhere("idalbaran=" + idAlb + " and numpale=" + i);
      qryBultos.setOrderBy("em_lineaspacking.numlineapacking,em_lineaspacking.numpale");
		debug("qryBultos: "+qryBultos.sql());
      if (!qryBultos.exec()) {
        var msg = "genEdiEmbalajes: ";
        msg += sys.translate("ERROR: Fall� la consulta");
        msg += '\n' + qryBultos.sql();
        //sys.errorPopup(msg);
        debug(msg);
        return msg;
      }

      while (qryBultos.next()) {
        ++numEmb;

        indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
        txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
        txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
        txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
        txt += ediIface.pub_formatValueEdi("2", fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
        txt += ediIface.pub_formatValueEdi("0", fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
        txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
        indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
        txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
        txt += ediIface.pub_formatValueEdi(qryBultos.value(0), fields[indentPos], objEdi);

        txt += flfactppal.iface.pub_espaciosDerecha("", 237);

        var idLinea = qryBultos.value(1);
        var sscc1 = "3" + codEmpEAN +
                    flfactppal.iface.pub_cerosIzquierda(idLinea, 9);
        sscc1 += _i.digitoControl(sscc1);
        txt += flfactppal.iface.pub_espaciosDerecha(sscc1, 35);

        txt += flfactppal.iface.pub_espaciosDerecha("", 310);

        AQSql.update("em_detallelineapacking",
                     ["lineaembalajeedi"], [numEmb],
                     "idlineadetalle=" + idLinea);
        txt += "\r\n";
      }

    }

    AQUtil.setProgress(++p);
  }

  var workDir = "u:/edicom";
  var curSet = new AQSqlCursor("edi_settings");
  curSet.select("");
  if (curSet.first())
    workDir = curSet.valueBuffer("workdir");
  if (!fileName || fileName == "")
    fileName = objEdi.cod;
  var filePath = workDir + "/" + fileName + ".txt";

  var file = new QFile(filePath);
  if (!file.open(File.WriteOnly)) {
    var msg = file.errorString();
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var ts = new QTextStream(file.ioDevice());
  ts.opIn(txt);
  file.close();

  debug(
    sys.translate("Fichero EDI generado en:\n") +
    filePath
  );

  AQUtil.destroyProgressDialog();

  return filePath;
}

function oficial_genEdiEmbalajesALC(codEsquema, where, fileName)
{
  var _i = this.iface;

  var qry = new AQSqlQuery;
  qry.setSelect("idalbaran,palets,codtipoembalajepaleedi,codigo");
  qry.setFrom("albaranescli inner join clientes on albaranescli.codcliente=clientes.codcliente");
  qry.setOrderBy("codigo");
  qry.setWhere(where);

  if (!qry.exec()) {
    var msg = "genEdiEmbalajes: ";
    msg += sys.translate("ERROR: Fall� la consulta");
    msg += '\n' + qry.sql();
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var cur = new FLSqlCursor("edi_esquemas");
  cur.select("codesquema='" + codEsquema + "'");
  cur.first();
  if (!cur.isValid()) {
    var msg = sys.translate("ERROR: No existe el esquema ") + codEsquema;
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var codEmpEAN = AQUtil.sqlSelect("empresa", "codedi", "1=1");

  var ediIface = formedi_esquemas.iface;
  var objEdi = ediIface.pub_objEdiFromRec(cur);
  var fields = ediIface.pub_fieldsEdiFromRec(cur);

  var p = 0;
  var txt = "";

  AQUtil.createProgressDialog(sys.translate("Procesando..."), qry.size());
  AQUtil.setProgress(1);

  while (qry.next()) {
    var numEmb = 1;
    var idAlb = qry.value(0);
    var numPalets = qry.value(1);
    var codAlb = qry.value(3);

    if (!numPalets) {
      var msg = sys.translate("ERROR: El n� Palets debe ser mayor de 0 en albar�n ") + codAlb;
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    var qryBultos = new AQSqlQuery;
    qryBultos.setSelect("numpale");
    qryBultos.setFrom("em_lineaspacking");
    qryBultos.setWhere("idalbaran=" + idAlb);
    qryBultos.setOrderBy("numlineapacking");

    if (!qryBultos.exec()) {
      var msg = "genEdiEmbalajes: ";
      msg += sys.translate("ERROR: Fall� la consulta");
      msg += '\n' + qryBultos.sql();
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    if (qryBultos.size() == 0 || !qryBultos.last()) {
      var msg = sys.translate("ERROR: Debe generarse un packing list en albar�n ") + codAlb;
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    var lastNumPalet = qryBultos.value(0);
    if (numPalets != lastNumPalet) {
      var msg = sys.translate("ERROR: N� palets de cabecera %1, pero el �ltimo n� palet en l�neas es %2, en albar�n ") + codAlb;
      //sys.errorPopup(msg.arg(numPalets).arg(lastNumPalet));
      debug(msg.arg(numPalets).arg(lastNumPalet));
      return msg.arg(numPalets).arg(lastNumPalet);
    }

    var indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
    txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
    txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
    txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
    txt += ediIface.pub_formatValueEdi(numPalets, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
    indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
    txt += ediIface.pub_formatValueEdi(qry.value(2), fields[indentPos], objEdi);   

    txt += flfactppal.iface.pub_espaciosDerecha("", 582);

    txt += "\r\n";
	debug("numPalets: "+numPalets);
    for (var i = 1; i <= numPalets; ++i) {
      ++numEmb;

      indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
      txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
      txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
      txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
      txt += ediIface.pub_formatValueEdi("1", fields[indentPos], objEdi);

      var numBultos = AQUtil.sqlSelect("em_lineaspacking", "sum(numbultos)",
                                       "idalbaran=" + idAlb + " and numpale=" + i);
      indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
      var numBultosStr = ediIface.pub_formatValueEdi(numBultos, fields[indentPos], objEdi);
      txt += numBultosStr;

      indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
      txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
      indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
      txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

      var tipoEmb = AQUtil.sqlSelect("em_lineaspacking", "codtipoembalajeedi",
                                     "idalbaran=" + idAlb + " and numpale=" + i);
      indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
      var tipoEmbStr = ediIface.pub_formatValueEdi(tipoEmb, fields[indentPos], objEdi);
      var tipoEmbPal = ediIface.pub_formatValueEdi("201", fields[indentPos], objEdi);
      txt += tipoEmbPal;
      

      

      //txt += flfactppal.iface.pub_espaciosDerecha("", 447);
      txt += flfactppal.iface.pub_espaciosDerecha("", 237);
             var idLinea = AQUtil.sqlSelect("em_lineaspacking", "idlinea_packing","idalbaran=" + idAlb + " and numpale=" + i);
    	var sscc1 = "3" + codEmpEAN +
    	flfactppal.iface.pub_cerosIzquierda(idLinea, 9);
    	sscc1 += _i.digitoControl(sscc1);
    	txt += flfactppal.iface.pub_espaciosDerecha(sscc1, 35);
    	
    	txt += flfactppal.iface.pub_espaciosDerecha("", 175); 	
    	
      txt += tipoEmbStr;
      txt += numBultosStr;
      txt += flfactppal.iface.pub_espaciosDerecha("", 117);
    

      txt += "\r\n";
		//AQSql.update("em_detallelineapacking", ["lineaembalajeedi"], [numEmb+1],"idlineadetalle=" + idLinea);
      
      var qryBultos = new AQSqlQuery;
      qryBultos.setSelect("em_lineaspacking.codtipoembalajeedi,em_detallelineapacking.idlineadetalle");
      qryBultos.setFrom("em_lineaspacking inner join em_detallelineapacking on " +
                        "em_lineaspacking.idlinea_packing=em_detallelineapacking.idlinea_packing");
      qryBultos.setWhere("idalbaran=" + idAlb + " and numpale=" + i);
      qryBultos.setOrderBy("em_lineaspacking.numlineapacking,em_lineaspacking.numpale");
		debug("qryBultos: "+qryBultos.sql());
      if (!qryBultos.exec()) {
        var msg = "genEdiEmbalajes: ";
        msg += sys.translate("ERROR: Fall� la consulta");
        msg += '\n' + qryBultos.sql();
        //sys.errorPopup(msg);
        debug(msg);
        return msg;
      }

      while (qryBultos.next()) {
       /* ++numEmb;

       indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
        txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
        txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
        txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
        txt += ediIface.pub_formatValueEdi("2", fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
        txt += ediIface.pub_formatValueEdi("0", fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
        txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
        indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
        txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
        txt += ediIface.pub_formatValueEdi(qryBultos.value(0), fields[indentPos], objEdi);

        txt += flfactppal.iface.pub_espaciosDerecha("", 237);

        
        var sscc1 = "3" + codEmpEAN +
                    flfactppal.iface.pub_cerosIzquierda(idLinea, 9);
        sscc1 += _i.digitoControl(sscc1);
        txt += flfactppal.iface.pub_espaciosDerecha(sscc1, 35);

        txt += flfactppal.iface.pub_espaciosDerecha("", 310);*/
		  var idLinea = qryBultos.value(1);	
        AQSql.update("em_detallelineapacking", ["lineaembalajeedi"], [numEmb],"idlineadetalle=" + idLinea);
        //txt += "\r\n";
      }

    }

    AQUtil.setProgress(++p);
  }

  var workDir = "u:/edicom";
  var curSet = new AQSqlCursor("edi_settings");
  curSet.select("");
  if (curSet.first())
    workDir = curSet.valueBuffer("workdir");
  if (!fileName || fileName == "")
    fileName = objEdi.cod;
  var filePath = workDir + "/" + fileName + ".txt";

  var file = new QFile(filePath);
  if (!file.open(File.WriteOnly)) {
    var msg = file.errorString();
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var ts = new QTextStream(file.ioDevice());
  ts.opIn(txt);
  file.close();

  debug(
    sys.translate("Fichero EDI generado en:\n") +
    filePath
  );

  AQUtil.destroyProgressDialog();

  return filePath;
}

function oficial_digitoControl(str)
{
  var sumPares = 0;
  var sumImpares = 0;
  for (var i = 0; i < str.length; i += 2)
    sumImpares += (parseInt(str.charAt(i)) * 3);
  for (var i = 1; i < str.length; i += 2)
    sumPares += parseInt(str.charAt(i));
  var ret = 10 - ((sumPares + sumImpares) % 10);
  if (ret == 10)
    return 0;
  return ret;
}

function oficial_buildWhere()
{
  var _i = this.iface;

  if (!_i.cur_.isNull("codintervalo") && _i.cur_.valueBuffer("codintervalo") != "") {
    var intervalo = [];
    intervalo = flfactppal.iface.pub_calcularIntervalo(
                  _i.cur_.valueBuffer("codintervalo")
                );
    _i.cur_.setValueBuffer("d_albaranescli_fecha", intervalo.desde);
    _i.cur_.setValueBuffer("h_albaranescli_fecha", intervalo.hasta);
  }

  var q = flfactinfo.iface.pub_establecerConsulta(_i.cur_, "i_albaranescli");
  var where = q.where();

  if (!_i.cur_.isNull("codgrupo")) {
    if (!where.isEmpty())
      where += " AND ";
    where += " clientes.codgrupo='" +
             _i.cur_.valueBuffer("codgrupo") + "'";
  }

  if (!where.isEmpty())
    where += " AND ";
  where += " clientes.edialbaranes='t'";

  return where;
}
function oficial_genEdiNoc()
{
  var _i = this.iface;

  if (!_i.cur_.isValid()) {
    sys.errorMsgBox(sys.translate("Debe seleccionar un registro"));
    return;
  }
  var mensaje = _i.cur_.valueBuffer("codmensaje");
  var where = _i.buildWhere();
  where += " AND tipodeposito NOT IN ('Venta dep�sito')";
debug("where2: "+where);

  var ediIface = formedi_esquemas.iface;  
  
  
/*  var msg = sys.translate("Proceso finalizado") + "\n\n";
  msg += ediIface.pub_genEdiFile("CABCRE", where) + "\n";
  msg += ediIface.pub_genEdiFile("EMBCRE", where) + "\n";
  msg += ediIface.pub_genEdiFile("LINCRE", where) + "\n";
  sys.infoMsgBox(msg);*/
  
	var msg = sys.translate("Proceso finalizado") + "\n\n";	

	var q = new AQSqlQuery;	
	q.setSelect("codesquema,nombrefichero");
	q.setFrom("edi_esquemas");
	q.setWhere("codmensaje = '" + mensaje + "'"); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var codEsquema = q.value("codesquema");	
		msg += ediIface.pub_genEdiFile(codEsquema, where) + "\n";
		
	}
	sys.infoMsgBox(msg);
  
  
}

function oficial_comprobarUnidesEnvio(where)
{
	var _i = this.iface;
	var retorno = "";
	var codAlbaran = ""; 
	var numLinea = "";
	var q = new AQSqlQuery;	
	q.setSelect("albaranescli.codigo,em_lineaspacking.numlineapacking, em_detallelineapacking.cantidad");
	q.setFrom("albaranescli inner join em_lineaspacking on albaranescli.idalbaran=em_lineaspacking.idalbaran inner join em_detallelineapacking on em_lineaspacking.idlinea_packing=em_detallelineapacking.idlinea_packing inner join clientes on albaranescli.codcliente=clientes.codcliente");
	q.setWhere(where+" GROUP BY albaranescli.codigo,em_lineaspacking.numlineapacking, em_detallelineapacking.cantidad ORDER BY albaranescli.codigo,em_lineaspacking.numlineapacking, em_detallelineapacking.cantidad"); 			
	if (!q.exec()){
		return;
	}  
	debug("q.sql: "+q.sql());
	while(q.next())
	{
		if(codAlbaran == q.value("albaranescli.codigo") && numLinea == q.value("em_lineaspacking.numlineapacking")) {			
			retorno += retorno == "" ? "" : "\n";
			retorno += sys.translate("En el albar�n %1 y l�nea de packing %2 hay distintas unidades en el detalle de packing").arg(codAlbaran).arg(numLinea);			
		} else {
			codAlbaran = q.value("albaranescli.codigo");
			numLinea = q.value("em_lineaspacking.numlineapacking");
		} 	
	}	
	debug("retorno: "+retorno);
	return retorno;
}

function oficial_genEdiEmbalajesCON(codEsquema, where, fileName)
{
  var _i = this.iface;

  var qry = new AQSqlQuery;
  qry.setSelect("idalbaran,palets,codtipoembalajepaleedi,codigo");
  qry.setFrom("albaranescli inner join clientes on albaranescli.codcliente=clientes.codcliente");
  qry.setOrderBy("codigo");
  qry.setWhere(where);

  if (!qry.exec()) {
    var msg = "genEdiEmbalajes: ";
    msg += sys.translate("ERROR: Fall� la consulta");
    msg += '\n' + qry.sql();
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var cur = new FLSqlCursor("edi_esquemas");
  cur.select("codesquema='" + codEsquema + "'");
  cur.first();
  if (!cur.isValid()) {
    var msg = sys.translate("ERROR: No existe el esquema ") + codEsquema;
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var codEmpEAN = AQUtil.sqlSelect("empresa", "codedi", "1=1");

  var ediIface = formedi_esquemas.iface;
  var objEdi = ediIface.pub_objEdiFromRec(cur);
  var fields = ediIface.pub_fieldsEdiFromRec(cur);

  var p = 0;
  var txt = "";

  AQUtil.createProgressDialog(sys.translate("Procesando..."), qry.size());
  AQUtil.setProgress(1);

  while (qry.next()) {
    var numEmb = 1;
    var numEmbPadre = 1;
    var idAlb = qry.value(0);
    var numPalets = qry.value(1);
    var codAlb = qry.value(3);

    if (!numPalets) {
      var msg = sys.translate("ERROR: El n� Palets debe ser mayor de 0 en albar�n ") + codAlb;
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    var qryBultos = new AQSqlQuery;
    qryBultos.setSelect("numpale,idlinea_packing");
    qryBultos.setFrom("em_lineaspacking");
    qryBultos.setWhere("idalbaran=" + idAlb);
    qryBultos.setOrderBy("numlineapacking");
    debug("qryBultos: "+qryBultos.sql());
    if (!qryBultos.exec()) {
      var msg = "genEdiEmbalajes: ";
      msg += sys.translate("ERROR: Fall� la consulta");
      msg += '\n' + qryBultos.sql();
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    if (qryBultos.size() == 0 || !qryBultos.last()) {
      var msg = sys.translate("ERROR: Debe generarse un packing list en albar�n ") + codAlb;
      //sys.errorPopup(msg);
      debug(msg);
      return msg;
    }

    var lastNumPalet = qryBultos.value(0);
    if (numPalets != lastNumPalet) {
      var msg = sys.translate("ERROR: N� palets de cabecera %1, pero el �ltimo n� palet en l�neas es %2, en albar�n ") + codAlb;
      //sys.errorPopup(msg.arg(numPalets).arg(lastNumPalet));
      debug(msg.arg(numPalets).arg(lastNumPalet));
      return msg.arg(numPalets).arg(lastNumPalet);
    }

    var indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
    txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
    txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
    txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
    txt += ediIface.pub_formatValueEdi(numPalets, fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
    indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
    txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

    indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
   
    txt += ediIface.pub_formatValueEdi(qry.value(2), fields[indentPos], objEdi);
    txt += flfactppal.iface.pub_espaciosDerecha("", 450);
    indentPos = flfactppal.iface.pub_cerosIzquierda(9, 9);
    
   
    var bultos = AQUtil.sqlSelect("em_lineaspacking","SUM(numbultos)","idalbaran = "+idAlb);
    
	 txt += ediIface.pub_formatValueEdi(bultos, fields[indentPos], objEdi);
    txt += flfactppal.iface.pub_espaciosDerecha("", 117);

    txt += "\r\n";
	debug("numPalets: "+numPalets);
    for (var i = 1; i <= numPalets; ++i) {
      ++numEmb;
		numEmbPadre = numEmb;
      indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
      txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
      txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
      txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

      indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
      txt += ediIface.pub_formatValueEdi("1", fields[indentPos], objEdi);

      var numBultos = AQUtil.sqlSelect("em_lineaspacking", "sum(numbultos)",
                                       "idalbaran=" + idAlb + " and numpale=" + i);
      indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
      var numBultosStr = ediIface.pub_formatValueEdi(numBultos, fields[indentPos], objEdi);
      txt += numBultosStr;

      indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
      txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
      indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
      txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

      var tipoEmb2 = AQUtil.sqlSelect("em_lineaspacking", "codtipoembalajeedi","idalbaran=" + idAlb + " and numpale=" + i);
      var tipoEmb = "201";
      indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
      var tipoEmbStr = ediIface.pub_formatValueEdi(tipoEmb, fields[indentPos], objEdi);
      var tipoEmbStr2 = ediIface.pub_formatValueEdi(tipoEmb2, fields[indentPos], objEdi);
      txt += tipoEmbStr;

		txt += flfactppal.iface.pub_espaciosDerecha("", 237);

		//var idLinea = qryBultos.value(1);
		var idLinea = AQUtil.sqlSelect("em_lineaspacking","idlinea_packing","idalbaran=" + idAlb  + " and numpale=" + i);
				debug("\n\n*****************************idLinea: "+idLinea);
		var sscc1 = "3" + codEmpEAN + flfactppal.iface.pub_cerosIzquierda(idLinea, 9);
		sscc1 += _i.digitoControl(sscc1);
		txt += flfactppal.iface.pub_espaciosDerecha(sscc1, 35);

		txt += flfactppal.iface.pub_espaciosDerecha("", 175);	     
      txt += tipoEmbStr2;
      txt += numBultosStr;
      txt += flfactppal.iface.pub_espaciosDerecha("", 117);

      txt += "\r\n";

      var qryBultos = new AQSqlQuery;
      qryBultos.setSelect("em_lineaspacking.codtipoembalajeedi,em_detallelineapacking.idlineadetalle");
      qryBultos.setFrom("em_lineaspacking inner join em_detallelineapacking on " +
                        "em_lineaspacking.idlinea_packing=em_detallelineapacking.idlinea_packing");
      qryBultos.setWhere("idalbaran=" + idAlb + " and numpale=" + i);
      qryBultos.setOrderBy("em_lineaspacking.numlineapacking,em_lineaspacking.numpale");
		debug("qryBultos: "+qryBultos.sql());
      if (!qryBultos.exec()) {
        var msg = "genEdiEmbalajes: ";
        msg += sys.translate("ERROR: Fall� la consulta");
        msg += '\n' + qryBultos.sql();
        //sys.errorPopup(msg);
        debug(msg);
        return msg;
      }

      while (qryBultos.next()) {
        ++numEmb;

        indentPos = flfactppal.iface.pub_cerosIzquierda(1, 9);
        txt += ediIface.pub_formatValueEdi(idAlb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(2, 9);
        txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(3, 9);
        txt += ediIface.pub_formatValueEdi(numEmb, fields[indentPos], objEdi);
	 
        indentPos = flfactppal.iface.pub_cerosIzquierda(4, 9);
        txt += ediIface.pub_formatValueEdi(numEmbPadre, fields[indentPos], objEdi);
		 	
        indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
        txt += ediIface.pub_formatValueEdi("1", fields[indentPos], objEdi);
		  	
        indentPos = flfactppal.iface.pub_cerosIzquierda(6, 9);
        txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);
        indentPos = flfactppal.iface.pub_cerosIzquierda(7, 9);
        txt += ediIface.pub_formatValueEdi("", fields[indentPos], objEdi);

        indentPos = flfactppal.iface.pub_cerosIzquierda(8, 9);
        txt += ediIface.pub_formatValueEdi(qryBultos.value(0), fields[indentPos], objEdi);

        txt += flfactppal.iface.pub_espaciosDerecha("", 237);

        var idLinea = qryBultos.value(1);
        var sscc1 = "3" + codEmpEAN +
                    flfactppal.iface.pub_cerosIzquierda(idLinea, 9);
        sscc1 += _i.digitoControl(sscc1);
        txt += flfactppal.iface.pub_espaciosDerecha(sscc1, 35);

		  txt += flfactppal.iface.pub_espaciosDerecha("", 178);	
		  indentPos = flfactppal.iface.pub_cerosIzquierda(5, 9);
        txt += ediIface.pub_formatValueEdi("1", fields[indentPos], objEdi);
			
			
        txt += flfactppal.iface.pub_espaciosDerecha("", 117);

        AQSql.update("em_detallelineapacking",
                     ["lineaembalajeedi"], [numEmb],
                     "idlineadetalle=" + idLinea);
        txt += "\r\n";
      }

    }

    AQUtil.setProgress(++p);
  }

  var workDir = "u:/edicom";
  var curSet = new AQSqlCursor("edi_settings");
  curSet.select("");
  if (curSet.first())
    workDir = curSet.valueBuffer("workdir");
  if (!fileName || fileName == "")
    fileName = objEdi.cod;
  var filePath = workDir + "/" + fileName + ".txt";

  var file = new QFile(filePath);
  if (!file.open(File.WriteOnly)) {
    var msg = file.errorString();
    //sys.errorPopup(msg);
    debug(msg);
    return msg;
  }

  var ts = new QTextStream(file.ioDevice());
  ts.opIn(txt);
  file.close();

  debug(
    sys.translate("Fichero EDI generado en:\n") +
    filePath
  );

  AQUtil.destroyProgressDialog();

  return filePath;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
