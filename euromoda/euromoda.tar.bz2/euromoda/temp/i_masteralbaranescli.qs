
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function tbnAlbaranTrans_clicked() {
		return this.ctx.euromoda_tbnAlbaranTrans_clicked();
	}
	function obtenerParamInformeAT() {
		return this.ctx.euromoda_obtenerParamInformeAT();
	}
	function tbnEtiquetas_clicked() {
		return this.ctx.euromoda_tbnEtiquetas_clicked();
	}
	function lanzaEtiquetas(q, oParam) {
    return this.ctx.euromoda_lanzaEtiquetas(q, oParam);
  }
	function imprimirMembrete_clicked() {
		return this.ctx.euromoda_imprimirMembrete_clicked();
	}
	function obtenerParamInforme() {
		return this.ctx.euromoda_obtenerParamInforme();
	}
	function tbnAlbInternacionalMem_clicked() {
		return this.ctx.euromoda_tbnAlbInternacionalMem_clicked();
	}
	function obtenerParamInformeAI() {
		return this.ctx.euromoda_obtenerParamInformeAI();
	}
	function tbnAlbInternacional_clicked() {
		return this.ctx.euromoda_tbnAlbInternacional_clicked();
	}	
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_lanzaEtiquetas(q, oParam) {
		return this.lanzaEtiquetas(q, oParam);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	
	connect (this.child("tbnAlbaranTrans"), "clicked()", _i, "tbnAlbaranTrans_clicked()");
	connect (this.child("tbnEtiquetas"), "clicked()", _i, "tbnEtiquetas_clicked()");
	connect (this.child("tbnImprimirMembrete"), "clicked()", _i, "imprimirMembrete_clicked()");
	connect (this.child("tbnAlbInternacionalMem"), "clicked()", _i, "tbnAlbInternacionalMem_clicked()");
	connect (this.child("tbnAlbInternacional"), "clicked()", _i, "tbnAlbInternacional_clicked()");
	if (cursor.action() == "i_resalbaranescli") {
		if(this.child("tbnImprimirMembrete")) {
			this.child("tbnImprimirMembrete").close();
		}
		if(this.child("tbnAlbInternacionalMem")) {
			this.child("tbnAlbInternacionalMem").close();
		}
		if(this.child("tbnAlbInternacional")) {
			this.child("tbnAlbInternacional").close();
		}
		
	}
}

function euromoda_tbnAlbaranTrans_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var pI = _i.obtenerParamInformeAT();
  if (!pI) {
    return; 
  }

  flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

function euromoda_obtenerParamInformeAT()
{
  var cursor = this.cursor();
  var oP = flfactinfo.iface.pub_dameParamInforme();
  oP.nombreInforme = "i_albaranescli_trans";
  return oP;
}

function euromoda_tbnEtiquetas_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  //var pI = _i.obtenerParamInformeEti();
//   if (!pI) {
//     return; 
//   }
  
  var q = flfactinfo.iface.pub_establecerConsulta(cursor, "i_eti_albaranescli");
  if (!q) {
		return false;
	}
	_i.lanzaEtiquetas(q);

  //flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

function euromoda_lanzaEtiquetas(q, oParam)
{
// 	var qryLineas = new FLSqlQuery();
// 	with (qryLineas) {
// 		setTablesList("albaranescli");
// 		setSelect("a.nombrecliente, a.direccion, a.ciudad, a.provincia, t.nombre, a.bultos, a.fecha, e.nombre, e.direccion, e.telefono, e.fax, e.codpostal, e.ciudad, e.provincia");
// 		setFrom("empresa e, albaranescli a LEFT OUTER JOIN proveedores t ON a.codagencia = t.codproveedor");
// 		setWhere("a.idalbaran = " + idAlbaran);
// 		setForwardOnly(true);
// 	}
	if (!q.exec()) {
		MessageBox.warning(sys.translate("Error al ejecutar la consulta"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	debug(q.sql());
	var xmlKD = new FLDomDocument;
	xmlKD.setContent("<!DOCTYPE KUGAR_DATA><KugarData/>");
	var eRow:FLDomElement;
	var bultos, bulto;
	while (q.next()) {
    bultos = q.value("albaranescli.bultos");
    if (bultos == 0) {
			continue;
      //MessageBox.information(sys.translate("El albar�n no tiene bultos asociados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      //return;
    }
		for (var i = 0; i < bultos; i++) {
			bulto = i + 1;
			eRow = xmlKD.createElement("Row");
			eRow.setAttribute("estaciondest", sys.translate("ESTACI�N DE DESTINO: %1").arg(q.value("albaranescli.ciudad")));
			eRow.setAttribute("nombredest", sys.translate("CONSIGNATARIO: %1").arg(q.value("albaranescli.nombrecliente")));
			eRow.setAttribute("direcciondest", sys.translate("DOMICILIO: %1").arg(q.value("albaranescli.direccion")));
			eRow.setAttribute("ciudaddest", sys.translate("POBLACION: %1.").arg(q.value("albaranescli.ciudad")));
			eRow.setAttribute("provinciadest", sys.translate("PROVINCIA: %1").arg(q.value("albaranescli.provincia")));
			eRow.setAttribute("remitido", sys.translate("REMITIDO POR: %1").arg(q.value("proveedores.nombre")));
			eRow.setAttribute("bultosfecha", sys.translate("N� DE BULTOS: %1 / %2.   FECHA: %3").arg(bulto).arg(bultos).arg(AQUtil.dateAMDtoDMA(q.value("albaranescli.fecha"))));
			eRow.setAttribute("empresa", q.value("empresa.nombre"));
			eRow.setAttribute("direccionemp", q.value("empresa.direccion"));
			eRow.setAttribute("telefonoemp", sys.translate("Tel. %1 - Fax. %2").arg(q.value("empresa.telefono")).arg(q.value("empresa.fax")));
			eRow.setAttribute("ciudademp", sys.translate("%1 %2 (%3)").arg(q.value("empresa.codpostal")).arg(q.value("empresa.ciudad")).arg(q.value("empresa.provincia")));
			eRow.setAttribute("level", 0);
			xmlKD.firstChild().appendChild(eRow);
		}
	}
debug(xmlKD.toString(4));

// 	var rptViewer = new FLReportViewer();
// 	rptViewer.setReportData(xmlKD);
	if (oParam) {
		var rptViewer = oParam.rptViewer;
		var flags = (oParam.display ? rptViewer.Display : 0) | (oParam.append ? rptViewer.Append : 0) | (oParam.pageBreak ? rptViewer.PageBreak : 0);
    rptViewer.setReportData(xmlKD);
		rptViewer.setReportTemplate("i_eti_albaranescli");
		rptViewer.renderReport(false, false, flags);
debug("oParam.display ? " + oParam.display);
		if (!oParam.display) {
			return true;
		}
debug("Exec");
		rptViewer.exec();
	} else {
		var rptViewer = new FLReportViewer();
		rptViewer.setReportTemplate("i_eti_albaranescli");
		rptViewer.setReportData(xmlKD);
		rptViewer.renderReport();
debug("Exec 2");
		rptViewer.exec();
	}
}

function euromoda_imprimirMembrete_clicked()
{
	var _i = this.iface;
	flfactinfo.iface.pub_ponerMembrete(true);
	_i.__lanzar();
	flfactinfo.iface.pub_ponerMembrete(false);
}

function euromoda_obtenerParamInforme()
{
	var _i = this.iface;
	var oP = _i.__obtenerParamInforme();
	var orderBy = oP.orderBy;
	if(!orderBy || orderBy == "") {
		orderBy = "albaranescli.idalbaran";
	}
	oP.orderBy = orderBy + ",lineasalbaranescli.numlinea,lineasalbaranescli.idpedido,movistock.codlote";
	
  	return oP;
}

function euromoda_tbnAlbInternacionalMem_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	flfactinfo.iface.pub_ponerMembrete(true);
	var pI = _i.obtenerParamInformeAI();
	if (!pI) {
		return; 
	}

	flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

function euromoda_obtenerParamInformeAI()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var oP = _i.obtenerParamInforme();
	oP.nombreReport = "i_albaranescli_int";
	return oP;
}

function euromoda_tbnAlbInternacional_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	flfactinfo.iface.pub_ponerMembrete(false);
	var pI = _i.obtenerParamInformeAI();
	if (!pI) {
		return; 
	}

	flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
