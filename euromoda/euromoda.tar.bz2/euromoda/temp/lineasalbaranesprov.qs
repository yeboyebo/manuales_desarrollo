
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
class euromoda extends prod {
    function euromoda( context ) { prod ( context ); }
    function init() {
		return this.ctx.euromoda_init();
	}
	function pbnInsertarPlantillaTexto_clicked() {
    return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
  }
   function modoTexto() {
    return this.ctx.euromoda_modoTexto();
  }
  function bufferChanged(fN:String) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function validaArticuloFabricado() {
    return this.ctx.euromoda_validaArticuloFabricado();
  }
  function dameFiltroReferencia() {
		return this.ctx.euromoda_dameFiltroReferencia();
	}
	function tbnQuitarPartida_clicked() {
    	return this.ctx.euromoda_tbnQuitarPartida_clicked();
   }
   function recalcularCantidad() {
    	return this.ctx.euromoda_recalcularCantidad();
   }
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!cursor.cursorRelation()) { /// Por si se abre desde distribuci�n a confecciones
		this.close();
		return;
	}
  
	_i.__init();
	
	connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");
  	connect(this.child("tbnQuitarPartida"), "clicked()", _i, "tbnQuitarPartida_clicked");
	switch (cursor.modeAccess()) {
	case cursor.Edit: {
		sys.disableObj(this, "fdbTipoConcepto");
		break;
		}
		case cursor.Insert: {
			if(cursor.cursorRelation().valueBuffer("codformato") && cursor.cursorRelation().valueBuffer("codformato") != "") {
				this.child("fdbCodFormato").setValue(cursor.cursorRelation().valueBuffer("codformato"));
			}
			break
		}
	}
	sys.disableObj(this, "fdbCodPartida");
	
	formRecordlineaspedidosprov.iface.pub_habilitaTipoConcepto(this);
	_i.modoTexto();
	

	
}


function euromoda_pbnInsertarPlantillaTexto_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbTexto").setValue(texto);
}

function euromoda_modoTexto()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
  case "Texto": {
      this.child("fdbReferencia").setValue("");
      this.child("fdbCantidad").setValue(0);
      this.child("fdbPvpUnitario").setValue(0);
      this.child("fdbCodImpuesto").setValue("");
      this.child("groupBox7").enabled = false;
      this.child("groupBox8").enabled = false;
      this.child("groupBox9").enabled = false;
      this.child("groupBox10").enabled = false;
      this.child("tbwLinea").setTabEnabled("texto", true);
      this.child("tbwLinea").showPage("texto");
      this.child("fdbTexto").setFocus();
      break;
    }
  default: {
      this.child("groupBox7").enabled = true;
      this.child("groupBox8").enabled = true;
      this.child("groupBox9").enabled = true;
      this.child("groupBox10").enabled = true;
      this.child("tbwLinea").showPage("movimientos");
      this.child("tbwLinea").setTabEnabled("texto", false);
      this.child("fdbTexto").setValue("");
      break;
    }
  }
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "tipoconcepto": {
      _i.__bufferChanged(fN);
			_i.modoTexto();
      break;
    }
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_validaArticuloFabricado()
{
	return true;
}

function euromoda_dameFiltroReferencia()
{
	var _i = this.iface;
// 	var f = _i.__dameFiltroReferencia();
	var f = "NOT debaja";
	return f;
}

function euromoda_tbnQuitarPartida_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var curPartidas = this.child("tdbPartidas").cursor();
	
	curPartidas.setModeAccess(cursor.Edit);
	curPartidas.refreshBuffer();
	
	curPartidas.setNull("idlinea");
	
	if(!curPartidas.commitBuffer()) {
		return false;
	}
	
	cursor.setValueBuffer("cantidad",_i.recalcularCantidad());
}

function euromoda_recalcularCantidad()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	return AQUtil.sqlSelect("lotesstock","sum(candisponible)","idlinea = " + cursor.valueBuffer("idlinea")); //pineboo 21-08-2019
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
