/**************************************************************************
                 em_reservasstock.qs  -  description
                             -------------------
    begin                : mar abr 23 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
    function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var cIDM, cIDP, cIDL, cSEL, cCOD, cLIN, cNOM, cORD, cLOT, cCAN, cREX, cRPR, cRAF, cFMX, cMAN, cUSU;
	var tblReservas_;
	var cNoSel_, cSel_;
	var cRes_, cResPR_, cAFaltas_, cMan_;
	var estado_, fOrigen_;
	var cRREX, cRRPR, cFAF, cORA;
	var cFAFaltas_, cNoFAFaltas_;
	var accion_;
	
	function oficial( context ) { interna( context ); } 
	function tblReservas_currentChanged(row, col) {
		return this.ctx.oficial_tblReservas_currentChanged(row, col);
	}
	function poblarTabla() {
		return this.ctx.oficial_poblarTabla();
	}
	function poblarTablaProducto() {
		return this.ctx.oficial_poblarTablaProducto();
	}
	function poblarTablaMP() {
		return this.ctx.oficial_poblarTablaMP();
	}
	function generarTabla() {
		return this.ctx.oficial_generarTabla();
	}
	function calculaTotales() {
		return this.ctx.oficial_calculaTotales();
	}
	function coloreaFila(f, clr) {
		return this.ctx.oficial_coloreaFila(f, clr);
	}
	function colores() {
		return this.ctx.oficial_colores();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function tbnCancelar_clicked() {
		return this.ctx.oficial_tbnCancelar_clicked();
	}
	function labelXEstado() {
		return this.ctx.oficial_labelXEstado();
	}
	function tbnLiberar_clicked() {
		return this.ctx.oficial_tbnLiberar_clicked();
	}
	function tbnAsociar_clicked() {
		return this.ctx.oficial_tbnAsociar_clicked();
	}
	function tbnForzarAFaltas_clicked() {
		return this.ctx.oficial_tbnForzarAFaltas_clicked();
	}
	function asociar(f, idMovPteRx) {
		return this.ctx.oficial_asociar(f, idMovPteRx);
	}
	function liberar(f) {
		return this.ctx.oficial_liberar(f);
	}
	function cambiaReservasMS(fOrigen, fDestino) {
		return this.ctx.oficial_cambiaReservasMS(fOrigen, fDestino);
	}
	function creaReservaPedidoLote(idLineaPC, codLote, cantidad) {
		return this.ctx.oficial_creaReservaPedidoLote(idLineaPC, codLote, cantidad);
	}
	function tbnVerMovimiento_clicked() {
		return this.ctx.oficial_tbnVerMovimiento_clicked();
	}
	function tblReservas_currentChanged(f, c) {
		return this.ctx.oficial_tblReservas_currentChanged(f, c);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.tblReservas_ = this.child("tblReservas");
	var cursor = this.cursor();

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked()");
	connect(_i.tblReservas_, "doubleClicked(int, int)", _i, "tblReservas_currentChanged");
	connect(this.child("tbnCancelar"), "clicked()", _i, "tbnCancelar_clicked");
	connect(this.child("tbnLiberar"), "clicked()", _i, "tbnLiberar_clicked");
	connect(this.child("tbnAsociar"), "clicked()", _i, "tbnAsociar_clicked");
	connect(this.child("tbnForzarAFaltas"), "clicked()", _i, "tbnForzarAFaltas_clicked");
	connect(this.child("tbnVerMovimiento"), "clicked()", _i, "tbnVerMovimiento_clicked");
	
	var hoy = new Date();	
	_i.colores();
	_i.generarTabla();
	_i.poblarTabla();	
	_i.estado_ = "Reposo";
	_i.labelXEstado();	

}

function interna_validateForm()
{
	var _i = this.iface;
	if(_i.accion_ && _i.accion_ == "em_pedidosptes") {
		if(!formem_pedidosptes.iface.compruebaUsuario("reservasStock")) { 
			return false;	
		}
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
// function oficial_datosLinea()
// {
// 	var _i = this.iface;
// 	var curLP = formRecordlineaspedidoscli.cursor();
// 	if (!curLP) {
// 		return;
// 	}
// 	this.child("lblDesReferencia").text = curLP.valueBuffer("referencia") + " - " + curLP.valueBuffer("descripcion");
// 	_i.canLinea = curLP.valueBuffer("cantidad");
// 	this.child("lblCantidad").text = sys.translate("Cantidad %1").arg(_i.canLinea);
// 	this.child("dedServLinea").date = curLP.valueBuffer("fechaservicio");
// 	this.child("dedServPedido").date = curLP.cursorRelation().valueBuffer("fechaservicio");
// }

function oficial_tblReservas_currentChanged(f, c)
{
	var _i = this.iface;
	
	switch (c) 	{
		case _i.cMAN: {
			var idMov = _i.tblReservas_.text(f, _i.cIDM);
			var curMov = new FLSqlCursor("movistock");
			curMov.setActivatedCommitActions(false);
			curMov.setActivatedCheckIntegrity(false);
			curMov.select("idmovimiento = " + idMov);
			if (!curMov.first()) {
				return false;
			}
			curMov.setModeAccess(curMov.Edit);
			curMov.refreshBuffer();
			curMov.setValueBuffer("reservamanual", !curMov.valueBuffer("reservamanual"));
			curMov.setValueBuffer("usuarioreserva", sys.nameUser());
			if (!curMov.commitBuffer()) {
				return false;
			}
			_i.calculaTotales();
			_i.poblarTabla();
			break;
		}
		case _i.cCAN:
		case _i.cREX:
		case _i.cRPR:
		case _i.cRAF: {
			if (_i.estado_ == "Reposo") {
				_i.fOrigen_ = f;
				_i.estado_ = "Enviando";
				_i.labelXEstado();
			} else {
				if (!_i.cambiaReservasMS(_i.fOrigen_, f)) {
					return false;
				}
				_i.calculaTotales();
				_i.poblarTabla();
				_i.estado_ = "Reposo";
				_i.labelXEstado();
			}
			break;
		}
	}
}


function oficial_calculaTotales()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var idStock = cursor.valueBuffer("idstock");
	flfactalma.iface.pub_revisarReservasStock(idStock);
}

function oficial_bufferChanged(fN:String)
{
	switch (fN) {
		case "codejercicio": {
			break;
		}
	}
}

function oficial_poblarTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (cursor.action()) {
		case "em_reservasstock": {
			_i.poblarTablaProducto();
			break;
		}
		case "em_reservasstockmp": {
			_i.poblarTablaMP();
			break;
		}
	}
}
function oficial_poblarTablaProducto()
{
		var _i = this.iface;
	var cursor = this.cursor();
	var idStock = cursor.valueBuffer("idstock");
	var q = new FLSqlQuery;
	q.setSelect("ms.cantidad, ms.idmovimiento, ms.reservaex, ms.reservapr, ms.reservaaf, ms.reservamanual, ms.usuarioreserva, ms.forzarafaltas, lp.idlinea, lp.numlinea, p.idpedido, p.codigo, p.nombrecliente, ls.codlote, op.codorden, p.fechaservicio, op.nombrecliente, op.fechaentrega, ms.idmovproducto, ms.codloteprod");
	q.setFrom("movistock ms LEFT OUTER JOIN lineaspedidoscli lp ON ms.idlineapc = lp.idlinea LEFT OUTER JOIN pedidoscli p ON lp.idpedido = p.idpedido LEFT OUTER JOIN lotesstock ls ON ms.codloteprod = ls.codlote LEFT OUTER JOIN pr_ordenesproduccion op ON ls.codordenproduccion = op.codorden");
	q.setWhere("ms.idstock = " + idStock + " AND ms.estado = 'PTE' AND ms.cantidad < 0 ORDER BY p.codigo, lp.numlinea, op.codorden	");
	q.setForwardOnly(true);
	debug("consulta1: "+q.sql());
	if (!q.exec()) {
		return false;
	}
	var f = 0, clrClasif;
	_i.tblReservas_.setNumRows(0);
	while (q.next()) {
		_i.tblReservas_.insertRows(f);
		_i.tblReservas_.setText(f, _i.cIDM, q.value("ms.idmovimiento"));
		
		var idPedido = q.value("p.idpedido");
		var idLinea = q.value("lp.idlinea");
		var codPedido = q.value("p.codigo");
		var numLinea = q.value("lp.numlinea");
		var nombreCliente = q.value("p.nombrecliente") ? q.value("p.nombrecliente") : q.value("op.nombrecliente");
		if(!q.value("ms.idlineapc") || q.value("ms.idlineapc") =="") {
			var idMovProducto = q.value("ms.idmovproducto");
			var qProd = new FLSqlQuery;
			qProd.setSelect("lp.idlinea, lp.numlinea, p.idpedido, p.codigo, p.nombrecliente, p.fechaservicio");
			qProd.setFrom("movistock mp LEFT OUTER JOIN lineaspedidoscli lp ON mp.idlineapc = lp.idlinea LEFT OUTER JOIN pedidoscli p ON lp.idpedido = p.idpedido");
			qProd.setWhere("mp.idmovimiento = " + idMovProducto);
			qProd.setForwardOnly(true);
			debug("consulta1: "+qProd.sql());
			if (!qProd.exec()) {
				return false;
			}
			if(qProd.first()) {
				idPedido = qProd.value("p.idpedido");
				idLinea = qProd.value("lp.idlinea");
				codPedido = qProd.value("p.codigo");
				numLinea = qProd.value("lp.numlinea");
				nombreCliente = "(CONSUMOS LINEA) "+qProd.value("p.nombrecliente");
			}
		
		} 
		var codLoteProd = q.value("ms.codloteprod");
		
		if (codLoteProd && codLoteProd != "") {
			debug("****************************************************");
			nombreCliente = q.value("op.codorden");
			
			debug("nombreCliente: "+nombreCliente);
			debug("****************************************************");
		}
		_i.tblReservas_.setText(f, _i.cIDP, idPedido);
		_i.tblReservas_.setText(f, _i.cIDL, idLinea);
		_i.tblReservas_.setText(f, _i.cCOD, codPedido);
		_i.tblReservas_.setText(f, _i.cLIN, numLinea);
		_i.tblReservas_.setText(f, _i.cNOM, nombreCliente);
		//_i.tblReservas_.setText(f, _i.cORD, q.value("op.codorden"));
//		_i.tblReservas_.setText(f, _i.cLOT, q.value("ls.codlote"));
		_i.tblReservas_.setText(f, _i.cCAN, q.value("ms.cantidad") * -1);
		if (q.value("ms.reservaex") > 0) {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cREX, _i.cRes_);
		} else {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cREX, _i.cNoSel_);
		}
		_i.tblReservas_.setText(f, _i.cREX, q.value("ms.reservaex"));
		if (q.value("ms.reservapr") > 0) {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cRPR, _i.cResPR_);
		} else {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cRPR, _i.cNoSel_);
		}
		_i.tblReservas_.setText(f, _i.cRPR, q.value("ms.reservapr"));
		if (q.value("ms.reservaaf") > 0) {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cRAF, _i.cAFaltas_);
		} else {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cRAF, _i.cNoSel_);
		}
		_i.tblReservas_.setText(f, _i.cRAF, q.value("ms.reservaaf"));
		_i.tblReservas_.setCellBackgroundColor(f, _i.cMAN, q.value("ms.reservamanual") ? _i.cMan_ : _i.cNoSel_);
		_i.tblReservas_.setText(f, _i.cMAN, q.value("ms.reservamanual") ? "S�" : " ")	;
		_i.tblReservas_.setText(f, _i.cUSU, q.value("ms.usuarioreserva"));
		_i.tblReservas_.setText(f, _i.cFMX, q.value("p.fechaservicio") ? AQUtil.dateAMDtoDMA(q.value("p.fechaservicio")) : AQUtil.dateAMDtoDMA(q.value("op.fechaentrega")));

		if (q.value("ms.forzarafaltas")) {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cFAF, _i.cFAFaltas_);
		} else {
			_i.tblReservas_.setCellBackgroundColor(f, _i.cFAF, _i.cNoFAFaltas_);
		}
		_i.tblReservas_.setText(f, _i.cFAF, q.value("ms.forzarafaltas") ? "S" : "N");

		var qResIni = new AQSqlQuery();
		qResIni.setSelect("rpr.cantidad,mpr.estado,ls.codordenproduccion, rpr.id, lspp.codordenproduccion, lsconf.codordenproduccion");
		qResIni.setFrom("movistock ms INNER JOIN em_reservaspterx rpr ON ms.idmovimiento = rpr.idmovreserva INNER JOIN movistock mpr ON rpr.idmovpterx = mpr.idmovimiento LEFT OUTER JOIN em_reservaslotepedido rlp ON rpr.idrlp = rlp.idrlp LEFT OUTER JOIN lotesstock ls ON rlp.codlote = ls.codlote LEFT OUTER JOIN lotesstock lsconf ON mpr.codlote = lsconf.codlote LEFT OUTER JOIN lineaspedidosprov lp ON mpr.idlineapp = lp.idlinea LEFT OUTER JOIN lotesstock lspp ON lp.codloteprod = lspp.codlote");
		qResIni.setWhere("rpr.idmovreserva = " + q.value("ms.idmovimiento") + " AND mpr.cantidad > 0 AND ms.estado = 'PTE' AND mpr.estado IN ('HECHO', 'PTE')");
		if (!qResIni.exec()) {
			return false;
		}
		debug(qResIni.sql());
		/*
		_i.tblReservas_.setText(f, _i.cRREX, 0);
		_i.tblReservas_.setText(f, _i.cRRPR, 0);
		*/
		var canRREx = 0, canRRPR = 0;
		var ordenes = "", asignadas = "", codOrden;
		while (qResIni.next()) {
			if (qResIni.value("rlp.idrlp")) {
				codOrden = qResIni.value("ls.codordenproduccion");
				if (codOrden && codOrden != "") {
					asignadas += asignadas == "" ? "" : ", ";
					asignadas += codOrden;
				}
			} else {
				codOrden = qResIni.value("lspp.codordenproduccion");
				if (!codOrden || codOrden == "") {
					codOrden = qResIni.value("lsconf.codordenproduccion");
				}
				if (codOrden && codOrden != "") {
					ordenes += ordenes == "" ? "" : ", ";
					ordenes += codOrden;
				}
			}
			if (qResIni.value("mpr.estado") == "PTE") {
				canRRPR += parseFloat(qResIni.value("cantidad"));
			} else {
				canRREx += parseFloat(qResIni.value("cantidad"));
			}
		}
		_i.tblReservas_.setCellBackgroundColor(f, _i.cRRPR, canRRPR > 0 ? _i.cResPR_ : _i.cNoSel_);
		_i.tblReservas_.setText(f, _i.cRRPR, isNaN(canRRPR) ? 0 : canRRPR);
		
		_i.tblReservas_.setCellBackgroundColor(f, _i.cRREX, canRREx > 0 ? _i.cRes_ : _i.cNoSel_);
		_i.tblReservas_.setText(f, _i.cRREX, isNaN(canRREx) ? 0 : canRREx);
		
		_i.tblReservas_.setText(f, _i.cORD, ordenes);
		_i.tblReservas_.setText(f, _i.cORA, asignadas);
/*
				if (qResIni.value("SUM(rpr.cantidad)") > 0) {
					_i.tblReservas_.setCellBackgroundColor(f, _i.cRRPR, _i.cResPR_);
				} else {
					_i.tblReservas_.setCellBackgroundColor(f, _i.cRRPR, _i.cNoSel_);
				}
				_i.tblReservas_.setText(f, _i.cRRPR, qResIni.value("SUM(rpr.cantidad)"));
			} else {
				if (qResIni.value("SUM(rpr.cantidad)") > 0) {
					_i.tblReservas_.setCellBackgroundColor(f, _i.cRREX, _i.cRes_);
				} else {
					_i.tblReservas_.setCellBackgroundColor(f, _i.cRREX, _i.cNoSel_);
				}
				_i.tblReservas_.setText(f, _i.cRREX, qResIni.value("SUM(rpr.cantidad)"));
			}
		}
		*/
		f++;                                                      
	}
}

function oficial_generarTabla()
{
	var _i = this.iface;
	var cab = "", s = "*";
	var c = 0;
	cab += sys.translate("IdM");
	cab += s;
	_i.cIDM = c++;
	cab += sys.translate("IdP");
	cab += s;
	_i.cIDP = c++;
	cab += sys.translate("IdL");
	cab += s;
	_i.cIDL = c++;
	cab += sys.translate("Sel");
	cab += s;
	_i.cSEL = c++;
	cab += sys.translate("Pedido");
	cab += s;
	_i.cCOD = c++;
	cab += sys.translate("L�nea");
	cab += s;
	_i.cLIN = c++;
	cab += sys.translate("Cliente");
	cab += s;
	_i.cNOM = c++;
	cab += sys.translate("Orden");
	cab += s;
	_i.cORD = c++;
	cab += sys.translate("O.Asignada");
	cab += s;
	_i.cORA = c++;
	cab += sys.translate("F.Tope");
	cab += s;
	_i.cFMX = c++;
	cab += sys.translate("Cantidad");
	cab += s;
	_i.cCAN = c++;
	cab += sys.translate("R.Existencias");
	cab += s;
	_i.cREX = c++;
	cab += sys.translate("R.Pte.Recibir");
	cab += s;
	_i.cRPR = c++;
	cab += sys.translate("R.A Faltas");
	cab += s;
	_i.cRAF = c++;

	cab += sys.translate("R.R.Ex.");
	cab += s;
	_i.cRREX = c++;
	cab += sys.translate("R.R.Pte.R.");
	cab += s;
	_i.cRRPR = c++;
	cab += sys.translate("Forzado AF");
	cab += s;
	_i.cFAF = c++;

	cab += sys.translate("Prioritario");
	cab += s;
	_i.cMAN = c++;
	cab += sys.translate("Usuario");
	cab += s;
	_i.cUSU = c++;
	
	_i.tblReservas_.setNumCols(c);
	_i.tblReservas_.hideColumn(_i.cIDM);
	_i.tblReservas_.hideColumn(_i.cIDP);
	_i.tblReservas_.hideColumn(_i.cIDL);
	_i.tblReservas_.hideColumn(_i.cSEL);
	_i.tblReservas_.setColumnWidth(_i.cSEL, 30);
	_i.tblReservas_.setColumnWidth(_i.cCOD, 100);
	_i.tblReservas_.setColumnWidth(_i.cLIN, 50);
	_i.tblReservas_.setColumnWidth(_i.cNOM, 300);
	_i.tblReservas_.setColumnWidth(_i.cORD, 100);
	_i.tblReservas_.setColumnWidth(_i.cORA, 100);
	_i.tblReservas_.setColumnWidth(_i.cCAN, 80);
	_i.tblReservas_.setColumnWidth(_i.cREX, 80);
	_i.tblReservas_.setColumnWidth(_i.cRPR, 80);
	_i.tblReservas_.setColumnWidth(_i.cRAF, 80);

	_i.tblReservas_.setColumnWidth(_i.cRREX, 80);
	_i.tblReservas_.setColumnWidth(_i.cRRPR, 80);
	_i.tblReservas_.setColumnWidth(_i.cFAF, 80);

	_i.tblReservas_.setColumnWidth(_i.cFMX, 90);
	_i.tblReservas_.setColumnWidth(_i.cMAN, 80);
	_i.tblReservas_.setColumnWidth(_i.cUSU, 80);
	_i.tblReservas_.setColumnLabels(s, cab);
}

function oficial_coloreaFila(f, clr)
{
	var _i = this.iface;
	var nC = _i.tblReservas_.numCols();
	for (var c = 0; c < nC; c++) {
		_i.tblReservas_.setCellBackgroundColor(f, c, clr);
		_i.tblReservas_.setText(f, c,_i.tblReservas_.text(f, c));
	}
}

function oficial_colores()
{
	var _i = this.iface;
	
	_i.cNoSel_ = new Color("white");
	_i.cSel_ = new Color("green");	
	_i.cRes_ = new Color("green");
	_i.cResPR_ = new Color("yellow");
	_i.cAFaltas_ = new Color("red");	
	_i.cMan_ = new Color("cyan");
	_i.cFAFaltas_ = new Color("cyan");
	_i.cNoFAFaltas_ = new Color("green");
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
// 	if (!_i.validarForm()) {
// 		return;
// 	}
// 	if (!_i.cambiaFechas()) {
// 		return false;
// 	}
	var cursor = this.cursor();
// 	var fS = this.child("dedServLineaSel").date;
// 	cursor.setValueBuffer("fechaservicio", fS);
	this.accept();
}

function oficial_tbnCancelar_clicked()
{
	var _i = this.iface;
	_i.estado_ = "Reposo";
	_i.labelXEstado();
}

function oficial_labelXEstado()
{
	var _i = this.iface;
	if (_i.estado_ == "Reposo") {
		this.child("lblMensaje").paletteForegroundColor = new Color(flfactppal.iface.pub_dameColor("tinta_verde"));
		sys.setObjText(this, "lblMensaje", sys.translate("Seleccione el movimiento de stock ORIGEN"));
	} else {
		this.child("lblMensaje").paletteForegroundColor = new Color("red");		
		sys.setObjText(this, "lblMensaje", sys.translate("Seleccione el movimiento de stock DESTINO"));
	}
}

function oficial_tbnLiberar_clicked()
{
	var _i = this.iface;
	
	var t = _i.tblReservas_;
	
	_i.estado_ = "Reposo";
	_i.labelXEstado();
	
	var f = t.currentRow();
	if (f < 0) {
		return;
	}
	
	if (!_i.liberar(f)) {
		return;
	}
	_i.calculaTotales();
	_i.poblarTabla();
}

function oficial_tbnAsociar_clicked()
{
	var _i = this.iface;
	
	var t = _i.tblReservas_;
	var valorT = _i.tblReservas_.text;

	_i.estado_ = "Reposo";
	_i.labelXEstado();
	
	var f = t.currentRow();
	if (f < 0) {
		return;
	}
	var idMovimiento = valorT(f, _i.cIDM);

	var fPteRx = new FLFormSearchDB("movistock");
	var curPteRx = fPteRx.cursor();
	var cursor = this.cursor();
	var referencia = cursor.valueBuffer("referencia");

	curPteRx.setMainFilter("referencia = '" + referencia + "' AND cantidad > 0 AND estado = 'PTE' AND NOT em_merma AND cantidad > enreserva AND codlote IS NOT NULL");
	debug("SELECT idmovimiento FROM movistock WHERE " + "referencia = '" + referencia + "' AND cantidad > 0 AND estado = 'PTE' AND NOT em_merma AND cantidad > enreserva AND codlote IS NOT NULL");
	fPteRx.setMainWidget();
	var idMovPteRx = fPteRx.exec("idmovimiento");
	if (!idMovPteRx) {
		return;
	}

	if (!_i.asociar(f, idMovPteRx)) {
		return;
	}
	_i.calculaTotales();
	_i.poblarTabla();
	
}

function oficial_tbnForzarAFaltas_clicked()
{
	var _i = this.iface;
	
	var t = _i.tblReservas_;
	var valorT = _i.tblReservas_.text;
	
	_i.estado_ = "Reposo";
	_i.labelXEstado();
	
	var f = t.currentRow();
	if (f < 0) {
		return;
	}
	if (valorT(f, _i.cRREX) != 0 || valorT(f, _i.cRRPR) != 0) {
		var res = MessageBox.warning(sys.translate("Esta acci�n eliminar� la relaci�n de esta l�nea con su orden o pedido de compras asociado.\n�Desea continuar?"), MessageBox.Yes, MessageBox.No);
		if (res != MessageBox.Yes) {
			return;
		}
	}
	var idLineaPC = valorT(f, _i.cIDL);
	var forzado = valorT(f, _i.cFAF);
	if (!AQSql.update("lineaspedidoscli", ["forzarafaltas"], [!(forzado == "S")], "idlinea = " + idLineaPC)) {
		sys.warnMsgBox(sys.translate("Error al modificar la l�nea de pedido %1").arg(idLineaPC));
		return false;
	}
	_i.calculaTotales();
	_i.poblarTabla();
}

function oficial_asociar(f, idMovPteRx)
{
	var _i = this.iface;

	var t = _i.tblReservas_;
	var valorT = _i.tblReservas_.text;
	
	var canAsignable = valorT(f, _i.cCAN) - valorT(f, _i.cRREX) - valorT(f, _i.cRREX);
debug("canAsignable " + canAsignable);
	var idMovimiento = valorT(f, _i.cIDM);
	var q = new AQSqlQuery;
	q.setSelect("ms.cantidad, ms.enreserva, ms.codlote");
	q.setFrom("movistock ms");
	q.setWhere("ms.idmovimiento = " + idMovPteRx);
	if (!q.exec()) {
		return false;
	}
	debug(q.sql());
	var idLineaPC = valorT(f, _i.cIDL);
	if (!q.first()) {
		return false;
	}
	var cantidad = q.value("ms.cantidad") - q.value("ms.enreserva");
	if (isNaN(cantidad) || cantidad <= 0) {
		return false;
	}
	
	cantidad = Math.min(cantidad, canAsignable);
	if (!_i.creaReservaPedidoLote(idLineaPC, q.value("ms.codlote"), cantidad)) {
		return false;
	}

	return true;
}

function oficial_liberar(f)
{
	var _i = this.iface;

	var t = _i.tblReservas_;
	var valorT = _i.tblReservas_.text;

	var idMovimiento = valorT(f, _i.cIDM);
	var q = new AQSqlQuery;
	q.setSelect("rpr.id, rpr.cantidad, rpr.idmovpterx, rpr.idrlp, rlp.idlineapc");
	q.setFrom("em_reservaspterx rpr LEFT OUTER JOIN em_reservaslotepedido rlp ON rpr.idrlp = rlp.idrlp");
	q.setWhere("rpr.idmovreserva = " + idMovimiento + "");
	if (!q.exec()) {
		return false;
	}
	debug(q.sql());
	var idLineaPC;
	while (q.next()) {
		idLineaPC = q.value("rlp.idlineapc");
		if (idLineaPC) {
			if (!AQSql.del("em_reservaslotepedido", "idrlp = " + q.value("rpr.idrlp"))) {
				sys.warnMsgBox(sys.translate("Error al borrar la reserva asociada a la l�nea de pedido %1").arg(idLineaPC));
				return false;
			}
		} else {
			if (!AQSql.del("em_reservaspterx", "id = " + q.value("rpr.id"))) {
				sys.warnMsgBox(sys.translate("Error al borrar la reserva de movimiento de stock %1").arg(q.value("rpr.id")));
				return false;
			}
		}
	}
	return true;
}

function oficial_cambiaReservasMS(fOrigen, fDestino)
{
	var _i = this.iface;
	var valorT = _i.tblReservas_.text;
	
	var idMovOrigen = valorT(fOrigen, _i.cIDM);
	var idMovDestino = valorT(fDestino, _i.cIDM);
	var idLineaPCDestino = AQUtil.sqlSelect("movistock", "idlineapc", "idmovimiento = " + idMovDestino);
	if (!idLineaPCDestino) {
		sys.warnMsgBox(sys.translate("El movimiento de reserva %1 no est� ligado a una l�nea de pedido de cliente").arg(idMovDestino));
		return false;
	}
	var curRPR = new FLSqlCursor("em_reservaspterx");

	var aEnviar = Math.min((valorT(fDestino,  _i.cCAN) - valorT(fDestino,  _i.cREX)), valorT(fOrigen, _i.cRREX));
	if (aEnviar <= 0) {
		sys.warnMsgBox(sys.translate("No hay reservas que transferir"));
		return false;
	}
	var qREX = new AQSqlQuery;
	qREX.setSelect("rpr.id, rpr.cantidad, rpr.idmovpterx, rpr.idrlp, mres.idlineapc, mres.idmovimiento, rlp.codlote, rlp.cantidad");
	qREX.setFrom("em_reservaspterx rpr INNER JOIN movistock mpterx ON rpr.idmovpterx = mpterx.idmovimiento INNER JOIN movistock mres ON rpr.idmovreserva = mres.idmovimiento LEFT OUTER JOIN em_reservaslotepedido rlp ON rpr.idrlp = rlp.idrlp");
	qREX.setWhere("rpr.idmovreserva = " + idMovOrigen + " AND mpterx.estado = 'HECHO'");
	if (!qREX.exec()) {
		return false;
	}
	var porEnviar = aEnviar;
	var canEnviable;
	var enviado = 0;
	var curRLP = new FLSqlCursor("em_reservaslotepedido");
	
	while (qREX.next() && porEnviar > 0) {
		canEnviable = qREX.value("rpr.cantidad");
		/*
		curRPR.select("id = " + qREX.value("rpr.id"));
		if (!curRPR.first()) {
			return false;
		}
		curRPR.setModeAccess(curRPR.Edit);
		curRPR.refreshBuffer();
		*/
		var idLineaPCOrigen = qREX.value("mres.idlineapc");
		if (!idLineaPCOrigen) {
			sys.warnMsgBox(sys.translate("El movimiento de reserva %1 no est� ligado a una l�nea de pedido de cliente").arg(qREX.value("mres.idmovimiento")));
			return false;
		}

		if (canEnviable <= porEnviar) {
			if (!AQSql.del("em_reservaslotepedido", "idrlp = " + qREX.value("rpr.idrlp"))) {
				sys.warnMsgBox(sys.translate("Error al borrar la reserva asociada a la l�nea de pedido %1").arg(idLineaPCOrigen));
				return false;
			}
			if (!_i.creaReservaPedidoLote(idLineaPCDestino, qREX.value("rlp.codlote"), qREX.value("rlp.cantidad"))) {
				return false;
			}
			/*
			curRPR.setValueBuffer("idmovreserva", idMovDestino);
			if (!curRPR.commitBuffer()) {
				return false;
			}
			*/
			porEnviar -= canEnviable;
			enviado += parseFloat(canEnviable);
		} else {
			/*
			curRPR.setValueBuffer("cantidad", canEnviable - porEnviar);
			if (!curRPR.commitBuffer()) {
				return false;
			}
			if (!flfactalma.iface.creaReservaStock(idMovDestino, qREX.value("rpr.idmovpterx"), porEnviar)) {
				return false;
			}
			*/
			if (!AQSql.del("em_reservaslotepedido", "idrlp = " + qREX.value("rpr.idrlp"))) {
				sys.warnMsgBox(sys.translate("Error al borrar la reserva asociada a la l�nea de pedido %1").arg(idLineaPCOrigen));
				return false;
			}
			if (!_i.creaReservaPedidoLote(idLineaPCOrigen, qREX.value("rlp.codlote"), canEnviable - porEnviar)) {
				return false;
			}
			if (!_i.creaReservaPedidoLote(idLineaPCDestino, qREX.value("rlp.codlote"), porEnviar)) {
				return false;
			}
			porEnviar = 0;
			enviado = porEnviar;
		}
	}
	var aDevolver = (parseFloat(valorT(fDestino, _i.cRREX)) + parseFloat(valorT(fDestino, _i.cRRPR)) + parseFloat(enviado)) - valorT(fDestino, _i.cCAN);
debug("aDevolver " + aDevolver + " " + parseFloat(valorT(fDestino, _i.cRREX)) + " " + parseFloat(valorT(fDestino, _i.cRRPR)) + " " + parseFloat(enviado) + " - " + valorT(fDestino, _i.cCAN));
	if (aDevolver > 0) {
		var qRPR = new AQSqlQuery;
		qRPR.setSelect("rpr.id, rpr.cantidad, rpr.idmovpterx, rpr.idrlp, mres.idlineapc, mres.idmovimiento, rlp.codlote, rlp.cantidad");
		qRPR.setFrom("em_reservaspterx rpr INNER JOIN movistock mpterx ON rpr.idmovpterx = mpterx.idmovimiento INNER JOIN movistock mres ON rpr.idmovreserva = mres.idmovimiento LEFT OUTER JOIN em_reservaslotepedido rlp ON rpr.idrlp = rlp.idrlp");
		qRPR.setWhere("rpr.idmovreserva = " + idMovDestino + " AND mpterx.estado = 'PTE'");
		if (!qRPR.exec()) {
			return false;
		}
debug(qRPR.sql());
		var porDevolver = aDevolver;
		var canDevolvible;
		while (qRPR.next() && porDevolver > 0) {
			canDevolvible = qRPR.value("rpr.cantidad");
debug("canDevolvible " + canDevolvible);
			/*
			curRPR.select("id = " + qRPR.value("rpr.id"));
			if (!curRPR.first()) {
				return false;
			}
			curRPR.setModeAccess(curRPR.Edit);
			curRPR.refreshBuffer();
			*/
			var idLineaPCOrigen = qRPR.value("mres.idlineapc");
			if (!idLineaPCOrigen) {
				sys.warnMsgBox(sys.translate("El movimiento de reserva %1 no est� ligado a una l�nea de pedido de cliente").arg(qREX.value("mres.idmovimiento")));
				return false;
			}
			if (canDevolvible <= porDevolver) {
				if (!AQSql.del("em_reservaslotepedido", "idrlp = " + qRPR.value("rpr.idrlp"))) {
					sys.warnMsgBox(sys.translate("Error al borrar la reserva asociada a la l�nea de pedido %1").arg(idLineaPCDestino));
					return false;
				}
				if (!_i.creaReservaPedidoLote(idLineaPCOrigen, qRPR.value("rlp.codlote"), qRPR.value("rlp.cantidad"))) {
					return false;
				}
				/*
				curRPR.setValueBuffer("idmovreserva", idMovOrigen);
				if (!curRPR.commitBuffer()) {
					return false;
				}
				*/
				porDevolver -= canDevolvible;
			} else {
				/*
				curRPR.setValueBuffer("cantidad", canDevolvible - porDevolver);
				if (!curRPR.commitBuffer()) {
					return false;
				}
				if (!flfactalma.iface.creaReservaStock(idMovOrigen, qRPR.value("rpr.idmovpterx"), porDevolver)) {
					return false;
				}
				*/
				debug("Borrando donde " + "idrlp = " + qRPR.value("rpr.idrlp"));
				if (!AQSql.del("em_reservaslotepedido", "idrlp = " + qRPR.value("rpr.idrlp"))) {
				debug("fallo");
					sys.warnMsgBox(sys.translate("Error al borrar la reserva asociada a la l�nea de pedido %1").arg(idLineaPCDestino));
					return false;
				}
				debug("OK");
				if (!_i.creaReservaPedidoLote(idLineaPCDestino, qRPR.value("rlp.codlote"), canDevolvible - porDevolver)) {
					return false;
				}
				debug("OK 2");
				if (!_i.creaReservaPedidoLote(idLineaPCOrigen, qRPR.value("rlp.codlote"), porDevolver)) {
					return false;
				}
				debug("OK 3");

				porDevolver = 0;
			}
debug("porDevolver " + porDevolver);
		}
	}
	var curMS = new FLSqlCursor("movistock");
	curMS.select("idmovimiento = " + idMovOrigen);
	curMS.setActivatedCommitActions(false);
	curMS.setActivatedCheckIntegrity(false);
	if (!curMS.first()) {
		return false;
	}
	curMS.setModeAccess(curMS.Edit);
	curMS.refreshBuffer();
	//curMS.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMS));
	curMS.setValueBuffer("usuarioreserva", sys.nameUser());
	if (!curMS.commitBuffer()) {
		return false;
	}
	curMS.select("idmovimiento = " + idMovDestino);
	if (!curMS.first()) {
		return false;
	}
	curMS.setModeAccess(curMS.Edit);
	curMS.refreshBuffer();
	//curMS.setValueBuffer("enreserva", formRecordmovistock.iface.commonCalculateField("enreservares", curMS));
	curMS.setValueBuffer("usuarioreserva", sys.nameUser());
	if (!curMS.commitBuffer()) {
		return false;
	}
	return true;
}

function oficial_creaReservaPedidoLote(idLineaPC, codLote, cantidad)
{
	var _i = this.iface;
	
	var curRLP = new FLSqlCursor("em_reservaslotepedido");
	curRLP.setModeAccess(curRLP.Insert);
	curRLP.refreshBuffer();
	curRLP.setValueBuffer("idlineapc", idLineaPC);
	curRLP.setValueBuffer("cantidad", cantidad);
	curRLP.setValueBuffer("codlote", codLote);
	if (!curRLP.commitBuffer()) {
		sys.warnMsgBox(sys.translate("Error al crear la reserva asociada a la l�nea de pedido %1").arg(idLineaPCOrigen));
		return false;
	}
	var idRlp = curRLP.valueBuffer("idrlp");
	if (!flfactalma.iface.creaReservasPedidoProd(idLineaPC, codLote, cantidad, idRlp)) {
		return false;
	}
	return true;
}

function oficial_tbnVerMovimiento_clicked()
{
	var _i = this.iface;

	var t = _i.tblReservas_;
	var f = t.currentRow();
	if (f < 0) {
		return;
	}

	var valorT = _i.tblReservas_.text;

	var idMovimiento = valorT(f, _i.cIDM);

	var curMS = new FLSqlCursor("movistock");
	curMS.select("idmovimiento = " + idMovimiento);
	if (!curMS.first()) {
		return;
	}
	curMS.browseRecord();
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
