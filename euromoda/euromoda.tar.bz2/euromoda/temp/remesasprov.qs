
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function tbnVencimiento_clicked() {
		return this.ctx.euromoda_tbnVencimiento_clicked();
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	this.child("tbwRecibos").setTabEnabled("pagos", false);
	
	connect(this.child("tbnVencimiento"), "clicked()", _i, "tbnVencimiento_clicked");
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	
	switch (fN) {
		case "estado": {
			if (_i.pagoIndirecto_) {
				valor = _i.__commonCalculateField(fN, cursor);
			} else if (_i.pagoDiferido_) {
				if (AQUtil.sqlSelect("pagosdevolprov p INNER JOIN recibosprov r ON p.idrecibo = r.idrecibo", "p.tipo", "p.idremesa = " + cursor.valueBuffer("idremesa") + " AND p.tipo = 'Remesado' AND (r.em_idsaldopartida IS NULL OR r.em_idsaldopartida = 0) AND (r.idanticipo IS NULL OR r.idanticipo = 0)", "recibosprov")) {
					valor = "Emitida";
				} else {
					valor = "Pagada";
				}
			} else {
				valor = _i.__commonCalculateField(fN, cursor);
			}
			break;
		}
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function euromoda_tbnVencimiento_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var curR = this.child("tdbRecibos").cursor();
	var idRecibo = curR.valueBuffer("idrecibo");
	if (!idRecibo) {
		return;
	}
	var dialog = new Dialog;
	dialog.okButtonText = sys.translate("Aceptar");
	dialog.cancelButtonText = sys.translate("Cancelar");

	var dedFecha = new DateEdit;
	dedFecha.label = sys.translate("Fecha de vencimineto");
	dedFecha.date = new Date;
	dialog.add(dedFecha);
	if ( !dialog.exec() ) {
		return false;
	}	
	var fecha = dedFecha.date;
	if (!AQSql.update("recibosprov", ["fechav"], [fecha], "idrecibo = " + idRecibo)) {
		return false;
	}
	this.child("tdbRecibos").refresh();
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
