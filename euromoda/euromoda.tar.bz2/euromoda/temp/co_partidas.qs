
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends modelo303
{
  function euromoda(context)
  {
    modelo303(context);
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function calculateField(fN)
  {
    return this.ctx.euromoda_calculateField(fN);
  }
  function habilitaPorTipoSubcuenta(miForm, tipo, fdbCodCliente, fdbCodProveedor, fdbCodCuentaBanco, fdbCodActivo)
  {
    return this.ctx.euromoda_habilitaPorTipoSubcuenta(miForm, tipo, fdbCodCliente, fdbCodProveedor, fdbCodCuentaBanco, fdbCodActivo);
  }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function validateForm()
  {
    return this.ctx.euromoda_validateForm();
  }
  function controlBloqueoProv()
  {
    return this.ctx.euromoda_controlBloqueoProv();
  }
  function compruebaTipoSubcuenta()
  {
    return this.ctx.euromoda_compruebaTipoSubcuenta();
  }
  function compruebaSaldoPartida()
  {
    return this.ctx.euromoda_compruebaSaldoPartida();
  }
  function acceptedForm()
  {
    return this.ctx.euromoda_acceptedForm();
  }
  function calculaDesAuxContra()
  {
    return this.ctx.euromoda_calculaDesAuxContra();
  }
  function calculaDesAux()
  {
    return this.ctx.euromoda_calculaDesAux();
  }
  function commonCalculateField(fN, cursor)
  {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function controlSubcuentaOK()
  {
    return this.ctx.euromoda_controlSubcuentaOK();
  }
  function controlPartidaCancelada(cursor) {
    return this.ctx.euromoda_controlPartidaCancelada(cursor);
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx
{
  function pubEuromoda(context)
  {
    ifaceCtx(context);
  }
  function pub_habilitaPorTipoSubcuenta(miForm, tipo, fdbCodCliente, fdbCodProveedor, fdbCodCuentaBanco, fdbCodActivo) {
    return this.habilitaPorTipoSubcuenta(miForm, tipo, fdbCodCliente, fdbCodProveedor, fdbCodCuentaBanco, fdbCodActivo);
  }
  function pub_commonCalculateField(fN, cursor) {
    return this.commonCalculateField(fN, cursor);
  }
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;

  _i.__init();
  
  var cursor = this.cursor();
  _i.habilitaPorTipoSubcuenta(this);
  _i.habilitaPorTipoSubcuenta(this, cursor.valueBuffer("tipocontrapartida"), "fdbCodClienteContra", "fdbCodProveedorContra", "fdbCodCuentaBancoContra", "fdbCodActivoContra");
  
	this.child("tdbSaldoPartidas1").setReadOnly(true);
	this.child("tdbSaldoPartidas2").setReadOnly(true);
  _i.calculaDesAux();
  _i.calculaDesAuxContra();  
  _i.controlPartidaCancelada(cursor)
}



function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
    case "tiposubcuenta": {
      _i.habilitaPorTipoSubcuenta(this);
      break;
    }
    case "tipocontrapartida": {
      _i.habilitaPorTipoSubcuenta(this, cursor.valueBuffer("tipocontrapartida"), "fdbCodClienteContra", "fdbCodProveedorContra", "fdbCodCuentaBancoContra", "fdbCodActivoContra");
      break;
    }
    case "codcliente": {
      sys.setObjText(this, "fdbIdSubcuenta",  _i.calculateField("idsubcuentacliente"));
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxCliente");
      break;
    }
    case "codclientecontra": {
      sys.setObjText(this, "fdbIdContrapartida",  _i.calculateField("idcontrapartidacliente"));
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxClienteContra");
      break;
    }
    case "codproveedor": {
      sys.setObjText(this, "fdbIdSubcuenta",  _i.calculateField("idsubcuentaproveedor"));
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxProveedor");
      break;
    }
    case "codproveedorcontra": {
      sys.setObjText(this, "fdbIdContrapartida",  _i.calculateField("idcontrapartidaproveedor"));
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxProveedorContra");
      break;
    }
    case "codcuentabanco": {
      sys.setObjText(this, "fdbIdSubcuenta",  _i.calculateField("idsubcuentabanco"));
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxCuentaBanco");
      break;
    }
    case "codcuentabancocontra": {
      sys.setObjText(this, "fdbIdContrapartida",  _i.calculateField("idcontrapartidabanco"));
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxCuentaBancoContra");
      break;
    }
    case "codactivo": {
      sys.setObjText(this, "fdbIdSubcuenta",  _i.calculateField("idsubcuentaactivo"));
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxActivo");
      break;
    }
    case "codactivocontra": {
      sys.setObjText(this, "fdbIdContrapartida",  _i.calculateField("idcontrapartidaactivo"));
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxActivoContra");
      break;
    }
    default: {
      _i.__bufferChanged(fN);
    }
  }
}


function euromoda_habilitaPorTipoSubcuenta(miForm, tipo, fdbCodCliente, fdbCodProveedor, fdbCodCuentaBanco, fdbCodActivo)
{
  var _i = this.iface;
  fdbCodCliente = fdbCodCliente ? fdbCodCliente : "fdbCodCliente";
  fdbCodProveedor = fdbCodProveedor ? fdbCodProveedor : "fdbCodProveedor";
  fdbCodCuentaBanco = fdbCodCuentaBanco ? fdbCodCuentaBanco  : "fdbCodCuentaBanco";
  fdbCodActivo = fdbCodActivo ? fdbCodActivo : "fdbCodActivo";
  tipo = tipo ? tipo : miForm.cursor().valueBuffer("tiposubcuenta");
  switch (tipo) {
    case "Proveedor": {
      sys.setObjText(miForm, fdbCodCliente, "");
      miForm.child(fdbCodCliente).close();
      sys.setObjText(miForm, fdbCodCuentaBanco, "");
      miForm.child(fdbCodCuentaBanco).close();
      sys.setObjText(miForm, fdbCodActivo, "");
      miForm.child(fdbCodActivo).close();
      miForm.child(fdbCodProveedor).obj().show();
      break;
    }
    case "Banco": {
      sys.setObjText(miForm, fdbCodCliente, "");
      miForm.child(fdbCodCliente).close();
      sys.setObjText(miForm, fdbCodProveedor, "");
      miForm.child(fdbCodProveedor).close();
      sys.setObjText(miForm, fdbCodActivo, "");
      miForm.child(fdbCodActivo).close();
      miForm.child(fdbCodCuentaBanco).obj().show();
      break;
    }
    case "Activo": {
      sys.setObjText(miForm, fdbCodCliente, "");
      miForm.child(fdbCodCliente).close();
      sys.setObjText(miForm, fdbCodProveedor, "");
      miForm.child(fdbCodProveedor).close();
      sys.setObjText(miForm, fdbCodCuentaBanco, "");
      miForm.child(fdbCodCuentaBanco).close();
      miForm.child(fdbCodActivo).obj().show();
      break;
    }
    default: {
      sys.setObjText(miForm, fdbCodProveedor, "");
      miForm.child(fdbCodProveedor).close();
      sys.setObjText(miForm, fdbCodCuentaBanco, "");
      miForm.child(fdbCodCuentaBanco).close();
      sys.setObjText(miForm, fdbCodActivo, "");
      miForm.child(fdbCodActivo).close();
      miForm.child(fdbCodCliente).obj().show();
      break;
    }
  }
  if (tipo == "Cliente" || tipo == "Proveedor") {
    var cursor = miForm.cursor();
    if (cursor.valueBuffer("idpartida")) {
	    if (AQUtil.sqlSelect("co_em_saldopartidas", "idsaldo", "(idpartida1 = " + cursor.valueBuffer("idpartida") + " OR idpartida2 = " + cursor.valueBuffer("idpartida") + ")")) {
	        sys.disableObj(miForm, "fdbCodSubcuenta");
	        sys.disableObj(miForm, "fdbIdSubcuenta");
	    }
	}
  }
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
    case "lblDesAuxCliente": {
      var codCliente = cursor.valueBuffer("codcliente");
      valor = AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + codCliente + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxClienteContra": {
      var codCliente = cursor.valueBuffer("codclientecontra");
      valor = AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + codCliente + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxProveedor": {
      var codProveedor = cursor.valueBuffer("codproveedor");
      valor = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxProveedorContra": {
      var codProveedor = cursor.valueBuffer("codproveedorcontra");
      valor = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxCuentaBanco": {
      var codCuenta = cursor.valueBuffer("codcuentabanco");
      valor = AQUtil.sqlSelect("cuentasbanco", "descripcion", "codcuenta = '" + codCuenta + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxCuentaBancoContra": {
      var codCuenta = cursor.valueBuffer("codcuentabancocontra");
      valor = AQUtil.sqlSelect("cuentasbanco", "descripcion", "codcuenta = '" + codCuenta + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxActivo": {
      var codActivo = cursor.valueBuffer("codactivo");
      valor = AQUtil.sqlSelect("co_amortizaciones", "elemento", "codamortizacion = '" + codActivo + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "lblDesAuxActivoContra": {
      var codActivo = cursor.valueBuffer("codactivocontra");
      valor = AQUtil.sqlSelect("co_amortizaciones", "elemento", "codamortizacion = '" + codActivo + "'");
      if (!valor) {
        valor = "";
      }
      break;
    }
    case "idsubcuentacliente": {
      valor = "";
      var codCliente = cursor.valueBuffer("codcliente");
      if (!AQUtil.sqlSelect("clientes", "codcliente", "codcliente = '" + codCliente + "'")) {
        break;
      }
      var oAux = new Object;
      oAux.codejercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var oDC = flfactppal.iface.pub_datosCtaCliente(codCliente, oAux);
      if (oDC) {
        valor = oDC.idsubcuenta;
      }
      break;
    }
    case "idcontrapartidacliente": {
      valor = "";
      var codCliente = cursor.valueBuffer("codclientecontra");
      if (!AQUtil.sqlSelect("clientes", "codcliente", "codcliente = '" + codCliente + "'")) {
        break;
      }
      var oAux = new Object;
      oAux.codejercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var oDC = flfactppal.iface.pub_datosCtaCliente(codCliente, oAux);
      if (oDC) {
        valor = oDC.idsubcuenta;
      }
      break;
    }
    case "idsubcuentaproveedor": {
      valor = "";
      var codProveedor = cursor.valueBuffer("codproveedor");
      if (!AQUtil.sqlSelect("proveedores", "codproveedor", "codproveedor = '" + codProveedor + "'")) {
        break;
      }
      var oAux = new Object;
      oAux.codejercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var oDC = flfactppal.iface.pub_datosCtaProveedor(codProveedor, oAux);
      if (oDC) {
        valor = oDC.idsubcuenta;
      }
      break;
    }
    case "idcontrapartidaproveedor": {
      valor = "";
      var codProveedor = cursor.valueBuffer("codproveedorcontra");
      if (!AQUtil.sqlSelect("proveedores", "codproveedor", "codproveedor = '" + codProveedor + "'")) {
        break;
      }
      var oAux = new Object;
      oAux.codejercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var oDC = flfactppal.iface.pub_datosCtaProveedor(codProveedor, oAux);
      if (oDC) {
        valor = oDC.idsubcuenta;
      }
      break;
    }
    case "idsubcuentabanco": {
      valor = "";
      var codCuenta = cursor.valueBuffer("codcuentabanco");
      var codEjercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var codSubcuenta = AQUtil.sqlSelect("cuentasbanco", "codsubcuenta", "codcuenta = '" + codCuenta + "'");
      if (codSubcuenta) {
        valor = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
      }
      break;
    }
    case "idcontrapartidabanco": {
      valor = "";
      var codCuenta = cursor.valueBuffer("codcuentabancocontra");
      var codEjercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var codSubcuenta = AQUtil.sqlSelect("cuentasbanco", "codsubcuenta", "codcuenta = '" + codCuenta + "'");
      if (codSubcuenta) {
        valor = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
      }
      break;
    }
    case "idsubcuentaactivo": {
      valor = "";
      var codActivo = cursor.valueBuffer("codactivo");
      var codEjercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var codSubcuenta = AQUtil.sqlSelect("co_amortizaciones a INNER JOIN co_gruposcontablesamo gca ON a.codgrupocontableamo = gca.codgrupo", "gca.codsubcuentaele", "a.codamortizacion = '" + codActivo + "'", "co_amortizaciones,co_gruposcontablesamo");
      if (codSubcuenta) {
        valor = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
      }
      break;
    }
    case "idcontrapartidaactivo": {
      valor = "";
      var codActivo = cursor.valueBuffer("codactivocontra");
      var codEjercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var codSubcuenta = AQUtil.sqlSelect("co_amortizaciones a INNER JOIN co_gruposcontablesamo gca ON a.codgrupocontableamo = gca.codgrupo", "gca.codsubcuentaele", "a.codamortizacion = '" + codActivo + "'", "co_amortizaciones,co_gruposcontablesamo");
      if (codSubcuenta) {
        valor = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
      }
      break;
    }
    default: {
      valor = _i.__calculateField(fN);
    }
  }
  return valor;
}

function euromoda_validateForm()
{
  var _i = this.iface;
  if (!_i.controlBloqueoProv()) {
    return false;
  }
  if (!_i.compruebaTipoSubcuenta()) {
    return false;
  }
  if (!_i.compruebaSaldoPartida()) {
    return false;
  }
  if (!_i.controlSubcuentaOK()) {
    return false;
  }
  if (!_i.__validateForm()) {
    return false;
  }
  return true;
}

function euromoda_controlSubcuentaOK()
{
    var cursor = this.cursor();
    var codSubcuenta = cursor.valueBuffer("codsubcuenta");
    var idSubcuenta = cursor.valueBuffer("idsubcuenta");
    debug("idsubcuenta" + idSubcuenta);
    var codEjercicio = cursor.cursorRelation().valueBuffer("codejercicio");
    debug("select idsubcuenta from co_subcuentas where codejercicio = '" + codEjercicio + "' AND codsubcuenta = '" + codSubcuenta + "'");
    if (codSubcuenta && codSubcuenta != "" && (!idSubcuenta || idSubcuenta == 0 || idSubcuenta != AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codejercicio = '" + codEjercicio + "' AND codsubcuenta = '" + codSubcuenta + "'"))) {
        sys.warnMsgBox(sys.translate("La subcuenta indicada no existe en la tabla de subcuentas o no ha sido ligada correctamente"));
        return false;
    }
     /** Quitado porque en el caso de moneda extranjera pone a cero debe y haber
    cursor.setValueBuffer("idsubcuenta", 0);
    cursor.setValueBuffer("idsubcuenta", idSubcuenta);
    */
    return true;
}

function euromoda_controlBloqueoProv()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.valueBuffer("tiposubcuenta") != "Proveedor") {
		return true;
	}
	var codProveedor = cursor.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
      return false;
    }
  }
	return true;
}

function euromoda_compruebaTipoSubcuenta()
{
  var _i = this.iface;
  var cursor = this.cursor();

  if (cursor.isNull("tiposubcuenta") && cursor.valueBuffer("codcliente") != "") {
    cursor.setValueBuffer("tiposubcuenta", "Cliente");
  }
  return true;
}

function euromoda_compruebaSaldoPartida()
{
	var _i = this.iface;
  var cursor = this.cursor();
	if (!(cursor.cursorRelation() && cursor.cursorRelation().table() == "co_asientos" && cursor.cursorRelation().valueBuffer("editable"))) {
		return true;
	}
	if (cursor.valueBuffer("codcliente") || cursor.valueBuffer("codproveedor")) {
		cursor.setValueBuffer("importependientemig", cursor.valueBuffer("debe") - cursor.valueBuffer("haber"));
		cursor.setValueBuffer("importependiente", _i.calculateField("importependiente"));
	}
	return true;
}

function euromoda_acceptedForm()
{
  return;
}

function euromoda_calculaDesAux()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tiposubcuenta")) {
  case "Proveedor": {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxProveedor");
      break;
    }
  case "Banco": {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxCuentaBanco");
      break;
    }
  case "Activo": {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxActivo");
      break;
    }
  default: {
      this.child("lblDesAux").text = _i.calculateField("lblDesAuxCliente");
      break;
    }
  }
}

function euromoda_calculaDesAuxContra()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipocontrapartida")) {
  case "Proveedor": {
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxProveedorContra");
      break;
    }
  case "Banco": {
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxCuentaBancoContra");
      break;
    }
  case "Activo": {
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxActivoContra");
      break;
    }
  default: {
      this.child("lblDesAuxContra").text = _i.calculateField("lblDesAuxClienteContra");
      break;
    }
  }
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "importependiente": {
			var importeMig = cursor.valueBuffer("importependientemig");
			importeMig = isNaN(importeMig) ? 0 : importeMig;
			var saldos1 = parseFloat(AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idpartida1 = " + cursor.valueBuffer("idpartida")));
			saldos1 = isNaN(saldos1) ? 0 : saldos1;
			var saldos2 = parseFloat(AQUtil.sqlSelect("co_em_saldopartidas", "SUM(importe)", "idpartida2 = " + cursor.valueBuffer("idpartida")));
			saldos2 = isNaN(saldos2) ? 0 : saldos2;
			valor = importeMig - saldos1 + saldos2;
			//debug("valor1: " + valor);
			//debug("tipo: " + typeof(valor));
            // Modificado por devolver valores de saldo muy peque�os y parcheandolos mal. Por ejemplo para el n�mero -9.094947017729282E-13 (con 13 nulos despues de coma) devuelva -9. Fecha 28-02-2023 
            valor = (isNaN(valor) || Math.abs(valor) < 0.03) ? 0 : valor;
            //debug("valor2: " + valor);
            //debug("tipo2: " + typeof(valor));
			break;
		}
		default: {
			try { valor = _i.__commonCalculateField(fN, cursor); } catch(e) {}
		}
	}
	return valor;
}

function euromoda_controlPartidaCancelada(cursor)
{
    var _i = this.iface;
    var idPartida = cursor.valueBuffer("idpartida");
    var idSaldo = AQUtil.sqlSelect("co_em_saldopartidas","idsaldo","idpartida1 = " + idPartida + " or idpartida2 = " + idPartida);

    if(idSaldo && idSaldo != "") {
        this.child("gbxEuromoda").setEnabled(false);        
    } else {
        this.child("gbxEuromoda").setEnabled(true);   
    }

    //query que saca los distintos por cliente
    //select p.codcliente, s.codcliente, p.idpartida,p.idasiento,a.numero,a.codejercicio from co_em_saldopartidas s inner join co_partidas p on (s.idpartida1 = p.idpartida or s.idpartida2 = p.idpartida) inner join co_asientos a on a.idasiento = p.idasiento where p.tiposubcuenta = 'Cliente' and p.codcliente <> s.codcliente;
    //select p.codproveedor, s.codproveedor, p.idpartida,p.idasiento,a.numero,a.codejercicio from co_em_saldopartidas s inner join co_partidas p on (s.idpartida1 = p.idpartida or s.idpartida2 = p.idpartida) inner join co_asientos a on a.idasiento = p.idasiento where p.tiposubcuenta = 'Proveedor' and p.codproveedor <> s.codproveedor;


}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
