/***************************************************************************
                 em_articuloscli.qs  -  description
                             -------------------
    begin                : mie oct 22 2014
    copyright            : (C) 2014 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() { 
		this.ctx.interna_init(); 
	}
	function calculateField(fN) { 
		return this.ctx.interna_calculateField(fN); 
	}
	function validateForm() {
	     return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	
	function oficial( context ) { 
		interna( context ); 
	} 
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}	
	function traducirDescripcion() {
		return this.ctx.oficial_traducirDescripcion();
	}	
	function estableceRefArticulo(ref, codBarras) {
		return this.ctx.oficial_estableceRefArticulo(ref, codBarras);
	}
	function ledEmArticulo_returnPressed() {
		return this.ctx.oficial_ledEmArticulo_returnPressed();
	}
	function validacionEsq(fN) {
		return this.ctx.oficial_validacionEsq(fN);
	}
	function validaCampoEsquema(fN, valor, tipoEsquema) {
		return this.ctx.oficial_validaCampoEsquema(fN, valor, tipoEsquema);
	}
	function formateaValorEsquema(fN, valor, esquema) {
		return this.ctx.oficial_formateaValorEsquema(fN, valor, esquema);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
	function pub_validaCampoEsquema(fN, valor, tipoEsquema) {
		return this.validaCampoEsquema(fN, valor, tipoEsquema);
	}
	function pub_formateaValorEsquema(fN, valor, esquema) {
		return this.formateaValorEsquema(fN, valor, esquema);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");	
	connect(this.child("pbnTradDescripcion"), "clicked()", _i, "traducirDescripcion");
	connect(this.child("ledEmArticulo"), "returnPressed()", _i, "ledEmArticulo_returnPressed");
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;	
	if(!_i.validacionEsq()) {	
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_commonCalculateField(fN, cursor)
{
debug("oficial_commonCalculateField " + fN);
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "pvpdto": {
      	var pvpBase = cursor.valueBuffer("pvpbase");
			var dtoPor = cursor.valueBuffer("dtopor");
      	if (isNaN(pvpBase) || pvpBase == 0)  {
        		valor = 0;
	    	} else if (isNaN(dtoPor) || dtoPor == 0) {
	     		valor = pvpBase;
			} else {
        		valor = pvpBase - ((pvpBase * dtoPor) / 100);
      	}
      	break;
		}
		case "pvpsiniva": {
			var pvpDto = cursor.valueBuffer("pvpdto");
			var referencia = cursor.valueBuffer("referencia");
			var codCliente = cursor.valueBuffer("codcliente");
			var codImpuesto = AQUtil.sqlSelect("articulos", "codimpuesto", "referencia='" + referencia + "'");
			var codGrupoIvaNeg = AQUtil.sqlSelect("clientes", "codgrupoivaneg", "codcliente = '" + codCliente + "'");
			var fecha = new Date;
			var porcIva  = flfacturac.iface.pub_campoImpuesto("iva", codImpuesto, fecha, "cli", codGrupoIvaNeg);
			
			if (isNaN(pvpDto) || pvpDto == 0)  {
				valor = 0;
			} else if (isNaN(porcIva) || porcIva == 0) {
				valor = pvpDto;
			} else {
				valor = (100 * pvpDto) / (100 + parseFloat(porcIva))
			}
			break;
		}
		case "pvpeuromoda": {
			var dtoEmoda = cursor.valueBuffer("dtoemoda");
			var pvpSinIva = cursor.valueBuffer("pvpsiniva");
			if (isNaN(pvpSinIva) || pvpSinIva == 0)  {
				valor = 0;
			} else if (isNaN(dtoEmoda) || dtoEmoda == 0) {
				valor = pvpSinIva; 
			} else {
				valor = (parseFloat(pvpSinIva) * parseFloat(dtoEmoda)) / 100;
			}
			var esquema = AQUtil.sqlSelect("clientes", "em_tipoesqexpcat", "codcliente = '" + cursor.valueBuffer("codcliente") + "'");
			valor = _i.formateaValorEsquema("pvpeuromoda", valor, esquema);
			break;
		}
		default: {
		}
	}
			
	return valor;
}

function oficial_formateaValorEsquema(fN, valor, esquema)
{
	var cursor = this.cursor();
	var valorOut = valor;
	switch (esquema) {
		case "FLEX": {
			switch (fN) {
				case "pvpeuromoda": {
					valorOut = Math.round(valor * 100) / 100;
					debug("valorOut " + valorOut);
					valorOut = AQUtil.roundFieldValue(valorOut, "em_articuloscli", "pvpeuromoda");
					debug("valorOut Rouded " + valorOut);
					break;
				}
			}
			break;
		}
	}
	return valorOut;
}


function oficial_bufferChanged(fN)
{
debug("oficial_bufferChanged " + fN);
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "pvpbase": 
		case "dtopor": {
			 sys.setObjText(this, "fdbPvpDto", _i.calculateField("pvpdto"));
			 sys.setObjText(this, "fdbPvpSinIva", _i.calculateField("pvpsiniva"));
			 var valor = _i.calculateField("pvpeuromoda");
			 cursor.setValueBuffer("pvpeuromoda", valor);
			break;
		}
		case "dtoemoda": {
			 var valor = _i.calculateField("pvpeuromoda");
			 debug("valor antes de mostrar: "+valor);
			 cursor.setValueBuffer("pvpeuromoda", valor);
			break;
		}    
		default: {
		}
	}
}
function oficial_traducirDescripcion()
{
	return flfactppal.iface.pub_traducir("em_articuloscli", "descripcioncliente", this.cursor().valueBuffer("id"));
}

function oficial_ledEmArticulo_returnPressed()
{
	var _i = this.iface;
	
	var a = this.child("ledEmArticulo").text;
	if (!a || a == "") {
		return;
	}
	if (a.toString().startsWith(".")) {
		var barcode = a.toString().right(a.length - 1);
		if (barcode.length != 6) {
			sys.warnMsgBox(sys.translate("El dato de barcode debe contener 6 caracteres"));
			return;
		}
		var q = new AQSqlQuery;
		q.setSelect("referencia, codbarras, descripcion, codtamanoem, codcolorem");
		q.setFrom("articulos");
		q.setWhere("codbarras LIKE '%" + barcode + "' ORDER BY codbarras");
		if (!q.exec()) {
			return;
		}
		if (q.size() < 1) {
			sys.warnMsgBox(sys.translate("No hay ning�n c�digo de barras que finalice con el valor %1").arg(barcode));
		} else if (q.size() == 1) {
			if (!q.first()) {
				return false;
			}
			_i.estableceRefArticulo(q.value("referencia"), q.value("codbarras"));
		} else {
			var aOps = new Array;
			var aRefs = new Array;
			var aCodBs = new Array;
			while (q.next()) {
				aOps.push(sys.translate("CB: %1. Ref: %2. %3 - %4 - %5").arg(q.value("codbarras")).arg(q.value("referencia")).arg(q.value("descripcion")).arg(q.value("codtamanoem")).arg(q.value("codcolorem")));
				aRefs.push(q.value("referencia"));
				aCodBs.push(q.value("codbarras"));
			}
			var o = flfactppal.iface.pub_elegirOpcion(aOps, sys.translate("Seleccione art�culo"));
			if (o >= 0) {
				_i.estableceRefArticulo(aRefs[o], aCodBs[o]);
			}
		}
	} else {
		var ref = AQUtil.sqlSelect("articulos", "referencia", "UPPER(referencia) = '" + a.toString().toUpperCase() + "'");
		if (!ref || ref == "") {
			sys.warnMsgBox(sys.translate("No hay ning�n art��culo con la referencia %1").arg(a));
			return false;
		}
		var codbarras = AQUtil.sqlSelect("articulos", "codbarras", "UPPER(referencia) = '" + ref + "'");
		_i.estableceRefArticulo(ref, codbarras);
	}
}

function oficial_estableceRefArticulo(ref, codBarras)
{
	sys.setObjText(this, "fdbReferencia", ref);
	sys.setObjText(this, "fdbCodBarras", codBarras);
	this.child("fdbReferenciaCliente").setFocus();
	this.child("ledEmArticulo").text = "";
}
function oficial_validacionEsq()
{
     var _i = this.iface;
	var cursor = this.cursor();
	var codCliente = cursor.valueBuffer("codcliente");
	var tipoEsquema = AQUtil.sqlSelect("clientes", "em_tipoesqexpcat", "codcliente = '" + codCliente + "'");
	
	switch(tipoEsquema) {
		case "FLEX": {		
			if (!_i.validaCampoEsquema("pvpeuromoda", cursor.valueBuffer("pvpeuromoda"), tipoEsquema)) {
				return false;
			}
/*			if(!_i.validaEsqPvpEuromoda(cursor.valueBuffer("pvpeuromoda"),tipoEsquema)) {
				return false;
			}*/
			break;
		}	
		default: {		
		}
	}
	return true;
}

function oficial_validaCampoEsquema(fN, valor, tipoEsquema)
{
	switch (tipoEsquema) {
		case "FLEX": {
			switch (fN) {
				case "pvpeuromoda": {
					var valor1 = Math.round(valor * 100) * 10;
					var valor2 = Math.round(valor * 1000);
					if (Math.abs(valor1 - valor2) > 0.001) {
						sys.warnMsgBox(sys.translate("No se puede guardar el registro ya que para el tipo de esquema FLEX, el campo PVP Euromoda, debe de tener un 0 en el tercer decimal."));
						return false;			
					}
					break;
				}
			}
			break;
		}
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////
