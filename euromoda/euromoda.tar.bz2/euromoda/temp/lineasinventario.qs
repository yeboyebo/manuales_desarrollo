
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function informaCanIni() {
		return this.ctx.euromoda_informaCanIni();
	}
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__bufferChanged(fN);
	var curInv = cursor.cursorRelation();
	if(fN == "referencia"){
		if (!_i.informaCanIni()) {
			return false;
		}
	}
}

function euromoda_informaCanIni()
{
	debug("informaCanIni");
	var _i = this.iface;
	var cursor = this.cursor();
	if (cursor.modeAccess() != cursor.Insert) {
		return true;
	}
	var idStock = _i.calculateField("idstock");
	if (idStock) {
		cursor.setValueBuffer("idstock", idStock);		
		this.child("fdbCantidadIni").setValue(_i.calculateField("cantidadini"));	
	} else {	
		this.child("fdbCantidadIni").setValue(0);	
	}

	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
