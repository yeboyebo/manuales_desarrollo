/***************************************************************************
                            em_detallelineapacking.qs
                             -------------------
    begin                : mar jun 26 2012
    copyright            : (C) 2003-2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
	function calculateField(fN) { 
		return this.ctx.interna_calculateField(fN); 
	}
	function validateForm() { 
		return this.ctx.interna_validateForm(); 
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  function oficial(context)
  {
    interna(context);
  }
  function bufferChanged(fN)
  {
    this.ctx.oficial_bufferChanged(fN);
  }
  function valoresInit()
  {
    this.ctx.oficial_valoresInit();
  }
  function commonCalculateField(fN, cursor) {
  	return this.ctx.oficial_commonCalculateField(fN, cursor);
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
		
  var _i = this.iface;
	var cursor = this.cursor();
	
  connect(cursor, "bufferChanged(QString)", _i, "bufferChanged()");
	_i.valoresInit();
}

function interna_calculateField(fN)
{
  var _i = this.iface;
	var cursor = this.cursor();
	return _i.commonCalculateField(fN, cursor);
	/*var valor
	switch (fN) {
		case "numbulto":{
			valor = AQUtil.sqlSelect("em_detallelineapacking", "numbulto", "idlinea_packing= '" + cursor.valueBuffer("idlinea_packing") + "' ORDER BY numbulto DESC");
			if(!valor){
				valor = AQUtil.sqlSelect("em_lineaspacking", "desdebulto", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
				if(!valor) {				
					valor = 1;
				}
			} else {
				valor++;
			}
			break;
		}
		case "referencia":{
			valor = AQUtil.sqlSelect("em_lineaspacking", "referencia", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
			break;
		}
		case "descripcion":{
			valor = AQUtil.sqlSelect("em_lineaspacking", "descripcion", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
			break;
		}
		case "cantidadlinea":{
			valor = AQUtil.sqlSelect("em_detallelineapacking", "SUM(cantidad)", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
			if (!valor){
				valor = 0;
			}
			break;
		}
	}
	return valor;*/
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	/// Poner aqui si hace falta alg�n tipo de validaci�n.
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "numbulto":{
			valor = AQUtil.sqlSelect("em_detallelineapacking", "numbulto", "idlinea_packing= '" + cursor.valueBuffer("idlinea_packing") + "' ORDER BY numbulto DESC");
			if(!valor){
				valor = AQUtil.sqlSelect("em_lineaspacking", "desdebulto", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
				if(!valor) {				
					valor = 1;
				}
			} else {
				valor++;
			}
			break;
		}
		case "referencia":{
			valor = AQUtil.sqlSelect("em_lineaspacking", "referencia", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
			break;
		}
		case "descripcion":{
			valor = AQUtil.sqlSelect("em_lineaspacking", "descripcion", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
			break;
		}
		case "cantidadlinea":{
			valor = AQUtil.sqlSelect("em_detallelineapacking", "SUM(cantidad)", "idlinea_packing = '" + cursor.valueBuffer("idlinea_packing") + "'");
			if (!valor){
				valor = 0;
			}
			break;
		}
	}
	return valor;
}

function oficial_bufferChanged(fN)
{
  var _i = this.iface;

 /* switch (fN) {
  }*/
}

function oficial_valoresInit()
{
	var _i = this.iface;
	var cursor = this.cursor();

	switch(cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbNumBulto", _i.calculateField("numbulto"));
		}
		case cursor.Edit: {
			sys.setObjText(this, "fdbReferencia", _i.calculateField("referencia"));
			sys.setObjText(this, "fdbDescripcion", _i.calculateField("descripcion"));
			sys.setObjText(this, "fdbCantidadLinea", _i.calculateField("cantidadlinea"));
			break;
		}
	}
	this.child("fdbCantidad").setFocus();
	this.child("fdbCantidad").selectAll();
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
