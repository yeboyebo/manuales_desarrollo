/**************************************************************************
                 em_asignacionpiezasoe.qs  -  description
                             -------------------
    begin                : jue nov 19 2015
    copyright            : (C) 2015 by YeboYebo S.L.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {	
	var todos_;
	var tblLineas_;
	var idAlbaran_;
	var aLineasAlb_;
	var aPedidos_;
	var cSEL_, cREF_, cPZA_, cDES_, cCAN_, cDIS_, cPTE_, cALM_, cEST_, cPED_, cCPED_, cCSEL_;
	var colorNoSel_,colorSel_, colorRojo_,colorBlanco_;
	var codAlmacenAlb_;
    function oficial( context ) { interna( context ); }
	function tbnTodos_clicked() {
		return this.ctx.oficial_tbnTodos_clicked();
	}
	function tbnNinguno_clicked() {
		return this.ctx.oficial_tbnNinguno_clicked();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function actualizarOrden() {
		return this.ctx.oficial_actualizarOrden();
	}
	function creaLineas() {
		return this.ctx.oficial_creaLineas();
	}
	function tbnBuscarOE_clicked() {
		return this.ctx.oficial_tbnBuscarOE_clicked();
	}
	function iniciaTabla() {
		return this.ctx.oficial_iniciaTabla();
	}
	function tblLineas_clicked(f, c) {
		return this.ctx.oficial_tblLineas_clicked(f, c);
	}
	function colSelClicked(f) {
		return this.ctx.oficial_colSelClicked(f);
	}
	function colores() {
		return this.ctx.oficial_colores();
	}
	function creaLineaAlbaran(idAlbaran, referencia) {
		return this.ctx.oficial_creaLineaAlbaran(idAlbaran, referencia);
	}
	function creaMovLote(oParam) {
		return this.ctx.oficial_creaMovLote(oParam);
	}
	function totalizaLineaAlbaran(idLineaAlb, calculaPrecio) {
		return this.ctx.oficial_totalizaLineaAlbaran(idLineaAlb, calculaPrecio);
	}
	function totalesLineasAlbaran(curLinAlb) {
		return this.ctx.oficial_totalesLineasAlbaran(curLinAlb);
	}
	function calculaDatosLineas(codOrden, codAlmacen, tipoBusqueda) {
		return this.ctx.oficial_calculaDatosLineas(codOrden, codAlmacen, tipoBusqueda);
	}
	function buscarOE() {
		return this.ctx.oficial_buscarOE();
	}
	function colorearFila(fila) {
		return this.ctx.oficial_colorearFila(fila);
	}
	function compruebaMarcado(fila) {
		return this.ctx.oficial_compruebaMarcado(fila);
	}
	function controlCantSel(fila) {
		return this.ctx.oficial_controlCantSel(fila);
	}
	function tbnBuscarAlb_clicked() {
		return this.ctx.oficial_tbnBuscarAlb_clicked();
	}
	function buscarAlb() {
		return this.ctx.oficial_buscarAlb();
	}
	function buscar() {
		return this.ctx.oficial_buscar();
	}
	function habilitaCampos() {
		return this.ctx.oficial_habilitaCampos();
	}
	function tbnBorraOrden__clicked() {
		return this.ctx.oficial_tbnBorraOrden_clicked();
	}
	function tbnBorraAlbaran_clicked() {
		return this.ctx.oficial_tbnBorraAlbaran_clicked();
	}
	function compruebaRestoLineasPedido() {
		return this.ctx.oficial_compruebaRestoLineasPedido();
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
	var _i = this.iface;
	_i.colores();
	_i.tblLineas_ = this.child("tblLineas");
	connect(_i.tblLineas_, "doubleClicked(int, int)", _i, "tblLineas_clicked");
	connect(this.child("tbnTodos"), "clicked()", _i, "tbnTodos_clicked");
	connect(this.child("tbnNinguno"), "clicked()", _i, "tbnNinguno_clicked");	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	connect(this.child("tbnBuscarOE"), "clicked()", _i, "tbnBuscarOE_clicked");
	connect(this.child("tbnBuscarAlb"), "clicked()", _i, "tbnBuscarAlb_clicked");
	connect(this.child("lneCodAlmacen"), "textChanged(QString)", _i, "buscar()");
	connect(this.child("lneCodOrden"), "textChanged(QString)", _i, "habilitaCampos()");
	connect(this.child("lneCodAlbaran"), "textChanged(QString)", _i, "habilitaCampos()");
	connect(this.child("tbnBorraOrden"), "clicked()", _i, "tbnBorraOrden__clicked");
	connect(this.child("tbnBorraAlbaran"), "clicked()", _i, "tbnBorraAlbaran_clicked");
	
	_i.idAlbaran_ = formRecordalbaranescli.iface.idAlbaranDev_;	
	var oDatosAlbCli = flfactppal.iface.pub_ejecutarQry("albaranescli","codalmacen","idalbaran = "+ _i.idAlbaran_,"albaranescli");
	if(oDatosAlbCli == -1) {
		return false;
	}
	var codAlmacenAlb = oDatosAlbCli.codalmacen;
	this.child("lneCodAlmacen").text = codAlmacenAlb;	
	_i.codAlmacenAlb_ = codAlmacenAlb;
	_i.todos_ = false;	
	_i.iniciaTabla();	

	
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciaTabla()
{
	var _i = this.iface;
	
	var cursor = this.cursor();
	
	var c = 0, cH = [];
  
  _i.cSEL_ = c++;
  _i.cREF_ = c++;
  _i.cPZA_ = c++;  
  _i.cDES_ = c++;
  _i.cCAN_ = c++;	
  _i.cDIS_ = c++;
  _i.cCPED_ = c++;
  _i.cPTE_ = c++;
  _i.cALM_ = c++;
  _i.cEST_ = c++;
  _i.cPED_ = c++;
  _i.cCSEL_ = c++;
	
	cH[_i.cSEL_] = AQUtil.translate("scripts", "Sel.");
	cH[_i.cREF_] = AQUtil.translate("scripts", "Referencia");
	cH[_i.cPZA_] = AQUtil.translate("scripts", "Pieza");
	cH[_i.cDES_] = AQUtil.translate("scripts", "Descripci�n");
	cH[_i.cCAN_] = AQUtil.translate("scripts", "Cantidad");
	cH[_i.cDIS_] = AQUtil.translate("scripts", "Disponible");
	cH[_i.cCPED_] = AQUtil.translate("scripts", "Cant.pedido");
	cH[_i.cPTE_] = AQUtil.translate("scripts", "Cant.PTE");
	cH[_i.cALM_] = AQUtil.translate("scripts", "Almac�n");
	cH[_i.cEST_] = AQUtil.translate("scripts", "Estado");
	cH[_i.cPED_] = AQUtil.translate("scripts", "Pedidos");
	cH[_i.cCSEL_] = AQUtil.translate("scripts", "Cantidad seleccionada");

	
  	_i.tblLineas_.setNumCols(c);  

	_i.tblLineas_.setColumnWidth(_i.cSEL_, 40);
	_i.tblLineas_.setColumnWidth(_i.cREF_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cPZA_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cDES_, 500);  	
  	_i.tblLineas_.setColumnWidth(_i.cCAN_, 120);
  	_i.tblLineas_.setColumnWidth(_i.cDIS_, 120);
  	_i.tblLineas_.setColumnWidth(_i.cCPED_, 120);
  	_i.tblLineas_.setColumnWidth(_i.cPTE_, 120);
  	_i.tblLineas_.setColumnWidth(_i.cEST_, 120);
  	_i.tblLineas_.setColumnWidth(_i.cPED_, 120);
  	_i.tblLineas_.setColumnWidth(_i.cCSEL_, 120);
  	

  	
  	_i.tblLineas_.setColumnReadOnly(_i.cREF_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cPZA_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cDES_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cCAN_, true);  
  	_i.tblLineas_.setColumnReadOnly(_i.cDIS_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cCPED_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cPTE_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cALM_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cEST_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cPED_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cCSEL_, true);


  	//_i.tblLineas_.hideColumn(_i.cCPED_);
  	_i.tblLineas_.hideColumn(_i.cCSEL_);
  	_i.tblLineas_.hideColumn(_i.cEST_);
  	_i.tblLineas_.hideColumn(_i.cPED_);
  	
  	
  		
 	_i.tblLineas_.setColumnLabels("*", cH.join("*"));
}

function oficial_tbnBuscarOE_clicked()
{
	var _i = this.iface;		
	var filtro = "1=1";
	var f = new FLFormSearchDB("em_ordenesestampacionsearch");	
	f.setMainWidget();
	f.cursor().setMainFilter(filtro);
	var codOrden = f.exec("codordenest");

	if (codOrden) {
		_i.tblLineas_.setNumRows(0);
		this.child("lneCodOrden").text = codOrden;
		this.child("lneDescripcionOE").text = AQUtil.sqlSelect("em_ordenesestampacion","descripcion","codordenest = '" + codOrden + "'");
		var codAlmacenBus = this.child("lneCodAlmacen").text;
		
		if(codOrden && codOrden != "" && codAlmacenBus && codAlmacenBus !="") {
			_i.calculaDatosLineas(codOrden, codAlmacenBus, "OE");
		} else {
			sys.warnMsgBox(sys.translate("Debe de seleccionar un almac�n y una O.E."));
		}
	}
}

function oficial_buscarOE()
{
	var _i = this.iface;		

	var codOrden = this.child("lneCodOrden").text;
	var codAlmacenBus = this.child("lneCodAlmacen").text;	
	_i.tblLineas_.setNumRows(0);
	if(codOrden && codOrden != "" && codAlmacenBus && codAlmacenBus !="") {
		this.child("lneDescripcionOE").text = AQUtil.sqlSelect("em_ordenesestampacion","descripcion","codordenest = '" + codOrden + "'");
		_i.calculaDatosLineas(codOrden, codAlmacenBus, "OE");
	}
	
}

function oficial_calculaDatosLineas(codOrden, codAlmacen, tipoBusqueda)
{
	var _i = this.iface;
	var aPedidos = [];
	_i.aPedidos_ = [];
	var q = new AQSqlQuery;	
	q.setSelect("p.codigo,p.idpedido");
	q.setFrom("lineasalbaranescli l inner join pedidoscli p on l.idpedido = p.idpedido inner join lineaspedidoscli lp on lp.idlinea = l.idlineapedido");
	q.setWhere("l.idalbaran = " + _i.idAlbaran_ + " and l.idpedido is not null and l.idpedido <> 0  GROUP BY p.codigo,p.idpedido");		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		aPedidos.push(q.value("p.codigo"));				
		_i.aPedidos_.push(q.value("p.idpedido"));
	}
	var sPedidos = aPedidos.join(",");	
	

	var r = 0;
	var q = new AQSqlQuery;
	var metrosAcu = 0;
	q.setSelect("lotesstock.referencia,lotesstock.codlote,lotesstock.articulo,lotesstock.canlote,lotesstock.candisponible,lotesstock.codalmacen");

	if(tipoBusqueda == "AP") {
		q.setFrom("lotesstock");		
		q.setWhere("lotesstock.codalbaranprov = '" + codOrden + "' and lotesstock.candisponible > 0 and lotesstock.codalmacen = '" + codAlmacen + "' GROUP BY lotesstock.referencia, lotesstock.codlote, lotesstock.articulo, lotesstock.canlote, lotesstock.candisponible, lotesstock.codalmacen order by lotesstock.referencia,lotesstock.codlote");	
	} else {

		q.setFrom("lotesstock inner join em_tramostejido on lotesstock.codlote=em_tramostejido.codpartida");		
		q.setWhere("lotesstock.codordenest = '" + codOrden + "' and em_tramostejido.espieza and lotesstock.candisponible > 0 and lotesstock.codalmacen = '" + codAlmacen + "' GROUP BY lotesstock.referencia, lotesstock.codlote, lotesstock.articulo, lotesstock.canlote, lotesstock.candisponible, lotesstock.codalmacen order by lotesstock.referencia,lotesstock.codlote");			
	}
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		_i.tblLineas_.insertRows(r);
		var cantidad = parseFloat(q.value("lotesstock.canlote"));						
		cantidad = AQUtil.roundFieldValue(cantidad, "lotesstock", "canlote"); 
		var canDisponible = parseFloat(q.value("lotesstock.candisponible"));						
		canDisponible = AQUtil.roundFieldValue(canDisponible, "lotesstock", "candisponible");      	

		_i.tblLineas_.setText(r,  _i.cREF_, q.value("lotesstock.referencia"));
		_i.tblLineas_.setText(r, _i.cPZA_, q.value("lotesstock.codlote"));
		_i.tblLineas_.setText(r, _i.cDES_, q.value("lotesstock.articulo"));
		_i.tblLineas_.setText(r, _i.cCAN_, cantidad);
		_i.tblLineas_.setText(r, _i.cDIS_, canDisponible);
		_i.tblLineas_.setText(r, _i.cALM_, q.value("lotesstock.codalmacen"));
		_i.tblLineas_.setText(r,_i.cPED_, sPedidos);
		_i.colorearFila(r);
		r++;
	}
}

function oficial_colores()
{
  var _i = this.iface;

  _i.colorNoSel_ = new Color("grey");
  _i.colorSel_ = new Color("green");
  _i.colorBlanco_ = new Color(flfactppal.iface.pub_dameColor("fondo_blanco"));
  _i.colorRojo_= new Color("red");
 
}

function oficial_tblLineas_clicked(f, c)
{
	var _i = this.iface;
  	switch (c) {
  		case _i.cSEL_: {
  			_i.colSelClicked(f);
      		break;
 		} 		
	}
}

function oficial_colSelClicked(f)
{
  var _i = this.iface;
  
  if (_i.tblLineas_.text(f, _i.cSEL_) == "") {
  	if(!_i.compruebaMarcado(f)) {
  		return true;
  	}  	
    _i.tblLineas_.setText(f, _i.cSEL_, "X");
    _i.tblLineas_.setCellBackgroundColor(f, _i.cSEL_, _i.colorSel_);  
  } else {
    _i.tblLineas_.setText(f, _i.cSEL_, "");
    _i.tblLineas_.setCellBackgroundColor(f, _i.cSEL_, _i.colorNoSel_); 
  } 
  if(!_i.controlCantSel(f)) {
  	return false;
  }

  return true;
}

function oficial_tbnTodos_clicked()
{
	var _i = this.iface;  
  	var nF = _i.tblLineas_.numRows();  	
  	for (var f = 0; f < nF; f++) {    
    	if (_i.tblLineas_.text(f, 0) == "") {
      		if (!_i.colSelClicked(f)) {        		
        		return false;
      		}
    	}
  	}  
}


function oficial_tbnNinguno_clicked()
{
	var _i = this.iface;		
  	var nF = _i.tblLineas_.numRows();  	
  	for (var f = 0; f < nF; f++) {    
    	if (_i.tblLineas_.text(f, 0) == "X") {
      		if (!_i.colSelClicked(f)) {        		
        		return false;
      		}
    	}
  	}  
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	
	var sel = false;
	var nF = _i.tblLineas_.numRows();
	for (var f = 0; f < nF && !sel; f++) {    
    	if (_i.tblLineas_.text(f, 0) == "X") {
      		sel = true;
    	}
  	} 
  	if(!sel) {
  		sys.warnMsgBox(sys.translate("No ha seleccionado ning�n registro."));
  		return false;
  	}
	if(!_i.creaLineas()) {
		return false;
	}
	_i.compruebaRestoLineasPedido();
	this.obj().accept();
}

/*function oficial_creaLineas()
{
	var _i = this.iface;	
	var aRef = [];
	//cargamos en aRef las referencias que ya est�n en las l�neas.
	var q = new AQSqlQuery;	
	q.setSelect("distinct(referencia)");
	q.setFrom("lineasalbaranescli");
	q.setWhere("idalbaran = " + _i.idAlbaran_); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		aRef.push(q.value("distinct(referencia)"));		
	}	
	var nF = _i.tblLineas_.numRows();
	for (var f = 0; f < nF; f++) {    
    	if (_i.tblLineas_.text(f, _i.cSEL_) == "X") {      		
      	var referencia = _i.tblLineas_.text(f, _i.cREF_);
      	if(aRef.join(",").find(referencia) ==-1) {
      		aRef.push(referencia);
      		if(!_i.creaLineaAlbaran(_i.idAlbaran_, referencia)) {
					return false;      		
      		}     	
      	} 
      	var cantidad = _i.tblLineas_.text(f, _i.cDIS_);
      	var codPieza = _i.tblLineas_.text(f, _i.cPZA_);
      	var idLineaAlb = AQUtil.sqlSelect("lineasalbaranescli","idlinea","idalbaran = "+_i.idAlbaran_ +" and referencia = '" + referencia + "'");
      	var oParam = new Object;
      	oParam.idLineaAlb = idLineaAlb;
      	oParam.codLote = codPieza;
      	oParam.cantidad = (-1)*cantidad;
      	oParam.codAlmacenAlb = this.child("lneCodAlmacen").text;
      	oParam.tipoAlb = "VENTA";
      	if(!_i.creaMovLote(oParam)) {
      		return false;
      	} 	
      	if(!_i.totalizaLineaAlbaran(idLineaAlb)) {
      		return false;
      	} 		
    	}
  	} 
	return true;
}*/

function oficial_creaLineas()
{
	var _i = this.iface;	
	var aRef = [];
	_i.aLineasAlb_ = [];
	//cargamos en aRef las referencias que ya est�n en las l�neas.
	var p=0;

	var qRef = new AQSqlQuery;	
	qRef.setSelect("l.referencia, l.idlinea");
	qRef.setFrom("lineasalbaranescli l left outer join movistock m on m.idlineaac=l.idlinea");
	qRef.setWhere("l.idalbaran = " + _i.idAlbaran_ +" and m.idlineaac is null group by l.referencia, l.idlinea"); 			
	if (!qRef.exec()){
		return;
	}  
	while(qRef.next())
	{	
		
		aRef[p] = new Array(2);
		aRef[p][0] = qRef.value("l.referencia");
		aRef[p][1] = this.child("lneCodAlmacen").text;
		aRef[p][2] = qRef.value("l.idlinea");
		p++;			
	}	


	var q = new AQSqlQuery;	
	q.setSelect("m.referencia, s.codalmacen, l.idlinea");
	q.setFrom("movistock m inner join lineasalbaranescli l on m.idlineaac=l.idlinea inner join stocks s on m.idstock=s.idstock");
	q.setWhere("l.idalbaran = " + _i.idAlbaran_ + " group by m.referencia, s.codalmacen,l.idlinea"); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		
		var referencia = q.value("m.referencia");
		var codAlmacen = q.value("s.codalmacen");
		var refAlmacen = referencia+","+codAlmacen;
		if(aRef.join(",").find(refAlmacen) ==-1) {
			aRef[p] = new Array(2);
			aRef[p][0] = q.value("m.referencia");
			aRef[p][1] = q.value("s.codalmacen");			
			aRef[p][2] = q.value("l.idlinea");	
			p++;
		}
	}	
	var nF = _i.tblLineas_.numRows();
	for (var f = 0; f < nF; f++) {    
		if (_i.tblLineas_.text(f, _i.cSEL_) == "X") {  
			//if(!_i.compruebaDisponible(f)) {
  			//	_i.tblLineas_.setText(f, _i.cSEL_, "");
    		//	_i.tblLineas_.setCellBackgroundColor(f, _i.cSEL_, _i.colorNoSel_); 
  			//} else {

				var referencia = _i.tblLineas_.text(f, _i.cREF_);
				var codAlmacen = _i.tblLineas_.text(f, _i.cALM_);
				var refAlmacen = referencia+","+codAlmacen;

				var idLineaAlbN, idLineaAlb;
				if(aRef.join(",").find(refAlmacen) ==-1) {
					
					aRef[p] = new Array(2);
					aRef[p][0] = referencia;
					aRef[p][1] = codAlmacen;
					
					idLineaAlbN = _i.creaLineaAlbaran(_i.idAlbaran_, referencia);
					if(!idLineaAlbN) {
						return false;      		
					} 
					aRef[p][2] = idLineaAlbN;
					idLineaAlb = idLineaAlbN;
					p++;    	
				} else {
					for(var a =0; a < aRef.length; a++) {
						if(aRef[a][0] == referencia && aRef[a][1] == codAlmacen) {
							idLineaAlb = 	aRef[a][2];
						}				
					}			
				}
				var cantidad = _i.tblLineas_.text(f, _i.cDIS_);
				var codPieza = _i.tblLineas_.text(f, _i.cPZA_);
				
				//var idLineaAlb = AQUtil.sqlSelect("movistock m inner join lineasalbaranescli l on m.idlineaac=l.idlinea inner join stocks s on m.idstock=s.idstock","l.idlinea","l.idalbaran = "+_i.idAlbaran_ +" and m.referencia = '" + referencia + "' and s.codalmacen='" + codAlmacen+ "'","movistock");
				//if(!idLineaAlb) { // es porque tiene que ir a la l�nea que acabamos de crear.
				//	idLineaAlb = idLineaAlbN;
				//}
				var oParam = new Object;
				oParam.idLineaAlb = idLineaAlb;
				oParam.codLote = codPieza;
				oParam.cantidad = (-1)*cantidad;
				//oParam.codAlmacenAlb = this.child("lneCodAlmacen").text;
				oParam.codAlmacenAlb = _i.codAlmacenAlb_;
				oParam.tipoAlb = "VENTA";
				if(!_i.creaMovLote(oParam)) {
					return false;
				} 	
				if(!_i.totalizaLineaAlbaran(idLineaAlb, true)) {
					return false;
				} 		
				_i.aLineasAlb_.push(idLineaAlb);
  			//}    		
		}
	} 
	return true;
}

function oficial_creaLineaAlbaran(idAlbaran, referencia)
{
	
	var _i = this.iface;
	var cursorLA = new FLSqlCursor("lineasalbaranescli");
  	cursorLA.setModeAccess(cursorLA.Insert);
 	cursorLA.refreshBuffer();   	
	cursorLA.setValueBuffer("idalbaran",idAlbaran);
	var numLinea = AQUtil.sqlSelect("lineasalbaranescli","numlinea","idalbaran = "+ idAlbaran +" order by numlinea desc");
	numLinea = isNaN(numLinea) ? 1 : numLinea+1;
	var codTamanoEm, codColorEm, codArancelario, refCliente;	
	var q = new AQSqlQuery;	
	q.setSelect("codtamanoem, codcolorem, codarancelario, aliasart");
	q.setFrom("articulos");
	q.setWhere("referencia = '" + referencia + "' "); 			
	if (!q.exec()){
		return false;
	}  
	if(q.first())
	{
		codTamanoEm = q.value("codtamanoem");
		codColorEm = q.value("codcolorem");		
		codArancelario = q.value("codarancelario");		
		refCliente = q.value("aliasart");		
	}		
	cursorLA.setValueBuffer("numlinea",numLinea);
	cursorLA.setValueBuffer("referencia",referencia);
	cursorLA.setValueBuffer("descripcion",formRecordlineasalbaranescli.iface.pub_commonCalculateField("desarticulo", cursorLA));	
	cursorLA.setValueBuffer("codtamanoem",codTamanoEm);
	cursorLA.setValueBuffer("codcolorem",codColorEm);		
	cursorLA.setValueBuffer("cantidad",0);		
	cursorLA.setValueBuffer("canfactura",0);		
	cursorLA.setValueBuffer("pvpunitario",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvpunitario", cursorLA));	
	cursorLA.setValueBuffer("pvpsindto",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvpsindto", cursorLA));	
	cursorLA.setValueBuffer("pvptotal",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvptotal", cursorLA));	
	cursorLA.setValueBuffer("codimpuesto",formRecordlineasalbaranescli.iface.pub_commonCalculateField("codimpuesto", cursorLA));	
	cursorLA.setValueBuffer("iva",formRecordlineasalbaranescli.iface.pub_commonCalculateField("iva", cursorLA));	
	cursorLA.setValueBuffer("dtolineal",formRecordlineasalbaranescli.iface.pub_commonCalculateField("dtolineal", cursorLA));	
	cursorLA.setValueBuffer("dtopor",formRecordlineasalbaranescli.iface.pub_commonCalculateField("dtopor", cursorLA));	
	cursorLA.setValueBuffer("recargo",formRecordlineasalbaranescli.iface.pub_commonCalculateField("recargo", cursorLA));		
	cursorLA.setValueBuffer("irpf",formRecordlineasalbaranescli.iface.pub_commonCalculateField("irpf", cursorLA));	
	cursorLA.setValueBuffer("porcomision",formRecordlineasalbaranescli.iface.pub_commonCalculateField("porcomision", cursorLA));	
	cursorLA.setValueBuffer("codarancelario",codArancelario);
	cursorLA.setValueBuffer("refcliente",refCliente);
	cursorLA.setValueBuffer("tipoconcepto","Producto");
	cursorLA.setValueBuffer("codsubcuenta",formRecordlineasalbaranescli.iface.pub_commonCalculateField("codsubcuenta", cursorLA));
	cursorLA.setValueBuffer("idsubcuenta",formRecordlineasalbaranescli.iface.pub_commonCalculateField("idsubcuenta", cursorLA));
	if (!cursorLA.commitBuffer()) {
  		return false;
   }
	return cursorLA.valueBuffer("idlinea");

}


function oficial_creaMovLote(oParam)
{ 
	
	var _i = this.iface;
	var idLineaAlb = oParam.idLineaAlb;
	var codLote = oParam.codLote;
	var cantidad = oParam.cantidad;
	var codAlmacenAlb = oParam.codAlmacenAlb;
	var tipoAlb = oParam.tipoAlb; 
	
	var curMoviStock = new FLSqlCursor("movistock");
 	curMoviStock.setModeAccess(curMoviStock.Insert);
	curMoviStock.refreshBuffer();	    		
 	curMoviStock.setValueBuffer("codlote",codLote);
  	var oDatosLote = flfactppal.iface.pub_ejecutarQry("lotesstock","referencia,codalmacen,ubicacion","codlote= '" + codLote + "' ","lotesstock");
	if (oDatosLote.result != 1) {
		MessageBox.warning(sys.translate("Error al crear movimiento de los lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}    		
	var referencia = oDatosLote.referencia;	
	var codAlmacenLote = oDatosLote.codalmacen; 	
	if(tipoAlb == "DEVOL") {
		if(codAlmacenLote != codAlmacenAlb) {
			//cambiamos el lote de almac�n
			/*if (!AQUtil.execSql("UPDATE lotesstock SET codalmacen = '" + codAlmacenAlb + "' WHERE codlote = '" + codLote + "'")) {
				return false;
			}*/
			if (!AQUtil.execSql("UPDATE lotesstock SET codalmacen = '" + codAlmacenAlb + "', em_codalmacenori = '" + codAlmacenLote + "' WHERE codlote = '" + codLote + "'")) {
				return false;
			}
			//actualizamos el stock del almac�n anterior
			var idStockAnt = AQUtil.sqlSelect("stocks", "idstock", "codalmacen = '" + codAlmacenLote + "' AND referencia = '" + referencia + "'");
			flfactalma.iface.pub_actualizarStock(idStockAnt);
			codAlmacenLote = codAlmacenAlb;
		} else {
			if (!AQUtil.execSql("UPDATE lotesstock SET em_codalmacenori = '" + codAlmacenLote + "' WHERE codlote = '" + codLote + "'")) {
				return false;
			}
		}
	}	
			
   curMoviStock.setValueBuffer("referencia",referencia);   	
   curMoviStock.setValueBuffer("estado","HECHO");
   curMoviStock.setValueBuffer("cantidad",cantidad); 
   
   var curLinAlb = new FLSqlCursor("lineasalbaranescli");
  	curLinAlb.select("idlinea = " + idLineaAlb);
  	if(!curLinAlb.first()) {
  		return false;
  	}
	curLinAlb.setModeAccess(curLinAlb.Browse);
	curLinAlb.refreshBuffer();    		
	var aD = flfactalma.iface.pub_dameDatosStockLinea(curLinAlb);
	if (aD && aD.concepto != "") {
		curMoviStock.setValueBuffer("concepto", aD.concepto);
	}
	var hoy = new Date;
	curMoviStock.setValueBuffer("fechareal",hoy);
	curMoviStock.setValueBuffer("horareal",hoy);       		
	//var idStock = AQUtil.sqlSelect("stocks", "idstock", "codalmacen = '" + codAlmacenAlb + "' AND referencia = '" + referencia + "'");
	var idStock = AQUtil.sqlSelect("stocks", "idstock", "codalmacen = '" + codAlmacenLote + "' AND referencia = '" + referencia + "'");
	if (!idStock) {
		var oArticulo = new Object();
		oArticulo.referencia = referencia;
		oArticulo.ubicacion = oDatosLote.ubicacion;
		oArticulo.codalmacen = codAlmacenAlb;		
		idStock = flfactalma.iface.pub_crearStock(codAlmacenAlb, oArticulo );
		if (!idStock) {
			sys.warnMsgBox(sys.translate("Error al crear idstock para la referencia %1 en almac�n %2").arg(referencia).arg(codAlmacenAlb));
			return false;
		}		
	}				
	curMoviStock.setValueBuffer("idstock",idStock);
	curMoviStock.setValueBuffer("idlineaac",idLineaAlb);   
	if(!curMoviStock.commitBuffer()){
		MessageBox.warning(sys.translate("Error al crear movimiento de los lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function oficial_totalizaLineaAlbaran(idLineaAlb, calculaPrecio)
{
	
	var _i = this.iface;
	var curLinAlb = new FLSqlCursor("lineasalbaranescli");
  	curLinAlb.select("idlinea = " + idLineaAlb);
  	if(!curLinAlb.first()) {
  		return false;
  	}
	curLinAlb.setModeAccess(curLinAlb.Edit);
	curLinAlb.refreshBuffer();
	if(!_i.totalesLineasAlbaran(curLinAlb)) {
		return false;
	}
	if(!curLinAlb.commitBuffer()) {
		return false;
	}
	return true;
}
function oficial_totalesLineasAlbaran(curLinAlb, calculaPrecio)
{
	
	curLinAlb.setValueBuffer("cantidad",formRecordlineasalbaranescli.iface.pub_commonCalculateField("cantidadtrazable", curLinAlb));	
	//curLinAlb.setValueBuffer("candistribuida",formRecordlineasalbaranescli.iface.pub_commonCalculateField("candistribuida", curLinAlb));
	curLinAlb.setValueBuffer("canfactura",formRecordlineasalbaranescli.iface.pub_commonCalculateField("canfactura", curLinAlb));	
	if(calculaPrecio) {
		curLinAlb.setValueBuffer("pvpunitario",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvpunitario", curLinAlb));	
	}
	curLinAlb.setValueBuffer("pvpsindto",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvpsindto", curLinAlb));	
	curLinAlb.setValueBuffer("pvptotal",formRecordlineasalbaranescli.iface.pub_commonCalculateField("pvptotal", curLinAlb));	
	
	return true;
}

function oficial_colorearFila(fila) 
{
	var _i = this.iface;
	var color = "";
	var canTotal = 0;
	var canTotalPed = 0;
	var canTotalAlb = 0;
	var referencia = _i.tblLineas_.text(fila, _i.cREF_);
	var aPedidos = [];
	var q = new AQSqlQuery;	
	q.setSelect("p.codigo,SUM(lp.cantidad-l.cantidad),SUM(lp.cantidad), SUM(l.cantidad)");
	q.setFrom("lineasalbaranescli l inner join pedidoscli p on l.idpedido = p.idpedido inner join lineaspedidoscli lp on lp.idlinea = l.idlineapedido");
	q.setWhere("l.idalbaran = " + _i.idAlbaran_ + " and l.idpedido is not null and l.idpedido <> 0 and l.referencia = '" + referencia + "' GROUP BY p.codigo");		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		aPedidos.push(q.value("p.codigo"));		
		canTotal += q.value("SUM(lp.cantidad-l.cantidad)"); 	
		canTotalPed += q.value("SUM(lp.cantidad)");
		canTotalAlb += q.value("SUM(l.cantidad)"); 
	}

	var idPedido = AQUtil.sqlSelect("lineasalbaranescli","idpedido","idalbaran = " + _i.idAlbaran_ + " and idpedido is not null and idpedido <> 0");	
	if(!idPedido || idPedido == "") {		
	//if(aPedidos.length == 0) {
		color = _i.colorBlanco_;
		_i.tblLineas_.setText(fila,_i.cEST_, "NOPED");
	} else {	
		//var sPedidos = aPedidos.join(",");
		//debug("sPdidos: "+sPedidos);
		//_i.tblLineas_.setText(fila,_i.cPED_, sPedidos);
		
		var idLinea = AQUtil.sqlSelect("lineasalbaranescli","idlinea","idalbaran = " + _i.idAlbaran_ + " and referencia = '" + referencia + "'");
		if(idLinea && idLinea != "") {			
			color =  _i.colorSel_;		
			_i.tblLineas_.setText(fila,_i.cEST_, "SIALB");
		} else {				
			color = _i.colorRojo_;			
			_i.tblLineas_.setText(fila,_i.cEST_, "NOALB");
		}
	}
	canTotal= AQUtil.roundFieldValue(canTotal, "lotesstock", "candisponible");
	_i.tblLineas_.setText(fila,_i.cPTE_,canTotal);
	_i.tblLineas_.setText(fila,_i.cCPED_,canTotalPed);
	_i.tblLineas_.setText(fila,_i.cCSEL_,canTotalAlb);
			
	var numCol = _i.tblLineas_.numCols();
	for (var iCol = 1; iCol < numCol; iCol++) {		
		_i.tblLineas_.setCellBackgroundColor(fila, iCol, color);
	}
}

function oficial_compruebaMarcado(fila)
{
	var _i = this.iface;
	var estado = _i.tblLineas_.text(fila, _i.cEST_);
	var pedidos = _i.tblLineas_.text(fila, _i.cPED_);
	var referencia = _i.tblLineas_.text(fila, _i.cREF_); 
	var cantidadPedido = _i.tblLineas_.text(fila, _i.cCPED_);
	if(!cantidadPedido || cantidadPedido == "") {
		cantidadPedido = 0;
	}
	var cantidadSel = _i.tblLineas_.text(fila, _i.cCSEL_);
	if(!cantidadSel || cantidadSel == "") {
		cantidadSel = 0;
	}

	var cantidadDisp = _i.tblLineas_.text(fila, _i.cDIS_);
	if(!cantidadDisp || cantidadDisp == "") {
		cantidadDisp = 0;
	}

	
	if(estado == "NOALB") {
		var res = flfactppal.iface.preguntaMsg(sys.translate("Est� incorporando la referencia %1 que no existe en el pedido %2 �Desea continuar?").arg(referencia).arg(pedidos),"info",this,MessageBox.Yes, MessageBox.No);  
  		if (res != MessageBox.Yes) {
			return false;
  		}
	}  else if (estado == "SIALB") {
		//debug("\n\n");
		//debug("cantidadSel: "+ cantidadSel);
		//debug("cantidadSel: "+ cantidadPedido);
		var cantTotal = parseFloat(cantidadSel) + parseFloat(cantidadDisp);
		//debug("cantTotal: "+ cantTotal);
		var porc = ((parseFloat(cantTotal)/parseFloat(cantidadPedido)) -1)*100;
		//debug("porc: "+ porc);
		porc = AQUtil.roundFieldValue(porc, "lotesstock", "candisponible");
		cantidadPedido = AQUtil.roundFieldValue(cantidadPedido, "lotesstock", "candisponible");
		if(porc > 10) {
			var res = flfactppal.iface.preguntaMsg(sys.translate("Est� asignando un %1 % m�s cantidad de la solicitada %2 para la referencia %3 del pedido %4. �Desea continuar?").arg(porc).arg(cantidadPedido).arg(referencia).arg(pedidos),"info",this,MessageBox.Yes, MessageBox.No);  
  			if (res != MessageBox.Yes) {
				return false;
  			}
		}

	}
	return true;
}

function oficial_controlCantSel(fila)
{
	var _i = this.iface;
	var estado = _i.tblLineas_.text(fila, _i.cEST_);
	if(estado == "SIALB") {
		var cantidad = _i.tblLineas_.text(fila, _i.cDIS_);
		var referencia = _i.tblLineas_.text(fila, _i.cREF_);
		var marcado = _i.tblLineas_.text(fila, _i.cSEL_); 
		var nF = _i.tblLineas_.numRows();
		for (var f = 0; f < nF; f++) {    
    		if (_i.tblLineas_.text(f, _i.cREF_) == referencia) {
    			var cantidadPTE = _i.tblLineas_.text(f, _i.cPTE_); 
    			var cantidadSEL = _i.tblLineas_.text(f, _i.cCSEL_); 
      			if(marcado == "X") {
      				_i.tblLineas_.setText(f, _i.cPTE_,parseFloat(cantidadPTE) - parseFloat(cantidad));
      				_i.tblLineas_.setText(f, _i.cCSEL_,parseFloat(cantidadSEL) + parseFloat(cantidad));
      			} else {
      				_i.tblLineas_.setText(f, _i.cPTE_,parseFloat(cantidadPTE) + parseFloat(cantidad));	
      				_i.tblLineas_.setText(f, _i.cCSEL_,parseFloat(cantidadSEL) - parseFloat(cantidad));	
      			}	 
    		}
    	}
  	  
	}	
	return true;	
}

function oficial_tbnBuscarAlb_clicked()
{
	var _i = this.iface;		
	var filtro = "1=1";
	var f = new FLFormSearchDB("em_albaranesprovsearch");	
	f.setMainWidget();
	f.cursor().setMainFilter(filtro);
	var codAlbaran = f.exec("codigo");

	if (codAlbaran) {
		_i.tblLineas_.setNumRows(0);
		this.child("lneCodAlbaran").text = codAlbaran;
		this.child("lneNombreProveedor").text = AQUtil.sqlSelect("albaranesprov","nombre","codigo = '" + codAlbaran + "'");
		var codAlmacenBus = this.child("lneCodAlmacen").text;
		
		if(codAlbaran && codAlbaran != "" && codAlmacenBus && codAlmacenBus !="") {
			_i.calculaDatosLineas(codAlbaran, codAlmacenBus, "AP");
		} else {
			sys.warnMsgBox(sys.translate("Debe de seleccionar un almac�n y una O.E."));
		}
	}
}

function oficial_buscarAlb()
{
	var _i = this.iface;		

	var codAlbaran = this.child("lneCodAlbaran").text;
	var codAlmacenBus = this.child("lneCodAlmacen").text;	
	_i.tblLineas_.setNumRows(0);
	if(codAlbaran && codAlbaran != "" && codAlmacenBus && codAlmacenBus !="") {
		this.child("lneNombreProveedor").text = AQUtil.sqlSelect("albaranesprov","nombre","codigo = '" + codAlbaran + "'");
		_i.calculaDatosLineas(codAlbaran, codAlmacenBus, "AP");
	}
	
}

function oficial_buscar()
{
	var _i = this.iface;
	if(this.child("lneCodAlbaran").text && this.child("lneCodAlbaran").text != "") {
		_i.buscarAlb();
	} else {
		_i.buscarOE();
	}

}

function oficial_habilitaCampos()
{
	var _i = this.iface
	var codAlbaran = this.child("lneCodAlbaran").text;
	var codOrden = this.child("lneCodOrden").text;

	if(codAlbaran && codAlbaran != "") {
		sys.disableObj(this, "tbnBuscarOE");
		sys.disableObj(this, "tbnBorraOrden");
	} else {
		sys.enableObj(this, "tbnBuscarOE");
		sys.enableObj(this, "tbnBorraOrden");
	}
	if(codOrden && codOrden != "") {
		sys.disableObj(this, "tbnBuscarAlb");
		sys.disableObj(this, "tbnBorraAlbaran");
		
	} else {
		sys.enableObj(this, "tbnBuscarAlb");
		sys.enableObj(this, "tbnBorraAlbaran");
	}

}

function oficial_tbnBorraOrden_clicked()
{
	var _i = this.iface;
	this.child("lneCodOrden").text = "";
	this.child("lneDescripcionOE").text = "";
	_i.tblLineas_.setNumRows(0);
	
}

function oficial_tbnBorraAlbaran_clicked()
{
	var _i = this.iface;
	this.child("lneCodAlbaran").text = "";
	this.child("lneNombreProveedor").text = "";
	_i.tblLineas_.setNumRows(0);
	
}

function oficial_compruebaRestoLineasPedido()
{
	var _i = this.iface;
	debug("oficial_compruebaRestoLineasPedido");
	var sLineasAlb = _i.aLineasAlb_.join(",");
	var aLineasPed = [];
	var q = new AQSqlQuery;	
	q.setSelect("lp.idlinea");
	q.setFrom("lineasalbaranescli l inner join pedidoscli p on l.idpedido = p.idpedido inner join lineaspedidoscli lp on lp.idlinea = l.idlineapedido");
	q.setWhere("l.idalbaran = " + _i.idAlbaran_ + " and l.idlinea NOT IN ( " + sLineasAlb + ") and l.idpedido is not null and l.idpedido <> 0  GROUP BY lp.idlinea");		
	if (!q.exec()){
		return;
	}  
	debug("q: " + q.sql());
	while(q.next())
	{
		aLineasPed.push(q.value("lp.idlinea"));				
	}

	var idLineaPed;
	var cantidadServida;
	var query = new FLSqlQuery();
	for(var i=0; i< aLineasPed.length; i++) {

		var curLineaPedido = new FLSqlCursor("lineaspedidoscli");
		curLineaPedido.select("idlinea = " + aLineasPed[i]);
		curLineaPedido.setModeAccess(curLineaPedido.Edit);
		if (!curLineaPedido.first()) {
			continue;
		}
		
		query.setTablesList("lineasalbaranescli");
		query.setSelect("SUM(cantidad)");
		query.setFrom("lineasalbaranescli");
		query.setWhere("idlineapedido = " + aLineasPed[i]);
		if (!query.exec()) {
			return false;
		}
		if (query.next()) {
			cantidadServida = parseFloat(query.value("SUM(cantidad)"));
			if (isNaN(cantidadServida)) {
				cantidadServida = 0;
			}
			
			curLineaPedido.setValueBuffer("totalenalbaran", cantidadServida);
			if (!curLineaPedido.commitBuffer()) {
				return false;
			}
		}
	}


	for(var i=0; i< _i.aPedidos_.length; i++) {
		if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(_i.aPedidos_[i])) { 
			return;
		}
	}
	
	return true;
}

///// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
