/***************************************************************************
                 i_masterroyalties.qs  -  description
                             -------------------
    begin                : lun may 7 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  function oficial( context ) { interna( context ); } 
  function lanzar() {
    return this.ctx.oficial_lanzar();
  }
  function obtenerParamInforme() {
    return this.ctx.oficial_obtenerParamInforme();
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  connect (this.child("toolButtonPrint"), "clicked()", _i, "lanzar()");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_lanzar()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var pI = this.iface.obtenerParamInforme();
  if (!pI) {
    return;
  }
  flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

/** \D Obtiene un array con los par�metros necesarios para establecer el informe
@return	array de par�metros o false si hay error
\end */
function oficial_obtenerParamInforme()
{
  var cursor = this.cursor();
  var seleccion= cursor.valueBuffer("id");
  if (!seleccion) {
    return false;
  }
  var paramInforme = flfactinfo.iface.pub_dameParamInforme();
  paramInforme.nombreInforme = cursor.action();
  
  if (cursor.valueBuffer("codintervalo")) {
    var intervalo= [];
    intervalo = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalo"));
    cursor.setValueBuffer("d_facturascli_fecha", intervalo.desde);
    cursor.setValueBuffer("h_facturascli_fecha", intervalo.hasta);
  }
  
  var where= "";
  if (cursor.valueBuffer("filtrardto")) {
		if (!cursor.isNull("desdedto")) {
			where += (where != "") ? " AND " : "";
			where += "lineasfacturascli.dtopor >= " + cursor.valueBuffer("desdedto");
		}
		if (!cursor.isNull("hastadto")) {
			where += (where != "") ? " AND " : "";
			where += "lineasfacturascli.dtopor <= " + cursor.valueBuffer("hastadto");
		}
	}
	
	var listaAgentes = cursor.valueBuffer("listaagentes");
	if (listaAgentes && listaAgentes != "") {
		var aAgentes = listaAgentes.split(",");
		where += (where != "") ? " AND " : "";
		where += "facturascli.codagente IN ('" + aAgentes.join("', '") + "')";
	}
	
  paramInforme.whereFijo = where;
	
  return paramInforme;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////