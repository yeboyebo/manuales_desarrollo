
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
  var cCOD_, cFEC_, cREF_, cDES_, cCAN_, cPTE_, cMER_, cCER_;
  var tblSubPartidas_,aTiposSubPartidasV_,aCamposSubPartidasV_,aColsSubPartidasV_;
  var cxTx_;
  var cabeceraPedidos_;
  var curS_, pK_;
  var lineaAct_;
  var curUbiAlt_;
  function euromoda( context ) { prod ( context ); }
  function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function refrescarArbol() {
    return this.ctx.euromoda_refrescarArbol();
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function filtraPiezas() {
    return this.ctx.euromoda_filtraPiezas();
  }
  function calculateCounter(curLS, prefijoLote) {
    return this.ctx.euromoda_calculateCounter(curLS, prefijoLote);
  }
  function cargaTablaPedidosDist() {
    return this.ctx.euromoda_cargaTablaPedidosDist();
  }
  function refrescarTotales() {
    return this.ctx.euromoda_refrescarTotales();
  }
  function tbnCerrarMovimiento_clicked() {
    return this.ctx.euromoda_tbnCerrarMovimiento_clicked();
  }
  function habilitaCanLote() {
    return this.ctx.euromoda_habilitaCanLote();
  }
  function regularizarLote(codLote,cantNueva) {
	  return this.ctx.euromoda_regularizarLote(codLote,cantNueva);
  }
  function ordenarColConsumos() {
  		return this.ctx.euromoda_ordenarColConsumos();
  }
  function iniciaTablas() {
  		return this.ctx.euromoda_iniciaTablas();
  }
  function leCampoSubPartidas_returnPressed() {
  		return this.ctx.euromoda_leCampoSubPartidas_returnPressed();
  }
  function cbCampoSubPartidas() {
  		return this.ctx.euromoda_cbCampoSubPartidas();
  }
  function rellenaComboSubPartidas() {
  		return this.ctx.euromoda_rellenaComboSubPartidas();
  }
  function rellenaCombos() {
  		return this.ctx.euromoda_rellenaCombos();
  }
  function dameParamExcelSubPartidas() {
  		return this.ctx.euromoda_dameParamExcelSubPartidas();
  }
  function tbnExcelSubPartidas_clicked() {
  		return this.ctx.euromoda_tbnExcelSubPartidas_clicked();
  }
  function cbCampoSubPartidas_activated() {
		return this.ctx.euromoda_cbCampoSubPartidas_activated();
	}
	function abreCxTx() {
		return this.ctx.euromoda_abreCxTx();
	}
	function tbnReajustarPartida_clicked() {
		return  this.ctx.euromoda_tbnReajustarPartida_clicked();
	}
	function trReajustarPartida(oParam) {
		return this.ctx.euromoda_trReajustarPartida(oParam);
	}
	function habilitaRegularizacion() {
		return this.ctx.euromoda_habilitaRegularizacion();
	}
	function tbnReajustarTramo_clicked() {
		return this.ctx.euromoda_tbnReajustarTramo_clicked();
	}
	function tbnExcelPedidos_clicked() {
		return this.ctx.euromoda_tbnExcelPedidos_clicked();
	}
	function dameParamExcelPedidos() {
		return this.ctx.euromoda_dameParamExcelPedidos();
	}
	function tdbConsumos_recordChoosed() {
		return this.ctx.euromoda_tdbConsumos_recordChoosed();
	}
	function toolButtonInsertC_clicked() {
		return this.ctx.euromoda_toolButtonInsertC_clicked();
	}
	function toolButtonEditC_clicked() {
		return this.ctx.euromoda_toolButtonEditC_clicked();
	}
	function toolButtonDeleteC_clicked() {
		return this.ctx.euromoda_toolButtonDeleteC_clicked();
	}
	function toolButtonZoomC_clicked() {
		return this.ctx.euromoda_toolButtonZoomC_clicked();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function curS_bufferCommited() {
		return this.ctx.euromoda_curS_bufferCommited();
	}
	function refrescaTablaCon() {
		return this.ctx.euromoda_refrescaTablaCon();
	}
	function ordenarColMovimientos() {
		return this.ctx.euromoda_ordenarColMovimientos();
	}
	function pbnCambiarCoste_clicked() {
		return this.ctx.euromoda_pbnCambiarCoste_clicked();
	}
	function tdbEmUbicaciones_recordChoosed() {
		return this.ctx.euromoda_tdbEmUbicaciones_recordChoosed();
	}
	function toolButtonInsertUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonInsertUbiAlt_clicked();
	}
	function toolButtonEditUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonEditUbiAlt_clicked();
	}
	function toolButtonDeleteUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonDeleteUbiAlt_clicked();
	}
	function toolButtonZoomUbiAlt_clicked() {
		return this.ctx.euromoda_toolButtonZoomUbiAlt_clicked();
	}
	function accionCursorExternoUbiAlt(accion) {
		return this.ctx.euromoda_accionCursorExternoUbiAlt(accion);
	}
	function curUbiAlt_bufferCommited() {
		return this.ctx.euromoda_curUbiAlt_bufferCommited();
	}
	function refrescaTablaUbiAlt() {
		return this.ctx.euromoda_refrescaTablaUbiAlt();
	}
	function tbnUbicacionActual_clicked() { 
    	return this.ctx.euromoda_tbnUbicacionActual_clicked();
  	}

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx
{
	function pubEuromoda(context)
	{
		ifaceCtx(context);
	}
	function pub_calculateCounter(curLS, prefijoLote) {
		return this.calculateCounter(curLS, prefijoLote);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////




/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_commonCalculateField(fN, cursor)
{
debug("euromoda_commonCalculateField " + fN);
  var _i = this.iface;
  var valor;
  var codLote = cursor.valueBuffer("codlote");
  var referencia = cursor.valueBuffer("referencia");
  
  // 	curLote.setValue("mdistribuidos", _iLS.pub_commonCalculateField("mdistribuidos", curLote));
  // 	curLote.setValue("mrecibidos", _iLS.pub_commonCalculateField("mrecibidos", curLote));
  // 	curLote.setValue("mmerma", _iLS.pub_commonCalculateField("mmerma", curLote));
  // 	curLote.setValue("pormerma", _iLS.pub_commonCalculateField("pormerma", curLote));
  // 	curLote.setValue("mptedist", _iLS.pub_commonCalculateField("mptedist", curLote));
  // 	curLote.setValue("mpterec", _iLS.pub_commonCalculateField("mpterec", curLote));
  // 	curLote.setValue("distribucionfin", _iLS.pub_commonCalculateField("distribucionfin", curLote));
  
  switch (fN) {
  		case "canlote":
		case "cantotal": {
			//valor = _i.__commonCalculateField(fN, cursor);		

			if (flfactalma.iface.pub_esPartidaXTramos(codLote)) {
				debug("ha entrado con fn:" +fN);
				valor = parseFloat(AQUtil.sqlSelect("em_tramostejido", "SUM(cantotal)", "codpartida = '" + codLote + "' "));
				valor = (!valor || isNaN(valor)) ? 0 : valor;
			} else {
				valor = _i.__commonCalculateField(fN, cursor);			
			}
			break;
		}
		case "canusada": {
			if (flfactalma.iface.pub_esPartidaXTramos(codLote)) {							
				var canUsada = parseFloat(AQUtil.sqlSelect("em_tramostejido", "SUM(canusada)", "codpartida = '" + codLote + "' ")); 
				//valor = parseFloat(AQUtil.sqlSelect("em_tramostejido", "SUM(canusada)", "codpartida = '" + codLote + "' ")); 25-04-2016
				valor = parseFloat(AQUtil.sqlSelect("em_tramostejido", "SUM(canusada) + SUM(canmerma)", "codpartida = '" + codLote + "' "));
				valor = (!valor || isNaN(valor)) ? 0 : valor;			
				
				/*valorReg = parseFloat(AQUtil.sqlSelect("movistock", "SUM(cantidad)", "codlote = '" + codLote + "' AND estado = 'HECHO' AND emidlineabpm IS NOT NULL"));
				valorReg = (!valorReg || isNaN(valorReg)) ? 0 : valorReg;
				valor -= parseFloat(valorReg);*/
			} else {
			
				var mDis = _i.commonCalculateField("mdistribuidos", cursor)
				mDis = isNaN(mDis) ? 0 : mDis;
				valor = _i.__commonCalculateField(fN, cursor);
				valor = isNaN(valor) ? 0 : valor;
				valor += parseFloat(mDis);
				valor = AQUtil.roundFieldValue(valor, "lotesstock", "canusada");
			} 
			break;
		}
		case "candisponible": {
			if (cursor.valueBuffer("distribucionfin")) {
				valor = 0;
			} else {
				valor = _i.__commonCalculateField(fN, cursor);
			}
			break;
		}
		case "msalidas": {
			valor = parseFloat(AQUtil.sqlSelect("movistock", "SUM(cantidad)", "codlote = '" + codLote + "' AND estado = 'HECHO' AND cantidad < 0"));
			valor = isNaN(valor) ? 0 : valor;
			valor *= -1;
			break;
		}
		case "mdistribuidos": {
			var mdistGit = cursor.valueBuffer("mdistribuidosgit");
			mdistGit = isNaN(mdistGit) ? 0 : mdistGit;
			valor = parseFloat(AQUtil.sqlSelect("movistock", "SUM(canpedida)", "codpartida = '" + codLote + "'"));
			valor = isNaN(valor) ? 0 : valor;
			valor += mdistGit;
			break;
		}
  case "mrecibidos": {
      var mReciGit = cursor.valueBuffer("mrecibidosgit");
			mReciGit = isNaN(mReciGit) ? 0 : mReciGit;
			valor = parseFloat(AQUtil.sqlSelect("movistock", "SUM(cantidad)", "codpartida = '" + codLote + "' AND estado = 'HECHO'"));
      valor = isNaN(valor) ? 0 : valor;
			valor += mReciGit;
      break;
    }
  case "mmerma": {
// 			if (cursor.valueBuffer("distribucionfin")) {
// 				valor = cursor.valueBuffer("mdistribuidos") - cursor.valueBuffer("mrecibidos");
// 				if (cursor.valueBuffer("mdistribuidos") == 0 && cursor.valueBuffer("mrecibidos") == 0) {
// 					valor = cursor.valueBuffer("mmermagit");
// 				}
// 			} else {
// 				valor = 0;
// 			}
			var mMermaGit = cursor.valueBuffer("mmermagit");
			mMermaGit = isNaN(mMermaGit) ? 0 : mMermaGit;
      valor = parseFloat(AQUtil.sqlSelect("movistock", "SUM(cantidad)", "codpartida = '" + codLote + "' AND estado = 'PTE' AND em_merma"));
      valor = isNaN(valor) ? 0 : valor;
			valor += mMermaGit;
      break;
    }
  case "pormerma": {
      var dist = parseFloat(cursor.valueBuffer("mdistribuidos"));
      dist = isNaN(dist) ? 0 : dist;
      var merma = parseFloat(cursor.valueBuffer("mmerma"));
      merma = isNaN(merma) ? 0 : merma;
      valor = dist != 0 ? (merma / dist) * 100 : 0;
      valor = isNaN(valor) ? 0 : valor;
      valor = AQUtil.roundFieldValue(valor, "lotesstock", "pormerma");
      break;
    }
  case "mptedist": {
  		valor = _i.commonCalculateField("candisponible", cursor);
  		/*
      var dist = parseFloat(cursor.valueBuffer("mdistribuidos"));
      dist = isNaN(dist) ? 0 : dist;
      var total = parseFloat(cursor.valueBuffer("cantotal"));
      total = isNaN(total) ? 0 : total;
      valor = total - dist;
			valor = valor < 0 ? 0 : valor;
			*/
      break;
    }
  case "mpterec": {
			valor = cursor.valueBuffer("mdistribuidos") - cursor.valueBuffer("mrecibidos") - cursor.valueBuffer("mmerma");
/// 			valor = parseFloat(AQUtil.sqlSelect("movistock", "SUM(cantidad)", "codpartida = '" + codLote + "' AND estado = 'PTE' AND NOT em_merma")); No se usa porque no va bien con los datos migrados de GIT
      valor = isNaN(valor) ? 0 : valor;
      break;
    }
  case "distribucionfin": {
  		if (flfactalma.iface.pub_esPartidaXTramos(codLote)) { 
  			/*var canDisponible = 	parseFloat(cursor.valueBuffer("candisponible"));
  			if(canDisponible == 0) {
  				valor = true;
  			} else {
  				valor = false;	
  			}*/
  			var total = parseFloat(cursor.valueBuffer("cantotal"));
  			total = isNaN(total) ? 0 : total;
  			var usada = parseFloat(cursor.valueBuffer("canusada"));
  			usada = isNaN(usada) ? 0 : usada;
  			return (total-usada) <=0;
  			
  		} else {
  			var total = parseFloat(cursor.valueBuffer("cantotal"));
      	total = isNaN(total) ? 0 : total;
      	var reci = parseFloat(cursor.valueBuffer("mrecibidos"));
      	reci = isNaN(reci) ? 0 : reci;
      	var merma = parseFloat(cursor.valueBuffer("mmerma"));
      	merma = isNaN(merma) ? 0 : merma;
      	valor = total != 0 &&  (reci + merma) >= total;
  		}

      break;
    }
	case "fechaentradaem": {
			valor = AQUtil.sqlSelect("movistock", "fechareal", "codlote = '" + cursor.valueBuffer("codlote") + "' AND cantidad > 0 AND estado = 'HECHO' ORDER BY fechareal");
//       var fecha = AQUtil.quickSqlSelect("movistock", "fechareal", "codlote = '" + cursor.valueBuffer("codlote") + "' AND cantidad > 0 ORDER BY fechareal DESC");
			break;
    }
		case "articulo": {
			valor = AQUtil.sqlSelect("articulos", "descripcion || (CASE WHEN codtamanoem IS NULL THEN '' ELSE (' ' || codtamanoem) END) || (CASE WHEN codcolorem IS NULL THEN '' ELSE (' ' || codcolorem) END)", "referencia = '" + cursor.valueBuffer("referencia") + "'");
			break;
		}
  default: {
      valor = _i.__commonCalculateField(fN, cursor);
    }
  }
debug("euromoda_commonCalculateField valor = " + valor);
  return valor;
}

function euromoda_calculateCounter(curLS, prefijoLote)
{
	var _i = this.iface;

/*	if (!_i.abreCxTx()) {
		return false;
	}*/

	if (curLS == "codlote") {
		return _i.__calculateCounter(curLS);
	}
	var util = new FLUtil();
	var prefijo = "LS";
	
	var referencia = curLS.valueBuffer("referencia");

	if (flfactalma.iface.pub_esReferenciaXPiezas(referencia)) {
		if(prefijoLote && prefijoLote != "") {
			prefijo = prefijoLote; 
		} else {
			prefijo = "PZ"; /// Piezas		
		}
		
	} else if (flfactalma.iface.pub_esReferenciaXPartidas(referencia)) {
		prefijo = "PT"; /// Partidas
	} else {
		var tipo = AQUtil.sqlSelect("articulos", "em_tipoarticulo", "referencia = '" + referencia + "'");
		if (tipo == "Producto") {
			prefijo = "PD";
		}
	}
	
	var ultimoLote:Number = util.sqlSelect("secuenciaslotes","valor","prefijo = '" + prefijo + "'");

	if (!ultimoLote) {
		var idUltimo = util.sqlSelect("lotesstock", "codlote", "codlote LIKE '" + prefijo + "%' ORDER BY codlote DESC");
		ultimoLote = idUltimo ? parseFloat(idUltimo.right(8)) : 0;
		ultimoLote += 1;
		AQSql.insert("secuenciaslotes", ["prefijo","valor"], [prefijo, ultimoLote]);
	}
	else {
		ultimoLote += 1;
		
		AQSql.update("secuenciaslotes", ["valor"], [ultimoLote], "prefijo = '" + prefijo + "'");
	}

	var id = prefijo + flfacturac.iface.pub_cerosIzquierda((ultimoLote).toString(), 8);

	return id;
}

function euromoda_abreCxTx()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (!_i.cxTx_) {
		_i.cxTx_ = "CxTx";
	}
	var dbTx= AQSql.database(_i.cxTx_);
	/*
	if (_i.cxTx_ && dbTx.connectionName() == _i.cxTx_ ) {
		/// Porque aunque se deje abierta a los 15min de inactividad TCP muere y no se detecta que se haya roto la conexi�n
		if (!sys.removeDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error en la desconexi�n."), "info");
			return false;
		}
		dbTx = AQSql.database(_i.cxTx_);
	}
	*/
	if (dbTx.connectionName() != _i.cxTx_ || !dbTx.isOpen()) {
		if (!sys.addDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error al establecer la conexi�n de comprobaci�n de transacciones."), "warn");
			return false;
		}
	}
	return true;
}


function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
  _i.filtraPiezas();
  _i.cargaTablaPedidosDist();
	this.child("tbwLotesStock").setTabEnabled("TabPageEstado", false);
	connect(this.child("tbnCerrarMovimiento"), "clicked()", _i, "tbnCerrarMovimiento_clicked");
	_i.habilitaCanLote();
	_i.ordenarColConsumos();
	_i.ordenarColMovimientos();
	connect(this.child("tbnExcelSubPartidas"), "clicked()", _i, "tbnExcelSubPartidas_clicked");	
	connect(this.child("cbCampoSubPartidas"), "activated(QString)", _i, "cbCampoSubPartidas_activated");
	connect(this.child("leCampoSubPartidas"), "returnPressed()", _i, "leCampoSubPartidas_returnPressed");
	connect(this.child("tbnReajustarPartida"), "clicked()", _i, "tbnReajustarPartida_clicked");
	connect(this.child("tbnReajustarTramo"), "clicked()", _i, "tbnReajustarTramo_clicked");
	connect(this.child("tbnExcelPedidos"), "clicked()", _i, "tbnExcelPedidos_clicked");

	if(this.child("toolButtonInsertUbiAlt")) {
		connect(this.child("toolButtonInsertUbiAlt"), "clicked()", _i, "toolButtonInsertUbiAlt_clicked");	
	}
	
	if(this.child("toolButtonEditUbiAlt")) {
		connect(this.child("toolButtonEditUbiAlt"), "clicked()", _i, "toolButtonEditUbiAlt_clicked");	
	}
	
	if(this.child("toolButtonDeleteUbiAlt")) {
		connect(this.child("toolButtonDeleteUbiAlt"), "clicked()", _i, "toolButtonDeleteUbiAlt_clicked");	
	}
	
	if(this.child("toolButtonZoomUbiAlt")) {
		connect(this.child("toolButtonZoomUbiAlt"), "clicked()", _i, "toolButtonZoomUbiAlt_clicked");	
	}
	if(this.child("tdbEmUbicaciones")) {
		connect(this.child("tdbEmUbicaciones").cursor(), "recordChoosed()", _i, "tdbEmUbicaciones_recordChoosed");		
	}
	if (this.child("tbnUbicacionActual")) {
		connect(this.child("tbnUbicacionActual"), "clicked()", _i, "tbnUbicacionActual_clicked");
	}
	
	_i.iniciaTablas();
	_i.rellenaCombos();	
	_i.habilitaRegularizacion();
	

	var cursor = this.cursor();
	if(cursor.modeAccess() == cursor.Insert) {
		var cursorRelation = cursor.cursorRelation();

		if(cursorRelation) {
			if(cursorRelation.table() == "lineasalbaranesprov") {
				if(cursorRelation.valueBuffer("codformato") && cursorRelation.valueBuffer("codformato") != "") {
					this.child("fdbCodFormato").setValue(cursorRelation.valueBuffer("codformato"));
}
			}
			
		}
	}

	connect(this.child("toolButtonInsertC"), "clicked()", _i, "toolButtonInsertC_clicked");
	connect(this.child("toolButtonEditC"), "clicked()", _i, "toolButtonEditC_clicked");
	connect(this.child("toolButtonDeleteC"), "clicked()", _i, "toolButtonDeleteC_clicked");
	connect(this.child("toolButtonZoomC"), "clicked()", _i, "toolButtonZoomC_clicked");
	connect(this.child("tdbConsumos").cursor(), "recordChoosed()", _i, "tdbConsumos_recordChoosed");	
	connect(this.child("pbnCambiarCoste"), "clicked()", _i, "pbnCambiarCoste_clicked");
	
}


function euromoda_tdbConsumos_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEditC_clicked();
}


function euromoda_toolButtonInsertC_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");
}

function euromoda_toolButtonEditC_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDeleteC_clicked()
{
	var _i = this.iface;

	var res = flfactppal.iface.preguntaMsg(sys.translate("El registro activo ser� borrado �Desea continuar?"),"info",this,MessageBox.Yes, MessageBox.No);  
	if (res != MessageBox.Yes) {
		return;
	}
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoomC_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}

function euromoda_accionCursorExterno(accion)
{
	debug("euromoda_accionCursorExterno");
	var _i = this.iface;
	var cursor = this.cursor();
	//var curTabla = new FLSqlCursor("movistock");
	var curTabla = this.child("tdbConsumos").cursor();
	if (_i.curS_) {
		disconnect(_i.curS_, "commited()", _i, "refrescaTablaCon");
		disconnect(_i.curS_, "commited()", _i, "curS_bufferCommited");
		_i.curS_ = undefined;
	}
	
	_i.curS_ = new FLSqlCursor("movistock");
	_i.curS_.setAction("movistock");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {			
			debug("curTabla.primaryKey(): "+curTabla.primaryKey());
			debug("******" +curTabla.valueBuffer(curTabla.primaryKey()));
			_i.curS_.select(curTabla.primaryKey() + " = " + curTabla.valueBuffer(curTabla.primaryKey()));
			if (!_i.curS_.first()) {
				debug("no lo encuentra");
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");
			_i.curS_.insertRecord();
			_i.curS_.setValueBuffer("codloteprod",cursor.valueBuffer("codlote"));
			break;
		}
		case "edit": {
			_i.lineaAct_ = this.child("tdbConsumos").currentRow();				
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");			
			_i.curS_.editRecord();				
			break;
		}
		case "del": {
			
			_i.curS_.setModeAccess(_i.curS_.Del);
 			_i.curS_.refreshBuffer(); 
 			if(!_i.curS_.commitBuffer()) {
 				return false;
 			}
			break;
		}
		case "browse": {	
			_i.curS_.browseRecord();
			break;
		}
	}
}

function euromoda_curS_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	this.child("tdbConsumos").refresh();
	var dtbLC = this.mainWidget().child("tdbConsumos").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);	
	var pos = cursor.atFromBinarySearch("idmovimiento", _i.pK_, asc);	
	cursor.seek(pos);
	cursor.refresh()
}

function euromoda_refrescaTablaCon()
{
	var _i = this.iface;
	var cursor = this.cursor();
	this.child("tdbConsumos").refresh();
}



function euromoda_habilitaCanLote()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var habilitado = true;
	if (cursor.modeAccess() == cursor.Edit) {
		var codOrden = cursor.valueBuffer("codordenproduccion");
		if (codOrden) {
			if (AQUtil.sqlSelect("pedidosprov", "idpedido", "codordenprod = '" + codOrden + "'")) {
				habilitado = false;
			}
		}
	}
	if (habilitado) {
		sys.enableObj(this, "fdbCanLote");
	} else {
		sys.disableObj(this, "fdbCanLote");
	}
	if (cursor.modeAccess() != cursor.Insert) {
		sys.disableObj(this, "fdbCodAlmacen");
	}
}

function euromoda_tbnCerrarMovimiento_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
// 	var curM = this.child("tdbMoviStock").cursor();
// 	if (!curM.valueBuffer("idmovimiento")) {
// 		return;
// 	}
// 	if (!curM.isNull("idlineapp")) {
// 		sys.warnMsgBox(sys.translate("El movimiento tiene una l�nea de pedido de proveedor asociado.\nDebe cerrar o reabrir la l�nea"));
// 		return;
// 	}
// 	if (curM.valueBuffer("estado") != "PTE") {
// 		sys.warnMsgBox(sys.translate("El movimiento debe estar pendiente"));
// 		return;
// 	}
// 	if (curM.valueBuffer("cantidad") >= 0) {
// 		sys.warnMsgBox(sys.translate("El movimiento debe ser negativo"));
// 		return;
// 	}
// 	curM.setModeAccess(curM.Edit);
// 	curM.refreshBuffer();
// 	curM.setValueBuffer("merma", !curM.valueBuffer("merma"));
// 	if (!curM.commitBuffer()) {
// 		return false;
// 	}
	if (cursor.valueBuffer("distribucionfin")) {
		sys.setObjText(this, "fdbDistribucionFin", false);
		sys.setObjText(this, "fdbMMerma", _i.commonCalculateField("mmerma", cursor));
		sys.setObjText(this, "fdbPorMerma", _i.commonCalculateField("pormerma", cursor));
		sys.setObjText(this, "fdbMPteRec", _i.commonCalculateField("mpterec", cursor));
	} else {
		sys.setObjText(this, "fdbDistribucionFin", true);
		sys.setObjText(this, "fdbMPteRec", 0);
		sys.setObjText(this, "fdbMMerma", _i.commonCalculateField("mmerma", cursor));
		sys.setObjText(this, "fdbPorMerma", _i.commonCalculateField("pormerma", cursor));
	}
}

function euromoda_cargaTablaPedidosDist()
{
  var cursor = this.cursor();
  var codLote = cursor.valueBuffer("codlote");
  
  var t = this.child("tblLineasPedido");
  var _i = this.iface;
  var c = 0, sep = "*", cab = "";
  cab += sys.translate("Pedido") + sep;
  _i.cCOD_ = c++;
  cab += sys.translate("Fecha") + sep;
  _i.cFEC_ = c++;
  cab += sys.translate("Referencia") + sep;
  _i.cREF_ = c++;
  cab += sys.translate("Producto") + sep;
  _i.cDES_ = c++;
  cab += sys.translate("Cantidad") + sep;
  _i.cCAN_ = c++;
  cab += sys.translate("Pendiente") + sep;
  _i.cPTE_ = c++;
  cab += sys.translate("Merma") + sep;
  _i.cMER_ = c++;
  cab += sys.translate("Cerrado");
  _i.cCER_ = c++;
  _i.cabeceraPedidos_ = cab.split(sep);
  t.setNumCols(c);
  t.setColumnWidth(_i.cCOD_, 100);
  t.setColumnWidth(_i.cFEC_, 80);
  t.setColumnWidth(_i.cREF_, 100);
  t.setColumnWidth(_i.cDES_, 200);
  t.setColumnWidth(_i.cCAN_, 60);
  t.setColumnWidth(_i.cPTE_, 60);
  t.setColumnWidth(_i.cMER_, 60);
  t.setColumnWidth(_i.cCER_, 60);
  
  t.setColumnLabels(sep, cab);
  t.setNumRows(0);
//  t.setReadOnly(true);
  
  var q = new FLSqlQuery;
  q.setSelect("p.codigo, p.fecha, lp.referencia, lp.descripcion, ms.canpedida, ms.cantidad, ms.em_merma, lp.idlinea");
  q.setFrom("movistock ms INNER JOIN lineaspedidosprov lp ON ms.idlineapp = lp.idlinea INNER JOIN pedidosprov p ON lp.idpedido = p.idpedido");
  q.setWhere("ms.codpartida = '" + codLote + "'");
  q.setForwardOnly(true);
  if (!q.exec()) {
    return false;
  }
  var f = 0, cerrada, rx, merma;
  while (q.next()) {
// 		rx = parseFloat(AQUtil.sqlSelect("lineasalbaranesprov la INNER JOIN movistock ms ON la.idlinea = ms.idlineaap", "SUM(ms.cantidad)", "la.idlineapedido = " + q.value("lp.idlinea") + " AND ms.codpartida = '" + codLote + "'", "lineasalbaranesprov"));
// 		rx = isNaN(rx) ? 0 : rx;
    cerrada = q.value("ms.em_merma");
    t.insertRows(f);
    t.setText(f, _i.cCOD_, q.value("p.codigo"));
    t.setText(f, _i.cFEC_, AQUtil.dateAMDtoDMA(q.value("p.fecha")));
    t.setText(f, _i.cREF_, q.value("lp.referencia"));
    t.setText(f, _i.cDES_, q.value("lp.descripcion"));



    t.setText(f, _i.cCAN_, AQUtil.roundFieldValue(q.value("ms.canpedida"), "movistock","cantidad"));
		t.setText(f, _i.cPTE_, cerrada ? 0 : q.value("ms.cantidad"));
// 		merma = q.value("ms.canpedida") - rx;
		t.setText(f, _i.cMER_, cerrada ? AQUtil.roundFieldValue(q.value("ms.cantidad"), "movistock","cantidad") : 0);
// 		t.setText(f, _i.cMER_, merma);
    t.setText(f, _i.cCER_, cerrada ? sys.translate("S�") : sys.translate("No"));
  }
}

function euromoda_filtraPiezas()
{
  return;
  var cursor = this.cursor();
  var codLote = cursor.valueBuffer("codlote");
  var filtro = "codlote IN (SELECT codlote FROM movistock WHERE codpartida = '" + codLote + "')";
  this.child("tdbPiezas").setFilter(filtro);
  this.child("tdbPiezas").refresh();
}

function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "mmermagit": {
			sys.setObjText(this, "fdbMMerma", _i.calculateField("mmerma"));
			sys.setObjText(this, "fdbPorMerma", _i.calculateField("pormerma"));
			sys.setObjText(this, "fdbDistribucionFin", _i.calculateField("distribucionfin"));
			break;
		}
		case "mdistribuidos": {
			sys.setObjText(this, "fdbCanUsada", _i.calculateField("canusada"));
			sys.setObjText(this, "fdbMPteDist", _i.calculateField("mptedist"));
			sys.setObjText(this, "fdbMPteRec", _i.calculateField("mpterec"));
			break;
		}
		case "mrecibidos": {
			sys.setObjText(this, "fdbMPteRec", _i.calculateField("mpterec"));
			sys.setObjText(this, "fdbDistribucionFin", _i.calculateField("distribucionfin"));
			break;
		}
		case "mdistribuidosgit": {
			sys.setObjText(this, "fdbMDistribuidos", _i.calculateField("mdistribuidos"));
			break;
		}
		case "mrecibidosgit": {
			sys.setObjText(this, "fdbMRecibidos", _i.calculateField("mrecibidos"));
			break;
		}
		case "distribucionfin": {
			sys.setObjText(this, "fdbCanDisponible", _i.calculateField("candisponible"));
			break;
		}
		default: {
			_i.__bufferChanged(fN);
		}
	}	
}

function euromoda_refrescarArbol()
{
	return true;
}

function euromoda_refrescarTotales()
{
	var _i = this.iface;
	_i.__refrescarTotales();
	
	this.child("fdbMPteDist").setValue(this.iface.calculateField("mptedist"));
}

function euromoda_regularizarLote(codLote,cantNueva)
{
	var _i = this.iface;
	var curLote = new FLSqlCursor("lotesstock");
	if(!codLote) {
		return false;
	}
	
	curLote.select("codlote = '" + codLote + "'");
	if(!curLote.first()) {
		return false;
	}
	
	curLote.setModeAccess(curLote.Edit);
	curLote.refreshBuffer();
	
	var codAlmacen = curLote.valueBuffer("codalmacen");
	if(!codAlmacen || codAlmacen == "") {
		return false;
	}
	
	var cantActual = parseFloat(curLote.valueBuffer("candisponible"));
	if(!cantActual)
		cantActual = 0;
	
	var movimiento = parseFloat(cantNueva) - cantActual;
	
	var fecha = new Date();
	var hora = fecha.toString().right(8);
	
	var curRegLS = new FLSqlCursor("reglotestock");
	curRegLS.setModeAccess(curRegLS.Insert);
	curRegLS.refreshBuffer();
	curRegLS.setValueBuffer("codlote",codLote);
	curRegLS.setValueBuffer("actual",cantActual);
	curRegLS.setValueBuffer("nueva",cantNueva);
	curRegLS.setValueBuffer("movimiento",movimiento);
	curRegLS.setValueBuffer("fecha",fecha);
	curRegLS.setValueBuffer("hora",hora);
	curRegLS.setValueBuffer("codalmacen",codAlmacen);
	curRegLS.setValueBuffer("motivo","Recuento a trav�s de pistola");
	if(!curRegLS.commitBuffer())
		return false;
	
	return true;
}

function euromoda_ordenarColConsumos()
{
	
	var t = this.child("tdbConsumos");
  	var listaCampos;   
	listaCampos = ["referencia","descripcionart","codtamanoemart","codcoloremart","estado","cantidad","reservaex","reservapr","reservaaf","concepto","canpedida"];	
	t.setOrderCols(listaCampos);

}

function euromoda_iniciaTablas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codLote = cursor.valueBuffer("codlote");	
	
	_i.tblSubPartidas_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblSubPartidas"));	
	var q = new AQSqlQuery;		
	q.setSelect("lotesstock.codlote,lotesstock.referencia,articulos.descripcion,lotesstock.candisponible,lotesstock.canlote,lotesstock.cantotal,lotesstock.canusada,lotesstock.msalidas, lotesstock.ubicacion, lotesstock.codbobina, em_bobinas.soporteactual, em_bobinas.estado");
	q.setFrom("lotesstock inner join em_tramostejido AS t2 on lotesstock.codlote = t2.codpartida inner join em_tramostejido AS t on t2.idtramoorigen = t.idtramo INNER JOIN articulos ON articulos.referencia = lotesstock.referencia LEFT OUTER JOIN em_bobinas ON em_bobinas.codbobina = lotesstock.codbobina");	
	q.setWhere("t.codpartida = '" + codLote + "'  AND lotesstock.codlote like '%PT%' order by lotesstock.codlote");
	debug("sql de subpartidas: "+q.sql());	
	
	_i.tblSubPartidas_.setQuery(q);
	_i.tblSubPartidas_.setColumnWidth("lotesstock.codlote", 80);
	_i.tblSubPartidas_.setColumnWidth("lotesstock.referencia", 70);
  	_i.tblSubPartidas_.setColumnWidth("articulos.descripcion", 450);
  	_i.tblSubPartidas_.setColumnWidth("lotesstock.candisponible", 80);
  	_i.tblSubPartidas_.setColumnWidth("lotesstock.canlote", 80);
  	_i.tblSubPartidas_.setColumnWidth("lotesstock.cantotal", 80);
  	_i.tblSubPartidas_.setColumnWidth("lotesstock.canusada", 80);
  	_i.tblSubPartidas_.setColumnWidth("lotesstock.msalidas", 80);  
  	_i.tblSubPartidas_.setColumnWidth("lotesstock.ubicacion", 85);
  	_i.tblSubPartidas_.setColumnWidth("lotesstock.codbobina", 85);
  	_i.tblSubPartidas_.setColumnWidth("em_bobinas.soporteactual", 85);	
  	_i.tblSubPartidas_.setColumnWidth("em_bobinas.estado", 110);	
	_i.tblSubPartidas_.refresh();	
	
}

function euromoda_rellenaCombos()
{
	var _i = this.iface;
	_i.rellenaComboSubPartidas();

}

function euromoda_rellenaComboSubPartidas()
{

	//hayq ue rellenar el combo

	var _i = this.iface;
	var aCampos = _i.tblSubPartidas_.getCabeceras();
	var aColsN = _i.tblSubPartidas_.getColsN();
	var aMtd = _i.tblSubPartidas_.getColsMtd();
	aCamposSubPartidasV_ = [];
	aColsSubPartidasV_ = [];
	aTiposSubPartidasV_ = [];
	for(var i = 0; i < aMtd.length; i++){
		var visible = aMtd[i].visibleGrid();

		if(visible) {
			aCamposSubPartidasV_.push(aCampos[i]); 
			aColsSubPartidasV_.push(aColsN[i]);
			if(aMtd[i] == 19) {
				aTiposSubPartidasV_.push(19);			
			} else {
				aTiposSubPartidasV_.push(aMtd[i].type());
			} 

		}		
	}	

	this.child("cbCampoSubPartidas").clear();
	this.child("cbCampoSubPartidas").insertStringList(aCamposSubPartidasV_);	 

}

function euromoda_cbCampoSubPartidas_activated()
{
	debug("valor combo: "+this.child("cbCampoSubPartidas").currentText);
	debug("indice combo: "+this.child("cbCampoSubPartidas").currentItem);
	var indice = this.child("cbCampoSubPartidas").currentItem;
	this.child("tblSubPartidas").sortColumn(indice, true, true);
}

function euromoda_leCampoSubPartidas_returnPressed()
{
	var _i = this.iface;
	var indice = this.child("cbCampoSubPartidas").currentItem;
	var valor = this.child("leCampoSubPartidas").text;
	var columna = aColsSubPartidasV_[indice];
	var tipo = aTiposSubPartidasV_[indice];
	var sF = "";

	if(valor && valor != "") {
		if(tipo == 3) {
			sF = "( upper("+columna  + ") like '%" + valor.upper() + "%' )";			
		} else {
			if(isNaN(valor)) {
				return ;
			}
			sF = "("+columna  + " = " + valor+ ")";
		}
		debug("sF: "+sF);
	} 

	_i.tblSubPartidas_.setSearchFilter(sF, true); 

}

function euromoda_tbnExcelSubPartidas_clicked()
{
	var _i = this.iface;
	var oParamExcel = _i.dameParamExcelSubPartidas(); 
	_i.tblSubPartidas_.exportarTablaExcel(oParamExcel);
}

function euromoda_dameParamExcelSubPartidas()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var codLote = cursor.valueBuffer("codlote");
  	var oParam = flfactppal.iface.pub_dameParamExcel();	
	var fecha = new Date;	
	var prefijo = "Subpartidas_de_" + codLote;
  	oParam.nombreFichero = fleumoesta.iface.pub_dameNombreFecha(prefijo);
  	oParam.titulo = "Subpartidas de " + codLote;
  	return oParam;
}

/*function euromoda_tbnReajustarPartida_clicked()

{
	var _i = this.iface;
	var cursor = this.cursor();
	var codPartida = cursor.valueBuffer("codlote");
	if(!codPartida || codPartida =="") {
		sys.warnMsgBox(sys.translate("No hay ninguna partida que reajustar"));	
		return;
	}	
	//var idTramo = AQUtil.sqlSelect("em_tramostejido","idtramo","codpartida = '" + codPartida + "' order by caninicio desc ");
	var idTramo = AQUtil.sqlSelect("em_tramostejido","idtramo","codpartida = '" + codPartida + "' order by candisponible desc ");	
	if(!idTramo || idTramo =="") {
		sys.warnMsgBox(sys.translate("No hay ningun tramo que reajustar"));	
		return;
	}
	var canTotalTramo = AQUtil.sqlSelect("em_tramostejido", "cantotal", "idtramo = " + idTramo );
	var cantidad = Input.getNumber(sys.translate("Introduzca la nueva cantidad de metros"), 0, 2, 0,999999999 , "AbanQ");
	debug("cantidad");
	if (cantidad == "undefined") {
		return false;
	}
	if(!cantidad) {
		cantidad = 0;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al reajustar la partida");
	oParam.codPartida = codPartida;
	oParam.cantidad = cantidad;
	oParam.idTramo = idTramo;	
	oParam.motivo = "Regularizaci�n de partida manual";
	
	var f = new Function("oParam", "return formRecordlotesstock.iface.trReajustarPartida(oParam)");	
	if (!sys.runTransaction(f, oParam)) {		
		sys.warnMsgBox(sys.translate("Se ha producido un error al reajustar la partida %1").arg(codPartida));
		return;
	}
	sys.infoMsgBox(sys.translate("Reajuste de la partida %1 realizada correctamente").arg(codPartida));	
	this.child("tdbRegLoteStock").refresh();
	_i.refrescarTotales();
}*/

function euromoda_tbnReajustarPartida_clicked()
{
	var _i = this.iface; 
	var cursor = this.cursor();
	var codPartida = cursor.valueBuffer("codlote"); 
	if(!codPartida || codPartida =="") {
		sys.warnMsgBox(sys.translate("No hay ninguna partida que reajustar"));	
		return;
	}	
	var numTramos = AQUtil.sqlSelect("em_tramostejido","count(*)","codpartida= '" + codPartida + "'");
	if(numTramos > 1) {
		sys.warnMsgBox(sys.translate("La partida tiene m�s de un tramo, debe regularizar tramo a tramo desde la pesta�a de tramos."));	
		return;
	} 
	var idTramo = AQUtil.sqlSelect("em_tramostejido","idtramo","codpartida = '" + codPartida + "' order by candisponible desc ");	
	if(!idTramo || idTramo =="") {
		sys.warnMsgBox(sys.translate("No hay ningun tramo que reajustar"));	
		return;
	}
	var canTotalTramo = AQUtil.sqlSelect("em_tramostejido", "cantotal", "idtramo = " + idTramo );
	var cantidad = Input.getNumber(sys.translate("Introduzca la nueva cantidad de metros"), 0, 2, 0,999999999 , "AbanQ");
	debug("cantidad");
	if (cantidad == "undefined") {
		return false;
	}
	if(!cantidad) {
		cantidad = 0;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al reajustar la partida");
	oParam.codPartida = codPartida;
	oParam.cantidad = cantidad;
	oParam.idTramo = idTramo;	
	oParam.motivo = "Regularizaci�n de partida manual";
	
	var f = new Function("oParam", "return formRecordlotesstock.iface.trReajustarPartida(oParam)");	
	if (!sys.runTransaction(f, oParam)) {		
		sys.warnMsgBox(sys.translate("Se ha producido un error al reajustar la partida %1").arg(codPartida));
		return;
	}
	sys.infoMsgBox(sys.translate("Reajuste de la partida %1 realizada correctamente").arg(codPartida));	
	this.child("tdbRegLoteStock").refresh();
	_i.refrescarTotales();
	
}

function euromoda_trReajustarPartida(oParam)
{
	var _i = this.iface;
	var codPartida = oParam.codPartida;
	var cantidad = oParam.cantidad;
	var idTramo = oParam.idTramo;
	var motivo = oParam.motivo;
	debug("cantidad a regularizar: "+cantidad);
	debug("motivo: "+motivo);
	if(!formem_estampacion.iface.regulPartida(codPartida, cantidad, motivo)) {
		return false;
	}

	if(!formem_estampacion.iface.regulTramosPartida(idTramo, cantidad)) {
		return false;
	}

	return true;
}

function euromoda_habilitaRegularizacion()
{
	var cursor = this.cursor();
	var porTramos = cursor.valueBuffer("portramos");
	debug("porTRamos: "+porTramos);
	if(porTramos) {
		debug("si tramos");
		sys.disableObj(this, "toolButtomInsertReg");
		sys.disableObj(this, "toolButtonEditReg");
		sys.disableObj(this, "toolButtonDeleteReg");
		sys.enableObj(this, "tbnReajustarPartida");		
		//sys.runObjMethod(this, "tdbRegLoteStock", "setOnlyTable", true);	
		sys.runObjMethod(this, "tdbRegLoteStock", "setReadOnly", true);
	} else {
		debug("no tramos");
		sys.enableObj(this, "toolButtomInsertReg");
		sys.enableObj(this, "toolButtonEditReg");
		sys.enableObj(this, "toolButtonDeleteReg");
		sys.disableObj(this, "tbnReajustarPartida");		
	}

}

function euromoda_tbnReajustarTramo_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codPartida = cursor.valueBuffer("codlote");
	if(!codPartida || codPartida =="") {
		sys.warnMsgBox(sys.translate("No hay ninguna partida que reajustar"));	
		return;
	}	
	var cursorTramo = this.child("tdbTramos").cursor();	
	var idTramo = cursorTramo.valueBuffer("idtramo");
	if(!idTramo || idTramo =="") {
		sys.warnMsgBox(sys.translate("No hay ningun tramo que reajustar"));	
		return;
	}
	var canTotalTramo = cursorTramo.valueBuffer("cantotal");
	var cantidad = Input.getNumber(sys.translate("Introduzca la nueva cantidad de metros"), 0, 2, 0,999999999 , "AbanQ");
	debug("cantidad");
	if (cantidad == "undefined") {
		return false;
	}
	if(!cantidad) {
		cantidad = 0;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al reajustar la partida");
	oParam.codPartida = codPartida;
	oParam.cantidad = cantidad;
	oParam.idTramo = idTramo;	
	oParam.motivo = "Regularizaci�n de partida manual";
	
	var f = new Function("oParam", "return formRecordlotesstock.iface.trReajustarPartida(oParam)");	
	if (!sys.runTransaction(f, oParam)) {		
		sys.warnMsgBox(sys.translate("Se ha producido un error al reajustar la partida %1").arg(codPartida));
		return;
	}
	sys.infoMsgBox(sys.translate("Reajuste de la partida %1 realizada correctamente").arg(codPartida));	
	this.child("tdbRegLoteStock").refresh();
	_i.refrescarTotales();

}

function euromoda_tbnExcelPedidos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var oParam = _i.dameParamExcelPedidos();
	flfactppal.iface.pub_exportarTablaExcel(oParam);
}

function euromoda_dameParamExcelPedidos()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codLote = cursor.valueBuffer("codlote");
	var oParam = flfactppal.iface.pub_dameParamExcel();
	
	oParam.nombreFichero = "distribucion_"+codLote;
	oParam.tabla = this.child("tblLineasPedido");
	oParam.nombreColumnas = _i.cabeceraPedidos_;
	oParam.titulo = "DISTRIBUCI�N DE PARTIDA " + codLote;
  	return oParam;
}

function euromoda_ordenarColMovimientos()
{
	
	var t = this.child("tdbMoviStock");
  	var listaCampos;   
	listaCampos = ["fechareal","horareal","idmovimiento"];	
	t.setOrderCols(listaCampos);

}

function euromoda_pbnCambiarCoste_clicked()
{
	var _i = this.iface;	
	var cursor = this.cursor();
	var hoy = new Date();
	var coste = cursor.valueBuffer("em_costefinaleur");

	var fecha = cursor.valueBuffer("em_fechacostefinal");

	if(!fecha || fecha =="") {
		fecha = cursor.valueBuffer("fechaentradaem");
		if(!fecha || fecha == "") {
			fecha = hoy;
		}
	}

	var f = new FLFormSearchDB("em_costefinallote");
	var curD = f.cursor();
	curD.setModeAccess(curD.Insert);
	curD.refreshBuffer();
	if(coste && coste != "") {
		curD.setValueBuffer("em_costefinaleur",coste);	
	}
	if(fecha && fecha != "") {
		curD.setValueBuffer("em_fechacostefinal",fecha);	
	}
	
	f.setMainWidget();
	f.exec();
	if (!f.accepted()) {		
		return false;
	}
	debug("aceptado");
	var costeFinal = curD.valueBuffer("em_costefinaleur");
	var fechaFinal = curD.valueBuffer("em_fechacostefinal");
	debug("costeFinal: "+costeFinal);
	debug("fechaFinal: "+fechaFinal);
	if(fechaFinal && fechaFinal != "") {
		this.child("fdbFechaCosteFinal").setValue(fechaFinal);
		this.child("fdbCosteFinalEur").setValue(costeFinal);
	} else {
		debug("la pone a vacio");
		this.child("fdbFechaCosteFinal").setValue("");	
		this.child("fdbCosteFinalEur").setValue("");
		cursor.setNull("em_costefinaleur");	
		cursor.setNull("em_fechacostefinal");
	}

	var codAlbaran = cursor.valueBuffer("codalbaranprov");
	if(!codAlbaran || codAlbaran =="") {
		return true;
	}

 	var referencia = cursor.valueBuffer("referencia");
 	var codLote = cursor.valueBuffer("codlote"); 
 	var q = new AQSqlQuery;	
	q.setSelect("lot.codlote");
	q.setFrom("lineasalbaranesprov la inner join albaranesprov a on la.idalbaran = a.idalbaran inner join lotesstock lot on lot.referencia = la.referencia and lot.codalbaranprov=a.codigo");
	q.setWhere("a.codigo = '" + codAlbaran + "' and lot.referencia = '" + referencia + "' and lot.codlote != '" + codLote + "'"); 				
	debug("query: "+q.sql());
	if (!q.exec()){
		return true;
	}  
	var numLotes = q.size();
	debug("numLotes: "+numLotes);
	if(numLotes > 0) {
		var res = flfactppal.iface.preguntaMsg(sys.translate("Hay m�s lotes de esta referencia en el mismo albar�n, �quieres asignar a todos los mismos COSTES?"),"info",this,MessageBox.Yes, MessageBox.No);  
  		if (res != MessageBox.Yes) {
			return true;
  		}
	}
	while(q.next())
	{
		var codLoteNuevo = q.value("lot.codlote");
		debug("codLote: "+codLote);
		if(fechaFinal && fechaFinal != "") {
			debug("actualiza con valor");
			if (!AQUtil.execSql("UPDATE lotesstock SET em_costefinaleur = " + costeFinal + ",em_fechacostefinal = '" + fechaFinal + "'  WHERE codlote = '" + codLoteNuevo + "'")) {
				debug("error1");
				return false;
			}
		} else {
			debug("actualiza a nulo");
			if (!AQUtil.execSql("UPDATE lotesstock SET em_costefinaleur = NULL,em_fechacostefinal = NULL  WHERE codlote = '" + codLoteNuevo + "'")) {
				debug("error2");
				return false;
			}
		}
		
	}	
	
	
}

function euromoda_tdbEmUbicaciones_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEditUbiAlt_clicked();
}


function euromoda_toolButtonInsertUbiAlt_clicked()
{
	var _i = this.iface;
	_i.accionCursorExternoUbiAlt("insert");
}

function euromoda_toolButtonEditUbiAlt_clicked()
{
	var _i = this.iface;
	_i.accionCursorExternoUbiAlt("edit");
}

function euromoda_toolButtonDeleteUbiAlt_clicked()
{
	var _i = this.iface;

	var res = flfactppal.iface.preguntaMsg(sys.translate("El registro activo ser� borrado �Desea continuar?"),"info",this,MessageBox.Yes, MessageBox.No);  
	if (res != MessageBox.Yes) {
		return;
	}
	_i.accionCursorExternoUbiAlt("del");
}

function euromoda_toolButtonZoomUbiAlt_clicked()
{
	var _i = this.iface;
	_i.accionCursorExternoUbiAlt("browse");
}

function euromoda_accionCursorExternoUbiAlt(accion)
{
	debug("euromoda_accionCursorExternoUbiAlt");
	var _i = this.iface;
	var cursor = this.cursor();
	var curTabla = this.child("tdbEmUbicaciones").cursor();
	if (_i.curUbiAlt_) {
		disconnect(_i.curUbiAlt_, "commited()", _i, "refrescaTablaUbiAlt");
		disconnect(_i.curUbiAlt_, "commited()", _i, "curUbiAlt_bufferCommited");
		_i.curUbiAlt_ = undefined;
	}
	
	_i.curUbiAlt_ = new FLSqlCursor("em_lotesxubicacion");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {			
			debug("curTabla.primaryKey(): "+curTabla.primaryKey());
			debug("******" +curTabla.valueBuffer(curTabla.primaryKey()));
			_i.curUbiAlt_.select(curTabla.primaryKey() + " = " + curTabla.valueBuffer(curTabla.primaryKey()));
			if (!_i.curUbiAlt_.first()) {
				debug("no lo encuentra");
				return false;
			}
		}
	}	
	switch (accion) {
		case "insert": {
			connect(_i.curUbiAlt_, "commited()", _i, "curUbiAlt_bufferCommited");
			formRecordem_lotesxubicacion.iface.codLote_ = cursor.valueBuffer("codlote");
			_i.curUbiAlt_.insertRecord();
			_i.curUbiAlt_.setValueBuffer("codlote",cursor.valueBuffer("codlote"));
			break;
		}
		case "edit": {
			connect(_i.curUbiAlt_, "commited()", _i, "curUbiAlt_bufferCommited");			
			_i.curUbiAlt_.editRecord();				
			break;
		}
		case "del": {
			
			_i.curUbiAlt_.setModeAccess(_i.curUbiAlt_.Del);
 			_i.curUbiAlt_.refreshBuffer(); 
 			if(!_i.curUbiAlt_.commitBuffer()) {
 				return false;
 			}
 			_i.refrescaTablaUbiAlt();
			break;
		}
		case "browse": {	
			_i.curUbiAlt_.browseRecord();
			break;
		}
	}
}

function euromoda_curUbiAlt_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	this.child("tdbEmUbicaciones").refresh();
	var dtbLC = this.mainWidget().child("tdbEmUbicaciones").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);	
	var pos = cursor.atFromBinarySearch("id", _i.pK_, asc);	
	cursor.seek(pos);
	cursor.refresh()
}

function euromoda_refrescaTablaUbiAlt()
{
	var _i = this.iface;
	var cursor = this.cursor();
	this.child("tdbEmUbicaciones").refresh();
}

function euromoda_tbnUbicacionActual_clicked()
{
	var cursor = this.cursor();
	var curUbi = this.child("tdbEmUbicaciones").cursor();
	var idUbi = curUbi.valueBuffer("id");
	if (!idUbi) {
		return;
	}
	var codUbicacionAct = curUbi.valueBuffer("em_ubialternativa");
	if (!AQSql.update("em_lotesxubicacion", ["actual"], [false], "codlote = '" + cursor.valueBuffer("codlote") + "'")) {
		return false;
	}
	if (!AQSql.update("em_lotesxubicacion", ["actual"], [true], "id= " + idUbi)) {
		return false;
	}
	this.child("tdbEmUbicaciones").refresh();
	sys.setObjText(this, "fdbEmUbiActual", codUbicacionAct);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
