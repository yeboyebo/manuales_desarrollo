
/** @class_declaration euromoda*/
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends modelo340 {
	var politicaCostes_;
  function euromoda( context ) { modelo340 ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function validateForm() {
    return this.ctx.euromoda_validateForm();
  }
  function habilitaPorSerie() {
    return this.ctx.euromoda_habilitaPorSerie();
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function tdbRecibosCli_bufferCommited() {
    return this.ctx.euromoda_tdbRecibosCli_bufferCommited();
  }
  function calcularTotales() {
    return this.ctx.euromoda_calcularTotales();
  }
  function actualizarLineasIva(curFactura) {
    return this.ctx.euromoda_actualizarLineasIva(curFactura);
  }
  function filtraDirEnvio() {
    return this.ctx.euromoda_filtraDirEnvio();
  }
  function setObjFilter(container, component, filter) {
    return this.ctx.euromoda_setObjFilter(container, component, filter);
  }
  function ponNumeroTemp(codigo, numero) {
  	return this.ctx.euromoda_ponNumeroTemp(codigo, numero);
  }
  function buscarFactura(){
  	return this.ctx.euromoda_buscarFactura();
  }
  function ocultarCamposContabilidad() {
	return this.ctx.euromoda_ocultarCamposContabilidad();
  }
  function trataRectificativa() {
  	return this.ctx.euromoda_trataRectificativa();
  }
  function trataAbono() {
  	return this.ctx.euromoda_trataAbono();	
  }
  	function tbnEmRegenerarCostes_clicked() {
		return this.ctx.euromoda_tbnEmRegenerarCostes_clicked();
	}
 	function tbnEmCargarCostes_clicked() {
 		return this.ctx.euromoda_tbnEmCargarCostes_clicked();
 	}
 	function copiarLineasRec(idFacturaOriginal, aLineas, factor) {
 		return this.ctx.euromoda_copiarLineasRec(idFacturaOriginal, aLineas, factor)
 	}
 	function pbnImportarCSV_clicked() {
		return this.ctx.euromoda_pbnImportarCSV_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "codpago": {
			_i.__bufferChanged(fN);
			sys.setObjText(this, "fdbPorDtoEsp", _i.calculateField("pordtoesp_fp"));
			break;
		}
		case "codcliente": {
			if (!flfacturac.iface.pub_controlBloqueoCliente(cursor.valueBuffer("codcliente"), "Facturar")) {
				return false;
			}
			_i.__bufferChanged(fN);
			sys.setObjText(this, "fdbCodDirE", 0);
			sys.setObjText(this, "fdbCodDirE", cursor.valueBuffer("coddir"));
			_i.filtraDirEnvio();
			sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
			formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",cursor.valueBuffer("codcliente"));
			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",cursor.valueBuffer("codcliente"));
			break;
		}
		case "deabono": {
			_i.__bufferChanged(fN);
			sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
			_i.trataAbono();
		}
		case "provinciae": {
			if (!this.iface.bloqueoProvincia) {
				this.iface.bloqueoProvincia = true;
				flfactppal.iface.pub_obtenerProvincia(this, "idprovinciae", "codprovinciae", "codpaise");
				this.iface.bloqueoProvincia = false;
			}
			break;
		}
		case "idprovinciae": {
			if (cursor.valueBuffer("idprovinciae") == 0)
				cursor.setNull("idprovinciae");
			break;
		}
		case "coddire": {
			sys.setObjText(this, "fdbProvinciaE", _i.calculateField("provinciae"));
			sys.setObjText(this, "fdbCodPaisE", _i.calculateField("codpaise"));
			break;
		}
		case "em_deabono": {			
			sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));		
			_i.trataRectificativa();
			break;	
		}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_trataRectificativa()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var deAbono = cursor.valueBuffer("em_deabono");
	if(deAbono) {
		this.child("tbnBuscarFactura").setDisabled(true);
		this.child("fdbDeAbono").setDisabled(true);
		_i.lblDatosFacturaAbono.text = "";
		cursor.setValueBuffer("codigorect", ""); 
		cursor.setNull("idfacturarect"); 
	} else {
		this.child("fdbDeAbono").setDisabled(false);
	}
}

function euromoda_trataAbono()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var rectificativa = cursor.valueBuffer("deabono");
	if(rectificativa) {		
		this.child("fdbEmDeAbono").setDisabled(true);		
	} else {
		this.child("fdbEmDeAbono").setDisabled(false);		

	}
}

function euromoda_filtraDirEnvio()
{
	var _i = this.iface;
	var cursor = this.cursor();
  sys.filterObj(this, "fdbCodDirE", "codcliente = '" + cursor.valueBuffer("codcliente") + "'");
}

function euromoda_validateForm()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	if (!_i.__validateForm()) {
		return false;
	}
	if(!formRecordpresupuestoscli.iface.evaluarCostesCab(cursor)) { 
		return false;
	}
	if (!flfacturac.iface.pub_controlBloqueoCliente(cursor.valueBuffer("codcliente"), "Facturar")) {
		return false;
	}
	//#bloqueo facturas por serie
	var codigo = cursor.valueBuffer("codigo");
	var numeroTemp = cursor.valueBuffer("numero"); 
	
	if(codigo.left(1) == "#") {
		debug("\n\ncalcula el c�digo aqui");
		flfacturac.iface.recalcularHuecos( cursor.valueBuffer("codserie"), cursor.valueBuffer("codejercicio"), "nfacturacli","DIRECTA");
		numero = flfacturac.iface.siguienteNumero(cursor.valueBuffer("codserie"), cursor.valueBuffer("codejercicio"), "nfacturacli");
		if (!numero) {
			_i.ponNumeroTemp(codigo, numeroTemp);
			return false;
		}
		cursor.setValueBuffer("numero", numero);
		cursor.setValueBuffer("codigo", formfacturascli.iface.pub_commonCalculateField("codigo", cursor));	
		if(!flfacturac.iface.comprobarDuplicidadCodigoFacturaCli(cursor)) {
			_i.ponNumeroTemp(codigo, numeroTemp);
			return false;
		}
		if(!flfacturac.iface.validaFechaFacturaCli(cursor)) {
			_i.ponNumeroTemp(codigo, numeroTemp);
			return false;
		}

	}
	//fin #bloqueo facturas por serie


	return true;
}

function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
	var cursor = this.cursor();

	formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",cursor.valueBuffer("codcliente"));
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("facturascli",cursor.valueBuffer("codcliente"));
	connect(this.child("tbnEmRegenerarCostes"), "clicked()", _i, "tbnEmRegenerarCostes_clicked");
 	connect(this.child("tbnEmCargarCostes"), "clicked()", _i, "tbnEmCargarCostes_clicked");

  _i.habilitaPorSerie();
	_i.filtraDirEnvio();
	connect(this.child("tdbRecibosCli").cursor(), "bufferCommited()", _i, "tdbRecibosCli_bufferCommited");

	
	if (cursor.valueBuffer("automatica") == true && cursor.modeAccess() == cursor.Edit) {
		this.child("tdbLineasFacturasCli").setReadOnly(false);
		this.child("tdbLineasFacturasCli").setEditOnly(true);
		this.child("toolButtonEdit").setDisabled(false);
	}
	
	if (cursor.modeAccess() == cursor.Insert) {
		cursor.setValueBuffer("codigo", "#" + cursor.valueBuffer("idfactura").toString());
		cursor.setValueBuffer("numero", "#" + cursor.valueBuffer("idfactura").toString());
	}
	connect(this.child("pbnImportarCSV"), "clicked()", _i, "pbnImportarCSV_clicked");
}

function euromoda_tdbRecibosCli_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();

	cursor.setValueBuffer("em_vencimientos", _i.calculateField("em_vencimientos"));
}

function euromoda_habilitaPorSerie()
{
  var cursor = this.cursor();
  if (cursor.modeAccess() == cursor.Edit) {
    this.child("fdbCodCliente").setDisabled(true);
    this.child("fdbDeAbono").setDisabled(true);
    this.child("fdbEmDeAbono").setDisabled(true);
    
  } else {
    this.child("fdbCodCliente").setDisabled(false);
    this.child("fdbDeAbono").setDisabled(false);
    this.child("fdbEmDeAbono").setDisabled(false);
  }
}

function euromoda_calcularTotales()
{
    var _i = this.iface;   
  _i.__calcularTotales();
  _i.habilitaPorSerie();
}

/** \D
Evita las l�neas con impuesto NO SUJETO que no deben generar partida de IVA
@param curFactura: Cursor posicionado en la factura
\end */
function euromoda_actualizarLineasIva(curFactura)
{
debug("actualizarLineasIva(curFactura)");
	var util = new FLUtil;
	var _i = this.iface;

	var idFactura;
	try {
		idFactura = curFactura.valueBuffer("idfactura");
	} catch (e) {
		// Antes se recib�a s�lo idFactura
		MessageBox.critical(util.translate("scripts", "Hay un problema con la actualizaci�n de su personalizaci�n.\nPor favor, p�ngase en contacto con InfoSiAL para solucionarlo"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}

	var porDto:Number = parseFloat(curFactura.valueBuffer("pordtoesp"));
	if (isNaN(porDto)) {
		porDto = 0;
	}


	var netoExacto:Number = curFactura.valueBuffer("neto");
	var lineasSinIVA:Number = util.sqlSelect("lineasfacturascli", "SUM(pvptotal)", "idfactura = " + idFactura + " AND (iva IS NULL OR (codimpuesto = 'NO SUJETO' AND iva = 0))");
	lineasSinIVA = (isNaN(lineasSinIVA) ? 0 : lineasSinIVA);
	netoExacto -= lineasSinIVA;
	netoExacto = util.roundFieldValue(netoExacto, "facturascli", "neto");

	var ivaExacto:Number = util.sqlSelect("lineasfacturascli", "SUM((pvptotal * iva * (100 - " + porDto + ")) / 100 / 100)", "idfactura = " + idFactura);
	if (!ivaExacto)
		ivaExacto = 0;
	var reExacto:Number = util.sqlSelect("lineasfacturascli", "SUM((pvptotal * recargo * (100 - " + porDto + ")) / 100 / 100)", "idfactura = " + idFactura);
	if (!reExacto)
		reExacto = 0;

	if (!util.sqlDelete("lineasivafactcli", "idfactura = " + idFactura)) {
		return false;
	}

	var codImpuestoAnt:String = "";
	var codImpuesto:String = "";
	var iva:Number;
	var recargo:Number;
	var totalNeto:Number = 0;
	var totalIva:Number = 0;
	var totalRecargo:Number = 0;
	var totalLinea:Number = 0;
	var acumNeto:Number = 0;
	var acumIva:Number = 0;
	var acumRecargo:Number = 0;

	var curLineaIva:FLSqlCursor = new FLSqlCursor("lineasivafactcli");
	var qryLineasFactura:FLSqlQuery = new FLSqlQuery;
	with (qryLineasFactura) {
		setTablesList("lineasfacturascli");
		setSelect("codimpuesto, iva, recargo, pvptotal");
		setFrom("lineasfacturascli");
		setWhere("idfactura = " + idFactura + " AND pvptotal <> 0 AND iva IS NOT NULL AND codimpuesto <> 'NO SUJETO' ORDER BY codimpuesto");
		setForwardOnly(true);
	}

	if (!qryLineasFactura.exec()) {
		return false;
	}
	var regIva = flfacturac.iface.pub_regimenIVACliente(curFactura);

	while (qryLineasFactura.next()) {
		codImpuesto = qryLineasFactura.value("codimpuesto");
		if (codImpuestoAnt != "" && codImpuestoAnt != codImpuesto) {
			totalNeto = (totalNeto * (100 - porDto)) / 100;
			totalNeto = util.roundFieldValue(totalNeto, "lineasivafactcli", "neto");
			totalIva = util.roundFieldValue((iva * totalNeto) / 100, "lineasivafactcli", "totaliva");
			totalRecargo = util.roundFieldValue((recargo * totalNeto) / 100, "lineasivafactcli", "totalrecargo");
			totalLinea = parseFloat(totalNeto) + parseFloat(totalIva) + parseFloat(totalRecargo);
			totalLinea = util.roundFieldValue(totalLinea, "lineasivafactcli", "totallinea");

			acumNeto += parseFloat(totalNeto);
			acumIva += parseFloat(totalIva);
			acumRecargo += parseFloat(totalRecargo);

			with(curLineaIva) {
				setModeAccess(Insert);
				refreshBuffer();
				setValueBuffer("idfactura", idFactura);
				setValueBuffer("codimpuesto", codImpuestoAnt);
				setValueBuffer("iva", iva);
				setValueBuffer("recargo", recargo);
				setValueBuffer("neto", totalNeto);
				setValueBuffer("totaliva", totalIva);
				setValueBuffer("totalrecargo", totalRecargo);
				setValueBuffer("totallinea", totalLinea);
			}
			if (!curLineaIva.commitBuffer())
					return false;
			totalNeto = 0;
		}

		codImpuestoAnt = codImpuesto;
		if (regIva == "U.E." || regIva == "Exento" || regIva == "Exportaciones") {
			ivaExacto = 0;
			reExacto = 0;
			iva = 0;
			recargo = 0;
		} else {
			iva = parseFloat(qryLineasFactura.value("iva"));
			recargo = parseFloat(qryLineasFactura.value("recargo"));
			if (isNaN(recargo)) {
				recargo = 0;
			}
		}
		totalNeto += parseFloat(qryLineasFactura.value("pvptotal"));
	}

	if (totalNeto != 0) {
		totalNeto = util.roundFieldValue(netoExacto - acumNeto, "lineasivafactcli", "neto");
		totalIva = util.roundFieldValue(ivaExacto - acumIva, "lineasivafactcli", "totaliva");
		totalRecargo = util.roundFieldValue(reExacto - acumRecargo, "lineasivafactcli", "totalrecargo");
		totalLinea = parseFloat(totalNeto) + parseFloat(totalIva) + parseFloat(totalRecargo);
		totalLinea = util.roundFieldValue(totalLinea, "lineasivafactcli", "totallinea");

		with(curLineaIva) {
			setModeAccess(Insert);
			refreshBuffer();
			setValueBuffer("idfactura", idFactura);
			setValueBuffer("codimpuesto", codImpuestoAnt);
			setValueBuffer("iva", iva);
			setValueBuffer("recargo", recargo);
			setValueBuffer("neto", totalNeto);
			setValueBuffer("totaliva", totalIva);
			setValueBuffer("totalrecargo", totalRecargo);
			setValueBuffer("totallinea", totalLinea);
		}
		if (!curLineaIva.commitBuffer())
			return false;
	}
	return true;
}

function euromoda_ponNumeroTemp(codigo, numero)
{
	//#bloqueo facturas por serie
	var cursor = this.cursor();
	cursor.setValueBuffer("numero", numero);
	cursor.setValueBuffer("codigo", codigo);	

	
}

function euromoda_buscarFactura()
{
	var ruta = new FLFormSearchDB("busfactcli");
	var curFacturas = ruta.cursor();
	var cursor = this.cursor();
	var _i = this.iface;
	
	var codCliente = cursor.valueBuffer("codcliente");
	var masFiltro = "";
	if (codCliente)
		masFiltro += " AND codcliente = '" + codCliente + "'";
	
	if (cursor.modeAccess() == cursor.Insert)
		curFacturas.setMainFilter("deabono = false" + masFiltro);
	else
		curFacturas.setMainFilter("deabono = false and idfactura <> " + this.cursor().valueBuffer("idfactura") + masFiltro);

	ruta.setMainWidget();
	var idFactura = ruta.exec("idfactura");

	var codDropshipping = curFacturas.valueBuffer("em_coddropshipping");

	if (!idFactura) {
		return;
	}

	if(codDropshipping && codDropshipping != ""){
		cursor.setValueBuffer("em_coddropshipping", codDropshipping);
	}
	cursor.setValueBuffer("idfacturarect", idFactura);
	var codigo = AQUtil.sqlSelect("facturascli", "codigo", "idfactura = '" + idFactura + "'");
	cursor.setValueBuffer("codigorect", codigo);
	_i.mostrarDatosFactura(idFactura);
	_i.mostrarOpcionesFacturaRec(idFactura);
}

function euromoda_ocultarCamposContabilidad()
{
	return true;
}

function euromoda_tbnEmRegenerarCostes_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	//Permite regenerar los costes y m�rgenes de as l�neas. Esto supone borrar los actuales y volver a cargar sin dar avisos.
	var curLineas =  this.child("tdbLineasFacturasCli").cursor();
	formRecordpresupuestoscli.iface.pub_actualizaCostes(cursor,curLineas,true);
    this.child("tdbLineasFacturasCli").refresh();
}

function euromoda_tbnEmCargarCostes_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	//Permite regenerar los costes y m�rgenes de as l�neas. Esto supone borrar los actuales y volver a cargar sin dar avisos.
	var curLineas =  this.child("tdbLineasFacturasCli").cursor();
	formRecordpresupuestoscli.iface.pub_actualizaCostes(cursor,curLineas,false);
    this.child("tdbLineasFacturasCli").refresh();

}

function euromoda_copiarLineasRec(idFacturaOriginal, aLineas, factor)
{
	var _i = this.iface;
	if(!_i.__copiarLineasRec(idFacturaOriginal, aLineas, factor)) {
		return false;
	}
	_i.tbnEmCargarCostes_clicked();
	return true;
}

function euromoda_pbnImportarCSV_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbLineasFacturasCli").cursor().commitBufferCursorRelation())
			return false;
	}	
	if(!formRecordpedidoscli.iface.importarDatosCSV(cursor)){
		return false;
	}
	_i.calcularTotales();
	this.child("tdbLineasFacturasCli").refresh();	
	return true;

}




//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
