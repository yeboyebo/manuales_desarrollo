/**************************************************************************
                 em_devolucionpiezas.qs  -  description
                             -------------------
    begin                : mar nov 1 2015
    copyright            : (C) 2015 by YeboYebo S.L.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {	
	var todos_;
	var tblLineas_;
	var idAlbaran_;
	var cSEL_, cREF_, cPZA_, cDES_, cCAN_, cALM_,cPVP_;
	var colorNoSel_,colorSel_;
	var codAlmacenAlb_;
    function oficial( context ) { interna( context ); }
	function tbnTodos_clicked() {
		return this.ctx.oficial_tbnTodos_clicked();
	}
	function tbnNinguno_clicked() {
		return this.ctx.oficial_tbnNinguno_clicked();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function actualizarOrden() {
		return this.ctx.oficial_actualizarOrden();
	}
	function creaLineas() {
		return this.ctx.oficial_creaLineas();
	}
	function tbnBuscarAlbaran_clicked() {
		return this.ctx.oficial_tbnBuscarAlbaran_clicked();
	}
	function iniciaTabla() {
		return this.ctx.oficial_iniciaTabla();
	}
	function tblLineas_clicked(f, c) {
		return this.ctx.oficial_tblLineas_clicked(f, c);
	}
	function colSelClicked(f) {
		return this.ctx.oficial_colSelClicked(f);
	}
	function colores() {
		return this.ctx.oficial_colores();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
	var _i = this.iface;
	_i.colores();
	_i.tblLineas_ = this.child("tblLineas");
	connect(_i.tblLineas_, "doubleClicked(int, int)", _i, "tblLineas_clicked");
	connect(this.child("tbnTodos"), "clicked()", _i, "tbnTodos_clicked");
	connect(this.child("tbnNinguno"), "clicked()", _i, "tbnNinguno_clicked");	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	connect(this.child("tbnBuscarAlbaran"), "clicked()", _i, "tbnBuscarAlbaran_clicked");
	_i.idAlbaran_ = formRecordalbaranescli.iface.idAlbaranDev_;		
	//_i.codAlmacenAlb_ = AQUtil.sqlSelect("albaranescli","codalmacen","idalbaran = "+ _i.idAlbaran_);
	//var codCliente = AQUtil.sqlSelect("albaranescli","codcliente","idalbaran=" + _i.idAlbaran_);
	var oDatosAlbCli = flfactppal.iface.pub_ejecutarQry("albaranescli","codalmacen,codcliente","idalbaran = "+ _i.idAlbaran_,"albaranescli");
	if(oDatosAlbCli == -1) {
		return false;
	}
	var codCliente = oDatosAlbCli.codcliente;
	var codAlmacenAlb = oDatosAlbCli.codalmacen;
	this.child("lneCodCliente").text = codCliente;
	this.child("lneNombreCliente").text = AQUtil.sqlSelect("clientes","nombre","codcliente='" + codCliente + "'");
	this.child("lneCodAlmacen").text = codAlmacenAlb;
	
	_i.todos_ = false;
	
	//_i.tdbLineas_.setReadOnly(true);	
	_i.iniciaTabla();	

	
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciaTabla()
{
	var _i = this.iface;
	
	var cursor = this.cursor();
	
	var c = 0, cH = [];
  
  _i.cSEL_ = c++;
  _i.cREF_ = c++;
  _i.cPZA_ = c++;  
  _i.cDES_ = c++;
  _i.cCAN_ = c++;	
  _i.cALM_ = c++;
  //_i.cPVP_ = c++;
	
	cH[_i.cSEL_] = AQUtil.translate("scripts", "Sel.");
	cH[_i.cREF_] = AQUtil.translate("scripts", "Referencia");
	cH[_i.cPZA_] = AQUtil.translate("scripts", "Pieza");
	cH[_i.cDES_] = AQUtil.translate("scripts", "Descripci�n");
	cH[_i.cCAN_] = AQUtil.translate("scripts", "Cantidad");
	cH[_i.cALM_] = AQUtil.translate("scripts", "Almac�n");
	//cH[_i.cPVP_] = AQUtil.translate("scripts", "PVP");
	
  	_i.tblLineas_.setNumCols(c);  

	_i.tblLineas_.setColumnWidth(_i.cSEL_, 40);
	_i.tblLineas_.setColumnWidth(_i.cREF_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cPZA_, 100);
  	_i.tblLineas_.setColumnWidth(_i.cDES_, 500);
  	_i.tblLineas_.setColumnWidth(_i.cCAN_, 120);

  	
  	_i.tblLineas_.setColumnReadOnly(_i.cREF_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cPZA_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cDES_, true);
  	_i.tblLineas_.setColumnReadOnly(_i.cCAN_, true);  
  	_i.tblLineas_.setColumnReadOnly(_i.cALM_, true);
  	//_i.tblLineas_.setColumnReadOnly(_i.cPVP_, true);		
 	_i.tblLineas_.setColumnLabels("*", cH.join("*"));
}

function oficial_tbnBuscarAlbaran_clicked()
{
	var _i = this.iface;	
	var codCliente = this.child("lneCodCliente").text;
	var filtro = "codcliente = '" + codCliente + "' and idalbaran != "+ _i.idAlbaran_;
	var f = new FLFormSearchDB("busalbcli");	
	f.setMainWidget();
	f.cursor().setMainFilter(filtro);
	var codAlbaran = f.exec("codigo");
	debug("codAlbaran: "+codAlbaran);
	if (codAlbaran) {
		_i.tblLineas_.setNumRows(0);
		this.child("lneAlbaran").text = codAlbaran;
		var idAlbaran = AQUtil.sqlSelect("albaranescli","idalbaran","codigo = '" + codAlbaran + "'");
		
		var r = 0;
		var q = new AQSqlQuery;
		var metrosAcu = 0;
		q.setSelect("lotesstock.referencia,lotesstock.codlote,lotesstock.articulo,movistock.cantidad,lotesstock.codalmacen,lineasalbaranescli.numlinea");
		q.setFrom("lotesstock inner join movistock on lotesstock.codlote=movistock.codlote inner join lineasalbaranescli on lineasalbaranescli.idlinea = movistock.idlineaac");		
		q.setWhere("lineasalbaranescli.idalbaran = " + idAlbaran + " and lotesstock.candisponible =0 order by lineasalbaranescli.numlinea" );			
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			_i.tblLineas_.insertRows(r);
			var cantidad = parseFloat(q.value("movistock.cantidad"));						
			cantidad = AQUtil.roundFieldValue(cantidad, "movistock", "cantidad");      	
      	debug("referencia: "+q.value("lotesstock.referencia"));
      	debug("numlinea: "+q.value("lineasalbaranescli.numlinea"));
      	_i.tblLineas_.setText(r,  _i.cREF_, q.value("lotesstock.referencia"));
     		_i.tblLineas_.setText(r, _i.cPZA_, q.value("lotesstock.codlote"));
      	_i.tblLineas_.setText(r, _i.cDES_, q.value("lotesstock.articulo"));
      	_i.tblLineas_.setText(r, _i.cCAN_, cantidad);
			_i.tblLineas_.setText(r, _i.cALM_, q.value("lotesstock.codalmacen"));
			//_i.tblLineas_.setText(r, _i.cPVP_, q.value("lineasalbaranescli.pvpunitario"));
			r++;
		}		

	}
}

function oficial_colores()
{
  var _i = this.iface;

  _i.colorNoSel_ = new Color("grey");
  _i.colorSel_ = new Color("green");
 
}

function oficial_tblLineas_clicked(f, c)
{
	var _i = this.iface;
  	switch (c) {
  		case _i.cSEL_: {
  			_i.colSelClicked(f);
      		break;
 		}
	}
}

function oficial_colSelClicked(f)
{
  var _i = this.iface;
  
  if (_i.tblLineas_.text(f, _i.cSEL_) == "") {
    _i.tblLineas_.setText(f, _i.cSEL_, "X");
    _i.tblLineas_.setCellBackgroundColor(f, _i.cSEL_, _i.colorSel_);  
  } else {
    _i.tblLineas_.setText(f, _i.cSEL_, "");
    _i.tblLineas_.setCellBackgroundColor(f, _i.cSEL_, _i.colorNoSel_); 
  } 
  return true;
}

function oficial_tbnTodos_clicked()
{
	var _i = this.iface;  
  	var nF = _i.tblLineas_.numRows();  	
  	for (var f = 0; f < nF; f++) {    
    	if (_i.tblLineas_.text(f, 0) == "") {
      		if (!_i.colSelClicked(f)) {        		
        		return false;
      		}
    	}
  	}  
}


function oficial_tbnNinguno_clicked()
{
	var _i = this.iface;		
  	var nF = _i.tblLineas_.numRows();  	
  	for (var f = 0; f < nF; f++) {    
    	if (_i.tblLineas_.text(f, 0) == "X") {
      		if (!_i.colSelClicked(f)) {        		
        		return false;
      		}
    	}
  	}  
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	
	var sel = false;
	var nF = _i.tblLineas_.numRows();
	for (var f = 0; f < nF && !sel; f++) {    
    	if (_i.tblLineas_.text(f, 0) == "X") {
      		sel = true;
    	}
  	} 
  	if(!sel) {
  		sys.warnMsgBox(sys.translate("No ha seleccionado ning�n registro."));
  		return false;
  	}	
	if(!_i.creaLineas()) {
		return false;
	}	
	this.obj().accept();
}

/*function oficial_creaLineas()
{
	var _i = this.iface;	
	var aRef = [];
	//cargamos en aRef las referencias que ya est�n en las l�neas.
	var q = new AQSqlQuery;	
	q.setSelect("distinct(referencia)");
	q.setFrom("lineasalbaranescli");
	q.setWhere("idalbaran = " + _i.idAlbaran_); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		aRef.push(q.value("distinct(referencia)"));		
	}	
	var nF = _i.tblLineas_.numRows();
	for (var f = 0; f < nF; f++) {    
    	if (_i.tblLineas_.text(f, _i.cSEL_) == "X") {      		
      	var referencia = _i.tblLineas_.text(f, _i.cREF_);
      	if(aRef.join(",").find(referencia) ==-1) {
      		aRef.push(referencia);
      		var idLineaAlb = formem_asignacionpiezasoe.iface.creaLineaAlbaran(_i.idAlbaran_, referencia);
      		if(!idLineaAlb) {
					return false;      		
      		}    	
      	} 
      	var cantidad = _i.tblLineas_.text(f, _i.cCAN_);
      	var codPieza = _i.tblLineas_.text(f, _i.cPZA_);
      	var idLineaAlb = AQUtil.sqlSelect("lineasalbaranescli","idlinea","idalbaran = "+_i.idAlbaran_ +" and referencia = '" + referencia + "'");
      	var oParam = new Object;
      	oParam.idLineaAlb = idLineaAlb;
      	oParam.codLote = codPieza;
      	oParam.cantidad = (-1)*cantidad;
      	oParam.codAlmacenAlb = this.child("lneCodAlmacen").text;
      	oParam.tipoAlb = "DEVOL";
      	if(!formem_asignacionpiezasoe.iface.creaMovLote(oParam)) {
      		return false;
      	} 	
      	if(!formem_asignacionpiezasoe.iface.totalizaLineaAlbaran(idLineaAlb)) {
      		return false;
      	} 		
    	}
  	} 
	return true;
}*/

function oficial_creaLineas()
{
	var _i = this.iface;	
	var aRef = [];
	var p = 0;
	//cargamos en aRef las referencias que ya est�n en las l�neas.
	var q = new AQSqlQuery;	
	q.setSelect("m.referencia, s.codalmacen");
	q.setFrom("movistock m inner join lineasalbaranescli l on m.idlineaac=l.idlinea inner join stocks s on m.idstock=s.idstock");
	q.setWhere("l.idalbaran = " + _i.idAlbaran_ + " group by m.referencia, s.codalmacen"); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		aRef[p] = new Array(2);
		aRef[p][0] = q.value("m.referencia");
		aRef[p][1] = q.value("s.codalmacen");
		p++;
	}	
	var nF = _i.tblLineas_.numRows();
	for (var f = 0; f < nF; f++) {    
    	if (_i.tblLineas_.text(f, _i.cSEL_) == "X") {           	
      		var referencia = _i.tblLineas_.text(f, _i.cREF_);
			var codAlmacen = _i.tblLineas_.text(f, _i.cALM_);
			//var pvp = _i.tblLineas_.text(f, _i.cPVP_);
			var refAlmacen = referencia+","+codAlmacen;
			debug("aRef.join: "+aRef.join(","));
			debug("encontrar: "+aRef.join(",").find(refAlmacen));
			var idLineaAlbN;
			if(aRef.join(",").find(refAlmacen) ==-1) {
				aRef[p] = new Array(2);
				aRef[p][0] = referencia;
				aRef[p][1] = codAlmacen;
				p++;
				idLineaAlbN = formem_asignacionpiezasoe.iface.creaLineaAlbaran(_i.idAlbaran_, referencia);
				if(!idLineaAlbN) {
					return false;      		
				}     	
			}       	
			
      		var cantidad = _i.tblLineas_.text(f, _i.cCAN_);
      		var codPieza = _i.tblLineas_.text(f, _i.cPZA_);
      		var idLineaAlb = AQUtil.sqlSelect("movistock m inner join lineasalbaranescli l on m.idlineaac=l.idlinea inner join stocks s on m.idstock=s.idstock inner join lotesstock lot on lot.codlote=m.codlote","l.idlinea","l.idalbaran = "+_i.idAlbaran_ +" and m.referencia = '" + referencia + "' and lot.em_codalmacenori ='" + codAlmacen + "'","movistock");
      		debug("idLineaAlb: "+idLineaAlb);
			if(!idLineaAlb) { // es porque tiene que ir a la l�nea que acabamos de crear.
				idLineaAlb = idLineaAlbN;
			}
      		var oParam = new Object;
      		oParam.idLineaAlb = idLineaAlb;
      		oParam.codLote = codPieza;
      		oParam.cantidad = (-1)*cantidad;
      		oParam.codAlmacenAlb = this.child("lneCodAlmacen").text;
      		oParam.tipoAlb = "DEVOL";
      		if(!formem_asignacionpiezasoe.iface.creaMovLote(oParam)) {
      			return false;
      		} 	
      		if(!formem_asignacionpiezasoe.iface.totalizaLineaAlbaran(idLineaAlb, true)) {
      			return false;
      		} 
      				
    	}
  	} 
	return true;
}
///// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
