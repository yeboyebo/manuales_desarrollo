/***************************************************************************
                 em_rutastpsubfam.qs  -  description
                             -------------------
    begin                : mie oct 24 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function validateForm() {return this.ctx.interna_validateForm();}
  function calculateField(fN) {
    return this.ctx.interna_calculateField(fN);
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  function oficial( context ) { interna( context ); } 
  function commonCalculateField(fN, cursor) {
    return this.ctx.oficial_commonCalculateField(fN, cursor);
  }
  function bufferChanged(fN) {
    return this.ctx.oficial_bufferChanged(fN);
  }
	function initNumLinea() {
		return this.ctx.oficial_initNumLinea();
  }
  function validaNumLinea() {
		return this.ctx.oficial_validaNumLinea();
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	
	_i.initNumLinea()
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;
	if (!_i.validaNumLinea()) {
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "numlinea": {
			var codSubfamilia = cursor.valueBuffer("codsubfamilia");
			valor = parseInt(AQUtil.sqlSelect("em_rutastpsubfam", "numlinea", "codsubfamilia = '" + codSubfamilia + "' ORDER BY numlinea DESC"));
			if (isNaN(valor)) {
				valor = 0;
			}
			valor++;
			break;
		}
		default: {
		}
	}
			
	return valor;
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		default: {
		}
	}
}

function oficial_initNumLinea()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			this.child("fdbNumLinea").setValue(_i.calculateField("numlinea"));
			break;
		}
	}
	return true
}

function oficial_validaNumLinea()
{
	var cursor = this.cursor();
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var numLinea = cursor.valueBuffer("numlinea");
	if (isNaN(numLinea)) {
		return false;
	}
	if (AQUtil.sqlSelect("em_rutastpsubfam", "idrutatp", "codsubfamilia = '" + codSubfamilia + "' AND numlinea = " + numLinea + " AND idrutatp <> " + cursor.valueBuffer("idrutatp"))) {
		sys.warnMsgBox(sys.translate("Ya hay una entrada de ruta con n�mero de l�nea %1 para la subfamilia %2").arg(numLinea).arg(codSubfamilia));
		return false;
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////



/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////