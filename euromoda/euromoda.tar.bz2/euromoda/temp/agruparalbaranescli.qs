
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends ivaNav {	
	var COL_DOCEXTERNO;
	var COL_DROPSHIPPING;
	var COL_FECHAVALOR;
	function euromoda( context ) { ivaNav ( context ); }
	function init(){
		return this.ctx.euromoda_init();
	}
	function bufferChanged(fN){
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function habilitaPorDropshipping(){
		return this.ctx.euromoda_habilitaPorDropshipping();
	}
	function actualizar(){
		return this.ctx.euromoda_actualizar();
	}
	function informaPorDropshipping() {
		return this.ctx.euromoda_informaPorDropshipping();
	}
	function ocultarCamposContabilidad() {
	   return this.ctx.euromoda_ocultarCamposContabilidad();
 	}	
 	function insertarLineaTabla(curAlbaranes) {
 		return this.ctx.euromoda_insertarLineaTabla(curAlbaranes);
 	}

	function generarTabla() {
		return this.ctx.euromoda_generarTabla();
	}
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////

function euromoda_init(){
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	var hoy = new Date();
	var ahora = hoy.toString().right(8);
	this.child("fdbHora").setValue(ahora);

	cursor.setValueBuffer("em_optfechavalor","Agrupar por fecha valor");
	_i.habilitaPorDropshipping();
}

function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	switch (fN) {
		case "emcoddropshipping": {			
			_i.habilitaPorDropshipping();	
			_i.informaPorDropshipping();		
			break;
		}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_habilitaPorDropshipping()
{
	if(this.child("fdbCodDrop").value() != "" && this.child("fdbCodDrop").value()){
		//poner a vac�o
		this.child("fLFieldDB17_3").setValue("");
		this.child("fLFieldDB8").setValue("");
		this.child("fLFieldDB9").setValue("");
		//this.child("coddir").setValue("");
		//this.child("fLFieldDB1_3_3_2").setValue("");
		//this.child("fLFieldDB8_2").setValue("");
		//this.child("fLFieldDB1_3_3").setValue("");
		//this.child("fLFieldDB16").setValue("");
		//this.child("FLFieldDB1_2_2_2").setValue("");
		//deshabilitar
		this.child("fLFieldDB17_3").setDisabled(true);
		this.child("fLFieldDB8").setDisabled(true);
		this.child("fLFieldDB9").setDisabled(true);
		//this.child("coddir").setDisabled(true);
		//this.child("fLFieldDB1_3_3_2").setDisabled(true);
		//this.child("fLFieldDB8_2").setDisabled(true);
		//this.child("fLFieldDB1_3_3").setDisabled(true);
		//this.child("fLFieldDB16").setDisabled(true);
		//this.child("FLFieldDB1_2_2_2").setDisabled(true);
	}else{
		this.child("fLFieldDB17_3").setDisabled(false);
		this.child("fLFieldDB8").setDisabled(false);
		this.child("fLFieldDB9").setDisabled(false);
		this.child("coddir").setDisabled(false);
		this.child("fLFieldDB1_3_3_2").setDisabled(false);
		this.child("fLFieldDB8_2").setDisabled(false);
		this.child("fLFieldDB1_3_3").setDisabled(false);
		this.child("fLFieldDB16").setDisabled(false);
		this.child("FLFieldDB1_2_2_2").setDisabled(false);
	}
	}

function euromoda_actualizar()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codDropshipping = cursor.valueBuffer("emcoddropshipping");

	if(!codDropshipping || codDropshipping == ""){
		return _i.__actualizar();
	}

	var curAlbaranes = new FLSqlCursor("albaranescli");

	var fechaDesde = cursor.valueBuffer("fechadesde");
  	var fechaHasta = cursor.valueBuffer("fechahasta");
	
	var fila;
	var numFilas = _i.tblAlbaranes.numRows();

	for (fila = 0; fila < numFilas; fila++)
		_i.tblAlbaranes.removeRow(0);

	//var where = "albaranescli.ptefactura = 'true' AND albaranescli.em_coddropshipping = '" + codDropshipping + "'";

	var aCodDrop = codDropshipping.split(",");

	var where = "albaranescli.ptefactura = 'true' AND albaranescli.em_coddropshipping IN ('" + aCodDrop.join("', '") + "')";
	where += " AND albaranescli.fecha >= '" + fechaDesde + "' AND albaranescli.fecha <= '" + fechaHasta + "'";
	where += " ORDER BY codcliente,codalmacen DESC";
	debug("where: "+where);
	if (!curAlbaranes.select(where))
		return;

	while (curAlbaranes.next()) {
		curAlbaranes.setModeAccess(curAlbaranes.Browse);
		curAlbaranes.refreshBuffer();
		_i.insertarLineaTabla(curAlbaranes);
	}
	
	_i.estado = "Seleccionando";
	_i.gestionEstado();

	if (this.iface.tblAlbaranes.numRows() == 0)
		this.child("pushButtonAccept").enabled = false;
}

function euromoda_informaPorDropshipping()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codDropshipping = cursor.valueBuffer("emcoddropshipping");
	if(!codDropshipping || codDropshipping == ""){
		return ;
	}

	var codCliente = AQUtil.sqlSelect("em_dropshipping", "codcliente", "codigo = '" + codDropshipping + "'");
	this.child("fLFieldDB17_3").setValue(codCliente);

}

function euromoda_ocultarCamposContabilidad()
{
	return true;
}


function euromoda_generarTabla()
{
	var _i = this.iface;
	_i.__generarTabla();


	_i.COL_DOCEXTERNO = 7;
	_i.COL_DROPSHIPPING = 8;
	_i.COL_FECHAVALOR = 9;
	_i.tblAlbaranes.setNumCols(10);
	this.iface.tblAlbaranes.setColumnLabels("/", "Incluir/C�digo/Fecha/Total/Cliente/Nombre/idalbaran/Doc.Externo/Dropshipping/Fecha valor");
	
}

function euromoda_insertarLineaTabla(curAlbaranes)
{
	var _i = this.iface;
	var numLinea = _i.tblAlbaranes.numRows();
	_i.__insertarLineaTabla(curAlbaranes);

	_i.tblAlbaranes.setText(numLinea, _i.COL_DOCEXTERNO, curAlbaranes.valueBuffer("docexterno"));
	_i.tblAlbaranes.setText(numLinea, _i.COL_DROPSHIPPING, curAlbaranes.valueBuffer("em_coddropshipping"));

	var fechaValor = curAlbaranes.valueBuffer("fechavalor");
	if(fechaValor && fechaValor != "") {
		fechaValor = AQUtil.dateAMDtoDMA(fechaValor);
	}

	_i.tblAlbaranes.setText(numLinea, _i.COL_FECHAVALOR, fechaValor);
}
//// EUROMODA /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

