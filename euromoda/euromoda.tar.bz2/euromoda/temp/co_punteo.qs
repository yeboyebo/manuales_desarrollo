
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var sI_;
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function iniciaSaldo() {
		return this.ctx.euromoda_iniciaSaldo();
	}
	function saldoInicial() {
		return this.ctx.euromoda_saldoInicial();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	//_i.iniciaSaldo()
	_i.__init();
	
	/// Comentar esto al pasar punteo_cont a la versi�n 2.5
	_i.iniciaSaldo();
	if (this.child("tdbPartidasPunteo")) {
		this.child("tdbPartidasPunteo").refresh();
	}
	//*/
}

function euromoda_saldoInicial()
{
	var _i = this.iface;
	return _i.sI_;
}

function euromoda_iniciaSaldo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var sI = formRecordco_subcuentas.iface.pub_calculaSaldoInicial(cursor.valueBuffer("codsubcuenta"), cursor.valueBuffer("codejercicio"));
	sys.setObjText(this, "lblSaldoInicial", sys.translate("Saldo inicial: %1").arg(AQUtil.formatoMiles(AQUtil.roundFieldValue(sI, "co_partidas", "debe"))));
	_i.sI_ = sI;
	debug("Saldo = " + _i.sI_);
}
