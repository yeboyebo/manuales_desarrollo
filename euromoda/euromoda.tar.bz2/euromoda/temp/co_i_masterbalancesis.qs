
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var datosSaldoCli_, datosSaldoProv_;
	function euromoda( context ) { oficial ( context ); }
  function init() {
		return this.ctx.euromoda_init();
	}
	function obtenerParamInformeCliProv() {
		return this.ctx.euromoda_obtenerParamInformeCliProv();
	}
	function lanzar() {
		return this.ctx.euromoda_lanzar();
	}
// 	function saldoInicialCli(nodo, campo) {
// 		return this.ctx.euromoda_saldoInicialCli(nodo, campo);
// 	}
// 	function saldoInicialProv(nodo, campo) {
// 		return this.ctx.euromoda_saldoInicialProv(nodo, campo);
// 	}
// 	function saldoFinalCli(nodo, campo) {
// 		return this.ctx.euromoda_saldoFinalCli(nodo, campo);
// 	}
// 	function saldoFinalProv(nodo, campo) {
// 		return this.ctx.euromoda_saldoFinalProv(nodo, campo);
// 	}
// 	function cargaSaldoCliente(codCliente) {
// 		return this.ctx.euromoda_cargaSaldoCliente(codCliente);
// 	}
// 	function cargaSaldoProveedor(codProveedor) {
// 		return this.ctx.euromoda_cargaSaldoProveedor(codProveedor);
// 	}
	function dameWhereFechaSaldoInicial(cursor) {
		return this.ctx.euromoda_dameWhereFechaSaldoInicial(cursor);
	}
// 	function saldoInicialCli(codCliente) {
// 		return this.ctx.euromoda_saldoInicialCli(codCliente);
// 	}
	function cargaTablaTemp() {
		return this.ctx.euromoda_cargaTablaTemp();
	}
	function dameWhereCli() {
		return this.ctx.euromoda_dameWhereCli();
	}
	function dameWhereProv() {
		return this.ctx.euromoda_dameWhereProv();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	var cursor = this.cursor();
}

function euromoda_lanzar()
{
	var _i = this.iface;
	var cursor = this.cursor()
	
	if (!(cursor.valueBuffer("clientes") || cursor.valueBuffer("proveedores"))) {
		return _i.__lanzar();
	}
	flcontinfo.iface.pub_establecerInformeActual(cursor.valueBuffer("id"), "co_i_balancesis");
	
	if (!_i.cargaTablaTemp()) {
		return false;
	}
// 	return;
// 	
// 	var pI = this.iface.obtenerParamInformeCliProv();
// 	if (!pI) {
// 		return;
// 	}
// 	flfactinfo.iface.pub_lanzaInforme(cursor, pI);
}

/*function euromoda_cargaTablaTemp()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var cli = cursor.valueBuffer("clientes");
	
	if (!AQUtil.execSql("DELETE FROM co_i_balancesis_buffer_cliprov WHERE idusuario = '" + sys.nameUser() + "'")) {
		return false;
	}
	var saldoF;
	/// Saldo inicial
	var wC = cli ? _i.dameWhereCli() : _i.dameWhereProv();
	var fechaDesde = cursor.valueBuffer("d_co__asientos_fecha");
	wC += wC != "" ? " AND " : "";
	wC += ("co_asientos.fecha < '" + fechaDesde + "'");
	var qC = new FLSqlQuery;
	if (cli) {
		qC.setSelect("clientes.codcliente, clientes.nombre, clientes.codgrupocontablecli, SUM(co_partidas.debe-co_partidas.haber)");
		qC.setFrom("clientes INNER JOIN gruposcontablescli ON clientes.codgrupocontablecli = gruposcontablescli.codgrupo INNER JOIN co_subcuentas ON (gruposcontablescli.codsubcuentacli = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefectos = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefdesc = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefcobro = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefimp = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafaccobro = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafacdesc = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafacimp = co_subcuentas.codsubcuenta) INNER JOIN co_partidas ON (co_subcuentas.idsubcuenta = co_partidas.idsubcuenta AND co_partidas.codcliente = clientes.codcliente) INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
		qC.setWhere(wC + " GROUP BY clientes.codcliente, clientes.nombre, clientes.codgrupocontablecli");
	} else {
		qC.setSelect("proveedores.codproveedor, proveedores.nombre, proveedores.codgrupocontableprov, SUM(co_partidas.debe-co_partidas.haber)");
		qC.setFrom("proveedores INNER JOIN gruposcontablesprov ON proveedores.codgrupocontableprov = gruposcontablesprov.codgrupo 		INNER JOIN co_subcuentas ON (gruposcontablesprov.codsubcuentaprov = co_subcuentas.codsubcuenta OR gruposcontablesprov.codsubcuentaefectos = co_subcuentas.codsubcuenta OR gruposcontablesprov.codsubcuentaefpago = co_subcuentas.codsubcuenta OR gruposcontablesprov.codsubcuentafacpago = co_subcuentas.codsubcuenta) INNER JOIN co_partidas ON (co_subcuentas.idsubcuenta = co_partidas.idsubcuenta AND co_partidas.codproveedor = proveedores.codproveedor) INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
		qC.setWhere(wC + " GROUP BY proveedores.codproveedor, proveedores.nombre, proveedores.codgrupocontableprov");
	}
	if (!qC.exec()) {
		return false;
	}
debug(qC.sql());
	var saldo, p = 0;
	var curT = new FLSqlCursor("co_i_balancesis_buffer_cliprov");
	flfactppal.iface.creaDialogoProgreso(sys.translate("Cargando saldos iniciales..."), qC.size());
	while (qC.next()) {
		AQUtil.setProgress(++p);
		saldo = parseFloat(qC.value("SUM(co_partidas.debe-co_partidas.haber)"));
		if (Math.abs(saldo) < 0.001) {
			continue;
		}
		curT.setModeAccess(curT.Insert);
		curT.refreshBuffer();
		curT.setValueBuffer("idusuario", sys.nameUser());
		curT.setValueBuffer("codtercero", cli ? qC.value("clientes.codcliente") : qC.value("proveedores.codproveedor"));
		curT.setValueBuffer("nombre", cli ? qC.value("clientes.nombre") : qC.value("proveedores.nombre"));
		curT.setValueBuffer("debe", 0);
		curT.setValueBuffer("haber", 0);
		curT.setValueBuffer("saldoinicial", saldo);
		saldoF = parseFloat(curT.valueBuffer("saldoinicial")) + parseFloat(curT.valueBuffer("debe")) - parseFloat(curT.valueBuffer("haber"));
		saldoF = AQUtil.roundFieldValue(saldoF, "co_partidas", "debe");
		curT.setValueBuffer("saldo", saldoF);
		curT.setValueBuffer("codgrupo", cli ? qC.value("clientes.codgrupocontablecli") : qC.value("proveedores.codgrupocontableprov"));
		if (!curT.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	
	/// Saldos per�odo
	var pI = this.iface.obtenerParamInformeCliProv();
	if (!pI) {
		return;
	}
	var q = flfactinfo.iface.estableceConsulta(cursor, pI);
	if (!q.exec()) {
		return false;
	}
	p = 0;
	flfactppal.iface.creaDialogoProgreso(sys.translate("Cargando datos..."), q.size());
	while (q.next()) {
		AQUtil.setProgress(++p);
		curT.select("idusuario = '" + sys.nameUser() + "' AND codtercero = '" + (cli ? q.value("clientes.codcliente") : q.value("proveedores.codproveedor")) + "'");
		if (!curT.first()) {
			curT.setModeAccess(curT.Insert);
			curT.refreshBuffer();
			curT.setValueBuffer("idusuario", sys.nameUser());
			curT.setValueBuffer("codtercero", cli ? q.value("clientes.codcliente") : q.value("proveedores.codproveedor"));
			curT.setValueBuffer("nombre", cli ? q.value("clientes.nombre") : q.value("proveedores.nombre"));
			curT.setValueBuffer("codgrupo", cli ? q.value("clientes.codgrupocontablecli") : q.value("proveedores.codgrupocontableprov"));
		} else {
			curT.setModeAccess(curT.Edit);
			curT.refreshBuffer();
		}
		curT.setValueBuffer("debe", q.value("SUM(co_partidas.debe)"));
		curT.setValueBuffer("haber", q.value("SUM(co_partidas.haber)"));
		
		saldoF = parseFloat(curT.valueBuffer("saldoinicial")) + parseFloat(curT.valueBuffer("debe")) - parseFloat(curT.valueBuffer("haber"));
		saldoF = AQUtil.roundFieldValue(saldoF, "co_partidas", "debe");
		curT.setValueBuffer("saldo", saldoF);
		if (!curT.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	
	var nombreReport = cli ? "co_i_balancesis_clientes" : "co_i_balancesis_proveedores";
	
	var q = new FLSqlQuery("co_i_balancesis_cliprov");
	debug(q.sql());
// 	q.setSelect("codtercero, nombre saldoinicial, debe, haber, saldofinal");
// 	q.setFrom("em_buffersyscliprov");
	var wQ = "idusuario = '" + sys.nameUser() + "'";
	if (cursor.valueBuffer("excluirsaldocero")) {
		wQ += " AND saldo <> 0";
	}
	q.setWhere(wQ);
	
	
	var rptViewer = new FLReportViewer();
	rptViewer.setReportData(q);
	rptViewer.setReportTemplate(nombreReport);
	rptViewer.renderReport();
	rptViewer.exec();
	
// 	if (!AQUtil.execSql("DELETE FROM co_i_balancesis_buffer_cliprov WHERE idusuario = '" + sys.nameUser() + "'")) {
// 		return false;
// 	}
}*/


function euromoda_cargaTablaTemp()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var cli = cursor.valueBuffer("clientes");
	
	if (!AQUtil.execSql("DELETE FROM co_i_balancesis_buffer_cliprov WHERE idusuario = '" + sys.nameUser() + "'")) {
		return false;
	}
	var saldoF;
	/// Saldo inicial

	var whereSubcuenta = "";

	if(cli) {
		var cuentasCli = AQUtil.sqlSelect("co_contppal_general","em_cuentascli","1=1");
		var excepCuentasCli = AQUtil.sqlSelect("co_contppal_general","em_excepcuentascli","1=1");
		var excepSubCuentasCli = AQUtil.sqlSelect("co_contppal_general","em_excepsubcuentascli","1=1");
		if(cuentasCli && cuentasCli != "") {
			whereSubcuenta = "co_subcuentas.codcuenta IN ('" + cuentasCli.split(",").join("', '") + "')";

			if(excepCuentasCli && excepCuentasCli != "") {
				whereSubcuenta += " AND co_subcuentas.codcuenta NOT IN ('" + excepCuentasCli.split(",").join("', '") + "')";				
			}

			if(excepSubCuentasCli && excepSubCuentasCli != "") {
				whereSubcuenta += " AND co_subcuentas.codsubcuenta NOT IN ('" + excepSubCuentasCli.split(",").join("', '") + "')";				
			}


		} else {
			formUI.ponMsgWarn(sys.translate("No est� informado el campo Cuentas de Cliente en el Area Financiera-Principal-Configuraci�n.\nPor favor informe las cuentas de clientes separadas por ','.\nSe cancela el proceso."));
		}
	} else {
		var cuentasProv = AQUtil.sqlSelect("co_contppal_general","em_cuentasprov","1=1");
		var excepCuentasProv = AQUtil.sqlSelect("co_contppal_general","em_excepcuentasprov","1=1");
		var excepSubCuentasProv = AQUtil.sqlSelect("co_contppal_general","em_excepsubcuentasprov","1=1");


		if(cuentasProv && cuentasProv != "") {
			whereSubcuenta = "co_subcuentas.codcuenta IN ('" + cuentasProv.split(",").join("', '") + "')";

			if(excepCuentasProv && excepCuentasProv != "") {
				whereSubcuenta += " AND co_subcuentas.codcuenta NOT IN ('" + excepCuentasProv.split(",").join("', '") + "')";				
			}

			if(excepSubCuentasProv && excepSubCuentasProv != "") {
				whereSubcuenta += " AND co_subcuentas.codsubcuenta NOT IN ('" + excepSubCuentasProv.split(",").join("', '") + "')";				
			}

		} else {
			formUI.ponMsgWarn(sys.translate("No est� informado el campo Cuentas de Proveedor en el Area Financiera-Principal-Configuraci�n.\nPor favor informe las cuentas de proveedores separadas por ','.\nSe cancela el proceso."));
		}
	}



	

	var wC = cli ? _i.dameWhereCli() : _i.dameWhereProv();
	var fechaDesde = cursor.valueBuffer("d_co__asientos_fecha");
	wC += wC != "" ? " AND " : "";
	wC += ("co_asientos.fecha < '" + fechaDesde + "'");

	if(whereSubcuenta && whereSubcuenta != "") {		
		wC += wC != "" ? " AND " : "";		
		wC += whereSubcuenta;
	}
	var qC = new FLSqlQuery;
	if (cli) {
		qC.setSelect("clientes.codcliente, clientes.nombre, clientes.codgrupocontablecli, SUM(co_partidas.debe-co_partidas.haber)");
		qC.setFrom("clientes INNER JOIN co_partidas ON  co_partidas.codcliente = clientes.codcliente INNER JOIN co_subcuentas ON co_subcuentas.idsubcuenta = co_partidas.idsubcuenta  INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
		qC.setWhere(wC + " GROUP BY clientes.codcliente, clientes.nombre, clientes.codgrupocontablecli");
	} else {
		qC.setSelect("proveedores.codproveedor, proveedores.nombre, proveedores.codgrupocontableprov, SUM(co_partidas.debe-co_partidas.haber)");
		qC.setFrom("proveedores INNER JOIN co_partidas ON  co_partidas.codproveedor = proveedores.codproveedor INNER JOIN co_subcuentas ON co_subcuentas.idsubcuenta = co_partidas.idsubcuenta  INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
		qC.setWhere(wC + " GROUP BY proveedores.codproveedor, proveedores.nombre, proveedores.codgrupocontableprov");
	}
	if (!qC.exec()) {
		return false;
	}
debug(qC.sql());
	var saldo, p = 0;
	var curT = new FLSqlCursor("co_i_balancesis_buffer_cliprov");
	flfactppal.iface.creaDialogoProgreso(sys.translate("Cargando saldos iniciales..."), qC.size());
	while (qC.next()) {
		AQUtil.setProgress(++p);
		saldo = parseFloat(qC.value("SUM(co_partidas.debe-co_partidas.haber)"));
		if (Math.abs(saldo) < 0.001) {
			continue;
		}
		curT.setModeAccess(curT.Insert);
		curT.refreshBuffer();
		curT.setValueBuffer("idusuario", sys.nameUser());
		curT.setValueBuffer("codtercero", cli ? qC.value("clientes.codcliente") : qC.value("proveedores.codproveedor"));
		curT.setValueBuffer("nombre", cli ? qC.value("clientes.nombre") : qC.value("proveedores.nombre"));
		curT.setValueBuffer("debe", 0);
		curT.setValueBuffer("haber", 0);
		curT.setValueBuffer("saldoinicial", saldo);
		saldoF = parseFloat(curT.valueBuffer("saldoinicial")) + parseFloat(curT.valueBuffer("debe")) - parseFloat(curT.valueBuffer("haber"));
		saldoF = AQUtil.roundFieldValue(saldoF, "co_partidas", "debe");
		curT.setValueBuffer("saldo", saldoF);
		curT.setValueBuffer("codgrupo", cli ? qC.value("clientes.codgrupocontablecli") : qC.value("proveedores.codgrupocontableprov"));
		if (!curT.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	
	/// Saldos per�odo
	//var pI = this.iface.obtenerParamInformeCliProv();
	//if (!pI) {
	//	return;
	//}
	//var q = flfactinfo.iface.estableceConsulta(cursor, pI);


	var wC = cli ? _i.dameWhereCli() : _i.dameWhereProv();
	var fechaDesde = cursor.valueBuffer("d_co__asientos_fecha");
	if(fechaDesde && fechaDesde != "") {
		wC += wC != "" ? " AND " : "";
		wC += ("co_asientos.fecha >= '" + fechaDesde + "'");
		
	}

	var fechaHasta = cursor.valueBuffer("h_co__asientos_fecha");
	if(fechaHasta && fechaHasta != "") {		
		wC += wC != "" ? " AND " : "";
		wC += ("co_asientos.fecha <= '" + fechaHasta + "'");	
	}
	if(whereSubcuenta && whereSubcuenta != "") {		
		wC += wC != "" ? " AND " : "";		
		wC += whereSubcuenta;
	}

	var codEjercicio = cursor.valueBuffer("i_co__subcuentas_codejercicio");
	if(codEjercicio && codEjercicio != "") {
		wC += wC != "" ? " AND " : "";
		wC = wC + "co_subcuentas.codejercicio = '" + codEjercicio + "'";
	}

	var q = new FLSqlQuery;
	if (cli) {
		q.setSelect("clientes.codcliente, clientes.nombre, SUM(co_partidas.debe), SUM(co_partidas.haber), clientes.codgrupocontablecli");
		q.setFrom("clientes INNER JOIN co_partidas ON  co_partidas.codcliente = clientes.codcliente INNER JOIN co_subcuentas ON co_subcuentas.idsubcuenta = co_partidas.idsubcuenta  INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
		q.setWhere(wC + " GROUP BY clientes.codcliente, clientes.nombre, clientes.codgrupocontablecli");
	} else {
		q.setSelect("proveedores.codproveedor, proveedores.nombre,SUM(co_partidas.debe), SUM(co_partidas.haber), proveedores.codgrupocontableprov");
		q.setFrom("proveedores INNER JOIN co_partidas ON  co_partidas.codproveedor = proveedores.codproveedor INNER JOIN co_subcuentas ON co_subcuentas.idsubcuenta = co_partidas.idsubcuenta  INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
		q.setWhere(wC + " GROUP BY proveedores.codproveedor, proveedores.nombre, proveedores.codgrupocontableprov");
	}
	debug("q2: "+q.sql());

	if (!q.exec()) {
		return false;
	}
	p = 0;
	flfactppal.iface.creaDialogoProgreso(sys.translate("Cargando datos..."), q.size());
	while (q.next()) {
		AQUtil.setProgress(++p);
		curT.select("idusuario = '" + sys.nameUser() + "' AND codtercero = '" + (cli ? q.value("clientes.codcliente") : q.value("proveedores.codproveedor")) + "'");
		if (!curT.first()) {
			curT.setModeAccess(curT.Insert);
			curT.refreshBuffer();
			curT.setValueBuffer("idusuario", sys.nameUser());
			curT.setValueBuffer("codtercero", cli ? q.value("clientes.codcliente") : q.value("proveedores.codproveedor"));
			curT.setValueBuffer("nombre", cli ? q.value("clientes.nombre") : q.value("proveedores.nombre"));
			curT.setValueBuffer("codgrupo", cli ? q.value("clientes.codgrupocontablecli") : q.value("proveedores.codgrupocontableprov"));
		} else {
			curT.setModeAccess(curT.Edit);
			curT.refreshBuffer();
		}
		curT.setValueBuffer("debe", q.value("SUM(co_partidas.debe)"));
		curT.setValueBuffer("haber", q.value("SUM(co_partidas.haber)"));
		
		saldoF = parseFloat(curT.valueBuffer("saldoinicial")) + parseFloat(curT.valueBuffer("debe")) - parseFloat(curT.valueBuffer("haber"));
		saldoF = AQUtil.roundFieldValue(saldoF, "co_partidas", "debe");
		curT.setValueBuffer("saldo", saldoF);
		if (!curT.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	
	var nombreReport = cli ? "co_i_balancesis_clientes" : "co_i_balancesis_proveedores";
	
	var q = new FLSqlQuery("co_i_balancesis_cliprov");
	
// 	q.setSelect("codtercero, nombre saldoinicial, debe, haber, saldofinal");
// 	q.setFrom("em_buffersyscliprov");
	var wQ = "idusuario = '" + sys.nameUser() + "'";
	if (cursor.valueBuffer("excluirsaldocero")) {
		wQ += " AND saldo <> 0";
	}
	q.setWhere(wQ);
	debug(q.sql());
	
	var rptViewer = new FLReportViewer();
	rptViewer.setReportData(q);
	rptViewer.setReportTemplate(nombreReport);
	rptViewer.renderReport();
	rptViewer.exec();
	
// 	if (!AQUtil.execSql("DELETE FROM co_i_balancesis_buffer_cliprov WHERE idusuario = '" + sys.nameUser() + "'")) {
// 		return false;
// 	}
}

function euromoda_obtenerParamInformeCliProv()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var w = "";
	var paramInforme = flfactinfo.iface.pub_dameParamInforme();
	
	if (cursor.valueBuffer("clientes")) {
		paramInforme.nombreInforme = "co_i_balancesis_clientes";
		paramInforme.groupBy = "clientes.codcliente, clientes.nombre, clientes.codgrupocontablecli";
		
		w = _i.dameWhereCli();
	} else {
		paramInforme.nombreInforme = "co_i_balancesis_proveedores";
		paramInforme.groupBy = "proveedores.codproveedor, proveedores.nombre, proveedores.codgrupocontableprov";
		
		w = _i.dameWhereProv();
	}
	
	paramInforme.whereFijo = w;
	return paramInforme;
}

function euromoda_dameWhereProv()
{
	var cursor = this.cursor();
	
	var w = "";

	var codProveedor = cursor.valueBuffer("codproveedor");
	if (codProveedor) {
		w += w != "" ? " AND " : "";
		w = "proveedores.codproveedor = '" + codProveedor + "'";
	}

	var codGrupoContableProv = cursor.valueBuffer("codgrupocontableprov");
	if(codGrupoContableProv){
		w += w != "" ? " AND " : "";
		w += "proveedores.codgrupocontableprov = '" + codGrupoContableProv + "'";
	}
	return w;
}

function euromoda_dameWhereCli()
{
	var cursor = this.cursor();
	var w = "";
	var codCliente = cursor.valueBuffer("codcliente");
	if (codCliente) {
		w += w != "" ? " AND " : "";
		w = "clientes.codcliente = '" + codCliente + "'";
	}

	var codGrupoContableCli = cursor.valueBuffer("codgrupocontablecli");
	if(codGrupoContableCli){
		w += w != "" ? " AND " : "";
		w = w + "clientes.codgrupocontablecli = '" + codGrupoContableCli + "'";
	}

	var codAgente = cursor.valueBuffer("codagente");
	if (codAgente) {
		w += w != "" ? " AND " : "";
		w = w + "clientes.codagente = '" + codAgente + "'";
	}
	return w;
}

// function euromoda_saldoInicialCli(nodo, campo)
// {
// 	var _i = this.iface;
// 	var codCliente = nodo.attributeValue("clientes.codcliente");
// 	if (!_i.datosSaldoCli_ || _i.datosSaldoCli_["codcliente"] != codCliente) {
// 		if (!_i.cargaSaldoCliente(codCliente)) {
// 			return false;
// 		}
// 	}
// 	return _i.datosSaldoCli_["saldoinicial"];
// }

// function euromoda_saldoInicialProv(nodo, campo)
// {
// 	var _i = this.iface;
// 	var codProveedor = nodo.attributeValue("proveedores.codproveedor");
// 	if (!_i.datosSaldoProv_ || _i.datosSaldoProv_["codproveedor"] != codProveedor) {
// 		if (!_i.cargaSaldoProveedor(codProveedor)) {
// 			return false;
// 		}
// 	}
// 	return _i.datosSaldoProv_["saldoinicial"];
// }

// function euromoda_saldoFinalCli(nodo, campo)
// {
// 	var _i = this.iface;
// 	var codCliente = nodo.attributeValue("clientes.codcliente");
// 	if (!_i.datosSaldoCli_ || _i.datosSaldoCli_["codcliente"] != codCliente) {
// 		if (!_i.cargaSaldoCliente(codCliente)) {
// 			return false;
// 		}
// 	}
// 	var debe = parseFloat(nodo.attributeValue("SUM(co_partidas.debe)"));
// 	debe = isNaN(debe) ? 0 : debe;
// 	var haber = parseFloat(nodo.attributeValue("SUM(co_partidas.haber)"));
// 	haber = isNaN(haber) ? 0 : haber;
// 	return _i.datosSaldoCli_["saldoinicial"] + debe - haber;
// }

// function euromoda_saldoFinalProv(nodo, campo)
// {
// 	var _i = this.iface;
// 	var codProveedor = nodo.attributeValue("proveedores.codproveedor");
// 	if (!_i.datosSaldoProv_ || _i.datosSaldoProv_["codproveedor"] != codProveedor) {
// 		if (!_i.cargaSaldoProveedor(codProveedor)) {
// 			return false;
// 		}
// 	}
// 	var debe = parseFloat(nodo.attributeValue("SUM(co_partidas.debe)"));
// 	debe = isNaN(debe) ? 0 : debe;
// 	var haber = parseFloat(nodo.attributeValue("SUM(co_partidas.haber)"));
// 	haber = isNaN(haber) ? 0 : haber;
// 	return _i.datosSaldoProv_["saldoinicial"] + debe - haber;
// }

// function euromoda_saldoInicialCli(codCliente)
// {
// 	var _i = this.iface;
// 	var cursor = this.cursor();
// 	
// 	var fechaDesde = cursor.valueBuffer("d_co__asientos_fecha");
// 	var sI = AQUtil.sqlSelect("clientes INNER JOIN gruposcontablescli ON clientes.codgrupocontablecli = gruposcontablescli.codgrupo INNER JOIN co_subcuentas ON (gruposcontablescli.codsubcuentacli = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefectos = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefdesc = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefcobro = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefimp = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafaccobro = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafacdesc = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafacimp = co_subcuentas.codsubcuenta) INNER JOIN co_partidas ON (co_subcuentas.idsubcuenta = co_partidas.idsubcuenta AND co_partidas.codcliente = clientes.codcliente) INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento", "SUM(co_partidas.debe-co_partidas.haber)", "clientes.codcliente = '" + codCliente + "' AND co_asientos.fecha < '" + fechaDesde + "'", "clientes");
// 	sI = isNaN(sI) ? 0 : sI;
// 		
// 	return sI;
// }

// function euromoda_cargaSaldoCliente(codCliente)
// {
// 	var _i = this.iface;
// 	var cursor = this.cursor();
// 	
// 	if (!_i.datosSaldoCli_) {
// 		_i.datosSaldoCli_ = new Object;
// 	}
// 	_i.datosSaldoCli_["codcliente"] = codCliente;
// 	
// 	var fechaDesde = cursor.valueBuffer("d_co__asientos_fecha");
// 	var sI = AQUtil.sqlSelect("clientes INNER JOIN gruposcontablescli ON clientes.codgrupocontablecli = gruposcontablescli.codgrupo INNER JOIN co_subcuentas ON (gruposcontablescli.codsubcuentacli = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefectos = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefdesc = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefcobro = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentaefimp = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafaccobro = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafacdesc = co_subcuentas.codsubcuenta OR gruposcontablescli.codsubcuentafacimp = co_subcuentas.codsubcuenta) INNER JOIN co_partidas ON (co_subcuentas.idsubcuenta = co_partidas.idsubcuenta AND co_partidas.codcliente = clientes.codcliente) INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento", "SUM(co_partidas.debe-co_partidas.haber)", "clientes.codcliente = '" + codCliente + "' AND co_asientos.fecha < '" + fechaDesde + "'", "clientes");
// 	sI = isNaN(sI) ? 0 : sI;
// 		
// 	_i.datosSaldoCli_["saldoinicial"] = sI;
// 	return true;
// }

// function euromoda_cargaSaldoProveedor(codProveedor)
// {
// 	var _i = this.iface;
// 	var cursor = this.cursor();
// 	
// 	if (!_i.datosSaldoProv_) {
// 		_i.datosSaldoProv_ = new Object;
// 	}
// 	_i.datosSaldoProv_["codproveedor"] = codProveedor;
// 	
// 	var fechaDesde = cursor.valueBuffer("d_co__asientos_fecha");
// 	var sI = AQUtil.sqlSelect("proveedores INNER JOIN gruposcontablesprov ON proveedores.codgrupocontableprov = gruposcontablesprov.codgrupo 		INNER JOIN co_subcuentas ON (gruposcontablesprov.codsubcuentaprov = co_subcuentas.codsubcuenta OR gruposcontablesprov.codsubcuentaefectos = co_subcuentas.codsubcuenta OR gruposcontablesprov.codsubcuentaefpago = co_subcuentas.codsubcuenta OR gruposcontablesprov.codsubcuentafacpago = co_subcuentas.codsubcuenta) INNER JOIN co_partidas ON (co_subcuentas.idsubcuenta = co_partidas.idsubcuenta AND co_partidas.codproveedor = proveedores.codproveedor) INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento", "SUM(co_partidas.debe-co_partidas.haber)", "proveedores.codproveedor = '" + codProveedor + "' AND co_asientos.fecha < '" + fechaDesde + "'", "proveedores");
// 	sI = isNaN(sI) ? 0 : sI;
// 		
// 	_i.datosSaldoProv_["saldoinicial"] = sI;
// 	return true;
// }

function euromoda_dameWhereFechaSaldoInicial(cursor)
{
	var w = "";
	var desdeAct = cursor.valueBuffer("d_co__asientos_fecha");
	if (desdeAct) {
		w += (w != "") ? " AND " : "";
		w += "co_asientos.fecha < '" + desdeAct + "'"
	}
	return w;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
