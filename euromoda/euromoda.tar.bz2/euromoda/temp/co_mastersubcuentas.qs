
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA //////////////////////////////////////////////
class euromoda extends oficial {
    function euromoda( context ) { oficial ( context ); }
    function init() {
        return this.ctx.euromoda_init();
    }
    function tbnRecalculaSaldos_clicked() {
        return this.ctx.euromoda_tbnRecalculaSaldos_clicked();
    }
}
//// EUROMODA //////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA //////////////////////////////////////////////
function euromoda_init()
{
    var _i = this.iface;
    _i.__init();
    
    connect(this.child("tbnRecalculaSaldos"), "clicked()", _i, "tbnRecalculaSaldos_clicked");
}

function euromoda_tbnRecalculaSaldos_clicked()
{
    var _i = this.iface;
    
	var codEjercicio = flfactppal.iface.pub_ejercicioActual();
	
	var qrySaldos = new FLSqlQuery;
	qrySaldos.setTablesList("co_subcuentas");
	qrySaldos.setSelect("idsubcuenta");
	qrySaldos.setFrom("co_subcuentas");
	qrySaldos.setWhere("codejercicio = '" + codEjercicio + "'");
	qrySaldos.setForwardOnly( true ); 
	if (!qrySaldos.exec()) {
		return false;
	}
	AQUtil.createProgressDialog( sys.translate("Revisando saldos" ), qrySaldos.size() );
	var progress = 0;
	while (qrySaldos.next()) {
		AQUtil.setProgress(progress++);
		if (!flcontppal.iface.pub_calcularSaldo(qrySaldos.value(0), true)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	this.child("tableDBRecords").refresh();
	return true;
}

//// EUROMODA //////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
