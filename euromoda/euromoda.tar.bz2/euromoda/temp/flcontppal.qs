
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends ivaNav {
	var cacheCliProv_;
	var enCierre_;
  function euromoda( context ) { ivaNav ( context ); }
  function beforeCommit_co_asientos(curA) {
    return this.ctx.euromoda_beforeCommit_co_asientos(curA);
  }
  function beforeCommit_co_partidas(curP) {
    return this.ctx.euromoda_beforeCommit_co_partidas(curP);
  }
  function afterCommit_co_partidas(curP) {
    return this.ctx.euromoda_afterCommit_co_partidas(curP);
  }
  function compruebaFechaAsiento(curA) {
    return this.ctx.euromoda_compruebaFechaAsiento(curA);
  }
  function valorDefectoCont(fN) {
    return this.ctx.euromoda_valorDefectoCont(fN);
  }
  function compruebaBloqueoCompras(curA) {
    return this.ctx.euromoda_compruebaBloqueoCompras(curA);
  }
  function compruebaDatosAuxPartida(curP) {
    return this.ctx.euromoda_compruebaDatosAuxPartida(curP);
  }
  function subcuentasCache(codigo, tipo) {
    return this.ctx.euromoda_subcuentasCache(codigo, tipo);
  }
  function fullyCalculateField(fieldName, cursor, tableName, queryName, orderBy) {
    return this.ctx.euromoda_fullyCalculateField(fieldName, cursor, tableName, queryName, orderBy);
  }
  function comprobarSaldoCliProv(curP) {
    return this.ctx.euromoda_comprobarSaldoCliProv(curP);
  }
  function afterCommit_co_em_saldopartidas(curSP) {
    return this.ctx.euromoda_afterCommit_co_em_saldopartidas(curSP);
  }
  function beforeCommit_co_em_saldopartidas(curSP) {
    return this.ctx.euromoda_beforeCommit_co_em_saldopartidas(curSP);
  }
  function controlRecibosSP(curSP) {
    return this.ctx.euromoda_controlRecibosSP(curSP);
  }
  function totalizaSaldoPartida(curSP) {
    return this.ctx.euromoda_totalizaSaldoPartida(curSP);
  }
  function datosPartidaDotacionElem(curPartida, curDotacion, idAsiento, valoresDefecto) {
    return this.ctx.euromoda_datosPartidaDotacionElem(curPartida, curDotacion, idAsiento, valoresDefecto);
  }
  function datosPartidaDotacionAmor(curPartida, curDotacion, idAsiento, valoresDefecto) {
    return this.ctx.euromoda_datosPartidaDotacionAmor(curPartida, curDotacion, idAsiento, valoresDefecto);
  }
  function calcularSaldo(idSubcuenta, forzar) {
    return this.ctx.euromoda_calcularSaldo(idSubcuenta, forzar);
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_actualizaSubsaldoPartidas(curPartida, oDatos) {
		return this.actualizaSubsaldoPartidas(curPartida, oDatos);
	}
	function pub_calcularSaldo(idSubcuenta, forzar) {
		return this.calcularSaldo(idSubcuenta, forzar);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_beforeCommit_co_asientos(curA)
{
  var _i = this.iface;
  if (!_i.compruebaFechaAsiento(curA)) {
    return false;
  }
  if (!_i.__beforeCommit_co_asientos(curA)) {
    return false;
  }
  if (!_i.compruebaBloqueoCompras(curA)) {
    return false;
  }
  return true;
}

function euromoda_beforeCommit_co_partidas(curP)
{
  var _i = this.iface;
  if (!_i.compruebaDatosAuxPartida(curP)) {
    return false;
  }
  return true;
}

function euromoda_compruebaDatosAuxPartida(curP)
{
	if (curP.modeAccess() == curP.Del) {
		return true;
	}
  
  // Esta comprobaci�n no deja hacer el asiento de cierre y de apertura.
  // Esto es temporal para ignorarla. Habr� que modificar la
  // funci�n que hace el cierre para que funcione con Euromoda
  var concepto = curP.valueBuffer("concepto");
	if (concepto && concepto != "") {
		if (concepto.startsWith(sys.translate("Asiento de cierre de ejercicio")) ||
				concepto.startsWith(sys.translate("Asiento de apertura de ejercicio"))) {
			return true;
		}
	}
  ///////
  
	var idCuentaEsp = AQUtil.sqlSelect("co_subcuentas s INNER JOIN co_cuentas c ON s.idcuenta = c.idcuenta", "c.idcuentaesp", "s.idsubcuenta = " + curP.valueBuffer("idsubcuenta"), "co_subcuentas,co_cuentas");
	switch (idCuentaEsp) {
		case "CLIENT": {
			var codCliente = curP.valueBuffer("codcliente");
			if (!codCliente || codCliente == "") {
				MessageBox.warning(sys.translate("Ha establecido una subcuenta de cliente pero no ha informado el correspondiente c�digo de cliente en la partida"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
			}
			break;
		}
		/*case "PROVEE": {
			var codProveedor = curP.valueBuffer("codproveedor");
			if (!codProveedor || codProveedor == "") {
				MessageBox.warning(sys.translate("Ha establecido una subcuenta de proveedor pero no ha informado el correspondiente c�digo de proveedor en la partida"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
			}
			break;
		}*/
		//Ahora para proveedor no va a ir por idcuenta especial, vamos a buscar en la lista 	

      case "ACTIVO": {
			var codActivo = curP.valueBuffer("codactivo");
			if (!codActivo || codActivo == "") {
				MessageBox.warning(sys.translate("Ha establecido una subcuenta de activo pero no ha informado el correspondiente c�digo de activo en la partida"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
			}
			break;
		}
	}

	
	

	var codProveedor = curP.valueBuffer("codproveedor");
	if(!codProveedor || codProveedor == "") {
		var cuentasProv = AQUtil.sqlSelect("co_contppal_general","em_cuentasprov","1=1");
		if(AQUtil.sqlSelect("co_subcuentas","codcuenta","idsubcuenta = " + curP.valueBuffer("idsubcuenta") + " AND codcuenta IN  ('" + cuentasProv.split(",").join("', '") + "')")) {
			MessageBox.warning(sys.translate("Ha establecido una subcuenta de proveedor pero no ha informado el correspondiente c�digo de proveedor en la partida"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return false;
		}
	}

	return true;
}

function euromoda_compruebaFechaAsiento(curA)
{
  var _i = this.iface;
  var fecha = curA.valueBuffer("fecha");
  var fDMA = AQUtil.dateAMDtoDMA(fecha);
  var fD = _i.valorDefectoCont("fechacompdesde");
  if (fD && AQUtil.daysTo(fecha, fD) > 0) {
    MessageBox.warning(sys.translate("La fecha del asiento (%1) est� por debajo del intervalo de fechas permitido").arg(fDMA), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  var fH = _i.valorDefectoCont("fechacomphasta");
  if (fH && AQUtil.daysTo(fecha, fH) < 0) {
    MessageBox.warning(sys.translate("La fecha del asiento (%1) est� por encima del intervalo de fechas permitido").arg(fDMA), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  return true;
}

function euromoda_valorDefectoCont(fN)
{
  return AQUtil.sqlSelect("co_contppal_general", fN, "true");
}

function euromoda_compruebaBloqueoCompras(curA)
{
  var idAsiento = curA.valueBuffer("idasiento");
  var fecha = curA.valueBuffer("fecha");
  var fDMA = AQUtil.dateAMDtoDMA(fecha);
  var mes1 = fecha.setDate(1);
  if (!AQUtil.sqlSelect("co_mesesbloqueados", "mes", "mes = '" + mes1 + "' AND bloqcompras")) {
    return true;
  }
  var sCCompras = AQUtil.sqlSelect("co_partidas p INNER JOIN co_subcuentas s ON p.idsubcuenta = s.idsubcuenta INNER JOIN co_cuentas c ON s.idcuenta = c.idcuenta", "p.codsubcuenta", "p.idasiento = " + idAsiento + " AND c.idcuentaesp = 'COMPRA'", "co_partidas,co_subcuentas,co_cuentas");
  if (sCCompras) {
    MessageBox.warning(sys.translate("El asiento contiene una subcuenta de compras (%1) y su fecha (%2) pertenece a un mes con las compras bloqueadas").arg(sCCompras).arg(fDMA), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  return true;
}

function euromoda_subcuentasCache(codigo, tipo)
{
// debug("euromoda_subcuentasCache");
	var _i = this.iface;
	if (_i.cacheCliProv_) {
		if (_i.cacheCliProv_["tipo"] == tipo && _i.cacheCliProv_["codigo"] == codigo) {
// debug("euromoda_subcuentasCache: " + codigo + " En cache");
			return _i.cacheCliProv_["subcuentas"];
		}
	}
	_i.cacheCliProv_ = new Object;
	_i.cacheCliProv_["codigo"] = codigo;
	_i.cacheCliProv_["tipo"] = tipo;
	_i.cacheCliProv_["subcuentas"] = "'not found'";
	switch (tipo) {
		case "cliente": {
			var codGrupo = AQUtil.sqlSelect("clientes", "codgrupocontablecli", "codcliente = '" + codigo + "'");
			_i.cacheCliProv_["subcuentas"] = formRecordclientes.iface.pub_dameListaSubcuentas(codGrupo);
			break;
		}
		case "proveedor": {
			var codGrupo = AQUtil.sqlSelect("proveedores", "codgrupocontableprov", "codproveedor = '" + codigo + "'");
			_i.cacheCliProv_["subcuentas"] = formRecordproveedores.iface.pub_dameListaSubcuentas(codGrupo);
			break;
		}
		case "activo": {
			var codGrupo = AQUtil.sqlSelect("co_amortizaciones", "codgrupocontableamo", "codamortizacion = '" + codigo + "'");
			_i.cacheCliProv_["subcuentas"] = formRecordco_amortizaciones.iface.pub_dameListaSubcuentas(codGrupo);
		}
	}
	return _i.cacheCliProv_["subcuentas"];
}

function euromoda_fullyCalculateField(fieldName, cursor, tableName, queryName, orderBy)
{
	var _i = this.iface;
	switch (queryName) {
		case "co_partidasmayorcliprov": {
			switch (fieldName) {
				case "subsaldo": {
					var fecha = cursor.value("fecha");
					var idPartida = cursor.value("idpartida");
					var codSubcuenta = cursor.value("codsubcuenta");
					var codCliente = cursor.value("codcliente");
					var codProveedor = cursor.value("codproveedor");
					var whereCliProv = codCliente ? (" AND codcliente = '" + codCliente + "'") : (" AND codproveedor = '" + codProveedor + "'");
					var subcuentas = codCliente ? _i.subcuentasCache(codCliente, "cliente") : _i.subcuentasCache(codProveedor, "proveedor");

					var qry = new AQSqlQuery;
					qry.setSelect("SUM(debe-haber)");
					qry.setFrom("co_partidas INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
					qry.setWhere("codsubcuenta IN (" + subcuentas + ")" + whereCliProv + " AND (co_asientos.fecha < '" + fecha + "' OR (co_asientos.fecha = '" + fecha + "' AND co_partidas.idpartida <= " + idPartida + "))");
// 					qry.setOrderBy("co_asientos.fecha, co_partidas.idpartida");
debug(qry.sql());
					if (!qry.exec())
						return undefined;

					var saldo = 0;
					if (!qry.first()) {
						return undefined;
					}
					saldo = qry.value(0);
// 					while (qry.next()) {
// 						saldo += parseFloat(qry.value(0));
// 						if (qry.value(1) == idPartida)
// 							break;
// 					}
					return saldo;
					break;
				}
				default: {
					return _i.__fullyCalculateField(fieldName, cursor, tableName, queryName, orderBy);
				}
			}
			break;
		}
		case "co_qry_amortizacion": {
			switch (fieldName) {
				case "subsaldo": {
					var fecha = cursor.value("fecha");
					var idPartida = cursor.value("idpartida");
// 					var codSubcuenta = cursor.value("codsubcuenta");
					var codActivo = cursor.value("codactivo");
					var whereActivo = " AND codactivo = '" + codActivo + "'";
					var subcuentas = _i.subcuentasCache(codActivo, "activo")
					
					var qry = new AQSqlQuery;
					qry.setSelect("SUM(debe-haber)");
					qry.setFrom("co_partidas INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
// 					qry.setWhere("codsubcuenta IN (" + subcuentas + ")" + whereActivo);
					qry.setWhere("codsubcuenta IN (" + subcuentas + ")" + whereActivo + " AND (co_asientos.fecha < '" + fecha + "' OR (co_asientos.fecha = '" + fecha + "' AND co_partidas.idpartida <= " + idPartida + "))");
// 					qry.setOrderBy("co_asientos.fecha, co_partidas.idpartida");
					if (!qry.exec())
						return undefined;

					var saldo = 0;
					if (!qry.first()) {
						return undefined;
					}
					saldo = qry.value(0);
// 					while (qry.next()) {
// 						saldo += parseFloat(qry.value(0));
// 						if (qry.value(1) == idPartida)
// 							break;
// 					}
					return saldo;
					break;
				}
				default: {
					return _i.__fullyCalculateField(fieldName, cursor, tableName, queryName, orderBy);
				}
			}
			break;
		}
		case "co_qry_punteo_partidas":
		case "co_partidasmayor": {
			switch (fieldName) {
					case "saldo": {
					var idPartida = cursor.value("idpartida");
					var codSubcuenta = cursor.value("codsubcuenta");

					var qry = new AQSqlQuery;
// 					qry.setSelect("debe-haber,idpartida");
// 					qry.setFrom("co_partidas INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
// 					qry.setWhere("codsubcuenta = '" + codSubcuenta + "'");
// // qry.setWhere("idsubcuenta IN (SELECT idsubcuenta FROM co_subcuentas WHERE codsubcuenta = '" + codSubcuenta + "')");
// 					qry.setOrderBy("co_asientos.fecha, co_partidas.idpartida");
// 					if (!qry.exec()) {
// 						return undefined;
// 					}
// 					var saldo = 0;
// 					while (qry.next()) {
// 						saldo += parseFloat(qry.value(0));
// 						if (qry.value(1) == idPartida)
// 							break;
// 					}
// 					return saldo;
					var fecha = cursor.value("fecha");
					var numero = cursor.value("numero");
					var idPartida = cursor.value("idpartida");
// debug("numero = " + numero);
// debug("idPartida = " + idPartida);
					qry.setSelect("SUM(debe-haber)");
					qry.setFrom("co_partidas INNER JOIN co_asientos ON co_partidas.idasiento = co_asientos.idasiento");
					qry.setWhere("codsubcuenta = '" + codSubcuenta + "' AND (co_asientos.fecha < '" + fecha + "' OR (co_asientos.fecha = '" + fecha + "' AND co_partidas.idpartida <= " + idPartida + "))" );
 debug(qry.sql());
					if (!qry.exec()) {
						return undefined;
					}
					if (!qry.first()) {
						return undefined;
					}
					saldo = qry.value(0);
					return saldo;
					break;
				}
				default: {
					return _i.__fullyCalculateField(fieldName, cursor, tableName, queryName, orderBy);
				}
			}
			break;
		}
		default: {
			return _i.__fullyCalculateField(fieldName, cursor, tableName, queryName, orderBy);
		}
  }
  return undefined;
}

function euromoda_afterCommit_co_partidas(curP)
{
	var _i = this.iface;
	if (!_i.__afterCommit_co_partidas(curP)) {
		return false;
	}
	if (!_i.comprobarSaldoCliProv(curP)) {
		return false;
	}
	return true;
}

function euromoda_comprobarSaldoCliProv(curP)
{
	if (curP.modeAccess() == curP.Edit && curP.valueBuffer("debe") == curP.valueBufferCopy("debe") && curP.valueBuffer("haber") == curP.valueBufferCopy("haber")) {
		return true;
	}
	var codCliente = curP.valueBuffer("codcliente");
	var codProveedor = curP.valueBuffer("codproveedor");
	if (!codCliente && !codProveedor) {
		return true;
	}
	if (codCliente) {
		if (!flfactteso.iface.pub_actualizaSaldoCliente(curP)) {
			return false;
		}
	} else {
		if (!flfactteso.iface.pub_actualizaSaldoProveedor(curP)) {
			return false;
		}
	}
	return true;
}

function euromoda_afterCommit_co_em_saldopartidas(curSP)
{
	var _i = this.iface;
	//debug("afterCommit_co_em_saldopartidas");
	if (!_i.totalizaSaldoPartida(curSP)) {
		return false;
	}
	//debug("afterCommit_co_em_saldopartidas 2");
	var idAnticipo = curSP.valueBuffer("idanticipocli");
	if (idAnticipo) {
		if (!flfactteso.iface.pub_actualizaPteAnticipo(idAnticipo)) {
			return false;
		}
	}
	var idAnticipoProv = curSP.valueBuffer("idanticipoprov");
	if (idAnticipoProv) {
		if (!flfactteso.iface.pub_actualizaPteAnticipoProv(idAnticipoProv)) {
			return false;
		}
	}
	return true;
}

function euromoda_beforeCommit_co_em_saldopartidas(curSP)
{
	var _i = this.iface;
	if (!_i.controlRecibosSP(curSP)) {
		return false;
	}
	return true;
}

function euromoda_controlRecibosSP(curSP)
{
	var _i = this.iface;
	if (curSP.modeAccess() == curSP.Del) {
		var idRecibo = curSP.valueBuffer("idrecibocli");
		if (idRecibo) {
			if (!flfactteso.iface.pub_desvincularReciboPartida(idRecibo, curSP.valueBuffer("idsaldo"))) {
				return false;
			}
		}
		var idReciboProv = curSP.valueBuffer("idreciboprov");
		if (idReciboProv) {
			if (!flfactteso.iface.pub_desvincularReciboProvPartida(idReciboProv, curSP.valueBuffer("idsaldo"))) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_totalizaSaldoPartida(curSP)
{
	var _i = this.iface;
	var idPartida = curSP.valueBuffer("idpartida1");
	var curPartida = new FLSqlCursor("co_partidas");
	curPartida.setActivatedCommitActions(false);
	curPartida.setActivatedCheckIntegrity(false);
	curPartida.select("idpartida = " + idPartida);
	if (!curPartida.first()) {
		return false;
	}
	//debug("totalizaSaldoPartida");
	curPartida.setModeAccess(curPartida.Edit);
	curPartida.refreshBuffer();
	curPartida.setValueBuffer("importependiente", formRecordco_partidas.iface.pub_commonCalculateField("importependiente", curPartida));
	//debug("totalizaSaldoPartida 1");
	if (!curPartida.commitBuffer()) {
		return false;
	}//debug("totalizaSaldoPartida 2");
	idPartida = curSP.valueBuffer("idpartida2");
	if (idPartida) {
		curPartida.select("idpartida = " + idPartida);
		if (!curPartida.first()) {
			return false;
		}
		curPartida.setModeAccess(curPartida.Edit);
		curPartida.refreshBuffer();
		curPartida.setValueBuffer("importependiente", formRecordco_partidas.iface.pub_commonCalculateField("importependiente", curPartida));
		if (!curPartida.commitBuffer()) {
			return false;
		}
	}
	//debug("totalizaSaldoPartida 3");
	return true;
}

function euromoda_datosPartidaDotacionElem(curPartida, curDotacion, idAsiento, valoresDefecto)
{
	var _i = this.iface;
	if (!_i.__datosPartidaDotacionElem(curPartida, curDotacion, idAsiento, valoresDefecto)) {
		return false;
	}
	curPartida.setValueBuffer("codactivo", curDotacion.valueBuffer("codamortizacion"));
	return true;
}

function euromoda_datosPartidaDotacionAmor(curPartida, curDotacion, idAsiento, valoresDefecto)
{
	var _i = this.iface;
	if (!_i.__datosPartidaDotacionAmor(curPartida, curDotacion, idAsiento, valoresDefecto)) {
		return false;
	}
	curPartida.setValueBuffer("codactivo", curDotacion.valueBuffer("codamortizacion"));
	return true;
}

/// Evita bloqueos. Sustituir por c�lculo tras transacciones.
function euromoda_calcularSaldo(idSubcuenta, forzar)
{
	var _i = this.iface;
	if (forzar || _i.enCierre_) {
		_i.__calcularSaldo(idSubcuenta);
	}
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
