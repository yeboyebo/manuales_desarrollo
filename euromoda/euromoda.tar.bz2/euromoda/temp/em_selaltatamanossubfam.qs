/***************************************************************************
                 em_seltamanossubfam.qs  -  description
                             -------------------
    begin                : mie sep 21 2011
    copyright            : (C) 2004-2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); }
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function cargaSelecciones() {
		return this.ctx.oficial_cargaSelecciones();
	}
	function ordenaColumnas()
	{
		return this.ctx.oficial_ordenaColumnas();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.ordenaColumnas();
	_i.cargaSelecciones();	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", this, "iface.pushButtonAccept_clicked");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_cargaSelecciones()
{
    debug("cursor.action()2: " + this.cursor().action());
	//var aSel = formRecordem_altamasivasubfam.iface.aTamanos_;
    var aSel = formem_altamasivasubfam2.iface.aTamanos_;
	if (!aSel) {
		return;
	}
    debug("aSel: " + aSel.toString());
	for (var i = 0; i < aSel.length; i++) {
		this.child("tdbTamanos").setPrimaryKeyChecked(aSel[i], true);
	}
	this.child("tdbTamanos").refresh();
}

function oficial_pushButtonAccept_clicked()
{
    debug("cursor.action()3: " + this.cursor().action());
	formRecordem_altamasivasubfam.iface.aTamanos_ = this.child("tdbTamanos").primarysKeysChecked();
    formem_altamasivasubfam2.iface.aTamanos_ = this.child("tdbTamanos").primarysKeysChecked();
    debug("formRecordem_altamasivasubfam.iface.aTamanos_ : " + formRecordem_altamasivasubfam.iface.aTamanos_.toString()); 
	this.accept();
}
function oficial_ordenaColumnas()
{
	var _i = this.iface;
 	var t = this.child("tdbTamanos");
   	
 	var campos = ["codtamanoem", "unidadesemb", "em_codtipoemb","orden"];
	t.setOrderCols(campos); 
  	t.refresh();
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
