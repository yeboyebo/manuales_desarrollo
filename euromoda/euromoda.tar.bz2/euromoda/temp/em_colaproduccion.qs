var form = this;
/***************************************************************************
         em_colaproduccion.qs  -  description
                             -------------------
    begin                : jue abr 27 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblPteConfirmar_, tblConfirmado_, tblCola_, codMaquina_, velMaquina_, tipoProduccion_; 
	var oMaquina_;
	var cMAQ_, cMMC_,cPMC_, cFIMC_, cFFMC_;
	var cSEC_, cMSC_,cPSC_, cFISC_, cFFSC_;
	var oRetardosMaq_;
	var sep_= "_X_";
	var curOrden_;
	var fechaBaseColaProd_;
	var colorNaranja_, colorAmarillo_, colorVerde_, colorAzul_;
	var analizarPTE_,analizarCON_,analizarCOLA_;
	var tejidoPTE_, tejidoCON_, tejidoCOLA_;
    function oficial( context ) { interna( context ); }
    function cargaCombos() {
    	return this.ctx.oficial_cargaCombos();
    }
	function cargaComboFabrica() {
		return this.ctx.oficial_cargaComboFabrica();
	}
	function cbFabrica_activated() {
		return this.ctx.oficial_cbFabrica_activated();
	}
	function cargaComboSeccion() {
		return this.ctx.oficial_cargaComboSeccion();
	}
	function cbSeccion_activated() {
		return this.ctx.oficial_cbSeccion_activated();
	}
	function cargaComboMaquina() {
		return this.ctx.oficial_cargaComboMaquina();
	}
	function cbMaquina_activated() {
		return this.ctx.oficial_cbMaquina_activated();
	}
	function iniciaTablas() {
		return this.ctx.oficial_iniciaTablas();
	}	
	function iniciaTablaPteConfirmar() {
		return this.ctx.oficial_iniciaTablaPteConfirmar();
	}
	function formateaPteConfirmar(f, c, v) {
		return this.ctx.oficial_formateaPteConfirmar(f, c, v);
	}
	function dimeGrupoSeccion(grupo) {
		return this.ctx.oficial_dimeGrupoSeccion(grupo);
	}
	function dameFiltroPteConfirmar() {
		return this.ctx.oficial_dameFiltroPteConfirmar();
	}
	function filtraPteConfirmar() {
		return this.ctx.oficial_filtraPteConfirmar();
	}
	function pbnConfirmar_clicked() {
		return this.ctx.oficial_pbnConfirmar_clicked();
	}
	function pbnDesconfirmar_clicked() {
		return this.ctx.oficial_pbnDesconfirmar_clicked();
	}
	function pbnParalizar_clicked() {
		return this.ctx.oficial_pbnParalizar_clicked();
	}
	function iniciaTablaConfirmado() {
		return this.ctx.oficial_iniciaTablaConfirmado();
	}
	function formateaConfirmado(f, c, v) {
		return this.ctx.oficial_formateaConfirmado(f, c, v);
	}
	function dameFiltroConfirmado() {
		return this.ctx.oficial_dameFiltroConfirmado();
	}	
	function filtraConfirmado() {
		return this.ctx.oficial_filtraConfirmado();
	}
	function iniciaTablaCola() {
		return this.ctx.oficial_iniciaTablaCola();
	}
	function iniciaTablaMaquina() {
		return this.ctx.oficial_iniciaTablaMaquina();
	}
	function iniciaTablaSeccion() {
		return this.ctx.oficial_iniciaTablaSeccion();
	}
	function formateaCola(f, c, v) {
		return this.ctx.oficial_formateaCola(f, c, v);
	}
	function dameDescripcionOrden(q) {
		return this.ctx.oficial_dameDescripcionOrden(q);
	}
	function dameDiaMes(fecha) {
		return this.ctx.oficial_dameDiaMes(fecha);
	}
	function concatenaValorSiExiste(valor, vCon, sep) {
		return this.ctx.oficial_concatenaValorSiExiste(valor, vCon, sep);
	}
	function dameFiltroCola(codMaquina) {
		return this.ctx.oficial_dameFiltroCola(codMaquina);
	}
	function filtraCola() {
		return this.ctx.oficial_filtraCola();
	}
	function tbnRefrescaCola_clicked() {
		return this.ctx.oficial_tbnRefrescaCola_clicked();
	}
	function refresca() {
		return this.ctx.oficial_refresca();
	}
	function tbnEnviar_clicked() {
		return this.ctx.oficial_tbnEnviar_clicked();
	}
	function tbnInsertar_clicked() {
		return this.ctx.oficial_tbnInsertar_clicked();
	}
	function tbnQuitaOrden_clicked() {
		return this.ctx.oficial_tbnQuitaOrden_clicked();
	}
	function tbnArriba_clicked() {
		return this.ctx.oficial_tbnArriba_clicked();
	}
	function tbnAbajo_clicked() {
		return this.ctx.oficial_tbnAbajo_clicked();
	}
	function recalculaOrdenCola() {
		return this.ctx.oficial_recalculaOrdenCola();
	}
	function estimaMinutosProd(codModoOper,cantidadPte) {
		return this.ctx.oficial_estimaMinutosProd(codModoOper,cantidadPte);
	}
	function dameVelocidadMaquina(codModoOper) {
		return this.ctx.oficial_dameVelocidadMaquina(codModoOper);
	}
	function recalculaPrevision() {
		return this.ctx.oficial_recalculaPrevision();
	}
	function calculaTiemposCola() {
		return this.ctx.oficial_calculaTiemposCola();
	}
	function calculaRetardoParo(curO) {
		return this.ctx.oficial_calculaRetardoParo(curO);
	}
	function cargaFabricaSeccion(codMaquina) {
		return this.ctx.oficial_cargaFabricaSeccion(codMaquina);
	}
	function cargaCacheMaquina() {
		return this.ctx.oficial_cargaCacheMaquina();
	}
	function asignaMaquina(codMaquina) {
		return this.ctx.oficial_asignaMaquina(codMaquina);
	}
	function cargaVelocidadXModo(codMaquina) {
		return this.ctx.oficial_cargaVelocidadXModo(codMaquina);
	}
	function cargaFechaCalculo() {
		return this.ctx.oficial_cargaFechaCalculo();
	}
	function dameCantidadPte(codOrden) {
		return this.ctx.oficial_dameCantidadPte(codOrden);
	}
	function cargaDatosMaq() {
		return this.ctx.oficial_cargaDatosMaq();
	}
	function cargaDatosSec() {
		return this.ctx.oficial_cargaDatosSec();
	}
	function tbnExcelCola_clicked() {
		return this.ctx.oficial_tbnExcelCola_clicked();
	} 
	function tbnImprimirCola_clicked() {
		return this.ctx.oficial_tbnImprimirCola_clicked();
	}
	function dameParamInformeCola() {
		return this.ctx.oficial_dameParamInformeCola();
	}
	function dameMaquinaColaAct() {
		return this.ctx.oficial_dameMaquinaColaAct();	
	}
	function imprimirCola(oParam) {
		return this.ctx.oficial_imprimirCola(oParam);
	}
	function tbnAhora_clicked() {
		return this.ctx.oficial_tbnAhora_clicked();
	}
	function cargarArrayRecargos() {
		return this.ctx.oficial_cargarArrayRecargos();
	}
	function calculaRetardoReverso(curO, fila) {
		return this.ctx.oficial_calculaRetardoReverso(curO, fila);
	}
	function calculaRetardoAnverso(curO, fila) {
		return this.ctx.oficial_calculaRetardoAnverso(curO, fila);
	}
	function calculaRetardoTipoTejido(curO, fila) {
		return this.ctx.oficial_calculaRetardoTipoTejido(curO, fila);
	}
	function calculaRetardoAcabado(curO, fila) {
		return this.ctx.oficial_calculaRetardoAcabado(curO, fila);
	}
	function colorConfirmado(f, c) {
    	return this.ctx.oficial_colorConfirmado(f, c);
    }
	function colorPendiente(f, c) {
    	return this.ctx.oficial_colorPendiente(f, c);
    }
    function colorCola(f, c) {
    	return this.ctx.oficial_colorCola(f, c);
    }
    function tblPteConfirmar_doubleClicked(f, c) {
    	return this.ctx.oficial_tblPteConfirmar_doubleClicked(f, c);
    }
    function tblConfirmado_doubleClicked(f, c) {
		return this.ctx.oficial_tblConfirmado_doubleClicked(f, c);
	}
    function tblCola_doubleClicked(f, c) {
		return this.ctx.oficial_tblCola_doubleClicked(f, c);
	}
	function tbnExcelColaAmp_clicked() {
		return this.ctx.oficial_tbnExcelColaAmp_clicked();
	} 
	function exportaExcelCola(ampliada) {
		return this.ctx.oficial_exportaExcelCola(ampliada);
	}
	function pbnVerReservas_clicked() {
		return this.ctx.oficial_pbnVerReservas_clicked();
	}
	function pbnVerReservasCon_clicked() {
		return this.ctx.oficial_pbnVerReservasCon_clicked();
	}
	function pbnVerReservasCola_clicked() {
		return this.ctx.oficial_pbnVerReservasCola_clicked();
	}
	function verReservas(tabla, codOrden, tejido) {
		return this.ctx.oficial_verReservas(tabla, codOrden, tejido);
	}
	function pbnAnalizar_clicked() {
		return this.ctx.oficial_pbnAnalizar_clicked();
	}
	function pbnAnalizarCon_clicked() {
		return this.ctx.oficial_pbnAnalizarCon_clicked();
	}
	function pbnAnalizarCola_clicked() {
		return this.ctx.oficial_pbnAnalizarCola_clicked();
	}
	function iniciaColores() {
		return this.ctx.oficial_iniciaColores();
	}
	function controlCheckTejido() {
		return this.ctx.oficial_controlCheckTejido();
	}
	function controlCheckTejidoCon() {
		return this.ctx.oficial_controlCheckTejidoCon();
	}
	function controlCheckTejidoCola() {
		return this.ctx.oficial_controlCheckTejidoCola();
	}
	function tbnRestaurarVista_toggled() {
		return this.ctx.oficial_tbnRestaurarVista_toggled();
	}
	function tbnAmpliarADerecha_toggled() {
		return this.ctx.oficial_tbnAmpliarADerecha_toggled();
	}
	function tbnAmpliarAIzquierda_toggled() {
		return this.ctx.oficial_tbnAmpliarAIzquierda_toggled();
	}
	function pbnVerComponentes_clicked() {
		return this.ctx.oficial_pbnVerComponentes_clicked();
	}
	function tbnImpPiezasRoll_clicked() {
		return this.ctx.oficial_tbnImpPiezasRoll_clicked();
	}
	function pbnEncolar_clicked() {
		return this.ctx.oficial_pbnEncolar_clicked();
	}
	function pbnDesEncolar_clicked() {
		return this.ctx.oficial_pbnDesEncolar_clicked();
	}	
	function dameValorSoporteBB(q) {
		return this.ctx.oficial_dameValorSoporteBB(q);
	}
	function damePorcTrex(q, confirmada) {
		return this.ctx.oficial_damePorcTrex(q, confirmada);
	}
	function damePorcCrex(q, confirmada) {
		return this.ctx.oficial_damePorcCrex(q, confirmada);
	}
	function dameBobinaPiezasRoll(codBobina) {
		return this.ctx.oficial_dameBobinaPiezasRoll(codBobina);
	}
	function controlOrdBobMaq(codBobina,codMaquina) {
		return this.ctx.oficial_controlOrdBobMaq(codBobina,codMaquina);
	}
	function encolar(codBobina,codMaquina, ordenCola) {
		return this.ctx.oficial_encolar(codBobina,codMaquina, ordenCola);
	}
	function controlBobMaq(codBobina,codMaquina) {
		return this.ctx.oficial_controlBobMaq(codBobina,codMaquina);
	}
	function desencolar(codBobina, codMaquina) {
		return this.ctx.oficial_desencolar(codBobina, codMaquina);
	}
	function dameOrderByPteConfirmar() {
		return this.ctx.oficial_dameOrderByPteConfirmar();
	}
	function dameOrderByConfirmado() {
		return this.ctx.oficial_dameOrderByConfirmado();
	}
	function dameOrderByCola() {
		return this.ctx.oficial_dameOrderByCola();
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
	function pub_dameMaquinaColaAct() {
		return this.dameMaquinaColaAct();
	}
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}
const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;

	_i.sep_ = "_X_";
	_i.iniciaColores();	
	_i.iniciaTablas();
	_i.cargaCombos();
	connect(this.child("cbFabrica"), "activated(QString)", _i, "cbFabrica_activated");
	connect(this.child("cbSeccion"), "activated(QString)", _i, "cbSeccion_activated");
	connect(this.child("cbMaquina"), "activated(QString)", _i, "cbMaquina_activated");
	connect(this.child("pbnConfirmar"), "clicked()", _i, "pbnConfirmar_clicked");	
	connect(this.child("pbnDesconfirmar"), "clicked()", _i, "pbnDesconfirmar_clicked");
	connect(this.child("pbnParalizar"), "clicked()", _i, "pbnParalizar_clicked");
	connect(this.child("tbnRefrescaCola"), "clicked()", _i, "tbnRefrescaCola_clicked");
	connect(this.child("tbnEnviar"), "clicked()", _i, "tbnEnviar_clicked");
	connect(this.child("tbnInsertar"), "clicked()", _i, "tbnInsertar_clicked");
	connect(this.child("tbnQuitaOrden"), "clicked()", _i, "tbnQuitaOrden_clicked");
	connect(this.child("tbnArriba"), "clicked()", _i, "tbnArriba_clicked");
	connect(this.child("tbnAbajo"), "clicked()", _i, "tbnAbajo_clicked");
	connect(this.child("tbnExcelCola"), "clicked()", _i, "tbnExcelCola_clicked");
	connect(this.child("tbnExcelColaAmp"), "clicked()", _i, "tbnExcelColaAmp_clicked");
	connect(this.child("tbnImprimirCola"), "clicked()", _i, "tbnImprimirCola_clicked");
	connect(this.child("tbnAhora"), "clicked()", _i, "tbnAhora_clicked");

	connect(this.child("tblPteConfirmar"), "doubleClicked(int, int)", _i, "tblPteConfirmar_doubleClicked");
	connect(this.child("tblConfirmado"), "doubleClicked(int, int)", _i, "tblConfirmado_doubleClicked");
	connect(this.child("tblCola"), "doubleClicked(int, int)", _i, "tblCola_doubleClicked");
	connect(this.child("pbnVerReservas"), "clicked()", _i, "pbnVerReservas_clicked");
	connect(this.child("pbnVerReservasCon"), "clicked()", _i, "pbnVerReservasCon_clicked");
	connect(this.child("pbnVerReservasCola"), "clicked()", _i, "pbnVerReservasCola_clicked");

	connect(this.child("pbnAnalizar"), "clicked()", _i, "pbnAnalizar_clicked");
	connect(this.child("pbnAnalizarCon"), "clicked()", _i, "pbnAnalizarCon_clicked");
	connect(this.child("pbnAnalizarCola"), "clicked()", _i, "pbnAnalizarCola_clicked");

	connect(this.child("tbnRestaurarVista"), "toggled(bool)", _i, "tbnRestaurarVista_toggled");
	connect(this.child("tbnAmpliarADerecha"), "toggled(bool)", _i, "tbnAmpliarADerecha_toggled");
	connect(this.child("tbnAmpliarAIzquierda"), "toggled(bool)", _i, "tbnAmpliarAIzquierda_toggled");	
	connect(this.child("pbnVerComponentes"), "clicked()", _i, "pbnVerComponentes_clicked");
	connect(this.child("tbnImpPiezasRoll"), "clicked()", _i, "tbnImpPiezasRoll_clicked");
	connect(this.child("pbnEncolar"), "clicked()", _i, "pbnEncolar_clicked");
	connect(this.child("pbnDesEncolar"), "clicked()", _i, "pbnDesEncolar_clicked");
	this.child("tbnRestaurarVista").setDisabled(true);



	var codMaquina = AQUtil.readSettingEntry("scripts/flprodppal/codMaquinaCol");	
	
	if (codMaquina && codMaquina != "") {
		
		_i.cargaFabricaSeccion(codMaquina);
		_i.asignaMaquina(codMaquina);			
	}	
	_i.analizarPTE_ = false;
	_i.analizarCON_ = false;
	_i.analizarCOLA_= false;

	connect(this.child("chkTejido"), "clicked()", _i, "controlCheckTejido");
	connect(this.child("chkTejidoCon"), "clicked()", _i, "controlCheckTejidoCon");	;
	connect(this.child("chkTejidoCola"), "clicked()", _i, "controlCheckTejidoCola");
	
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_cargaCombos()
{
	var _i = this.iface;
	_i.cargaComboFabrica();
	
	
}

function oficial_cargaComboFabrica()
{
	var _i = this.iface;
	var aFabricas = [];
	
	var q = new AQSqlQuery;
	q.setSelect("codfabrica, descripcion");
	q.setFrom("em_fabricas");
	q.setWhere("1=1");

	if (!q.exec()){	
		return;
	} 
	while(q.next()) {
		aFabricas.push(q.value("codfabrica"));
	}	
	this.child("cbFabrica").clear();
	this.child("cbFabrica").insertStringList(aFabricas);
	_i.cargaComboSeccion();

}

function oficial_cbFabrica_activated()
{
	var _i = this.iface;	
	_i.cargaComboSeccion();	
	_i.refresca();
}

function oficial_cargaComboSeccion()
{
	var _i = this.iface;
	var codFabrica = this.child("cbFabrica").currentText;

	if(!codFabrica || codFabrica == "") {
		return true;
	}

	var aSecciones = [];
	var q = new AQSqlQuery;
	q.setSelect("codseccion, descripcion");
	q.setFrom("em_secciones");
	q.setWhere("codfabrica = '" + codFabrica + "'");

	if (!q.exec()){	
		return;
	} 
	while(q.next()) {
		aSecciones.push(q.value("codseccion"));
	}
	
	this.child("cbSeccion").clear();
	this.child("cbSeccion").insertStringList(aSecciones);
	_i.cargaComboMaquina();
}

function oficial_cbSeccion_activated()
{
	var _i = this.iface;	
	
	_i.cargaComboMaquina();	
	_i.cbMaquina_activated();
	_i.refresca();
}

function oficial_cargaComboMaquina()
{
	var _i = this.iface;
	var aMaquinas = [];

	var codSeccion = this.child("cbSeccion").currentText;
	
	var q = new AQSqlQuery;
	q.setSelect("codmaquinacol, descripcion");
	q.setFrom("em_maquinascol");
	q.setWhere("codseccion='" + codSeccion + "'");

	if (!q.exec()){	
		return;
	} 
	while(q.next()) {
		aMaquinas.push(q.value("codmaquinacol"));
	}

	this.child("cbMaquina").clear();
	this.child("cbMaquina").insertStringList(aMaquinas);	
	if(aMaquinas.length== 0) {
		_i.cargaCacheMaquina();

		_i.codMaquina_ = false;
		_i.tipoProduccion_ = false;			
		_i.filtraCola();
	}
	_i.cbMaquina_activated();
	
}

function oficial_cbMaquina_activated()
{
	var _i = this.iface;

	var codMaquina = this.child("cbMaquina").currentText;
	if (!codMaquina) {		
		_i.cargaCacheMaquina();
		_i.codMaquina_ = false;
		_i.tipoProduccion_ = false;			
		_i.filtraCola();
	} else {
		_i.asignaMaquina(codMaquina);
	}
	_i.refresca();

}

function oficial_iniciaTablas()
{
	var _i = this.iface;

	_i.iniciaTablaPteConfirmar();
	_i.iniciaTablaConfirmado();
	_i.iniciaTablaCola();
	_i.iniciaTablaMaquina();
	_i.iniciaTablaSeccion();
	_i.curOrden_ = new FLSqlCursor("pr_ordenesproduccion");

}

function oficial_iniciaTablaPteConfirmar()
{
	var _i = this.iface;
	
	_i.tblPteConfirmar_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblPteConfirmar"));	
	_i.tblPteConfirmar_.setColorFunction("formem_colaproduccion.iface.colorPendiente");
	_i.tblPteConfirmar_.setFormatFunction("formem_colaproduccion.iface.formateaPteConfirmar");

	var q = new AQSqlQuery;	
	
	q.setSelect("pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.codpreparamat, pr_ordenesproduccion.codorden, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.totaluds, pr_ordenesproduccion.totalmetros, pr_ordenesproduccion.em_porctrex, pr_ordenesproduccion.em_porccrex, pr_ordenesproduccion.em_codgruposeccion,pr_ordenesproduccion.em_acabados, pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.em_alias,pr_ordenesproduccion.em_gramaje, pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.codsubfamilia,pr_ordenesproduccion.em_anchotejido,pr_ordenesproduccion.em_anverso, pr_ordenesproduccion.em_reverso, pr_ordenesproduccion.em_colordibujo,   pr_ordenesproduccion.em_colorreverso, pr_ordenesproduccion.em_paralizada,pr_ordenesproduccion.fecha, pr_ordenesproduccion.codpedidocli,pr_ordenesproduccion.em_motivopara, pr_tareas.estado");
	q.setFrom("pr_ordenesproduccion LEFT OUTER JOIN pr_tareas ON pr_tareas.idobjeto = pr_ordenesproduccion.codorden and pr_tareas.idtipotarea = 'PT' AND pr_tareas.estado ='TERMINADA'");
	q.setWhere(_i.dameFiltroPteConfirmar());
	q.setOrderBy(_i.dameOrderByPteConfirmar());
	
	_i.tblPteConfirmar_.setQuery(q);	
	




	var cHPTE = [];
	var c = 0;	

	cHPTE[c++] = "Descripci�n";
	cHPTE[c++] = "Dibujo anverso";
	cHPTE[c++] = "Soporte / BB";
	cHPTE[c++] = "N. de Orden";
	cHPTE[c++] = "F.Entrega";
	cHPTE[c++] = "Unidades";
	cHPTE[c++] = "Metros";
	var colTrex = c;
	cHPTE[c++] = "%TR.EX.";
	var colCrex = c;
	cHPTE[c++] = "%CR.EX.";


	cHPTE[c++] = "Agrupaci�n";	
	cHPTE[c++] = "Acabados";
	cHPTE[c++] = "Subfamilia";
	cHPTE[c++] = "Alias";
	cHPTE[c++] = "Gramaje";
	//cHPTE[c++] = "F.Fin.Prev.";  //nuevo
	//cHPTE[c++] = "H.Fin.Prev.";  //nuevo
	cHPTE[c++] = "Modo operaci�n";
	cHPTE[c++] = "Cod.Subfam.";
	cHPTE[c++] = "Ancho tejido";
	cHPTE[c++] = "Anverso";
	cHPTE[c++] = "Reverso";
	cHPTE[c++] = "Color dibujo";	
	cHPTE[c++] = "Color Reverso";	
	cHPTE[c++] = "Paralizada";
	var colFecha = c;
	cHPTE[c++] = "Fecha";
	var colPedidoCli = c;
	cHPTE[c++] = "Pedido Cli.";
	cHPTE[c++] = "M.Paraliza";
	var colEstadoPT = c;
	cHPTE[c++] = "Estado PT";
	var cHCOL = [];
	var c = 0;

	this.child("tblPteConfirmar").hideColumn(colFecha);
	this.child("tblPteConfirmar").hideColumn(colPedidoCli);
	this.child("tblPteConfirmar").hideColumn(colEstadoPT);
	this.child("tblPteConfirmar").showColumn(colTrex);
	this.child("tblPteConfirmar").showColumn(colCrex);
	
	this.child("tblPteConfirmar").setColumnLabels("*", cHPTE.join("*"));	

	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.emobservaciones", 140);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.codorden", 80);	
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.fechaentrega", 73);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.totaluds", 60);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.totalmetros", 60);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_codmodooper", 140);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.codsubfamilia", 70);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.subfamilia", 178);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_paralizada", 50);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_acabados", 120);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_alias", 100);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_anverso", 60);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_reverso", 60);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_colordibujo", 80);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_anchotejido", 60);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_colorreverso", 120);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.em_gramaje", 60);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.dibujo", 150);
	_i.tblPteConfirmar_.setColumnWidth("pr_ordenesproduccion.codpreparamat", 150);
	
	this.child("tblPteConfirmar").showColumn(19);	
}

function oficial_formateaPteConfirmar(f, c, v)
{
	var _i = this.iface;
	var nombreCol = _i.tblPteConfirmar_.nombreCol(c);
	var q = _i.tblPteConfirmar_.query();
	var valor;
	switch(nombreCol) {
		case "pr_ordenesproduccion.emobservaciones" : {			
			valor = _i.dameDescripcionOrden(q);
			break;
		}		
		case "pr_ordenesproduccion.codpreparamat" : {
			valor = _i.dameValorSoporteBB(q);
			break;
		}	
		case "pr_ordenesproduccion.em_porctrex": {
			valor = _i.damePorcTrex(q, false);
			break;
		}
		case "pr_ordenesproduccion.em_porccrex": {
			valor = _i.damePorcCrex(q, false);
			break;
		}
		default: {			
			valor = _i.tblPteConfirmar_.formateaValor(v, c);
		}	
	}
	return valor;
}

function oficial_dimeGrupoSeccion(grupo)
{
	if(grupo && grupo != "") {		
		grupo = AQUtil.sqlSelect("em_gruposordenseccion","COALESCE(em_codseccion, codsubfamilia)","em_codgruposeccion = " + grupo);
	}	
	return grupo;
}

function oficial_dameFiltroPteConfirmar()
{
	var _i = this.iface;		
	var codSeccion = this.child("cbSeccion").currentText;	
	var filtro = "1=2";
	if(codSeccion && codSeccion != "") {
		filtro = "(pr_ordenesproduccion.estado IN ('PTE','EN CURSO')) AND NOT pr_ordenesproduccion.em_confirmada AND (pr_ordenesproduccion.codfamilia IN (SELECT codfamilia FROM familias WHERE em_codseccion = '" + codSeccion + "') OR pr_ordenesproduccion.codsubfamilia IN (SELECT codsubfamilia FROM subfamilias WHERE em_codseccion = '" + codSeccion + "'))";
	}

	return filtro;
}

function oficial_filtraPteConfirmar()
{
	var _i = this.iface;
	_i.tblPteConfirmar_.setFilter(_i.dameFiltroPteConfirmar(),true);
}

function oficial_iniciaTablaConfirmado()
{
	var _i = this.iface;	

	_i.tblConfirmado_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblConfirmado"));
	_i.tblConfirmado_.setColorFunction("formem_colaproduccion.iface.colorConfirmado");
	_i.tblConfirmado_.setFormatFunction("formem_colaproduccion.iface.formateaConfirmado");

	var q = new AQSqlQuery;	

	q.setSelect("pr_ordenesproduccion.emobservaciones, pr_ordenesproduccion.dibujo,  pr_ordenesproduccion.codpreparamat,pr_ordenesproduccion.codorden, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.totaluds, pr_ordenesproduccion.totalmetros, pr_ordenesproduccion.em_porctrex, pr_ordenesproduccion.em_porccrex, pr_ordenesproduccion.em_codgruposeccion,pr_ordenesproduccion.em_acabados, pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.em_alias,pr_ordenesproduccion.em_gramaje, pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.codsubfamilia,pr_ordenesproduccion.em_anchotejido,pr_ordenesproduccion.em_anverso, pr_ordenesproduccion.em_reverso, pr_ordenesproduccion.em_colordibujo, pr_ordenesproduccion.em_colorreverso, pr_ordenesproduccion.em_paralizada,pr_ordenesproduccion.fecha, pr_ordenesproduccion.codpedidocli,pr_ordenesproduccion.em_motivopara, pr_tareas.estado");
	q.setFrom("pr_ordenesproduccion LEFT OUTER JOIN pr_tareas ON pr_tareas.idobjeto = pr_ordenesproduccion.codorden and pr_tareas.idtipotarea = 'PT' AND pr_tareas.estado ='TERMINADA'");
	q.setWhere(_i.dameFiltroConfirmado());
	q.setOrderBy(_i.dameOrderByConfirmado());
	_i.tblConfirmado_.setQuery(q);


	var cHCON = [];
	var c = 0;
	
	cHCON[c++] = "Descripci�n";
	cHCON[c++] = "Dibujo anverso";	
	cHCON[c++] = "Soporte / BB";
	cHCON[c++] = "N. de Orden";
	cHCON[c++] = "F.Entrega";
	cHCON[c++] = "Unidades";
	cHCON[c++] = "Metros";
	var colTrex = c;
	cHCON[c++] = "%TR.EX.";
	var colCrex = c;
	cHCON[c++] = "%CR.EX.";
	cHCON[c++] = "Agrupaci�n";
	cHCON[c++] = "Acabados";
	cHCON[c++] = "Subfamilia";
	cHCON[c++] = "Alias";
	cHCON[c++] = "Gramaje";
	cHCON[c++] = "Modo operaci�n";
	cHCON[c++] = "Cod.Subfam.";
	cHCON[c++] = "Ancho tejido";
	cHCON[c++] = "Anverso";
	cHCON[c++] = "Reverso";
	cHCON[c++] = "Color dibujo";	
	cHCON[c++] = "Color Reverso";		
	cHCON[c++] = "Paralizada";	
	var colFecha = c;
	cHCON[c++] = "Fecha";
	var colPedidoCli = c;
	cHCON[c++] = "Pedido Cli.";
	cHCON[c++] = "M.Paraliza";
	var colEstadoPT = c;
	cHCON[c++] = "Estado PT";

	this.child("tblConfirmado").hideColumn(colFecha);
	this.child("tblConfirmado").hideColumn(colPedidoCli);
	this.child("tblConfirmado").showColumn(colTrex);
	this.child("tblConfirmado").showColumn(colCrex);
	this.child("tblConfirmado").hideColumn(colEstadoPT);
	this.child("tblConfirmado").setColumnLabels("*", cHCON.join("*"));	

	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.emobservaciones", 140);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.codorden", 80);	
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.fechaentrega", 73);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.totaluds", 37);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.totalmetros", 58);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_codmodooper", 140);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.codsubfamilia", 70);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.subfamilia", 178);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.nombreconfeccionista", 100);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_acabados", 120);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_alias", 100);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_anverso", 60);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_reverso", 60);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_colordibujo", 80);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_anchotejido", 60);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_colorreverso", 120);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_gramaje", 60);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.em_paralizada", 50);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.dibujo", 150);
	_i.tblConfirmado_.setColumnWidth("pr_ordenesproduccion.codpreparamat", 150);
	
	this.child("tblConfirmado").showColumn(19);	
	//this.child("tblConfirmado").hideColumn(8);
	_i.tblConfirmado_.refresh();
	
}

function oficial_formateaConfirmado(f, c, v)
{
	var _i = this.iface;
	var nombreCol = _i.tblConfirmado_.nombreCol(c);
	var q = _i.tblConfirmado_.query();
	var valor;
	switch(nombreCol) {
		case "pr_ordenesproduccion.emobservaciones" : {
			valor = _i.dameDescripcionOrden(q);
			break;
		}	
		case "pr_ordenesproduccion.codpreparamat" : {
			valor = _i.dameValorSoporteBB(q);
			break;
		}	
		case "pr_ordenesproduccion.em_porctrex": {
			valor = _i.damePorcTrex(q, true);
			break;
		}
		case "pr_ordenesproduccion.em_porccrex": {
			valor = _i.damePorcCrex(q, true);
			break;
		}	
		default: {			
			valor = _i.tblConfirmado_.formateaValor(v, c);
		}	
	}
	return valor;
}

function oficial_dameFiltroConfirmado()
{
	var _i = this.iface;		
	var codSeccion = this.child("cbSeccion").currentText;	
	var filtro = "1=2";
	if(codSeccion && codSeccion != "") {
		filtro = "(pr_ordenesproduccion.estado IN ('PTE','EN CURSO')) AND pr_ordenesproduccion.em_confirmada AND (pr_ordenesproduccion.codfamilia IN (SELECT codfamilia FROM familias WHERE em_codseccion = '" + codSeccion + "') OR pr_ordenesproduccion.codsubfamilia IN (SELECT codsubfamilia FROM subfamilias WHERE em_codseccion = '" + codSeccion + "') AND (pr_ordenesproduccion.em_codmaquinacol is null or pr_ordenesproduccion.em_codmaquinacol =''))";
	}

	return filtro;
}

function oficial_filtraConfirmado()
{
	var _i = this.iface;
	_i.tblConfirmado_.setFilter(_i.dameFiltroConfirmado() ,true);
}

function oficial_pbnConfirmar_clicked()
{
	var _i=this.iface;



	var dialog = new Dialog;
	dialog.caption = "Confirmar";
	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione:");
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );	
	
	if(!dialog.exec() ) {
		return;
	}
	if (botonG.checked) {
		var codGrupo = _i.tblPteConfirmar_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		if (!codGrupo) {
			return false;
		}
		if (!AQSql.update("pr_ordenesproduccion", ["em_confirmada"], [true], _i.dameFiltroPteConfirmar() + " AND ( em_codgruposeccion = '" + codGrupo + "')")) {
			return false;
		}		
			
	} else {
		var codOrden = _i.tblPteConfirmar_.columnValue("pr_ordenesproduccion.codorden");
		if (!codOrden) {
			return false;
		}
		if (!AQSql.update("pr_ordenesproduccion", ["em_confirmada"], [true], "codorden = '" + codOrden + "'")) {
			return false;
		}
	}

	_i.refresca();

}

function oficial_pbnDesconfirmar_clicked()
{
	var _i=this.iface;



	var dialog = new Dialog;
	dialog.caption = "Desconfirmar";
	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione:");
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );	
	
	if(!dialog.exec() ) {
		return;
	}
	if (botonG.checked) {
		var codGrupo = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		if (!codGrupo) {
			return false;
		}
		if (!AQSql.update("pr_ordenesproduccion", ["em_confirmada"], [false], _i.dameFiltroConfirmado() + " AND ( em_codgruposeccion = '" + codGrupo + "')")) {
			return false;
		}		
			
	} else {
		var codOrden = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.codorden");
		if (!codOrden) {
			return false;
		}
		if (!AQSql.update("pr_ordenesproduccion", ["em_confirmada"], [false], "codorden = '" + codOrden + "'")) {
			return false;
		}
	}

	_i.refresca();

}

function oficial_pbnParalizar_clicked()
{
	var _i=this.iface;

	var paralizada= _i.tblPteConfirmar_.columnValue("pr_ordenesproduccion.em_paralizada");

	var paralizar = true;
	var dialog = new Dialog;
	var caption;
	if(paralizada == 'N') {
		caption = "Paralizar";
	}else {			
		caption = "Desparalizar";
		paralizar = false;
	}
	dialog.caption = caption;

	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione para %1:").arg(caption);
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );

	var motivoPara = "";
	var motivo;
	if(paralizar) {

		motivo = new LineEdit;	
		motivo.label = sys.translate("Motivo paralizaci�n:");
		motivo.text = "";
		dialog.add(motivo);			
	} 
	
	if(!dialog.exec() ) {
		return;
	}
	if(paralizar) {
		
		motivoPara = motivo.text;
	}

	if(!motivoPara) {
		
		motivoPara = null;
	} else {
		motivoPara = "'" + motivoPara + "'";
		
	}

	var where = "";

	if (botonG.checked) {
		var codGrupo = _i.tblPteConfirmar_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		if (!codGrupo) {
			return false;
		}
		where = _i.dameFiltroPteConfirmar() + " AND ( em_codgruposeccion = '" + codGrupo + "')";	
			
	} else {
		var codOrden = _i.tblPteConfirmar_.columnValue("pr_ordenesproduccion.codorden");
		if (!codOrden) {
			return false;
		}
		where = "codorden = '" + codOrden + "'";	
	}

	if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_paralizada = " + paralizar + ", em_motivopara = " + motivoPara + " WHERE " +  where )) {
  		return false;
  	}	

	_i.refresca();

}

function oficial_iniciaTablaCola()
{

	var _i = this.iface;	
	_i.tblCola_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblCola"));
	_i.tblCola_.setColorFunction("formem_colaproduccion.iface.colorCola");
	_i.tblCola_.setFormatFunction("formem_colaproduccion.iface.formateaCola");

	var q = new AQSqlQuery;	
	q.setSelect("pr_ordenesproduccion.em_ordenprod, pr_ordenesproduccion.emobservaciones,pr_ordenesproduccion.dibujo, pr_ordenesproduccion.codpreparamat, pr_ordenesproduccion.codorden, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.udsptes, pr_ordenesproduccion.metrosptes, pr_ordenesproduccion.em_porctrex, pr_ordenesproduccion.em_porccrex,  pr_ordenesproduccion.em_codgruposeccion,pr_ordenesproduccion.em_acabados,pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.em_alias, pr_ordenesproduccion.em_gramaje, pr_ordenesproduccion.em_fechafinprev, pr_ordenesproduccion.em_horafinprev, pr_ordenesproduccion.em_codmodooper, pr_ordenesproduccion.codsubfamilia, pr_ordenesproduccion.em_anchotejido, pr_ordenesproduccion.em_retardoacu,pr_ordenesproduccion.em_retardototal,pr_ordenesproduccion.em_retardoacabado,pr_ordenesproduccion.em_retardotipotejido,pr_ordenesproduccion.em_retardoanverso,		pr_ordenesproduccion.em_retardoreverso,pr_ordenesproduccion.em_anverso, pr_ordenesproduccion.em_reverso, pr_ordenesproduccion.em_colordibujo, pr_ordenesproduccion.em_colorreverso,pr_ordenesproduccion.em_horasdia,pr_ordenesproduccion.em_horasbrutascola,pr_ordenesproduccion.fecha,pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.em_paralizada,pr_ordenesproduccion.em_motivopara, pr_tareas.estado");
	q.setFrom("pr_ordenesproduccion LEFT OUTER JOIN pr_tareas ON pr_tareas.idobjeto = pr_ordenesproduccion.codorden and pr_tareas.idtipotarea = 'PT' AND pr_tareas.estado ='TERMINADA'");
	q.setWhere(_i.dameFiltroCola());
	q.setOrderBy(_i.dameOrderByCola());
	_i.tblCola_.setQuery(q);

	var cHCOL = [];
	var c = 0;

	cHCOL[c++] = "Orden";
	cHCOL[c++] = "Descripci�n";
	cHCOL[c++] = "Dibujo anverso";
	cHCOL[c++] = "Soporte / BB";
	cHCOL[c++] = "N. de Orden";
	cHCOL[c++] = "F.Entrega";
	cHCOL[c++] = "Uds.Ptes.";
	cHCOL[c++] = "Mtrs.Ptes.";
	var colTrex = c;
	cHCOL[c++] = "%TR.EX.";
	var colCrex = c;
	cHCOL[c++] = "%CR.EX.";
	cHCOL[c++] = "Agrupaci�n";
	cHCOL[c++] = "Acabados";
	cHCOL[c++] = "Subfamilia";
	cHCOL[c++] = "Alias";
	cHCOL[c++] = "Gramaje";
	cHCOL[c++] = "F.Fin.Prev.";
	cHCOL[c++] = "H.Fin.Prev.";
	cHCOL[c++] = "Modo operaci�n";
	cHCOL[c++] = "Cod.Subfam.";	
	cHCOL[c++] = "Ancho tejido";
	cHCOL[c++] = "Retardo acumulado";
	cHCOL[c++] = "Retardo total";	
	cHCOL[c++] = "Retardo acabado";
	cHCOL[c++] = "Retardo tipo tejido";
	cHCOL[c++] = "Retardo anverso";
	cHCOL[c++] = "Retardo reverso";
	cHCOL[c++] = "Anverso";
	cHCOL[c++] = "Reverso";
	cHCOL[c++] = "Color dibujo";	
	cHCOL[c++] = "Color Reverso";	
	cHCOL[c++] = "Horas dia";
	cHCOL[c++] = "Hr.Brutas";	
	

	var colFecha = c;
	cHCOL[c++] = "Fecha";
	var colPedidoCli = c;
	cHCOL[c++] = "Pedido Cli.";
	cHCOL[c++] = "Paralizada";
	cHCOL[c++] = "M.Paraliza";
	var colEstadoPT = c;
	cHCOL[c++] = "Estado PT";

	this.child("tblCola").hideColumn(colFecha);
	this.child("tblCola").hideColumn(colPedidoCli);
	this.child("tblCola").showColumn(colTrex);
	this.child("tblCola").showColumn(colCrex);
	this.child("tblCola").hideColumn(colEstadoPT);
	
	this.child("tblCola").setColumnLabels("*", cHCOL.join("*"));	

	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.emobservaciones", 140);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_ordenprod", 45);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.codorden", 80);	
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.fechaentrega", 75);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.udsptes", 60);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.metrosptes", 60);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_codmodooper", 140);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.codsubfamilia", 70);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.subfamilia", 178);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.nombreconfeccionista", 100);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_fechafinprev", 75);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_horasbrutas", 80);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_acabados", 120);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_retardototal", 100);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_retardoacu", 80);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_alias", 100);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_anverso", 60);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_reverso", 60);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_colordibujo", 80);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_anchotejido", 60);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_colorreverso", 120);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_gramaje", 60);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.dibujo", 150);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.em_paralizada", 50);
	_i.tblCola_.setColumnWidth("pr_ordenesproduccion.codpreparamat", 150);

	this.child("tblCola").showColumn(9);	
	this.child("tblCola").showColumn(28);
	_i.tblCola_.refresh();
   
	return true;
}

function oficial_concatenaValorSiExiste(valor, vCon, sep)
{
	var v = valor;
	if (vCon && vCon != "") {
		if (valor && valor != "") {
			v += sep;
		}
		v += vCon;
	}
	return v;
}

function oficial_formateaCola(f, c, v)
{
	var _i = this.iface;
	var nombreCol = _i.tblCola_.nombreCol(c);
	var q = _i.tblCola_.query();
	var valor;
	switch(nombreCol) {
		case "pr_ordenesproduccion.emobservaciones" : {			
			valor = _i.dameDescripcionOrden(q);
			break;
		}
		case "pr_ordenesproduccion.em_retardototal":
		case "pr_ordenesproduccion.em_retardoacu": {
			valor = formem_colaestampacion.iface.formatearTiempo(v);
			break;
		}
		case "pr_ordenesproduccion.codpreparamat" : {
			valor = _i.dameValorSoporteBB(q);
			break;
		}
		case "pr_ordenesproduccion.em_porctrex": {
			valor = _i.damePorcTrex(q, true);
			break;
		}
		case "pr_ordenesproduccion.em_porccrex": {
			valor = _i.damePorcCrex(q, true);
			break;
		}	
		default: {			
			valor = _i.tblCola_.formateaValor(v, c);
		}	
	}
	return valor;
}

function oficial_dameDescripcionOrden(q)
{
	var _i = this.iface;

	var valor = "";
	valor = _i.concatenaValorSiExiste(valor,  _i.dameDiaMes(q.value("pr_ordenesproduccion.fecha")), " ");
	valor = _i.concatenaValorSiExiste(valor, q.value("pr_ordenesproduccion.emobservaciones"), " ");
	valor = _i.concatenaValorSiExiste(valor, q.value("pr_ordenesproduccion.codpedidocli"), " ");
	valor = _i.concatenaValorSiExiste(valor, _i.dameDiaMes(q.value("pr_ordenesproduccion.fechaentrega")), " ");

	return valor;
}

function oficial_dameDiaMes(fecha)
{
	var fechaDM = "";
	if (fecha && fecha !="") {
		fecha = fecha.toString().left(10);
		fechaDM = fecha.toString().right(2) + "/" + fecha.toString().right(5).left(2);
	}
	return fechaDM;
}

function oficial_dameFiltroCola(codMaquina)
{
	var _i = this.iface;		
	var filtro = "1=2";
	var maquinaFiltro = _i.codMaquina_;
	if(codMaquina &&  codMaquina != "") {
		maquinaFiltro = codMaquina;
	}
	if(maquinaFiltro && maquinaFiltro != "") {
		filtro = "((pr_ordenesproduccion.estado IN ('PTE','EN CURSO')) OR (pr_ordenesproduccion.codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE'))) AND pr_ordenesproduccion.em_confirmada AND (pr_ordenesproduccion.em_codmaquinacol= '" + maquinaFiltro + "')";
	} else {
		filtro = "1=2";
	}
	return filtro;
}

function oficial_filtraCola()
{
	var _i = this.iface;
	_i.tblCola_.setFilter(_i.dameFiltroCola() ,true);
}

function oficial_iniciaTablaMaquina()
{
	var _i = this.iface;	
	
	/***********************   RESUMEN 	MAQUINAS    **********************************/
		
	var cMaq = 0, cHMAQ = [];

	_i.cMAQ_ = cMaq++;
	_i.cPMC_ = cMaq++;
	_i.cMMC_ = cMaq++;	
	_i.cFIMC_ = cMaq++;  
	_i.cFFMC_ = cMaq++;
	

	cHMAQ[_i.cMAQ_] = AQUtil.translate("scripts", "M�quina");
	cHMAQ[_i.cPMC_] = AQUtil.translate("scripts", "Prendas");
	cHMAQ[_i.cMMC_] = AQUtil.translate("scripts", "Metros");	
	cHMAQ[_i.cFIMC_] = AQUtil.translate("scripts", "F.Inicio cola");
	cHMAQ[_i.cFFMC_] = AQUtil.translate("scripts", "F.Fin prevista");

	var tResumMaq = this.child("tblResumMaq");
	tResumMaq.setNumCols(cMaq);
	tResumMaq.setColumnWidth(_i.cMAQ_, 70);
	tResumMaq.setColumnWidth(_i.cMMC_, 80);
	tResumMaq.setColumnWidth(_i.cPMC_, 80);
	tResumMaq.setColumnWidth(_i.cFIMC_, 130);
	tResumMaq.setColumnWidth(_i.cFFMC_, 130);

	tResumMaq.setColumnLabels("*", cHMAQ.join("*"));	
	
	_i.cargaDatosMaq();
}

function oficial_iniciaTablaSeccion()
{
	var _i = this.iface;
	var cSec = 0, cHSECC = [];

	_i.cSEC_ = cSec++;
	_i.cPSC_ = cSec++;
	_i.cMSC_ = cSec++;	
	_i.cFISC_ = cSec++;  
	_i.cFFSC_ = cSec++;

	cHSECC[_i.cSEC_] = AQUtil.translate("scripts", "Secci�n");
	cHSECC[_i.cPSC_] = AQUtil.translate("scripts", "Prendas");
	cHSECC[_i.cMSC_] = AQUtil.translate("scripts", "Metros");	
	cHSECC[_i.cFISC_] = AQUtil.translate("scripts", "F.Inicio cola");
	cHSECC[_i.cFFSC_] = AQUtil.translate("scripts", "F.Fin prevista");

	var tResSec = this.child("tblResumSec");
	tResSec.setNumCols(cSec);
	tResSec.setColumnWidth(_i.cSEC_, 70);
	tResSec.setColumnWidth(_i.cPSC_, 80);
	tResSec.setColumnWidth(_i.cMSC_, 80);
	tResSec.setColumnWidth(_i.cFISC_, 130);
	tResSec.setColumnWidth(_i.cFFSC_, 130);

	tResSec.setColumnLabels("*", cHSECC.join("*"));
	
	_i.cargaDatosSec();

}

function oficial_tbnRefrescaCola_clicked()
{
	var _i = this.iface;

	var codMaquina = this.child("cbMaquina").currentText
	
	_i.asignaMaquina(codMaquina);
	_i.refresca();
}

function oficial_refresca()
{
	var _i = this.iface;
	_i.filtraPteConfirmar();
	_i.filtraConfirmado();
	_i.filtraCola();
}

function oficial_tbnEnviar_clicked()
{
	var _i = this.iface;
	var codOrden = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden de producci�n seleccionada"));
		return;
	}
	var paralizada = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.em_paralizada");

	if(paralizada == 'S') {
		sys.warnMsgBox(sys.translate("La orden est� paralizada. No puede introducirla a la cola."));
		return;
	}


	if (!_i.codMaquina_) {
		sys.warnMsgBox(sys.translate("No hay una m�quina seleccionada"));
		return;
	}	

	var maxOrden = AQUtil.sqlSelect("pr_ordenesproduccion", "em_ordenprod", _i.dameFiltroCola() + " ORDER BY em_ordenprod DESC");
	maxOrden = isNaN(maxOrden) ? 0 : maxOrden;


	var dialog = new Dialog;
	dialog.caption = "Confirmar";
	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione:");
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );	

	var codBobinaPz = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.codpreparamat");

	var botonPZ = new RadioButton;
	botonPZ.text = "Soporte/BB";
	botonPZ.checked = false;
	var aLista = [];
	var cboBobinas = new ComboBox;
	//var gB = new GroupBox;
	if(codBobinaPz && codBobinaPz != "") {
		grupo.add( botonPZ );
		//gB.title = sys.translate("   Soporte/BB:");
		//dialog.add(gB);
		//var codBobina = new ComboBox;
		cboBobinas.label = sys.translate("      Soporte/BB");
		cboBobinas.editable = false;

		aLista = codBobinaPz.split(",");

		cboBobinas.itemList = aLista;
      	grupo.add(cboBobinas);
	}

	if(!dialog.exec() ) {
		return;
	}
	if (botonG.checked) {

		var codGrupo = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		if (!codGrupo) {
			return false;
		}			

		var qEnv = new AQSqlQuery;
		qEnv.setSelect("em_codmodooper,metrosptes,udsptes, codorden");
		qEnv.setFrom("pr_ordenesproduccion");
		qEnv.setWhere(_i.dameFiltroConfirmado() + " AND em_codgruposeccion = '" + codGrupo + "' ORDER BY codorden");
		if (!qEnv.exec()) {
			return false;
		}
		//var o = 0, minprev, ms; pozu
		var o = 1;
		while (qEnv.next()) {		

			maxOrden++;

			var codModoOper = qEnv.value("em_codmodooper");
			var metrosPtes = qEnv.value("metrosptes");
			var prendasPtes = qEnv.value("udsptes");
			var codOrden = qEnv.value("codorden");

			var cantidadPte;

			if(_i.tipoProduccion_ == "Prendas") {
				cantidadPte = prendasPtes;
			} else {
				cantidadPte = metrosPtes;
			}

			var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);	
			

			if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, maxOrden, minEstimados], "codorden = '" + codOrden + "'")) {
				return false;
			}	
	
		}
			
	} else if(botonO.checked){

		maxOrden++;
		var codModoOper = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.em_codmodooper");
		var metrosPtes = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.metrosptes");
		var prendasPtes = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.udsptes");

		var cantidadPte;

		if(_i.tipoProduccion_ == "Prendas") {
			cantidadPte = prendasPtes;
		} else {
			cantidadPte = metrosPtes;
		}

		var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);	
		
		if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, maxOrden, minEstimados], "codorden = '" + codOrden + "'")) {
			return false;
		}		

	} else {
		
		var codBobinaSop = cboBobinas.currentItem;
		debug("codBobinaSop: "+codBobinaSop);

		var res = formUI.preguntaMsg(sys.translate("Ha elegido encolar las OPs no encoladas del soporte/bobina %1 en la m�quina %2 de la secci�n %3. �Es correcto?").arg(codBobinaSop).arg(_i.codMaquina_).arg(this.child("cbSeccion").currentText), "info", this, MessageBox.Yes, MessageBox.No);
		if(res != MessageBox.Yes) {
			return false;
		}

		var aBobina = codBobinaSop.split("/");
		var codBobina = aBobina[aBobina.length-1];	
		debug("codBobina: "+codBobina);
		if(!codBobina) {
			codBobina = "";
		}
		var numRows = this.child("tblCola").numRows();
		var ordenCola = _i.tblCola_.cellValue(numRows-1,"pr_ordenesproduccion.em_ordenprod");
		debug("ordenCola: "+ordenCola);
		if(!ordenCola) {
			ordenCola = 0;
		}
		if(!_i.encolar(codBobina,_i.codMaquina_,ordenCola+1)) {
			return false;
		}
	}
	
	_i.recalculaOrdenCola();	
	_i.recalculaPrevision();
	_i.calculaTiemposCola();	
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec(); 	
	_i.refresca();	
	var numRows = this.child("tblCola").numRows();	
	this.child("tblCola").selectRow(numRows-1);

}

function oficial_tbnInsertar_clicked()
{
	var _i = this.iface;	
	var codOrden = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden de producci�n seleccionada"));
		return;
	}
	var paralizada = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.em_paralizada");

	if(paralizada == 'S') {
		sys.warnMsgBox(sys.translate("La orden est� paralizada. No puede introducirla a la cola."));
		return;
	}


	var codOrdenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrdenCola) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden de cola de producci�n seleccionada"));
		return;
	}
	if (!_i.codMaquina_) {
		sys.warnMsgBox(sys.translate("No hay una m�quina de producci�n seleccionada"));
		return;
	}

	var fila = this.child("tblCola").currentRow();
	var ordenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.em_ordenprod");
	
	
	/*-----------------------------Dialog--------------------------------------------*/
	var dialog = new Dialog;
	dialog.caption = "Confirmar";
	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione:");
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );


	var codBobinaPz = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.codpreparamat");

	var botonPZ = new RadioButton;
	botonPZ.text = "Soporte/BB";
	botonPZ.checked = false;
	var aLista = [];
	var cboBobinas = new ComboBox;
	
	if(codBobinaPz && codBobinaPz != "") {
		grupo.add( botonPZ );	
		cboBobinas.label = sys.translate("      Soporte/BB");
		cboBobinas.editable = false;
		aLista = codBobinaPz.split(",");
		cboBobinas.itemList = aLista;
      	grupo.add(cboBobinas);
	}
	if(!dialog.exec() ) {
		return;
	}
	/*--------------------------------------------------------------------------------------*/
	/*-----------------------------------Elige boton-------------------------------------------*/
	if (botonG.checked) {
		//boton grupo
		var codGrupo = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		if (!codGrupo) {
			return false;
		}			

		var qEnv = new AQSqlQuery;
		qEnv.setSelect("em_codmodooper,metrosptes,udsptes, codorden");
		qEnv.setFrom("pr_ordenesproduccion");
		qEnv.setWhere(_i.dameFiltroConfirmado() + " AND em_codgruposeccion = '" + codGrupo + "' ORDER BY codorden");
		if (!qEnv.exec()) {
			return false;
		}
		//var o = 0, minprev, ms; pozu
		var o = 1;
		while (qEnv.next()) {		
			if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = em_ordenprod + 1 WHERE " + _i.dameFiltroCola() + " AND em_ordenprod >= " + ordenCola)) {
			return false;
			}
			var codModoOper = qEnv.value("em_codmodooper");
			var metrosPtes = qEnv.value("metrosptes");
			var prendasPtes = qEnv.value("udsptes");
			var codOrden = qEnv.value("codorden");

			var cantidadPte;

			if(_i.tipoProduccion_ == "Prendas") {
				cantidadPte = prendasPtes;
			} else {
				cantidadPte = metrosPtes;
			}

			var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);	
			if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, ordenCola, minEstimados], "codorden = '" + codOrden + "'")) {
				return false;
			}		
			//ordenCola++;

		}	
	}  else if(botonO.checked){
		//boton orden seleccionada
		if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = em_ordenprod + 1 WHERE " + _i.dameFiltroCola() + " AND em_ordenprod >= " + ordenCola)) {
			return false;
		}
		var codModoOper = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.em_codmodooper");
		var metrosPtes = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.metrosptes");
		var prendasPtes = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.udsptes");

		var cantidadPte;

		if(_i.tipoProduccion_ == "Prendas") {
			cantidadPte = prendasPtes;
		} else {
			cantidadPte = metrosPtes;
		}

		var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);

		
		if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, ordenCola, minEstimados], "codorden = '" + codOrden + "'")) {
			return false;
		}		

	} else {

		var codBobinaSop = cboBobinas.currentItem;
		debug("codBobinaSop: "+codBobinaSop);

		var res = formUI.preguntaMsg(sys.translate("Ha elegido encolar las OPs no encoladas del soporte/bobina %1 en la m�quina %2 de la secci�n %3. �Es correcto?").arg(codBobinaSop).arg(_i.codMaquina_).arg(this.child("cbSeccion").currentText), "info", this, MessageBox.Yes, MessageBox.No);
		if(res != MessageBox.Yes) {
			return false;
		}

		var aBobina = codBobinaSop.split("/");
		var codBobina = aBobina[aBobina.length-1];	
		debug("codBobina: "+codBobina);
		if(!codBobina) {
			codBobina = "";
		}
		var numRows = this.child("tblCola").numRows();
		//var ordenCola = _i.tblCola_.cellValue(numRows-1,"pr_ordenesproduccion.em_ordenprod");
		debug("ordenCola: "+ordenCola);
		if(!ordenCola) {
			ordenCola = 0;
		}
		if(!_i.encolar(codBobina,_i.codMaquina_,ordenCola)) {
			return false;
		}

	}
	/*----------------------------------------------------------------------------------------*/
	_i.recalculaOrdenCola();
	_i.recalculaPrevision();	
	_i.calculaTiemposCola();	
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec(); 	
	_i.refresca();
	this.child("tblCola").selectRow(fila);
}

function oficial_tbnQuitaOrden_clicked()
{
	var _i = this.iface;

	var codOrden = _i.tblCola_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden de producci�n seleccionada"));
		return;
	}	

	/*.............................*/
	//if(!_i.compruebaOrdenEstampada(codOrden)) {
	//	if (!AQSql.update("em_ordenesestampacion", ["codmaquinaest", "orden"], [false, false], "codordenest = '" + codOrden + "'")) {
	//		return false;
	//	}
	//} else {
	/*..............................*/

	/*..............................*/
	/*if(!_i.compruebaOrdenEstampacionInsert(ordenCola)) {
		return false;
	}	*/	
	/*..............................*/

	var ordenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.em_ordenprod");	

	/*-----------------------------Dialog--------------------------------------------*/
	var dialog = new Dialog;
	dialog.caption = "Confirmar";
	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione:");
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );


	var codBobinaPz = _i.tblCola_.columnValue("pr_ordenesproduccion.codpreparamat");

	var botonPZ = new RadioButton;
	botonPZ.text = "Soporte/BB";
	botonPZ.checked = false;
	var aLista = [];
	var cboBobinas = new ComboBox;
	
	if(codBobinaPz && codBobinaPz != "") {
		grupo.add( botonPZ );	
		cboBobinas.label = sys.translate("      Soporte/BB");
		cboBobinas.editable = false;
		aLista = codBobinaPz.split(",");
		cboBobinas.itemList = aLista;
      	grupo.add(cboBobinas);
	}


	if(!dialog.exec() ) {
		return;
	}
	/*--------------------------------------------------------------------------------------*/

	/*-----------------------------------Elige boton-------------------------------------------*/
	if (botonG.checked) {
		//boton grupo
		var codGrupo = _i.tblCola_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		if (!codGrupo) {
			return false;
		}		
			

		var qEnv = new AQSqlQuery;
		qEnv.setSelect("codorden");
		qEnv.setFrom("pr_ordenesproduccion");
		qEnv.setWhere(_i.dameFiltroCola() + " AND em_codgruposeccion = '" + codGrupo + "' ORDER BY codorden");
		if (!qEnv.exec()) {
			return false;
		}
		while (qEnv.next()) {		
			
			var codOrden = qEnv.value("codorden");
			
			if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod"], [false, false], "codorden = '" + codOrden + "'")) {
			return false;
			}	
				

		}			
	} else if(botonO.checked) {
		//boton orden seleccionada
		if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod"], [false, false], "codorden = '" + codOrden + "'")) {
			return false;
		}	

	} else {

		if(!_i.codMaquina_ || _i.codMaquina_ == "") {
			formUI.ponMsgWarn(sys.translate("Debe indicar antes la m�quina asociada a la cola"));
			return false;
		}


		var codBobinaSop = cboBobinas.currentItem;
		debug("\n\ncodBobinaSop: "+codBobinaSop);
		if (!codBobinaSop) {
			return false;
		}	

		var aBobina = codBobinaSop.split("/");
		var codBobina = aBobina[aBobina.length-1];	
		var codSoporte = "";

		for(var i=0; i<aBobina.length-1; i++) {
			if(codSoporte != "") {
				codSoporte = codSoporte +"/";	
			}
			codSoporte = codSoporte + aBobina[i];
		}


		if(!_i.controlBobMaq(codBobina,_i.codMaquina_)) {
			return false;
		} 
		var res = formUI.preguntaMsg(sys.translate("Ha elegido desencolar las OPs encoladas de la m�quina %1 incluidas en el soporte/bobina %2. �Es correcto?").arg(_i.codMaquina_).arg(codBobinaSop), "info", this, MessageBox.Yes, MessageBox.No);
		if(res != MessageBox.Yes) {
			return false;
		}

		if(!_i.desencolar(codBobina,_i.codMaquina_)) {
			return false;
		}

	}
	/*----------------------------------------------------------------------------------------*/
	
	_i.recalculaOrdenCola();
	_i.recalculaPrevision();	
	_i.calculaTiemposCola();
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec(); 
	_i.refresca();

}

function oficial_tbnArriba_clicked()
{

	var _i = this.iface;	
	var fila = this.child("tblCola").currentRow();
	
	if(fila == 0) {		
		return true;
	}

	var dialog = new Dialog;
	dialog.caption = "Confirmar";
	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione:");
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );

	var codBobinaPz = _i.tblCola_.columnValue("pr_ordenesproduccion.codpreparamat");

	var botonPZ = new RadioButton;
	botonPZ.text = "Soporte/BB";
	botonPZ.checked = false;
	var aLista = [];
	var cboBobinas = new ComboBox;
	
	if(codBobinaPz && codBobinaPz != "") {
		grupo.add( botonPZ );	
		cboBobinas.label = sys.translate("      Soporte/BB");
		cboBobinas.editable = false;
		aLista = codBobinaPz.split(",");
		cboBobinas.itemList = aLista;
      	grupo.add(cboBobinas);
	}



	if(!dialog.exec() ) {
		return;
	}
	if (botonG.checked) {

		//si primera fila es del mismo grupo que el grupo seleccionado no hago nada
		//cogemos el grupo de la orden seleccionada A
		// buscamos el primero del grupo seleccionado 1A
		// cogemos el grupo de la orden anterior a 1A --> B
		// Buscamos el primero de B --> 1B
		//cogemos el orden de 1B y ese ser� el orden de 1A y seguidos pondremos todos los dem�s del grupo A
		var codGrupo = _i.tblCola_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		if (!codGrupo) {
			return false;
		}	
		var codGrupo0 = this.child("tblCola").text(0,10);

		if(codGrupo0 == codGrupo) {
			return true;
		}

		var ordenGrupo = AQUtil.sqlSelect("pr_ordenesproduccion","em_ordenprod","em_codgruposeccion = '" + codGrupo + "' ORDER BY em_ordenprod ASC");		
		var codGrupoAnterior, ordenAnterior;
		var encontrado = false;
		for(var i=0; i< ordenGrupo && !encontrado; i++) {
			if(this.child("tblCola").text(i,10) == codGrupo) {
				codGrupoAnterior = this.child("tblCola").text(i-1,10);
				ordenAnterior  = this.child("tblCola").text(i-1,0);
				encontrado = true;
			}
		}
		encontrado = false;
		var ordenPrimero;
		for(var i=0; i< ordenAnterior && !encontrado; i++) {
			if(this.child("tblCola").text(i,10) == codGrupoAnterior) {				
				ordenPrimero  = this.child("tblCola").text(i,0);
				encontrado = true;
			}
		}

		

		/*------------------------------------------------------------------------*/
		//hacer consulta para sacar los registros del grupo seleccionado
		//recorrer
		var qEnv = new AQSqlQuery;
		qEnv.setSelect("em_codmodooper,metrosptes,udsptes, codorden");
		qEnv.setFrom("pr_ordenesproduccion");
		qEnv.setWhere(_i.dameFiltroCola() + " AND em_codgruposeccion = '" + codGrupo + "' ORDER BY codorden");
		if (!qEnv.exec()) {
			return false;
		}
		//var o = 0, minprev, ms; pozu
		var o = 1;
		while (qEnv.next()) {		
			if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = em_ordenprod + 1 WHERE " + _i.dameFiltroCola() + " AND em_ordenprod >= " + ordenPrimero)) {
			return false;
			}
			var codModoOper = qEnv.value("em_codmodooper");
			var metrosPtes = qEnv.value("metrosptes");
			var prendasPtes = qEnv.value("udsptes");
			var codOrden = qEnv.value("codorden");

			var cantidadPte;

			if(_i.tipoProduccion_ == "Prendas") {
				cantidadPte = prendasPtes;
			} else {
				cantidadPte = metrosPtes;
			}

			var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);	
			if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, ordenPrimero, minEstimados], "codorden = '" + codOrden + "'")) {
				return false;
			}		
			//ordenCola++;

		}	
		anteriorFila = ordenPrimero - 1;
		/*-------------------------------------------------------------------------*/


	} else if(botonO.checked) {
		var codOrden = _i.tblCola_.columnValue("pr_ordenesproduccion.codorden");
		if (!codOrden) {
			sys.warnMsgBox(sys.translate("No hay ninguna orden de producci�n seleccionada"));
			return;
		}
		var codMaquina = this.child("cbMaquina").currentText;
		if (!codMaquina) {
			sys.warnMsgBox(sys.translate("No hay una m�quina seleccionada"));
			return;
		}
		
		var anteriorFila = fila - 1;
		var ordenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.em_ordenprod");

		var filtroCola=_i.dameFiltroCola();
		
		var codOrdenAnt = AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", filtroCola + " AND em_ordenprod < " + ordenCola + " ORDER BY em_ordenprod DESC");
		if (!codOrdenAnt) {
			return false;
		}
		/*.......................*/
		/*if(!_i.compruebaOrdenEstampacion(codOrden, codOrdenAnt)) {
			return false;
		}*/
		/*........................*/

		var ordenAnt = AQUtil.sqlSelect("pr_ordenesproduccion", "em_ordenprod", "codorden = '" + codOrdenAnt + "'");
		
		if (!AQSql.update("pr_ordenesproduccion", ["em_ordenprod"], [ordenAnt], "codorden = '" + codOrden + "'")) {
			return false;
		}

		if (!AQSql.update("pr_ordenesproduccion", ["em_ordenprod"], [ordenCola], "codorden = '" + codOrdenAnt + "'")) {
			return false;
		}	

	} else {

		var codBobinaSop = cboBobinas.currentItem;
		debug("\n\ncodBobinaSop: "+codBobinaSop);
		if (!codBobinaSop) {
			return false;
		}	
		var codBobinaSop0 = this.child("tblCola").text(0,3);

		if(codBobinaSop0 == codBobinaSop) {
			return true;
		}

		var aBobina = codBobinaSop.split("/");
		var codBobina = aBobina[aBobina.length-1];	
		var codSoporte = "";

		for(var i=0; i<aBobina.length-1; i++) {
			if(codSoporte != "") {
				codSoporte = codSoporte +"/";	
			}
			codSoporte = codSoporte + aBobina[i];
		}

		debug("codBobina: "+codBobina);
		debug("codSoporte: "+codSoporte);

		var ordenBobina = AQUtil.sqlSelect("pr_ordenesproduccion op inner join v_piezasrollbob p on p.codordenproduccion = op.codorden INNER JOIN em_bobinas b ON p.codbobinapiezaroll = b.codbobina","op.em_ordenprod","b.soporteactual = '" + codSoporte + "' AND p.codbobinapiezaroll= '" + codBobina + "' ORDER BY op.em_ordenprod ASC","pr_ordenesproduccion");		

		debug("ordenBobina: "+ordenBobina);

		var codBobinaSopAnterior, ordenAnterior;
		var codBobinaSopT;
		var encontrado = false;
		for(var i=0; i< ordenBobina && !encontrado; i++) {
			codBobinaSopT = this.child("tblCola").text(i,3);
			var aBobinas = codBobinaSopT.split(",");
			for(var k=0; k< aBobinas.length;k++) {
				if(aBobinas[k] == codBobinaSop) {
					codBobinaSopAnterior = this.child("tblCola").text(i-1,3);
					ordenAnterior  = this.child("tblCola").text(i-1,0);
					encontrado = true;
				}
			}
		}
		debug("codBobinaSopAnterior: "+codBobinaSopAnterior);
		debug("ordenAnterior: "+ordenAnterior);	
		encontrado = false;
		var ordenPrimero;
		if(!codBobinaSopAnterior || codBobinaSopAnterior == "") {
			ordenPrimero = ordenAnterior;
		} else {			
			for(var i=0; i< ordenAnterior && !encontrado; i++) {	
				codBobinaSopT = this.child("tblCola").text(i,3);
				var aBobinas = codBobinaSopT.split(",");
				for(var k=0; k< aBobinas.length;k++) {	
					var aBobinasAnt = codBobinaSopAnterior.split(",");
					for(j=0; j<aBobinasAnt.length;j++) {					
						if(aBobinas[k] == aBobinasAnt[j]) {				
							ordenPrimero  = this.child("tblCola").text(i,0);
							encontrado = true;
						}
					}			
				}
			}
		}
		
		debug("ordenPrimero: "+ordenPrimero);

		/*------------------------------------------------------------------------*/
		//hacer consulta para sacar los registros de la bobina seleccionada
		//recorrer
		var qEnv = new AQSqlQuery;
		qEnv.setSelect("pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.metrosptes,pr_ordenesproduccion.udsptes, pr_ordenesproduccion.codorden");
		qEnv.setFrom("pr_ordenesproduccion inner join v_piezasrollbob p on p.codordenproduccion = pr_ordenesproduccion.codorden INNER JOIN em_bobinas b ON p.codbobinapiezaroll = b.codbobina");
		qEnv.setWhere(_i.dameFiltroCola() + " AND b.soporteactual = '" + codSoporte + "' AND p.codbobinapiezaroll= '" + codBobina + "' ORDER BY pr_ordenesproduccion.codorden");
		debug("qEnv: "+qEnv.sql());
		if (!qEnv.exec()) {
			return false;
		}
		//var o = 0, minprev, ms; pozu
		var o = 1;
		while (qEnv.next()) {		
			if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = em_ordenprod + 1 WHERE " + _i.dameFiltroCola() + " AND em_ordenprod >= " + ordenPrimero)) {
				return false;
			}
			var codModoOper = qEnv.value("pr_ordenesproduccion.em_codmodooper");
			var metrosPtes = qEnv.value("pr_ordenesproduccion.metrosptes");
			var prendasPtes = qEnv.value("pr_ordenesproduccion.udsptes");
			var codOrden = qEnv.value("pr_ordenesproduccion.codorden");

			var cantidadPte;

			if(_i.tipoProduccion_ == "Prendas") {
				cantidadPte = prendasPtes;
			} else {
				cantidadPte = metrosPtes;
			}

			var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);	
			if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, ordenPrimero, minEstimados], "codorden = '" + codOrden + "'")) {
				return false;
			}		
			//ordenCola++;
		}	
		anteriorFila = ordenPrimero - 1;
	}

	_i.recalculaOrdenCola();	
	_i.recalculaPrevision();	
	_i.calculaTiemposCola();
	_i.refresca();
	//this.child("tblCola").selectRow(anteriorFila);

}



function oficial_tbnAbajo_clicked()
{
	var _i = this.iface;
	var codOrden = _i.tblCola_.columnValue("pr_ordenesproduccion.codorden");
	var fila = this.child("tblCola").currentRow();

	/*-------------------dialogo--------------------*/
	
	if(fila == 0) {		
		return true;
	}
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden de estampaci�n seleccionada"));
		return;
	}
	if (!_i.codMaquina_) {
		sys.warnMsgBox(sys.translate("No hay una m�quina de estampaci�n seleccionada"));
		return;
	}

	var dialog = new Dialog;
	dialog.caption = "Confirmar";
	dialog.okButtonText = "Aceptar";
	dialog.cancelButtonText = "Cancelar";    
	var texto = new Label;
	texto.text = sys.translate("Seleccione:");
	dialog.add( texto );
	    
	var grupo = new GroupBox;
	dialog.add( grupo );   
	
	var botonG = new RadioButton;
	botonG.text = "Aplicar la acci�n al grupo";
	botonG.checked = true;
	grupo.add( botonG );	

	
	var botonO = new RadioButton;
	botonO.text = "Orden seleccionada";
	botonO.checked = false;
	grupo.add( botonO );


	var codBobinaPz = _i.tblCola_.columnValue("pr_ordenesproduccion.codpreparamat");

	var botonPZ = new RadioButton;
	botonPZ.text = "Soporte/BB";
	botonPZ.checked = false;
	var aLista = [];
	var cboBobinas = new ComboBox;
	
	if(codBobinaPz && codBobinaPz != "") {
		grupo.add( botonPZ );	
		cboBobinas.label = sys.translate("      Soporte/BB");
		cboBobinas.editable = false;
		aLista = codBobinaPz.split(",");
		cboBobinas.itemList = aLista;
      	grupo.add(cboBobinas);
	}




	if(!dialog.exec() ) {
		return;
	}

	/*----------elijo boton------------*/

	if (botonG.checked) {
		//si primera fila es del mismo grupo que el grupo seleccionado no hago nada
		//cogemos el grupo de la orden seleccionada A
		// buscamos el primero del grupo seleccionado 1A
		// cogemos el grupo de la orden anterior a 1A --> B
		// Buscamos el primero de B --> 1B
		//cogemos el orden de 1B y ese ser� el orden de 1A y seguidos pondremos todos los dem�s del grupo A
		var codGrupo = _i.tblCola_.columnValue("pr_ordenesproduccion.em_codgruposeccion");
		
		if (!codGrupo) {
			return false;
		}	

		var regTblCols = new AQSqlQuery;
		regTblCols.setSelect("count(*)");
		regTblCols.setFrom("pr_ordenesproduccion");
		regTblCols.setWhere(_i.dameFiltroCola());
		if (!regTblCols.exec()) {
			return false;
		}
		regTblCols.next();
		registrosTblCola=regTblCols.value("count(*)");
	

		var codGrupo0 = this.child("tblCola").text(registrosTblCola-1,10);
		
		if(codGrupo0 == codGrupo) {
			return true;
		}
		var encontrado=false;
		var ordenPosterior, codGrupoPosterior;
		for(var i=registrosTblCola-1; i>=0 && !encontrado ;i--){
			if(this.child("tblCola").text(i,10) == codGrupo){
				//encuentro al ultimo registro del grupo seleccionado
				ordenPosterior  = this.child("tblCola").text(i+1,0);
				
				codGrupoPosterior = this.child("tblCola").text(i+1,10);
				
				encontrado=true;
			}
		}
		encontrado = false;
		var ordenPrimero;
		for(var i=registrosTblCola-1; i>=0 && !encontrado ;i--){
			if(this.child("tblCola").text(i,10) == codGrupoPosterior){
				//encuentro el ultimo registro del posterior al..
				ordenPrimero = this.child("tblCola").text(i+1,0);
				
				encontrado = true;
			}
		}
		
		//------------------------------Pongo registros------------------------------------------
		//hacer consulta para sacar los registros del grupo seleccionado
		//recorrer
		var qEnv = new AQSqlQuery;
		qEnv.setSelect("em_codmodooper,metrosptes,udsptes, codorden");
		qEnv.setFrom("pr_ordenesproduccion");
		qEnv.setWhere(_i.dameFiltroCola() + " AND em_codgruposeccion = '" + codGrupo + "' ORDER BY codorden DESC");
		if (!qEnv.exec()) {
			return false;
		}

		while (qEnv.next()) {		
			if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = em_ordenprod + 1 WHERE " + _i.dameFiltroCola() + " AND em_ordenprod >= " + ordenPrimero)) {
			return false;
			}
			var codModoOper = qEnv.value("em_codmodooper");
			var metrosPtes = qEnv.value("metrosptes");
			var prendasPtes = qEnv.value("udsptes");
			var codOrden = qEnv.value("codorden");

			var cantidadPte;

			if(_i.tipoProduccion_ == "Prendas") {
				cantidadPte = prendasPtes;
			} else {
				cantidadPte = metrosPtes;
			}

			var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);	
			if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, ordenPrimero, minEstimados], "codorden = '" + codOrden + "'")) {
				return false;
			}		
			//ordenCola++;
			

		}	

		//-------------------------------------------------------------------------


	} else if(botonO.checked) {

		var siguienteFila = fila;
		var ordenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.em_ordenprod");
		
		var filtroCola=_i.dameFiltroCola();


		var codOrdenPos = AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", filtroCola + " AND em_ordenprod > " + ordenCola + " ORDER BY em_ordenprod ASC");
		if (!codOrdenPos) {
			return false;
		}
		var ordenPos = AQUtil.sqlSelect("pr_ordenesproduccion", "em_ordenprod", "codorden = '" + codOrdenPos+ "'");
		if (!AQSql.update("pr_ordenesproduccion", ["em_ordenprod"], [ordenPos], "codorden = '" + codOrden + "'")) {
			return false;
		}
		if (!AQSql.update("pr_ordenesproduccion", ["em_ordenprod"], [ordenCola], "codorden = '" + codOrdenPos + "'")) {
			return false;
		}	

	} else {

		var codBobinaSop = cboBobinas.currentItem;
		debug("\n\ncodBobinaSop: "+codBobinaSop);
		if (!codBobinaSop) {
			return false;
		}	


		var regTblCols = new AQSqlQuery;
		regTblCols.setSelect("count(*)");
		regTblCols.setFrom("pr_ordenesproduccion");
		regTblCols.setWhere(_i.dameFiltroCola());
		if (!regTblCols.exec()) {
			return false;
		}
		regTblCols.next();
		registrosTblCola=regTblCols.value("count(*)");


		/*var codBobinaSop0 = this.child("tblCola").text(registrosTblCola-1,3); lo comento por ahora

		if(codBobinaSop0 == codBobinaSop) {
			return true;
		}	*/

		var aBobina = codBobinaSop.split("/");
		var codBobina = aBobina[aBobina.length-1];	
		var codSoporte = "";
		for(var i=0; i<aBobina.length-1; i++) {
			if(codSoporte != "") {
				codSoporte = codSoporte +"/";	
			}
			codSoporte = codSoporte + aBobina[i];
		}

		debug("codBobina: "+codBobina);
		debug("codSoporte: "+codSoporte);

		var codBobinaSopPosterior, ordenPosterior;
		var codBobinaSopT;
		var codordenPosterior;
		var encontrado=false;		
		for(var i=registrosTblCola-1; i>=0 && !encontrado ;i--){
			codBobinaSopT = this.child("tblCola").text(i,3);
			var aBobinas = codBobinaSopT.split(",");
			for(var k=0; k< aBobinas.length;k++) {
				if(aBobinas[k] == codBobinaSop) {				
					ordenPosterior  = this.child("tblCola").text(i+1,0);				
					codBobinaSopPosterior = this.child("tblCola").text(i+1,3);		
					codordenPosterior = this.child("tblCola").text(i+1,4);		
					encontrado=true;
				}
			}
		}

		debug("codBobinaSopPosterior: "+codBobinaSopPosterior);
		debug("ordenPosterior: "+ordenPosterior);
		debug("codordenPosterior: "+codordenPosterior);
		encontrado = false;
		var ordenPrimero;
		//if(!codBobinaSopPosterior || codBobinaSopPosterior == "") {
			ordenPrimero = AQUtil.sqlSelect("pr_ordenesproduccion  INNER JOIN v_piezasrollbob p ON p.codordenproduccion = pr_ordenesproduccion.codorden INNER JOIN em_bobinas b ON p.codbobinapiezaroll = b.codbobina","em_ordenprod",_i.dameFiltroCola() + " AND b.soporteactual = '" + codSoporte + "' AND p.codbobinapiezaroll= '" + codBobina + "' ORDER BY em_ordenprod ASC","pr_ordenesproduccion");

		/*} else {	
			for(var i=registrosTblCola-1; i>=0 && !encontrado ;i--){
				codBobinaSopT = this.child("tblCola").text(i,3);
				var aBobinas = codBobinaSopT.split(",");
				for(var k=0; k< aBobinas.length;k++) {	
					var aBobinasPos = codBobinaSopPosterior.split(",");
					for(j=0; j<aBobinasPos.length;j++) {
						if(aBobinas[k] == aBobinasPos[j]) {
							//encuentro el ultimo registro del posterior al..
							ordenPrimero = this.child("tblCola").text(i+1,0);				
							encontrado = true;
						}
			
					}
				}
			}
		}*/
		
		debug("ordenPrimero: "+ordenPrimero);

		//hacer consulta para sacar los registros del grupo seleccionado
		//recorrer

		var qEnv = new AQSqlQuery;
		qEnv.setSelect("pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.metrosptes,pr_ordenesproduccion.udsptes, pr_ordenesproduccion.codorden");
		qEnv.setFrom("pr_ordenesproduccion  inner join v_piezasrollbob p on p.codordenproduccion = pr_ordenesproduccion.codorden INNER JOIN em_bobinas b ON p.codbobinapiezaroll = b.codbobina");
		qEnv.setWhere(_i.dameFiltroCola() + " AND b.soporteactual = '" + codSoporte + "' AND p.codbobinapiezaroll= '" + codBobina + "' GROUP BY pr_ordenesproduccion.em_codmodooper,pr_ordenesproduccion.metrosptes,pr_ordenesproduccion.udsptes, pr_ordenesproduccion.codorden ORDER BY pr_ordenesproduccion.codorden DESC");
		debug("qEnv: "+qEnv.sql());
		if (!qEnv.exec()) {
			return false;
		}

		while (qEnv.next()) {		
			if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = em_ordenprod + 1 WHERE " + _i.dameFiltroCola() + " AND em_ordenprod >= " + ordenPrimero)) {
				return false;
			}
			var codModoOper = qEnv.value("pr_ordenesproduccion.em_codmodooper");
			var metrosPtes = qEnv.value("pr_ordenesproduccion.metrosptes");
			var prendasPtes = qEnv.value("pr_ordenesproduccion.udsptes");
			var codOrden = qEnv.value("pr_ordenesproduccion.codorden");

			var cantidadPte;

			if(_i.tipoProduccion_ == "Prendas") {
				cantidadPte = prendasPtes;
			} else {
				cantidadPte = metrosPtes;
			}

			var minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);
			//if(!codBobinaSopPosterior || codBobinaSopPosterior == "") {
				if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_minprev"], [_i.codMaquina_, minEstimados], "codorden = '" + codOrden + "'")) {
					return false;
				}
			/*} else {
				if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [_i.codMaquina_, ordenPrimero, minEstimados], "codorden = '" + codOrden + "'")) {
					return false;
				}

			}*/		

			//ordenCola++;		

		}	
		if(!codBobinaSopPosterior || codBobinaSopPosterior == "") {
			if (!AQSql.update("pr_ordenesproduccion", ["em_ordenprod"], [ordenPrimero], "codorden = '" + codordenPosterior + "'")) {
				return false;
			}
		} else {

			var aBobinasPosSop = codBobinaSopPosterior.split(",");
			for(var k=0; k< aBobinasPosSop.length;k++) {	
				var codBobinaSop = aBobinasPosSop[k];	
				var aBobina = codBobinaSop.split("/");
				var codBobina = aBobina[aBobina.length-1];	
				var codSoporte = "";
				for(var i=0; i<aBobina.length-1; i++) {
					if(codSoporte != "") {
						codSoporte = codSoporte +"/";	
					}
					codSoporte = codSoporte + aBobina[i];
				}					
				if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = " + ordenPrimero + " WHERE codorden  IN (SELECT pr_ordenesproduccion.codorden FROM pr_ordenesproduccion  inner join v_piezasrollbob p on p.codordenproduccion = pr_ordenesproduccion.codorden INNER JOIN em_bobinas b ON p.codbobinapiezaroll = b.codbobina where " + _i.dameFiltroCola() + " AND b.soporteactual = '" + codSoporte + "' AND p.codbobinapiezaroll= '" + codBobina + "')")) {
					return false;
				}	
				
			}			
		}
	}
	_i.recalculaOrdenCola();	
	_i.recalculaPrevision();	
	_i.calculaTiemposCola();
	_i.refresca();
	//this.child("tblCola").selectRow(siguienteFila);
	
}

function oficial_recalculaOrdenCola()
{
	var _i = this.iface;
	
	var qCola = new AQSqlQuery;
	qCola.setSelect("codorden, em_ordenprod");
	qCola.setFrom("pr_ordenesproduccion");
	qCola.setWhere(_i.dameFiltroCola() + " ORDER BY em_ordenprod");
	if (!qCola.exec()) {
		return false;
	}
	//var o = 0, minprev, ms; pozu
	var o = 1;
	while (qCola.next()) {		
		if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = " + o + " WHERE codorden = '" + qCola.value("codorden") + "'")) {
			return false;
		}
		o++;
	}
	
}

function oficial_estimaMinutosProd(codModoOper, cantidadPte)
{
	var _i = this.iface;

	var velocidad = _i.dameVelocidadMaquina(codModoOper);
	if (isNaN(velocidad) || velocidad == 0) {
		flfactppal.iface.ponMsgError(sys.translate("Error al obtener la velocidad para el modo de operaci�n %1").arg(codModoOper), "warn");
		return false;
	}

	return velocidad ? ((cantidadPte * 60) / velocidad) : 0;
}

function oficial_dameVelocidadMaquina(codModoOper)
{
	var _i = this.iface;

	var velocidad;
	var vxm = _i.oMaquina_["velocidadxmodo"];
	if (codModoOper in vxm) {
		velocidad = vxm[codModoOper];
	} else {
		velocidad = _i.oMaquina_["velocidad"];
	}

	return velocidad;
}

function oficial_recalculaPrevision()
{
	var _i = this.iface;
	var canPendiente;
	var fila = 0;
	var retardoAcumulado = 0; 
	var retardoAcabado = 0; 
	var retardoTipoTejido = 0; 
	var retardoAnverso = 0; 
	var retardoReverso = 0; 
	var retardoTotal = 0;
	var retardoParo = 0;
	var velocidad;
	var curO = new FLSqlCursor("pr_ordenesproduccion");
	curO.setActivatedCheckIntegrity(false);
	curO.setActivatedCommitActions(false);		
	curO.select(_i.dameFiltroCola() + " AND udsptes > 0 ORDER BY em_ordenprod");
	
	while (curO.next()) {
		curO.setModeAccess(curO.Edit);
		curO.refreshBuffer();
	
		
		var codOrden = curO.valueBuffer("codorden");	
		var codModoOper = curO.valueBuffer("em_codmodooper");	
		velocidad = _i.dameVelocidadMaquina(codModoOper);
		if (isNaN(velocidad) || velocidad == 0) {
			flfactppal.iface.ponMsgError(sys.translate("Error al obtener la velocidad para el modo de operaci�n %1").arg(codModoOper), "warn");
			return false;
		}
		
		if(_i.tipoProduccion_ == "Prendas") {
			canPendiente = curO.valueBuffer("udsptes");
		} else {
			canPendiente = curO.valueBuffer("metrosptes");
		}	

		var horasDia = AQUtil.sqlSelect("em_maquinascol", "horasdia", "codmaquinacol = '" + _i.codMaquina_ + "'");			
		var horasNetaCola = canPendiente / velocidad;



		if(fila != 0) {
			retardoAcabado = _i.calculaRetardoAcabado(curO, fila); 
			retardoTipoTejido = _i.calculaRetardoTipoTejido(curO, fila); 
			retardoAnverso = _i.calculaRetardoAnverso(curO, fila); 
			retardoReverso = _i.calculaRetardoReverso(curO, fila); 
			retardoTotal = parseFloat(retardoAcabado) + parseFloat(retardoTipoTejido) + parseFloat(retardoAnverso) +parseFloat(retardoReverso);
			retardoAcumulado = parseFloat(retardoAcumulado) + parseFloat(retardoTotal);
		}
		retardoParo = _i.calculaRetardoParo(curO);
		retardoParo = parseFloat(retardoParo / 3600);

		var totalRetardo = retardoTotal; 
		totalRetardo = parseFloat(totalRetardo/3600);
		horasNetaCola = parseFloat(horasNetaCola) + parseFloat(totalRetardo) + parseFloat(retardoParo);

		var horasBrutasCola = 0;
		var horasIdeales = 0;
		
		if(horasDia && horasDia !=0) {
			horasBrutasCola = horasNetaCola*24 / horasDia;
		}

		var segundos = parseInt(horasBrutasCola * 3600);

		var horasFormateadas = formem_colaestampacion.iface.formatearTiempo(segundos);
		
		horasFormateadas = horasFormateadas.toString().right(10);
		curO.setValueBuffer("em_minprev",_i.estimaMinutosProd(codModoOper,canPendiente));
		curO.setValueBuffer("em_horasnetacola",horasNetaCola);
		curO.setValueBuffer("em_horasdia",horasDia);		
		curO.setValueBuffer("em_horasbrutascola",horasFormateadas);		
		curO.setValueBuffer("em_retardoacabado",retardoAcabado);
		curO.setValueBuffer("em_retardotipotejido",retardoTipoTejido);
		curO.setValueBuffer("em_retardoanverso",retardoAnverso);
		curO.setValueBuffer("em_retardoreverso",retardoReverso);
		curO.setValueBuffer("em_retardototal",retardoTotal);
		curO.setValueBuffer("em_retardoacu",retardoAcumulado);
		if (!curO.commitBuffer()) {
			
			return false;
		}	
		fila++;		
	}
	return true;
}

function oficial_calculaRetardoParo(curO)
{
	var _i = this.iface;

	var tiempoParo = AQUtil.sqlSelect("em_parosprod", "SUM(tiempoparoreal)", "codorden = '" + curO.valueBuffer("codorden")+ "'");
	if (!tiempoParo) {
		tiempoParo = 0;
	}
	return tiempoParo;
}

function oficial_calculaTiemposCola()
{
	var _i = this.iface;
	

	var horasDiaDefecto = AQUtil.sqlSelect("em_maquinascol", "horasdia", "codmaquinacol = '" + _i.codMaquina_ + "'");	
	
	var desde = new Date(Date.parse(this.child("dedFecha").date.toString().left(10) + "T" + this.child("tedHora").time.toString().right(8)));
	
	var coeficiente = 1;

	var curO = new FLSqlCursor("pr_ordenesproduccion");
	curO.setActivatedCheckIntegrity(false);
	curO.setActivatedCommitActions(false);
	curO.select(_i.dameFiltroCola() + " AND udsptes > 0 ORDER BY em_ordenprod");
	var min, ms;
	var saldoTiempo = desde.getTime();
	
	var fechaPrev;
	var cuenta = 0;
	while (curO.next()) {
		curO.setModeAccess(curO.Edit);
		curO.refreshBuffer();	
		
		horasDia = horasDiaDefecto;				
		if(!horasDia || horasDia == "") {
			horasDia = 24;
		}
		if(horasDia && horasDia != "") {			
			coeficiente = (24 - horasDia) * 60*60000;
		}			

		
		var horasHasta = curO.valueBuffer("em_horasbrutascola");		
		horasHasta = horasHasta.toString().right(10);				
		var ms = formem_colaestampacion.iface.dameMilisegundos(horasHasta);				
		saldoTiempo += ms;		
		fechaPrev = new Date(saldoTiempo);	
		
		curO.setValueBuffer("em_fechacalcprev", desde.toString().left(10));
		curO.setValueBuffer("em_horacalcprev", desde.toString().right(8));
		curO.setValueBuffer("em_fechafinprev", fechaPrev.toString().left(10));
		curO.setValueBuffer("em_horafinprev", fechaPrev.toString().right(8));
		curO.setValueBuffer("em_horasdia", horasDia);
		
		
		if (!curO.commitBuffer()) {
			return false;
		}	
		desde = fechaPrev;
	}

	
	
}

function oficial_cargaFabricaSeccion(codMaquina) 
{
	var _i = this.iface;
	var codSeccion = AQUtil.sqlSelect("em_maquinascol","codseccion","codmaquinacol = '" + codMaquina + "'");
	var codFabrica = AQUtil.sqlSelect("em_secciones","codfabrica","codseccion = '" + codSeccion + "'");
	this.child("cbFabrica").currentText = codFabrica;
	_i.cargaComboSeccion();	
	this.child("cbSeccion").currentText = codSeccion;
	_i.cargaComboMaquina();	
	
}

function oficial_cargaCacheMaquina()
{
	var _i = this.iface;

	delete _i.oMaquina_;
	_i.oMaquina_ = {};
	_i.oMaquina_["codmaquina"] = undefined;
	_i.oMaquina_["velocidad"] = undefined;
	_i.oMaquina_["tipoproduccion"] = undefined;
	_i.oMaquina_["velocidadxmodo"] = {};

}

function oficial_asignaMaquina(codMaquina)
{
	var _i = this.iface;	

	_i.cargaCacheMaquina();

	this.child("cbMaquina").currentText = codMaquina;
	AQUtil.writeSettingEntry("scripts/flprodppal/codMaquinaCol", codMaquina);
	_i.codMaquina_ = codMaquina;	
	var q = new AQSqlQuery;
	q.setSelect("velocidadmaquina,tipoproduccion");
	q.setFrom("em_maquinascol");
	q.setWhere("codmaquinacol = '" + codMaquina + "'");
	if (!q.exec()) {
		flfactppal.iface.ponMsgError(sys.translate("Error al localizar la m�quina %1").arg(codMaquina), "warn");
		return false;
	} 	
	if (!q.first()) {
		flfactppal.iface.ponMsgError(sys.translate("Error al localizar la m�quina %1").arg(codMaquina), "warn");
		return false;
	}
	_i.oMaquina_["velocidad"] = q.value("velocidadmaquina");
	_i.tipoProduccion_ = q.value("tipoproduccion");

	
	if (!_i.cargaVelocidadXModo(codMaquina)) {
		flfactppal.iface.ponMsgError(sys.translate("Error al cargar las velocidades x modo de operaci�n de la m�quina %1").arg(codMaquina), "warn");
		return false;
	}

	_i.cargarArrayRecargos();
	_i.filtraCola();	
	_i.refresca();
	
	_i.cargaFechaCalculo();
}

function oficial_cargaVelocidadXModo(codMaquina)
{
	var _i = this.iface;
	var qModo = new FLSqlQuery;
	qModo.setSelect("codmodooper, velocidadoperacion");
	qModo.setFrom("em_maquinasmodooper");
	qModo.setWhere("codmaquinacol = '" + codMaquina + "'");
	if (!qModo.exec()) {
		flfactppal.iface.ponMsgError(sys.translate("Error al localizar los modos de operaci�n de la m�quina %1").arg(codMaquina), "warn");
		return false;
	}
	var vxm = _i.oMaquina_["velocidadxmodo"];
	while (qModo.next()) {
		vxm[qModo.value("codmodooper")] = qModo.value("velocidadoperacion");
	}
	return true;
}

function oficial_cargaFechaCalculo()
{
	var _i = this.iface;
	var minFecha = AQUtil.sqlSelect("pr_ordenesproduccion", "min(em_fechacalcprev+em_horacalcprev)", _i.dameFiltroCola() + " and codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE') ");

	//tambien podriamos hacer udsptes >0

	if(!minFecha || minFecha == "") {
		var ahora = new Date;
		this.child("dedFecha").date = ahora.toString().left(10);
		this.child("tedHora").time = ahora.toString().right(8);
	
	} else {
		this.child("dedFecha").date = minFecha.toString().left(10);
		this.child("tedHora").time = minFecha.toString().right(8);
	
	}	

}

function oficial_dameCantidadPte(codOrden)
{
	var _i = this.iface;
	if(_i.tipoProduccion_ == "Prendas") {
		cantidadPte = prendasPtes;
	} else {
		cantidadPte = metrosPtes;
	}
}

function oficial_cargaDatosMaq()
{
	var _i = this.iface;
	var tResumMaq = this.child("tblResumMaq");
	tResumMaq.setNumRows(0);
	var f = 0;
	var q = new AQSqlQuery;	
	q.setSelect("em_codmaquinacol,SUM(metrosptes),SUM(udsptes),min(em_fechacalcprev+em_horacalcprev), max(em_fechafinprev+em_horafinprev)");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("em_codmaquinacol is not null AND ((estado IN ('PTE','EN CURSO')) OR (codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE'))) AND udsptes > 0 group by em_codmaquinacol order by em_codmaquinacol"); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		tResumMaq.insertRows(f);		
		
		var fechaInicio = q.value("min(em_fechacalcprev+em_horacalcprev)");
		if(fechaInicio && fechaInicio !="") { 
			fechaInicio  = AQUtil.dateAMDtoDMA(fechaInicio.toString().left(10))+" "+fechaInicio.toString().right(8);
		}
		var fechaFin  = q.value("max(em_fechafinprev+em_horafinprev)");
		if(fechaFin && fechaFin !="") { 
			fechaFin  = AQUtil.dateAMDtoDMA(fechaFin.toString().left(10))+" "+fechaFin.toString().right(8);
		}
		var udsPendiente = q.value("SUM(udsptes)");
		udsPendiente = isNaN(udsPendiente) ? 0 : udsPendiente;
		udsPendiente = AQUtil.roundFieldValue(udsPendiente, "pr_ordenesproduccion", "udsptes");

		var metrosPendiente = q.value("SUM(metrosptes)");
		metrosPendiente = isNaN(metrosPendiente) ? 0 : metrosPendiente;
		metrosPendiente = AQUtil.roundFieldValue(metrosPendiente, "pr_ordenesproduccion", "metrosptes");	


		tResumMaq.setText(f, _i.cMAQ_, q.value("em_codmaquinacol"));
		tResumMaq.setText(f, _i.cPMC_, udsPendiente);
		tResumMaq.setText(f, _i.cMMC_, metrosPendiente);
		tResumMaq.setText(f, _i.cFIMC_, fechaInicio);
		tResumMaq.setText(f, _i.cFFMC_, fechaFin);	
		f++;	
	}		
	
	/*--------------------------------------------TOTAL-----------------------------------------------------------*/
	q = new AQSqlQuery;
	q.setSelect("SUM(metrosptes),SUM(udsptes), min(em_fechacalcprev+em_horacalcprev), max(em_fechafinprev+em_horafinprev)");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("em_codmaquinacol is not null AND ((estado IN ('PTE','EN CURSO')) OR (codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE'))) AND udsptes > 0"); 			
	if (!q.exec()){
		return;
	}  

	if(q.first())
	{
		tResumMaq.insertRows(f);		
		
		var fechaInicio = q.value("min(fechacalcprev+horacalcprev)");
		if(fechaInicio && fechaInicio !="") { 
			fechaInicio  = AQUtil.dateAMDtoDMA(fechaInicio.toString().left(10))+" "+fechaInicio.toString().right(8);
		}
		var fechaFin  = q.value("max(fechafinprev+horafinprev)");
		if(fechaFin && fechaFin !="") { 
			fechaFin  = AQUtil.dateAMDtoDMA(fechaFin.toString().left(10))+" "+fechaFin.toString().right(8);
		}
		var metrosPendiente = q.value("SUM(metrosptes)");
		metrosPendiente = isNaN(metrosPendiente) ? 0 : metrosPendiente;
		metrosPendiente = AQUtil.roundFieldValue(metrosPendiente, "pr_ordenesproduccion", "metrosptes");	

		var udsPendiente = q.value("SUM(udsptes)");
		udsPendiente = isNaN(udsPendiente) ? 0 : udsPendiente;
		udsPendiente = AQUtil.roundFieldValue(udsPendiente, "pr_ordenesproduccion", "udsptes");
	
		tResumMaq.setText(f, _i.cMAQ_, "TOTAL");
		tResumMaq.setText(f, _i.cPMC_, udsPendiente);
		tResumMaq.setText(f, _i.cMMC_, metrosPendiente);
		tResumMaq.setText(f, _i.cFIMC_, fechaInicio);
		tResumMaq.setText(f, _i.cFFMC_, fechaFin);		
	}

	return true;
}

function oficial_cargaDatosSec()
{

	var _i = this.iface;
	var tResumSec = this.child("tblResumSec");
	tResumSec.setNumRows(0);
	var f = 0;
	var q = new AQSqlQuery;	
	q.setSelect("em_maquinascol.codseccion,SUM(metrosptes),SUM(udsptes),min(em_fechacalcprev+em_horacalcprev), max(em_fechafinprev+em_horafinprev)");
	q.setFrom("pr_ordenesproduccion INNER JOIN em_maquinascol ON pr_ordenesproduccion.em_codmaquinacol = codmaquinacol");
	q.setWhere("em_codmaquinacol is not null AND ((estado IN ('PTE','EN CURSO')) OR (codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE'))) AND udsptes > 0 group by em_maquinascol.codseccion order by em_maquinascol.codseccion"); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		tResumSec.insertRows(f);		
		
		var fechaInicio = q.value("min(em_fechacalcprev+em_horacalcprev)");
		if(fechaInicio && fechaInicio !="") { 
			fechaInicio  = AQUtil.dateAMDtoDMA(fechaInicio.toString().left(10))+" "+fechaInicio.toString().right(8);
		}
		var fechaFin  = q.value("max(em_fechafinprev+em_horafinprev)");
		if(fechaFin && fechaFin !="") { 
			fechaFin  = AQUtil.dateAMDtoDMA(fechaFin.toString().left(10))+" "+fechaFin.toString().right(8);
		}
		var udsPendiente = q.value("SUM(udsptes)");
		udsPendiente = isNaN(udsPendiente) ? 0 : udsPendiente;
		udsPendiente = AQUtil.roundFieldValue(udsPendiente, "pr_ordenesproduccion", "udsptes");

		var metrosPendiente = q.value("SUM(metrosptes)");
		metrosPendiente = isNaN(metrosPendiente) ? 0 : metrosPendiente;
		metrosPendiente = AQUtil.roundFieldValue(metrosPendiente, "pr_ordenesproduccion", "metrosptes");




		tResumSec.setText(f, _i.cSEC_, q.value("em_maquinascol.codseccion"));
		tResumSec.setText(f, _i.cPSC_, udsPendiente);
		tResumSec.setText(f, _i.cMSC_, metrosPendiente);
		tResumSec.setText(f, _i.cFISC_, fechaInicio);
		tResumSec.setText(f, _i.cFFSC_, fechaFin);	
		f++;	
	}		
	
	/*--------------------------------------------TOTAL-----------------------------------------------------------*/
	q = new AQSqlQuery;
	q.setSelect("SUM(metrosptes),SUM(udsptes), min(em_fechacalcprev+em_horacalcprev), max(em_fechafinprev+em_horafinprev)");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("em_codmaquinacol is not null AND ((estado IN ('PTE','EN CURSO')) OR (codorden IN (SELECT codordenproduccion FROM lotesstock WHERE estado ='PTE'))) AND udsptes > 0"); 			
	if (!q.exec()){
		return;
	}  

	if(q.first())
	{
		tResumSec.insertRows(f);		
		
		var fechaInicio = q.value("min(fechacalcprev+horacalcprev)");
		if(fechaInicio && fechaInicio !="") { 
			fechaInicio  = AQUtil.dateAMDtoDMA(fechaInicio.toString().left(10))+" "+fechaInicio.toString().right(8);
		}
		var fechaFin  = q.value("max(fechafinprev+horafinprev)");
		if(fechaFin && fechaFin !="") { 
			fechaFin  = AQUtil.dateAMDtoDMA(fechaFin.toString().left(10))+" "+fechaFin.toString().right(8);
		}
		var metrosPendiente = q.value("SUM(metrosptes)");
		metrosPendiente = isNaN(metrosPendiente) ? 0 : metrosPendiente;
		metrosPendiente = AQUtil.roundFieldValue(metrosPendiente, "pr_ordenesproduccion", "metrosptes");	

		var udsPendiente = q.value("SUM(udsptes)");
		udsPendiente = isNaN(udsPendiente) ? 0 : udsPendiente;
		udsPendiente = AQUtil.roundFieldValue(udsPendiente, "pr_ordenesproduccion", "udsptes");
	
		tResumSec.setText(f, _i.cSEC_, "TOTAL");
		tResumSec.setText(f, _i.cPSC_, udsPendiente);
		tResumSec.setText(f, _i.cMSC_, metrosPendiente);
		tResumSec.setText(f, _i.cFISC_, fechaInicio);
		tResumSec.setText(f, _i.cFFSC_, fechaFin);	
	}

	return true;

}

function oficial_tbnExcelCola_clicked()
{
	var _i = this.iface;
	_i.exportaExcelCola(false);
}

function oficial_tbnImprimirCola_clicked()
{
	var _i = this.iface;
	_i.refresca();	
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec();
	var oParam = _i.dameParamInformeCola();
	if (!oParam) {
		return;
	}
	_i.imprimirCola(oParam);

}

function oficial_dameParamInformeCola()
{
	var _i = this.iface;
	var codMaquina = _i.dameMaquinaColaAct();
	if (!codMaquina || codMaquina == "") {
		return;
	}
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "em_i_colaproduccion";
	oParam.whereFijo = _i.dameFiltroCola(codMaquina);//"udsptes > 0 and em_codmaquinacol = '" + codMaquina + "'";
	return oParam;
	
}

function oficial_imprimirCola(oParam) 
{
	var _i = this.iface;	
	
	var fecha = this.child("dedFecha").date.toString().left(10);
	var hora = this.child("tedHora").time.toString().right(8);
	_i.fechaBaseColaProd_ = AQUtil.dateAMDtoDMA(fecha) +" "+hora;

	var curImprimir = new FLSqlCursor("pr_i_ordenesproduccion");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	//curImprimir.setValueBuffer("em_codmaquinacol", codMaquina);
	//curImprimir.setValueBuffer("h_pr__ordenesproduccion_em__codmaquinacol", codMaquina);	
	var seleccion = curImprimir.valueBuffer("id");

	if (!seleccion) {
		return;
	}		
	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);                               	
}

function oficial_dameMaquinaColaAct()
{
	var _i = this.iface;
	return _i.codMaquina_;
}

function oficial_tbnAhora_clicked()
{	
	
	var _i = this.iface;
	var ahora = new Date;
	var fecha = this.child("dedFecha").date.toString().left(10);
	var hora = this.child("tedHora").time.toString().right(8);
	
	if (!fecha || fecha == "") {
		this.child("dedFecha").date = ahora.toString().left(10);
		this.child("tedHora").time = ahora.toString().right(8);
	}

	var codMaquina = this.child("cbMaquina").currentText
	if (!codMaquina || codMaquina == "") {
		flfactppal.iface.pub_ponMsgError(sys.translate("Debe informar la m�quina"));
		return;
	}
	//_i.asignaMaquina(codMaquina);
	_i.recalculaPrevision();	
	_i.calculaTiemposCola();
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec();
	_i.refresca();
}

function oficial_calculaRetardoAcabado(curO, fila)
{
	_i = this.iface;
	var valor = 0;
	var acabadosActual = curO.valueBuffer("em_acabados");
	var acabadosAnterior = _i.tblCola_.cellValue(fila-1, "pr_ordenesproduccion.em_acabados");

	var aAcabadosActual = acabadosActual.split(",");
	var aAcabadosAnterior = acabadosAnterior.split(",");

	var acabado = "";
	for(var i = 0; i < aAcabadosAnterior.length; i++) {
		for(var k =0 ; k < aAcabadosActual.length; k++) {
			acabado = aAcabadosAnterior[i] + _i.sep_ + aAcabadosActual[k];
			if(acabado in _i.oRetardosMaq_.retardoAca) {
				valor += parseFloat(_i.oRetardosMaq_.retardoAca[acabado]);
			}
		}
	}
	return valor;

}

function oficial_calculaRetardoTipoTejido(curO, fila)
{	
	_i = this.iface;
	var valor = 0;
	var aliasActual = curO.valueBuffer("em_alias");
	var aliasAnterior = _i.tblCola_.cellValue(fila-1, "pr_ordenesproduccion.em_alias");
	if(aliasActual && aliasActual != "" && aliasAnterior && aliasAnterior != "") {
		var alias = aliasActual+_i.sep_+aliasAnterior;
		if(alias in _i.oRetardosMaq_.retardoTipo) {
			valor = _i.oRetardosMaq_.retardoTipo[alias];
		}
	}	
	return valor;
}

function oficial_calculaRetardoAnverso(curO, fila)
{
	_i = this.iface;
	var valor = 0;
	var anversoActual = curO.valueBuffer("em_anverso");
	var anversoAnterior = _i.tblCola_.cellValue(fila-1, "pr_ordenesproduccion.em_anverso");	
	if(anversoActual != anversoAnterior) {
		valor = _i.oRetardosMaq_.retardoAnverso;
	}
	
	return valor;

}

function oficial_calculaRetardoReverso(curO, fila)
{
	_i = this.iface;
	//em_reverso
	var valor = 0;
	var reversoActual = curO.valueBuffer("em_reverso");
	var reversoAnterior = _i.tblCola_.cellValue(fila-1, "pr_ordenesproduccion.em_reverso");	
	if(reversoActual != reversoAnterior) {
		valor = _i.oRetardosMaq_.retardoReverso;
	}
	
	return valor;

}	

function oficial_cargarArrayRecargos()
{
	_i = this.iface;

	if (_i.oRetardosMaq_ != undefined) {		
		_i.oRetardosMaq_ = undefined;		
	} 
	_i.oRetardosMaq_ = new Object;

	_i.oRetardosMaq_.retardoAca = [];
	_i.oRetardosMaq_.retardoTipo = [];
	_i.oRetardosMaq_.retardoAnverso = 0;
	_i.oRetardosMaq_.retardoReverso = 0;

	//var sSeccion = AQUtil----
	var codseccion = this.child("cbSeccion").currentText;
	

	/*--------------------------------Consulta a la familia--------------------------------------*/
	var q = new AQSqlQuery;
	q.setSelect("acabadoinicial,acabadofinal,retardoacabado,tipotejidoinicial,tipotejidofinal,retardotipotejido");
	q.setFrom("em_retardofam INNER JOIN familias ON familias.codfamilia = em_retardofam.codfamilia");
	q.setWhere("em_codseccion = '" + codseccion + "'");
	if (!q.exec()){	
		return;
	} 	
	var contfam=0;
	var acabado="a1";
	var tipoTejido="t1";
	while(q.next()) {
		contfam++;
		var acabadoInicial = q.value("acabadoinicial");
		var acabadoFinal = q.value("acabadofinal");
		acabado = acabadoInicial + _i.sep_ + acabadoFinal;
		_i.oRetardosMaq_.retardoAca[acabado] = q.value("retardoacabado");

		var tipotejidoInicial = q.value("tipotejidoinicial");
		var tipotejidoFinal = q.value("tipotejidofinal");
		tipoTejido = tipotejidoInicial + _i.sep_ + tipotejidoFinal;

		_i.oRetardosMaq_.retardoTipo[tipoTejido] = q.value("retardotipotejido");
		contfam++;

	}

	/*----------------------------------------------------------------------------------------*/

	/*--------------------------------Consulta a la maquina--------------------------------------*/
	var q = new AQSqlQuery;
	q.setSelect("retardoanverso,retardoreverso,acabadoinicial,acabadofinal,retardoacabado,tipotejidoinicial,tipotejidofinal,retardotipotejido");
	q.setFrom("em_retardomaquina");
	//q.setWhere("codmaquinacol = '" + codMaquina + "'");
	q.setWhere("codmaquinacol = '" + _i.codMaquina_ + "'");
	
	if (!q.exec()){	
		return;
	} 	
	var contmaq=0;
	acabado="a2";
	while(q.next()) {

		var acabadoInicial = q.value("acabadoinicial");
		var acabadoFinal = q.value("acabadofinal");
		acabado = acabadoInicial + _i.sep_ + acabadoFinal;
		_i.oRetardosMaq_.retardoAca[acabado] = q.value("retardoacabado");

		var tipotejidoInicial = q.value("tipotejidoinicial");
		var tipotejidoFinal = q.value("tipotejidofinal");
		tipoTejido = tipotejidoInicial + _i.sep_ + tipotejidoFinal;

		_i.oRetardosMaq_.retardoTipo[tipoTejido] = q.value("retardotipotejido");

		//reverso
		var retardoReverso = q.value("retardoreverso");
		if(retardoReverso && retardoReverso != "") {
		   _i.oRetardosMaq_.retardoReverso = retardoReverso;
		}
		//anverso
		var retardoAnverso = q.value("retardoanverso");
		if(retardoAnverso && retardoAnverso != "") {
			_i.oRetardosMaq_.retardoAnverso = retardoAnverso;
		}
		contmaq++;
	}	

}

function oficial_colorPendiente(f, c)
{
	
	var _i = this.iface;
	
	var color = new Color("white");
	var prepTejido= _i.tblPteConfirmar_.cellValue(f, "pr_tareas.estado"); 
	var paralizada= _i.tblPteConfirmar_.cellValue(f, "pr_ordenesproduccion.em_paralizada");
	if(paralizada == 'S') {
		color = new Color("grey");
	}	
	if(prepTejido == 'TERMINADA') {
		color = new Color(204, 255, 51);
	}
	if(_i.analizarPTE_ && c == 3) {	

		var codOrden =_i.tblPteConfirmar_.cellValue(f, "pr_ordenesproduccion.codorden");
		var resAF, resPR, resEX;
		var q = new AQSqlQuery;
		q.setSelect("SUM(reservaaf),SUM(reservaex),SUM(reservapr)");
		if(_i.tejidoPTE_) {
			q.setFrom("v_reservalotetej");
		} else {
			q.setFrom("v_reservaloteall");	
		}
		q.setWhere("codorden = '" + codOrden + "'"); 				
		if (!q.exec()){
			return;
		}  
		if(q.first())
		{
			resAF = q.value("SUM(reservaaf)");
			resPR = q.value("SUM(reservapr)");		
			resEX = q.value("SUM(reservaex)");		
		}
		if(resAF && resAF >0) {
			color = _i.colorNaranja_;
		} else if(resPR && resPR >0) {
			color = _i.colorAmarillo_;
		} else if(resEX && resEX >0) {
			color = _i.colorVerde_;
		} 
		if(_i.tejidoPTE_ && prepTejido == 'TERMINADA') {
			color = _i.colorAzul_;
		}
	}
	
	return color;
}
function oficial_colorConfirmado(f, c)
{			
	var _i = this.iface;
	//verde
	var color = new Color("white");
	var prepTejido= _i.tblConfirmado_.cellValue(f, "pr_tareas.estado"); 
	var paralizada= _i.tblConfirmado_.cellValue(f, "pr_ordenesproduccion.em_paralizada");
	if(paralizada == 'S') {
		color = new Color("grey");
	}
	if(_i.analizarCON_ && c == 3) {	
		
		var codOrden =_i.tblConfirmado_.cellValue(f, "pr_ordenesproduccion.codorden");
		var resAF, resPR, resEX;
		var q = new AQSqlQuery;
		q.setSelect("SUM(reservaaf),SUM(reservaex),SUM(reservapr)");
		if(_i.tejidoCON_) {
			q.setFrom("v_reservalotetejconf");
		} else {
			q.setFrom("v_reservaloteallconf");	
		}
		q.setWhere("codorden = '" + codOrden + "'"); 				
		if (!q.exec()){
			return;
		}  
		if(q.first())
		{
			resAF = q.value("SUM(reservaaf)");
			resPR = q.value("SUM(reservapr)");		
			resEX = q.value("SUM(reservaex)");		
		}
		if(resAF && resAF >0) {
			color = _i.colorNaranja_;
		} else if(resPR && resPR >0) {
			color = _i.colorAmarillo_;
		} else if(resEX && resEX >0) {
			color = _i.colorVerde_;
		} 
		if(_i.tejidoCON_ && prepTejido == 'TERMINADA') {
			color = _i.colorAzul_;
		}
	}
	
	return color;
}

function oficial_colorCola(f, c)
{			
	var _i = this.iface;
	//verde
	var color = new Color("white");
	var prepTejido= _i.tblCola_.cellValue(f, "pr_tareas.estado"); 
	if(_i.analizarCOLA_ && c == 4) {	
		
		var codOrden =_i.tblCola_.cellValue(f, "pr_ordenesproduccion.codorden");
		var resAF, resPR, resEX;
		var q = new AQSqlQuery;
		q.setSelect("SUM(reservaaf),SUM(reservaex),SUM(reservapr)");
		if(_i.tejidoCOLA_) {
			q.setFrom("v_reservalotetejcolab");
		} else {
			q.setFrom("v_reservaloteallcolab");	
		}
		q.setWhere("codorden = '" + codOrden + "'"); 				
		if (!q.exec()){
			return;
		}  
		if(q.first())
		{
			resAF = q.value("SUM(reservaaf)");
			resPR = q.value("SUM(reservapr)");		
			resEX = q.value("SUM(reservaex)");		
		}
		if(resAF && resAF >0) {
			color = _i.colorNaranja_;
		} else if(resPR && resPR >0) {
			color = _i.colorAmarillo_;
		} else if(resEX && resEX >0) {
			color = _i.colorVerde_;
		} 
		if(_i.tejidoCOLA_ && prepTejido == 'TERMINADA') {
			color = _i.colorAzul_;
		}
	}
	
	return color;
}

function oficial_tblPteConfirmar_doubleClicked(f, c)
{

	var _i = this.iface;
	var codOrden = _i.tblPteConfirmar_.cellValue(f, "pr_ordenesproduccion.codorden");
	if (!codOrden) {
		return false;
	}
	_i.curOrden_.select("codorden = '" + codOrden + "'");
	if (!_i.curOrden_.first()) {
		return false;
	}
	connect(_i.curOrden_, "bufferCommited()", _i.tblPteConfirmar_, "refreshCurrentRow");
	_i.curOrden_.editRecord();

}

function oficial_tblConfirmado_doubleClicked(f, c)
{
	var _i = this.iface;
	var codOrden = _i.tblConfirmado_.cellValue(f, "pr_ordenesproduccion.codorden");
	if (!codOrden) {
		return false;
	}
	_i.curOrden_.select("codorden = '" + codOrden + "'");
	if (!_i.curOrden_.first()) {
		return false;
	}
	connect(_i.curOrden_, "bufferCommited()", _i.tblConfirmado_, "refreshCurrentRow");
	_i.curOrden_.editRecord();
}

function oficial_tblCola_doubleClicked(f, c)
{

	var _i = this.iface;
	var codOrden = _i.tblCola_.cellValue(f, "pr_ordenesproduccion.codorden");
	if (!codOrden) {
		return false;
	}
	_i.curOrden_.select("codorden = '" + codOrden + "'");
	if (!_i.curOrden_.first()) {
		return false;
	}
	connect(_i.curOrden_, "bufferCommited()", _i.tblCola_, "refreshCurrentRow");
	_i.curOrden_.editRecord();
}


function oficial_tbnExcelColaAmp_clicked()
{
	var _i = this.iface;
	_i.exportaExcelCola(true);
}

function oficial_exportaExcelCola(ampliada)
{
	var _i = this.iface;
	_i.refresca();	
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec(); 

	var codSeccion = this.child("cbSeccion").currentText;
	
	flprodppal.iface.pub_excelColaProd(codSeccion, ampliada);
	
}

function oficial_pbnVerReservas_clicked()
{
	var _i = this.iface;
	var codOrden = _i.tblPteConfirmar_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden seleccionada."));
		return false;
	}	
	var tejido = this.child("chkTejido").checked;
	_i.verReservas("pendiente",codOrden, tejido);
}

function oficial_pbnVerReservasCon_clicked()
{
	var _i = this.iface;
	var codOrden = _i.tblConfirmado_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden seleccionada."));
		return false;
	}	
	var tejido = this.child("chkTejidoCon").checked;
	_i.verReservas("confirmada",codOrden, tejido);
}

function oficial_pbnVerReservasCola_clicked()
{
	var _i = this.iface;
	var codOrden = _i.tblCola_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden seleccionada."));
		return false;
	}	
	var tejido = this.child("chkTejidoCola").checked;
	_i.verReservas("cola",codOrden, tejido);
}

function oficial_verReservas(tabla,codOrden, tejido)
{
	var _i = this.iface;

	formem_reservasop.iface.codOrden_ = codOrden;	
	formem_reservasop.iface.tej_ = tejido;
	formem_reservasop.iface.tabla_ = tabla
	var fS = new FLFormSearchDB("em_reservasop");
	var curMS = fS.cursor();
	fS.setMainWidget();
	fS.exec("id");
	
}

function oficial_pbnAnalizar_clicked()
{
	var _i = this.iface;
	_i.tejidoPTE_ = this.child("chkTejido").checked;
	_i.analizarPTE_ = true;
	_i.filtraPteConfirmar();
	//_i.analizarPTE_ = false;	
}

function oficial_pbnAnalizarCon_clicked()
{
	var _i = this.iface;
	_i.tejidoCON_ = this.child("chkTejidoCon").checked;
	_i.analizarCON_ = true;
	_i.filtraConfirmado();
	//_i.analizarCON_ = false;	
}

function oficial_pbnAnalizarCola_clicked()
{

	var _i = this.iface;
	_i.tejidoCOLA_ = this.child("chkTejidoCola").checked;
	_i.analizarCOLA_ = true;
	_i.filtraCola();
	//_i.analizarCOLA_ = false;	
}

function oficial_iniciaColores()
{
	var _i = this.iface;
	_i.colorNaranja_ = new Color(flfactppal.iface.pub_dameColor("fondo_naranja"));
	_i.colorAmarillo_= new Color(flfactppal.iface.pub_dameColor("fondo_amarillo"));
	_i.colorVerde_ = new Color(flfactppal.iface.pub_dameColor("fondo_verde"));
	_i.colorAzul_ = new Color(flfactppal.iface.pub_dameColor("fondo_azul_claro"));
}

function oficial_controlCheckTejido() 
{
	/*var _i = this.iface;
	_i.tejidoPTE_ = this.child("chkTejido").checked;
	if(_i.tejidoPTE_) {
		_i.analizarPTE_ = false;
		_i.filtraPteConfirmar();		
	}*/		
}
function oficial_controlCheckTejidoCon() 
{
	/*var _i = this.iface;
	_i.tejidoCON_ = this.child("chkTejidoCon").checked;
	
	if(_i.tejidoCON_) {
		_i.analizarCON_ = false;
		_i.filtraConfirmado();
	}*/	
}
function oficial_controlCheckTejidoCola() 
{
	/*var _i = this.iface;
	_i.tejidoCOLA_ = this.child("chkTejidoCola").checked;
	if(_i.tejidoCOLA_) {
		_i.analizarCOLA_ = false;
		_i.filtraCola();		
	}*/	
}

function oficial_tbnRestaurarVista_toggled()
{	
	if (this.child("tbnRestaurarVista").on) {
		this.child("gbxIzquierda").show();
		this.child("gbxDerecha").show();
		this.child("tbnRestaurarVista").setDisabled(true);
		this.child("tbnAmpliarADerecha").on = false;
		this.child("tbnAmpliarAIzquierda").on = false;
	} else {
		this.child("tbnRestaurarVista").setDisabled(false);
	}
	
}
function oficial_tbnAmpliarADerecha_toggled()
{
	if (this.child("tbnAmpliarADerecha").on) {
		this.child("gbxIzquierda").show();
		this.child("gbxDerecha").close();
		this.child("tbnAmpliarADerecha").setDisabled(true);
		this.child("tbnRestaurarVista").on = false;
		this.child("tbnAmpliarAIzquierda").on = false;
	} else {
		this.child("tbnAmpliarADerecha").setDisabled(false);
	}
}
function oficial_tbnAmpliarAIzquierda_toggled()
{
	if (this.child("tbnAmpliarAIzquierda").on) {
		this.child("gbxIzquierda").close();
		this.child("gbxDerecha").show();
		this.child("tbnAmpliarAIzquierda").setDisabled(true);
		this.child("tbnRestaurarVista").on = false;
		this.child("tbnAmpliarADerecha").on = false;
	} else {
		this.child("tbnAmpliarAIzquierda").setDisabled(false);
	}
}
function oficial_pbnVerComponentes_clicked()
{
	var _i = this.iface;
	var codOrden = _i.tblPteConfirmar_.columnValue("pr_ordenesproduccion.codorden");
	if (!codOrden) {
		sys.warnMsgBox(sys.translate("No hay ninguna orden seleccionada."));
		return false;
	}	
	formem_reservascompop.iface.codOrden_ = codOrden;	
	var fS = new FLFormSearchDB("em_reservascompop");
	var curMS = fS.cursor();
	fS.setMainWidget();
	fS.exec("id");
}
function oficial_tbnImpPiezasRoll_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var fila = this.child("tblCola").currentRow();
	var codBobina =_i.tblCola_.cellValue(fila, "pr_ordenesproduccion.codpreparamat");
	var aBobinas = codBobina.split(",");

	var aBobina = aBobinas[0].split("/");
	codBobina = aBobina[aBobina.length-1];	

	if(!codBobina) {
		codBobina = "";
	}

	var aBobinaSop = _i.dameBobinaPiezasRoll(codBobina);
	if(!aBobinaSop) {
		return false;
	}


	var codBobina = aBobinaSop["codBobina"];
	if(!codBobina || codBobina == "" || codBobina =="undefined") {
		return true;
	}

	debug("codBobina: "+codBobina);
	formem_bobinas.iface.imprimirPiezasRollBob(codBobina);
	return true;
}
function oficial_pbnEncolar_clicked()
{
	var _i = this.iface;
	if(!_i.codMaquina_ || _i.codMaquina_ == "") {
		formUI.ponMsgWarn(sys.translate("Debe indicar antes la m�quina asociada a la cola"));
		return false;
	}
	var aBobinaSop = _i.dameBobinaPiezasRoll();
	if(!aBobinaSop) {
		return false;
	}
	if(!_i.controlOrdBobMaq(aBobinaSop["codBobina"],_i.codMaquina_)) {
		return false;
	} 

	var res = formUI.preguntaMsg(sys.translate("Ha elegido encolar las OPs no encoladas incluidas en el soporte/bobina %1 en la m�quina %2. �Es correcto?").arg(aBobinaSop["codSoporte"]+"/"+aBobinaSop["codBobina"]).arg(_i.codMaquina_), "info", this, MessageBox.Yes, MessageBox.No);
	if(res != MessageBox.Yes) {
		return false;
	}
	var ordenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.em_ordenprod");

	if(!_i.encolar(aBobinaSop["codBobina"],_i.codMaquina_,ordenCola)) {
		return false;
	}


	return true;
}

function oficial_dameBobinaPiezasRoll(codBobina)
{
	var _i = this.iface;
	var aFields = [];
	var oBobina = new Object;
	oBobina.field = "Bobina Piezas Rolladas";
	oBobina.type = "Text";
	oBobina.label = "Bobina o soporte: ";	
	var codBobinaPiezasRoll = "";
	var soportePiezasRoll = "";
	var aBobinaSop = new Object;
	if(codBobina && codBobina != "") {
		codBobinaPiezasRoll = codBobina;	
	}
	oBobina.value = codBobinaPiezasRoll;	
	aFields.push(oBobina);
	var aValues = flfactppal.iface.pub_createInputDialog("Selecciona bobina o soporte de piezas rolladas", aFields);
	var busqueda;
	var codSoporte;
	if(!aValues) {
		busqueda = false;
	}
	else {
		busqueda = aValues[0];
	}
	if (!busqueda || busqueda == "") {
		return false;
	} else {
		busqueda = busqueda.upper();
		if (busqueda.left(2) == "BB") {
			busqueda = fleumoesta.iface.pub_busquedaPunto(busqueda, 10);
		}

		var codBobina = AQUtil.sqlSelect("em_bobinas", "codbobina", "upper(codbobina) = '" + busqueda + "'");
		if (codBobina) {
			codBobinaPiezasRoll = codBobina;
		} else {
			codSoporte = AQUtil.sqlSelect("em_soportestextiles", "codigo", "upper(codigo) = '" + busqueda + "'");
			if (!codSoporte) {
				formUI.ponMsgWarn(sys.translate("La bobina o soporte indicado no existe"));				
				return false;
			}			
			codBobinaPiezasRoll = AQUtil.sqlSelect("em_soportestextiles", "bobinaactual", "codigo = '" + codSoporte + "'");			
			if (!codBobinaPiezasRoll || codBobinaPiezasRoll == "") {
				formUI.ponMsgWarn(sys.translate("El soporte %1 no tiene bobina asociada").arg(codSoporte));
				return false;
			}			
		}
		
	}
	// miramos si la bobina es de tipo piezas rolladas
	var estadoBobina = AQUtil.sqlSelect("em_bobinas", "estado", "codbobina = '" + codBobinaPiezasRoll + "'");
	if(estadoBobina != "PIEZAS ROLLADAS") {
		formUI.ponMsgWarn(sys.translate("La bobina %1 no es de tipo PIEZAS ROLLADAS").arg(codBobinaPiezasRoll));		
		return false;
	}
		
	soportePiezasRoll = AQUtil.sqlSelect("em_soportestextiles", "codigo", "bobinaactual = '" + codBobinaPiezasRoll + "'");
	
	if (!soportePiezasRoll || soportePiezasRoll =="")  {	
		var res = formUI.preguntaMsg(sys.translate("El soporte que estaba asociado a la bobina %1 de tipo PIEZAS ROLLADAS ya no est� asociado a la bobina, �Desea asociar un soporte libre bobina?").arg(codBobinaPiezasRoll), "info", this, MessageBox.Yes, MessageBox.No);		
		if (res != MessageBox.Yes) {				
			return false;
		}
		var f = new FLFormSearchDB("em_soportestextilesbus");
  		var curSoporte = f.cursor();
  		var mF = fleumoesta.iface.filtroSoportesLibres();
  		curSoporte.setMainFilter(mF);
  		f.setMainWidget();
  		soportePiezasRoll = f.exec("codigo");		
  		if(!soportePiezasRoll) {
			soportePiezasRoll = "";	
			formUI.ponMsgWarn(sys.translate("No se ha seleccionado un soporte a la bobina %1. Se cancela el proceso").arg(soportePiezasRoll));
			return false;
  		}
  		fleumoesta.iface.pub_asignaBobinaSoporte(codBobinaPiezasRoll, soportePiezasRoll);	
	}
	aBobinaSop["codBobina"] = codBobinaPiezasRoll;
	aBobinaSop["codSoporte"] = soportePiezasRoll;

	return aBobinaSop;

}


function oficial_pbnBobinaSal_clicked()
{
	var _i = this.iface;	
	var aFields = [];
	
	if(!_i.compruebaObligatorios()) {
		return false;
	}
	var oBobina = new Object;
	oBobina.field = "Bobina Salida";
	oBobina.type = "Text";
	oBobina.label = "Bobina o soporte: ";
	//var codBobina = _i.tblBobinas_.columnValue("em_bobinas.codbobina");
	var codBobina = "";
	oBobina.value = codBobina;	
	aFields.push(oBobina);

	var aValues = flfactppal.iface.pub_createInputDialog("Selecciona bobina o soporte de salida", aFields);
	var busqueda;
	var codSoporte;
	if(!aValues) {
		busqueda = false;
	}
	else {
		busqueda = aValues[0];
	}

	if (!busqueda || busqueda == "") {
		return false;
	} else {
		busqueda = busqueda.upper();
		if (busqueda.left(2) == "BB") {
			busqueda = fleumoesta.iface.pub_busquedaPunto(busqueda, 10);
		}

		var codBobina = AQUtil.sqlSelect("em_bobinas", "codbobina", "upper(codbobina) = '" + busqueda + "'");
		if (codBobina) {
			/*if(!_i.compBobinaLibre(codBobina)) {
				return false;
		 	}*/
			_i.codBobinaSAL_ = codBobina;
		} else {
			codSoporte = AQUtil.sqlSelect("em_soportestextiles", "codigo", "upper(codigo) = '" + busqueda + "'");
			if (!codSoporte) {
				sys.warnMsgBox(sys.translate("No se ha encontrado el soporte, bobina o partida %1").arg(busqueda));
				return false;
			}			
			codBobina = AQUtil.sqlSelect("em_soportestextiles", "bobinaactual", "codigo = '" + codSoporte + "'");			
			if (!codBobina) {
				//sys.warnMsgBox(sys.translate("El soporte %1 no tiene ninguna partida asociada").arg(codSoporte));
				//return false;
				//creamos y asignamos
				codBobina = fleumoesta.iface.pub_creaBobina("PIEZAS ROLLADAS");
				fleumoesta.iface.pub_asignaBobinaSoporte(codBobina, codSoporte);
			}
			/*if(!_i.compBobinaLibre(codBobina)) {
				return false;
		 	}*/
			_i.codBobinaSAL_ = codBobina;
		}
		
	}
	var estadoBobina = AQUtil.sqlSelect("em_bobinas", "estado", "codbobina = '" + _i.codBobinaSAL_ + "'");
	if(estadoBobina != "PIEZAS ROLLADAS") {
		sys.warnMsgBox(sys.translate("La bobina no es de tipo PIEZAS ROLLADAS"));
		//_i.limpiaDatos();
		return false;
	}

	if(_i.codBobinaSAL_  && _i.codBobinaSAL_ && (!codSoporte || codSoporte == "")) {		
		codSoporte = AQUtil.sqlSelect("em_soportestextiles", "codigo", "bobinaactual = '" + _i.codBobinaSAL_ + "'");
	}
	if (!codSoporte || codSoporte =="")  {
	
		var res = MessageBox.warning(sys.translate("El soporte que estaba asociado a la bobina %1 de tipo PIEZAS ROLLADAS ya no est� asociado a la bobina, �Desea asociar un soporte libre bobina?").arg(_i.codBobinaSAL_),MessageBox.Yes, MessageBox.No);
		if (res != MessageBox.Yes) {	
			//_i.limpiaDatos();		
			return false;
		}
		var f = new FLFormSearchDB("em_soportestextilesbus");
  		var curSoporte = f.cursor();
  		var mF = fleumoesta.iface.filtroSoportesLibres();
  		curSoporte.setMainFilter(mF);
  		f.setMainWidget();
  		codSoporte = f.exec("codigo");
		
  		if(!codSoporte) {
			codSoporte = "";	
			return false;
  		}

  		fleumoesta.iface.pub_asignaBobinaSoporte(_i.codBobinaSAL_, codSoporte);	
	}
	//_i.inicioRollado_ = false;
	//_i.limpiaDatosSalida();
	_i.muestraDatosSAL(codSoporte);	
}

function oficial_pbnDesEncolar_clicked()
{
	var _i = this.iface;
	if(!_i.codMaquina_ || _i.codMaquina_ == "") {
		formUI.ponMsgWarn(sys.translate("Debe indicar antes la m�quina asociada a la cola"));
		return false;
	}
	var aBobinaSop = _i.dameBobinaPiezasRoll();
	if(!aBobinaSop) {
		return false;
	}
	if(!_i.controlBobMaq(aBobinaSop["codBobina"],_i.codMaquina_)) {
		return false;
	} 
	var res = formUI.preguntaMsg(sys.translate("Ha elegido desencolar las OPs encoladas de la m�quina %1 incluidas en el soporte/bobina %2. �Es correcto?").arg(_i.codMaquina_).arg(aBobinaSop["codSoporte"]+"/"+aBobinaSop["codBobina"]), "info", this, MessageBox.Yes, MessageBox.No);
	if(res != MessageBox.Yes) {
		return false;
	}

	if(!_i.desencolar(aBobinaSop["codBobina"],_i.codMaquina_)) {
		return false;
	}


	return true;
}

function oficial_dameValorSoporteBB(q)
{	
	var codOrden = q.value("pr_ordenesproduccion.codorden");
	var res = "";
	var codBobina,soporte;
	var q = new AQSqlQuery;	
	q.setSelect("p.codbobinapiezaroll,b.soporteactual");
	q.setFrom("v_piezasrollbob p INNER JOIN em_bobinas b ON p.codbobinapiezaroll = b.codbobina");
	q.setWhere("p.codordenproduccion = '" + codOrden + "' GROUP BY p.codbobinapiezaroll,b.soporteactual");	
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{	
		codBobina = q.value("p.codbobinapiezaroll");
		soporte = q.value("b.soporteactual");		
		if(res != "") {
			res += ","
		}
		res += soporte+"/"+codBobina;
	}
	return res;

}

function oficial_damePorcTrex(q, confirmada)
{
	var codOrden = q.value("pr_ordenesproduccion.codorden");
	var tabla;
	if(confirmada) {
		tabla = "v_reservalotetejconf";
	} else {
		tabla = "v_reservalotetej";
	}
	var porc = 100 * parseFloat((AQUtil.sqlSelect(tabla,"SUM(reservaex)/SUM(cantidadtejido)", "codorden = '" + codOrden + "'")));	
	porc = AQUtil.roundFieldValue(porc, "pr_ordenesproduccion", "em_porctrex");
	return porc;
}

function oficial_damePorcCrex(q, confirmada)
{
	var codOrden = q.value("pr_ordenesproduccion.codorden");
	var tabla;
	if(confirmada) {
		tabla = "v_reservalotenotejconf";
	} else {
		tabla = "v_reservalotenotej";
	}
	var porc = 100 * parseFloat((AQUtil.sqlSelect(tabla,"SUM(reservaex)/SUM(cantidadcompo)", "codorden = '" + codOrden + "'")));	
	porc = AQUtil.roundFieldValue(porc, "pr_ordenesproduccion", "em_porctrex");
	return porc;
}

function oficial_controlOrdBobMaq(codBobina,codMaquina)
{
	var aOps = [];

	var q = new AQSqlQuery;	
	q.setSelect("p.codordenproduccion");
	q.setFrom("v_piezasrollbob p");
	q.setWhere("p.codbobinapiezaroll = '" + codBobina + "'");	
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{	
		aOps.push(q.value("p.codordenproduccion"));
	}

	var codMaquinaM = AQUtil.sqlSelect("pr_ordenesproduccion","em_codmaquinacol","em_codmaquinacol <> '" + codMaquina + "' AND codorden IN ('" +aOps.join("','") + "')");

	if(codMaquinaM && codMaquinaM != "") {
		var res = formUI.preguntaMsg(sys.translate("Una o m�s �rdenes asociadas a la bobina %1 est�n ya asociadas a la m�quina %2 �Desea continuar?").arg(codBobina).arg(codMaquinaM), "info", this, MessageBox.Yes, MessageBox.No);
		if(res != MessageBox.Yes) {
			return false;
		}
	}

	return true;
}

function oficial_encolar(codBobina, codMaquina,ordenCola)
{
	var _i = this.iface;
	debug("\n\nencolar");
	debug("ordenCola donde quiero insertar: "+ordenCola);
	debug("ORDEN DE LA ULTIMA FILA: "+_i.tblCola_.cellValue(this.child("tblCola").numRows()-1,"pr_ordenesproduccion.em_ordenprod"));
	var codOrden;
	var colaActual;
	var ordenColaN;

	/*if(ordenCola == _i.tblCola_.cellValue(this.child("tblCola").numRows()-1,"pr_ordenesproduccion.em_ordenprod")) {
		ordenColaN = ordenCola+1;
	} else {
		ordenColaN = ordenCola;
	}*/


	var codModOper,metrosPtes,prendasPtes,cantidadPte,minEstimados;
	//var ordenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.em_ordenprod");
	var q = new AQSqlQuery;	
	q.setSelect("p.codordenproduccion, op.em_codmaquinacol,op.em_codmodooper,op.metrosptes,op.udsptes");
	q.setFrom("v_piezasrollbob p INNER JOIN pr_ordenesproduccion op ON p.codordenproduccion = op.codorden");
	q.setWhere("p.codbobinapiezaroll = '" + codBobina + "' GROUP BY p.codordenproduccion, op.em_codmaquinacol,op.em_codmodooper,op.metrosptes,op.udsptes");
	//debug("*************************************qencolar: "+q.sql());	
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{	
		codOrden = q.value("p.codordenproduccion");
		colaActual = q.value("op.em_codmaquinacol");
		debug("---------------------------------------------------------");
		debug("codOrden: "+codOrden);	
		debug("colaActual: "+colaActual);


		if(colaActual && colaActual != "" && colaActual != codMaquina) {
			continue;
		} else {
			if(!colaActual || colaActual == "") {
				if (!AQSql.update("pr_ordenesproduccion", ["em_confirmada"], [true], "codorden = '" + codOrden + "'")) {
					return false;
				}

				if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_ordenprod = em_ordenprod + 1 WHERE " + _i.dameFiltroCola() + " AND em_ordenprod >= " + ordenCola)) {
					return false;
				}
			} 

			codModoOper = q.value("em_codmodooper");
			metrosPtes = q.value("metrosptes");
			prendasPtes = q.value("udsptes");
			if(_i.tipoProduccion_ == "Prendas") {
				cantidadPte = prendasPtes;
			} else {
				cantidadPte = metrosPtes;
			}
			minEstimados = _i.estimaMinutosProd(codModoOper,cantidadPte);

			//yo creo que hay que decir, si estoy marcando la ultima fila ser�a ordencola+1 y si no estoy marcando el ultimo seria ordencola.



			if (!AQSql.update("pr_ordenesproduccion", ["em_codmaquinacol", "em_ordenprod", "em_minprev"], [codMaquina, ordenCola, minEstimados], "codorden = '" + codOrden + "'")) {
				return false;
			}	
		}	
		//debug("---------------------------------------------------------\n\n");
	}
	_i.recalculaOrdenCola();
	_i.recalculaPrevision();	
	_i.calculaTiemposCola();	
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec(); 	
	_i.refresca();
	return true;
}

function oficial_controlBobMaq(codBobina,codMaquina)
{
	var aOps = [];

	var q = new AQSqlQuery;	
	q.setSelect("p.codordenproduccion");
	q.setFrom("v_piezasrollbob p");
	q.setWhere("p.codbobinapiezaroll = '" + codBobina + "'");	
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{	
		aOps.push(q.value("p.codordenproduccion"));
	}

	var codMaquinaM = AQUtil.sqlSelect("pr_ordenesproduccion","em_codmaquinacol","em_codmaquinacol = '" + codMaquina + "' AND codorden IN ('" +aOps.join("','") + "')");

	if(!codMaquinaM || codMaquinaM == "") {
		formUI.ponMsgWarn(sys.translate("No existen OPs con el Soporte/BB indicado en esta m�quina"));		
		return false;	
	}

	return true;
}

function oficial_desencolar(codBobina, codMaquina)
{
	var _i = this.iface;

	var codOrden;
	var colaActual;
	var codModOper,metrosPtes,prendasPtes,cantidadPte,minEstimados;
	var ordenCola = _i.tblCola_.columnValue("pr_ordenesproduccion.em_ordenprod");
	var q = new AQSqlQuery;	
	q.setSelect("p.codordenproduccion, op.em_codmaquinacol,op.em_codmodooper,op.metrosptes,op.udsptes");
	q.setFrom("v_piezasrollbob p INNER JOIN pr_ordenesproduccion op ON p.codordenproduccion = op.codorden");
	q.setWhere("p.codbobinapiezaroll = '" + codBobina + "' GROUP BY p.codordenproduccion, op.em_codmaquinacol,op.em_codmodooper,op.metrosptes,op.udsptes");
	//debug("*************************************qencolar: "+q.sql());	
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{	
		codOrden = q.value("p.codordenproduccion");
		colaActual = q.value("op.em_codmaquinacol");
		//debug("\n\n---------------------------------------------------------");
		//debug("codOrden: "+codOrden);	
		//debug("colaActual: "+colaActual);

		if(colaActual && colaActual != "" && colaActual == codMaquina) {		
			if (!AQUtil.sqlUpdate("pr_ordenesproduccion", "em_codmaquinacol,em_ordenprod,em_minprev", "NULL,NULL,NULL", "codorden = '" + codOrden + "'")) {
					return false;
			}		
		}	
		//debug("---------------------------------------------------------\n\n");
	}
	_i.recalculaOrdenCola();
	_i.recalculaPrevision();	
	_i.calculaTiemposCola();	
	_i.cargaDatosMaq(); 
	_i.cargaDatosSec(); 	
	_i.refresca();
	return true;
}

function oficial_dameOrderByPteConfirmar()
{
	return "pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.codorden";
}


function oficial_dameOrderByConfirmado()
{
	return "pr_ordenesproduccion.codorden DESC";
}

function oficial_dameOrderByCola()
{
	return "pr_ordenesproduccion.em_ordenprod";
}


//// OFICIAL  ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
