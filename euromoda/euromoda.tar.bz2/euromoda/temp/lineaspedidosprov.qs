
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod
{
	var tipoX_, eventWatcher_;
	function euromoda(context)
	{
		prod(context);
	}
	function init()
	{
		return this.ctx.euromoda_init();
	}
	function validaArticuloFabricado()
	{
		return this.ctx.euromoda_validaArticuloFabricado();
	}
	function bufferChanged(fN)
	{
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function ponFiltroPartida()
	{
		return this.ctx.euromoda_ponFiltroPartida();
	}
	function validateForm()
	{
		return this.ctx.euromoda_validateForm();
	}
	function validaPartida()
	{
		return this.ctx.euromoda_validaPartida();
	}
	function validaArticuloDeBaja() {
		return this.ctx.euromoda_validaArticuloDeBaja();
	}
	function validaDibujoProv()
	{
		return this.ctx.euromoda_validaDibujoProv();
	}
	function commonCalculateField(fN, cursor)
	{
		return this.ctx.euromoda_commonCalculateField(fN, cursor);
	}
	function pbnInsertarPlantillaTexto_clicked() {
		return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
	}
	function modoTexto() {
		return this.ctx.euromoda_modoTexto();
	}
	function commonBufferChanged(fN:String, miForm:Object) {
		return this.ctx.euromoda_commonBufferChanged(fN, miForm);
	}
	function habilitaTipoConcepto(miForm) {
		return this.ctx.euromoda_habilitaTipoConcepto(miForm);
	}
	function controlXPartidas() {
		return this.ctx.euromoda_controlXPartidas();
	}
	function habilitaControlesXPartidas() {
		return this.ctx.euromoda_habilitaControlesXPartidas();
	}	
	function totalesXPartidas() {
		return this.ctx.euromoda_totalesXPartidas();
	}
	function habilitaXPartidas() {
		return this.ctx.euromoda_habilitaXPartidas();
	}
	function calculaTipoX() {
		return this.ctx.euromoda_calculaTipoX();
	}
	function dameFiltroReferencia() {
		return this.ctx.euromoda_dameFiltroReferencia();
	}
	function initEventFilter()  {
		this.ctx.euromoda_initEventFilter();
	}
	function eventFilter(o, e)  {
		this.ctx.euromoda_eventFilter(o, e);
	}
	function initWatch(obj) {
		this.ctx.euromoda_initWatch(obj);
	}
	function finishWatch(obj)  {
		this.ctx.euromoda_finishWatch(obj);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_habilitaTipoConcepto(miForm) {
		return this.habilitaTipoConcepto(miForm);
	}
}
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_validaArticuloFabricado()
{
	return true;
}

function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (!cursor.cursorRelation()) { /// Por si se abre desde distribuci�n a confecciones
		this.close();
		return;
	}
	_i.__init();
	_i.ponFiltroPartida();
	
	connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");
	
	switch (cursor.modeAccess()) {
	case cursor.Edit: {
			sys.disableObj(this, "fdbTipoConcepto");
			break;
		}
	}
	
	_i.habilitaTipoConcepto(this);
	_i.modoTexto();
	_i.calculaTipoX()
	_i.habilitaControlesXPartidas();
	
	_i.initEventFilter();
	_i.initWatch(this.child("fdbReferencia").editor());
}

function euromoda_habilitaXPartidas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!cursor.valueBuffer("idlinea")) {
		return;
	}
	
	var hayMovXPartidas = AQUtil.quickSqlSelect("movistock", "idmovimiento", "idlineapp = " + cursor.valueBuffer("idlinea") + " AND codpartida IS NOT NULL");
	
	switch (_i.tipoX_) {
		// 		case "xpiezas": {
		// 			sys.disableObj(this, "fdbXPartidas");
		// 			break;
		// 		}
	case "xpiezas": 
	case "xpartidas": {
			if (hayMovXPartidas) {
				sys.disableObj(this, "fdbXPartidas");
			} else {
				sys.enableObj(this, "fdbXPartidas");
			}
			break;
		}
	default: {
			sys.disableObj(this, "fdbXPartidas");
		}
	}
	if (hayMovXPartidas) {
		sys.disableObj(this, "fdbReferencia");
	} else {
		sys.enableObj(this, "fdbReferencia");
	}
}

function euromoda_controlXPartidas()
{
debug("euromoda_controlXPartidas");
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (cursor.valueBuffer("xpartidas")) {
		_i.totalesXPartidas()
	} else {
		sys.setObjText(this, "fdbCerrada", false);
	}
	_i.habilitaControlesXPartidas();
}

function euromoda_habilitaControlesXPartidas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (cursor.valueBuffer("xpartidas")) {
		connect(this.child("tdbMoviStock").cursor(), "bufferCommited()", _i, "totalesXPartidas");
		this.child("tdbMoviStock").cursor().setAction("em_movistockpartidaspp");

		this.child("gbxMoviStock").setDisabled(false);
		this.child("fdbCantidad").setDisabled(true);
		sys.disableObj(this, "fdbCerrada");
	} else {
		this.child("gbxMoviStock").setDisabled(true);
		this.child("fdbCantidad").setDisabled(false);
		this.child("fdbReferencia").setDisabled(false);
		sys.enableObj(this, "fdbCerrada");
	}
}

function euromoda_totalesXPartidas()
{
debug("euromoda_totalesXPartidas");
	var _i = this.iface;
	sys.setObjText(this, "fdbCantidad", _i.calculateField("cantidadxpartidas"));
	sys.setObjText(this, "fdbCerrada", _i.calculateField("cerradaxpartidas"));
	_i.habilitaXPartidas();
}


function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
	case "referencia": {
			/// S�lo se calcula la descripci�n, el resto cuando se pierde el foco
			sys.setObjText(this, "fdbDescripcion", _i.calculateField("desarticulo"));
			break;
		}
	case "referenciaLostFocus": {
	debug("referenciaLostFocus");
			if (cursor.modeAccess() == cursor.Edit && cursor.valueBuffer("referencia") == cursor.valueBufferCopy("referencia")) {
				break;
			}
			_i.calculaTipoX();
			sys.setObjText(this, "fdbXPartidas", _i.commonCalculateField("xpartidas", cursor));
			_i.controlXPartidas();
			_i.__bufferChanged(fN);
			break;
		}
	case "xpartidas": {
		debug("xpartidas");
			_i.controlXPartidas();
			break;
		}
	case "cantidad": {
			_i.__bufferChanged(fN);
			_i.ponFiltroPartida();
			sys.setObjText(this, "fdbPendiente", _i.calculateField("pendiente"));
			debug("pendiente = " + _i.calculateField("pendiente"));
			break;
		}
	case "tipoconcepto": {
			_i.__bufferChanged(fN);
			_i.modoTexto();
			break;
		}
	default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_ponFiltroPartida()
{
	return;
	
	var cursor = this.cursor();
	/*
	var codProveedor = cursor.cursorRelation().valueBuffer("codproveedor");
	var codAlmacen = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codProveedor + "'");
	if (!codAlmacen) {
		codAlmacen = cursor.cursorRelation().valueBuffer("codalmacen");
	}
	*/
	var codAlmacen = cursor.cursorRelation().valueBuffer("codalmaorigen");
	if (!codAlmacen) {
		codAlmacen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
	}
	var cantidad = cursor.valueBuffer("cantidad");
	cantidad = isNaN(cantidad) ? 0 : cantidad;
	var filtro = "codalmacen = '" + codAlmacen + "' AND mptedist >= " + cantidad;
	debug("filtro " + filtro);
	this.child("fdbCodPartida").setFilter(filtro);
}

function euromoda_validateForm()
{
	var _i = this.iface;
	
	if (!_i.__validateForm()) {
		return false;
	}
	
	if (!_i.validaPartida()) {
		return false;
	}
	
	if (!_i.validaDibujoProv()) {
		return false;
	}
	
	if(!_i.validaArticuloDeBaja()) {
		return false;
	}
	
	return true;
}

function euromoda_validaArticuloDeBaja()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var referencia = cursor.valueBuffer("referencia");
	
	if(!referencia || referencia == "")
		return true;
	
	if (AQUtil.sqlSelect("articulos", "debaja", "referencia = '" + referencia + "'")) {
		var res = MessageBox.warning(sys.translate("El art�culo est� dado de baja, revise si es este art�culo realmente el que desea comprar"), MessageBox.Ok, MessageBox.Cancel, MessageBox.NoButton, "AbanQ");
		if(res != MessageBox.Ok)
			return false;		  
		return true;
	}
	
	if (AQUtil.sqlSelect("articulos", "descatalogado", "referencia = '" + referencia + "'")) {
		var res = MessageBox.warning(sys.translate("El art�culo est� descatalogado, revise si es este art�culo realmente el que desea comprar"), MessageBox.Ok, MessageBox.Cancel, MessageBox.NoButton, "AbanQ");
		if(res != MessageBox.Ok)
			return false;		  
		return true;
	}
	
	return true;
}

function euromoda_validaPartida()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var referencia = cursor.valueBuffer("referencia");
	/*if (!AQUtil.sqlSelect("articulos", "piezasem", "referencia = '" + referencia + "' AND em_tipoarticulo = 'Producto'")) {
		return true;
	}*/
	var codFamEstampado = flfactalma.iface.pub_valorDefectoAlmacen("codfamiliaestampado");
	if (!AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + referencia + "' AND codfamilia = '" + codFamEstampado + "'")) {
		return true;
	}
	var codPartida = cursor.valueBuffer("codpartida");
	if (!codPartida || codPartida == "") {
		MessageBox.warning(sys.translate("Debe establecer la partida de art�culo %1").arg(referencia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var codAlmacen = AQUtil.sqlSelect("lotesstock", "codalmacen", "codlote = '" + codPartida + "'");
	if (!codAlmacen || codAlmacen == "") {
		MessageBox.warning(sys.translate("La partida %1 no tiene almac�n asociado").arg(codPartida), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	
	return true;
}

function euromoda_validaDibujoProv()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var referencia = cursor.valueBuffer("referencia");
	if (!flfactalma.iface.pub_esReferenciaXPiezas(referencia) && !flfactalma.iface.pub_esReferenciaXPartidas(referencia)) {
		return true;
	}
	
	var codProvDibujo = AQUtil.sqlSelect("articulos a INNER JOIN em_dibujos d ON (a.coddibestamp = d.coddibujoem OR a.coddibjacquard = d.coddibujoem)", "d.codproveedor", "a.referencia = '" + referencia + "'", "articulos,em_dibujos");
	if (!codProvDibujo) {
		return true;
	}
	var codProveedor = cursor.cursorRelation().valueBuffer("codproveedor");
	if (codProveedor != codProvDibujo) {		
		var provDibujo = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProvDibujo + "'");
		var res = MessageBox.warning(sys.translate("El proveedor seleccionado no coincide con el proveedor asociado el dibujo del art�culo indicado (%1-%2).\n�Desea continuar?").arg(codProvDibujo).arg(provDibujo), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	
	return true;
}

function euromoda_calculaTipoX()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var referencia = cursor.valueBuffer("referencia");
	if (flfactalma.iface.pub_esReferenciaXPiezas(referencia)) {
		valor = true;
		_i.tipoX_ = "xpiezas";
	} else if (flfactalma.iface.pub_esReferenciaXPartidas(referencia)) {
		valor = cursor.valueBuffer("xpartidas");
		_i.tipoX_ = "xpartidas";
	} else {
		valor = false;
		_i.tipoX_ = "no";
	}
	_i.habilitaXPartidas();
}

function euromoda_commonCalculateField(fN, cursor)
{
	var util = new FLUtil();
	var _i = this.iface;
	var valor;
	
	switch (fN) {
	case "xpartidas": {
			_i.calculaTipoX();
			switch (_i.tipoX_) {
			case "xpiezas": {
					valor = true;
					break;
				}
			case "xpartidas": {
					valor = cursor.valueBuffer("xpartidas");
					break;
				}
			default: {
					valor = false;
				}
			}
			break;
		}
	case "cerradaxpartidas": {
			debug("Calcula cerradaxpartidas");
			if (AQUtil.sqlSelect("movistock", "idmovimiento", "idlineapp = " + cursor.valueBuffer("idlinea") + " AND NOT em_merma")) {
				valor = false;
			} else {
				valor = true;
			}
			debug("Valor " + valor);
			break;
		}
	case "cantidadxpartidas": {
			valor = AQUtil.sqlSelect("movistock", "SUM(canpedida)", "idlineapp = " + cursor.valueBuffer("idlinea"));
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
	case "pendiente": {
			valor = parseFloat(cursor.valueBuffer("cantidad")) - parseFloat(cursor.valueBuffer("totalenalbaran"));
			valor = valor < 0 ? 0 : valor;
			break;
		}
	case "desarticulo": {
			valor = AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + cursor.valueBuffer("referencia") + "'");
			//       valor = AQUtil.sqlSelect("articulos", "descripcion || (CASE WHEN codtamanoem IS NULL THEN '' ELSE (' ' || codtamanoem) END) || (CASE WHEN codcolorem IS NULL THEN '' ELSE (' ' || codcolorem) END)", "referencia = '" + cursor.valueBuffer("referencia") + "'");
			break;
		}
	case "destexto": {
			valor = "";
			var t = cursor.valueBuffer("texto");
			if (t && t != "") {
				var posRC = t.find("\n");
				if (posRC >= 0) {
					valor = t.left(posRC) + "...";
				} else {
					valor = t;
				}
			}
			break;
		}
	default: {
			valor = _i.__commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function euromoda_pbnInsertarPlantillaTexto_clicked()
{
	var f = new FLFormSearchDB("em_plantillastexto");
	f.setMainWidget();
	var texto = f.exec("texto");
	if (!texto) {
		return;
	}
	this.child("fdbTexto").setValue(texto);
}

function euromoda_modoTexto()
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (cursor.valueBuffer("tipoconcepto")) {
	case "Texto": {
			this.child("fdbReferencia").setValue("");
			this.child("fdbCantidad").setValue(0);
			this.child("fdbPvpUnitario").setValue(0);
			this.child("fdbCodImpuesto").setValue("");
			this.child("groupBox7").enabled = false;
			this.child("groupBox8").enabled = false;
			this.child("groupBox9").enabled = false;
			this.child("groupBox10").enabled = false;
			this.child("tbwLinea").setTabEnabled("texto", true);
			this.child("tbwLinea").showPage("texto");
			this.child("fdbTexto").setFocus();
			break;
		}
	default: {
			this.child("groupBox7").enabled = true;
			this.child("groupBox8").enabled = true;
			this.child("groupBox9").enabled = true;
			this.child("groupBox10").enabled = true;
			this.child("tbwLinea").showPage("movimientos");
			this.child("tbwLinea").setTabEnabled("texto", false);
			this.child("fdbTexto").setValue("");
			break;
		}
	}
}

function euromoda_commonBufferChanged(fN, miForm)
{
	var _i = this.iface;
	var cursor = miForm.cursor();
	switch (fN) {
	case "tipoconcepto": {
			_i.habilitaTipoConcepto(miForm);
			if (cursor.valueBuffer("tipoconcepto") == "Texto") {
				sys.setObjText(miForm, "fdbCodArancelario", "");
			}
			break;
		}
	case "referencia": {
			_i.__commonBufferChanged("referencia", miForm);
			sys.setObjText(miForm, "fdbDescripcion", _i.commonCalculateField("desarticulo", cursor));
			break;
		}
	case "texto": {
			sys.setObjText(miForm, "fdbDescripcion", _i.commonCalculateField("destexto", cursor));
			break;
		}
	default: {
			_i.__commonBufferChanged(fN, miForm);
		}
	}
}


function euromoda_habilitaTipoConcepto(miForm)
{
	var cursor = miForm.cursor();
	switch (cursor.valueBuffer("tipoconcepto")) {
	case "Producto": {
			//       miForm.child("fdbCodAmortizacion").close();
			//       miForm.child("fdbCodAmortizacion").setValue("");
			miForm.child("fdbReferencia").obj().show();
			if (miForm.child("fdbRefCliente")) {
				miForm.child("fdbRefCliente").obj().show();
			}
			miForm.child("fdbReferencia").setFocus();
			// 			miForm.child("fdbCodSubcuenta").setDisabled(true);
			break;
		}
	}
	miForm.child("fdbCantidad").setDisabled(false);
}

function euromoda_dameFiltroReferencia()
{
	var _i = this.iface;
	// 	var f = _i.__dameFiltroReferencia();
	var f = "NOT debaja";
	return f;
}

function euromoda_initEventFilter()
{
	var _i = this.iface;
	
	_i.eventWatcher_ = new QObject;
	_i.eventWatcher_.eventFilterFunction = this.name + ".iface.eventFilter";
	_i.eventWatcher_.allowedEvents = [ /**AQS.Enter, AQS.Leave AQS.FocusIn, */AQS.FocusOut/**, AQS.KeyPress*/];
}

function euromoda_eventFilter(o, e)
{
	var cursor = this.cursor();
	var _i = this.iface;
	var rtti = o.rtti();
	
	switch (e.type) {
	case AQS.FocusOut: {
			debug("o.parentWidget().name " + o.parentWidget().name)
					if (o.parentWidget().name == "fdbReferencia") {
				debug("va");
				_i.bufferChanged("referenciaLostFocus");
			}
			return true;
		}
	}
	return false;
}

function euromoda_initWatch(obj)
{
	if (obj == undefined)
		return;
	var _i = this.iface;
	obj.installEventFilter(_i.eventWatcher_);
}

function euromoda_finishWatch(obj)
{
	if (obj == undefined)
		return;
	var _i = this.iface;
	obj.removeEventFilter(_i.eventWatcher_);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
