/***************************************************************************
                 em_resumencortehor.qs  -  description
                             -------------------
    begin                : mar jun 5 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var usuarioActual_;
	var cREF, cDES, cTAM, cCOL, cLOT, cCPR, cCCO, cCC1;

	function oficial( context ) { interna( context ); }
	function cargaTabla() {
		return this.ctx.oficial_cargaTabla();
	}
	function iniciarTabla() {
		return this.ctx.oficial_iniciarTabla();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function terminaTareaCorte(oParam) {
		return this.ctx.oficial_terminaTareaCorte(oParam);
	}
	function terminaTarea(idTarea, usuario) {
		return this.ctx.oficial_terminaTarea(idTarea, usuario);
	}
	function gestionAlarmas(codOrden) {
		return this.ctx.oficial_gestionAlarmas(codOrden);
	}
	function muestraUsuarioActual() {
		return this.ctx.oficial_muestraUsuarioActual();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_gestionAlarmas(codOrden) {
		return this.gestionAlarmas(codOrden);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
	
	this.child("pushButtonAccept").close();
	this.child("pushButtonCancel").close();
	
	connect(this.child("tbnAceptar"), "clicked()", _i, "pushButtonAccept_clicked");
  connect(this.child("tbnCancelar"), "clicked()", this.child("pushButtonCancel"), "animateClick()");
	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	
// 	var t = this.child("tblLotes");
// 	connect(t, "clicked(int, int)", t, "editCell(int, int)");
  
	_i.muestraUsuarioActual();
	_i.iniciarTabla();
	_i.cargaTabla();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_muestraUsuarioActual()
{
	var _i = this.iface;
	_i.usuarioActual_ = formem_cortehor.iface.usuarioActual_;
	var usuario;
	if (_i.usuarioActual_) {
		var n = AQUtil.sqlSelect("flusers", "descripcion", "iduser = '" + _i.usuarioActual_ + "'");
		usuario = n + " (" + _i.usuarioActual_ + ")";
	} else {
		usuario = sys.translate("Usuario actual no establecido");
	}
	sys.setObjText(this, "lblUsuario", usuario);
}


function oficial_iniciarTabla()
{
  var _i = this.iface;

	var c = 0, cH = [];
  _i.cREF = c++;
  _i.cDES = c++;
  _i.cTAM = c++;
	_i.cCOL = c++;
  _i.cLOT = c++;
	_i.cCPR = c++;
  _i.cCCO = c++;
	_i.cCC1 = c++;

  cH[_i.cLOT] = sys.translate("Lote");
  cH[_i.cREF] = sys.translate("Ref.");
  cH[_i.cDES] = sys.translate("Producto");
	cH[_i.cTAM] = sys.translate("Tama�o");
  cH[_i.cCOL] = sys.translate("Color");
	cH[_i.cCPR] = sys.translate("Program.");
  cH[_i.cCCO] = sys.translate("Cortada");
	cH[_i.cCC1] = sys.translate("Cortada original");
  

  var t = this.child("tblLotes");
  t.setNumCols(c);
  t.setColumnWidth(_i.cLOT, 140);
  t.setColumnWidth(_i.cREF, 90);
  t.setColumnWidth(_i.cDES, 450);
	t.setColumnWidth(_i.cTAM, 130);
  t.setColumnWidth(_i.cCOL, 130);
  t.setColumnWidth(_i.cCPR, 100);
  t.setColumnWidth(_i.cCCO, 100);
	t.hideColumn(_i.cCC1);
	
	t.setColumnReadOnly(_i.cLOT, true);
	t.setColumnReadOnly(_i.cREF, true);
	t.setColumnReadOnly(_i.cDES, true);
	t.setColumnReadOnly(_i.cTAM, true);
	t.setColumnReadOnly(_i.cCOL, true);
	t.setColumnReadOnly(_i.cCPR, true);

  t.setColumnLabels("*", cH.join("*"));
}

function oficial_cargaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codOrden = cursor.valueBuffer("codorden");
	var t = this.child("tblLotes");
	
	var q = new AQSqlQuery;
	q.setSelect("ls.codlote, ls.referencia, ls.canprogramada, ls.canlote, a.descripcion, a.codtamanoem, a.codcolorem");
	q.setFrom("lotesstock ls INNER JOIN articulos a ON ls.referencia = a.referencia");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "'");
	if (!q.exec()) {
		return false;
	}
	var f = 0;
	while (q.next()) {
		t.insertRows(f);
		t.setRowHeight(f, 30);
		t.setText(f, _i.cLOT, q.value("ls.codlote"));
		t.setText(f, _i.cREF, q.value("ls.referencia"));
		t.setText(f, _i.cDES, q.value("a.descripcion"));
		t.setText(f, _i.cTAM, q.value("a.codtamanoem"));
		t.setText(f, _i.cCOL, q.value("a.codcolorem"));
		t.setText(f, _i.cCPR, q.value("ls.canprogramada"));
		t.setText(f, _i.cCCO, q.value("ls.canlote"));
		t.setText(f, _i.cCC1, q.value("ls.canlote"));
		f++;
	}
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var oParam = new Object;
  oParam.errorMsg = sys.translate("Error al terminar la tarea de corte horizontal");
  var f = new Function("oParam", "return formem_resumencortehor.iface.terminaTareaCorte(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  this.accept();
}

function oficial_terminaTareaCorte(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var t = this.child("tblLotes");
	var codOrden = cursor.valueBuffer("codorden");
	
	var idUsuario = formem_cortehor.iface.usuarioActual_;
	var codLote, canCortada;
	var oLote = new Object;
	for (var f = 0; f < t.numRows(); f++) {
		if (t.text(f, _i.cCCO) == t.text(f, _i.cCC1)) {
			continue;
		}
		codLote = t.text(f, _i.cLOT);
		oLote.idUsuario = idUsuario;
		canCortada = t.text(f, _i.cCCO);
		if (isNaN(canCortada)) {
			oParam.errorMsg = sys.translate("La cantidad indicada para el lote %1 no es v�lida").arg(codLote);
			return false;
		}
		oLote.canCortada = canCortada;
		oLote.codLote = codLote;
		oLote.estado = "CORTADO";
		oLote.codOrden = cursor.valueBuffer("codordenproduccion");
		if (!formem_cortehor.iface.pub_cortaLote(oLote)) {
			oParam.errorMsg = oLote.errorMsg;
			return false;
		}
	}
	var idTarea = AQUtil.sqlSelect("pr_tareas", "idtarea", "idobjeto = '" + codOrden + "' AND idtipotarea IN ('CO', 'J1') AND estado = 'PTE'");
	if (!idTarea) {
		oParam.errorMsg = sys.translate("No se ha encontrado una tarea de tipo CO o J1 en estado PTE para la orden %1").arg(codOrden);
		return false;
	}
	if (!_i.terminaTarea(idTarea, idUsuario)) {
		oParam.errorMsg = sys.translate("Error al terminar la tarea %1").arg(idTarea);
		return false;
	}
	
	if (!_i.gestionAlarmas(codOrden)) {
		oParam.errorMsg = sys.translate("Error al realizar la gesti�n de alarmas de material");
		return false;
	}
	return true;
}

function oficial_gestionAlarmas(codOrden)
{
debug("oficial_gestionAlarmas");
	var _i = this.iface;
	
	var listaSFLaminas = flfactalma.iface.pub_dameSubfamLaminas();
	if (!listaSFLaminas) {
		return false;
	}
	var qS = new AQSqlQuery;
	qS.setSelect("ms.idstock");
	qS.setFrom("lotesstock ls INNER JOIN movistock ms ON ls.codlote = ms.codloteprod INNER JOIN articulos a ON ms.referencia = a.referencia");
	qS.setWhere("ls.codordenproduccion = '" + codOrden + "' AND a.codsubfamilia IN (" + listaSFLaminas + ")");
	if (!qS.exec()) {
		return false;
	}
	while (qS.next()) {
		if (!flfactalma.iface.pub_revisarReservasStock(qS.value("ms.idstock"))) {
			return false;
		}
	}
	var q = new AQSqlQuery;
	q.setSelect("SUM(ms.reservaaf), ms.referencia, a.descripcion, a.codtamanoem, a.codcolorem");
	q.setFrom("lotesstock ls INNER JOIN movistock ms ON ls.codlote = ms.codloteprod INNER JOIN articulos a ON ms.referencia = a.referencia");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "' AND a.codsubfamilia IN (" + listaSFLaminas + ") GROUP BY ms.referencia, a.descripcion, a.codtamanoem, a.codcolorem");
debug(q.sql());
	if (!q.exec()) {
		return false;
	}
	var ahora = new Date;
	var curA = new FLSqlCursor("em_alarmasmat");
	var cantidad, desMaterial, referencia, canAnterior;
	var qAnt = new AQSqlQuery;
	qAnt.setSelect("idalarma, tipogestion, canpendiente");
	qAnt.setFrom("em_alarmasmat");
	
	while (q.next()) {
		canAnterior = 0;
		referencia = q.value("ms.referencia");
		cantidad = q.value("SUM(ms.reservaaf)");
		desMaterial = q.value("a.descripcion") + " " + q.value("a.codtamanoem") + " " + q.value("a.codcolorem");
		qAnt.setWhere("codorden = '" + codOrden + "' AND referencia = '" + referencia + "'");
		if (!qAnt.exec()) {
			return false;
		}
		if (qAnt.first()) {
			canAnterior = qAnt.value("canpendiente");
			if (cantidad != canAnterior) {
				if (qAnt.value("tipogestion") == "Pendiente") {
					curA.select("idalarma = " + qAnt.value("idalarma"));
					if (!curA.first()) {
						return false;
					}
					if (cantidad == 0) {
						curA.setModeAccess(curA.Del);
						curA.refreshBuffer();
					} else {
						curA.setModeAccess(curA.Edit);
						curA.refreshBuffer();
						curA.setValueBuffer("cantidad", cantidad);
						curA.setValueBuffer("canpendiente", cantidad);
					}
					if (!curA.commitBuffer()) {
						return false;
					}
				} else {
					if (cantidad > 0) {
						cantidad = cantidad - canAnterior;
						curA.setModeAccess(curA.Insert);
						curA.refreshBuffer();
						curA.setValueBuffer("codorden", codOrden);
						curA.setValueBuffer("fecha", ahora.toString().left(10));
						curA.setValueBuffer("hora", ahora.toString().right(8));
						curA.setValueBuffer("referencia", referencia);
						if (cantidad > 0) {
							curA.setValueBuffer("articulo", desMaterial);
						} else {
							curA.setValueBuffer("articulo", sys.translate("Revise o ignore l�mina %1 en orden %2 (+%3)").arg(desMaterial).arg(codOrden).arg(cantidad));
						}
						curA.setValueBuffer("cantidad", cantidad);
						curA.setValueBuffer("canpendiente", cantidad);
						if (!curA.commitBuffer()) {
							return false;
						}
					}
				}
			}
		} else {
			if (cantidad > 0) {
				debug("Insert");
				curA.setModeAccess(curA.Insert);
				curA.refreshBuffer();
				curA.setValueBuffer("codorden", codOrden);
				curA.setValueBuffer("fecha", ahora.toString().left(10));
				curA.setValueBuffer("hora", ahora.toString().right(8));
				curA.setValueBuffer("referencia", referencia);
				curA.setValueBuffer("articulo", desMaterial);
				curA.setValueBuffer("cantidad", cantidad);
				curA.setValueBuffer("canpendiente", cantidad);
				if (!curA.commitBuffer()) {
					return false;
				}
			}
		}
	}
	return true;
}

function oficial_terminaTarea(idTarea, usuario)
{
  var curTarea = new FLSqlCursor("pr_tareas");
  curTarea.select("idtarea = '" + idTarea + "'");
  if (!curTarea.first()) {
    return false;
  }
  if (!flcolaproc.iface.pub_iniciarTarea(curTarea, usuario)) {
    return false;
  }
  if (!flcolaproc.iface.pub_terminarTarea(curTarea)) {
    return false;
  }
  return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////