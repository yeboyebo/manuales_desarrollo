
/** @class_declaration euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial( context ); }
	function ordenarColumnas()  {
		return this.ctx.euromoda_ordenarColumnas();
	}	
}
//// EUROMODA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////////

function euromoda_ordenarColumnas()
{
	//cuando instalemos reoperado lo eliminamos del parche, lo escribimos aqu� para poder subirlo
	var t = this.child("tdbLineasOrdenEst");
  	var listaCampos;   
	listaCampos = ["referencia","tejido","consumo","cantidad","copias","canpendiente","canestampada","canrollada","canrolladapieza","canrolladasaldo","cancancelada","canmerma","canencurso","maquetado","ripeado","grupo","ordengrupo"];
	t.setOrderCols(listaCampos);

}
//// EUROMODA  ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
