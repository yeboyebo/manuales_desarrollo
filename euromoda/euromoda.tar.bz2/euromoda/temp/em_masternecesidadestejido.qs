/***************************************************************************
                 em_masternecesidadestejido.qs  -  description
                             -------------------
    begin                : lun jun 08 2015
    copyright            : (C) 2015 by YeboYebo S.L.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
		
	function oficial( context ) { interna( context ); }
	
	function ordenaCols() {
    return this.ctx.oficial_ordenaCols();
  }
	function marcaSeleccionado() {
    return this.ctx.oficial_marcaSeleccionado();
  }
  function seleccionarTodo(){
    return this.ctx.oficial_seleccionarTodo();
  }
  function deseleccionarTodo(){
    return this.ctx.oficial_deseleccionarTodo();
  }
  function imprimir(){
    return this.ctx.oficial_imprimir();
  }
  function lanzarInforme(q){
    return this.ctx.oficial_lanzarInforme(q);
  }
	function encabezadoInforme() {
		return this.ctx.oficial_encabezadoInforme();
	}
	function rellenaTablaBuffer() {
		return this.ctx.oficial_rellenaTablaBuffer();
	}
	function subfamRuta(nodo, campo) {
		return this.ctx.oficial_subfamRuta(nodo, campo);
	}
	function fechaServicio(nodo,campo) {
		return this.ctx.oficial_fechaServicio(nodo,campo);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
    
	function pub_encabezadoInforme() {
		return this.encabezadoInforme();
	}
	function pub_subfamRuta(nodo, campo) {
		return this.subfamRuta(nodo, campo);
	}
	function pub_fechaServicio(nodo, campo) {
		return this.fechaServicio(nodo, campo);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El Al copiar un art�culo se copian tambi�n sus tarifas y sus precios por proveedor.
\end */
function interna_init()
{
	var _i = this.iface;
	debug("init");
	//_i.ordenaCols();
	_i.marcaSeleccionado();
  connect(this.child("pbnSeleccionar"), "clicked()", _i, "seleccionarTodo");
	connect(this.child("pbnDeseleccionar"), "clicked()", _i, "deseleccionarTodo");
	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "imprimir");
	
	
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_ordenaCols()
{
	var oC = ["descripcion", "codsubfamilia"];
	this.child("tableDBRecords").setOrderCols(oC);
}

function oficial_marcaSeleccionado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var seleccionado = formem_stocktejidos.iface.pub_dameRegistroSeleccionado();
	
	debug("seleccionado: "+seleccionado);
	this.child("tableDBRecords").setPrimaryKeyChecked(seleccionado, true);
	
}

function oficial_seleccionarTodo()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
	var filtro = formem_stocktejidos.iface.pub_dameFiltro();

	debug("filtro al seleccionar todos: "+filtro);
  var q = new FLSqlQuery();
  //q.setSelect("subfamilias.codsubfamilia");
  q.setSelect("em_rutastpsubfam.idrutatp");  
  q.setFrom("subfamilias inner join em_rutastpsubfam on em_rutastpsubfam.codsubfamilia = subfamilias.codsubfamilia  inner join em_tipostejidoprep on em_tipostejidoprep.codtipotejidoprep = em_rutastpsubfam.codtipotejidoprep");
  q.setWhere(filtro);
	debug("consulta de todos: "+q.sql());
  if (!q.exec()){
    return;
	}
  while (q.next()) {
    //this.child("tableDBRecords").setPrimaryKeyChecked(q.value("subfamilias.codsubfamilia"), true);
    this.child("tableDBRecords").setPrimaryKeyChecked(q.value("em_rutastpsubfam.idrutatp"), true);
  }
  this.child("tableDBRecords").refresh();
}

function oficial_deseleccionarTodo()
{
  this.child("tableDBRecords").clearChecked();
  this.child("tableDBRecords").refresh();
}

function oficial_imprimir()
{
	var _i = this.iface;
	var cursor = this.cursor()
	
	_i.rellenaTablaBuffer();	
	
  var q = new FLSqlQuery("em_necesidadestejido");
  q.setWhere("idusuario = '" + sys.nameUser() + "'");
	
	_i.lanzarInforme(q);
	this.close();
}

function oficial_rellenaTablaBuffer() 
{
	var _i = this.iface;	
	var user =  sys.nameUser();
	var soloFaltas = this.child("chkSoloFaltas").checked;
	//1� eliminamos los datos por usuario y luego rellenamos
	
	AQUtil.sqlDelete("em_necesidadestejido_buffer", "idusuario = '" + user + "' ");
	
	var clavesSeleccionadas = this.child("tableDBRecords").primarysKeysChecked();
	clavesSeleccionadas = clavesSeleccionadas.join("','");	
	debug("claves seleccionadas: "+clavesSeleccionadas);	
	
	var sWhere = "em_rutastpsubfam.idrutatp in ('" + clavesSeleccionadas + "')";
	if(soloFaltas) {
		sWhere += " and me.reservaaf > 0";
	}
	
	var q = new AQSqlQuery;	
	//q.setSelect("em_rutastpsubfam.idrutatp, em_tipostejidoprep.codalmacen, em_rutastpsubfam.referencia, subfamilias.codsubfamilia, subfamilias.descripcion, em_rutastpsubfam.destipotejidoprep, p.codigo,p.nombrecliente, p.fechaservicio, SUM(me.cantidad), SUM(mt.reservaex), SUM(mt.reservapr), SUM(mt.reservaaf)");
	//q.setSelect("em_rutastpsubfam.idrutatp, em_tipostejidoprep.codalmacen, em_rutastpsubfam.referencia, subfamilias.codsubfamilia, subfamilias.descripcion, em_rutastpsubfam.destipotejidoprep, p.codigo,p.nombrecliente, p.fechaservicio, SUM(me.cantidad), SUM(me.reservaex), SUM(me.reservapr), SUM(me.reservaaf)");
	q.setSelect("em_rutastpsubfam.idrutatp, em_tipostejidoprep.codalmacen, em_rutastpsubfam.referencia, subfamilias.codsubfamilia, subfamilias.descripcion, em_rutastpsubfam.destipotejidoprep, p.codigo,p.nombrecliente, p.fechaservicio, SUM(mt.cantidad), SUM(mt.reservaex), SUM(mt.reservapr), SUM(mt.reservaaf)");
	q.setFrom("em_rutastpsubfam  INNER JOIN em_tipostejidoprep  ON em_rutastpsubfam.codtipotejidoprep = em_tipostejidoprep.codtipotejidoprep LEFT OUTER JOIN stocks ON (em_rutastpsubfam.referencia = stocks.referencia AND em_tipostejidoprep.codalmacen = stocks.codalmacen) INNER JOIN subfamilias ON em_rutastpsubfam.codsubfamilia = subfamilias.codsubfamilia INNER JOIN movistock mt ON stocks.idstock = mt.idstock INNER JOIN movistock me ON me.idmovimiento = mt.idmovtejidopadre INNER JOIN movistock mp ON (me.idmovproducto = mp.idmovimiento or me.idmovimiento=mp.idmovimiento) INNER JOIN lineaspedidoscli lp ON mp.idlineapc = lp.idlinea INNER JOIN pedidoscli p ON lp.idpedido = p.idpedido INNER JOIN articulos tej ON (tej.referencia = me.referencia and subfamilias.codsubfamilia = tej.codsubfamilia)");
	q.setWhere(sWhere + " group by em_rutastpsubfam.idrutatp, em_tipostejidoprep.codalmacen, em_rutastpsubfam.referencia, subfamilias.codsubfamilia, subfamilias.descripcion, em_rutastpsubfam.destipotejidoprep, p.codigo, p.nombrecliente, p.fechaservicio"); 			
	debug("consulta: "+q.sql());
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idRutaTP = q.value("em_rutastpsubfam.idrutatp");
		var codAlmacen = q.value("em_tipostejidoprep.codalmacen");
		var referencia = q.value("em_rutastpsubfam.referencia");		
		var codSubfamilia = q.value("subfamilias.codsubfamilia");
		var descSubfam = q.value("subfamilias.descripcion");
		var descTipoTej = q.value("em_rutastpsubfam.destipotejidoprep");
		var codPedidoCli = q.value("p.codigo");
		var nombreCliente = q.value("p.nombrecliente");
		var fechaServicio = q.value("p.fechaservicio");
		//var cantidad = q.value("SUM(me.cantidad)")*(-1);
		/*var reservaEX = q.value("SUM(mt.reservaex)");
		var reservaPR = q.value("SUM(mt.reservapr)");
		var reservaAF = q.value("SUM(mt.reservaaf)");*/
		
		/*var reservaEX = q.value("SUM(me.reservaex)");
		var reservaPR = q.value("SUM(me.reservapr)");
		var reservaAF = q.value("SUM(me.reservaaf)");*/
		
		var cantidad = q.value("SUM(mt.cantidad)")*(-1);
		var reservaEX = q.value("SUM(mt.reservaex)");
		var reservaPR = q.value("SUM(mt.reservapr)");
		var reservaAF = q.value("SUM(mt.reservaaf)");
		
		var curNecTej = new FLSqlCursor("em_necesidadestejido_buffer");
  		curNecTej.setModeAccess(curNecTej.Insert);
  		curNecTej.refreshBuffer(); 
  		curNecTej.setValueBuffer("idrutatp",idRutaTP);
  		curNecTej.setValueBuffer("codalmacen",codAlmacen);
  		curNecTej.setValueBuffer("referencia",referencia);
  		curNecTej.setValueBuffer("codsubfamilia",codSubfamilia);
  		curNecTej.setValueBuffer("descsubfam",descSubfam);
  		curNecTej.setValueBuffer("destipotejidoprep",descTipoTej);
  		curNecTej.setValueBuffer("codigo",codPedidoCli);
  		curNecTej.setValueBuffer("nombrecliente",nombreCliente);
  		curNecTej.setValueBuffer("fechaservicio",fechaServicio);
  		curNecTej.setValueBuffer("cantotal",cantidad);
  		curNecTej.setValueBuffer("reservaex",reservaEX);
  		curNecTej.setValueBuffer("reservapr",reservaPR);
  		curNecTej.setValueBuffer("reservaaf",reservaAF);
  		curNecTej.setValueBuffer("idusuario",user);
  		curNecTej.setValueBuffer("tipo","PC");
  		
      if (!curNecTej.commitBuffer()) {
      	return false;
    	}	
	}
	var sWhereOE = "em_rutastpsubfam.idrutatp in ('" + clavesSeleccionadas + "')";
	if(soloFaltas) {
		sWhereOE += " and mt.reservaaf > 0";
	}
	
	var q = new AQSqlQuery;	
	q.setSelect("em_rutastpsubfam.idrutatp, em_tipostejidoprep.codalmacen, em_rutastpsubfam.referencia, subfamilias.codsubfamilia, subfamilias.descripcion, em_rutastpsubfam.destipotejidoprep, oe.codordenest,oe.descripcion, oe.fechaentrega, SUM(mt.cantidad), SUM(mt.reservaex), SUM(mt.reservapr), SUM(mt.reservaaf)");	
	//q.setFrom("em_rutastpsubfam  INNER JOIN em_tipostejidoprep  ON em_rutastpsubfam.codtipotejidoprep = em_tipostejidoprep.codtipotejidoprep LEFT OUTER JOIN stocks ON (em_rutastpsubfam.referencia = stocks.referencia AND em_tipostejidoprep.codalmacen = stocks.codalmacen) INNER JOIN subfamilias ON em_rutastpsubfam.codsubfamilia = subfamilias.codsubfamilia INNER JOIN movistock mt ON stocks.idstock = mt.idstock INNER JOIN movistock me ON me.idmovimiento = mt.idmovtejidopadre INNER JOIN em_lineasordenest lo ON me.emidlineaest = lo.idlinea INNER JOIN em_ordenesestampacion oe ON oe.codordenest = lo.codordenest  INNER JOIN articulos tej ON (tej.referencia = me.referencia and subfamilias.codsubfamilia = tej.codsubfamilia)");
	q.setFrom("em_rutastpsubfam  INNER JOIN em_tipostejidoprep  ON em_rutastpsubfam.codtipotejidoprep = em_tipostejidoprep.codtipotejidoprep LEFT OUTER JOIN stocks ON (em_rutastpsubfam.referencia = stocks.referencia AND em_tipostejidoprep.codalmacen = stocks.codalmacen) INNER JOIN subfamilias ON em_rutastpsubfam.codsubfamilia = subfamilias.codsubfamilia INNER JOIN movistock mt ON stocks.idstock = mt.idstock INNER JOIN movistock me ON me.idmovimiento = mt.idmovtejidopadre INNER JOIN em_lineasordenest lo ON me.emidlineaest = lo.idlinea INNER JOIN em_ordenesestampacion oe ON oe.codordenest = lo.codordenest  LEFT OUTER JOIN articulos tej ON (tej.referencia = me.referencia and subfamilias.codsubfamilia = tej.codsubfamilia)");
	q.setWhere(sWhereOE + " group by em_rutastpsubfam.idrutatp, em_tipostejidoprep.codalmacen, em_rutastpsubfam.referencia, subfamilias.codsubfamilia, subfamilias.descripcion, em_rutastpsubfam.destipotejidoprep, oe.codordenest,oe.descripcion, oe.fechaentrega"); 		
	debug("consulta: "+q.sql());
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idRutaTP = q.value("em_rutastpsubfam.idrutatp");
		var codAlmacen = q.value("em_tipostejidoprep.codalmacen");
		var referencia = q.value("em_rutastpsubfam.referencia");		
		var codSubfamilia = q.value("subfamilias.codsubfamilia");
		var descSubfam = q.value("subfamilias.descripcion");
		var descTipoTej = q.value("em_rutastpsubfam.destipotejidoprep");
		var codOrdenEst = q.value("oe.codordenest");
		var descOrden = q.value("oe.descripcion");
		var fechaEntrega = q.value("oe.fechaentrega");
		var cantidad = q.value("SUM(mt.cantidad)")*(-1);
		var reservaEX = q.value("SUM(mt.reservaex)");
		var reservaPR = q.value("SUM(mt.reservapr)");
		var reservaAF = q.value("SUM(mt.reservaaf)");

		
		var curNecTej = new FLSqlCursor("em_necesidadestejido_buffer");
  		curNecTej.setModeAccess(curNecTej.Insert);
  		curNecTej.refreshBuffer(); 
  		curNecTej.setValueBuffer("idrutatp",idRutaTP);
  		curNecTej.setValueBuffer("codalmacen",codAlmacen);
  		curNecTej.setValueBuffer("referencia",referencia);
  		curNecTej.setValueBuffer("codsubfamilia",codSubfamilia);
  		curNecTej.setValueBuffer("descsubfam",descSubfam);
  		curNecTej.setValueBuffer("destipotejidoprep",descTipoTej);
  		curNecTej.setValueBuffer("codigo",codOrdenEst);
  		curNecTej.setValueBuffer("nombrecliente",descOrden);
  		curNecTej.setValueBuffer("fechaservicio",fechaEntrega);
  		curNecTej.setValueBuffer("cantotal",cantidad);
  		curNecTej.setValueBuffer("reservaex",reservaEX);
  		curNecTej.setValueBuffer("reservapr",reservaPR);
  		curNecTej.setValueBuffer("reservaaf",reservaAF);
  		curNecTej.setValueBuffer("idusuario",user);
  		curNecTej.setValueBuffer("tipo","OE");
  		
      if (!curNecTej.commitBuffer()) {
      	return false;
    	}	
	}	
	
	//sacamos por subfamilia-almacen el subtotal
	
	var q = new AQSqlQuery;	
	q.setSelect("SUM(cantotal),SUM(reservaex),SUM(reservapr),SUM(reservaaf),idrutatp");
	q.setFrom("em_necesidadestejido_buffer");
	q.setWhere("idusuario = '" + user + "'  group by idrutatp"); 		
	debug("consulta: "+q.sql());
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var totalCanTotal = q.value("SUM(cantotal)");
		var totalReservaEX = q.value("SUM(reservaex)");
		var totalReservaPr = q.value("SUM(reservapr)");
		var totalReservaAF = q.value("SUM(reservaaf)");
		var idRutaTP = q.value("idrutatp");
		AQSql.update("em_necesidadestejido_buffer", ["totalcantotal","totalreservaex","totalreservapr","totalreservaaf"], [totalCanTotal,totalReservaEX,totalReservaPr,totalReservaAF], "idrutatp = "  + idRutaTP);
	}
		

}


function oficial_lanzarInforme(q)
{
	var rptViewer = new FLReportViewer();
	rptViewer.setReportData(q);
	rptViewer.setReportTemplate("em_necesidadestejido");
	rptViewer.renderReport();
	rptViewer.exec();
}

function oficial_encabezadoInforme()
{
	var hoy = new Date();
	var hora = hoy.toString().right(8);
	
	var texto = "Usuario: " + sys.nameUser() + "     Fecha: " + AQUtil.dateAMDtoDMA(hoy) + "  Hora: " + hora;
	
	return texto;
}

function oficial_subfamRuta(nodo, campo) 
{
	var valor = "";
	var descSubfam = nodo.attributeValue("em_necesidadestejido_buffer.descsubfam");
	var descRuta = nodo.attributeValue("em_necesidadestejido_buffer.destipotejidoprep");
	
	valor = descSubfam+" "+descRuta;
	return valor;

}

function oficial_fechaServicio(nodo,campo)
{	
	var tipo = nodo.attributeValue("em_necesidadestejido_buffer.tipo");
	var valor = "";

	if(tipo== "PC" && campo == "PC") {
		valor = nodo.attributeValue("em_necesidadestejido_buffer.fechaservicio");	
	} else if (tipo == "OE" && campo =="OE") {
		valor = nodo.attributeValue("em_necesidadestejido_buffer.fechaservicio");	
	}
	
	return valor;

}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////
