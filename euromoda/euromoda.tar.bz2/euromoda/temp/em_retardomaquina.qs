/***************************************************************************
                 em_retardomaquina.qs  -  description
                             -------------------
    begin                : mar abr 25 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function validateForm():Boolean { return this.ctx.interna_validateForm(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); } 
	function filtrarAcabados() {
		return this.ctx.oficial_filtrarAcabados();
	}
	function dameFiltroAcabadosFam() {
		return this.ctx.oficial_dameFiltroAcabadosFam();
	} 
	function validaAcabados() {
		return this.ctx.oficial_validaAcabados();
	}
	function validaAlias() {
		return this.ctx.oficial_validaAlias();
	}	
	function validaRetardos() {
		return this.ctx.oficial_validaRetardos();
	}
	function dameFiltroAliasFam() {
		return this.ctx.oficial_dameFiltroAliasFam();
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();

  _i.filtrarAcabados();  
 
}

function interna_validateForm()
{
	var _i = this.iface;

	if(!_i.validaAcabados()) {
		return false;
	}
	if(!_i.validaAlias()) {
		return false;
	}
	if(!_i.validaRetardos()) {
		return false;
	}
	return true;
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_filtrarAcabados()
{
	var _i = this.iface;


	var filtroAcabadosFam = _i.dameFiltroAcabadosFam();	
	this.child("fdbAcabadoInicial").setFilter(filtroAcabadosFam);
	this.child("fdbAcabadoFinal").setFilter(filtroAcabadosFam);

	var filtroAliasFam = _i.dameFiltroAliasFam();	
	this.child("fdbTipTejidoInicial").setFilter(filtroAliasFam);
	this.child("fdbTipTejidoFinal").setFilter(filtroAliasFam);
}

function oficial_dameFiltroAcabadosFam()
{
	var _i = this.iface;	

	var filtro = "1=2"
	var cursor = this.cursor();	
	var codMaquinacol = cursor.valueBuffer("codmaquinacol");
	var codSeccionMaq=AQUtil.sqlSelect("em_maquinascol","codseccion", "codmaquinacol = '" + codMaquinacol + "'");	
	
	if(codSeccionMaq && codSeccionMaq != "") {
	 	filtro = "codfamilia IN (SELECT codfamilia from familias where em_codseccion = '" + codSeccionMaq + "')";
	}
	debug("filtro: "+filtro);
	return filtro;
}

function oficial_dameFiltroAliasFam()
{
	return "";

	/*var _i = this.iface;
	var filtro = "1=2"
	var cursor = this.cursor();	
	var codMaquinacol = cursor.valueBuffer("codmaquinacol");
	var codSeccionMaq=AQUtil.sqlSelect("em_maquinascol","codseccion", "codmaquinacol = '" + codMaquinacol + "'");	
	if(codSeccionMaq && codSeccionMaq != "") {
	 	filtro = "alias IN (SELECT em_alias FROM subfamilias WHERE em_codseccion = '" + codSeccionMaq + "')";
	}
	return filtro;*/
}

function oficial_validaAcabados()
{
	var cursor = this.cursor();

	//que no tenga un registro ya en la tabla
	var id = cursor.valueBuffer("id");
	var acabadoIni = cursor.valueBuffer("acabadoinicial");
	var acabadoFin = cursor.valueBuffer("acabadofinal"); 
	var codMaquinacol = cursor.valueBuffer("codmaquinacol");
	var retardoAcabado  = cursor.valueBuffer("retardoacabado");

	if((!acabadoIni ||  acabadoIni == "") && (!acabadoFin ||  acabadoFin == "") && (!retardoAcabado || retardoAcabado == 0)) {
		return true;
	} 

	if(!acabadoIni ||  acabadoIni == "") {
		sys.warnMsgBox(sys.translate("El campo Acabado inicial es obligatorio si ha informado Acabado final o Retardo de acabado."));
		return false;
	}
	if(!acabadoFin ||  acabadoFin == "") {
		sys.warnMsgBox(sys.translate("El campo Acabado final es obligatorio si ha informado Acabado inicial o Retardo de acabado."));
		return false;
	}
	if(!retardoAcabado || retardoAcabado == 0) {
		sys.warnMsgBox(sys.translate("El campo Retardo acabado es obligatorio si ha informado Acabado inicial y Acabado final."));
		return false;
	}


	if(AQUtil.sqlSelect("em_retardomaquina","count(*)","acabadoinicial = '" + acabadoIni + "' and acabadofinal = '" + acabadoFin + "' and id <>  " + id )>0) {
		sys.warnMsgBox(sys.translate("Ya hay un registro con acabado inicial %1 y acabado final %2").arg(acabadoIni).arg(acabadoFin));
		return false;
	}
	/*----------------------------------------------------------------------------*/
	//acabado inicial y final, pernececer familias por la seccion de maquinas

	//saco codseccion de em_maquinascol
	debug("codMaquinacol "+codMaquinacol);
	var codSeccMaquCol=AQUtil.sqlSelect("em_maquinascol","codseccion", "codmaquinacol = '" + codMaquinacol + "'");

	if(!AQUtil.sqlSelect("em_acabadosfam","acabado","codfamilia IN (SELECT codfamilia from familias where em_codseccion = '" + codSeccMaquCol + "') and acabado = '" + acabadoIni + "'")) {

		sys.warnMsgBox(sys.translate("El acabado inicial %1 no pertenece a ninguna familia asociada a la secci�n %2 asocida a la m�quina").arg(acabadoIni).arg(codSeccMaquCol));

		return false;
	}	

	if(!AQUtil.sqlSelect("em_acabadosfam","acabado","codfamilia IN (SELECT codfamilia from familias where em_codseccion = '" + codSeccMaquCol + "') and acabado = '" + acabadoFin + "'")) {

		sys.warnMsgBox(sys.translate("El acabado final %1 no pertenece a ninguna familia asociada a la secci�n %2 asocida a la m�quina").arg(acabadoFin).arg(codSeccMaquCol));

		return false;
	}	



	/*----------------------------------------------------------------------------*/


	return true;
}

function oficial_validaAlias()
{
	var cursor = this.cursor();

	
	var id = cursor.valueBuffer("id");
	var aliasIni = cursor.valueBuffer("tipotejidoinicial");
	var aliasFin = cursor.valueBuffer("tipotejidofinal"); 
	var codMaquinacol = cursor.valueBuffer("codmaquinacol");
	var retardoTejido = cursor.valueBuffer("retardotipotejido");
	var acabadoInicial = cursor.valueBuffer("acabadoinicial");
	var acabadoFinal = cursor.valueBuffer("acabadofinal");

	debug("////////el tipo tejido es"+aliasIni+"   "+aliasFin);
	debug("////////el retardo"+retardoTejido);

	if((!aliasIni ||  aliasIni == "") && (!aliasFin ||  aliasFin == "") && (!retardoTejido || retardoTejido == 0)) {
		return true;
	} 

	if(!aliasIni ||  aliasIni == "") {
		sys.warnMsgBox(sys.translate("El campo Tejido inicial es obligatorio si ha informado Tejido final o Retardo de acabado."));
		return false;
	}
	if(!aliasFin ||  aliasFin == "") {
		sys.warnMsgBox(sys.translate("El campo Tejido final es obligatorio si ha informado Tejido inicial o Retardo de acabado."));
		return false;
	}
	if(!retardoTejido || retardoTejido == 0) {
		sys.warnMsgBox(sys.translate("El campo Retardo acabado es obligatorio si ha informado Tejido inicial y Tejido final."));
		return false;
	}
      


	//que no tenga un registro ya en la tabla
	//if(AQUtil.sqlSelect("em_retardomaquina","count(*)","tipotejidoinicial = '" + aliasIni + "' and tipotejidofinal = '" + aliasFin + "' and id <>  " + id )>0) {
	if(AQUtil.sqlSelect("em_retardomaquina","count(*)","codmaquinacol = '" + codMaquinacol + "' and acabadoinicial = '" + acabadoInicial + "' and acabadofinal = '" + acabadoFinal + "'  and tipotejidoinicial = '" + aliasIni + "' and tipotejidofinal = '" + aliasFin + "' and id <>  " + id )>0) {
		sys.warnMsgBox(sys.translate("Ya hay un registro con tipo tejido inicial %1 y tipo tejido final %2").arg(aliasIni).arg(aliasFin));
		return false;
	}


	/*----------------------------------------------------------------------------*/
	//tejido inicial y final, pernececer subfamilias por la seccion de maquinas
	//saco codseccion de em_maquinascol
	
	/* Comentado a petici�n Jose 20/07/17
	var codSeccMaquCol=AQUtil.sqlSelect("em_maquinascol","codseccion", "codmaquinacol = '" + codMaquinacol + "'");	
	if(!AQUtil.sqlSelect("subfamilias","em_alias"," em_codseccion = '" + codSeccMaquCol + "' and em_alias = '" + aliasIni + "'")) {		

		sys.warnMsgBox(sys.translate("El tipo tejido inicial %1 no pertenece a ninguna subfamilia de la secci�n %2 asociada a la m�quina").arg(aliasIni).arg(codSeccMaquCol));

		return false;
	}
	if(!AQUtil.sqlSelect("subfamilias","em_alias"," em_codseccion = '" + codSeccMaquCol + "' and em_alias = '" + aliasFin + "'")) {		

		sys.warnMsgBox(sys.translate("El tipo tejido final %1 no pertenece a ninguna subfamilia de la secci�n %2 asociada a la m�quina").arg(aliasFin).arg(codSeccMaquCol));

		return false;
	}
	*/
	return true;
}

function oficial_validaRetardos()
{
	var cursor = this.cursor();

	var id = cursor.valueBuffer("id");
	var codMaquinacol = cursor.valueBuffer("codmaquinacol");
	var retardoAnverso = cursor.valueBuffer("retardoanverso");
	var retardoReverso = cursor.valueBuffer("retardoreverso");

	if(retardoAnverso && retardoAnverso != 0) {
		if(AQUtil.sqlSelect("em_retardomaquina","count(*)","codmaquinacol = '" + codMaquinacol + "' and retardoanverso <>0 and id <>  " + id )>0 ) {
			sys.warnMsgBox(sys.translate("Ya hay un registro con retardo anverso informado para la maquina %1").arg(codMaquinacol));
			return false;
		}
	}

	if(retardoReverso && retardoReverso != 0) {

		if(AQUtil.sqlSelect("em_retardomaquina","count(*)","codmaquinacol = '" + codMaquinacol + "' and retardoreverso <>0 and id <>  " + id )>0) {
			sys.warnMsgBox(sys.translate("Ya hay un registro con retardo reverso informado para la maquina %1").arg(codMaquinacol));
			return false;
		}
	}


	return true;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
