
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
  function euromoda ( context ) { oficial ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function calculateField(fN) {
    return this.ctx.euromoda_calculateField(fN);
  }
  function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function recalcularValorAdquisicion() {
    return this.ctx.euromoda_recalcularValorAdquisicion();
  }
//   function dameListaSubcuentas(codGrupoContableAmo) {
//     return this.ctx.euromoda_dameListaSubcuentas(codGrupoContableAmo);
//   }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
  function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_dameListaSubcuentas(codGrupoContableAmo) {
		return this.dameListaSubcuentas(codGrupoContableAmo);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  switch (fN) {
//   case "codgrupocontableamo": {
//       sys.setObjText(this, "fdbIdSubcuentaElem", _i.calculateField("idsubcuentaelem"));
//       sys.setObjText(this, "fdbIdSubcuentaAmor", _i.calculateField("idsubcuentaamor"));
//       break;
//     }
  default: {
      return _i.__bufferChanged(fN);
    }
  }
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
//   case "idsubcuentaelem": {
//       valor = AQUtil.sqlSelect("co_gruposcontablesamo", "idsubcuentaele", "codgrupo = '" + cursor.valueBuffer("codgrupocontableamo") + "'");
//       break;
//     }
//   case "idsubcuentaamor": {
//       valor = AQUtil.sqlSelect("co_gruposcontablesamo", "idsubcuentaamo", "codgrupo = '" + cursor.valueBuffer("codgrupocontableamo") + "'");
//       break;
//     }
  default: {
      valor = _i.__calculateField(fN);
    }
  }
  return valor;
}

function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	_i.__init();
	
	connect(this.child("tdbRegValorAmor").cursor(), "bufferCommited()", _i, "recalcularValorAdquisicion");
  
// 	var subcuentas = _i.dameListaSubcuentas(cursor.valueBuffer("codgrupocontableamo"));
// 	if (cursor.modeAccess() == cursor.Edit) {
// // 		var codSubcuentaE = cursor.valueBuffer("codsubcuentaelem");
// 		var subcuentas = _i.dameListaSubcuentas(cursor.valueBuffer("codgrupocontableamo"));
// 		this.child("tdbMovimientos").cursor().setMainFilter("codsubcuenta IN  (" + subcuentas + ")");
// 		this.child("tdbMovimientos").refresh();
// 	}
}

function euromoda_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	
	switch (fN) {
		case "valoradquisicion": {
			var pvp = AQUtil.sqlSelect("lineasfacturasprov", "SUM(pvptotal)", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
			var reg = AQUtil.sqlSelect("co_regvaloramor", "SUM(valoradquisicion)", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
			pvp = isNaN(pvp) ? 0 : pvp;
			reg = isNaN(reg) ? 0 : reg;
			valor = pvp + reg;
			//valor = AQUtil.sqlSelect("lineasfacturasprov", "SUM(pvptotal)", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
			valor = isNaN(valor) ? 0 : valor;
			valor = AQUtil.roundFieldValue(valor, "co_amortizaciones", "valoradquisicion");
			break;
		}
		case "valorresidual": {
			valor = AQUtil.sqlSelect("co_regvaloramor", "SUM(valorresidual)", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
			valor = isNaN(valor) ? 0 : valor;
			valor = AQUtil.roundFieldValue(valor, "co_amortizaciones", "valorresidual");
			break;
		}
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
		}
	}
	return valor;
}

function euromoda_recalcularValorAdquisicion()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	cursor.setValueBuffer("valoradquisicion", _i.calculateField("valoradquisicion"));
	cursor.setValueBuffer("valorresidual", _i.calculateField("valorresidual"));
}

// function euromoda_dameListaSubcuentas(codGrupoContableAmo)
// {
// 	var _i = this.iface;
// 	var q = new FLSqlQuery;
// 	q.setSelect("codsubcuentaele, codsubcuentagas, codsubcuentaamo");
// 	q.setFrom("co_gruposcontablesamo");
// 	q.setWhere("codgrupo = '" + codGrupoContableAmo + "'");
// 	if (!q.exec()) {
// 		return false;
// 	}
// 	if (!q.first()) {
// 		return "'Not Found'";
// 	}
// 	var valor = "";
// 	valor += ("'" + q.value("codsubcuentaele") + "'");
// 	valor += q.value("codsubcuentaamo") != "" ? (", '" + q.value("codsubcuentaamo") + "'") : "";
// debug("lista = " + valor);
// 	return valor;
// }

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
