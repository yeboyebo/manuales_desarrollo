/***************************************************************************
                 em_lineasplantilladib.qs  -  description
                             -------------------
    begin                : jue sep 27 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN:String) { return this.ctx.interna_calculateField(fN); }
	function validateForm() {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var aSubFam_, aColor_, aTamano_;
	function oficial( context ) { interna( context ); } 
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function validaCriteriosProd() {
		return this.ctx.oficial_validaCriteriosProd();
	}
	function filtraProd() {
		return this.ctx.oficial_filtraProd();
	}
	function filtraTamano() {
		return this.ctx.oficial_filtraTamano();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	debug("interna_init");
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	
	_i.filtraProd();
	_i.filtraTamano();
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;
	
	if (!_i.validaCriteriosProd()) {
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_filtraProd()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codDibujo = cursor.valueBuffer("coddibujoem");
	var qSF = new AQSqlQuery;
	qSF.setSelect("codsubfamilia");
	qSF.setFrom("em_dibujossubfam");
	qSF.setWhere("coddibujoem = " + codDibujo);
	if (!qSF.exec()) {
		return false;
	}
	_i.aSubFam_ = [];
	while (qSF.next()) {
		_i.aSubFam_.push(qSF.value("codsubfamilia"));
	}
	var fSF = _i.aSubFam_.length > 0 ? ("codsubfamilia IN ('" + _i.aSubFam_.join("', '") + "')") : "1 = 2";
	this.child("fdbCodSubfamiliaProd").setFilter(fSF);
	
	var qC = new AQSqlQuery;
	qC.setSelect("codcolorem");
	qC.setFrom("em_dibujoscolor");
	qC.setWhere("coddibujoem = " + codDibujo);
	if (!qC.exec()) {
		return false;
	}
	_i.aColor_ = [];
	while (qC.next()) {
		_i.aColor_.push(qC.value("codcolorem"));
	}
	var fC = _i.aColor_.length > 0 ? ("codcolorem IN ('" + _i.aColor_.join("', '") + "')") : "1 = 2";
	this.child("fdbCodColorEmProd").setFilter(fC);
}

function oficial_filtraTamano()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	_i.aTamano_ = [];
	
	var codDibujo = cursor.valueBuffer("coddibujoem");
	if (cursor.valueBuffer("codsubfamiliaprod")) {
		var qT = new AQSqlQuery;
		qT.setSelect("codtamanoem");
		qT.setFrom("em_dibujostamsub");
		qT.setWhere("coddibujoem = " + codDibujo + " AND codsubfamilia = '" + cursor.valueBuffer("codsubfamiliaprod") + "'");
		if (!qT.exec()) {
			return false;
		}
		
debug(qT.sql());
		while (qT.next()) {
			_i.aTamano_.push(qT.value("codtamanoem"));
		}
debug("codtamanoem IN ('" + _i.aTamano_.join("', '") + "')");
		
	}
	var fT = _i.aTamano_.length > 0 ? ("codtamanoem IN ('" + _i.aTamano_.join("', '") + "')") : "1 = 2";
	this.child("fdbCodTamanoEmProd").setFilter(fT);
}

function oficial_commonCalculateField(fN, cursor)
{
debug("oficial_commonCalculateField " + fN);
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "factor": {
      var piezasAncho = cursor.valueBuffer("piezasancho") ;
      if (isNaN(piezasAncho) || piezasAncho == 0) {
        valor = 0;
      } else {
        valor = cursor.valueBuffer("largo") / piezasAncho / 100;
      }
      break;
		}
		case "piezasancho": {
			var ancho = cursor.valueBuffer("ancho");
			if (!ancho || isNaN(ancho)) {
				valor = 0;
			} else {
				valor = Math.floor(280 / ancho);
			}
			break;
		}
		default: {
		}
	}
			
	return valor;
}

function oficial_bufferChanged(fN)
{
debug("oficial_bufferChanged " + fN);
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "codsubfamiliaprod": {
			_i.filtraTamano();
			break;
		}
		case "largo":
		case "piezasancho": {
      sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
      this.child("fdbFactor").setValue(_i.calculateField("factor"));
      break;
    }
		case "ancho": {
      sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
			this.child("fdbFactor").setValue(_i.calculateField("factor"));
      break;
    }
		default: {
		}
	}
}

function oficial_validaCriteriosProd()
{
	/// Valida que subfamilia, tama�o y color est�n en los arrays globales que se crean al establecer los filtros
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////