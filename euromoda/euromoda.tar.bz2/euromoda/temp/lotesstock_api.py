# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa
import json
import re
#from articulos_api import insertar_ubicacion, comprobar_formato_ubicacion
# lotimport reesstock = qsa.class_("lotesstock")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */
class Oficial(Base):

    def get(self, params, username=None):

        mapa = self.get_mapa()
        obj = qsa.from_project("formAPI").get_resources('lotesstock', params, mapa, username)

        return obj

    def cortarPieza(self, params, username=None):
        obj = qsa.from_project("formau_automata").iface.cortaPiezaJson(params)
        return obj

    def regularizarPieza(self, params, username=None):
        obj = qsa.from_project("formau_automata").iface.regularizarLoteJson(params)
        return obj


    def ubicar_pieza_actual(self, pk, params, username=None):
         ## solucion error this connection is closed??
        session = qsa.thread_session_new()
        session.begin()
        ##
        cod_lote = pk
        nueva_ubicacion = params["nueva_ubicacion"]
        self.comprobar_formato_ubicacion(nueva_ubicacion)
        existe_emubicaciones = qsa.FLUtil.sqlSelect("em_ubicaciones", "em_codubicacion", "em_codubicacion = '" + nueva_ubicacion + "'")
        if not existe_emubicaciones:
            self.insertar_ubicacion(nueva_ubicacion)
        
        Em_lotesxubicacion = qsa.orm_("em_lotesxubicacion") #ponemos todas las ubicaciones con actual = false
        ubicaciones = Em_lotesxubicacion.query().filter(Em_lotesxubicacion.codlote == cod_lote)
        for ubicacion in ubicaciones:
            ubicacion.actual = False
            ubicacion.save()

        existe_lotesxubicacion = qsa.FLUtil.sqlSelect("em_lotesxubicacion", "id", "em_ubialternativa = '" + nueva_ubicacion + "' AND codlote = '" + cod_lote + "'")
        if not existe_lotesxubicacion:
            lotesxubicacion = Em_lotesxubicacion()
            lotesxubicacion.em_ubialternativa = nueva_ubicacion
            lotesxubicacion.codlote = cod_lote
            lotesxubicacion.actual = True
            lotesxubicacion.save()
        else:
            lotesxubicacion = Em_lotesxubicacion.get(existe_lotesxubicacion)
            lotesxubicacion.actual = True
            lotesxubicacion.save()
        
        # actualizamos la tabla lotestocks 
        LoteStocks = qsa.orm_("lotesstock")
        lote = LoteStocks.get(cod_lote)
        lote.em_ubiactual = nueva_ubicacion
        lote.save()
        session.commit()
        return True

    def ubicar_pieza_alternativa(self, pk, params, username=None):
        ## solucion error this connection is closed??
        session = qsa.thread_session_new()
        session.begin()
        ##
        cod_lote = pk
        nueva_ubicacion = params["nueva_ubicacion"]
        self.comprobar_formato_ubicacion(nueva_ubicacion)
        existe_emubicaciones = qsa.FLUtil.sqlSelect("em_ubicaciones", "em_codubicacion", "em_codubicacion = '" + nueva_ubicacion + "'")
        if not existe_emubicaciones:
            self.insertar_ubicacion(nueva_ubicacion)

        existe_lotestocksxubicacion = qsa.FLUtil.sqlSelect("em_lotesxubicacion", "id", "em_ubialternativa = '" + nueva_ubicacion + "' AND codlote = '" + cod_lote + "'")
        if not existe_lotestocksxubicacion:
            Em_lotesxubicacion = qsa.orm_("em_lotesxubicacion")
            lostesxubicacion = Em_lotesxubicacion()
            lostesxubicacion.em_ubialternativa = nueva_ubicacion
            lostesxubicacion.codlote = cod_lote
            lostesxubicacion.actual = False
            lostesxubicacion.save()
        session.commit()
        return True

    def desubicar_actual(self, pk, params, username=None):
        cod_lote = pk
        ubicacion_actual = params["ubicacion_actual"]
        self.comprobar_formato_ubicacion(ubicacion_actual)
        LoteStocks = qsa.orm_("lotesstock")
        lotestock = LoteStocks.get(cod_lote)
        lotestock.em_ubiactual = None
        lotestock.save()
        # actualizamos em_lotesxubicacion para poner esa ubicacion a False
        Em_lotesxubicacion = qsa.orm_("em_lotesxubicacion")
        lotesxubicacion = Em_lotesxubicacion.query().filter(Em_lotesxubicacion.codlote == cod_lote)\
            .filter(Em_lotesxubicacion.em_ubialternativa == ubicacion_actual)
        for lote in lotesxubicacion:
            lote.actual = False
            lote.save()
        return True

    def desubicar_alternativa(self, pk, params, username=None):
        #cod_lote = pk
        id_ubicacion = params["id_ubicacion"]
        Em_lotesxubicacion = qsa.orm_("em_lotesxubicacion")
        lotesxubicacion = Em_lotesxubicacion.get(id_ubicacion)
        lotesxubicacion.delete()
        return True


    @staticmethod
    def insertar_ubicacion(ubicacion):
        zonas = ubicacion.split('-')
        nave = int(zonas[0][1:]) # par evitar problemas ejemplo: N01-P1-E1-A1 seria igual a N1-P1-E1-A1
        pasillo = int(zonas[1][1:])
        estante = int(zonas[2][1:])
        altura = int(zonas[3][1:])
        #print('ubicacion', ubicacion, 'nave', nave, 'altura', altura, 'pasillo', pasillo, 'estante', estante)
        Em_Ubicaciones = qsa.orm_("em_ubicaciones")
        em_ubicacion = Em_Ubicaciones()
        em_ubicacion.em_ubipasillo = pasillo
        em_ubicacion.em_ubiestante = estante
        em_ubicacion.em_ubinave = nave
        em_ubicacion.em_ubialtura = altura
        em_ubicacion.em_codubicacion = ubicacion
        em_ubicacion.save()

    @staticmethod
    def comprobar_formato_ubicacion(text):
        if re.match("^N[0-9]{1,2}-P[0-9]{1,2}-E[0-9]{1,2}-A[0-9]{1,2}$", text) is None:
            raise Exception('Ubicacion no tiene el formato aceptado.')
        

    def get_mapa(self):
        return {
            'join': 'lotesstock INNER JOIN articulos on lotesstock.referencia = articulos.referencia',
            'order': 'codlote',
            'map': {
                'referencia': {'field': 'lotesstock.referencia', 'type': 'string'},
                'candisponible': {'field': 'lotesstock.candisponible', 'type': 'string'},
                'codlote': {'field': 'lotesstock.codlote', 'type': 'string'},
                'estado': {'field': 'lotesstock.estado', 'type': 'string'},
                'descripcion': {'field': 'articulos.descripcion', 'type': 'string'},
                'codcolorem': {'field': 'articulos.codcolorem', 'type': 'string'},
                'codtamanoem': {'field': 'articulos.codtamanoem', 'type': 'string'},
                'em_ubiactual': {'field': 'lotesstock.em_ubiactual', 'type': 'string'}
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
