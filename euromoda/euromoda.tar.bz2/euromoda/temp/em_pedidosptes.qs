/***************************************************************************
                 em_pedidosptes.qs  -  description
                             -------------------
    begin                : vie mar 02 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function preloadMainFilter() {
		return this.ctx.interna_preloadMainFilter();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var totalAEnviar_;
	var curPedido_, curReserva_, curTS_;
	var codCliente_, refReserva_, oPedido_;
	var colorCliente_, topesLineaPed_;
	var rV_;
	var fechaApertura_;
	var horaApertura_;
	function oficial( context ) { interna( context ); }
	function tbnRefrescar_clicked() {
		return this.ctx.oficial_tbnRefrescar_clicked();
	}
	function dameColorLinea(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, fT, sel);
	}
	function dameColorCliente(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_dameColorCliente(fN, fV, cursor, fT, sel);
	}
	function tbnBorrar_clicked() {
		return this.ctx.oficial_tbnBorrar_clicked();
	}
	function dameColorPedido(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_dameColorPedido(fN, fV, cursor, fT, sel);
	}
	function formatoTabla() {
		return this.ctx.oficial_formatoTabla();
	}
	function pbnGenerarAlbaran_clicked() {
		return this.ctx.oficial_pbnGenerarAlbaran_clicked();
	}
	function generarAlbaranParcialClicked() {
		return this.ctx.oficial_generarAlbaranParcialClicked();
	}
  function filtrarPedidos(){
    return this.ctx.oficial_filtrarPedidos();
  }
  function filtrarLineas(){
    return this.ctx.oficial_filtrarLineas();
  }
  function tbnReservas_clicked() {
    return this.ctx.oficial_tbnReservas_clicked();
  }
  function cargaDatos(referencia, idPedido, noNuevos) {
    return this.ctx.oficial_cargaDatos(referencia, idPedido, noNuevos);
  }
  function calculaEstadoPedidos() {
    return this.ctx.oficial_calculaEstadoPedidos();
  }
  function actualizarPorReferencia() {
    return this.ctx.oficial_actualizarPorReferencia();
  }
  function tbnHojaCarga_clicked() {
    return this.ctx.oficial_tbnHojaCarga_clicked();
  }
  function tbnHojaCompleta_clicked() {
    return this.ctx.oficial_tbnHojaCompleta_clicked();
  }
  function imprimirHojaCompleta(codigo) {
  	return this.ctx.oficial_imprimirHojaCompleta(codigo);
  }
  function validaPedido(idPedido) {
    return this.ctx.oficial_validaPedido(idPedido);
  }
  function dameParamInformeHCompleta(idPedido) {
    return this.ctx.oficial_dameParamInformeHCompleta(idPedido);
  }
  function cargaMaximosLineaPedido(codPedido) {
    return this.ctx.oficial_cargaMaximosLineaPedido(codPedido);
  }
  function dameMaximoLineaPedido(idlinea) {
    return this.ctx.oficial_dameMaximoLineaPedido(idlinea);
  }
  function dameParamInformeHC(idPedido) {
    return this.ctx.oficial_dameParamInformeHC(idPedido);
  }
  function dameAEnviar(nodo, campos) {
    return this.ctx.oficial_dameAEnviar(nodo, campos);
  }
  function recargaPedido() {
    return this.ctx.oficial_recargaPedido();
  }
  function tbnCambiaHC_clicked() {
    return this.ctx.oficial_tbnCambiaHC_clicked();
  }
  function cambiaHCPedido(idPedido, hC) {
    return this.ctx.oficial_cambiaHCPedido(idPedido, hC);
  }
  function controlRestricciones() {
    return this.ctx.oficial_controlRestricciones();
  }
  function totalesHC(nodo, campo) {
    return this.ctx.oficial_totalesHC(nodo, campo);
  }
  function tbnTraspasoStock_clicked() {
    return this.ctx.oficial_tbnTraspasoStock_clicked();
	}
	function curTS_bufferCommited() {
		return this.ctx.oficial_curTS_bufferCommited();
	}
	function actualizaUltimaCarga() {
		return this.ctx.oficial_actualizaUltimaCarga();
	}
	function pintaUltimaCarga() {
		return this.ctx.oficial_pintaUltimaCarga();
	}
	function imprimeAlbaran(codAlbaran) {
		return this.ctx.oficial_imprimeAlbaran(codAlbaran);
	}
	function dameParamEtiDropShipping(oParamPed) {
		return this.ctx.oficial_dameParamEtiDropShipping(oParamPed);
	}
	function informaArrayEtiDS(idPedido) {
		return this.ctx.oficial_informaArrayEtiDS(idPedido);
	}
	function tbnEtiqueta_clicked() {
		return this.ctx.oficial_tbnEtiqueta_clicked();
	}
	function imprimirEtiqueta(codigo) {
		return this.ctx.oficial_imprimirEtiqueta(codigo);
	}
	function dameDatosStock(idStock) {
		return this.ctx.oficial_dameDatosStock(idStock);
	}
	function refrescaDatosStock(idStock) {
		return this.ctx.oficial_refrescaDatosStock(idStock);
	}
	function refrescarLineas() {
		return this.ctx.oficial_refrescarLineas();
	}
	function pbnGenerarAlbaranCDB_clicked() {
		return this.ctx.oficial_pbnGenerarAlbaranCDB_clicked();
	}
	function compruebaUsuario(tipo) {
		return this.ctx.oficial_compruebaUsuario(tipo);
	}
	function actualizaUsuarioCargando() {
		return this.ctx.oficial_actualizaUsuarioCargando();
	}
	function pintaCargaActual(miForm) {
		return this.ctx.oficial_pintaCargaActual(miForm);
	}
	function compruebaFechaApertura(tipo) {
		return this.ctx.oficial_compruebaFechaApertura(tipo);
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
	function pub_dameMaximoLineaPedido(idlinea) {
		return this.dameMaximoLineaPedido(idlinea);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	connect(this.child("tbnRefrescar"), "clicked()", _i, "tbnRefrescar_clicked");
	connect(this.child("pbnGenerarAlbaran"), "clicked()", _i, "pbnGenerarAlbaran_clicked");
	connect(this.child("tbnTraspasoStock"), "clicked()", _i, "tbnTraspasoStock_clicked");

	connect(this.child("tdbClientesPedPtes").cursor(), "newBuffer()", _i, "filtrarPedidos()");
	connect(this.child("tdbPedidosPedPtes").cursor(), "newBuffer()", _i, "filtrarLineas()");
	connect(this.child("chkFiltroPedidos"), "clicked()", _i, "filtrarPedidos()");
  connect(this.child("chkFiltroLineas"), "clicked()", _i, "filtrarLineas()");
// 	if (this.child("tbnReservas")) {
// 		this.child("tbnReservas").close();
// 	}
	connect(this.child("tbnReservas"), "clicked()", _i, "tbnReservas_clicked()");
	connect(this.child("tbnBorrar"), "clicked()", _i, "tbnBorrar_clicked");
	connect(this.child("tbnHojaCarga"), "clicked()", _i, "tbnHojaCarga_clicked");
	connect(this.child("tbnHojaCompleta"), "clicked()", _i, "tbnHojaCompleta_clicked");
	connect(this.child("tbnCambiaHC"), "clicked()", _i, "tbnCambiaHC_clicked");
	connect(this.child("tbnEtiqueta"), "clicked()", _i, "tbnEtiqueta_clicked");
	connect(this.child("pbnGenerarAlbaranCDB"), "clicked()", _i, "pbnGenerarAlbaranCDB_clicked");


	_i.formatoTabla();
// 	_i.tbnRefrescar_clicked();

	_i.curReserva_ = new FLSqlCursor("stocks");
	_i.curReserva_.setAction("em_reservasstock");

	_i.controlRestricciones();
	_i.filtrarPedidos();

	_i.pintaUltimaCarga();
	_i.pintaCargaActual(this);

	var fecha = new Date();
	_i.horaApertura_ = fecha.toString().right(9);
	_i.fechaApertura_ = fecha.toString().left(10);
}


function interna_preloadMainFilter()
{
	var _i = this.iface;		
	var q = new AQSqlQuery;	
	q.setSelect("em_fechainicargapp, em_horainicargapp, em_usucargapp");
	q.setFrom("prodppal_general");
	q.setWhere("1 = 1"); 		
	if (!q.exec()){
		return true;
	}  
	if(!q.first()) {
		return true;
	}

	var usuarioCargaPP = q.value("em_usucargapp");
	if(usuarioCargaPP && usuarioCargaPP) {
		formUI.ponMsgWarn(sys.translate("La pantalla est� siendo recargada por otro usuario, deber� cerrarla y volverla a abrir cuando termine la recarga"));
	}
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_formatoTabla()
{
	var t = this.child("tdbLineasPedPtes");
	var cols = [["cantidad", 40], ["totalenalbaran", 40], ["pendiente", 40], ["enstock", 40], ["programada", 40], ["falta", 40], ["existencias", 50], ["disponible", 50]];
	for (var c = 0; c < cols.length; c++) {
		t.setColumnWidth(cols[c][0], cols[c][1]);
	}
	
	var tP = this.child("tdbPedidosPedPtes");
	var colsP = [["emcatservicio", 40],["em_coddropshipping", 110]];
	for (var c = 0; c < colsP.length; c++) {
		tP.setColumnWidth(colsP[c][0], colsP[c][1]);
	}
}

function oficial_tbnRefrescar_clicked()
{
	var _i = this.iface;

	if(!_i.compruebaUsuario("recarga")) { 
		return false;	
	}

	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}

	_i.actualizaUsuarioCargando();

	if (!AQSql.del("em_pedidospedptes", "")) {
		return false;
	}
	if (!AQSql.del("em_clientespedptes", "")) {
		return false;
	}
	if (!AQSql.del("em_lineaspedptes", "")) {
		return false;
	}

	_i.cargaDatos()
	if (!_i.calculaEstadoPedidos()) {
		return false;
	}

	_i.actualizaUltimaCarga();
	_i.pintaCargaActual(this);
}

function oficial_cargaDatos(referencia, idPedidoParam, noNuevos)
{
	var _i = this.iface;
	var masWhere = referencia ? ("AND l.referencia = '" + referencia + "'") : "";
	
	masWhere += idPedidoParam ? ("AND p.idpedido = " + idPedidoParam) : "";
	
	var desde = this.child("dedDesde").date;
	
	if (desde) {

		masWhere += "AND p.fechaservicio >= '" + desde + "'";
	}
	var hasta = this.child("dedHasta").date;
	if (hasta) {
		masWhere += "AND p.fechaservicio <= '" + hasta + "'";
	}
	var from = "pedidoscli p INNER JOIN lineaspedidoscli l ON p.idpedido = l.idpedido LEFT OUTER JOIN articulos a ON l.referencia = a.referencia LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') LEFT OUTER JOIN movistock ms ON (l.idlinea = ms.idlineapc AND l.referencia = ms.referencia) LEFT OUTER JOIN agentes ag ON p.codagente = ag.codagente LEFT OUTER JOIN clientes c ON p.codcliente = c.codcliente LEFT OUTER JOIN em_dropshipping d ON p.em_coddropshipping = d.codigo ";
	from += noNuevos ? " INNER JOIN em_pedidospedptes ppp ON p.idpedido = ppp.idpedido" : "";
	var q = new FLSqlQuery;
	q.setSelect("p.codcliente, p.idpedido, p.codigo, p.docexterno, p.fechaservicio, p.fechasalida, p.emcatservicio, c.bloqueado, l.referencia, l.descripcion, a.codtamanoem, a.codcolorem, l.cantidad, l.totalenalbaran, s.cantidad, p.nombrecliente, p.fecha, p.obsinternas, l.idlinea, p.codagente, ag.nombreap, p.hojacarga, SUM(ms.cantidad), SUM(ms.reservaex), SUM(ms.reservapr), SUM(ms.reservaaf), p.fechasalida, c.nombre, p.observaciones, p.em_coddropshipping, d.descripcion, s.idstock,s.disponible");
	q.setFrom(from);
	q.setWhere("l.cantidad > l.totalenalbaran AND NOT l.cerrada " + masWhere + " GROUP BY p.codcliente, p.idpedido, p.codigo, p.docexterno, p.fechaservicio, p.emcatservicio, c.bloqueado, l.referencia, l.descripcion, a.codtamanoem, a.codcolorem, l.cantidad, l.totalenalbaran, s.cantidad, p.nombrecliente, p.fecha, p.obsinternas, l.idlinea, p.codagente, ag.nombreap, p.hojacarga, p.fechasalida, c.nombre, p.observaciones, p.em_coddropshipping, d.descripcion, s.idstock, s.disponible ORDER BY p.codcliente,p.idpedido");
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	if(q.size() == 0) {
		return true;
	}
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando pedidos..."), q.size());
// 	AQUtil.createProgressDialog(sys.translate("Cargando pedidos..."), q.size());
	var p = 0;
	var cantidad, servida, pendiente;
	var curLin = new FLSqlCursor("em_lineaspedptes");
	var curCli = new FLSqlCursor("em_clientespedptes");
	var curPed = new FLSqlCursor("em_pedidospedptes");
	var existe;
	var idLinea, idLineaAnt = false, obsInternas;
	var almacen, programada, aFaltas;
	var estadoPedido = "NEW", idPedido;
	var estadoCliente = "NEW", codCliente;
// 	_i.colorCliente_ = new Object;
	while (q.next()) {
		obsInternas = q.value("p.obsinternas");
		obsInternas = (obsInternas && obsInternas != "" && obsInternas.length > 500) ? obsInternas.left(500) : obsInternas;
		idLinea = q.value("l.idlinea");
		if (idLinea != idLineaAnt && idLineaAnt) {
			curLin.setValueBuffer("programada", programada);
			/// Des Cambiado para pruebas Gonzalo
 			curLin.setValueBuffer("enstock", almacen);
			curLin.setValueBuffer("falta", aFaltas);

			var alma = curLin.valueBuffer("enstock");
			alma = alma < 0 ? 0 : alma;
			if (!curLin.commitBuffer()) {
				AQUtil.destroyProgressDialog();
				sys.errorMsgBox("Error al guardar la l�nea pendiente");
				return false;
			}
		}
		if (idLinea != idLineaAnt) {
			AQUtil.setProgress(p++);
			if (referencia) {
				curLin.select("idlineapedido = " + idLinea);
				if (!curLin.first()) {
					sys.errorMsgBox("Error al buscar la l�nea pendiente");
					return false;
				}
				curLin.setModeAccess(curLin.Edit);
				curLin.refreshBuffer();
			} else {
				cantidad = q.value("l.cantidad");
				servida = q.value("l.totalenalbaran");
				pendiente = cantidad - servida
				curLin.setModeAccess(curLin.Insert);
				curLin.refreshBuffer();
				curLin.setValueBuffer("idpedido", q.value("p.idpedido"));
				curLin.setValueBuffer("idlineapedido", idLinea);
				curLin.setValueBuffer("codigo", q.value("p.codigo"));				
				curLin.setValueBuffer("fechaservicio", q.value("p.fechaservicio"));
				curLin.setValueBuffer("referencia", q.value("l.referencia"));
				curLin.setValueBuffer("descripcion", q.value("l.descripcion"));
				curLin.setValueBuffer("codtamanoem", q.value("a.codtamanoem"));
				curLin.setValueBuffer("codcolorem", q.value("a.codcolorem"));
				curLin.setValueBuffer("cantidad", cantidad);
				curLin.setValueBuffer("totalenalbaran", servida);
				curLin.setValueBuffer("pendiente", pendiente);
				curLin.setValueBuffer("nombrecliente", q.value("p.nombrecliente"));
				curLin.setValueBuffer("fecha", q.value("p.fecha"));
				curLin.setValueBuffer("observaciones", obsInternas);
				curLin.setValueBuffer("codcliente", q.value("p.codcliente"));

				curLin.setValueBuffer("idstock", q.value("s.idstock"));
				curLin.setValueBuffer("existencias", q.value("s.cantidad"));
				curLin.setValueBuffer("disponible", q.value("s.disponible"));

				/// Des Cambiado para pruebas Gonzalo (ahora bien para producci�n)
// 				curLin.setValueBuffer("enstock", q.value("s.cantidad"));

				existe = AQUtil.sqlSelect("em_pedidospedptes", "idpedido", "idpedido = " + q.value("p.idpedido"));
				if(!existe){
					if (idPedido) {
						AQSql.update("em_pedidospedptes", ["estado"], [estadoPedido], "idpedido = " + idPedido);
					}

					curPed.setModeAccess(curPed.Insert);
					curPed.refreshBuffer();
					curPed.setValueBuffer("idpedido", q.value("p.idpedido"));
					curPed.setValueBuffer("codigo", q.value("p.codigo"));
					curPed.setValueBuffer("docexterno", q.value("p.docexterno"));
					curPed.setValueBuffer("codcliente", q.value("p.codcliente"));
					curPed.setValueBuffer("nombrecliente", q.value("p.nombrecliente"));
					curPed.setValueBuffer("nombreagente", q.value("ag.nombreap"));
					curPed.setValueBuffer("fechaservicio", q.value("p.fechaservicio"));
					curPed.setValueBuffer("emcatservicio", q.value("p.emcatservicio"));
					curPed.setValueBuffer("fecha", q.value("p.fecha"));
					curPed.setValueBuffer("hojacarga", q.value("p.hojacarga"));
					curPed.setValueBuffer("fechacliente", q.value("p.fechasalida"));

					curPed.setValueBuffer("observaciones", q.value("p.observaciones"));
					curPed.setValueBuffer("obsinternas", q.value("p.obsinternas"));
					curPed.setValueBuffer("em_coddropshipping", q.value("p.em_coddropshipping"));
					curPed.setValueBuffer("descdropshipping", q.value("d.descripcion"));					
					if (!curPed.commitBuffer()) {
						AQUtil.destroyProgressDialog();
						sys.errorMsgBox("Error al guardar el pedido pendiente");
						return false;
					}
					idPedido = q.value("p.idpedido");
					estadoPedido = "NEW";
				}
				existe = AQUtil.sqlSelect("em_clientespedptes", "codcliente", "codcliente = '" + q.value("p.codcliente") + "'");
				if (!existe){
					curCli.setModeAccess(curCli.Insert);
					curCli.refreshBuffer();
					curCli.setValueBuffer("codcliente", q.value("p.codcliente"));
					//curCli.setValueBuffer("nombre", q.value("p.nombrecliente"));
					curCli.setValueBuffer("nombre", q.value("c.nombre"));
					curCli.setValueBuffer("bloqueado", q.value("c.bloqueado"));
					curCli.setValueBuffer("codagente", q.value("p.codagente"));
					curCli.setValueBuffer("agente", q.value("ag.nombreap"));
					if (!curCli.commitBuffer()) {
						AQUtil.destroyProgressDialog();
						sys.errorMsgBox("Error al guardar el cliente pendiente");
						return false;
					}
					codCliente = q.value("p.codcliente");
					nombreCliente = q.value("p.nombrecliente");
					estadoCliente = "NEW";
				}
			}
			almacen = 0;
			programada = 0;
			aFaltas = 0;
		}
		almacen = q.value("SUM(ms.reservaex)") ? q.value("SUM(ms.reservaex)") : 0;
		programada = q.value("SUM(ms.reservapr)") ? q.value("SUM(ms.reservapr)") : 0;
		aFaltas = q.value("SUM(ms.reservaaf)") ? q.value("SUM(ms.reservaaf)") : 0;
		idLineaAnt = idLinea;
	}
	AQUtil.destroyProgressDialog();
	if (q.size() > 0) {
		curLin.setValueBuffer("programada", programada);
			/// Des Cambiado para pruebas Gonzalo

		curLin.setValueBuffer("enstock", almacen);
		curLin.setValueBuffer("falta", aFaltas);
		var alma = curLin.valueBuffer("enstock");
		alma = alma < 0 ? 0 : alma;
		if (!curLin.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			sys.errorMsgBox("Error al guardar la l�nea pendiente (2)");
			return false;
		}
	}
	AQUtil.destroyProgressDialog();

}

function oficial_calculaEstadoPedidos()
{
	if (!AQUtil.execSql("update em_pedidospedptes set estado = 'PTE'")) {
		return false;
	}
	if (!AQUtil.execSql("update em_pedidospedptes set estado = 'PARCIAL' where idpedido in (select idpedido from em_lineaspedptes where idpedido = em_pedidospedptes.idpedido and enstock > 0)")) {
		return false;
	}
	if (!AQUtil.execSql("update em_pedidospedptes set estado = 'OK' where estado = 'PARCIAL' AND idpedido NOT in (select idpedido from em_lineaspedptes LEFT OUTER JOIN articulos ON articulos.referencia = em_lineaspedptes.referencia WHERE idpedido = em_pedidospedptes.idpedido and enstock < pendiente and NOT articulos.nostock)")) {
		return false;
	}
	if (!AQUtil.execSql("update em_clientespedptes set estado = 'PTE'")) {
		return false;
	}
	if (!AQUtil.execSql("update em_clientespedptes set estado = 'OK' where codcliente IN (SELECT codcliente FROM em_pedidospedptes where codcliente = em_clientespedptes.codcliente AND estado IN ('OK', 'PARCIAL'))")) {
		return false;
	}
	if(this.child("tdbLineasPedPtes")) {
		this.child("tdbLineasPedPtes").refresh();	
	}
	if(this.child("tdbClientesPedPtes")) {
		this.child("tdbClientesPedPtes").refresh();	
	}
	if(this.child("tdbPedidosPedPtes")) {
		this.child("tdbPedidosPedPtes").refresh();	
	}	
	return true;
}

function oficial_filtrarPedidos()
{
	var _i = this.iface;
  var filtro = "";
  if (!this.child("chkFiltroPedidos").checked) {
		if (!this.child("tbnOcultarClientes").on) {
			var curCli = this.child("tdbClientesPedPtes").cursor();
			_i.codCliente_ = curCli.valueBuffer("codcliente");
		}
		if (_i.codCliente_) {
			filtro = "codcliente = '" + _i.codCliente_ + "'";
		} else {
			filtro = "1 = 2";
		}
  }
  //this.child("tdbPedidosPedPtes").setFilter(filtro);
  this.child("tdbPedidosPedPtes").cursor().setMainFilter(filtro);
  this.child("tdbPedidosPedPtes").refresh();
  _i.pintaUltimaCarga();
}

function oficial_filtrarLineas()
{
	var _i = this.iface;
	var filtro = "1 = 1";

	if (!this.child("chkFiltroLineas").checked) {
		var curPed = this.child("tdbPedidosPedPtes").cursor();
		var codigo = curPed.valueBuffer("codigo");
		if (codigo) {
			filtro = "codigo = '" + codigo + "'";
		} else {
			filtro = "1 = 2";
		}
	}  else if (this.child("chkFiltroLineas").checked && !this.child("chkFiltroPedidos").checked){
		var curCli = this.child("tdbClientesPedPtes").cursor();
		var codigo = curCli.valueBuffer("codcliente");
		if(codigo){
			filtro = "codcliente = '" + codigo + "'";
		} else {
			filtro = "1 = 2";
		}
	}

	this.child("tdbLineasPedPtes").cursor().setMainFilter(filtro);
	_i.refrescarLineas();
	_i.pintaUltimaCarga();
	_i.pintaCargaActual(this);
	//this.child("tdbLineasPedPtes").refresh();
}

function oficial_dameColorLinea(fN, fV, cursor, fT, sel)
{
	var color = "";
	switch (fN) {
		case "pendiente": {
			if (cursor.valueBuffer("enstock") >= cursor.valueBuffer("pendiente")) {
				color = "#63AA4F"; /// Verde
			}
			break;
		}
		case "programada": {
			if (cursor.valueBuffer("programada") != 0) {
				color = "#FFFF7F"; /// Amarillo
			}
			break;
		}
		default: {
			return;
		}
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}

function oficial_dameColorPedido(fN, fV, cursor, fT, sel)
{
	var color = "";
	switch (fN) {
		case "estado": {
			switch (fV) {
				case "OK": {
					color = "#63AA4F"; /// Verde
					break;
				}
				case "PARCIAL": {
					color = "#FFFF7F"; /// Amarillo
					break;
				}
				default: {
					return;
				}
			}
			break;
		}
		default: {
			return;
		}
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}

function oficial_tbnBorrar_clicked()
{
	var _i = this.iface;
	this.child("dedDesde").date = "";
	this.child("dedHasta").date = "";
}

function oficial_dameColorCliente(fN, fV, cursor, sel, fT)
{
	var _i = this.iface;
	var color = "";
	switch (fN) {
		case "nombre": {
			if (cursor.valueBuffer("bloqueado") == "Enviar" || cursor.valueBuffer("bloqueado") == "Facturar" || cursor.valueBuffer("bloqueado") == "Todo") {
				color = flfactppal.iface.pub_dameColor(sel ? "fondo_cliente_bloqueado_sel" : "fondo_cliente_bloqueado");
				break;
			}
			if (cursor.valueBuffer("estado") == "OK") {
				color = sel ? "#4FDD4F" : "#63AA4F";
			}
			break;
		}
		default: {
			return;
		}
	}
	if (color != "") {
		var a = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}


/*function oficial_pbnGenerarAlbaran_clicked()
{
	var _i = this.iface;
	var cursor:FLSqlCursor = this.cursor();
	if (!cursor.isValid()) {
		return;
	}
	var codigo = cursor.valueBuffer("codigo");
	if (!codigo) {
		return;
	}

	_i.curPedido_ = undefined;
	_i.curPedido_ = new FLSqlCursor("pedidoscli");
	_i.curPedido_.select("codigo = '" + codigo + "'");
	if (!_i.curPedido_.first())
		return;

	if (!flfacturac.iface.pub_controlBloqueoCliente(_i.curPedido_.valueBuffer("codcliente"), "Enviar")) {
		return false;
	}

	if (!_i.cargaMaximosLineaPedido(codigo)) {
		return false;
	}
	_i.curPedido_.setAction("em_pedidoscliparciales");
	_i.oPedido_ = new Object;
	_i.oPedido_["idpedido"] = cursor.valueBuffer("idpedido");
	_i.oPedido_["codcliente"] = cursor.valueBuffer("codcliente");
	_i.oPedido_["emcatservicio"] = cursor.valueBuffer("emcatservicio");
debug("catservicio pedpte " + _i.oPedido_["emcatservicio"]);
	connect(_i.curPedido_, "commited()", _i, "recargaPedido");
	debug("antes de editar");
	_i.curPedido_.editRecord();
	debug("despues de editar");
}*/
function oficial_pbnGenerarAlbaran_clicked()
{
	var _i = this.iface;

	if(!_i.compruebaUsuario("tbnEtiqueta")) { 
		return false;	
	}
	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}

	var cursor = this.cursor();	
	if (!cursor.isValid()){
		return;
	}
	var codigo = cursor.valueBuffer("codigo");
	if (!codigo) {
		return;
	}

	formpedidoscli.iface.asociarAlbaran_ = false;
	formpedidoscliparciales.iface.idAlbaran_ = false; //13-02-2020 generar albaranes CDB
	var codCliente = cursor.valueBuffer("codcliente");
	if (codCliente && codCliente != "") {
		if (!flfacturac.iface.pub_controlBloqueoCliente(codCliente, "Enviar")) {
		  return false;
		}
	}
	if (!_i.cargaMaximosLineaPedido(codigo)) {
		return false;
	}

	_i.oPedido_ = new Object;
	_i.oPedido_["idpedido"] = cursor.valueBuffer("idpedido");
	_i.oPedido_["codcliente"] = cursor.valueBuffer("codcliente");
	_i.oPedido_["emcatservicio"] = cursor.valueBuffer("emcatservicio");
	
	formpedidoscli.iface.msg_ = "";
	formpedidoscli.iface.idFacturaC_ = 0;
	formpedidoscli.iface.idAlbaranC_ = 0;
	cursor.transaction(false);
	try {
		if (_i.generarAlbaranParcialClicked()){
			cursor.commit();
		}
		else{
			cursor.rollback();
		}
	}
	catch (e) {
		cursor.rollback();
		sys.warnMsgBox(sys.translate("Hubo un error en el proceso\n").arg(e));
	}
	if(formpedidoscli.iface.idAlbaranC_ && formpedidoscli.iface.idAlbaranC_ != "undefined" && formpedidoscli.iface.idAlbaranC_ != "") {
		_i.recargaPedido();
		formpedidoscli.iface.procesarEstado();
		formpedidoscli.iface.mostrarMensajeResultado();
	}
}

function oficial_generarAlbaranParcialClicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idPedido = cursor.valueBuffer("idpedido");
	var f = new FLFormSearchDB("pedidoscliparciales");
	var curPedParcial = f.cursor();
	f.cursor().setAction("em_pedidoscliparciales");
	var mF = "pedidoscli.idpedido = '" + idPedido + "'";
	curPedParcial.select(mF);
	curPedParcial.first();
	f.setMainWidget();
	formpedidoscli.iface.idAlbaranC_ = undefined;
	idPedido = f.exec("idpedido");
	if(!idPedido){
		return false;
	}
	formpedidoscli.iface.msg_ = "";
	if(formpedidoscli.iface.idAlbaranC_ && formpedidoscli.iface.idAlbaranC_ != 0 && formpedidoscli.iface.idAlbaranC_ != "" && formpedidoscli.iface.idAlbaranC_ != undefined){
		formpedidoscli.iface.msg_ += sys.translate("Se ha creado el albar�n %1\n").arg(AQUtil.sqlSelect("albaranescli","codigo","idalbaran = " + formpedidoscli.iface.idAlbaranC_));
	}
	return true;
}


function oficial_recargaPedido()
{
	var _i = this.iface;
	
	if (!_i.oPedido_) {
		return;
	}
	var idPedido = _i.oPedido_["idpedido"];
	var codCliente = _i.oPedido_["codcliente"];
	
	var codAlbaran = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran", "a.codigo", "l.idpedido = " + idPedido + " ORDER BY a.idalbaran DESC", "albaranescli");
	if (codAlbaran) {
		var catServicio = _i.oPedido_["emcatservicio"];
		if (catServicio && catServicio > 0) {
			var curAlbaran = new FLSqlCursor("albaranescli");
			curAlbaran.select("codigo = '" + codAlbaran + "'");
			if (!curAlbaran.first()) {
				return;
			}
			formalbaranescli.iface.pub_distribuyeEjercicio(curAlbaran);
		}
	}
	/// Recargamos todos los pedidos del cliente porque puede haberse servido una cantidad reservada para otros pedidos del mismo cliente
	var q = new AQSqlQuery;
	q.setSelect("idpedido");
	q.setFrom("em_pedidospedptes");
// 	q.setWhere("codcliente = '" + codCliente + "'");
	q.setWhere("idpedido = " + idPedido);
	if (!q.exec()) {
		return false;
	}
	var idPedidoCli;
	while (q.next()) {
		idPedidoCli = q.value("idpedido");
		if (!AQSql.del("em_pedidospedptes", "idpedido = " + idPedidoCli)) {
			return false;
		}
		_i.cargaDatos(false, idPedidoCli);
	}
	if (!_i.calculaEstadoPedidos()) {
		return false;
	}

	_i.oPedido_ = undefined;
	if (codAlbaran) {
		_i.imprimeAlbaran(codAlbaran);
	}
}

function oficial_imprimeAlbaran(codAlbaran)
{
	var _i = this.iface;
	var idAlbaranComp = AQUtil.sqlSelect("albaranescli", "idalbarancomp", "codigo = '" + codAlbaran + "'");
	var d = new Dialog;
	d.okButtonText = sys.translate("Aceptar");
	d.cancelButtonText = sys.translate("Cancelar");
	
	var chkA1 = new CheckBox;
	chkA1.text = sys.translate("Imprimir albar�n");
	chkA1.checked = true;
	d.add(chkA1);
	
	var chkB1 = new CheckBox;
	if (idAlbaranComp) {
		chkB1.text = sys.translate("Imprimir albar�n de reparto");
		chkB1.checked = true;
		d.add(chkB1);
	}
	
	var chkA2 = new CheckBox;
	chkA2.text = sys.translate("Imprimir albar�n para transportista");
	chkA2.checked = true;
	d.add(chkA2);
	
	var chkB2 = new CheckBox;
	if (idAlbaranComp) {
		chkB2.text = sys.translate("Imprimir albar�n de reparto para transportista");
		chkB2.checked = true;
		d.add(chkB2);
	}
	
	var chkA3 = new CheckBox;
	chkA3.text = sys.translate("Imprimir etiquetas");
	chkA3.checked = true;
	d.add(chkA3);
	
	var chkB3 = new CheckBox;
	if (idAlbaranComp) {
		chkB3.text = sys.translate("Imprimir etiquetas de reparto");
		chkB3.checked = true;
		d.add(chkB3);
	}
	
	if (!d.exec()) {
		return false;
	}
	
	var primero = true;
	
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "i_albaranescli";
	oParam.whereFijo = "NOT (lineasalbaranescli.candistribuida <> 0 AND lineasalbaranescli.canfactura = 0 AND lineasalbaranescli.tipoconcepto = 'Producto')";
	oParam.rptViewer = new FLReportViewer();
	
	var curImprimir = new FLSqlCursor("i_albaranescli");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_albaranescli_codigo", codAlbaran);
	curImprimir.setValueBuffer("h_albaranescli_codigo", codAlbaran);
	
	var nombreCx;
	if (idAlbaranComp) {
		if (!flfacturac.iface.pub_conectarDA()) {
			return;
		}
		nombreCx = flfacturac.iface.pub_conexionDA();
	}

	var numeroAlbaranes = AQUtil.sqlSelect("albaranescli inner join clientes on clientes.codcliente = albaranescli.codcliente","clientes.copiasalbaran","albaranescli.codigo = '" + codAlbaran + "'","albaranescli");

	if(!numeroAlbaranes || numeroAlbaranes == "") {
		numeroAlbaranes = 2;
	}
	
	if (chkA1.checked) {
		for (var i = 0; i < numeroAlbaranes; i++) {
			flfactinfo.iface.pub_ponerMembrete(true);
			oParam.append = !primero;
			oParam.pageBreak = !primero;
			oParam.display = i == numeroAlbaranes-1 && !(idAlbaranComp && chkB1.checked); //!((idAlbaranComp && chkB1.checked) || chkA2.checked || (idAlbaranComp && chkB2.checked));
			oParam.nombreCx = undefined;
			flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
			primero = false;
		}
	}
	if (idAlbaranComp && chkB1.checked) {
		for (var i = 0; i < numeroAlbaranes; i++) {
			flfactinfo.iface.pub_ponerMembrete(false);
			oParam.append = !primero;
			oParam.pageBreak = !primero;
			oParam.display = i == numeroAlbaranes-1; //!(chkA2.checked || (idAlbaranComp && chkB2.checked));
			oParam.nombreCx = nombreCx;
			flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
			primero = false;
		}
	}
	primero = true;
	oParam.rptViewer = undefined;
	oParam.rptViewer = new FLReportViewer();
	oParam.nombreInforme = "i_albaranescli_trans";
	oParam.nombreReport = "i_albaranescli_trans";
	oParam.whereFijo = undefined;
	if (chkA2.checked) {
		oParam.append = !primero;
		oParam.pageBreak = false; //!primero;
		oParam.display = !(idAlbaranComp && chkB2.checked);
		oParam.nombreCx = undefined;
		flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
		primero = false;
	}
	if (idAlbaranComp && chkB2.checked) {
		flfactinfo.iface.pub_ponerMembrete(false);
		oParam.append = !primero;
		oParam.pageBreak = true; //!primero;
		oParam.display = true;
		oParam.nombreCx = nombreCx;
		flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
		primero = false;
	}
	flfactinfo.iface.pub_ponerMembrete(false);
	
	oParamP = new Object;
	oParamP.rptViewer = new FLReportViewer();
	if (chkA3.checked) {
		oParamP.append = false;
		oParamP.pageBreak = true;
		oParamP.display = !(idAlbaranComp && chkB3.checked);
		var q = new FLSqlQuery("i_eti_albaranescli");
		q.setWhere("albaranescli.codigo = '" + codAlbaran + "'");
		formi_albaranescli.iface.pub_lanzaEtiquetas(q, oParamP);
	}
	if (idAlbaranComp && chkB3.checked) {
		oParamP.append = chkA3.checked;
		oParamP.pageBreak = true;
		oParamP.display = true;
		var q = new FLSqlQuery("i_eti_albaranescli", nombreCx);
		q.setWhere("albaranescli.idalbaran = " + idAlbaranComp);
		formi_albaranescli.iface.pub_lanzaEtiquetas(q, oParamP);
	}
}

function oficial_cargaMaximosLineaPedido(codPedido)
{
	var _i = this.iface;
	var qMLP = new AQSqlQuery;
	qMLP.setSelect("idlineapedido, enstock,referencia");
	qMLP.setFrom("em_lineaspedptes");
	qMLP.setWhere("codigo = '" + codPedido + "'");
	qMLP.setForwardOnly(true);
	if (!qMLP.exec()) {
		return false;
	}
	_i.topesLineaPed_ = new Object;
	var max;
	while (qMLP.next()) {
		max = qMLP.value("enstock");
		max = max < 0 ? 0 : max;
		_i.topesLineaPed_[qMLP.value("idlineapedido")] = max;
	}
	return true;
}

function oficial_dameMaximoLineaPedido(idlinea)
{
	var _i = this.iface;
	if (_i.topesLineaPed_ && idlinea in _i.topesLineaPed_) {
		return _i.topesLineaPed_[idlinea];
	}
	return false;
}

function oficial_tbnReservas_clicked()
{
	var _i = this.iface;

	if(!_i.compruebaUsuario("tbnReservas")) { 
		return false;	
	}
	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}
	_i.refrescarLineas();
	var cursor = this.child("tdbLineasPedPtes").cursor();
	var codAlmacen = "1";
	_i.refReserva_ = cursor.valueBuffer("referencia");

	_i.curReserva_.select("referencia = '" + _i.refReserva_ + "' AND codalmacen = '" + codAlmacen + "'")
	if (!_i.curReserva_.first()) {
		MessageBox.warning(sys.translate("No hay un registro de stock para la referencia y almac�n indicados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return;
	}

	formRecordem_reservasstock.iface.accion_ = "em_pedidosptes";

	connect(_i.curReserva_, "bufferCommited()", _i, "actualizarPorReferencia");
	_i.curReserva_.editRecord();
	
}

function oficial_actualizarPorReferencia()
{
	var _i = this.iface;
	_i.cargaDatos(_i.refReserva_, false, true);
	if (!_i.calculaEstadoPedidos()) {
		return false;
	}
	return true;
}

function oficial_tbnHojaCarga_clicked()
{
	var _i = this.iface;

	if(!_i.compruebaUsuario("tbnHojaCarga")) { 
		return false;	
	}
	
	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}

	var cursor = this.cursor();
	var codigo = cursor.valueBuffer("codigo");
	if (!codigo) {
		return false;
	}

	var idPedido = AQUtil.sqlSelect("pedidoscli", "idpedido","codigo = '" + codigo + "'");	

	if (!_i.validaPedido(idPedido)) {
		return false;
	}


	if (!_i.cargaMaximosLineaPedido(codigo)) {
		return false;
	}

	var oParam = this.iface.dameParamInformeHC(idPedido);
	if (!oParam) {
		return;
	}
	var curImprimir:FLSqlCursor = new FLSqlCursor("i_pedidoscli");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_pedidoscli_codigo", codigo);
	curImprimir.setValueBuffer("h_pedidoscli_codigo", codigo);
	if (!flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam)) {
		return false;
	}

	if (!AQSql.update("em_pedidospedptes", ["hojacarga"], [true], "idpedido = " + cursor.valueBuffer("idpedido"))) {
		return false;
	}
	if (!_i.cambiaHCPedido(cursor.valueBuffer("idpedido"), true)) {
		return false;
		}
	


	this.child("tdbPedidosPedPtes").refresh();
}

function oficial_validaPedido(idPedido)
{
	var _i = this.iface;
	var codCliente = AQUtil.sqlSelect("pedidoscli", "codcliente", "idpedido = " + idPedido);
	if (!flfacturac.iface.pub_controlBloqueoCliente(codCliente, "Enviar")) {
		return false;
	}

	if (!AQUtil.sqlSelect("pedidoscli", "editable", "idpedido = " + idPedido)) {
		var res = MessageBox.warning(sys.translate("El pedido seleccionado est� bloqueado.�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	return true;
}

function oficial_tbnHojaCompleta_clicked()
{
	var _i = this.iface;

	if(!_i.compruebaUsuario("tbnHojaCompleta")) { 
		return false;	
	}

	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}

	var cursor = this.cursor();
	var codigo = cursor.valueBuffer("codigo");
	if (!codigo) {
		return false;
	}
	if(!_i.imprimirHojaCompleta(codigo)) {
		return false;
	}
	if (!AQSql.update("em_pedidospedptes", ["hojacarga"], [true], "idpedido = " + cursor.valueBuffer("idpedido"))) {
		return false;
	}
	if (!_i.cambiaHCPedido(cursor.valueBuffer("idpedido"), true)) {
		return false;
	}

	this.child("tdbPedidosPedPtes").refresh();

}

function oficial_imprimirHojaCompleta(codigo)
{

	var _i = this.iface;
	var idPedido = AQUtil.sqlSelect("pedidoscli", "idpedido","codigo = '" + codigo + "'");	

	if (!_i.validaPedido(idPedido)) {
		return false;
	}

	if (!_i.cargaMaximosLineaPedido(codigo)) {
		return false;
	}

	var oParam = _i.dameParamInformeHCompleta(idPedido);
	if (!oParam) {
		return;
	}
	var curImprimir:FLSqlCursor = new FLSqlCursor("i_pedidoscli");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_pedidoscli_codigo", codigo);
	curImprimir.setValueBuffer("h_pedidoscli_codigo", codigo);
	if (!flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam)) {
		return false;
	}
	return true;
}

function oficial_tbnEtiqueta_clicked()
{
	var _i = this.iface;
	if(!_i.compruebaUsuario("tbnEtiqueta")) { 
		return false;	
	}
	
	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}

	var cursor = this.cursor();
	var codigo = cursor.valueBuffer("codigo");
	if (!codigo) {
		return false;
	}
	_i.imprimirEtiqueta(codigo);

}

function oficial_imprimirEtiqueta(sCodigos)
{
	var _i = this.iface;
	_i.rV_ = new FLReportViewer();
	var numPedidos;
	var p = 0;
	var append = false, display = true, newPage = false;
	var iInfo = 0;
	var curImprimir:FLSqlCursor = new FLSqlCursor("i_pedidoscli");
	var q = new AQSqlQuery;	
	q.setSelect("pedidoscli.idpedido, pedidoscli.em_coddropshipping, pedidoscli.codcliente, pedidoscli.codigo, clientes.em_tipoetiquetadrop");
	q.setFrom("pedidoscli INNER JOIN clientes ON clientes.codcliente = pedidoscli.codcliente");
	q.setWhere("pedidoscli.codigo IN ('" + sCodigos +"')");	
	if (!q.exec()){
		return;
	}
	numPedidos = q.size(); 
	flfactppal.iface.creaDialogoProgreso(sys.translate("Creando etiquetas..."), q.size());			
	var oParamPed = new Object;
	while(q.next()) {	
		AQUtil.setProgress(++p);
		numPedidos--;
		var idPedido = q.value("pedidoscli.idpedido");
		var codDropShipping = q.value("pedidoscli.em_coddropshipping");	
		var codCliente = q.value("pedidoscli.codcliente");	
		var codigo = q.value("pedidoscli.codigo");
		var tipoEtiqueta = q.value("clientes.em_tipoetiquetadrop");
		if(!codDropShipping || codDropShipping == "") {
			flfactppal.iface.ponMsgError(sys.translate("El pedido no est� asociado a un dropshippsing"),"warn",this);
			AQUtil.destroyProgressDialog();	 
			return;
		}	

		
		flprodinfo.iface.numHojaEtiqueta_ = 0;

		_i.informaArrayEtiDS(idPedido);

		var tam = flprodinfo.iface.lineas_.length;			

		var numHojas = tam/5;
		var numBarcodes;
		numHojas = Math.ceil(numHojas);	
		
		var numHojasBarcode = numHojas;
		var tamBarcodes = tam;
		//var append = false, display = true, newPage = false;
		//var iInfo = 0;
		oParamPed["idPedido"] = idPedido;		
		oParamPed["tipoEtiqueta"] = tipoEtiqueta;

		for(var k=0; k<numHojas; k++) {
			append = (iInfo > 0); /// Siempre si no es el primero
			//display = (k == (numHojas - 1)); /// Nunca si no es el �ltimo
			if(k ==(numHojas - 1) && numPedidos == 0) {
				display = true;
			} else {
				display = false;
			}
			newPage = (iInfo > 0); /// Al inicio de cada nueva orden, excepto la primera			

			oParamPed["append"] = append;
			oParamPed["display"] = display;
			oParamPed["newPage"] = newPage;
			//var oParam = _i.dameParamEtiDropShipping(idPedido, append, display, newPage);
			var oParam = _i.dameParamEtiDropShipping(oParamPed);
			if (!oParam) {
				AQUtil.destroyProgressDialog();	 
				return;
			}

			if(numHojasBarcode == 1) {
				oParam.numBarcodes = tamBarcodes;	
			} else {
				oParam.numBarcodes = 5;
			}
			oParam.codCliente = codCliente;

			//var curImprimir:FLSqlCursor = new FLSqlCursor("i_pedidoscli");
			curImprimir.setModeAccess(curImprimir.Insert);
			curImprimir.refreshBuffer();
			curImprimir.setValueBuffer("descripcion", "temp");
			curImprimir.setValueBuffer("d_pedidoscli_codigo", codigo);
			curImprimir.setValueBuffer("h_pedidoscli_codigo", codigo);
			if (!flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam)) {
				AQUtil.destroyProgressDialog();	 
				return false;
			}
			flprodinfo.iface.numHojaEtiqueta_ = flprodinfo.iface.numHojaEtiqueta_ + 5;
			numHojasBarcode--;
			tamBarcodes = tamBarcodes-5;
			iInfo++;
		}
	}	
	AQUtil.destroyProgressDialog();	 
}

/*function oficial_imprimirEtiqueta(codigo)
{
	var _i = this.iface;
	
	var q = new AQSqlQuery;	
	q.setSelect("idpedido, em_coddropshipping, codcliente");
	q.setFrom("pedidoscli");
	q.setWhere("codigo = '" + codigo + "'");
	q.setOrderBy
	if (!q.exec()){
		return;
	}  
	if(!q.first()) {
		return false;
	}
	var idPedido = q.value("idpedido");
	var codDropShipping = q.value("em_coddropshipping");	
	var codCliente = q.value("codcliente");	
	
	if(!codDropShipping || codDropShipping == "") {
		flfactppal.iface.ponMsgError(sys.translate("El pedido no est� asociado a un dropshippsing"),"warn",this);
		return;
	}	

	
	flprodinfo.iface.numHojaEtiqueta_ = 0;

	_i.informaArrayEtiDS(idPedido);

	var tam = flprodinfo.iface.lineas_.length;	

	

	var numHojas = tam/5;
	var numBarcodes;
	numHojas = Math.ceil(numHojas);	
	debug("tam: "+tam);
	debug("numHojas: "+numHojas);
	
	var numHojasBarcode = numHojas;
	var tamBarcodes = tam;
	var append = false, display = true, newPage = false;
	var iInfo = 0;
	for(var k=0; k<numHojas; k++) {



		append = (iInfo > 0); /// Siempre si no es el primero
		display = (k == (numHojas - 1)); /// Nunca si no es el �ltimo
		newPage = (iInfo > 0); /// Al inicio de cada nueva orden, excepto la primera			

		var oParam = _i.dameParamEtiDropShipping(idPedido, append, display, newPage);
		if (!oParam) {
			return;
		}

		if(numHojasBarcode == 1) {
			oParam.numBarcodes = tamBarcodes;	
		} else {
			oParam.numBarcodes = 5;
		}
		oParam.codCliente = codCliente;

		var curImprimir:FLSqlCursor = new FLSqlCursor("i_pedidoscli");
		curImprimir.setModeAccess(curImprimir.Insert);
		curImprimir.refreshBuffer();
		curImprimir.setValueBuffer("descripcion", "temp");
		curImprimir.setValueBuffer("d_pedidoscli_codigo", codigo);
		curImprimir.setValueBuffer("h_pedidoscli_codigo", codigo);
		if (!flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam)) {
			debug("falla li");
			return false;
		}
		flprodinfo.iface.numHojaEtiqueta_ = flprodinfo.iface.numHojaEtiqueta_ + 5;
		numHojasBarcode--;
		tamBarcodes = tamBarcodes-5;
		iInfo++;
	}	

}*/


function oficial_dameParamInformeHC(idPedido)
{
	var _i = this.iface;
	_i.totalAEnviar_ = 0;

	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "i_hojacarga";
	oParam.whereFijo = "em_lineaspedptes.enstock  > 0";
	oParam.orderBy = "pedidoscli.codigo, lineaspedidoscli.descripcion";
	return oParam;
}

function oficial_dameParamInformeHCompleta(idPedido)
{
	var _i = this.iface;
	_i.totalAEnviar_ = 0;

	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "i_hojacarga";
	oParam.orderBy = "pedidoscli.codigo, em_ubicaciones.em_ubinave, em_ubicaciones.em_ubipasillo, em_ubicaciones.em_ubiestante, em_ubicaciones.em_ubialtura, lineaspedidoscli.referencia";
	return oParam;
}

function oficial_dameAEnviar(nodo, campos)
{
	var _i = this.iface;
	var idLinea = nodo.attributeValue("lineaspedidoscli.idlinea");
	var pte = nodo.attributeValue("lineaspedidoscli.cantidad-lineaspedidoscli.totalenalbaran");
	var can = _i.dameMaximoLineaPedido(idLinea)
	can = can ? can : 0;
	var valor = can > pte ? pte : can;
	_i.totalAEnviar_ += parseFloat(valor);
	return valor;
}

function oficial_tbnCambiaHC_clicked()
{
	var _i = this.iface;
	if(!_i.compruebaUsuario("tbnCambiaHC")) { 
		return false;	
	}
	
	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}

	var cursor = this.cursor();
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
	cursor.setValueBuffer("hojacarga", !cursor.valueBuffer("hojacarga"));
	if (!cursor.commitBuffer()) {
		return false;
	}
	if (!_i.cambiaHCPedido(cursor.valueBuffer("idpedido"), cursor.valueBuffer("hojacarga"))) {
		return false;
	}
	return true;
}

function oficial_cambiaHCPedido(idPedido, hC)
{
	if (hC) {
		if (!AQUtil.execSql("UPDATE pedidoscli SET hojacarga = true, fechahc = CURRENT_DATE WHERE idpedido = " + idPedido)) {
			return false;
		}
	} else {
		if (!AQUtil.execSql("UPDATE pedidoscli SET hojacarga = false, fechahc = NULL WHERE idpedido = " + idPedido)) {
			return false;
		}
	}
}

function oficial_controlRestricciones()
{
	var _i = this.iface;
	var restringido = AQUtil.sqlSelect("usuarios", "restrigidoagente", "idusuario = '" + sys.nameUser() + "'");
	if (!restringido) {
		return;
	}
	this.child("barraBotones").close();
	this.child("chkFiltroPedidos").close();
	this.child("chkFiltroLineas").close();
	var filtro = "1 = 2";
	_i.codCliente_ = "NONE";
	var lista = AQUtil.sqlSelect("usuarios", "agentespermitidos", "idusuario = '" + sys.nameUser() + "'");
	if (lista && lista != "") {
		if (lista == "*") {
			filtro = "";
		} else {
			var aLista = lista.split(",");
			var sLista = aLista.join("', '");
			filtro = "codagente IN ('" + sLista + "')";
		}
	}
	this.child("tdbClientesPedPtes").cursor().setMainFilter(filtro);
	//this.child("tdbPedidosPedPtes").cursor().setMainFilter(filtro);
	_i.filtrarPedidos();
	_i.filtrarLineas();
}

function oficial_totalesHC(nodo, campo)
{
	var _i = this.iface;
  var valor;
	var idPedido = nodo.attributeValue("pedidoscli.idpedido");
	switch (campo) {
		case "cantidadpedido": {
			valor = AQUtil.sqlSelect("lineaspedidoscli", "SUM(cantidad)", "idpedido = " + idPedido);
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
		case "servidas": {
			valor = AQUtil.sqlSelect("lineaspedidoscli", "SUM(totalenalbaran)", "idpedido = " + idPedido);
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
		case "aservir": {
			valor = _i.totalAEnviar_;
			break;
		}
	}
	return valor;
}

function oficial_tbnTraspasoStock_clicked()
{
	var _i = this.iface;

	if(!_i.compruebaUsuario("tbnTraspasoStock")) { 
		return false;	
	}

	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}

	if (_i.curTS_) {
		_i.curTS_ = undefined;
	}
	_i.curTS_ = new FLSqlCursor("em_traspasosstock");
	formRecordem_traspasosstock.iface.accion_ = "em_pedidosptes";
	connect(_i.curTS_, "bufferCommited()", _i, "curTS_bufferCommited");
	_i.curTS_.insertRecord();
}

function oficial_curTS_bufferCommited()
{
	var _i = this.iface;
	if (!_i.curTS_) {
		return false;
	}
	flfactalma.iface.pub_procesaStocks();
	var codAlmacen = _i.curTS_.valueBuffer("codalmacen");
	var refDesde = _i.curTS_.valueBuffer("refdesde");
	var refHasta = _i.curTS_.valueBuffer("refhasta");
	_i.cargaDatos(refDesde, false, true);
	_i.cargaDatos(refHasta, false, true);
	if (!_i.calculaEstadoPedidos()) {
		return false;
	}
}

function oficial_actualizaUltimaCarga()
{
	var _i = this.iface;

	var fecha = new Date();

	var hora = fecha.toString().right(8);
	var fecha = fecha.toString().left(10);
	var user = sys.nameUser();

	var curGen = new FLSqlCursor("prodppal_general");

	curGen.select("1 = 1");
	if (!curGen.first())
	{
		return false;
	}

	curGen.setModeAccess(curGen.Edit);
	curGen.refreshBuffer();
	curGen.setValueBuffer("fechacargapc", fecha);
	curGen.setValueBuffer("horacargapc", hora);
	curGen.setValueBuffer("usuariocargapc", user);
	curGen.setNull("em_usucargapp");
	curGen.setNull("em_fechainicargapp");
	curGen.setNull("em_horainicargapp");
	curGen.commitBuffer();

	_i.pintaUltimaCarga();
}

function oficial_pintaUltimaCarga()
{
	var _i = this.iface;

	var curGen = new FLSqlCursor("prodppal_general");

	curGen.select("1 = 1");
	if (!curGen.first())
	{
		return false;
	}

	var fecha = curGen.valueBuffer("fechacargapc").toString().left(10);
	var hora = curGen.valueBuffer("horacargapc").toString().right(8);
	var user = curGen.valueBuffer("usuariocargapc");

	var anio = fecha.toString().left(4);
	var mes = fecha.toString().right(5);
	var mes = mes.left(2);
	var dia = fecha.toString().right(2);



	this.child("lblUltimaCarga").text = "�ltima carga: d�a " + dia + "/" + mes + "/" + anio + " a las " + hora + " por " + user;
}


//function oficial_dameParamEtiDropShipping(idPedido, append, display, newPage)
function oficial_dameParamEtiDropShipping(oParamPed)
{
	var _i = this.iface;	
	var idPedido = oParamPed["idPedido"];
	var append = oParamPed["append"];
	var display = oParamPed["display"];
	var newPage = oParamPed["newPage"];
	var tipoEtiqueta = oParamPed["tipoEtiqueta"]; 
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "em_i_etidropshipping";
	if(tipoEtiqueta == "Simplificada Interleave 2:5") {
		oParam.nombreReport = "em_i_etidropshippingPie";	
	} else {
		oParam.nombreReport = "em_i_etidropshippingPieIT";
	}	

	oParam.append = append;
	oParam.display = display;
	oParam.pageBreak = newPage;
	oParam.rptViewer = _i.rV_;

	oParam.groupBy = "pedidoscli.codcliente, pedidoscli.codigo, pedidoscli.nombrecliente,pedidoscli.direccion, pedidoscli.ciudad, pedidoscli.provincia,pedidoscli.cifnif, pedidoscli.codpostal, pedidoscli.fecha, pedidoscli.fechasalida,em_cargadropshipping.tracking,lineaspedidoscli.emcodbarras,lineaspedidoscli.referencia,lineaspedidoscli.descripcion,lineaspedidoscli.cantidad,paises.nombre,pedidoscli.fechahc,albaranescli.fecha,	em_cargadropshipping.infocarrier1, em_cargadropshipping.infocarrier2, em_cargadropshipping.codpostal,em_cargadropshipping.pedidoprivalia,em_cargadropshipping.telefono1,em_cargadropshipping.telefono2,clientes.nombre,dirclientes.descripcion, dirclientes.direccion,dirclientes.codpostal,dirclientes.provincia,dirclientes.ciudad,pedidoscli.observaciones,pedidoscli.docexterno, lineaspedidoscli.numlinea, clientes.em_tipocodbartrack, clientes.em_textofijo1, clientes.em_textofijo2,clientes.em_textofijo3";
	return oParam;

}

function oficial_informaArrayEtiDS(idPedido)
{
	var k=0;
	var descL1 = "";
	var descL2 = "";
	flprodinfo.iface.lineas_= [];
	var q = new AQSqlQuery;	
	q.setSelect("lineaspedidoscli.emcodbarras, lineaspedidoscli.referencia, lineaspedidoscli.descripcion, lineaspedidoscli.cantidad, lineaspedidoscli.totalenalbaran, lineaspedidoscli.codtamanoem, lineaspedidoscli.codcolorem, em_disenos.codseriediseno, subfamilias.descripcion, em_dibujos.descripcion, articulos.em_ubiactual");
	q.setFrom("lineaspedidoscli LEFT OUTER JOIN articulos ON lineaspedidoscli.referencia = articulos.referencia LEFT OUTER JOIN em_dibujos ON articulos.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno LEFT OUTER JOIN subfamilias ON subfamilias.codsubfamilia = articulos.codsubfamilia");
	q.setWhere("lineaspedidoscli.idpedido = " + idPedido); 			
	q.setOrderBy("lineaspedidoscli.numlinea");
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		flprodinfo.iface.lineas_[k] = [];
  		flprodinfo.iface.lineas_[k][0] = q.value("lineaspedidoscli.emcodbarras");
  		flprodinfo.iface.lineas_[k][1] = q.value("lineaspedidoscli.referencia");
  		var codseriediseno = q.value("em_disenos.codseriediseno");
  		if(codseriediseno && codseriediseno != "") {
  			var tamaSerie = codseriediseno.length;
  			if(tamaSerie == 1) {
  				flprodinfo.iface.lineas_[k][2] = q.value("lineaspedidoscli.descripcion").left(51) + " " + q.value("lineaspedidoscli.codtamanoem") + " " + q.value("lineaspedidoscli.codcolorem") + " - [" + codseriediseno + "]"
  			} else if(tamaSerie == 2) {
  				flprodinfo.iface.lineas_[k][2] = q.value("lineaspedidoscli.descripcion").left(50) + " " + q.value("lineaspedidoscli.codtamanoem") + " " + q.value("lineaspedidoscli.codcolorem") + " - [" + codseriediseno + "]"
  			} else if(tamaSerie == 3) {
  				flprodinfo.iface.lineas_[k][2] = q.value("lineaspedidoscli.descripcion").left(49) + " " + q.value("lineaspedidoscli.codtamanoem") + " " + q.value("lineaspedidoscli.codcolorem") + " - [" + codseriediseno + "]"
  			}


  		} else {
  			flprodinfo.iface.lineas_[k][2] = q.value("lineaspedidoscli.descripcion").left(57) + " " + q.value("lineaspedidoscli.codtamanoem") + " " + q.value("lineaspedidoscli.codcolorem");	
  		}
  		
  		flprodinfo.iface.lineas_[k][3] = q.value("lineaspedidoscli.cantidad");
  		flprodinfo.iface.lineas_[k][4] = q.value("lineaspedidoscli.totalenalbaran");
  		descL1 = "";
  		if(codseriediseno && codseriediseno != "") {
  			descL1 = "[" + codseriediseno + "] - ";
  		}
  		descL1 += q.value("subfamilias.descripcion"); 		

  		flprodinfo.iface.lineas_[k][5] = descL1;

  		descL2 = q.value("em_dibujos.descripcion") + " [" +  q.value("lineaspedidoscli.codtamanoem") + " " + q.value("lineaspedidoscli.codcolorem") + "]";
  		var ubicacion = q.value("articulos.em_ubiactual");
  		if(ubicacion && ubicacion != "") {
  			descL2 = descL2 + " - Ubica.: " + ubicacion;	
  		}
  		flprodinfo.iface.lineas_[k][6] = descL2;
  		k++;

	}	
}

function oficial_dameDatosStock(idStock)
{
	var _i = this.iface;
	var oParam = new Object;
	oParam.existencias = 0;
	oParam.disponible = 0;
	var q = new AQSqlQuery;	
	q.setSelect("cantidad,disponible");
	q.setFrom("stocks");
	q.setWhere("idstock = " + idStock); 				
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{
		oParam.existencias = q.value("cantidad");
		oParam.disponible = q.value("disponible");
	}	
	return oParam;
}
/*function oficial_refrescarLineas()
{
	var _i = this.iface;

	var mF = this.child("tdbLineasPedPtes").cursor().mainFilter();
	var fF = this.child("tdbLineasPedPtes").findFilter();
	var f = this.child("tdbLineasPedPtes").filter();
	var filtro = mF;
	if (fF != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += fF;
	}
	if (f != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += f;
	}	
	var idStock, id;
	var curLineas = this.child("tdbLineasPedPtes").cursor();
	curLineas.select(filtro);
	while (curLineas.next()) 
	{
		curLineas.setModeAccess(curLineas.Browse);
		curLineas.refreshBuffer();
		idStock = curLineas.valueBuffer("idstock");
		idLinea = curLineas.valueBuffer("id");
		var oDatos = _i.dameDatosStock(idStock);

		if (!AQUtil.execSql("update em_lineaspedptes set existencias = " + oDatos.existencias + ", disponible = " + oDatos.disponible + " WHERE id = " + idLinea)) {
			return false;
		}
		//curLineas.setValueBuffer("existencias",oDatos.existencias);
		//curLineas.setValueBuffer("disponible",oDatos.disponible);

		//if(!curLineas.commitBuffer()) {
		//	return false;
		//}
 
	}

	this.child("tdbLineasPedPtes").refresh()
}*/

function oficial_refrescarLineas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idStock, id;

	var idPedido = cursor.valueBuffer("idpedido");
	if(!idPedido) {
		return true;
	}
	var q = new FLSqlQuery;
	q.setSelect("idstock,id");
	q.setFrom("em_lineaspedptes");
	q.setWhere("idpedido = " + idPedido);	
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		idStock = q.value("idstock");
		idLinea = q.value("id");
		var oDatos = _i.dameDatosStock(idStock);

		if (!AQUtil.execSql("update em_lineaspedptes set existencias = " + oDatos.existencias + ", disponible = " + oDatos.disponible + " WHERE id = " + idLinea)) {
			return false;
		}	
	}	


	this.child("tdbLineasPedPtes").refresh()
}

function oficial_refrescaDatosStock(idStock)
{
	var _i = this.iface;
	return true;

}

function oficial_pbnGenerarAlbaranCDB_clicked()
{

	var _i = this.iface;

	if(!_i.compruebaUsuario("pbnGenerarAlbaranCDB")) { 
		return false;	
	}

	if(!_i.compruebaFechaApertura("pedidosptes")) {
		return false;
	}


	formem_genalbarancdb.iface.tblAlbaranes_ = false;
	var f = new FLFormSearchDB("em_genalbarancdb");
	f.cursor().setAction("em_pedidoscliparciales");
	var curGenAlbCDB = f.cursor();  
	curGenAlbCDB.setModeAccess(curGenAlbCDB.Insert);
	curGenAlbCDB.refreshBuffer();
	formpedidoscli.iface.idPedAlbCDB_ = curGenAlbCDB.valueBuffer("em_idpedalbcdb");
	f.setMainWidget();
	f.exec();
	if (!_i.calculaEstadoPedidos()) {			
		return false;
	}

}

function oficial_compruebaUsuario(tipo)
{
	var usuario = sys.nameUser();
	var usuarioCargaPP = AQUtil.sqlSelect("prodppal_general","em_usucargapp","1=1");
	if(usuarioCargaPP && usuarioCargaPP != "") {
		if(tipo == "recarga") {
			formUI.ponMsgWarn(sys.translate("El usuario %1 est� recargando actualmente, espere unos minutos y vuelva a intentarlo").arg(usuarioCargaPP));
		} else if(tipo == "emitirAlbaranCDB" || tipo == "emitirAlbaran") {
			formUI.ponMsgWarn(sys.translate("La consola se encuentra en proceso de recarga, cierre la pantalla sin guardar\ny la de pedidos pendientes y espere unos minutos para emitir albaranes."));			
		} else if(tipo == "traspasoStock") {
			formUI.ponMsgWarn(sys.translate("La consola se encuentra en proceso de recarga, cierre la pantalla sin guardar\ny la de pedidos pendientes y espere unos minutos para realizar el traspaso de stock."));			
		} else if(tipo == "reservasStock") {
			formUI.ponMsgWarn(sys.translate("La consola se encuentra en proceso de recarga, cierre la pantalla sin guardar\ny la de pedidos pendientes y espere unos minutos para editar reservas de stock."));			
		} else {
			formUI.ponMsgWarn(sys.translate("La consola se encuentra en proceso de recarga, cierre la consola y espere unos minutos."));
		}		
		return false;
	}
	return true; 
}

function oficial_actualizaUsuarioCargando()
{
	var fecha = new Date();
	var hora = fecha.toString().right(8);
	var fecha = fecha.toString().left(10);
	var user = sys.nameUser();

	if(!AQUtil.execSql("UPDATE prodppal_general SET em_usucargapp = '" + user + "', em_fechainicargapp = '" + fecha + "', em_horainicargapp = '" + hora + "' WHERE 1 = 1")) {
   		return false;
   	}
   	return true;
}

function oficial_pintaCargaActual(miForm)
{

	var curGen = new FLSqlCursor("prodppal_general");

	curGen.select("1 = 1");
	if (!curGen.first())
	{
		return false;
	}

	var fecha = curGen.valueBuffer("em_fechainicargapp").toString().left(10);
	var hora = curGen.valueBuffer("em_horainicargapp").toString().right(8);
	var user = curGen.valueBuffer("em_usucargapp");

	if(user && user != "") {
		var anio = fecha.toString().left(4);
		var mes = fecha.toString().right(5);
		var mes = mes.left(2);
		var dia = fecha.toString().right(2);
		miForm.child("lblEstado").show();
		miForm.child("lblEstado").text = "Recargando, inicio de carga: " + dia + "/" + mes + "/" + anio + " a las " + hora + " por " + user;

	} else {
		if(miForm.child("lblEstado")) {
			miForm.child("lblEstado").close();	
		}
		
	}
}


function oficial_compruebaFechaApertura(tipo)
{
	var _i = this.iface;
	var fechaUltCarga, horaUltCarga;
	var q = new AQSqlQuery;	
	q.setSelect("fechacargapc, horacargapc,usuariocargapc");
	q.setFrom("prodppal_general");
	q.setWhere("1 = 1"); 		
	if (!q.exec()){
		return true;
	}  
	if(!q.first()) {
		return true;
	}

	var fechaUltCarga = q.value("fechacargapc");
	var horaUltCarga = q.value("horacargapc");	
	var usuUltCarga  = q.value("usuariocargapc");	
	var usuario = sys.nameUser();

	if(!fechaUltCarga || fechaUltCarga == "" || !horaUltCarga || horaUltCarga == "" || !usuUltCarga || usuUltCarga == "") {
		return true;
	} 

	if(usuario == usuUltCarga) {
		return true;
	}

	debug("fechaApertura: " + _i.fechaApertura_);
	debug("horaApertura: " + _i.horaApertura_);
	debug("fechaUltCarga: "+ fechaUltCarga.toString().left(10));
	debug("horaUltCarga: "+horaUltCarga.toString().right(9));
	var fecUltCarga = new Date(Date.parse(fechaUltCarga.toString().left(10)+horaUltCarga.toString().right(9)));
	var fechaApertura = new Date(Date.parse(_i.fechaApertura_+_i.horaApertura_));

	debug("daysto: "+AQUtil.daysTo(fecUltCarga, fechaApertura));

	debug("fecUltCarga: "+fecUltCarga);
	debug("fechaApertura: "+fechaApertura);
	if(fecUltCarga.getTime() - fechaApertura.getTime() > 0) {
		if(tipo == "pedidosptes") {
			formUI.ponMsgWarn(sys.translate("La pantalla ha sido recargada por otro usuario, debe cerrarla y voverla a abrir para continuar."));	
		} else if(tipo == "emitirAlbaranCDB" || tipo == "emitirAlbaran") {
			formUI.ponMsgWarn(sys.translate("La pantalla ha sido recargada por otro usuario, debe cerrarla y voverla a abrir para continuar, cierre esta pantalla sin guardar, y la de pedidos pendientes y vuelva a intentarlo."));
		}		
		return false;		
	}
	return true;	
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////
