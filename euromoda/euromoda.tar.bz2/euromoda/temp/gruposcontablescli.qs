/***************************************************************************
                 gruposcontablescli.qs  -  description
                             -------------------
    begin                : lun nov 07 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) {
		this.ctx = context;
	}
	function init() {
		this.ctx.interna_init();
	}
	function validateForm():Boolean {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var ejercicioActual;
	var longSubcuenta;
	var posActualPuntoSubcuenta, posActualPuntoEfectos, posActualPuntoEfDesc, posActualPuntoEfCobro, posActualPuntoEfImp, posActualPuntoFacCobro, posActualPuntoFacDesc, posActualPuntoFacImp;
	var bloqueoSubcuenta;

	function oficial( context ) { interna( context ); } 
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.ejercicioActual = flfactppal.iface.pub_ejercicioActual();
	_i.longSubcuenta = AQUtil.sqlSelect("ejercicios", "longsubcuenta", "codejercicio = '" + _i.ejercicioActual + "'");
	_i.bloqueoSubcuenta = false; 
	_i.posActualPuntoSubcuenta = -1;
	_i.posActualPuntoEfectos = -1;
	_i.posActualPuntoEfDesc = -1;
	_i.posActualPuntoEfCobro = -1;
	_i.posActualPuntoEfImp = -1;
	_i.posActualPuntoFacCobro = -1;
	_i.posActualPuntoFacDesc = -1;
	_i.posActualPuntoFacImp = -1;
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();

	switch (fN) {
		case "codsubcuentacli": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoSubcuenta = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaCli", _i.longSubcuenta, _i.posActualPuntoSubcuenta);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentaefectos": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoEfectos = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaEfectos", _i.longSubcuenta, _i.posActualPuntoEfectos);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentaefdesc": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoEfDesc = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaEfDesc", _i.longSubcuenta, _i.posActualPuntoEfDesc);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentaefcobro": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoEfCobro = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaEfCobro", _i.longSubcuenta, _i.posActualPuntoEfCobro);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentaefimp": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoEfImp = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaEfImp", _i.longSubcuenta, _i.posActualPuntoEfImp);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentafaccobro": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoFacCobro = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaFacCobro", _i.longSubcuenta, _i.posActualPuntoFacCobro);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentafacdesc": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoFacDesc = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaFacDesc", _i.longSubcuenta, _i.posActualPuntoFacDesc);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
		case "codsubcuentafacimp": {
			if (!_i.bloqueoSubcuenta) {
				_i.bloqueoSubcuenta = true;
				_i.posActualPuntoFacImp = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuentaFacImp", _i.longSubcuenta, _i.posActualPuntoFacImp);
				_i.bloqueoSubcuenta = false;
			}
			break;
		}
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
