
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function dameDirBancoDev(codCuenta) {
		return this.ctx.euromoda_dameDirBancoDev(codCuenta);
	}
	function dameCiudadBancoDev(codCuenta) {
		return this.ctx.euromoda_dameCiudadBancoDev(codCuenta);
	}
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
function euromoda_dameDirBancoDev(codCuenta)
{
	return AQUtil.sqlSelect("cuentasbanco c INNER JOIN sucursales s ON c.agencia = s.agencia", "s.direccion", "c.codcuenta = '" + codCuenta + "'","cuentasbanco,sucursales");
}

function euromoda_dameCiudadBancoDev(codCuenta)
{
	return AQUtil.sqlSelect("cuentasbanco c INNER JOIN sucursales s ON c.agencia = s.agencia", "s.poblacion", "c.codcuenta = '" + codCuenta + "'","cuentasbanco,sucursales");
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
