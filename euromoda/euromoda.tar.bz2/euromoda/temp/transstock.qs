
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var pbnAutomaticas;
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function generarTransferenciasAutomaticas() {
		return this.ctx.euromoda_generarTransferenciasAutomaticas();
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function validaAlmacenesMovistock() {
		return this.ctx.euromoda_validaAlmacenesMovistock();
	}
	function creaLineasTransConf(curTrans) {
		return this.ctx.euromoda_creaLineasTransConf(curTrans);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class  pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_creaLineasTransConf(curTrans) {
		return this.creaLineasTransConf(curTrans);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	debug("entra al init"); 
	var _i = this.iface;
	_i.__init();
	var cursor = this.cursor();
	if (cursor.modeAccess() == cursor.Insert && cursor.action() == "em_transstock") {
		cursor.setValueBuffer("codordenprod", formem_materialesconf.cursor().valueBuffer("codorden"));
	}
	if (cursor.modeAccess() == cursor.Insert && cursor.action() == "em_transstock_ac") {
		cursor.setValueBuffer("codasigconf", formem_asignacionesconf.cursor().valueBuffer("codasigconf"));
		var codProveedor = formem_asignacionesconf.cursor().valueBuffer("codconfeccionista");
		cursor.setValueBuffer("codalmadestino", AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codProveedor + "'"));
	}
	if (!cursor.isNull("codasigconf")) {
		this.child("fdbCodAlmaDestino").setDisabled(true);
	}	
	connect(this.child("pbnAutomaticas"), "clicked()", _i, "generarTransferenciasAutomaticas");
	this.child("fdbCodAlmaOrigen").setFocus();
	this.mainWidget().show();
}

function euromoda_generarTransferenciasAutomaticas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbLineasTrans").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}
	if (!_i.creaLineasTransConf(cursor)) {
		return false;
	}
	this.child("tdbLineasTrans").refresh()
	_i.habilitarCampos();
}

function euromoda_creaLineasTransConf(cursor)
{
	var _i = this.iface;
	var almaOrigen = cursor.valueBuffer("codalmaorigen");
	var almaDestino = cursor.valueBuffer("codalmadestino");
	var idTrans = cursor.valueBuffer("idtrans");
	
	var listaFamEstampado = flfactalma.iface.pub_dameFamEstampado();
	var listaSubfamEstampado = flfactalma.iface.pub_dameSubfamEstampado();
	
	var query = new AQSqlQuery();
	var codAsigConf = cursor.valueBuffer("codasigconf");
	if (!codAsigConf) {
		sys.warnMsgBox(sys.translate("La transferencia de stock no est� asociada a una asignaci�n de �rdenes a confeccionista"));
		return false;
	}
	query.setSelect("ms.referencia, SUM(ms.cantidad*-1), a.descripcion")
	query.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion INNER JOIN movistock ms ON ls.codlote = ms.codloteprod INNER JOIN articulos a ON ms.referencia = a.referencia");
	query.setWhere("op.codasigconf = '" + codAsigConf + "' AND a.codfamilia NOT IN (" + listaFamEstampado + ")  AND a.codsubfamilia NOT IN (" + listaSubfamEstampado + ") GROUP BY ms.referencia, a.codfamilia, a.codsubfamilia, a.descripcion ORDER BY a.codfamilia, a.codsubfamilia, a.descripcion");
	if (!query.exec() ) {
		return false;
	}
	
	AQUtil.createProgressDialog(sys.translate("Creando transferencias autom�ticas"), query.size());
	var p = 0;
	var cantidad = 0, referencia, descripcion;
	var curLineaTS = new FLSqlCursor("lineastransstock"); 
	while(query.next()) {
		cantidad = parseFloat(query.value("SUM(ms.cantidad*-1)"));
		referencia = query.value("ms.referencia");
		descripcion = query.value("a.descripcion");
		if (flfactalma.iface.pub_esReferenciaXPartidas(referencia)) {
			continue;
		}
		AQUtil.setProgress(p++);
		curLineaTS.setModeAccess(curLineaTS.Insert);
		curLineaTS.refreshBuffer();
		curLineaTS.setValueBuffer("idtrans", idTrans);
		curLineaTS.setValueBuffer("numlinea", formRecordlineastransstock.iface.commonCalculateField("numlinea", curLineaTS));
		curLineaTS.setValueBuffer("referencia", referencia);
		curLineaTS.setValueBuffer("descripcion", descripcion);
		curLineaTS.setValueBuffer("cantidad", cantidad);
		if(!curLineaTS.commitBuffer()) {
			var res = MessageBox.warning(sys.translate("La inserci�n de la l�nea con referencia %1 ha fallado.\n�Desea continuar?").arg(referencia), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
			if (res != MessageBox.Yes) {
				sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
				return false;
			}
		}
	}
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	return true;
}

function euromoda_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (!_i.__validateForm()) {
		return false;
	}
	
	if (!_i.validaAlmacenesMovistock()) {
		return false;
	}
	
	return true;
}

function euromoda_validaAlmacenesMovistock()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var idTrans = cursor.valueBuffer("idtrans");
	if (AQUtil.sqlSelect("transstock tr INNER JOIN lineastransstock l ON  tr.idtrans = l.idtrans INNER JOIN movistock ms ON l.idlinea = ms.idlineats INNER JOIN stocks s ON ms.idstock = s.idstock", "tr.idtrans", "tr.idtrans = " + idTrans + " AND tr.codalmadestino <> s.codalmacen AND tr.codalmaorigen <> s.codalmacen", "transstock")) {
		sys.warnMsgBox(sys.translate("Hay l�neas de transferencia asociadas a almacenes distintos de los indicados en la cabecera de la transferencia"));
		return false;
	}
	
	return true;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
