/***************************************************************************
                 em_filtroordenesptes.qs  -  description
                             -------------------
    begin                : mar may 7 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  function oficial(context)
  {
    interna(context);
  }
  function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
  function construirFiltro(cursor) {
	  return this.ctx.oficial_construirFiltro(cursor);
  }
  function tbnLimpiarFiltro_clicked() {
	  return this.ctx.oficial_tbnLimpiarFiltro_clicked();
  }
  function limpiarFiltro(form) {
	  return this.ctx.oficial_limpiarFiltro(form);
  }

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
  function pub_construirFiltro(cursor) {
		return this.construirFiltro(cursor);
	}
	function pub_limpiarFiltro(form) {
		return this.limpiarFiltro(form);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;

  connect(this.cursor(), "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
  connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	
	this.child("fdbCodPedido").setFilter("codigo IN (SELECT pedido FROM em_ordenesptes)");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_construirFiltro(cursor)
{
	
	var estados = "";
	var pendientes = cursor.valueBuffer("pendientes");
	if (pendientes) {
		estados += (estados != "") ? ", " : "";
		estados += "'PTE'";
	}
	
	var enCurso = cursor.valueBuffer("encurso");
	if (enCurso) {
		estados += (estados != "") ? ", " : "";
		estados += "'EN CURSO'";
	}
	
	var ptesConfec = cursor.valueBuffer("ptesconfec");
	if (ptesConfec) {
		estados += (estados != "") ? ", " : "";
		estados += "'PTE CONFECCION'";
	}
	
	var filtro = estados != "" ? "estado IN (" + estados + ")" : "";
	
	var sinAsignar = cursor.valueBuffer("sinasignar");
	if (sinAsignar) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "estado = 'PTE CONFECCION' AND codconfeccionista IS NULL";
	}
	
	var asignadas = cursor.valueBuffer("asignadas");
	if (asignadas) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "estado = 'PTE CONFECCION' AND codconfeccionista IS NOT NULL";
	}
	
	var codPedido = cursor.valueBuffer("codpedido");
	if (codPedido) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "pedido = '" + codPedido + "'";
	}

	debug("Filtro " + filtro);
	return filtro;
}

function oficial_bufferChanged(fN)
{
	var cursor = this.cursor();
	switch(fN) {
		case "coddibestamp":{
			break;
		}
	}
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtro = _i.construirFiltro(cursor);
	if (!filtro) {
		filtro = "";
	}
	cursor.setValueBuffer("filtro", filtro);

	this.obj().accept();
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var cursor = miForm.cursor();
	var campos = "fdbPendientes,fdbEnCurso,fdbPtesConfec,fdbSinAsignar,fdbAsignadas";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(miForm, aCampos[i], false);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////