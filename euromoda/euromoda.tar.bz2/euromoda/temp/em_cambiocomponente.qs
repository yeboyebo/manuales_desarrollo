/***************************************************************************
                 em_cambiocomponente.qs  -  description
                             -------------------
    begin                : lun may 14 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function calculateField(fN) {
		return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	//var materialFT_;
	var ordenFT_;
  function oficial( context ) { interna( context ); } 
  function bufferChanged(fN) {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function validaReferencias() {
    return this.ctx.oficial_validaReferencias();
  }
  function pbnAplicar_clicked() {
    return this.ctx.oficial_pbnAplicar_clicked();
  }
  function cambiaComponente(oParam) {
    return this.ctx.oficial_cambiaComponente(oParam);
  }
  function iniciaFiltros() {
    return this.ctx.oficial_iniciaFiltros();
  }
  function pbnBuscar_clicked() {
    return this.ctx.oficial_pbnBuscar_clicked();
  }
  function tbnLimpiarFiltro_clicked() {
    return this.ctx.oficial_tbnLimpiarFiltro_clicked();
  }
  function pbnFichaTecnica_clicked() {
  	return this.ctx.oficial_pbnFichaTecnica_clicked();
  }
	function controlAccion() {
		return this.ctx.oficial_controlAccion();
	}
	function filtroCompenente() {
		return this.ctx.oficial_filtroCompenente();
	}
	function aniadeComponente(oParam) {
		return this.ctx.oficial_aniadeComponente(oParam);
	}
	function quitaComponente(oParam) {
		return this.ctx.oficial_quitaComponente(oParam);
	}
	function filtroOrden() {
		return this.ctx.oficial_filtroOrden();
	}
	function tdbArticulos_recordChoosed() {
		return this.ctx.oficial_tdbArticulos_recordChoosed();
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  connect(this.child("pbnAplicar"), "clicked()", _i, "pbnAplicar_clicked");
	connect(this.child("pbnBuscar"), "clicked()", _i, "pbnBuscar_clicked");
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
  connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
  connect(this.child("pbnFichaTecnica"), "clicked()", _i, "pbnFichaTecnica_clicked");
  connect(this.child("tdbArticulos").cursor(), "recordChoosed()", _i, "tdbArticulos_recordChoosed");
  switch (cursor.modeAccess()) {
  case cursor.Insert: {
		sys.setObjText(this, "fdbIdUsuario", sys.nameUser());
      break;
    }
  case cursor.Edit: {
      break;
    }
  }
  sys.disableObj(this, "fdbRefComponente");
  _i.iniciaFiltros();
	_i.controlAccion();
}

function interna_calculateField(fN)
{

	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "matftec": {
			var refCompuesto = cursor.valueBuffer("refftec");
			var orden = cursor.valueBuffer("ordenftec");
			if(refCompuesto && refCompuesto != "" && orden) {
				valor = AQUtil.sqlSelect("articuloscomp","refcomponente","refcompuesto = '" + refCompuesto + "' and orden = " + orden);
				if(!valor) {
					valor = "";
				}
			} else {
				valor = "";
			} 
			
			break;
		}		
		default: {
			valor = 0;
		}
	}
	return valor;
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_pbnAplicar_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();		
	var accion = cursor.valueBuffer("accion"); 

	switch (accion) {
		case "A�adir": {
			var filtroA = this.child("tdbArticulos").cursor().mainFilter();
			if (filtroA == "") {
				sys.warnMsgBox(sys.translate("Debe buscar los art�culos antes de realizar el cambio"));
				return false;
			}

			var referenciaft = cursor.valueBuffer("refftec");
 			if(!referenciaft || referenciaft =="") {
				sys.warnMsgBox(sys.translate("El campo 'Referencia F.T.' es obligatorio."));
				return false;
			}
			
			var ordenft = cursor.valueBuffer("ordenftec");
 			if(!ordenft || ordenft =="") {
				sys.warnMsgBox(sys.translate("El campo 'Orden F.T.' es obligatorio."));
				return false;
			}

			var materialft = cursor.valueBuffer("matftec");
 			if(!materialft || materialft =="") {
				sys.warnMsgBox(sys.translate("El campo 'Material F.T.' es obligatorio."));
				return false;
			}

			var oParam = new Object;		
			oParam.errorMsg = sys.translate("Error al a�adir el componente");
			oParam.numCambios = 0;
			var f = new Function("oParam", "return formRecordem_cambiocomponente.iface.aniadeComponente(oParam)");
			if (!sys.runTransaction(f, oParam)) {
				return false;
			}
			sys.warnMsgBox(sys.translate("Se ha a�adido el componente %1 a %2 composiciones.").arg(cursor.valueBuffer("matftec")).arg(oParam.numCambios));	

			break;
		}

		case "Cambiar": {

			var componente = cursor.valueBuffer("refprevio");
 			if(!componente || componente =="") {
				sys.warnMsgBox(sys.translate("El campo 'Referencia P.' es obligatorio."));
				return false;
			}

			var componenteN = cursor.valueBuffer("refnuevo");
 			if(!componenteN || componenteN =="") {
				sys.warnMsgBox(sys.translate("El campo 'Referencia N.' es obligatorio."));
				return false;
			}

			if (!_i.validaReferencias()) {
				return false;
			}

			var filtroA = this.child("tdbArticulos").cursor().mainFilter();
			if (filtroA == "") {
				sys.warnMsgBox(sys.translate("Debe buscar los art�culos antes de realizar el cambio"));
				return false;
			}

			var oParam = new Object;
			// 	oParam.curImport = cursor;
			oParam.errorMsg = sys.translate("Error al cambiar el componente");
			oParam.numCambios = 0;
			var f = new Function("oParam", "return formRecordem_cambiocomponente.iface.cambiaComponente(oParam)");
			if (!sys.runTransaction(f, oParam)) {
				return false;
			}
			MessageBox.information(sys.translate("%1 composiciones cambiadas").arg(oParam.numCambios), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");

			break;
		}

		case "Quitar": {
			var filtroA = this.child("tdbArticulos").cursor().mainFilter();
			if (filtroA == "") {
				sys.warnMsgBox(sys.translate("Debe buscar los art�culos antes de realizar el cambio"));
				return false;
			}
			var componente = cursor.valueBuffer("refprevio");
			
 			if(!componente || componente =="") {
				sys.warnMsgBox(sys.translate("El campo 'Referencia P.' es obligatorio."));
				return false;
			}

			var oParam = new Object;		
			oParam.errorMsg = sys.translate("Error al quitar el componente");
			oParam.numCambios = 0;
			var f = new Function("oParam", "return formRecordem_cambiocomponente.iface.quitaComponente(oParam)");
			if (!sys.runTransaction(f, oParam)) {
				return false;
			}
			sys.warnMsgBox(sys.translate("Se ha quitado el componente %1 a %2 composiciones.").arg(cursor.valueBuffer("matftec")).arg(oParam.numCambios));			
		
			break;
		}
	
	}


}

function oficial_cambiaComponente(oParam)
{
	var _i = this.iface;
  var cursor = this.cursor();
	
	var refPrevio = cursor.valueBuffer("refprevio");
	var refNuevo = cursor.valueBuffer("refnuevo");
	/// Porque no hay comprobaci�n de integridad
	refNuevo = AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + refNuevo + "'");
	if (!refNuevo) {
		MessageBox.warning(sys.translate("Debe indicar un art�culo nuevo v�lido"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	var desNuevo = AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + refNuevo + "'");
	desNuevo = desNuevo.left(100);
	var codColor = AQUtil.sqlSelect("articulos", "codcolorem", "referencia = '" + refNuevo + "'");
	var codTamano = AQUtil.sqlSelect("articulos", "codtamanoem", "referencia = '" + refNuevo + "'");
	
	var filtroA = this.child("tdbArticulos").cursor().mainFilter();
	var filtroC = "refcomponente = '" + refPrevio + "'";
	filtroC += filtroA != "" ? (" AND refcompuesto IN (SELECT referencia FROM articulos WHERE " + filtroA + ")") : "";
	
	var curComponente = new FLSqlCursor("articuloscomp");
	curComponente.setActivatedCommitActions(false);
	curComponente.setActivatedCheckIntegrity(false);
	curComponente.select(filtroC);
	AQUtil.createProgressDialog(sys.translate("Cambiando composiciones..."), curComponente.size());
	var p = 0;
	while (curComponente.next()) {
		AQUtil.setProgress(++p);
		curComponente.setModeAccess(curComponente.Edit);
		curComponente.refreshBuffer();
		curComponente.setValueBuffer("refcomponente", refNuevo);
		curComponente.setValueBuffer("desccomponente", desNuevo);
		curComponente.setValueBuffer("codcolorem", codColor);
		curComponente.setValueBuffer("codtamanoem", codTamano);
		if (!curComponente.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			oParam.errorMsg = sys.translate("scripts", "Error al cambiar el componente %1 para el art�culo %2").arg(refPrevio).arg(curComponente.valueBuffer("refcompuesto"));
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	oParam.numCambios = p;
	return true;
}

function oficial_validaReferencias()
{
	var _i = this.iface;
  var cursor = this.cursor();
  
	var refPrevio = cursor.valueBuffer("refprevio");
	var refNuevo = cursor.valueBuffer("refnuevo");
	
	if (!AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + refPrevio + "' AND em_tipoarticulo = 'M.Prima'")) {
		MessageBox.warning(sys.translate("El art�culo %1 no existe o no es del tipo M.Prima").arg(refPrevio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	if (!AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + refNuevo + "' AND em_tipoarticulo = 'M.Prima'")) {
		MessageBox.warning(sys.translate("El art�culo %1 no existe o no es del tipo M.Prima").arg(refNuevo), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function oficial_iniciaFiltros()
{
	this.child("fdbRefNuevo").setFilter("em_tipoarticulo = 'M.Prima'");
	this.child("fdbRefPrevio").setFilter("em_tipoarticulo = 'M.Prima'");
}

function oficial_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  
	switch (fN) {
		case "refprevio": {
			cursor.setValueBuffer("refcomponente", cursor.valueBuffer("refprevio"));
			break;
		}
		case "accion": {
			_i.controlAccion();
			break;
		}
		case "refftec": {			
			_i.filtroOrden();
			_i.filtroCompenente();
			break;
		}
		case "matftec": {
			//sys.setObjText(this, "fdbCompFtec", _i.calculateField("matftec"));
			break;
		}
		case "ordenftec": {
			sys.setObjText(this, "fdbMatFtec", _i.calculateField("matftec"));
			break;
		}
  }
}

function oficial_pbnBuscar_clicked()
{
	var cursor = this.cursor();
	var f = formem_filtrosarticulos.iface.pub_construirFiltro(cursor);
	this.child("tdbArticulos").cursor().setMainFilter(f);
	this.child("tdbArticulos").refresh();
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	formem_filtrosarticulos.iface.pub_limpiarFiltro(this);
	cursor.setValueBuffer("refcomponente", cursor.valueBuffer("refprevio"));
}

function oficial_pbnFichaTecnica_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbArticulos").cursor();
	
	var referencia = cursor.valueBuffer("referencia");
	if(!referencia) {
		sys.warnMsgBox(sys.translate("Debe de seleccionar una referencia"));
		return false;
	}

	var f = new FLFormSearchDB("em_fichatecnicaedit");
	var curArticulos = f.cursor();	
	curArticulos.select("referencia = '" + referencia + "'");
	if (!curArticulos.first()) {
		return;
	}
	curArticulos.setModeAccess(curArticulos.Edit);
	curArticulos.refreshBuffer();
	f.setMainWidget();	
	f.exec();
	//var acpt = f.exec();
	//debug("acpt: "+acpt);
		/*cursor.setAction("em_fichatecnicaedit");
		cursor.editRecord();
		cursor.setAction("em_cambiocomponente");*/
	//if(acpt) {
		//debug("referncia aqui ya: "+_i.materialFT_);
		sys.setObjText(this, "fdbRefFtec", referencia);
		if(_i.ordenFT_) {
			sys.setObjText(this, "fdbOrdenFtec", _i.ordenFT_);
		}
		//sys.setObjText(this, "fdbMatFtec", _i.materialFT_);

	//}


	

}

function oficial_controlAccion()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var accion = cursor.valueBuffer("accion");
	if(accion == "A�adir") {	
		this.child("gbxPrevio").close();
		this.child("gbxNuevo").close();
		this.child("gbxAnadir").show();	
		_i.filtroOrden();
		_i.filtroCompenente();	
		
	} else {
		this.child("gbxPrevio").show();
		this.child("gbxNuevo").show();
		this.child("gbxAnadir").close();
	}
}

function oficial_filtroOrden()
{
	var cursor = this.cursor();
	var refCompuesto = cursor.valueBuffer("refftec");
	var filtro = "";
	if(refCompuesto && refCompuesto != "") {
		filtro = "refcompuesto = '" + refCompuesto + "'";
	}
	debug("filtro: "+filtro);
	this.child("fdbOrdenFtec").setFilter(filtro);
}

function oficial_filtroCompenente()
{
	var cursor = this.cursor();
	var refCompuesto = cursor.valueBuffer("refftec");
	var filtro = "";
	if(refCompuesto && refCompuesto != "") {
		filtro = "referencia IN (SELECT refcomponente FROM articuloscomp WHERE refcompuesto = '" + refCompuesto + "')";
	}
	debug("filtro: "+filtro);
	this.child("fdbMatFtec").setFilter(filtro);
}

function oficial_aniadeComponente(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var compuesto = cursor.valueBuffer("refftec"); 
	var material = cursor.valueBuffer("matftec");
	var orden = cursor.valueBuffer("ordenftec"); 
	//var componente = cursor.valueBuffer("compftec");
	/// Porque no hay comprobaci�n de integridad
	material = AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + material + "'");
	if (!material) {
		sys.warnMsgBox(sys.translate("Debe indicar una referencia v�lida."));
		return false;
	}

	var filtroA = this.child("tdbArticulos").cursor().mainFilter();	
	debug("filtroA: "+filtroA);

	var curOrigen = new FLSqlCursor("articuloscomp");
	curOrigen.select("refcompuesto = '" + compuesto + "' and orden = " + orden);
	if(!curOrigen.first()) {
		return false;
	}
	curOrigen.setModeAccess(curOrigen.Browse);
	curOrigen.refreshBuffer();
	var componente = curOrigen.valueBuffer("em_codcomponente");
	
	var q = new AQSqlQuery;	
	q.setSelect("referencia");
	q.setFrom("articulos");
	q.setWhere(filtroA + " and referencia <> '" + compuesto + "'"); 			
	if (!q.exec()){
		return;
	}  
	debug("q: "+q.sql());
	AQUtil.createProgressDialog(sys.translate("A�adiendo componente a composiciones..."), q.size());
	var p = 0;	
	while(q.next())
	{
		AQUtil.setProgress(++p);
		var referencia = q.value("referencia");
		var curComponente = new FLSqlCursor("articuloscomp");
		curComponente.setActivatedCommitActions(false);
		curComponente.setActivatedCheckIntegrity(false);		
		//hay que filtrar por el campo em_componente
		//miramos si existe ya alguno con el mismo em_componente, si existe se saca mensaje y si no existe se inserta
		curComponente.select("refcompuesto = '" + referencia + "' and refcomponente = '" + material + "' and em_codcomponente = '" + componente + "'");
		if(curComponente.first()) {
			var res = MessageBox.information(sys.translate("Existe ya el material %1 con componente %2 en la referencia %3. �Desea a�adirlo?").arg(material).arg(componente).arg(referencia), MessageBox.Yes, MessageBox.No)
			if (res != MessageBox.Yes) {
				continue;
			}
			
			
		}
		var orden = AQUtil.sqlSelect("articuloscomp","MAX(orden)","refcompuesto = '" + referencia + "'");
		if(!orden) {
			orden = 100;
		} else {
			orden += 100;
		}
		curComponente.setModeAccess(curComponente.Insert);
		curComponente.refreshBuffer();
		curComponente.setValueBuffer("refcompuesto",referencia);
		curComponente.setValueBuffer("orden",orden);
		curComponente.setValueBuffer("refcomponente",material);
		curComponente.setValueBuffer("desccomponente",curOrigen.valueBuffer("desccomponente"));
		curComponente.setValueBuffer("codtamanoem",curOrigen.valueBuffer("codtamanoem"));
		curComponente.setValueBuffer("codcolorem",curOrigen.valueBuffer("codcolorem"));
		curComponente.setValueBuffer("cantidad",curOrigen.valueBuffer("cantidad"));
		curComponente.setValueBuffer("largo",curOrigen.valueBuffer("largo"));
		curComponente.setValueBuffer("ancho",curOrigen.valueBuffer("ancho"));
		curComponente.setValueBuffer("alto",curOrigen.valueBuffer("alto"));
		curComponente.setValueBuffer("piezasancho",curOrigen.valueBuffer("piezasancho"));
		curComponente.setValueBuffer("factor",curOrigen.valueBuffer("factor"));
		curComponente.setValueBuffer("componormal",curOrigen.valueBuffer("componormal"));
		if (componente && componente != "") {
			curComponente.setValueBuffer("em_codcomponente",componente);
		}
		curComponente.setValueBuffer("componente",curOrigen.valueBuffer("componente"));
		curComponente.setValueBuffer("reservar",curOrigen.valueBuffer("reservar"));
		curComponente.setValueBuffer("codunidad",curOrigen.valueBuffer("codunidad"));
		curComponente.setValueBuffer("idseccion",curOrigen.valueBuffer("idseccion"));
		curComponente.setValueBuffer("observaciones",curOrigen.valueBuffer("observaciones"));
		curComponente.setValueBuffer("idtipoopcionart",curOrigen.valueBuffer("idtipoopcionart"));
		curComponente.setValueBuffer("idopcionarticulo",curOrigen.valueBuffer("idopcionarticulo"));
		//curComponente.setValueBuffer("idtipotareapro",curOrigen.valueBuffer("idtipotareapro"));
		curComponente.setValueBuffer("diasantelacion",curOrigen.valueBuffer("diasantelacion"));
		curComponente.setValueBuffer("codfamiliacomponente",curOrigen.valueBuffer("codfamiliacomponente"));
		curComponente.setValueBuffer("ftenlft",curOrigen.valueBuffer("ftenlft"));
		curComponente.setValueBuffer("idgit",curOrigen.valueBuffer("idgit"));
		curComponente.setValueBuffer("anchopiezatej",curOrigen.valueBuffer("anchopiezatej"));
		if (!curComponente.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			oParam.errorMsg = sys.translate("scripts", "Error al a�adir el componente %1 a la referencia %2").arg(material).arg(referencia);
			return false;
		}			
  			
	}
	AQUtil.destroyProgressDialog();
	oParam.numCambios = p;
	return true;
}

function oficial_quitaComponente(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var componente = cursor.valueBuffer("refprevio"); 
	var filtroA = this.child("tdbArticulos").cursor().mainFilter();	
	debug("filtroA: "+filtroA);
	
	var q = new AQSqlQuery;	
	q.setSelect("referencia");
	q.setFrom("articulos");
	q.setWhere(filtroA); 			
	if (!q.exec()){
		return;
	}  
	debug("q: "+q.sql());
	AQUtil.createProgressDialog(sys.translate("Quitando componente a composiciones..."), q.size());
	var p = 0;	
	while(q.next())
	{
		AQUtil.setProgress(++p);
		var referencia = q.value("referencia");
		var curComponente = new FLSqlCursor("articuloscomp");
		curComponente.setActivatedCommitActions(false);
		curComponente.setActivatedCheckIntegrity(false);		
		curComponente.select("refcompuesto = '" + referencia + "' and refcomponente = '" + componente + "' ");
		if (curComponente.first()) {			
			curComponente.setModeAccess(curComponente.Del);
			curComponente.refreshBuffer();			
			if (!curComponente.commitBuffer()) {
				AQUtil.destroyProgressDialog();
				oParam.errorMsg = sys.translate("scripts", "Error al quitar el componente %1 a la referencia %2").arg(material).arg(referencia);
				return false;
			}			
  		}	
	}
	AQUtil.destroyProgressDialog();
	oParam.numCambios = p;
	return true;
}

function oficial_tdbArticulos_recordChoosed()
{
	var _i = this.iface;
	var curArticulo = this.child("tdbArticulos").cursor();
	var cursor = this.cursor();
   curArticulo.commitBufferCursorRelation();
   curArticulo.editRecord();  
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
