
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function dameFiltro() {
		return this.ctx.euromoda_dameFiltro();
	}
	function dameDomiciliados() {
		return this.ctx.euromoda_dameDomiciliados();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	if (this.child("fdbCodPago")) {
		this.child("fdbCodPago").close();
	}
	if (this.child("fdbDesPago")) {
		this.child("fdbDesPago").close();
	}
	
	var aC = ["codigo", "estado", "importe", "fecha", "fechav", "em_codpago", "em_codclasificacion"];
	this.child("tdbRecibos").setOrderCols(aC);
	this.child("tdbRecibosSel").setOrderCols(aC);
	
}

function euromoda_dameFiltro()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var filtro = cursor.valueBuffer("filtro");
	var desde = this.child("dedDesde").date;
	var hasta = this.child("dedHasta").date;
	
	if (desde) {
		filtro += " AND fechav >= '" + desde + "'";
	}
	if (hasta) {
		filtro += " AND fechav <= '" + hasta + "'";
	}
	
	if (this.child("chkDomiciliados").checked) {
		if (_i.listaDom != "") {
			filtro += (filtro != "") ? " AND " : "";
			filtro += "em_codpago IN (" + _i.listaDom + ")";
		}
	}
	
	var codClasificacion = cursor.valueBuffer("em_codclasificacion");
	if (codClasificacion) {
		filtro += " AND em_codclasificacion = '" + codClasificacion + "'";
	}
	var emCodPago = cursor.valueBuffer("em_codpago");
	if (emCodPago) {
		filtro += " AND em_codpago = '" + emCodPago + "'";
	}
debug("filtro = " + filtro);
	return filtro;
}

function euromoda_dameDomiciliados()
{
	var _i = this.iface;
	_i.listaDom = "";
	var q = new FLSqlQuery();
	q.setSelect("em_codpago");
	q.setFrom("em_formaspago");
	q.setWhere("domiciliado IS true");

	if(!q.exec()){
		return false;
	}
	
	while(q.next()){
		_i.listaDom += (_i.listaDom != "") ? ", " : "";
		_i.listaDom += "'" + q.value("em_codpago") + "'";
	}
	
	return true;

}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
