
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
  function euromoda( context ) { oficial ( context ); }
  function obtenerParamInforme() {
    return this.ctx.euromoda_obtenerParamInforme();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA //////////////////////////////////////////////////
function euromoda_obtenerParamInforme()
{
  var cursor = this.cursor();
  var seleccion= cursor.valueBuffer("id");
  if (!seleccion) {
    return false;
  }
  var _i = this.iface;
  var pI = _i.__obtenerParamInforme();
  
  if (pI.nombreInforme == "i_resfacturasprov") {
    switch(cursor.valueBuffer("tipoinforme")) {
      case "Euros":
      case "Moneda original y euros": {
	return pI;
      }
    }
  } else {
    return pI;
  }
  var oB = pI.orderBy;
  if (oB == "") {
    oB = "facturasprov.coddivisa";
  } else {
    oB = "facturasprov.coddivisa, " + oB;
  }
  pI.orderBy = oB;
  return pI;
}
//// EUROMODA //////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
