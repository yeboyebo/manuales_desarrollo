/***************************************************************************
                 em_filtrosclientes.qs  -  description
                             -------------------
    begin                : mie may 08 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	var bloqueoProvincia = false;
  function oficial(context)
  {
    interna(context);
  }
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function construirFiltroCli(cursor) {
		return this.ctx.oficial_construirFiltroCli(cursor);
	}
	function construirFiltroDireccionesCli(cursor) {
		return this.ctx.oficial_construirFiltroDireccionesCli(cursor);
	}
	function construirFiltroPedidosCli(cursor) {
		return this.ctx.oficial_construirFiltroPedidosCli(cursor);
	}
  function tbnLimpiarFiltro_clicked() {
	  return this.ctx.oficial_tbnLimpiarFiltro_clicked();
	}
	function limpiarFiltro(form) {
		return this.ctx.oficial_limpiarFiltro(form);
	}
	function comprobarTabla() {
		return this.ctx.oficial_comprobarTabla();
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function validarCodigoProvincia() {
		return this.ctx.oficial_validarCodigoProvincia();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
	function pub_limpiarFiltro(form) {
		return this.limpiarFiltro(form);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
	var cursor = this.cursor();
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
  connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	_i.comprobarTabla();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_construirFiltroCli(cursor)
{
	var filtro = "";

	var codGrupo = cursor.valueBuffer("codgrupo");
	if (codGrupo && codGrupo != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (codGrupo.find(",") >= 0) {
			filtro += ("clientes.codgrupo IN ('" + codGrupo.split(",").join("', '") + "')");
		} else {
			filtro += "clientes.codgrupo = '" + codGrupo + "'";
		}
	}

	var bloqueado = cursor.valueBuffer("bloqueado");
	if (bloqueado && bloqueado != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (bloqueado){
			case "No": {
				filtro += "(clientes.bloqueado = 'No' OR clientes.bloqueado = ' ')";
				break;
			}
			case "Enviar": {
				filtro += "clientes.bloqueado = 'Enviar'";
				break;
			}
			case "Facturar": {
				filtro += "clientes.bloqueado = 'Facturar'";
				break;
			}
			default: {
				filtro += "clientes.bloqueado = 'Todo'";
				break;
			}
		}
	}

	var riesgo = cursor.valueBuffer("riesgosuperado");
	if (riesgo && riesgo != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (riesgo){
			case "No": {
				filtro += "(clientes.riesgomax >= clientes.riesgoalcanzado OR clientes.riesgoalcanzado is null)";
				break;
			}
			default:
				filtro += "clientes.riesgomax < clientes.riesgoalcanzado";
				break;
		}
	}

	return filtro;
}

function oficial_construirFiltroDireccionesCli(cursor)
{
	var _i = this.iface;

	var filtro = _i.construirFiltroCli(cursor);

	var provincia = cursor.valueBuffer("idprovincia");
	if (provincia && provincia != ""){
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "dirclientes.idprovincia = '" + provincia + "'";
	}

	var pais = cursor.valueBuffer("codpais");
	if (pais && pais != ""){
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "dirclientes.codpais = '" + pais + "'";
	}

	return filtro;
}

function oficial_construirFiltroPedidosCli(cursor)
{
	var filtro = "";

	var codGrupo = cursor.valueBuffer("codgrupo");
	if (codGrupo && codGrupo != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (codGrupo.find(",") >= 0) {
			filtro += ("pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.codgrupo IN ('" + codGrupo.split(",").join("', '") + "'))");
		} else {
			filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.codgrupo = '" + codGrupo + "')";
		}
	}

	var bloqueado = cursor.valueBuffer("bloqueado");
	if (bloqueado && bloqueado != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (bloqueado){
			case "No": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE (clientes.bloqueado = 'No' OR clientes.bloqueado = ' '))";
				break;
			}
			case "Enviar": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.bloqueado = 'Enviar')";
				break;
			}
			case "Facturar": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.bloqueado = 'Facturar')";
				break;
			}
			default: {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.bloqueado = 'Todo')";
				break;
			}
		}
	}

	var riesgo = cursor.valueBuffer("riesgosuperado");
	if (riesgo && riesgo != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (riesgo){
			case "No": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE (clientes.riesgomax >= clientes.riesgoalcanzado OR clientes.riesgoalcanzado is null))";
				break;
			}
			default:
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.riesgomax < clientes.riesgoalcanzado)";
				break;
		}
	}

	var provincia = cursor.valueBuffer("idprovincia");
	if (provincia && provincia != ""){
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "pedidoscli.idprovincia = '" + provincia + "'";
	}

	var pais = cursor.valueBuffer("codpais");
	if (pais && pais != ""){
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "pedidoscli.codpais = '" + pais + "'";
	}

	return filtro;
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (!_i.validarCodigoProvincia()) {
		return false;
	}

	if (!flfactppal.iface.pub_validarProvincia(cursor)) {
		return false;
	}

	var tabla = cursor.valueBuffer("tabla");
	var filtro;

	switch (tabla){
		case "clientes": {
			filtro = _i.construirFiltroCli(cursor);
			break;
		}
		case "qryclientes": {
			///dirclientes
			filtro = _i.construirFiltroDireccionesCli(cursor);
			break;
		}
		case "pedidoscli": {
			filtro = _i.construirFiltroPedidosCli(cursor);
			break;
		}
	}

	if (!filtro) {
		filtro = "";
	}
	cursor.setValueBuffer("filtro", filtro);

	this.obj().accept();
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var cursor = miForm.cursor();
	var campos = "fdbNombreGrupo,fdbCodGrupo,fdbProvincia,fdbIdProvincia,fdbCodPais,fdbBanderaPais";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(miForm, aCampos[i], "");
	}

	cursor.setValueBuffer("bloqueado", "Todos");
	cursor.setValueBuffer("riesgosuperado", "Todos");
}

function oficial_comprobarTabla() {

	var cursor = this.cursor();
	var tabla = cursor.valueBuffer("tabla");

	if (tabla == "clientes") {
		this.child("gbxLocalizacion").setDisabled(true);
	} else {
		this.child("gbxLocalizacion").setDisabled(false);
	}
}

function oficial_bufferChanged(fN)
{
	var cursor = this.cursor();

	var cursor = this.cursor();
	switch (fN) {
		case "provincia": {
			if (!this.iface.bloqueoProvincia) {
				this.iface.bloqueoProvincia = true;
				flfactppal.iface.pub_obtenerProvincia(this);
				this.iface.bloqueoProvincia = false;
			}
			break;
		}
		case "idprovincia": {
			if (cursor.valueBuffer("idprovincia") == 0) {
				cursor.setNull("idprovincia");
			}
			break;
		}
	}
}

function oficial_validarCodigoProvincia()
{
	var cursor = this.cursor();

	var nomProvincia = cursor.valueBuffer("provincia");
	if (nomProvincia && nomProvincia != "") {
		nomProvincia.toUpperCase();
	}
	else {
		cursor.setValueBuffer("idprovincia","");
		return true;
	}

	var codProvincia = AQUtil.sqlSelect("provincias","idprovincia","provincia = '" + nomProvincia + "'");

	if(codProvincia) {
		cursor.setValueBuffer("idprovincia",codProvincia);
	}
	else {
		sys.warnMsgBox(sys.translate("La provincia %1 no se encuentra en la base de datos.").arg(nomProvincia));
		return false;
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////