
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	var rV_, etiquetasExtra_;
	var numPagInfoOrden_, numPag_;;
	function euromoda( context ) { prod ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function filtra() {
		return this.ctx.euromoda_filtra();
	}
	function columnas() {
		return this.ctx.euromoda_columnas();
	}
	function calculaEtiquetasExtra() {
		return this.ctx.euromoda_calculaEtiquetasExtra();
	}
	function toolButtomInsert_clicked(curGAnt) {
		return this.ctx.euromoda_toolButtomInsert_clicked(curGAnt);
	}
  function borrarOrden(codOrden) {
    return this.ctx.euromoda_borrarOrden(codOrden);
  }
  function imprimir() {
		return this.ctx.euromoda_imprimir();
	}
	function informeProd(tipoInforme, codOrden, append, display, pageBreak) {
		return this.ctx.euromoda_informeProd(tipoInforme, codOrden, append, display, pageBreak);
	}
	function dameParamInforme(nombre, append, display, pageBreak) {
		return this.ctx.euromoda_dameParamInforme(nombre, append, display, pageBreak);
	}
	function tbnImprimeAA_clicked() {
		return this.ctx.euromoda_tbnImprimeAA_clicked();
	}
	function dameOrdenDH(tipoInforme) {
		return this.ctx.euromoda_dameOrdenDH(tipoInforme);
	}
	function numPagina() {
		return this.ctx.euromoda_numPagina();
	}
	function imprimirEtiquetas() {
    return this.ctx.euromoda_imprimirEtiquetas();
  }
	function arrayEtiquetas(oDH) {
    return this.ctx.euromoda_arrayEtiquetas(oDH);
  }
	function imprimeEtiquetas(w) {
    return this.ctx.euromoda_imprimeEtiquetas(w);
  }
	function dameArrayEtiquetas(w) {
    return this.ctx.euromoda_dameArrayEtiquetas(w);
  }
	function imprimeOrdenProd(oDH) {
    return this.ctx.euromoda_imprimeOrdenProd(oDH);
  }
	function imprimeOrdenMat(oDH) {
    return this.ctx.euromoda_imprimeOrdenMat(oDH);
  }
	function imprimeEtiquetasMat(codOrden, append, display, pageBreak) {
    return this.ctx.euromoda_imprimeEtiquetasMat(codOrden, append, display, pageBreak);
  }
  function tbnMovimientosNoOK_clicked()  {
    return this.ctx.euromoda_tbnMovimientosNoOK_clicked();
	}
	function compruebaUsuario() {
		return this.ctx.euromoda_compruebaUsuario();
	}
	function liberaUsuario() {
		return this.ctx.euromoda_liberaUsuario();
	}
	function pbnCambioMasivoFecha_clicked() {
		return this.ctx.euromoda_pbnCambioMasivoFecha_clicked();
	}
	function dameOrdenDHFechaEntrega() {
		return this.ctx.euromoda_dameOrdenDHFechaEntrega();
	}
	function cambioMasivoFechaEntrega(oDHFechaEntrega) {
		return this.ctx.euromoda_cambioMasivoFechaEntrega(oDHFechaEntrega);
	}
	function dameInformeMA(codSubfamilia) {
		return this.ctx.euromoda_dameInformeMA(codSubfamilia);
	}
	function dameInformesProd(codSubfamilia) {
		return this.ctx.euromoda_dameInformesProd(codSubfamilia);
	}
	function agruparPorReferencia(codOrden, codCliente) {
		return this.ctx.euromoda_agruparPorReferencia(codOrden, codCliente);
  	}
  	function actualizaObservacionOrden(oDH) {
  		return this.ctx.euromoda_actualizaObservacionOrden(oDH);
  	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_imprimeOrdenProd(oDH) {
		return this.imprimeOrdenProd(oDH);
	}
	function pub_imprimeOrdenMat(oDH) {
		return this.imprimeOrdenMat(oDH);
	}
	function pub_imprimeEtiquetas(w) {
		return this.imprimeEtiquetas(w);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("tbnImprimeAA"), "clicked()", _i, "tbnImprimeAA_clicked");
	connect(this.child("tbnMovimientosNoOK"), "clicked()", _i, "tbnMovimientosNoOK_clicked");
	connect(this.child("chkVerImpresas"), "clicked()", _i, "filtra");
	connect(this.child("pbnCambioMasivoFecha"), "clicked()", _i, "pbnCambioMasivoFecha_clicked");
	_i.columnas();
	_i.filtra();
	
	_i.calculaEtiquetasExtra();
}

function euromoda_tbnMovimientosNoOK_clicked() 
{
	if (!formmt_procesos.iface.ejecutaFuncionDefecto("emCompruebaReservasPedidos")) {
		return;
	}
	sys.infoMsgBox(sys.translate("Correcci�n finalizada"));
}

function euromoda_calculaEtiquetasExtra()
{
	var _i = this.iface;
	_i.etiquetasExtra_ = AQUtil.sqlSelect("prodppal_general", "etiquetasextra", "1 = 1");
}

function euromoda_columnas()
{
	var oCAncho = ["impresoorden", "impresomaterial", "atiempo"];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tableDBRecords").setColumnWidth(oCAncho[c], 40);
	}
}

function euromoda_filtra()
{
	var mF = "NOT impresoorden OR NOT impresomaterial";
	
	if (this.child("chkVerImpresas").checked) {
		mF = "";
	}
	this.child("tableDBRecords").cursor().setMainFilter(mF);
	this.child("tableDBRecords").refresh();
}

/*function euromoda_toolButtomInsert_clicked()
{
	var cursor = this.cursor();
	var _i = this.iface;
	if(!_i.compruebaUsuario()) {  		
		return false;			
  	}
	var f = new FLFormSearchDB("pr_generarordenesprodem");
	var curG = f.cursor();
	curG.setModeAccess(curG.Insert);
	curG.refreshBuffer();

	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	
	f.setMainWidget();
	
	try {
		var id = f.exec("id");
		if (id) {
			curT.commit();
		} else {
			curT.rollback();
		}
	} catch(e) {
		curT.rollback();
		if(!_i.liberaUsuario()) {
			sys.errorMsgBox(sys.translate("Error al liberar usuario de la consola de producci�n"));
		}
		MessageBox.critical(sys.translate("Error al generar las �rdenes de producci�n:\n") + e, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	if (curT.transactionLevel() != 0) {
		if(!_i.liberaUsuario()) {
			sys.errorMsgBox(sys.translate("Error al liberar usuario de la consola de producci�n"));
		}
		sys.errorMsgBox(sys.translate("ERROR GRAVE. NO se han guardado las �rdenes. Cierre AbanQ y vuelva a repetir la generaci�n.\nComunique el error al administrador."));
	}
	_i.tdbRecords.refresh();
	if(!_i.liberaUsuario()) {
		sys.errorMsgBox(sys.translate("Error al liberar usuario de la consola de producci�n"));
}
}*/

function euromoda_toolButtomInsert_clicked(curGAnt)
{
	var cursor = this.cursor();
	var _i = this.iface;
	if(!_i.compruebaUsuario()) { 
		return false;	
	}
	var f = new FLFormSearchDB("pr_generarordenesprodem");
	var curG;
	if (curGAnt) {
		debug("Anterior")
		curG = curGAnt;
		curG.setValueBuffer("nuevo",false);
		f.setCursor(curG);

		// curGAnt.refreshBuffer();
	} else {
		curG = f.cursor();
		curG.setModeAccess(curG.Insert);
		curG.refreshBuffer();
	}
	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);

	f.setMainWidget();

	var ok;
	try {
		var id = f.exec("id");
		if (id) {
			ok = true;
			curT.commit();
		} else {
			//ok = true; Para probar
			curT.rollback();
		}
	} catch(e) {
		curT.rollback();
		if(!_i.liberaUsuario()) {
			sys.errorMsgBox(sys.translate("Error al liberar usuario de la consola de producci�n"));
		}
		MessageBox.critical(sys.translate("Error al generar las �rdenes de producci�n:\n") + e, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	if (curT.transactionLevel() != 0) {
		if(!_i.liberaUsuario()) {
			sys.errorMsgBox(sys.translate("Error al liberar usuario de la consola de producci�n"));
		}
		sys.errorMsgBox(sys.translate("ERROR GRAVE. NO se han guardado las �rdenes. Cierre AbanQ y vuelva a repetir la generaci�n.\nComunique el error al administrador."));
	}
	_i.tdbRecords.refresh();
	if(!_i.liberaUsuario()) {
		sys.errorMsgBox(sys.translate("Error al liberar usuario de la consola de producci�n"));
	}
	if (ok) {
		_i.toolButtomInsert_clicked(curG);
	}
}


function euromoda_borrarOrden(codOrden)
{
  var _i = this.iface;
	AQS.Application_setOverrideCursor(AQS.WaitCursor);
  var idProceso = AQUtil.sqlSelect("pr_procesos", "idproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "'");
  if (!idProceso) {
		AQS.Application_restoreOverrideCursor();
    MessageBox.warning(sys.translate("scripts", "Error al buscar el proceso de producci�n asociado a la orden %1").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  flfactppal.iface.creaDialogoProgreso(sys.translate("Borrando orden"), 3);
	var p = 0;
	AQUtil.setProgress(p++);
	if (!flcolaproc.iface.pub_borrarProceso(idProceso)) {
		AQS.Application_restoreOverrideCursor();
    return false;
  }

  AQUtil.setProgress(p++);
  var curLote = new FLSqlCursor("lotesstock");
  curLote.setForwardOnly(true);
  curLote.select("codordenproduccion = '" + codOrden + "'");
  var idLineaPC, codLote;
  /// Desvincula de la orden los lotes que vienen de pedido de cliente, y borra los otros (creados al crear la orden)
  while (curLote.next()) {
		codLote = curLote.valueBuffer("codlote");
		
		if (!AQSql.update("lineaspedidoscli", ["emcodloteprod"], [false], "emcodloteprod = '" + codLote + "'")) {
			return false;
		}

    if (!AQSql.del("movistock", "codlote = '" + codLote + "' AND idproceso = " + idProceso)) {
			AQS.Application_restoreOverrideCursor();
			AQUtil.destroyProgressDialog();
      return false;
    }
    idLineaPC = curLote.valueBuffer("idlineapc");
	curLote.setModeAccess(curLote.Del);
	curLote.refreshBuffer();
    if (!curLote.commitBuffer()) {
			AQS.Application_restoreOverrideCursor();
			AQUtil.destroyProgressDialog();
      return false;
    }
  }
  AQUtil.setProgress(p++);
    
  if (!AQSql.del("pr_ordenesproduccion", "codorden = '" + codOrden + "'")) {
		AQS.Application_restoreOverrideCursor();
    return false;
  }

  AQS.Application_restoreOverrideCursor();
  AQUtil.destroyProgressDialog();
  return true;
}

function euromoda_imprimir()
{
	var _i = this.iface;
	var oDH = _i.dameOrdenDH("impresoOP");
	if (!oDH) {
		return false;
	}
	if(!_i.actualizaObservacionOrden(oDH)) {
		return false;
	}
	_i.imprimeOrdenProd(oDH)
	this.child("tableDBRecords").refresh();
}

function euromoda_imprimeOrdenProd(oDH)
{
	var _i = this.iface;
	var append = false, display = true, newPage = false;
	_i.rV_ = new FLReportViewer();
	
	var qO = new FLSqlQuery;
	qO.setSelect("codorden, codsubfamilia, codcliente");
	qO.setFrom("pr_ordenesproduccion");
	qO.setWhere("codorden >= '" + oDH.codOrdenDesde + "' AND codorden <= '" + oDH.codOrdenHasta + "' ORDER BY codorden");
	qO.setForwardOnly(true);
debug(qO.sql());
	if (!qO.exec()) {
		return false;
	}
	var numOrdenes = qO.size();
	if(numOrdenes > 0){
		AQUtil.createProgressDialog(sys.translate("Recopilando datos para imprimir..."),numOrdenes);
	}
	var progress = 0;
	var iInfo = 0, iOrden = 1, codOrden;
	_i.numPagInfoOrden_ = 0;
	_i.numPag_ = 0;

	var informeCV = "pr_i_ordenesprod_cv";
	var informeCH = "pr_i_ordenesprod_ch";
	var informeDC = "pr_i_ordenesprod_dc";
	var informeAC = "pr_i_ordenesprod_ac";
	var informeAL = "pr_i_ordenesprod_al";

	var codSubfamilia = "";

	while (qO.next()) {
		AQUtil.setProgress(progress++);
		if (progress == numOrdenes){
			AQUtil.destroyProgressDialog();///No lo hago despu�s del while porque si no hasta que no se cierra el visor de informes no cierra la progressbar
		}
		codOrden = qO.value("codorden");
		codSubfamilia = qO.value("codsubfamilia");
		codCliente = qO.value("codcliente");
		if(_i.agruparPorReferencia(codOrden, codCliente)) {
			informeAL = "pr_i_ordenesprod_alag";
		} else if(codSubfamilia && codSubfamilia != "" && ("impresoMA" in oDH) && oDH["impresoMA"] && oDH["impresoMA"] != "") {
			var tipoImpresoMA = oDH["impresoMA"];			

			if(tipoImpresoMA.left(3) == "001") {
				informeAL = "pr_i_ordenesprod_al";

			} else if (tipoImpresoMA.left(3) == "000") {
				informeAL = _i.dameInformeMA(codSubfamilia);
			}
		} 

		if(codSubfamilia && codSubfamilia != "" && ("impresoOP" in oDH) && oDH["impresoOP"] && oDH["impresoOP"] != "") {
			var tipoImpresoMA = oDH["impresoOP"];			

			if(tipoImpresoMA.left(3) == "001") {
				informeCV = "pr_i_ordenesprod_cv";
				informeCH = "pr_i_ordenesprod_ch";
				informeDC = "pr_i_ordenesprod_dc";
				informeAC = "pr_i_ordenesprod_ac";
			} else if (tipoImpresoMA.left(3) == "000") {
				var oInformesProd = _i.dameInformesProd(codSubfamilia);
				informeCV = oInformesProd["CV"];
				informeCH = oInformesProd["CH"];
				informeDC = oInformesProd["DC"];
				informeAC = oInformesProd["AC"];
			}
		} 


		//Comentado 16-02-2022, ahora antes de imprimir se mira a que �rdenes se les machaca la descripci�n.
		/*if (oDH.cliente && oDH.cliente != "") {
			AQSql.update("pr_ordenesproduccion", ["emobservaciones"], [oDH.cliente], "codorden = '" + codOrden + "'");
		}*/
		
		var idTipoProceso = AQUtil.sqlSelect("pr_procesos", "idtipoproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "'");
		if (!idTipoProceso) {
			MessageBox.warning(sys.translate("Error al obtener el tipo de proceso asociado a la orden"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
			return false;
		}
		var q = new FLSqlQuery;
		q.setSelect("ttp.idtipotarea, tt.descripcion");
		q.setFrom("pr_tipostareapro ttp INNER JOIN pr_tipostarea tt ON ttp.idtipotarea = tt.idtipotarea");
		q.setWhere("idtipoproceso = '" + idTipoProceso + "' ORDER BY ordenlista");
		q.setForwardOnly(true);
		if (!q.exec()) {
			return false;
		}
		var aTipos = [];
		var aCheck = [];
		var i = 0;
		var dialogo = new Dialog;
		while (q.next()) {
			_i.numPagInfoOrden_ = _i.rV_.pageCount();
			aTipos.push(q.value("ttp.idtipotarea"));
			aCheck[i] = new CheckBox;
			aCheck[i].text = q.value("tt.descripcion")
			aCheck[i].checked = true;
			dialogo.add(aCheck[i]);
			i++;
		}
		/** No quieren que pregunte, siempre lo imprime todo
		if (!dialogo.exec()) {
			return false;
		}*/
		var aInfo = [];
		for (var k = 0; k < i; k++) {
			if (aCheck[k].checked) {
				aInfo.push(aTipos[k]);
			}
		}
		var tInfo = aInfo.length;

		for (var f = 0; f < tInfo; f++) {
	debug("aInfo[f] " + aInfo[f]);
			append = (iInfo > 0); /// Siempre si no es el primero
			display = (iOrden == numOrdenes) && (f == (tInfo - 1)); /// Nunca si no es el �ltimp
			newPage = (iInfo > 0 && f == 0); /// Al inicio de cada nueva orden, excepto la primera
			switch (aInfo[f]) {
				case "PT": {
					debug("\n\n1");
					_i.informeProd(informeCV, codOrden, append, false, newPage);									
					break;
				}
				case "CO":
				case "J1":{
					debug("\n\n2");
					_i.informeProd(informeCH, codOrden, append, false, newPage);
					iInfo++;					
					break;
				}
				case "DC": {
					debug("\n\n3");
					_i.informeProd(informeDC, codOrden, append, false, newPage);				
					break;
				}
				case "ACE":
				case "ACO":{
					debug("\n\n4");
					_i.informeProd(informeAC, codOrden, append, false, newPage);				
					break;
				}
			}				
			iInfo++;
		}
		_i.informeProd(informeAL, codOrden, append, false, true);
		iInfo++;
		_i.imprimeEtiquetasMat(codOrden, true, display, false);
		
		//_i.rV_.appendPage();
		iOrden++;
	}	
	AQSql.update("pr_ordenesproduccion", ["impresoorden"], [true], "codorden >= '" + oDH.codOrdenDesde + "' AND codorden <= '" + oDH.codOrdenHasta + "'");
}

function euromoda_dameOrdenDH(tipoImpreso)
{
	var _i = this.iface;
	var d = new Dialog;
	d.caption = sys.translate("�rdenes de producci�n");
	d.okButtonText = sys.translate("Aceptar");
	d.cancelButtonText = sys.translate("Cancelar");

	var desde = new NumberEdit;
	desde.label = sys.translate("Desde orden");
	desde.decimals = 0;
	desde.minimum = 0;
	d.add( desde );
	
	var hasta = new NumberEdit;
	hasta.label = sys.translate("Hasta orden");
	hasta.decimals = 0;
	hasta.minimum = 0;
	d.add( hasta );
	                              	
	var cliente = new LineEdit;
	cliente.label = sys.translate("Cliente");
	d.add( cliente );

	var cbImpresosOP = new ComboBox;
	if(tipoImpreso == "impresoOP") {
		var aListaOP = ["000 - Informe subfamilia","001 - Orden de producci�n cl�sica"];
		
		cbImpresosOP.label = sys.translate("Impreso de Orden de Producci�n    ");
		cbImpresosOP.editable = false;
		cbImpresosOP.itemList = aListaOP;
		d.add(cbImpresosOP);
	}
	var cbImpresosMA = new ComboBox;	                             	
	if(tipoImpreso == "impresoOP" || tipoImpreso == "impresoMA") {
		var aListaMA = ["000 - Informe subfamilia","001 - Orden de materiales cl�sica"];
		
		cbImpresosMA.label = sys.translate("Impreso de Orden de M at. Auxiliares    ");
		cbImpresosMA.editable = false;
		cbImpresosMA.itemList = aListaMA;
		d.add(cbImpresosMA);
	}
	
	if (!d.exec()) {
		return false;
	}
	if (desde.value > hasta.value) {
		return false;
	}
	var oDatos = new Object;
	oDatos.codOrdenDesde = "OP" + flfactppal.iface.pub_cerosIzquierda(desde.value, 8);
	oDatos.codOrdenHasta = "OP" + flfactppal.iface.pub_cerosIzquierda(hasta.value, 8);
	oDatos.cliente = cliente.text;

	if(tipoImpreso == "impresoOP") {
		oDatos.impresoOP = cbImpresosOP.currentItem;
	}
	if(tipoImpreso == "impresoMA") {
		oDatos.impresoMA = cbImpresosMA.currentItem;
	}
	
	return oDatos;
}

function euromoda_imprimir()
{
	var _i = this.iface;
	var oDH = _i.dameOrdenDH("impresoOP");
	if (!oDH) {
		return false;
	}
	if(!_i.actualizaObservacionOrden(oDH)) {
		return false;
	}
	_i.imprimeOrdenProd(oDH)
}

function euromoda_tbnImprimeAA_clicked()
{
	var _i = this.iface;
	var oDH = _i.dameOrdenDH("impresoMA");
	if (!oDH) {
		return false;
	}
	if(!_i.actualizaObservacionOrden(oDH)) {
		return false;
	}
	_i.imprimeOrdenMat(oDH)
	this.child("tableDBRecords").refresh();
}

function euromoda_imprimeOrdenMat(oDH)
{
	var _i = this.iface;
	
	var wO;
	var qO = new FLSqlQuery;
	qO.setSelect("codorden, codsubfamilia,codcliente");
	qO.setFrom("pr_ordenesproduccion");
	if ("codpreparamat" in oDH) {
		wO = "codpreparamat = '" + oDH.codpreparamat + "'";
	} else {
		wO = "codorden >= '" + oDH.codOrdenDesde + "' AND codorden <= '" + oDH.codOrdenHasta + "'";		
	}

	if("masWhere" in oDH) {
		wO += oDH.masWhere;
	}

	wO += "  ORDER BY codorden";
	qO.setWhere(wO);
	qO.setForwardOnly(true);
debug(qO.sql());
	if (!qO.exec()) {
		return false;
	}
	_i.rV_ = new FLReportViewer();
	var numOrdenes = qO.size();
	if(numOrdenes > 0){
		AQUtil.createProgressDialog(sys.translate("Recopilando datos para imprimir..."),numOrdenes);
	}
debug("numOrdenes " + numOrdenes);
	var progress = 0;
	var iInfo = 0, iOrden = 1, codOrden;
	var display, append, pageBreak;

	var informe = "pr_i_ordenesprod_al";
	var codSubfamilia = "";
	var codCliente = "";

	while (qO.next()) {
		codOrden = qO.value("codorden");
		codSubfamilia = qO.value("codsubfamilia");
		codCliente = qO.value("codcliente");
		if(_i.agruparPorReferencia(codOrden, codCliente)) {
			informe = "pr_i_ordenesprod_alag";
		} else {
			if(codSubfamilia && codSubfamilia != "" && ("impresoMA" in oDH) && oDH["impresoMA"] && oDH["impresoMA"] != "") {
				var tipoImpresoMA = oDH["impresoMA"];		

				if(tipoImpresoMA.left(3) == "001") {
					informe = "pr_i_ordenesprod_al";
				} else if (tipoImpresoMA.left(3) == "000") {
					informe = _i.dameInformeMA(codSubfamilia);
				}
			} 
		}
		
		/*if ("cliente" in oDH && oDH.cliente && oDH.cliente != "") {
			AQSql.update("pr_ordenesproduccion", ["nombrecliente"], [oDH.cliente], "codorden = '" + codOrden + "'");
		}*/
		_i.numPagInfoOrden_ = _i.rV_.pageCount();
		AQUtil.setProgress(progress++);
		if (progress == numOrdenes){
			AQUtil.destroyProgressDialog();///No lo hago despu�s del while porque si no hasta que no se cierra el visor de informes no cierra la progressbar
		}
debug("iOrden == numOrdenes " + iOrden + " num " + numOrdenes);
		display = iOrden == numOrdenes;
		append = iOrden > 1;
		pageBreak = iOrden > 1;
		codOrden = qO.value("codorden");
		_i.informeProd(informe, codOrden, append, false, pageBreak);
		_i.imprimeEtiquetasMat(codOrden, true, display, false)
		iOrden++;
	}
	var idUsuarioMod = sys.nameUser();
	var fechaMod = flfactppal.iface.dameFechaActual();
	var horaMod = flfactppal.iface.dameHoraActual();

	AQSql.update("pr_ordenesproduccion", ["impresomaterial","idusuariomodimat","fechamodimat","horamodimat"], [true,idUsuarioMod,fechaMod,horaMod], wO);
}

function euromoda_informeProd(tipoInforme, codOrden, append, display, newPage)
{
debug("imprimiendo " + tipoInforme);
	var _i = this.iface;
	var cursor = this.cursor();
// 	var codOrden = cursor.valueBuffer("codorden");
// 	if (!codOrden || codOrden == "") {
// 		return;
// 	}
	var oParam = _i.dameParamInforme(tipoInforme, append, display, newPage);
	if (!oParam) {
		return;
	}
debug("append = " + append + " display = " + display + " pageBreak = " + newPage + " rpt viewer " + oParam.rptViewer);
	var curImprimir:FLSqlCursor = new FLSqlCursor("pr_i_ordenesproduccion");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	if(tipoInforme == "pr_i_ordenesprod_alag") {
		oParam.whereFijo = oParam.whereFijo + " AND v_ordenesprod_alag.codorden = '" + codOrden + "'";
	} else {
	curImprimir.setValueBuffer("d_pr__ordenesproduccion_codorden", codOrden);
	curImprimir.setValueBuffer("h_pr__ordenesproduccion_codorden", codOrden);
	}
	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
}

function euromoda_dameParamInforme(nombre, append, display, newPage)
{
	var _i = this.iface;
  var util = new FLUtil;
  var oParam = flfactinfo.iface.pub_dameParamInforme();
  oParam.nombreInforme = nombre;
	oParam.nombreReport = nombre;
	oParam.append = append;
	oParam.display = display;
	oParam.pageBreak = newPage;
	
	switch (nombre) {
		case "pr_i_ordenesprod_cv": {
			oParam.rptViewer = _i.rV_;
// 			oParam.whereFijo = "pr_tareas.idtarea = 'PT'";
			oParam.groupBy = "pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.codcliente, pr_ordenesproduccion.codpedidocli, pr_ordenesproduccion.emobservaciones, pr_tareas.idtarea, articulos.referencia, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, em_colores.codigogit, articuloscomp.refcomponente, articuloscomp.ancho, articuloscomp.idseccion, articuloscomp.piezasancho, articuloscomp.anchopiezatej,em_disenos.codseriediseno";
			break;
		}
		case "pr_i_ordenesprod_ch": {
			oParam.rptViewer = _i.rV_;
// 			oParam.whereFijo = "pr_tareas.idtarea IN ('CO', 'J1')";
			oParam.groupBy = "articuloscomp.orden,pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, pr_tareas.idtarea, lotesstock.referencia, prod.referencia, prod.descripcion, tamprod.descripcion, colprod.descripcion, colprod.codigogit, articulos.referencia, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, em_colores.codigogit, articuloscomp.largo, articuloscomp.ancho, articuloscomp.componente,em_disenos.codseriediseno,disprod.codseriediseno";
			break;
		}
		case "pr_i_ordenesprod_ac": {
			oParam.rptViewer = _i.rV_;
// 			oParam.whereFijo = "pr_tareas.idtarea IN ('ACO', 'ACE')";
			oParam.groupBy = "articuloscomp.orden,pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, pr_tareas.idtarea, lotesstock.referencia, prod.referencia, prod.descripcion, tamprod.descripcion, colprod.descripcion, colprod.codigogit, articulos.referencia, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, em_colores.codigogit, articuloscomp.largo, articuloscomp.ancho, em_componentes.descripcion,em_disenos.codseriediseno,disprod.codseriediseno";
			break;
		}
		case "pr_i_ordenesprod_dc": {
			oParam.rptViewer = _i.rV_;
			oParam.groupBy = "pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega,pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente,pr_ordenesproduccion.codcliente, pr_tareas.idtarea,articuloscomp.orden,articulos.codbarras, articulos.referencia, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, em_colores.codigogit, em_componentes.descripcion,em_disenos.codseriediseno";
			break;
		}
		case "pr_i_ordenesprod_al": {
			oParam.rptViewer = _i.rV_;
			oParam.whereFijo = "(articuloscomp.idseccion = '9' OR articuloscomp.id IS NULL OR articuloscomp.componormal = 'BIES')";
			//oParam.groupBy = "pr_ordenesproduccion.codorden, articuloscomp.orden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, articulos.referencia, articulos.codbarras, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, em_colores.codigogit, articuloscomp.refcomponente, articuloscomp.ancho,articuloscomp.idseccion, articuloscomp.observaciones";
			oParam.groupBy = "pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, articulos.referencia, articulos.codbarras, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, em_colores.codigogit, articuloscomp.refcomponente, articuloscomp.ancho,articuloscomp.idseccion,articuloscomp.componente,articuloscomp.componormal,em_disenos.codseriediseno, pr_ordenesproduccion.codpedidocli";
			break;
		}
		case "pr_i_ordenesprod_alag": {
			oParam.rptViewer = _i.rV_;
			oParam.whereFijo = "1=1";
			//oParam.groupBy = "pr_ordenesproduccion.codorden, articuloscomp.orden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, articulos.referencia, articulos.codbarras, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, em_colores.codigogit, articuloscomp.refcomponente, articuloscomp.ancho,articuloscomp.idseccion, articuloscomp.observaciones";
			//oParam.groupBy = "subfamilias.descripcion,pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia,pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, articulos.referencia, articulos.codbarras, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion,em_colores.codigogit, articulos.referencia";
			break;
		}
	}
  return oParam;
}

function euromoda_numPagina()
{
	var _i = this.iface;

 	//return _i.numPag_;
	
	
	if (!_i.rV_) {
		return 1;
	}
	return _i.rV_.pageCount() - _i.numPagInfoOrden_ + 1;
	
}

function euromoda_imprimirEtiquetas()
{
	var _i = this.iface;
	var oDH = _i.dameOrdenDH("impresoETI");
	if (!oDH) {
		return false;
	}
	var w = "op.codorden BETWEEN '" + oDH.codOrdenDesde + "' AND '" + oDH.codOrdenHasta + "' ORDER BY op.codorden, a.referencia";
	_i.imprimeEtiquetas(w);
}

function euromoda_imprimeEtiquetas(w)
{
	//debug("euromoda_imprimeEtiquetas " + w);
	var _i = this.iface;
	var aEtiquetas = _i.dameArrayEtiquetas(w);
	if (!aEtiquetas) {
		return false;
	}
  formem_etiquetasart.iface.pub_imprimeEtiquetas(aEtiquetas);

  	var idUsuarioMod = sys.nameUser();
	var fechaMod = flfactppal.iface.dameFechaActual();
	var horaMod = flfactppal.iface.dameHoraActual();

	var aWhere = w.split("ORDER");
	var sWhere = aWhere[0];
	sWhere = flfactppal.iface.replace(sWhere, "op.", "");
	debug("sWhere: "+sWhere);	

	AQUtil.execSql("UPDATE pr_ordenesproduccion SET idusuariomodiet = '" + idUsuarioMod + "', fechamodiet = '" + fechaMod + "', horamodiet = '" + horaMod + "'   WHERE " + sWhere);


}

function euromoda_arrayEtiquetas(oDH)
{
	var _i = this.iface;
	return _i.dameArrayEtiquetas("op.codorden BETWEEN '" + oDH.codOrdenDesde + "' AND '" + oDH.codOrdenHasta + "' ORDER BY op.codorden, a.referencia");
}

function euromoda_dameArrayEtiquetas(w)
{
	var _i = this.iface;
	
	if (_i.etiquetasExtra_ == undefined) {
		_i.calculaEtiquetasExtra();
	}
	
	var qE = new AQSqlQuery;
	qE.setSelect("op.codorden, a.referencia, a.codbarras, a.descripcion, a.codtamanoem, a.codcolorem, ls.canlote, ls.codlote, em_disenos.codseriediseno, ls.canprogramada, op.fechaentrega, op.subfamilia, op.dibujo, op.codpedidocli, op.emobservaciones, op.codcliente");
	qE.setFrom("pr_ordenesproduccion op INNER JOIN lotesstock ls ON op.codorden = ls.codordenproduccion INNER JOIN articulos a ON ls.referencia = a.referencia LEFT OUTER JOIN em_dibujos ON a.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno");
	qE.setWhere(w);
	if (!qE.exec()) {
		return false;
	}
//debug(qE.sql());
	var aEtiquetas = [];
	var referencia, cantidad, datosEmb, canEmb, observaciones;
	while (qE.next()) {
		referencia = qE.value("a.referencia");
		cantidad = qE.value("ls.canlote");
		datosEmb = flfactalma.iface.pub_dameEmbalajeArticulo(referencia, qE.value("ls.codlote"), true);
		canEmb = datosEmb ? (Math.ceil(cantidad / datosEmb.capacidad)) : 0;
		cantidad += parseFloat(canEmb);
		cantidad += parseFloat(_i.etiquetasExtra_);
		var descripcion = qE.value("a.descripcion");
		var codseriediseno = qE.value("em_disenos.codseriediseno");
		if (codseriediseno && codseriediseno != ""){
			descripcion += " - [" + codseriediseno + "]"
		}
	
	  var aE = new Object;
    aE["referencia"] = qE.value("a.referencia");
	    aE["descripcion"] = descripcion;
    aE["tamano"] = qE.value("a.codtamanoem");
    aE["color"] = qE.value("a.codcolorem");
    aE["cantidad"] = cantidad;
    aE["barcode"] = qE.value("a.codbarras");
	    //debug("cantidad progamada: "+ qE.value("ls.canprogramada"));
	   	aE["canprogramada"] = qE.value("ls.canprogramada");
	   	aE["canfinal"] = qE.value("ls.canlote");

	   	//nuevo para cabecera en addonheader
	   	aE["codorden"] = qE.value("op.codorden");	  
	   	aE["fechaentrega"] = AQUtil.dateAMDtoDMA(qE.value("op.fechaentrega").toString().left(10));	   
	   	aE["subfamilia"] = qE.value("op.subfamilia");
	   	aE["dibujo"] = qE.value("op.dibujo");
	   	aE["codpedidocli"] = qE.value("op.codpedidocli");

	   	observaciones = qE.value("op.emobservaciones");
		aE["codcliente"] = observaciones;
		if (!observaciones || observaciones == "") {
			aE["codcliente"] = qE.value("op.codcliente");
		}

	   	
    aEtiquetas.push(aE);
  }
  return aEtiquetas;
}

function euromoda_imprimeEtiquetasMat(codOrden, append, display, pageBreak)
{
	//debug("euromoda_imprimeEtiquetasMat " + codOrden + " display " + display + "append" + append + "pageBreak" + pageBreak);
	var _i = this.iface;
	
	var oDH = new Object;
	oDH.codOrdenDesde = codOrden;
	oDH.codOrdenHasta = codOrden;
  
	aEtiquetas = _i.arrayEtiquetas(oDH)
	if (!aEtiquetas) {
		return false;
	}
  var aE;
	var xmlKD = new FLDomDocument;
	xmlKD.setContent("<!DOCTYPE KUGAR_DATA><KugarData/>");
	var eRow:FLDomElement;
	
	for (var a = 0; a < aEtiquetas.length; a++) {
		aE = aEtiquetas[a];
		eRow = xmlKD.createElement("Row");
		for (var c in aE) {
			eRow.setAttribute(c, aE[c]);
		}
		eRow.setAttribute("level", 0);
		xmlKD.firstChild().appendChild(eRow);
	}
// debug(xmlKD.toString(4));

	var rptViewer = _i.rV_;
	var flags = (display ? rptViewer.Display : 0) | (append ? rptViewer.Append : 0) | (pageBreak ? rptViewer.PageBreak : 0);
	rptViewer.setReportData(xmlKD);
	rptViewer.setReportTemplate("pr_i_ordenesprod_et");
	rptViewer.renderReport(0, 0, flags);
	if (!display) {
		debug("display false");
		return true;
	}
	rptViewer.exec();
}

function euromoda_compruebaUsuario()
{
	var usuario = sys.nameUser();
	var usuarioCon = AQUtil.sqlSelect("prodppal_general","em_usuconsolaop","1=1");
	if(usuarioCon && usuarioCon != usuario) {
		var res = MessageBox.information(sys.translate("El usuario %1 est� utilizando la consola �Desea continuar?").arg(usuarioCon), MessageBox.Yes, MessageBox.No)
		if (res != MessageBox.Yes) {
			return false;
		}		
	}
	if (!AQUtil.execSql("UPDATE prodppal_general SET em_usuconsolaop = '" + usuario + "' WHERE 1 = 1")) {
		return false;
	}
	return true;
 
}

function euromoda_liberaUsuario()
{
	var usuario = sys.nameUser();
	var usuarioCon = AQUtil.sqlSelect("prodppal_general","em_usuconsolaop","1=1");
	if (usuarioCon && usuarioCon == usuario) { 
		if (!AQUtil.execSql("UPDATE prodppal_general SET em_usuconsolaop = NULL WHERE 1 = 1")) {
			return false;
		}
	}
	return true;
}

function euromoda_pbnCambioMasivoFecha_clicked()
{
	var _i = this.iface;
	var oDHFechaEntrega = _i.dameOrdenDHFechaEntrega();
	if (!oDHFechaEntrega) {
		return false;
	}
	if (!_i.cambioMasivoFechaEntrega(oDHFechaEntrega)) {
		return false;
	} 

	this.child("tableDBRecords").refresh();
}

function euromoda_dameOrdenDHFechaEntrega()
{
	var _i = this.iface;
	var d = new Dialog;
	d["caption"] = sys.translate("Cambio masivo de fecha de entrega de �rdenes de producci�n");
	d["okButtonText"] = sys.translate("Aceptar");
	d["cancelButtonText"] = sys.translate("Cancelar");

	var desde = new NumberEdit;
	desde["label"] = sys.translate("Desde orden");
	desde["decimals"] = 0;
	desde["minimum"] = 0;
	d.add(desde);
	
	var hasta = new NumberEdit;
	hasta["label"] = sys.translate("Hasta orden");
	hasta["decimals"] = 0;
	hasta["minimum"] = 0;
	d.add(hasta);
	                              	
	var hoy;
	hoy = new Date()
	var dedFecha = new DateEdit;
	dedFecha["label"] = "Nueva Fecha Entrega: ";
	// dedFecha["date"] = hoy;
	d.add(dedFecha);
	
	if (!d.exec()) {
		return false;
	}
	else {
		var fechaEntrega = dedFecha["date"];

		if(!fechaEntrega || fechaEntrega == "" || fechaEntrega == undefined || desde.value > hasta.value || desde.value == "" || hasta.value == "")   {
			formUI.ponMsgWarn(sys.translate("Los campos Fecha y Desde/Hasta orden son datos obligatorios. Se cancela el proceso."));
			return false;
		}/*
		if (desde.value > hasta.value || desde.value == "" || hasta.value == "") {
			return false;
		}*/
		var desdeOP = "OP" + flfactppal.iface.pub_cerosIzquierda(desde.value, 8);
		var hastaOP = "OP" + flfactppal.iface.pub_cerosIzquierda(hasta.value, 8);
		var res = formUI.preguntaMsg(sys.translate("IMPORTANTE:  Va a modificar la fecha de entrega  a %1  desde la orden %2  a %3.\nSi Acepta, el cambio no se podr� deshacer.").arg(AQUtil.dateAMDtoDMA(fechaEntrega.toString().left(10))).arg(desdeOP).arg(hastaOP), "info", this, MessageBox.Ok, MessageBox.Cancel);
		if(res != MessageBox.Ok) {
			return false;
		}
		var oDatos = new Object;
		oDatos["codOrdenDesde"] = desdeOP;
		oDatos["codOrdenHasta"] = hastaOP;
		oDatos["nuevaFechaEntrega"] = fechaEntrega;
		return oDatos;
	}
}

function euromoda_cambioMasivoFechaEntrega(oDHFechaEntrega)
{
	var _i = this.iface;
	var codOrden = "";
	var curOP = new FLSqlCursor("pr_ordenesproduccion");
	curOP.select("codorden >= '" + oDHFechaEntrega["codOrdenDesde"] + "' AND codorden <= '" + oDHFechaEntrega["codOrdenHasta"] + "' ORDER BY codorden");
	while (curOP.next()) {
		curOP.setModeAccess(curOP.Edit);
		curOP.refreshBuffer();	
		curOP.setValueBuffer("fechaentrega", oDHFechaEntrega["nuevaFechaEntrega"]);
		codOrden = curOP.valueBuffer("codorden");
		if (!curOP.commitBuffer()) {
			return false;
		}		
		if (!AQUtil.execSql("UPDATE movistock SET fechaprev = '" + oDHFechaEntrega["nuevaFechaEntrega"] + "' FROM  lotesstock WHERE lotesstock.codlote = movistock.codlote AND lotesstock.codordenproduccion = '" + codOrden + "'")) {
			return false;
		}
	}
	return true;
}

function euromoda_dameInformeMA(codSubfamilia)
{
	var informe = "pr_i_ordenesprod_al";

	var tipoInforme = AQUtil.sqlSelect("subfamilias","em_informemat","codsubfamilia = '" + codSubfamilia + "'");
	if(!tipoInforme || tipoInforme == "") {
		informe = "pr_i_ordenesprod_al";	

	} else if(tipoInforme.left(3) == "001") {
		informe = "pr_i_ordenesprod_al";

	} else  {
		informe = "pr_i_ordenesprod_al";
	}

	return informe;
}

function euromoda_dameInformesProd(codSubfamilia)
{
	var informeCV = "pr_i_ordenesprod_cv";
	var informeCH = "pr_i_ordenesprod_ch";
	var informeDC = "pr_i_ordenesprod_dc";
	var informeAC = "pr_i_ordenesprod_ac";

	var tipoInforme = AQUtil.sqlSelect("subfamilias","em_informemat","codsubfamilia = '" + codSubfamilia + "'");
	if(!tipoInforme || tipoInforme == "") {
		informeCV = "pr_i_ordenesprod_cv";
		informeCH = "pr_i_ordenesprod_ch";
		informeDC = "pr_i_ordenesprod_dc";
		informeAC = "pr_i_ordenesprod_ac";

	} else if(tipoInforme.left(3) == "001") {
		informeCV = "pr_i_ordenesprod_cv";
		informeCH = "pr_i_ordenesprod_ch";
		informeDC = "pr_i_ordenesprod_dc";
		informeAC = "pr_i_ordenesprod_ac";

	} else  {
		informeCV = "pr_i_ordenesprod_cv";
		informeCH = "pr_i_ordenesprod_ch";
		informeDC = "pr_i_ordenesprod_dc";
		informeAC = "pr_i_ordenesprod_ac";
	}



	var oInformesProd = new Object;
	oInformesProd["CV"] = informeCV;
	oInformesProd["CH"] = informeCH;
	oInformesProd["DC"] = informeDC;
	oInformesProd["AC"] = informeAC;

	return oInformesProd;
}

function euromoda_agruparPorReferencia(codOrden, codCliente)
{
	//tenemos que ver que si hay alguna referencia que no est� en la ficha t�cnica devolver true y si no devolvemos false
	//Hay que tener en cuenta que los embalajes no entran en la ficha t�cnica
	if(!codCliente || codCliente == "") {
		codCliente = false;
	}

	var aEmbalajes = [];
	var q = new AQSqlQuery;	
	q.setSelect("lotesstock.referencia");
	q.setFrom("lotesstock");
	q.setWhere("lotesstock.codordenproduccion = '" + codOrden + "'"); 				
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var referencia = q.value("lotesstock.referencia");
		var aDatosEmb = flfactalma.iface.pub_dameEmbalajeArticulo(referencia, codCliente, false);
		var refEmbalaje = aDatosEmb.referencia;
		aEmbalajes.push(refEmbalaje);
	}	

	var where = "articuloscomp.id is null and pr_ordenesproduccion.codorden = '" + codOrden + "'";


	if(aEmbalajes.length>0) {
		where += " AND movistock.referencia NOT IN ('" + aEmbalajes.join("','") + "')";
	}

	if(AQUtil.sqlSelect("pr_ordenesproduccion INNER JOIN pr_procesos ON (pr_procesos.tipoobjeto='pr_ordenesproduccion' AND pr_ordenesproduccion.codorden = pr_procesos.idobjeto) INNER JOIN lotesstock ON pr_ordenesproduccion.codorden = lotesstock.codordenproduccion LEFT OUTER JOIN movistock ON lotesstock.codlote = movistock.codloteprod LEFT OUTER JOIN articuloscomp ON (movistock.idarticulocomp = articuloscomp.id)","movistock.referencia",where,"pr_ordenesproduccion")) {
		return true;
	}
	return false;
}

function euromoda_actualizaObservacionOrden(oDH)
{
	var _i = this.iface;
		
	if (!oDH.cliente || oDH.cliente == "") {
		return true;
	}

	var distintas = AQUtil.sqlSelect("pr_ordenesproduccion","count(distinct emobservaciones)","codorden >= '" + oDH.codOrdenDesde + "' AND codorden <= '" + oDH.codOrdenHasta + "' and emobservaciones <> '" + oDH.cliente + "' and emobservaciones IS NOT NULL and emobservaciones != ''");

	debug("distintas: "+distintas);

	//actualizo siempre las que las observaciones est�n vacias o a null
	AQSql.update("pr_ordenesproduccion", ["emobservaciones"], [oDH.cliente], "codorden >= '" + oDH.codOrdenDesde + "' AND codorden <= '" + oDH.codOrdenHasta + "' and ( emobservaciones IS NULL OR emobservaciones = '')");


	if(!distintas || distintas == 0) {
		return true;
	}
	var codOrden;
	var observaciones;
	var totalUds;
	var subfamilia;
	var dibujo;
	var fechaEntrega;
	var noPreguntar = false;
	var observacionesAnt = "";
	var q = new AQSqlQuery;
	q.setSelect("emobservaciones,codorden,totaluds,subfamilia,dibujo,fechaentrega");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("codorden >= '" + oDH.codOrdenDesde + "' AND codorden <= '" + oDH.codOrdenHasta + "' and emobservaciones <> '" + oDH.cliente + "' and emobservaciones IS NOT NULL and emobservaciones != '' ORDER BY emobservaciones, codorden");
	debug("q.sql(): "+q.sql());
	if (!q.exec()){
		return;
	}
	while(q.next())
	{
		var dialog = new Dialog;
		dialog.caption = "ATENCI�N";
		dialog.okButtonText = "Aceptar";
		dialog.cancelButtonText = "Cancelar"; 

		codOrden = q.value("codorden");
		observaciones = q.value("emobservaciones");
		totalUds = q.value("totaluds");
		subfamilia = q.value("subfamilia");
		dibujo = q.value("dibujo");
		fechaEntrega = AQUtil.dateAMDtoDMA(q.value("fechaentrega").toString().left(10));

		if(observacionesAnt == "") {
			observacionesAnt = observaciones;
		}

		if(observacionesAnt != observaciones) {
			noPreguntar = false;
		}
		observacionesAnt = observaciones;
		if(noPreguntar) {			
			continue;
		}

		var texto = new Label;
		texto.text = sys.translate("ATENCI�N: Se han detectado %1 observaciones diferentes en el rango indicado, confirme los cambios:\n�Desea cambiar la observaci�n actual '%2' a '%3'\na la %4 - %5 uds - %6 - %7, F.Entrega %8?").arg(distintas).arg(observaciones).arg(oDH.cliente).arg(codOrden).arg(totalUds).arg(subfamilia).arg(dibujo).arg(fechaEntrega);
		dialog.add( texto );
		    
		var grupo = new GroupBox;
		dialog.add( grupo );   
		
		var botonS = new RadioButton;
		botonS.text = "S�";
		botonS.checked = false;
		grupo.add( botonS );

		var botonST = new RadioButton;
		botonST.text = "S� a todas las coincidentes";
		botonST.checked = false;
		grupo.add( botonST );

		var botonN = new RadioButton;
		botonN.text = "No";
		botonN.checked = true;
		grupo.add( botonN );

		var botonNT = new RadioButton;
		botonNT.text = "No a todas las coincidentes";
		botonNT.checked = false;
		grupo.add( botonNT );

		var botonE = new RadioButton;
		botonE.text = "Salir";
		botonE.checked = false;
		grupo.add( botonE );		

		if(!dialog.exec() ) {
			return;
		}
		if (botonS.checked) {		
			AQSql.update("pr_ordenesproduccion", ["emobservaciones"], [oDH.cliente], "codorden = '" + codOrden + "'");
		} else if (botonST.checked) {
			AQSql.update("pr_ordenesproduccion", ["emobservaciones"], [oDH.cliente], "codorden >= '" + oDH.codOrdenDesde + "' AND codorden <= '" + oDH.codOrdenHasta + "' and emobservaciones = '" + observaciones + "'");
			noPreguntar = true;			
		} else if (botonN.checked) {
			continue;
		} else if (botonNT.checked) {
			noPreguntar = true;
			continue;
		} else if (botonE.checked) {
			return false;
		}

	}	
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
