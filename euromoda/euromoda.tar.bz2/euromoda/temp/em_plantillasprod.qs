/***************************************************************************
                 em_plantillasprod.qs  -  description
                             -------------------
    begin                : mar ago XX 20XX
    copyright            : (C) 20XX by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN:String) { return this.ctx.interna_calculateField(fN); }
	function validateForm() {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblSust_;
	var tblLogCostes_;
	var actualizaHerencia_;
	function oficial( context ) { interna( context ); } 
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function cargaSustituciones() {
		return this.ctx.oficial_cargaSustituciones();
	}
	function dameTablaSustituciones() {
		return this.ctx.oficial_dameTablaSustituciones();
	}
	function dameTamaniosSust() {
		return this.ctx.oficial_dameTamaniosSust();
	}
	function cargaDatosLogCostes() {
		return this.ctx.oficial_cargaDatosLogCostes();
	}
	function dameTablaLogCostes() {
		return this.ctx.oficial_dameTablaLogCostes();
	}
	function pbnActualizarMargenes_clicked() {
		return this.ctx.oficial_pbnActualizarMargenes_clicked();
	}
	function pbnActualizarCostes_clicked() {
		return this.ctx.oficial_pbnActualizarCostes_clicked();
	}	
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	_i.cargaSustituciones();

	connect(this.child("pbnActualizarMargenes"), "clicked()", _i, "pbnActualizarMargenes_clicked");
	connect(this.child("pbnActualizarCostes"), "clicked()", _i, "pbnActualizarCostes_clicked");
	_i.tblLogCostes_ = undefined;	
	formRecordarticulos.iface.habilitaCamposCostesProd(this, cursor);
	_i.cargaDatosLogCostes();
	_i.actualizaHerencia_ = false;

}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
	/*if(!_i.actualizaHerencia_) {		
		if(!flfactalma.iface.controlDatosModCosteProd(cursor)) {
			return false;
		} 
		if(!formRecordarticulos.iface.ponDatosLogCostes("plantillas",cursor)) {
			return false;
		}
	}*/
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "nombre": {
			valor = "";
			var subfamilia = AQUtil.sqlSelect("subfamilias", "descripcion", "codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
			valor += (subfamilia) ? subfamilia : "";
			var codTamanoEm = cursor.valueBuffer("codtamanoem");
      		valor += " - ";
			valor += (codTamanoEm) ? codTamanoEm : "";
			/*var variante = cursor.valueBuffer("variante");
			valor += (variante && variante != "DEFAULT") ? (" - " + variante) : "";*/
			var color = cursor.valueBuffer("codcolorem");
			valor += (color) ? " "+color : "";
			valor += " - ";
			var codColeccion =  cursor.valueBuffer("codcoleccionem");
			valor += (codColeccion) ? " COLEC: "+codColeccion : "";
			var desCcoleccion =  cursor.valueBuffer("desccoleccion");
			valor += (desCcoleccion) ? "-"+desCcoleccion : "";
			valor = valor.left(100);
			break;
		}
		default: {
		}
	}
			
	return valor;
}



function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(fN == "codsubfamilia" || fN == "codsubfamilia" || fN == "codtamanoem" || fN == "codcoleccionem" || fN == "codcolorem") {
		sys.setObjText(this, "fdbNombre", _i.calculateField("nombre"));			
	} else if(fN =="em_margenprod" || fN == "em_observmargenprod") {
		var d = new Date;
		this.child("fdbEmFechaMargenProd").setValue(d.toString());
		this.child("fdbHoraMargenProd").setValue(d.toString().right(8));
		this.child("fdbEmIdUsuarioMargenProd").setValue(sys.nameUser());					
	} else if(fN =="em_costeprod" || fN == "em_observcosteprod") {
		var d = new Date;
		this.child("fdbEmFechaCosteProd").setValue(d.toString());
		this.child("fdbHoraCosteProd").setValue(d.toString().right(8));
		this.child("fdbEmIdUsuarioCosteProd").setValue(sys.nameUser());
	}	
}

function oficial_cargaSustituciones()
{
	var _i = this.iface;

	var obj = _i.dameTablaSustituciones();

	var cursor = this.cursor();
	var codColeccion = cursor.valueBuffer("codcoleccionem");
	if(!codColeccion) {
		return obj;
	}

	var miTabla = obj.miTabla;

	var q = new FLSqlQuery;

	q.setTablesList("em_colecciones,em_sustcompocol");
	q.setSelect("em_colecciones.codcoleccionem,em_colecciones.descripcion,em_sustcompocol.referenciasust,em_sustcompocol.descripcionsust,em_sustcompocol.referencianueva,em_sustcompocol.descripcionnueva,em_sustcompocol.cantsust,em_sustcompocol.cantnueva,em_sustcompocol.aplicado,em_sustcompocol.idusuarioalta,em_sustcompocol.fechaalta,em_sustcompocol.horaalta,em_sustcompocol.idusuariomod,em_sustcompocol.fechamod,em_sustcompocol.horamod,em_sustcompocol.idsustcompocol");
	q.setFrom("em_colecciones left outer join em_sustcompocol on em_colecciones.codcoleccionem = em_sustcompocol.codcoleccionem");
	q.setWhere("em_colecciones.codcoleccionplan = '" + codColeccion + "'");
	q.setOrderBy("em_colecciones.codcoleccionem,em_sustcompocol.referenciasust")

	//debug("q: "+q.sql());
	miTabla.setQuery(q);

	
	var tamanios = _i.dameTamaniosSust();
	for(var i = 0; i < tamanios.length; i++) {
		miTabla.setColumnWidth(tamanios[i][0], tamanios[i][1]);
	}	

	miTabla.setReadOnly(true);
	miTabla.refresh();

	return true;	
}

function oficial_dameTablaSustituciones()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblSust_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Sust");
	obj.gb = this.child("mte_gbExt_Sust");

	//if (!obj.creado) {
		_i.tblSust_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		//_i.tblSust_.checkColumnEnabled(true);
		//_i.tblSust_.setAliasCheckColumn("Sel.");
		_i.tblSust_.setSearchEnabled(true);

		//_i.tblSust_.setDoubleClickedFunction("formRecordem_colecciones.iface.editaDibujo");
		//_i.tblSust_.setSelectedFunction("formRecordem_colecciones.iface.selectedFunction");
		//_i.tblSust_.setCurrentChangedFunction("formRecordem_colecciones.iface.currentChangedFunction");
	//}
	
	obj.miTabla = _i.tblSust_;

	return obj;
}

function oficial_dameTamaniosSust()
{

	var aTam = [["em_colecciones.codcoleccionem", 80], ["em_sustcompocol.referenciasust",80],["em_sustcompocol.descripcionsust",350],["em_sustcompocol.referencianueva",80],["em_sustcompocol.descripcionnueva",350],["em_sustcompocol.cantsust",100],["em_sustcompocol.cantnueva",100],["em_sustcompocol.aplicado",60],["em_sustcompocol.idusuarioalta",80],["em_sustcompocol.fechaalta",80],["em_sustcompocol.horaalta",80],["em_sustcompocol.idusuariomod",80],["em_sustcompocol.fechamod",80],["em_sustcompocol.horamod",80], ["em_sustcompocol.idsustcompocol",80]];

	return aTam;
}

function oficial_cargaDatosLogCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var obj = _i.dameTablaLogCostes();	
	var miTabla = obj.miTabla;
	var q = new FLSqlQuery;
	q.setSelect(formRecordarticulos.iface.dameSelectLogCostes(cursor));		
	q.setFrom("v_logcostesmargenes");
	q.setWhere(formRecordarticulos.iface.dameWhereLogCostes(cursor));
	q.setOrderBy("v_logcostesmargenes.fechahis DESC, v_logcostesmargenes.horahis DESC");		
	miTabla.setQuery(q);	

	formRecordarticulos.iface.ponTamanosLogCostes(miTabla);

	miTabla.setReadOnly(true);	
	miTabla.refresh();
	
	return true;	
}

function oficial_dameTablaLogCostes()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblLogCostes_ ? true : false;
	obj.tabla = this.child("mte_tblExt_LogCostes");
	obj.gb = this.child("mte_gbExt_LogCostes");

	if (!obj.creado) {
		_i.tblLogCostes_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblLogCostes_.checkColumnEnabled(false);
		_i.tblLogCostes_.setAliasCheckColumn("Sel.");
		_i.tblLogCostes_.setSearchEnabled(true);
		_i.tblLogCostes_.setOrderDesc(true);
		//_i.tblLogCostes_.setDoubleClickedFunction("formem_reservasop.iface.abrirOP");
	}
	
	obj.miTabla = _i.tblLogCostes_;

	return obj;
}

function oficial_pbnActualizarMargenes_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.actualizaHerencia_ = true;
	flfactalma.iface.oMargenes_ = new Object();
	flfactalma.iface.oMargenes_["em_margenprod"] = cursor.valueBuffer("em_margenprod");
	flfactalma.iface.oMargenes_["em_observmargenprod"] = cursor.valueBuffer("em_observmargenprod");
	cursor.commitBuffer();
	if(!formRecordem_tamanossubfam.iface.actualizarMargenes(cursor)) {
		return false;
	}
	_i.tblLogCostes_.refresh();
	flfactalma.iface.oMargenes_ = false;
}

function oficial_pbnActualizarCostes_clicked()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	_i.actualizaHerencia_ = true;
	flfactalma.iface.oCostes_ = new Object();
	flfactalma.iface.oCostes_["em_costeprod"] = cursor.valueBuffer("em_costeprod");
	flfactalma.iface.oCostes_["em_observcosteprod"] = cursor.valueBuffer("em_observcosteprod");
	cursor.commitBuffer();
	if(!formRecordem_tamanossubfam.iface.actualizarCostes(cursor)) {
		return false;
	}

	_i.tblLogCostes_.refresh();
	flfactalma.iface.oCostes_ = false;
	return true;
}	

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////