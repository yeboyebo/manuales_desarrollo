/***************************************************************************
                 em_lineasplantillaprod.qs  -  description
                             -------------------
    begin                : jue sep 27 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN:String) { return this.ctx.interna_calculateField(fN); }
	function validateForm() {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var aSubFam_, aColor_, aTamano_;
	function oficial( context ) { interna( context ); } 
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function informaCamposPlan() {
		return this.ctx.oficial_informaCamposPlan();
	}
	function compruebaDibujo() {
		return this.ctx.oficial_compruebaDibujo();
	}
	function compruebaTamaSubFam() {
		return this.ctx.oficial_compruebaTamaSubFam();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	debug("interna_init");
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbOrden", _i.calculateField("orden"));
			sys.setObjText(this, "fdbIdSeccion", _i.calculateField("idseccion"));
			sys.setObjText(this, "fdbTipo", "Fijo");
			_i.informaCamposPlan();			
			break;
		}
		case cursor.Edit: {
			this.child("fdbRefComponente").setDisabled(false);
			break;
		}
	}
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "orden": {
			valor = AQUtil.sqlSelect("em_lineasplantillaprod", "MAX(orden)", "idplantilla = " + cursor.valueBuffer("idplantilla"));
			valor = isNaN(valor) ? 0 : valor;
			valor += 100;
			break;
		}
		case "idseccion": {
			valor = AQUtil.sqlSelect("em_lineasplantillaprod", "idseccion", "idplantilla = " + cursor.valueBuffer("idplantilla") + " ORDER BY orden DESC");
			valor = valor ? valor : "";
			break;
		}	
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;
	if(!_i.compruebaDibujo()) {
		return false;
	}
	if(!_i.compruebaTamaSubFam()) {
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_commonCalculateField(fN, cursor)
{
debug("oficial_commonCalculateField " + fN);
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "factor": {
      var piezasAncho = cursor.valueBuffer("piezasancho") ;
			if (isNaN(piezasAncho) || piezasAncho == 0) {
				valor = 1;
			} else {
				valor = cursor.valueBuffer("largo") / piezasAncho / 100;
			}
			//valor = valor == 0 ? valor = 1 : valor;//pineboo 21-08-2019
			if(valor == 0) {
				valor = 1;
			}
			break;
		}
		case "piezasancho": {
			var ancho = cursor.valueBuffer("ancho");     
      		var anchoPiezaTej = cursor.valueBuffer("anchopiezatej"); 
      		anchoPiezaTej = isNaN(anchoPiezaTej) ? 0 : anchoPiezaTej;
      		debug("ancho: "+ancho)
			if (!ancho || isNaN(ancho)) {
				valor = 0;
			} else {
				//valor = Math.floor(284 / ancho);
				valor = Math.floor(anchoPiezaTej / ancho);
			}
			break;
		}
		default: {
		}
	}
			
	return valor;
}

function oficial_bufferChanged(fN)
{
	debug("oficial_bufferChanged " + fN);
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "largo":
		case "piezasancho": {
			sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
			this.child("fdbFactor").setValue(_i.calculateField("factor"));
			break;
		}
		case "ancho": {
			sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
			this.child("fdbFactor").setValue(_i.calculateField("factor"));
			break;
		}
		case "anchopiezatej": {
			sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
			this.child("fdbFactor").setValue(_i.calculateField("factor"));
			break;
		}
		case "tipo": {
			var tipo = cursor.valueBuffer("tipo");
			if(tipo == "Fijo") {
				sys.setObjText(this,  "fdbDibujo", " ");	
				sys.setObjText(this,  "fdbRefComponente", cursor.valueBuffer("componenteorigen"));
			} else if (tipo == "Variable") {
				sys.setObjText(this,  "fdbDibujo", "Principal");	
				cursor.setValueBuffer("componenteorigen",cursor.valueBuffer("refcomponente"));
				sys.setObjText(this,  "fdbRefComponente", "");
				sys.setObjText(this,  "fdbDescComponente", "");
				

			}			
			break;
		}
		default: {
		}
	}
}

function oficial_informaCamposPlan()
{
	var cursor = this.cursor();
	var q = new AQSqlQuery;	
	q.setSelect("codcoleccionem, codsubfamilia, codtamanoem, codcolorem, nombre");
	q.setFrom("em_plantillasprod");
	q.setWhere("idplantilla = '" + cursor.valueBuffer("idplantilla") + "'");			

	if (!q.exec()){
		return;
	}  
	if(q.first())
	{
		this.child("fdbColeccionPlan").setValue(q.value("codcoleccionem"));	
		this.child("fdbCodSubfamiliaPlan").setValue(q.value("codsubfamilia"));	
		this.child("fdbCodTamanoPlan").setValue(q.value("codtamanoem"));	
		this.child("fdbCodColorPlan").setValue(q.value("codcolorem"));	
		this.child("fdbNombrePlan").setValue(q.value("nombre"));	

	}	
}

function oficial_compruebaDibujo()
{
	var cursor = this.cursor();
	var tipo = cursor.valueBuffer("tipo");
	var dibujo = cursor.valueBuffer("dibujo");
	debug("tipo: "+tipo);
	debug("dibujo: -"+dibujo+"-");
	if(tipo == "Fijo" && dibujo != " " && dibujo != "") {
		flfactppal.iface.ponMsgError(sys.translate("Si el tipo es Fijo, el campo 'Dibujo para b�squedas' tiene que estar vac�o"),"warn",this);
		return false;
	} else if (tipo == "Variable" && (dibujo != "Principal" && dibujo != "Coordinado")) {
		flfactppal.iface.ponMsgError(sys.translate("Si el tipo es Variable, el valor del campo 'Dibujo para b�squedas' tiene que ser Principal o Coordinado"),"warn",this);
		return false;
	}
	return true;
}

function oficial_compruebaTamaSubFam()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var tamaCont = cursor.valueBuffer("codtamanocont");
	var tamaPanot = cursor.valueBuffer("codtamanopanot");
	var codSubFam = cursor.valueBuffer("codsubfamilia");

	if(tamaCont && tamaCont != "" && codSubFam && codSubFam != "") {
		if(!AQUtil.sqlSelect("em_tamanossubfam","codtamanoem","codtamanoem = '" + tamaCont + "' AND codsubfamilia = '" + codSubFam + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("El tama�o continuo %1 no existe para la subfamilia %2").arg(tamaCont).arg(codSubFam),"warn",this);
			return false;
		}
	}

	if(tamaPanot && tamaPanot != "" && codSubFam && codSubFam != "") {
		if(!AQUtil.sqlSelect("em_tamanossubfam","codtamanoem","codtamanoem = '" + tamaPanot + "' AND codsubfamilia = '" + codSubFam + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("El tama�o panot %1 no existe para la subfamilia %2").arg(tamaPanot).arg(codSubFam),"warn",this);
			return false;
		}
	}
	return true;

}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////