var form = this;
/***************************************************************************
                 em_masterstocktejidos.qs  -  description
                             -------------------
    begin                : mie ago 21 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	var filtroPreload_;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function preloadMainFilter()
  {
    return this.ctx.interna_preloadMainFilter();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var curStock_;
	var registroSeleccionado_;
	var filtro_;
	var resPendientes_;
	
	function oficial( context ) { interna( context ); } 
	function ordenaCols()
  {
    return this.ctx.oficial_ordenaCols();
  }
  function filtraStocks()
  {
    return this.ctx.oficial_filtraStocks();
  }
  function tdbStocksTejidos_recordChoosed()
  {
    return this.ctx.oficial_tdbStocksTejidos_recordChoosed();
  }
  function chkOcultaBajas_clicked()
  {
    return this.ctx.oficial_chkOcultaBajas_clicked();
  }
  function tbnImprimir() {
    return this.ctx.oficial_tbnImprimir();
  }
  function dameRegistroSeleccionado() {
    return this.ctx.oficial_dameRegistroSeleccionado();
  }
  function dameFiltro() {
    return this.ctx.oficial_dameFiltro();
  }
	function refrescaReservasPendientes() {
		return this.ctx.oficial_refrescaReservasPendientes();
	}
	function calculaReservasPtes() {
		return this.ctx.oficial_calculaReservasPtes();
	}
	function tbnRevisarReservas_clicked() {
		return this.ctx.oficial_tbnRevisarReservas_clicked();
	}
	function formReady() {
		return this.ctx.oficial_formReady();
	}
	function tbnVerReservas_clicked() {
		return this.ctx.oficial_tbnVerReservas_clicked();
	}
	function tbnVerPartidas_clicked() {
		return this.ctx.oficial_tbnVerPartidas_clicked();
	}
	function tbnRecalculo_clicked() {
		return this.ctx.oficial_tbnRecalculo_clicked();
	}
	function recalculoReservasTejido(oParam) {
		return this.ctx.oficial_recalculoReservasTejido(oParam);
	}
	function tbnImprimirNT() {
    return this.ctx.oficial_tbnImprimirNT();
  }
  function tbnExcelCola_clicked() {
		return this.ctx.oficial_tbnExcelCola_clicked();
	}
	
}

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  
	function pub_dameRegistroSeleccionado() {
		return this.dameRegistroSeleccionado();
	}
	function pub_dameFiltro() {
		return this.dameFiltro();
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	
	_i.ordenaCols();
	
	connect(this.child("tdbSubfamilias").cursor(), "newBuffer()", _i, "filtraStocks");
	connect(this.child("tdbStocksTejidos").cursor(), "recordChoosed()", _i, "tdbStocksTejidos_recordChoosed");
	connect(this.child("tbnVerStock"), "clicked()", _i, "tdbStocksTejidos_recordChoosed");
	connect(this.child("chkOcultaBajas"), "clicked()", _i, "chkOcultaBajas_clicked");
  connect(this.child("tbnImprimir"), "clicked()", _i, "tbnImprimir()"); 
	connect(this.child("tbnRevisarReservas"), "clicked()", _i, "tbnRevisarReservas_clicked()"); 
	connect(this.child("tbnVerReservas"), "clicked()", _i, "tbnVerReservas_clicked()");
	connect(this.child("tbnVerPartidas"), "clicked()", _i, "tbnVerPartidas_clicked()");  
	connect(this.child("tbnRecalculo"), "clicked()", _i, "tbnRecalculo_clicked");
	connect(this, "formReady()", _i, "formReady");
	connect(this.child("tbnImprimirNT"), "clicked()", _i, "tbnImprimirNT()"); 
	connect(this.child("tbnExcelCola"), "clicked()", _i, "tbnExcelCola_clicked");
	_i.filtroPreload_ = this.child("tdbSubfamilias").cursor().mainFilter();
debug("MAIN FILTER " + _i.filtroPreload_ );
	_i.filtraStocks();
	_i.chkOcultaBajas_clicked();
	
	flfactalma.iface.recargaRutasTejidoPrep();

	
	
}


function interna_preloadMainFilter()
{
	var _i = this.iface;
	var fams = flfactalma.iface.pub_dameFamEstampado();
	var subfams = flfactalma.iface.pub_dameSubfamEstampado();
	
	var f = "(codsubfamilia IN (" + subfams + ") OR codfamilia IN (" + fams + "))";
	return f;
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_filtraStocks()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	
	var filtro = "1 = 2";
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	if (codSubfamilia) {
		filtro = "em_rutastpsubfam.codsubfamilia = '" + codSubfamilia + "'";
	}
	debug("filtro: "+filtro);
	
	
	this.child("tdbStocksTejidos").cursor().setMainFilter(filtro);

	this.child("tdbStocksTejidos").refresh();
}

function oficial_ordenaCols()
{
	var oC = ["descripcion", "codsubfamilia"];
	this.child("tdbSubfamilias").setOrderCols(oC);
}

function oficial_tdbStocksTejidos_recordChoosed()
{
	var _i = this.iface;
	if (!_i.curStock_) {
		_i.curStock_ = new FLSqlCursor("stocks");
	}
	var curST = this.child("tdbStocksTejidos").cursor();
	var idStock = curST.valueBuffer("idstock");
	_i.curStock_.select("idstock = " + idStock);
	if (_i.curStock_.first()) {
		_i.curStock_.browseRecord();
	}
}

function oficial_chkOcultaBajas_clicked()
{
	var _i = this.iface;
	var f = _i.filtroPreload_;
	if (this.child("chkOcultaBajas").checked) {
		f += " AND NOT subfamilias.embaja";
	}
	this.child("tdbSubfamilias").cursor().setMainFilter(f);
	this.child("tdbSubfamilias").refresh();
}

function oficial_tbnImprimir()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var filtro = _i.filtroPreload_;
	if (this.child("chkOcultaBajas").checked) {
		filtro += " AND NOT subfamilias.embaja";
	}
	
	_i.registroSeleccionado_ = cursor.valueBuffer("codsubfamilia");
	_i.filtro_ = filtro;
	
	var f = new FLFormSearchDB("em_subfamiliasrutareservas");
	f.cursor().setMainFilter(filtro);
	f.setMainWidget();
	f.exec();
	
}

function oficial_dameRegistroSeleccionado()
{
	var _i = this.iface;
  var cursor = this.cursor();
	
	return _i.registroSeleccionado_;
}

function oficial_dameFiltro()
{
	var _i = this.iface;
  var cursor = this.cursor();
	
	return _i.filtro_;
}

function oficial_calculaReservasPtes()
{
	var _i = this.iface;
	var p =0;
	var q = new AQSqlQuery;
	q.setSelect("m1.idmovimiento");
	q.setFrom("movistock m1 LEFT OUTER JOIN movistock m2 ON m1.idmovimiento = m2.idmovtejidoprep INNER JOIN articulos a on m1.referencia = a.referencia AND m1.codsubfamiliatp = a.codsubfamilia INNER JOIN subfamilias subfam on subfam.codsubfamilia = a.codsubfamilia"); /// El segundo join nos asegura que s�lo tomamos el movimiento ra�z de la cadena de reservas
	q.setWhere("m1.codsubfamiliatp IS NOT NULL AND m1.estado = 'PTE' AND m1.reservaaf > 0 AND m2.idmovimiento IS NULL and not subfam.em_excluirruta ORDER BY m1.idmovimiento");
	debug("consulta: "+q.sql());
	if (!q.exec()) {
		return false;
	}
	var r = q.size();
	r = isNaN(r) ? 0 : r;
	
	_i.resPendientes_ = undefined;
	_i.resPendientes_ = [];
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Calculando reservas"), r);
	while (q.next()) {
		AQUtil.setProgress(p++);
		
		_i.resPendientes_.push(q.value("m1.idmovimiento"));
	}
	AQUtil.destroyProgressDialog();
	return r;
}

function oficial_formReady()
{
	var _i = this.iface;
	_i.refrescaReservasPendientes();
}
function oficial_refrescaReservasPendientes()
{
	var _i = this.iface;
	var r = _i.calculaReservasPtes();
	var color = r ? new QColor(255, 0, 0) : new QColor(0, 0, 0);
	var texto = r ? sys.translate("AVISO: Debe revisar %1 reservas pendientes").arg(r) : sys.translate("No hay reservas pendientes");
	
	this.child("lblResPtes").paletteForegroundColor = color;
	sys.setObjText(this, "lblResPtes", texto);

}

function oficial_tbnRevisarReservas_clicked()
{
	var _i = this.iface;
	var oParam = new Object;
	oParam.canReservas = undefined;
	oParam.errorMsg = "";
	if (!formmt_procesos.iface.ejecutaFuncionDefecto("emRevisaReservasTejidoPrev")) {
		return false;
	}
	/*var f = new Function("oParam", "return formmt_procesos.iface.emRevisaReservasTejidoPrev(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		sys.warnMsgBox(sys.translate("Error al revisar las reservas de tejido") + "\n" + oParam.errorMsg);
		return false;
	}
	*/
	_i.refrescaReservasPendientes();
	this.child("tdbStocksTejidos").refresh();
}

function oficial_tbnVerReservas_clicked()
{
	var _i = this.iface;
	if (!_i.resPendientes_ || _i.resPendientes_.length == 0) {
		sys.infoMsgBox(sys.translate("No hay reservas pendientes"));
		return;
	}
	var f = "idmovimiento IN (" + _i.resPendientes_.join(", ") + ")";
	var fS = new FLFormSearchDB("em_reservastejidoptes");
	var curMS = fS.cursor();
	curMS.setMainFilter(f);

	fS.setMainWidget();
	fS.exec("idfactura");
}
function oficial_tbnVerPartidas_clicked()
{
debug("oficial_tbnVerPartidas_clicked");

	var curST = this.child("tdbStocksTejidos").cursor();
	var codAlmacen = curST.valueBuffer("codalmacen");
	var referencia = curST.valueBuffer("referencia");
	
	var f = new FLFormSearchDB("em_partidas");	
	f.setMainWidget();
	var curA = f.cursor();
	curA.setModeAccess(curA.Insert);
	curA.refreshBuffer();
	curA.setValueBuffer("codalmacen",codAlmacen);
	curA.setValueBuffer("nombrealmacen",AQUtil.sqlSelect("almacenes", "nombre", "codalmacen='" + codAlmacen + "'"));
	curA.setValueBuffer("referencia",referencia);
	curA.setValueBuffer("descarticulo",AQUtil.sqlSelect("articulos", "descripcion", "referencia='" + referencia + "'"));

	f.exec("codalmacen");	

}
function oficial_tbnRecalculo_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var oParam = { "codSubfamilia" : codSubfamilia };	
	var f = new Function("oParam", "return formem_stocktejidos.iface.recalculoReservasTejido(oParam)");	
	if (!sys.runTransaction(f, oParam)) {
		sys.warnMsgBox(sys.translate("Error al recalcular las reservas de tejido"));
		return false;
	}
	
	
/*	if (!_i.recalculoReservasTejido(oParam)) {
		return false;
	}*/
}

function oficial_recalculoReservasTejido(oParam)
{
	var _i = this.iface;
	var codSubfamilia = oParam.codSubfamilia;
	
	var qMov = new FLSqlQuery;
	qMov.setSelect("ms.idmovimiento");
	qMov.setFrom("movistock ms LEFT OUTER JOIN movistock mst ON ms.idmovtejidoprep = mst.idmovimiento");
	qMov.setWhere("ms.codsubfamiliatp = '" + codSubfamilia + "' AND mst.idmovimiento IS NULL");
	if (!qMov.exec()) {
		return false;
	}
	var curMovTP = new FLSqlCursor("movistock");
	AQUtil.createProgressDialog(sys.translate("Borrando reservas actuales"), qMov.size());
	var p = 0;
	while (qMov.next()) {
		AQUtil.setProgress(++p);
		curMovTP.select("idmovimiento = " + qMov.value("ms.idmovimiento"));
		if (!curMovTP.first()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		curMovTP.setModeAccess(curMovTP.Edit);
		curMovTP.refreshBuffer();
		if (!flfactalma.iface.borraMovTejidoPrep(curMovTP)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	if (!formmt_procesos.iface.emRevisaReservasTejidoPrev(oParam)) {
		return false;
	}
	return true;
}

function oficial_tbnImprimirNT()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var curRuta = this.child("tdbStocksTejidos").cursor();
	//var filtro = _i.filtroPreload_;
	var filtro = "";
	if (this.child("chkOcultaBajas").checked) {
		filtro += " NOT subfamilias.embaja";
	}
	
	_i.registroSeleccionado_ = curRuta.valueBuffer("idrutatp");
	_i.filtro_ = filtro;

	debug("filtro antes de abrir: "+_i.filtro_);
	var f = new FLFormSearchDB("em_necesidadestejido");
	f.cursor().setMainFilter(filtro);
	f.setMainWidget();
	f.exec();
	
}

function oficial_tbnExcelCola_clicked()
{
	fleumoesta.iface.pub_excelCola();
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////

