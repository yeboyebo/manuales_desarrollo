/***************************************************************************
                 em_preciosclientes.qs  -  description
                             -------------------
    begin                : mie ene 25 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function validateForm():Boolean { return this.ctx.interna_validateForm(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  function oficial( context ) { interna( context ); } 
  function bufferChanged(fN) {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function iniciaValores() {
    return this.ctx.oficial_iniciaValores();
  }
  function cargaDescripcion() {
    return this.ctx.oficial_cargaDescripcion();
  }
  function tbnBuscaCodVentas_clicked() {
    return this.ctx.oficial_tbnBuscaCodVentas_clicked();
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
  connect(this.child("tbnBuscaCodVentas"), "clicked()", _i, "tbnBuscaCodVentas_clicked");
  
  switch (cursor.modeAccess()) {
  case cursor.Insert: {
      _i.iniciaValores();
      break;
    }
  case cursor.Edit: {
      this.child("tbnBuscaCodVentas").enabled = false;
    }
  }
  _i.cargaDescripcion();
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
	return true;
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnBuscaCodVentas_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var des = "";
  switch (cursor.valueBuffer("tipoventa")) {
  case "Cliente": {
      var f = new FLFormSearchDB("clientes");
      f.setMainWidget();
      var codCliente = f.exec("codcliente");
      if (codCliente) {
        sys.setObjText(this, "fdbCodVentas", codCliente);
      }
      break;
    }
  case "Grupo precio cliente": {
      var f = new FLFormSearchDB("gruposclientes");
      f.setMainWidget();
      var codGrupo = f.exec("codgrupo");
      if (codGrupo) {
        sys.setObjText(this, "fdbCodVentas", codGrupo);
      }
      break;
    }	
  }
}

function oficial_cargaDescripcion()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var des = "";
  switch (cursor.valueBuffer("tipoventa")) {
  case "Cliente": {
      des = AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + cursor.valueBuffer("codventas") + "'");
      break;
    }
  case "Grupo precio cliente": {
      des = AQUtil.sqlSelect("gruposclientes", "nombre", "codgrupo = '" + cursor.valueBuffer("codventas") + "'");
      break;
    }	
  }
  sys.setObjText(this, "lblDesCodVentas", des ? des : "");
}

function oficial_bufferChanged(campo)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (campo) {
  case "tipoventa":
  case "codventas": {
      _i.cargaDescripcion();
      break;
    }
  }
}

function oficial_iniciaValores()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var curRel = cursor.cursorRelation();
	switch (curRel.table()) {
		case "clientes": {
			cursor.setValueBuffer("tipoventa", "Cliente");
			this.child("fdbCodVentas").setValue(curRel.valueBuffer("codcliente"));
			this.child("fdbTipoVenta").setDisabled(true);
			this.child("fdbCodVentas").setDisabled(true);
			break;
		}
		case "gruposclientes": {
			cursor.setValueBuffer("tipoventa", "Grupo precio cliente");
			this.child("fdbCodVentas").setValue(curRel.valueBuffer("codgrupo"));
			this.child("fdbTipoVenta").setDisabled(true);
			this.child("fdbCodVentas").setDisabled(true);
			break;
		}
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
