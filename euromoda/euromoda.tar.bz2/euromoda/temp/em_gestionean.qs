var form = this;
/***************************************************************************
								 em_gestionean.qs  -  description
														 -------------------
		begin                : jue feb 13 2014
		copyright            : (C) 2014 by InfoSiAL S.L.
		email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
	var ctx: Object;
	function interna(context)
	{
		this.ctx = context;
	}
	function init()
	{
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	function oficial(context)
	{
		interna(context);
	}
	function tbnGenerar_clicked()
	{
		return this.ctx.oficial_tbnGenerar_clicked();
	}
	function generaEans(oParam)
	{
		return this.ctx.oficial_generaEans(oParam);
	}
	function digitoControlEAN(valorSinDC)
	{
		return this.ctx.oficial_digitoControlEAN(valorSinDC);
	}
	function tbnBuscar_clicked()
	{
		return this.ctx.oficial_tbnBuscar_clicked();
	}
	function dameFiltro(p)
	{
		return this.ctx.oficial_dameFiltro(p);
	}
	function preprocesoEan(p)
	{
		return this.ctx.oficial_preprocesoEan(p);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
	function head(context)
	{
		oficial(context);
	}
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
	function ifaceCtx(context)
	{
		head(context);
	}
	function pub_generaEans(oParam) {
		return this.generaEans(oParam);
	}
	function pub_dameFiltro(p) {
		return this.dameFiltro(p);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	
	connect(this.child("tbnGenerar"), "clicked()", _i, "tbnGenerar_clicked");
	connect(this.child("tbnBuscar"), "clicked()", _i, "tbnBuscar_clicked()");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnBuscar_clicked()
{
	var _i = this.iface;
	var p = this.child("ledPrefijo").text;
	var f = _i.dameFiltro(p);

	var cursor = this.cursor();
	cursor.setMainFilter(f);
	this.child("tdbEAN").refresh();
}

function oficial_dameFiltro(p)
{
	var f;
	if (!p || p == "") {
		f = "true";
	} else {
		f = "ean LIKE '" + p + "%'";
	}
	return f;
}

function oficial_preprocesoEan(p)
{
	var _i = this.iface;
	if (!p || p == "" || p.length != 7) {
		sys.warnMsgBox(sys.translate("El formato del prefijo no es correcto"));
		return false;
	}
	if (isNaN(p)) {
		sys.warnMsgBox(sys.translate("El formato del prefijo no es correcto"));
		return false;
	}
	var numEan = AQUtil.sqlSelect("articulos", "COUNT(*)", "codbarras LIKE '" + p + "%'");
	numEan = isNaN(numEan) ? 0 : numEan;
	var numH = 100000 - numEan;
	var res = MessageBox.information(sys.translate("Hay %1 art�culos con el prefijo EAN %2.\nSe generar�n hasta %3 EANs disponibles").arg(numEan).arg(p).arg(numH), MessageBox.Ok, MessageBox.Cancel, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Ok) {
		return false;
	}
	return true;
}

function oficial_tbnGenerar_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var p = this.child("ledPrefijo").text;
	if (!_i.preprocesoEan(p)) {
		return false;
	}
	
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al regenerar los EAN");
	oParam.prefijo = p.toString();
	oParam.tabla = cursor.table();
	var f = new Function("oParam", "return formem_gestionean.iface.generaEans(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	this.child("tdbEAN").refresh();
	sys.infoMsgBox(sys.translate("Generaci�n completada"));
}

function oficial_generaEans(oParam)
{
	var _i = this.iface;
	var totalEan = 100000; //100000;
	var aux, dc, barcode;
	var prefijo = oParam.prefijo;
	var tabla = oParam.tabla;
	var eans = new Object;
	var q = new FLSqlQuery;
	q.setSelect("codbarras");
	q.setFrom("articulos");
	q.setWhere("codbarras LIKE '" + prefijo + "%' ORDER BY codbarras");
	if (!q.exec()) {
		return false;
	}
	AQUtil.createProgressDialog(sys.translate("Memorizando EANs existentes"), q.size());
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(++p);
		eans[q.value("codbarras")] = true;
	}
	AQUtil.destroyProgressDialog();
	
	AQUtil.createProgressDialog(sys.translate("Borrando EANs"), totalEan);
	AQUtil.setProgress(1);
	if (!AQSql.del(tabla, "ean LIKE '" + prefijo + "%'")) {
		return false;
	}
	//var curEan = new FLSqlCursor(tabla);
	AQUtil.setLabelText(sys.translate("Generando EANs"));
	for (var i = 0; i < totalEan; i++) {
		AQUtil.setProgress(i);
		aux = prefijo.toString() + flfactppal.iface.pub_cerosIzquierda(i, 5);
		dc = _i.digitoControlEAN(aux.toString());
		barcode = aux.toString() + dc.toString();
		if (barcode in eans) {
			continue;
		}
		AQUtil.setLabelText(sys.translate("Generando EAN %1").arg(barcode));
		if (!AQUtil.execSql("INSERT INTO " + tabla + " (ean) VALUES ('" + barcode.toString() + "')")) {
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_digitoControlEAN(valorSinDC)
{
	var pesos: Array;
	if (!valorSinDC || valorSinDC == "") {
		return false;
	}
	debug("dc para " + valorSinDC);
	var longValorSinDC: Number = valorSinDC.length;
	switch (longValorSinDC) {
	case 12: { /// EAN 13
			pesos = [1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3];
			break;
		}
	case 13: { /// EAN 14
			pesos = [3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3];
			break;
		}
	default: {
			return false;
		}
	}
	var suma: Number = 0;
	for (var i: Number = 0; i < longValorSinDC; i++) {
		suma += parseInt(valorSinDC.charAt(i)) * parseInt(pesos[i]);
	}
	var decenaSuperior: Number = (Math.floor(suma / 10) + 1) * 10;
	var valor: Number = decenaSuperior - suma;
	if (valor == 10) {
		valor = 0;
	}
	return valor.toString();
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
