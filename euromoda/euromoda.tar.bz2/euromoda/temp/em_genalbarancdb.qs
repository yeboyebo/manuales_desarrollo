/**************************************************************************
                 em_genalbarancdb.qs  -  description
                             -------------------
    begin                : jue ene 2 2020
    copyright            : (C) 2020 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {	
	var oPedido_;
	var tblAlbaranes_;
	var curPedido_;
	var curAlb_;
	var curImprimir_;
    function oficial( context ) { interna( context ); }
	
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}	
	function tbnBuscarAgencia_clicked() {
		return this.ctx.oficial_tbnBuscarAgencia_clicked();
	}	
	function leCodigo_returnPressed() {
		return this.ctx.oficial_leCodigo_returnPressed();
	}
	function buscaDatosPedido(oParam) {
		return this.ctx.oficial_buscaDatosPedido(oParam);
	}
	function buscaPedidoXPedido(codigo) {
		return this.ctx.oficial_buscaPedidoXPedido(codigo);
	}
	function buscaPedidoXDropship(codigo) {
		return this.ctx.oficial_buscaPedidoXDropship(codigo);
	}
	function buscaPedidoXTracking(codigo) {
		return this.ctx.oficial_buscaPedidoXTracking(codigo);
	}
	function generarAlbaranAutomatico(oParamPed) {
		return this.ctx.oficial_generarAlbaranAutomatico(oParamPed);
	}
	function generarAlbaranParcial(oParamPed) {
		return this.ctx.oficial_generarAlbaranParcial(oParamPed);
	}
	function generarAlbaran(oParamPed) {
		return this.ctx.oficial_generarAlbaran(oParamPed);
	}
	function datosAlbaranCDB(oParamPed) {
		return this.ctx.oficial_datosAlbaranCDB(oParamPed);
	}
	function imprimirSegunCheck(idAlbaran) {
		return this.ctx.oficial_imprimirSegunCheck(idAlbaran);
	}
	function imprimeAlbaran(oParamImp) {
		return this.ctx.oficial_imprimeAlbaran(oParamImp);
	}
	function cargaDatosAlbaranes() {
		return this.ctx.oficial_cargaDatosAlbaranes();
	}
	function dameTablaAlbaranes() {
		return this.ctx.oficial_dameTablaAlbaranes();
	}
	function dameSelectAlbarnes() {
		return this.ctx.oficial_dameSelectAlbarnes();
	}
	function editarLineasAlbParc() {
		return this.ctx.oficial_editarLineasAlbParc();
	}
	function toolButtonEdit_clicked() {
		return this.ctx.oficial_toolButtonEdit_clicked();	
	}
	function toolButtonDelete_clicked() {
		return this.ctx.oficial_toolButtonDelete_clicked();	
	}
	function toolButtonZoom_clicked() {
		return this.ctx.oficial_toolButtonZoom_clicked();
	}
	function tbnAbrirCerrar_clicked() {
		return this.ctx.oficial_tbnAbrirCerrar_clicked();
	}
	function accionCursorExterno(accion) {
		return this.ctx.oficial_accionCursorExterno(accion);
	}
	function refrescaTablaAlb() {
		return this.ctx.oficial_refrescaTablaAlb();
	}
	function curAlb_bufferCommited() {
		return this.ctx.oficial_curAlb_bufferCommited();
	}
	function toolButtonPrint_clicked() {
		return this.ctx.oficial_toolButtonPrint_clicked();
	}
	function tbnImprimirMembrete_clicked() {
		return this.ctx.oficial_tbnImprimirMembrete_clicked();
	}
	function tbnAlbaranTrans_clicked() {
		return this.ctx.oficial_tbnAlbaranTrans_clicked();
	}
	function tbnEtiquetas_clicked() {
		return this.ctx.oficial_tbnEtiquetas_clicked();
	}
	function tbnDistribuyeEjercicio_clicked() {
		return this.ctx.oficial_tbnDistribuyeEjercicio_clicked();
	}
	function pbnLineasPtes_clicked() {
		return this.ctx.oficial_pbnLineasPtes_clicked();
	}
	function abreGenerarParcial(idPedido, idAlbaran) {
		return this.ctx.oficial_abreGenerarParcial(idPedido, idAlbaran);
	}
	function guardaCamposPedido() {
  		return this.ctx.oficial_guardaCamposPedido();
  	}
	function leAgencia_lostFocus() {
		return this.ctx.oficial_leAgencia_lostFocus();
	}
	function leBultos_lostFocus() {
		return this.ctx.oficial_leBultos_lostFocus();
	}
	function lePesoBruto_lostFocus() {
		return this.ctx.oficial_lePesoBruto_lostFocus();
	}
	function leVolumen_lostFocus() {
		return this.ctx.oficial_leVolumen_lostFocus();
	}
	function dameTamaniosTabla() {
		return this.ctx.oficial_dameTamaniosTabla();
	}
	function recargaPedido() {
		return this.ctx.oficial_recargaPedido();
	}
	function dimeSiHayQueRevisar(idPedido) {
		return this.ctx.oficial_dimeSiHayQueRevisar(idPedido);
	}
	function calculaEstadoPedidos(idPedido) {
		return this.ctx.oficial_calculaEstadoPedidos(idPedido);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	connect(this.child("tbnBuscarAgencia"), "clicked()", _i, "tbnBuscarAgencia_clicked");	
	connect(this.child("leCodigo"), "returnPressed()", _i, "leCodigo_returnPressed");

	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	connect(this.child("tbnAbrirCerrar"), "clicked()", _i, "tbnAbrirCerrar_clicked");
	connect(this.child("toolButtonPrint"), "clicked()", _i, "toolButtonPrint_clicked");
	connect(this.child("tbnImprimirMembrete"), "clicked()", _i, "tbnImprimirMembrete_clicked");
	connect(this.child("tbnAlbaranTrans"), "clicked()", _i, "tbnAlbaranTrans_clicked");
	connect(this.child("tbnEtiquetas"), "clicked()", _i, "tbnEtiquetas_clicked");
	connect(this.child("tbnDistribuyeEjercicio"), "clicked()", _i, "tbnDistribuyeEjercicio_clicked");
	connect(this.child("pbnLineasPtes"), "clicked()", _i, "pbnLineasPtes_clicked");
	connect(this.child("leAgencia"), "lostFocus()", _i, "leAgencia_lostFocus");
	connect(this.child("leBultos"), "lostFocus()", _i, "leBultos_lostFocus");	
	connect(this.child("lePesoBruto"), "lostFocus()", _i, "lePesoBruto_lostFocus");	
	connect(this.child("leVolumen"), "lostFocus()", _i, "leVolumen_lostFocus");

	debug("cursor.action: "+cursor.action());

	_i.tblAlbaranes_ = false;
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);	
	} else {
		this.child("lblEstado").close();
	}
	
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnBuscarAgencia_clicked()
{
	var _i = this.iface;	

	var filtro = "esagenciat";
	var f = new FLFormSearchDB("proveedores");	
	f.setMainWidget();
	f.cursor().setMainFilter(filtro);
	var codProveedor = f.exec("codproveedor");
	if (codProveedor) {		
		this.child("leAgencia").text = codProveedor;
		var nombreAgencia = AQUtil.sqlSelect("proveedores","nombre","codproveedor = '" + codProveedor + "'");
		if(!nombreAgencia) {
			nombreAgencia = "";
		}
		this.child("leDescAgencia").text = nombreAgencia;	
	}
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	
	/*var sel = false;
	var nF = _i.tblLineas_.numRows();
	for (var f = 0; f < nF && !sel; f++) {    
    	if (_i.tblLineas_.text(f, 0) == "X") {
      		sel = true;
    	}
  	} 
  	if(!sel) {
  		sys.warnMsgBox(sys.translate("No ha seleccionado ning�n registro."));
  		return false;
  	}	
	if(!_i.creaLineas()) {
		return false;
	}	*/
	this.obj().accept();
}

function oficial_leCodigo_returnPressed()
{
	var _i = this.iface;		
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}


	if(!_i.tblAlbaranes_) {
		_i.cargaDatosAlbaranes();	
	}	
	var idPedAlbCDB = formpedidoscli.iface.idPedAlbCDB_;
	var fPC_ = formpedidoscli.iface;
	_i.oPedido_ = false;
	
	var codigo = this.child("leCodigo").text;
	codigo = codigo.toUpperCase();

	if(!codigo || codigo == "") {
		formUI.ponMsgWarn(sys.translate("El c�digo no puede estar vac�o. Se cancela el proceso"));
		return false;
	}

	var buscarXPedido = this.child("chkPedidos").checked;
	var buscarXDropship = this.child("chkPedidosDrop").checked;
	var buscarXTracking = this.child("chkTrackingDrop").checked;
	var omitirAvisosCostes = this.child("chkOmitirAvisosCos").checked;
	var cerrar = this.child("chkCerrarPedPar").checked; 
	

	if(omitirAvisosCostes) {
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_= true;
	} else {
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_= false;
	}

	if(!buscarXPedido && !buscarXDropship && !buscarXTracking) {
		formUI.ponMsgWarn(sys.translate("Debe marcar como m�nimo uno de los 3 checks para realizar la b�squeda del pedido.\n Se cancela el proceso"));
		return false;
	}

	var oParam = new Object;
	oParam["codigo"] = codigo;
	oParam["buscarXPedido"] = buscarXPedido;
	oParam["buscarXDropship"] = buscarXDropship;
	oParam["buscarXTracking"] = buscarXTracking;		
	_i.oPedido_ = _i.buscaDatosPedido(oParam);

	if(!_i.oPedido_) {
		formUI.ponMsgWarn(sys.translate("No se ha encontrado ning�n pedido"));
		return false;
	}
	var hayQueRevisar = 0;
	if (cursor.action() == "em_pedidoscliparciales") {	
		if (!formem_pedidosptes.iface.cargaMaximosLineaPedido(_i.oPedido_["codigo"])) {
			return false;
		}

		hayQueRevisar = _i.dimeSiHayQueRevisar(_i.oPedido_["idpedido"]);

	}	

	var oParamPed = new Object;
	oParamPed["idPedAlbCDB"] = idPedAlbCDB;
	oParamPed["chkUsarAgencia"] = this.child("chkUsarAgencia").checked;
	oParamPed["leAgencia"] = this.child("leAgencia").text;
	oParamPed["leBultos"] = this.child("leBultos").text;
	oParamPed["lePesoBruto"] = this.child("lePesoBruto").text;
	oParamPed["leVolumen"] = this.child("leVolumen").text;
	oParamPed["txtObsTrans"] = this.child("txtObsTrans").text;	
	oParamPed["leClaseM"] = this.child("leClaseM").text;
	oParamPed["idpedido"] = _i.oPedido_["idpedido"];

	fPC_.silent_ = true;
	var idAlbaran = "";
	if(this.child("chkAlbAutomatico").checked) {

		if(this.child("chkRevisarPedPar").checked && hayQueRevisar != 0) {
			formpedidoscliparciales.iface.idAlbaran_ = false;
			if(!_i.guardaCamposPedido()) {
				return false;
			}
			idAlbaran = _i.generarAlbaranParcial(oParamPed);
		} else {	
			if(hayQueRevisar == 2) {
				formUI.ponMsgWarn(sys.translate("No hay ninguna l�nea que servir y no se generar� el albar�n."));					
			} else {
				idAlbaran = _i.generarAlbaranAutomatico(oParamPed);	
			}			
		}
	} else {
		formpedidoscliparciales.iface.idAlbaran_ = false;
		if(!_i.guardaCamposPedido()) {
			return false;
		}
		idAlbaran = _i.generarAlbaranParcial(oParamPed);
	}
	if(idAlbaran && idAlbaran != "") {
		if(cerrar) {			
			if(!AQUtil.sqlUpdate("lineaspedidoscli","cerrada",true,"idpedido = " + _i.oPedido_["idpedido"] + " AND cantidad <> totalenalbaran")) {
				formUI.ponMsgWarn(sys.translate("Error al cerrar l�nea del pedido"));
				return false;
			}
		}
		if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(_i.oPedido_["idpedido"])) {
			return false;
		}	
	}
	fPC_.silent_ = false;
	if (cursor.action() == "em_pedidoscliparciales") {		
		if (!AQSql.del("em_pedidospedptes", "idpedido = " + _i.oPedido_["idpedido"])) {
			return false;
		}
		formem_pedidosptes.iface.cargaDatos(false, _i.oPedido_["idpedido"]);			
		if (!_i.calculaEstadoPedidos(_i.oPedido_["idpedido"])) {			
			return false;
		}

	}

	if(idAlbaran) {	
		_i.imprimirSegunCheck(idAlbaran);
		_i.tblAlbaranes_.refresh();
		this.child("leCodigo").text = "";
		if(!this.child("chkMantenerBultos").checked) {
			this.child("leBultos").text = "";
			this.child("lePesoBruto").text = "";
			this.child("leVolumen").text = "";
			this.child("leClaseM").text = "CAJAS";
		}
		this.child("txtObsTrans").text = "";
	}
	formRecordpresupuestoscli.iface.ignorarAvisosCostes_= false;
	this.child("leCodigo").setFocus();
	return true;
}

function oficial_buscaDatosPedido(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(oParam["buscarXPedido"]) {
		_i.oPedido_ = _i.buscaPedidoXPedido(oParam["codigo"]);	
	}
	if(_i.oPedido_) {
		return _i.oPedido_;
	}
	if(oParam["buscarXDropship"]) {
		_i.oPedido_ = _i.buscaPedidoXDropship(oParam["codigo"]);
	}
	if(_i.oPedido_) {
		return _i.oPedido_;
	}
	if(oParam["buscarXTracking"]) {
		_i.oPedido_ = _i.buscaPedidoXTracking(oParam["codigo"]);
	}
	return _i.oPedido_;
	
}

function oficial_buscaPedidoXPedido(codigo)
{
	var _i = this.iface;

	var q = new AQSqlQuery;	
	q.setSelect("p.codigo,p.codcliente,p.idpedido,p.emcatservicio");
	q.setFrom("pedidoscli p");
	q.setWhere("p.codigo = '" + codigo + "' AND p.servido IN ('No','Parcial')");	
	if (!q.exec()){
		return false;
	}  
	if(!q.first())
	{
		return false;	
	}		

	_i.oPedido_ = new Object;
	_i.oPedido_["codigo"] = q.value("p.codigo");
	_i.oPedido_["codcliente"] = q.value("p.codcliente");
	_i.oPedido_["idpedido"] = q.value("p.idpedido");
	_i.oPedido_["emcatservicio"] = q.value("p.emcatservicio");

	return _i.oPedido_;
}

function oficial_buscaPedidoXDropship(codigo)
{
	var _i = this.iface;

	var q = new AQSqlQuery;	
	q.setSelect("p.codigo,p.codcliente,p.idpedido,p.emcatservicio");
	q.setFrom("pedidoscli p INNER JOIN em_cargadropshipping ds ON ds.idpedido = p.idpedido");
	q.setWhere("ds.pedidoprivalia = '" + codigo + "' AND p.servido IN ('No','Parcial')");	
	if (!q.exec()){
		return false;
	}  
	if(!q.first())
	{
		return false;	
	}		

	_i.oPedido_ = new Object;
	_i.oPedido_["codigo"] = q.value("p.codigo");
	_i.oPedido_["codcliente"] = q.value("p.codcliente");
	_i.oPedido_["idpedido"] = q.value("p.idpedido");
	_i.oPedido_["emcatservicio"] = q.value("p.emcatservicio");

	return _i.oPedido_;
}

function oficial_buscaPedidoXTracking(codigo)
{
	var _i = this.iface;

	var q = new AQSqlQuery;	
	q.setSelect("p.codigo,p.codcliente,p.idpedido,p.emcatservicio");
	q.setFrom("pedidoscli p INNER JOIN em_cargadropshipping ds ON ds.idpedido = p.idpedido");
	q.setWhere("left(ds.tracking,17) = '" + codigo + "' AND p.servido IN ('No','Parcial')");	
	//debug("q: "+q.sql());
	if (!q.exec()){
		return false;
	}  
	if(!q.first())
	{
		return false;	
	}		

	_i.oPedido_ = new Object;
	_i.oPedido_["codigo"] = q.value("p.codigo");
	_i.oPedido_["codcliente"] = q.value("p.codcliente");
	_i.oPedido_["idpedido"] = q.value("p.idpedido");
	_i.oPedido_["emcatservicio"] = q.value("p.emcatservicio");

	return _i.oPedido_;
}

function oficial_generarAlbaranAutomatico(oParamPed)
{

	var _i = this.iface;

	var curT = new FLSqlCursor("empresa");
	curT.transaction(false);
	var idAlbaran = false;
	try {
		idAlbaran =_i.generarAlbaran(oParamPed);
		if (idAlbaran) {
			curT.commit();
		} else {
			curT.rollback();
		}
	}
	catch (e) {
		curT.rollback();
		debug("error 1");
		formUI.ponMsgWarn(sys.translate("Hubo un error en la generaci�n del albar�n:\n%1").arg(e));
	}	
	return idAlbaran;	
}

function oficial_generarAlbaranParcial(oParamPed)
{
	var _i = this.iface;
	var fPC_ = formpedidoscli.iface;	
	var idPedido = oParamPed["idpedido"];
	var idAlbaran = false;

	var f = new FLFormSearchDB("pedidoscliparciales");

	//debug("cursor.action(): "+this.cursor().action());

	var curPedParcial = f.cursor();
	if(this.cursor().action() == "em_pedidoscliparciales") {
		f.cursor().setAction("em_pedidoscliparciales");
	}
	var mF = "pedidoscli.idpedido = '" + idPedido + "'";
	curPedParcial.select(mF);
	curPedParcial.first();
	f.setMainWidget();
	fPC_.idAlbaranC_ = undefined;		
	idPedido = f.exec("idpedido");	
	if(!idPedido){
		fPC_.silent_ = false;
		return false;
	}
	var acpt = f.accepted();
  	if (!acpt) {
  		return false;
  	}
	if(!fPC_.idAlbaranC_ || fPC_.idAlbaranC_ == 0 || fPC_.idAlbaranC_ == "" || fPC_.idAlbaranC_ == undefined){
		//formUI.ponMsgWarn(sys.translate("Hubo un error en la generaci�n del albar�n"));
		fPC_.silent_ = false;
	} else {
		if(!AQUtil.execSql("UPDATE albaranescli SET em_idpedalbcdb = " + oParamPed["idPedAlbCDB"] + " WHERE idalbaran = " + fPC_.idAlbaranC_)) {
			fPC_.silent_ = false;
			return false;
		}
	}	
	return fPC_.idAlbaranC_;
}

function oficial_generarAlbaran(oParamPed)
{
	var _i = this.iface;
	var idPedAlbCDB = oParamPed["idPedAlbCDB"];
	var fPC_ = formpedidoscli.iface;

	fPC_.silent_ = true;

	var curPedido = new FLSqlCursor("pedidoscli");
	curPedido.select("idpedido = " + _i.oPedido_["idpedido"]);
	if (!curPedido.first()) {
		fPC_.silent_ = false;
		return false;
	}
	var where = "idpedido = " + _i.oPedido_["idpedido"];


	if (!fPC_.curAlbaran) {
		fPC_.curAlbaran = new FLSqlCursor("albaranescli");
	}	

	fPC_.curAlbaran.setModeAccess(fPC_.curAlbaran.Insert);
	fPC_.curAlbaran.refreshBuffer();


    const ahora = (new Date).toString()
    const masDatos = {
        "hora": ahora.right(8),
        "fecha": ahora.left(10)
    }        
    const masDatosRevisados = flfacturac.iface.revisaDatosNuevoDoc(masDatos, curPedido)
    if (!masDatosRevisados) {
        return false
    }   

	
	if (!fPC_.datosAlbaran(curPedido, where, masDatosRevisados)) {
		fPC_.silent_ = false;
		return false;
	}
	if (!_i.datosAlbaranCDB(oParamPed)) {
		fPC_.silent_ = false;
		return false;
	}
	if (!fPC_.curAlbaran.commitBuffer()) {
		fPC_.silent_ = false;
		return false;
	}

	var idAlbaran = fPC_.curAlbaran.valueBuffer("idalbaran");

	if (this.cursor().action() != "em_pedidoscliparciales") {		
		if(!AQUtil.execSql("UPDATE lineaspedidoscli SET canalbaran = cantidad-totalenalbaran  WHERE idpedido = " + _i.oPedido_["idpedido"])) {
			fPC_.silent_ = false;
			return false;
		}
	} else {
		//vamos fila a fila mirando la cantidad maxima
		var canAlbaran = 0;
		var q = new AQSqlQuery;	
		q.setSelect("l.idlinea, l.cantidad-l.totalenalbaran, a.nostock");
		q.setFrom("lineaspedidoscli l LEFT OUTER JOIN articulos a ON a.referencia = l.referencia");
		q.setWhere("l.idpedido = " + _i.oPedido_["idpedido"]); 			
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			var idLinea = q.value("l.idlinea");	
			var max = q.value("l.cantidad-l.totalenalbaran");
			if(!q.value("a.nostock")) {	
				var maxL = formem_pedidosptes.iface.pub_dameMaximoLineaPedido(idLinea);
				if(!maxL || maxL == "") {
					maxL = 0;
				}				
				if(max > maxL) {
					max = maxL;
				}			
				
			}
			if(!AQUtil.execSql("UPDATE lineaspedidoscli SET canalbaran = " + max + "  WHERE idlinea = " + idLinea)) {
				fPC_.silent_ = false;
				return false;
			}
		}	
	}


	if (!fPC_.copiaLineasParcial(_i.oPedido_["idpedido"], idAlbaran)) {
		fPC_.silent_ = false;
		return false;
	}

	fPC_.curAlbaran.select("idalbaran = " + idAlbaran);
	if (fPC_.curAlbaran.first()) {
		fPC_.curAlbaran.setModeAccess(fPC_.curAlbaran.Edit);
		fPC_.curAlbaran.refreshBuffer();
		fPC_.curAlbaran.setValueBuffer("em_idpedalbcdb",idPedAlbCDB);
		
		if (!fPC_.totalesAlbaran()) {
			fPC_.silent_ = false;
			return false;
		}
		
		if (!fPC_.curAlbaran.commitBuffer()) {
			fPC_.silent_ = false;
			return false;
		}
	}
	fPC_.silent_ = false;
	return idAlbaran;
}

function oficial_datosAlbaranCDB(oParamPed)
{
	var _i = this.iface;
	var fPC_ = formpedidoscli.iface;
	if(oParamPed["chkUsarAgencia"] && oParamPed["leAgencia"] && oParamPed["leAgencia"] != "") {
	 	fPC_.curAlbaran.setValueBuffer("codagencia", oParamPed["leAgencia"]);
	}	

	if(oParamPed["leBultos"] && oParamPed["leBultos"] != "") {
		fPC_.curAlbaran.setValueBuffer("bultos", oParamPed["leBultos"]);
	} else {
		fPC_.curAlbaran.setValueBuffer("bultos",0);
	}
	if(oParamPed["lePesoBruto"] && oParamPed["lePesoBruto"] != "") {
		fPC_.curAlbaran.setValueBuffer("pesobruto",oParamPed["lePesoBruto"]);
	} else {
		fPC_.curAlbaran.setValueBuffer("pesobruto",0);
	}
	if(oParamPed["leVolumen"] && oParamPed["leVolumen"] != "") {
		fPC_.curAlbaran.setValueBuffer("volumen", oParamPed["leVolumen"]);
	} else {
		fPC_.curAlbaran.setValueBuffer("volumen", 0);
	}	
	if(oParamPed["leClaseM"] && oParamPed["leClaseM"] != "") {
		fPC_.curAlbaran.setValueBuffer("desbultos", oParamPed["leClaseM"]);
	} else {
		fPC_.curAlbaran.setNull("desbultos");
	}
	if(oParamPed["txtObsTrans"] && oParamPed["txtObsTrans"] != "") {
		fPC_.curAlbaran.setValueBuffer("obstransporte", oParamPed["txtObsTrans"]);
	} else {
		fPC_.curAlbaran.setNull("obstransporte");
	}
	return true;
}


function oficial_imprimirSegunCheck(idAlbaran)
{
	
	var _i = this.iface;
	var oParamImp = new Object;
	oParamImp["chkImpAlbaran"] = this.child("chkImpAlbaran").checked;
	oParamImp["chkImpAlbaranRep"] = this.child("chkImpAlbaranRep").checked;
	oParamImp["chkImpAlbTrans"] = this.child("chkImpAlbTrans").checked;
	oParamImp["chkImpAlbTransRep"] = this.child("chkImpAlbTransRep").checked;
	oParamImp["chkImpEtiquetas"] = this.child("chkImpEtiquetas").checked;
	oParamImp["chkImpEtiquetasRep"] = this.child("chkImpEtiquetasRep").checked;
	oParamImp["codAlbaran"] = AQUtil.sqlSelect("albaranescli","codigo","idalbaran = " + idAlbaran);

	_i.imprimeAlbaran(oParamImp);
}



function oficial_imprimeAlbaran(oParamImp)
{
	var _i = this.iface;

	var chkA1 = oParamImp["chkImpAlbaran"];	
	var chkB1 = oParamImp["chkImpAlbaranRep"];
	var chkA2 = oParamImp["chkImpAlbTrans"];
	var chkB2 = oParamImp["chkImpAlbTransRep"];
	var chkA3 = oParamImp["chkImpEtiquetas"];
	var chkB3 = oParamImp["chkImpEtiquetasRep"];

	if((!chkA1 || chkA1 == "") && (!chkB1 || chkB1 == "") && (!chkA2 || chkA2 == "") && (!chkB2 || chkB2 == "") && (!chkA3 || chkA3 == "") && (!chkB3 || chkB3 == "")) {
		return true;
	}


	var codAlbaran = oParamImp["codAlbaran"];
	var idAlbaranComp = AQUtil.sqlSelect("albaranescli", "idalbarancomp", "codigo = '" + codAlbaran + "'");


	var primero = true;
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "i_albaranescli";
	oParam.whereFijo = "NOT (lineasalbaranescli.candistribuida <> 0 AND lineasalbaranescli.canfactura = 0 AND lineasalbaranescli.tipoconcepto = 'Producto')";
	oParam.rptViewer = new FLReportViewer();


	if (_i.curImprimir_) {				
		_i.curImprimir_ = undefined;
	}
	
	_i.curImprimir_ = new FLSqlCursor("i_albaranescli");
	_i.curImprimir_.setModeAccess(_i.curImprimir_.Insert);
	_i.curImprimir_.refreshBuffer();
	_i.curImprimir_.setValueBuffer("descripcion", "temp");
	_i.curImprimir_.setValueBuffer("d_albaranescli_codigo", codAlbaran);
	_i.curImprimir_.setValueBuffer("h_albaranescli_codigo", codAlbaran);
	var nombreCx;
	if (idAlbaranComp) {
		if (!flfacturac.iface.pub_conectarDA()) {
			return;
		}
		nombreCx = flfacturac.iface.pub_conexionDA();
	}
	var numeroAlbaranes = AQUtil.sqlSelect("albaranescli inner join clientes on clientes.codcliente = albaranescli.codcliente","clientes.copiasalbaran","albaranescli.codigo = '" + codAlbaran + "'","albaranescli");
	if(!numeroAlbaranes || numeroAlbaranes == "") {

		numeroAlbaranes = 2;
	}
	
	if (chkA1) {
		for (var i = 0; i < numeroAlbaranes; i++) {
			flfactinfo.iface.pub_ponerMembrete(true);
			oParam.append = !primero;
			oParam.pageBreak = !primero;
			oParam.display = i == numeroAlbaranes-1 && !(idAlbaranComp && chkB1.checked); //!((idAlbaranComp && chkB1.checked) || chkA2.checked || (idAlbaranComp && chkB2.checked));
			oParam.nombreCx = undefined;
			flfactinfo.iface.pub_lanzaInforme(_i.curImprimir_, oParam);
			primero = false;
		}
	}
	if (idAlbaranComp && chkB1) {
		for (var i = 0; i < numeroAlbaranes; i++) {
			flfactinfo.iface.pub_ponerMembrete(false);
			oParam.append = !primero;
			oParam.pageBreak = !primero;
			oParam.display = i == numeroAlbaranes-1; //!(chkA2.checked || (idAlbaranComp && chkB2.checked));
			oParam.nombreCx = nombreCx;
			flfactinfo.iface.pub_lanzaInforme(_i.curImprimir_, oParam);
			primero = false;
		}
	}
	primero = true;
	oParam.rptViewer = undefined;
	oParam.rptViewer = new FLReportViewer();
	oParam.nombreInforme = "i_albaranescli_trans";
	oParam.nombreReport = "i_albaranescli_trans";
	oParam.whereFijo = undefined;
	if (chkA2) {
		oParam.append = !primero;
		oParam.pageBreak = false; //!primero;
		oParam.display = !(idAlbaranComp && chkB2);
		oParam.nombreCx = undefined;
		flfactinfo.iface.pub_lanzaInforme(_i.curImprimir_, oParam);
		primero = false;
	}
	if (idAlbaranComp && chkB2) {
		flfactinfo.iface.pub_ponerMembrete(false);
		oParam.append = !primero;
		oParam.pageBreak = true; //!primero;
		oParam.display = true;
		oParam.nombreCx = nombreCx;
		flfactinfo.iface.pub_lanzaInforme(_i.curImprimir_, oParam);
		primero = false;
	}
	flfactinfo.iface.pub_ponerMembrete(false);
	oParamP = new Object;
	oParamP.rptViewer = new FLReportViewer();
	if (chkA3) {
		oParamP.append = false;
		oParamP.pageBreak = true;
		oParamP.display = !(idAlbaranComp && chkB3);
		var q = new FLSqlQuery("i_eti_albaranescli");
		q.setWhere("albaranescli.codigo = '" + codAlbaran + "'");
		formi_albaranescli.iface.pub_lanzaEtiquetas(q, oParamP);
	}
	if (idAlbaranComp && chkB3) {
		oParamP.append = chkA3;
		oParamP.pageBreak = true;
		oParamP.display = true;
		var q = new FLSqlQuery("i_eti_albaranescli", nombreCx);
		q.setWhere("albaranescli.idalbaran = " + idAlbaranComp);
		formi_albaranescli.iface.pub_lanzaEtiquetas(q, oParamP);
	}
}

function oficial_cargaDatosAlbaranes()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var obj = _i.dameTablaAlbaranes();	
	var miTabla = obj.miTabla;
	var q = new FLSqlQuery;
	q.setSelect(_i.dameSelectAlbarnes());		
	q.setFrom("v_albaranescdb");
	q.setWhere("em_idpedalbcdb = " + formpedidoscli.iface.idPedAlbCDB_);
	q.setOrderBy("v_albaranescdb.idalbaran DESC");		
	miTabla.setQuery(q);
	var tamanios = _i.dameTamaniosTabla();
	for (var i = 0; i < tamanios.length; i++) {
		miTabla.setColumnWidth(tamanios[i][0], tamanios[i][1]);
	}
	miTabla.setReadOnly(true);	
	miTabla.refresh();
	return true;

}

function oficial_dameTablaAlbaranes()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblAlbaranes_ ? true : false;
	obj.tabla = this.child("mte_tblExt_albaranes");
	obj.gb = this.child("mte_gbExt_albaranes");

	if (!obj.creado) {
		_i.tblAlbaranes_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblAlbaranes_.checkColumnEnabled(false);
		_i.tblAlbaranes_.setAliasCheckColumn("Sel.");
		_i.tblAlbaranes_.setSearchEnabled(true);
		_i.tblAlbaranes_.setOrderDesc(true);
		_i.tblAlbaranes_.setDoubleClickedFunction("formem_genalbarancdb.iface.editarLineasAlbParc");
	}
	
	obj.miTabla = _i.tblAlbaranes_;

	return obj;
}

function oficial_dameSelectAlbarnes()
{
	var sSelect = "v_albaranescdb.idalbaran,v_albaranescdb.codpedido,v_albaranescdb.em_coddropshipping,v_albaranescdb.pedidoprivalia,v_albaranescdb.servido,v_albaranescdb.emcatservicio, v_albaranescdb.porcserv,v_albaranescdb.codalbaran ,v_albaranescdb.nombrecliente,v_albaranescdb.docexterno,v_albaranescdb.descripciondir,v_albaranescdb.tracking,v_albaranescdb.codpostal,v_albaranescdb.ciudad,v_albaranescdb.codagencia,v_albaranescdb.bultos,v_albaranescdb.desbultos,v_albaranescdb.volumen,v_albaranescdb.observaciones,v_albaranescdb.obstransporte,v_albaranescdb.ptefactura,v_albaranescdb.fecha,v_albaranescdb.cifnif,v_albaranescdb.total,v_albaranescdb.codcliente,v_albaranescdb.coddivisa,v_albaranescdb.numero,v_albaranescdb.codserie,v_albaranescdb.neto,v_albaranescdb.porcomision,v_albaranescdb.totaleuros,v_albaranescdb.totaliva,v_albaranescdb.irpf,v_albaranescdb.totalirpf,v_albaranescdb.totalrecargo,v_albaranescdb.codpago,v_albaranescdb.em_codpago,v_albaranescdb.codagente,v_albaranescdb.codalmacen,v_albaranescdb.codalmadeposito,v_albaranescdb.tipodeposito,v_albaranescdb.coddir,v_albaranescdb.direccion,v_albaranescdb.provincia,v_albaranescdb.apartado,v_albaranescdb.codpais,v_albaranescdb.codejercicio,v_albaranescdb.tasaconv,v_albaranescdb.recfinanciero,v_albaranescdb.netosindtoesp,v_albaranescdb.pordtoesp,v_albaranescdb.dtoesp,v_albaranescdb.idintrastat,v_albaranescdb.codprovincia,v_albaranescdb.codcondicionentrega,v_albaranescdb.codnaturaleza,v_albaranescdb.codmodotransporte,v_albaranescdb.codpuerto,v_albaranescdb.codregimen,v_albaranescdb.nointrastat,v_albaranescdb.hora,v_albaranescdb.pesobruto,v_albaranescdb.pesoneto,v_albaranescdb.palets,v_albaranescdb.em_codtipoemb,v_albaranescdb.valorado,v_albaranescdb.departamento,v_albaranescdb.codclientefac,v_albaranescdb.idalbarancomp,v_albaranescdb.codliquidacion,v_albaranescdb.incoterm,v_albaranescdb.pobincoterm,v_albaranescdb.fechavalor,v_albaranescdb.tipoportes,v_albaranescdb.codgrupoivaneg,v_albaranescdb.ediactivo,v_albaranescdb.fechatrasedi,v_albaranescdb.estadogit,v_albaranescdb.codigogit,v_albaranescdb.codtipoembalajepaleedi,v_albaranescdb.deabono,v_albaranescdb.bultosreparto,v_albaranescdb.pesobrutoreparto,v_albaranescdb.volumenreparto,v_albaranescdb.idusuarioalta,v_albaranescdb.fechaalta,v_albaranescdb.horaalta,v_albaranescdb.idusuariomod,v_albaranescdb.fechamod,v_albaranescdb.em_idimpnoctalia,v_albaranescdb.em_idalbaranabono,v_albaranescdb.em_codigoabono,v_albaranescdb.emcodenviodrop,v_albaranescdb.horamod,v_albaranescdb.em_autorizadocostes,v_albaranescdb.em_estadocostes,v_albaranescdb.em_politicacostes,v_albaranescdb.em_motivocostes,v_albaranescdb.em_globalneto,v_albaranescdb.em_globalcostes,v_albaranescdb.em_globalmargenes,v_albaranescdb.em_netovscostes,v_albaranescdb.em_netovsmargenes,v_albaranescdb.em_idpedalbcdb,v_albaranescdb.idpedido";

	return sSelect;

}

function oficial_editarLineasAlbParc()
{
	var _i = this.iface;
	var cursor = _i.tblAlbaranes_.dameCursor();
	var idPedido = cursor.valueBuffer("idpedido");
	var idAlbaran = cursor.valueBuffer("idalbaran");
	_i.abreGenerarParcial(idPedido, idAlbaran);
	_i.tblAlbaranes_.refreshCurrentRow();
	formpedidoscliparciales.iface.idAlbaran_ = false;	
}

function oficial_toolButtonEdit_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	
	_i.accionCursorExterno("edit");
}

function oficial_toolButtonDelete_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	_i.accionCursorExterno("del");
}

function oficial_toolButtonZoom_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	_i.accionCursorExterno("browse");
}

function oficial_tbnAbrirCerrar_clicked() 
{
	var _i = this.iface;
	
	if(this.cursor().action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	if(!_i.tblAlbaranes_) {
		return false;
	}
	var cursor = _i.tblAlbaranes_.dameCursor();

	var idPedido = cursor.valueBuffer("idpedido");
	if(!idPedido) {
		formUI.ponMsgWarn(sys.translate("No hay ning�n registro seleccionado"));		
		return false;
	}

	var cerrar = true;
	var res = 0;
	if(AQUtil.sqlSelect("lineaspedidoscli","cerrada","idpedido = " + idPedido + " AND cerrada")) {
		cerrar = false;
		res = formUI.preguntaMsg(sys.translate("El pedido seleccionado tiene l�neas cerradas.\n�Seguro que desea abrirlas?"), "info", this, MessageBox.Yes, MessageBox.No);	
	} else {
		if(!AQUtil.sqlSelect("pedidoscli","editable","idpedido = " + idPedido)) {
			formUI.ponMsgWarn(sys.translate("El pedido ya ha sido servido completamente."));			
			return false;
		}
		res = formUI.preguntaMsg(sys.translate("Se va a cerrar el pedido y no podr� terminar de servirse.\n�Desea continuar?"), "info", this, MessageBox.Yes, MessageBox.No);	
	}
	if(res != MessageBox.Yes) {
		return;
	}	
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al cerrar el pedido");
	oParam.idPedido = idPedido;	
	oParam.cerrar = cerrar;	
	var f = new Function("oParam", "return formpedidoscli.iface.trAbrirCerrarPedido(oParam)");	
	if (!sys.runTransaction(f, oParam)) {	
		formUI.ponMsgWarn(sys.translate("Se ha producido un error al cerrar el pedido"));			
		return false;
	}
	_i.tblAlbaranes_.refresh();	
}

function oficial_accionCursorExterno(accion)
{
	var cursor = this.cursor();
	var _i = this.iface;
	if(!_i.tblAlbaranes_) {
		return false;
	}

	var curAlbaran = _i.tblAlbaranes_.dameCursor(); 
	if(!curAlbaran  ||	!curAlbaran.isValid()) {
		_i.tblAlbaranes_.refresh();	
		return true;
	}
	var idAlbaran = curAlbaran.valueBuffer("idalbaran");
	var idPedido = curAlbaran.valueBuffer("idpedido");
	if(!idPedido || idPedido)
	if (_i.curAlb_) {		
		disconnect(_i.curAlb_, "commited()", _i, "curAlb_bufferCommited");
		_i.curAlb_ = undefined;
	}

	_i.curAlb_ = new FLSqlCursor("albaranescli");
	_i.curAlb_.setAction("albaranescli");		
	_i.curAlb_.select("idalbaran = " + idAlbaran);
	if (!_i.curAlb_.first()) {		
		_i.tblAlbaranes_.refresh();	
		return false;
	}


	if(accion == "edit") {		
		connect(_i.curAlb_, "commited()", _i, "curAlb_bufferCommited");			
		_i.curAlb_.editRecord();	

	} else if(accion == "browse") {

		_i.curAlb_.browseRecord();

	} else if(accion == "del") {
		_i.curAlb_.setModeAccess(_i.curAlb_.Del);
 		_i.curAlb_.refreshBuffer(); 
 		if(!_i.curAlb_.commitBuffer()) {
 			_i.tblAlbaranes_.refresh();	
 			return false;
 		}
		
		if(!AQUtil.sqlUpdate("lineaspedidoscli","cerrada",false,"idpedido = " + idPedido + " AND cerrada")) {
			formUI.ponMsgWarn(sys.translate("Error al cerrar l�nea del pedido"));
			return false;
		}
			
		if (!flfacturac.iface.pub_actualizarEstadoPedidoCli(idPedido)) {
			return false;
		}	



 		if (cursor.action() == "em_pedidoscliparciales") {	

	 		//var idStocks = "";
	 		var salir = false;
 			var q = new AQSqlQuery;	
			q.setSelect("s.idstock");
			q.setFrom("lineaspedidoscli l INNER JOIN pedidoscli p on l.idpedido = p.idpedido INNER JOIN stocks s ON l.referencia = s.referencia AND p.codalmacen = s.codalmacen");
			q.setWhere("l.idpedido = " + idPedido);			
			if (!q.exec()){
				return;
			}  
			while(q.next())
			{
				while(!salir) {
					debug("esperando a stockdiferido");
					if(!AQUtil.sqlSelect("stocksptes","idstock","idstock = " + q.value("s.idstock"))) {
						salir = true;
					}
				}				
			}	
			if (!AQSql.del("em_pedidospedptes", "idpedido = " + idPedido)) {
				return false;
			}
			formem_pedidosptes.iface.cargaDatos(false, idPedido);			
			if (!_i.calculaEstadoPedidos(idPedido)) {			
				return false;
			}	
			if (!AQSql.del("em_pedidospedptes", "idpedido = " + idPedido)) {
				return false;
			}
			formem_pedidosptes.iface.cargaDatos(false, idPedido);			
			if (!_i.calculaEstadoPedidos(idPedido)) {			
				return false;
			}
		}
 		_i.tblAlbaranes_.refresh();	
	}
}

function oficial_refrescaTablaAlb()
{
	var _i = this.iface;
	_i.tblAlbaranes_.refresh();	
}

function oficial_curAlb_bufferCommited()
{
	var _i = this.iface;
	_i.tblAlbaranes_.refreshCurrentRow();

}

function oficial_toolButtonPrint_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	if(!_i.tblAlbaranes_) {
		return false;
	}
	var codAlbaran = _i.tblAlbaranes_.dameCursor().valueBuffer("codalbaran");
	formalbaranescli.iface.imprimir(codAlbaran);
}

function oficial_tbnImprimirMembrete_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	if(!_i.tblAlbaranes_) {
		return false;
	}
	var codAlbaran = _i.tblAlbaranes_.dameCursor().valueBuffer("codalbaran");
	flfactinfo.iface.pub_ponerMembrete(true);
	formalbaranescli.iface.imprimir(codAlbaran);  
	flfactinfo.iface.pub_ponerMembrete(false);
	
}

function oficial_tbnAlbaranTrans_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	if(!_i.tblAlbaranes_) {
		return false;
	}
	var codAlbaran = _i.tblAlbaranes_.dameCursor().valueBuffer("codalbaran");
	var idAlbaran = _i.tblAlbaranes_.dameCursor().valueBuffer("idalbaran");
	formalbaranescli.iface.imprimirAlbaranTrans(codAlbaran, idAlbaran);	
}

function oficial_tbnEtiquetas_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	if(!_i.tblAlbaranes_) {
		return false;
	}
	var idAlbaran = _i.tblAlbaranes_.dameCursor().valueBuffer("idalbaran");
	formalbaranescli.iface.imprimirEtiquetasAlbaran(idAlbaran)
}

function oficial_tbnDistribuyeEjercicio_clicked() 
{

	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	if(!_i.tblAlbaranes_) {
		return false;
	}
	//var  curAlbaran = _i.tblAlbaranes_.dameCursor();
	var idAlbaran = _i.tblAlbaranes_.dameCursor().valueBuffer("idalbaran");

	var curAlbaran = new FLSqlCursor("albaranescli");
	curAlbaran.select("idalbaran = " + idAlbaran);
	if (!curAlbaran.first()) {
		return; 
	}
	if (!formalbaranescli.iface.distribuyeEjercicio(curAlbaran)) {
		return false;
	}

	_i.tblAlbaranes_.refresh();	
	return true;
}

function oficial_pbnLineasPtes_clicked() 
{

	var _i = this.iface;
	
	if(this.cursor().action() == "em_pedidoscliparciales") {
		if(!formem_pedidosptes.iface.compruebaUsuario("emitirAlbaranCDB")) { 
			return false;	
		}
		if(!formem_pedidosptes.iface.compruebaFechaApertura("emitirAlbaranCDB")) {
			return false;
		}
	}
	if(!_i.tblAlbaranes_) {
		return false;
	}
	var cursor = _i.tblAlbaranes_.dameCursor();
	var idPedido = cursor.valueBuffer("idpedido");
	var idAlbaran = -1;
	_i.abreGenerarParcial(idPedido, idAlbaran);
	formpedidoscliparciales.iface.idAlbaran_ = false;
	_i.tblAlbaranes_.refresh();		

}

function oficial_abreGenerarParcial(idPedido, idAlbaran)
{
	var _i = this.iface;
	var fPC_ = formpedidoscli.iface;
	_i.oPedido_ = false;
	fPC_.silent_ = true;
	
	var omitirAvisosCostes = this.child("chkOmitirAvisosCos").checked;

	if(omitirAvisosCostes) {
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_= true;
	} else {
		formRecordpresupuestoscli.iface.ignorarAvisosCostes_= false;
	}
	formpedidoscliparciales.iface.idAlbaran_ = idAlbaran;
	var oParamPed = new Object;
	oParamPed["idpedido"] = idPedido;
	oParamPed["idPedAlbCDB"] = formpedidoscli.iface.idPedAlbCDB_;
	
	var q = new AQSqlQuery;	
	q.setSelect("p.codigo,p.codcliente,p.idpedido,p.emcatservicio");
	q.setFrom("pedidoscli p");
	q.setWhere("p.idpedido = " + idPedido);	
	if (!q.exec()){
		return false;
	}  
	if(!q.first())
	{	
		return false;	
	}		

	_i.oPedido_ = new Object;
	_i.oPedido_["codigo"] = q.value("p.codigo");
	_i.oPedido_["codcliente"] = q.value("p.codcliente");
	_i.oPedido_["idpedido"] = q.value("p.idpedido");
	_i.oPedido_["emcatservicio"] = q.value("p.emcatservicio");	

	if(!idAlbaran) {		
		if(!_i.guardaCamposPedido()) {
			return false;
		}
	}


	idAlbaran = _i.generarAlbaranParcial(oParamPed);
	fPC_.silent_ = false;

	if(idAlbaran) {
		_i.imprimirSegunCheck(idAlbaran);
	}
	formRecordpresupuestoscli.iface.ignorarAvisosCostes_= false;
	formpedidoscliparciales.iface.idAlbaran_ = false;
}	

function oficial_guardaCamposPedido()
{

	var _i = this.iface;
	var idPedido = _i.oPedido_["idpedido"]	
	var codAgencia = this.child("leAgencia").text;
	if(!codAgencia || codAgencia == "") {
		codAgencia = "";
	} else {
		if(!AQUtil.sqlSelect("proveedores","codproveedor","codproveedor = '" + codAgencia + "'")) {
			formUI.ponMsgWarn(sys.translate("La agencia %1 no existe, no se generar� ning�n albar�n.").arg(codAgencia));
			return false;
		}		
	}
	var bultos = this.child("leBultos").text;
	if(!bultos || bultos == "") {
		bultos = 0;
	}
	if(isNaN(bultos)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo bultos debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}

	var pesoBruto = this.child("lePesoBruto").text;
	if(!pesoBruto || pesoBruto == "") {
		pesoBruto = 0;
	}
	if(isNaN(pesoBruto)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo peso bruto debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}
	var volumen = this.child("leVolumen").text;
	if(!volumen || volumen == "") {
		volumen = 0;
	}
	if(isNaN(volumen)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo volumen debe de ser num�rico, no se generar� ning�n albar�n."));
		return false;
	}
	var desBultos = this.child("leClaseM").text;
	if(!desBultos || desBultos == "") {
		desBultos = "";
	}

	var observaciones = this.child("txtObsTrans").text;
	if(!observaciones || observaciones == "") {
		observaciones = "";
	}
	
	var camposSET = "bultos = " + bultos + ", pesobruto = " + pesoBruto + ", volumen = " + volumen + ", desbultos = '" + desBultos + "', obstransporte = '" + observaciones + "'";

	if(this.child("chkUsarAgencia").checked && codAgencia && codAgencia != "") {
		camposSET = camposSET + ", codagencia = '" + codAgencia + "'";
	} else {
		camposSET = camposSET + ", codagencia = NULL";
	}
	if(!AQUtil.execSql("UPDATE pedidoscli SET " + camposSET + " WHERE idpedido = " + idPedido)) {
		return false;
	}
	return true;

}

function oficial_leAgencia_lostFocus()
{
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}
	var codAgencia = this.child("leAgencia").text;
	if(!codAgencia || codAgencia == "") {
		this.child("leDescAgencia").text = "";
	} else {
		if(!AQUtil.sqlSelect("proveedores","codproveedor","codproveedor = '" + codAgencia + "'")) {
			formUI.ponMsgWarn(sys.translate("La agencia %1 no existe, por favor indique un valor correcto.").arg(codAgencia));
			this.child("leAgencia").text = "";
			this.child("leAgencia").setFocus();
			return false;
		}
		this.child("leDescAgencia").text = AQUtil.sqlSelect("proveedores","nombre","codproveedor = '" + codAgencia + "'");
	}
	return true;
}

function oficial_leBultos_lostFocus()
{
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}
	var bultos = this.child("leBultos").text;
	if(!bultos || bultos == "") {
		bultos = 0;
	}
	if(isNaN(bultos)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo bultos debe de ser num�rico, por favor indique un valor correcto.").arg(bultos));
		this.child("leBultos").text = "";
		this.child("leBultos").setFocus();
		return false;
	}
	return true;
}

function oficial_lePesoBruto_lostFocus()
{
	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}
	var pesoBruto = this.child("lePesoBruto").text;
	if(!pesoBruto || pesoBruto == "") {
		bultos = 0;
	}
	if(isNaN(pesoBruto)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo peso bruto debe de ser num�rico, por favor indique un valor correcto.").arg(pesoBruto));
		this.child("lePesoBruto").text = "";
		this.child("lePesoBruto").setFocus();
		return false;
	}
	return true;
}

function oficial_leVolumen_lostFocus()
{

	var cursor = this.cursor();
	if(cursor.action() == "em_pedidoscliparciales") {
		formem_pedidosptes.iface.pintaCargaActual(this);
	}
	var volumen = this.child("leVolumen").text;
	if(!volumen || volumen == "") {
		volumen = 0;
	}
	if(isNaN(volumen)) {
		formUI.ponMsgWarn(sys.translate("El valor del campo volumen debe de ser num�rico, por favor indique un valor correcto.").arg(volumen));
		this.child("leVolumen").text = "";
		this.child("leVolumen").setFocus();
		return false;
	}
	return true;
}

function oficial_dameTamaniosTabla()
{
	var tamanios = [];	
	tamanios.push(["v_albaranescdb.idalbaran", 70]);
	tamanios.push(["v_albaranescdb.codpedido", 100]);
	tamanios.push(["v_albaranescdb.em_coddropshipping", 70]);
	tamanios.push(["v_albaranescdb.pedidoprivalia", 120]);
	tamanios.push(["v_albaranescdb.servido", 50]);	
	tamanios.push(["v_albaranescdb.porcserv", 50]);
	tamanios.push(["v_albaranescdb.codalbaran", 100]);
	tamanios.push(["v_albaranescdb.nombrecliente", 150]);	
	tamanios.push(["v_albaranescdb.docexterno", 150]);
	tamanios.push(["v_albaranescdb.descripciondir", 150]);
	tamanios.push(["v_albaranescdb.tracking", 150]);
	tamanios.push(["v_albaranescdb.codpostal", 50]);
	tamanios.push(["v_albaranescdb.ciudad", 100]);
	tamanios.push(["v_albaranescdb.codagencia", 60]);
	tamanios.push(["v_albaranescdb.bultos", 50]);
	tamanios.push(["v_albaranescdb.desbultos", 70]);
	tamanios.push(["v_albaranescdb.volumen", 60]);
	tamanios.push(["v_albaranescdb.observaciones", 150]);
	tamanios.push(["v_albaranescdb.obstransporte", 150]);

	return tamanios;	
}

function oficial_recargaPedido()
{
	var _i = this.iface;
	if (!_i.oPedido_) {
		return;
	}
	var idPedido = _i.oPedido_["idpedido"];

	var codAlbaran = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran", "a.codigo", "l.idpedido = " + idPedido + " ORDER BY a.idalbaran DESC", "albaranescli");
	if (codAlbaran) {
		var catServicio = _i.oPedido_["emcatservicio"];
		if (catServicio && catServicio > 0) {
			var curAlbaran = new FLSqlCursor("albaranescli");
			curAlbaran.select("codigo = '" + codAlbaran + "'");
			if (!curAlbaran.first()) {
				return;
			}
			formalbaranescli.iface.pub_distribuyeEjercicio(curAlbaran);
		}
	}
	/// Recargamos todos los pedidos del cliente porque puede haberse servido una cantidad reservada para otros pedidos del mismo cliente
	/*var q = new AQSqlQuery;
	q.setSelect("idpedido");
	q.setFrom("em_pedidospedptes");
	q.setWhere("idpedido = " + idPedido);
	if (!q.exec()) {
		return false;
	}
	var idPedidoCli;
	while (q.next()) {
		idPedidoCli = q.value("idpedido");
		if (!AQSql.del("em_pedidospedptes", "idpedido = " + idPedidoCli)) {
			return false;
		}
		formem_pedidosptes.iface.cargaDatos(false, idPedidoCli);
	}*/

	if (!AQSql.del("em_pedidospedptes", "idpedido = " + idPedido)) {
		return false;
	}
	formem_pedidosptes.iface.cargaDatos(false, idPedido);

	if (!_i.calculaEstadoPedidos(idPedido)) {
		return false;
	}	
}

/*function oficial_dimeSiHayQueRevisar(idPedido)
{

	var hayQueRevisar = false;

	var q = new AQSqlQuery;	
	q.setSelect("l.idlinea,l.cantidad-l.totalenalbaran");
	q.setFrom("lineaspedidoscli l INNER JOIN articulos a ON l.referencia = a.referencia");
	q.setWhere("l.idpedido = " + idPedido + " AND l.cantidad <> l.totalenalbaran AND NOT l.cerrada AND NOT a.nostock"); 				
	if (!q.exec()){
		return;
	}  
	while(q.next() && !hayQueRevisar)
	{		
		var idLinea = q.value("l.idlinea");
		var cantidadMaxima = q.value("l.cantidad-l.totalenalbaran"); 		
		var dameMaximoLinea = formem_pedidosptes.iface.pub_dameMaximoLineaPedido(idLinea);
		if(!dameMaximoLinea || dameMaximoLinea == "") {
			dameMaximoLinea = 0;
		}	
		if(cantidadMaxima > dameMaximoLinea) {
			hayQueRevisar = true;
		}		
	}	

	return hayQueRevisar;
}*/
function oficial_dimeSiHayQueRevisar(idPedido)
{
	//Devuelve 0 si no hay que revisar, 1 si hay que revisar y 2 si no se puede servir nada porque no hay ninguna l�nea que servir
	var res = 0;
	var hayQueRevisar = false;
	var revisarTodas = 0;
	var numLineas = 0;
	var q = new AQSqlQuery;	
	q.setSelect("l.idlinea,l.cantidad-l.totalenalbaran,a.nostock,l.cerrada");
	q.setFrom("lineaspedidoscli l INNER JOIN articulos a ON l.referencia = a.referencia");
	q.setWhere("l.idpedido = " + idPedido + " AND l.cantidad <> l.totalenalbaran"); 				
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{		
		numLineas++;
		var idLinea = q.value("l.idlinea");
		var cerrada = q.value("l.cerrada");
		var cantidadMaxima = q.value("l.cantidad-l.totalenalbaran");
		if(q.value("a.nostock")) {	
			if(cantidadMaxima == 0) {
				revisarTodas++;
			}	 	
		}		 		
		var dameMaximoLinea = formem_pedidosptes.iface.pub_dameMaximoLineaPedido(idLinea);
		if(!dameMaximoLinea || dameMaximoLinea == "") {
			dameMaximoLinea = 0;
		}	
		if(cantidadMaxima > dameMaximoLinea) {
			hayQueRevisar = true;
			revisarTodas++;
		}		
	}	

	if(hayQueRevisar && revisarTodas == numLineas) {
		res = 2
	} else if(hayQueRevisar) {
		res = 1;
	}

	return res;
}

function oficial_calculaEstadoPedidos(idPedido)
{
	var codCliente = AQUtil.sqlSelect("pedidoscli","codcliente","idpedido = " + idPedido);
	if (!AQUtil.execSql("update em_pedidospedptes set estado = 'PTE' where idpedido = " + idPedido)) {
		return false;
	}
	if (!AQUtil.execSql("update em_pedidospedptes set estado = 'PARCIAL' where idpedido in (select idpedido from em_lineaspedptes where idpedido = em_pedidospedptes.idpedido and enstock > 0) and idpedido = " + idPedido)) {
		return false;
	}
	if (!AQUtil.execSql("update em_pedidospedptes set estado = 'OK' where estado = 'PARCIAL' AND idpedido NOT in (select idpedido from em_lineaspedptes LEFT OUTER JOIN articulos ON articulos.referencia = em_lineaspedptes.referencia where idpedido = em_pedidospedptes.idpedido and enstock < pendiente and NOT articulos.nostock) and idpedido = " + idPedido)) {
		return false;
	}
	if (!AQUtil.execSql("update em_clientespedptes set estado = 'PTE' where codcliente = '" + codCliente + "'")) {
		return false;
	}
	if (!AQUtil.execSql("update em_clientespedptes set estado = 'OK' where codcliente IN (SELECT codcliente FROM em_pedidospedptes where codcliente = em_clientespedptes.codcliente AND estado IN ('OK', 'PARCIAL')) and codcliente = '" + codCliente + "'")) {
		return false;
	}	
	return true;
}
///// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
