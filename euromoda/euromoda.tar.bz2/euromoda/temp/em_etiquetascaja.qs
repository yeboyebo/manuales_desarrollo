/***************************************************************************
                 em_etiquetascaja.qs  -  description
                             -------------------
    begin                : mar mar 1 2022
    copyright            : (C) 2022 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() {
		return this.ctx.interna_init();
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
	function main() {
		this.ctx.interna_main();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblEtiquetas_;
	var REFERENCIA_,BARCODE_, DESCRIPCION_, TAMANO_, COLOR_, CANTIDAD_,CODSERIE_,ABREVLOG_,DESCDIBUJO_,DESCSUBFAM_;
	var eventWatcher_;
	function oficial( context ) { interna( context ); }
	function construirTabla() {
		return this.ctx.oficial_construirTabla();
	}
	function cargarTabla() {
		return this.ctx.oficial_cargarTabla();
	}
	function borrarTabla() {
		return this.ctx.oficial_borrarTabla();
	}
	function imprimir() {
		return this.ctx.oficial_imprimir();
	}
	function obtenerWhere() {
		return this.ctx.oficial_obtenerWhere();
	}
	function imprimeEtiquetasCaja(aEtiquetas, impresora) {
		return this.ctx.oficial_imprimeEtiquetasCaja(aEtiquetas, impresora);
	}
	function insertaFila(f, q) {
		return this.ctx.oficial_insertaFila(f, q);
	}
	function tbnCargaTexto_clicked() {
		return this.ctx.oficial_tbnCargaTexto_clicked();
	}
	function ledCantidad_returnPressed() {
		return this.ctx.oficial_ledCantidad_returnPressed();
	}
	function initEventFilter()  {
		this.ctx.oficial_initEventFilter();
	}
	function eventFilter(o, e)  {
		this.ctx.oficial_eventFilter(o, e);
	}
	function initWatch(obj) {
		this.ctx.oficial_initWatch(obj);
	}
	function finishWatch(obj)  {
		this.ctx.oficial_finishWatch(obj);
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

	
/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
	function pub_imprimeEtiquetasCaja(aEtiquetas, impresora) {
		return this.imprimeEtiquetasCaja(aEtiquetas, impresora);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	_i.tblEtiquetas_ = this.child("tblEtiquetas");
	
	connect(this.child("tbnBuscar"), "clicked()",_i, "cargarTabla()");
	connect(this.child("tbnBorrar"), "clicked()",_i, "borrarTabla()");
	connect(this.child("tbnImprimir"), "clicked()",_i, "imprimir()");
	connect(this.child("tbnCargaTexto"), "clicked()",_i, "tbnCargaTexto_clicked");
	connect(this.child("ledCantidad"), "returnPressed()",_i, "ledCantidad_returnPressed");
// 	connect(this.child("fdbReferencia").editor(), "returnPressed()", this.child("ledCantidad"), "selectAll()");
	
	if (this.child("fdbCantidad")) {
		this.child("fdbCantidad").close();
	}
	
	_i.construirTabla();
	
	_i.initEventFilter();
  _i.initWatch(this.mainWidget().child("fdbReferencia").editor());
}

function interna_validateForm()
{
	var cursor = this.cursor();
	var _i = this.iface;
	
	return true;
}

function interna_main()
{
	var _i = this.iface;
	
	var f = new FLFormSearchDB("em_etiquetascaja");
	var cursor = f.cursor();

	cursor.select();
	if (!cursor.first()) {
		cursor.setModeAccess(cursor.Insert);
	} else {
		cursor.setModeAccess(cursor.Edit);
	}
	f.setMainWidget();
	cursor.refreshBuffer();
	var id = f.exec("idetiqueta");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_construirTabla()
{
	var cabecera = "";
	var _i = this.iface;
	var cursor = this.cursor();
	var c = 0;
	
	_i.REFERENCIA_ = c++;
	cabecera += sys.translate( "Referencia") + "/";
	_i.DESCRIPCION_  = c++;
	cabecera += sys.translate( "Descripci�n") + "/";
	_i.TAMANO_ = c++;
	cabecera += sys.translate( "Tama�o") + "/";
	_i.COLOR_ = c++;
	cabecera += sys.translate( "Color") + "/";
	_i.CODSERIE_ = c++;
	cabecera += sys.translate( "Serie") + "/";
	_i.CANTIDAD_ = c++;
	cabecera += sys.translate( "Cantidad") + "/";
	_i.BARCODE_ = c++;
	cabecera += sys.translate( "Barcode") + "/";
	_i.ABREVLOG_ = c++;
	cabecera += sys.translate( "Abrev.Log") + "/";
	_i.DESCDIBUJO_ = c++;
	cabecera += sys.translate( "Dibujo") + "/";
	_i.DESCSUBFAM_ = c++;
	cabecera += sys.translate( "Subfamilia") + "/";
  
	_i.tblEtiquetas_.setNumCols(c);

	_i.tblEtiquetas_.setColumnWidth(_i.REFERENCIA_, 100);
	_i.tblEtiquetas_.setColumnWidth(_i.DESCRIPCION_, 400);
	_i.tblEtiquetas_.setColumnWidth(_i.TAMANO_, 60);
	_i.tblEtiquetas_.setColumnWidth(_i.COLOR_, 60);
	_i.tblEtiquetas_.setColumnWidth(_i.CODSERIE_, 60);
	_i.tblEtiquetas_.setColumnWidth(_i.CANTIDAD_, 60);
	_i.tblEtiquetas_.hideColumn(_i.BARCODE_);
	_i.tblEtiquetas_.hideColumn(_i.ABREVLOG_);
	_i.tblEtiquetas_.hideColumn(_i.DESCDIBUJO_);
	_i.tblEtiquetas_.hideColumn(_i.DESCSUBFAM_);

	_i.tblEtiquetas_.setColumnReadOnly(_i.REFERENCIA_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.DESCRIPCION_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.TAMANO_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.COLOR_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.CODSERIE_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.CANTIDAD_, false);
	_i.tblEtiquetas_.setColumnReadOnly(_i.BARCODE_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.ABREVLOG_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.DESCDIBUJO_, true);
	_i.tblEtiquetas_.setColumnReadOnly(_i.DESCSUBFAM_, true);



	_i.tblEtiquetas_.setColumnLabels("/", cabecera);
}

function oficial_cargarTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var where = _i.obtenerWhere();
 	debug("where " + where);
	var q = new FLSqlQuery;
	q.setSelect("a.descripcion, a.codtamanoem, a.referencia, a.codcolorem, a.codbarras, em_disenos.codseriediseno,sf.descripcion,sf.em_abreviaturalog,a.emdibujo");
	q.setFrom("articulos a LEFT OUTER JOIN em_dibujos ON a.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno LEFT OUTER JOIN subfamilias sf ON sf.codsubfamilia = a.codsubfamilia");
	q.setWhere(where + " order by a.referencia, a.descripcion, a.codtamanoem");
	debug(q.sql());
	q.setForwardOnly(true);
	if (!q.exec()) {
		return;
	}
	
	if(q.size() > 100){
		var res = MessageBox.warning(sys.translate("La b�squeda que va a lanzar ha encontrado %1 registros.\n�Desea continuar?").arg(q.size()),MessageBox.Yes, MessageBox.No, MessageBox.NoButton,"AbanQ");
		if(res != MessageBox.Yes) {
			return;
		}
	}
	
	var cantidad = parseInt(this.child("ledCantidad").text);//cursor.valueBuffer("cantidad"));
	if (!cantidad && cantidad != 0) {
		cantidad = 1;
	}
	var f = 0;
	var stockOrigen = 0;
	var stockDestino = 0;
	var reponerLinea = 0;
	var oArticulo = [];
	var p = 0;
	AQUtil.createProgressDialog(sys.translate("Insertando selecci�n de art�culos"), q.size());
	
	while (q.next()) {
		AQUtil.setProgress(p++);
		_i.insertaFila(f, q);
		f++;
	}
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	
}

function oficial_insertaFila(f, q)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var cantidad = parseInt(this.child("ledCantidad").text); //cursor.valueBuffer("cantidad"));
	if (!cantidad && cantidad != 0) {
		cantidad = 1;
	}
	_i.tblEtiquetas_.insertRows(f, 1);
	_i.tblEtiquetas_.setText(f, _i.REFERENCIA_, q.value("a.referencia"));
	_i.tblEtiquetas_.setText(f, _i.DESCRIPCION_, q.value("a.descripcion"));
	_i.tblEtiquetas_.setText(f, _i.TAMANO_, q.value("a.codtamanoem"));
	_i.tblEtiquetas_.setText(f, _i.COLOR_, q.value("a.codcolorem"));
	_i.tblEtiquetas_.setText(f, _i.CODSERIE_, q.value("em_disenos.codseriediseno"));
	_i.tblEtiquetas_.setText(f, _i.CANTIDAD_, cantidad);
	_i.tblEtiquetas_.setText(f, _i.BARCODE_, q.value("a.codbarras"));
	_i.tblEtiquetas_.setText(f, _i.ABREVLOG_, q.value("sf.em_abreviaturalog"));
	_i.tblEtiquetas_.setText(f, _i.DESCDIBUJO_, q.value("a.emdibujo"));
	_i.tblEtiquetas_.setText(f, _i.DESCSUBFAM_, q.value("sf.descripcion"));

}

function oficial_borrarTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	_i.tblEtiquetas_.removeRow(_i.tblEtiquetas_.currentRow());
// 	_i.tblEtiquetas_.clear();
}

function oficial_obtenerWhere()
{
	var cursor = this.cursor();
	var where = "1 = 1";
	
	var referencia = cursor.valueBuffer("referencia");
	if (referencia && referencia != "") {
		where += " AND a.referencia = '" + referencia + "'";
	}
		
	var codTamano = cursor.valueBuffer("codtamanoem");
	if (codTamano && codTamano != "") {
		where += " AND a.codtamanoem = '" + codTamano + "'";
	}
	
	var codColor = cursor.valueBuffer("codcolorem");
	if (codColor && codColor != "") {
		where += " AND a.codcolorem = '" + codColor + "'";
	}
	
	if (!where || where == "") {
		where = "1=1";
	}
	return where;
}

function oficial_imprimir()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var aEtiquetas = [];
	var descDibujo = "";
	var codseriediseno = "";
	var descripcion = "";

	for (var f = 0; f < _i.tblEtiquetas_.numRows(); f++) {
		var aE = new Object;
		aE["referencia"] = _i.tblEtiquetas_.text(f, _i.REFERENCIA_);		
		aE["tamanocolor"] = _i.tblEtiquetas_.text(f, _i.TAMANO_) + "    " + _i.tblEtiquetas_.text(f, _i.COLOR_);		
		descripcion = _i.tblEtiquetas_.text(f, _i.DESCRIPCION_);
		codseriediseno = _i.tblEtiquetas_.text(f, _i.CODSERIE_);
		descDibujo = _i.tblEtiquetas_.text(f, _i.DESCDIBUJO_);

		if (codseriediseno && codseriediseno != ""){
			codseriediseno = "[" + codseriediseno + "]";
			descDibujo = descDibujo + " - " + codseriediseno;
		}
		aE["descripcion"] = descripcion;
		aE["codseriediseno"] = codseriediseno;
		aE["cantidad"] = _i.tblEtiquetas_.text(f, _i.CANTIDAD_);
		aE["barcode"] = _i.tblEtiquetas_.text(f, _i.BARCODE_);
		aE["abrevlog"] = _i.tblEtiquetas_.text(f, _i.ABREVLOG_);
		aE["descdibujo"] = descDibujo;
		aE["descsubfamilia"] = _i.tblEtiquetas_.text(f, _i.DESCSUBFAM_);
		

		aEtiquetas.push(aE);
	}
	_i.imprimeEtiquetasCaja(aEtiquetas);
	return true;
}

function oficial_imprimeEtiquetasCaja(aEtiquetas, impresora)
{
	var _i = this.iface;

	/*if (!impresora) {
		impresora = AQUtil.sqlSelect("prodppal_general", "impresoraetiart", "1 = 1");
	}*/

	var copias, aE;
	var xmlKD = new FLDomDocument;
	xmlKD.setContent("<!DOCTYPE KUGAR_DATA><KugarData/>");
	var eRow:FLDomElement;

	for (var a = 0; a < aEtiquetas.length; a++) {
		aE = aEtiquetas[a];
		copias = aE.cantidad;
		if (copias == 0) {
			continue;
		}
		for (var i = 0; i < copias; i++) {
			eRow = xmlKD.createElement("Row");
			for (var c in aE) {
				if (c == "cantidad") {
					continue;
				}
				eRow.setAttribute(c, aE[c]);
			}
			eRow.setAttribute("level", 0);
			xmlKD.firstChild().appendChild(eRow);
		}
	}
	debug(xmlKD.toString(4));

	var rptViewer = new FLReportViewer();
	rptViewer.setReportData(xmlKD);

	var rptViewer = new FLReportViewer();
	rptViewer.setReportTemplate("em_i_eti_caja");
	rptViewer.setReportData(xmlKD);
	rptViewer.renderReport();
	rptViewer.exec();  
	return true;
}

function oficial_tbnCargaTexto_clicked()
{
  	var _i = this.iface;
	var dialog = new Dialog;
	dialog.okButtonText = sys.translate("Aceptar");
	dialog.cancelButtonText = sys.translate("Cancelar");

	var gB = new GroupBox;
	gB.title = sys.translate("Pegue la lista de referencias");
	dialog.add( gB );
	var teTabla = new TextEdit;
	gB.add( teTabla );

	if(!dialog.exec()) {
		return;
	}
	var texto = teTabla.text;
	var aRefs = texto.split(";");
	if (!aRefs || aRefs.length == 0) {
		return;
	}
	var nL = aRefs.length;
	nL--;
	if (nL < 1) {
		return;
	}
	var t = _i.tblEtiquetas_;
	var f = t.numRows()
	var q = new AQSqlQuery;
	q.setSelect("a.descripcion, a.codtamanoem, a.referencia, a.codcolorem, a.codbarras, em_disenos.codseriediseno,sf.descripcion,sf.em_abreviaturalog,a.emdibujo");
	q.setFrom("articulos a LEFT OUTER JOIN em_dibujos ON a.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno LEFT OUTER JOIN subfamilias sf ON sf.codsubfamilia = a.codsubfamilia");
	
	for (var e = nL; e >= 0 ; e--) {
		q.setWhere("a.referencia = '" + aRefs[e] + "'");
		if (!(q.exec() && q.first())) {
			return false
		}
		_i.insertaFila(f, q)
		f++;
	}
}

function oficial_ledCantidad_returnPressed()
{
	this.child("tbnBuscar").animateClick();
	this.child("fdbReferencia").setFocus();
}

function oficial_initEventFilter()
{
  var _i = this.iface;

  _i.eventWatcher_ = new QObject;
  _i.eventWatcher_.eventFilterFunction = this.name + ".iface.eventFilter";
  _i.eventWatcher_.allowedEvents = [ /**AQS.Enter, AQS.Leave AQS.FocusIn, */AQS.FocusOut/**, AQS.KeyPress*/];
}

function oficial_eventFilter(o, e)
{
	var cursor = this.cursor();
	var _i = this.iface;
  var rtti = o.rtti();
	
  switch (e.type) {
		/**case AQS.KeyPress:{
			return true;
		}*/
//     case AQS.FocusIn: {
//       if (o.isWidgetType() && (rtti == "LineEdit" || rtti == "Table")) {
//         o.paletteBackgroundColor = "#BCF5A9";
// 				if(rtti == "Table" && cursor.valueBuffer("tipodoc") == "DEVOLUCION"){
// 					var f = _i.tblRapida.currentRow();
// 					if(isNaN(f) || f < 0) {
// 						return true;
// 					}
// 					_i.tblRapida.editCell(f, _i.colTR["cantidad"]);
// 					o.paletteBackgroundColor = "#BCF5A9";
// 				}
//       }
//       return true;
//     }
    case AQS.FocusOut: {
			if (o.parentWidget().name == "fdbReferencia") {
				this.child("ledCantidad").selectAll();
			}
      return true;
    }
  }
  return false;
}

function oficial_initWatch(obj)
{
  if (obj == undefined)
    return;
  var _i = this.iface;
  obj.installEventFilter(_i.eventWatcher_);
}

function oficial_finishWatch(obj)
{
  if (obj == undefined)
    return;
  var _i = this.iface;
  obj.removeEventFilter(_i.eventWatcher_);
}


//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
