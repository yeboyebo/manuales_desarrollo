# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa
import json

# lotesstock = qsa.class_("em_lotesxubicacion")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */ 
# UBICACIONES 
class Oficial(Base):

    def get(self, params, username=None):

        mapa = self.get_mapa()
        obj = qsa.from_project("formAPI").get_resources('em_lotesxubicacion', params, mapa, username)

        return obj


    def get_mapa(self):
        return {
            'join': 'em_lotesxubicacion INNER JOIN lotesstock ON em_lotesxubicacion.codlote = lotesstock.codlote INNER JOIN articulos ON articulos.referencia = lotesstock.referencia INNER JOIN subfamilias ON subfamilias.codsubfamilia = articulos.codsubfamilia',
            # 'join': 'em_lotesxubicacion INNER JOIN lotesstock ON em_lotesxubicacion.codlote = lotesstock.codlote',
            'order': 'subfamiliasdescripcion',
            'map': {
                'id': {'field': 'em_lotesxubicacion.id', 'type': 'string'},
                'actual': {'field': 'em_lotesxubicacion.actual', 'type': 'bool'},
                'em_ubialternativa': {'field': 'em_lotesxubicacion.em_ubialternativa', 'type': 'string'},
                'codlote': {'field': 'em_lotesxubicacion.codlote', 'type': 'string'},
                'referencia': {'field': 'lotesstock.referencia', 'type': 'string'},
                'descripcion': {'field': 'articulos.descripcion', 'type': 'string'},
                'codcolorem': {'field': 'articulos.codcolorem', 'type': 'string'},
                'codtamanoem': {'field': 'articulos.codtamanoem', 'type': 'string'},
                'coddibestamp': {'field': 'articulos.coddibestamp', 'type': 'string'},
                'candisponible': {'field': 'lotesstock.candisponible', 'type': 'string'},
                'codalmacen': {'field': 'lotesstock.codalmacen', 'type': 'string'},
                'subfamiliasdescripcion': {'field': 'subfamilias.descripcion', 'type': 'string'}
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
