
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends deposito {
  function euromoda( context ) { deposito ( context ); }
	function init() {
    return this.ctx.euromoda_init();
  }
  function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function imprimir(codFactura, membrete) {
		return this.ctx.euromoda_imprimir(codFactura, membrete);
	}
  function tbnImprimirMembrete_clicked() {
		return this.ctx.euromoda_tbnImprimirMembrete_clicked();
	}
	function dameParamInforme(idFactura) {
		return this.ctx.euromoda_dameParamInforme(idFactura);
	}
	function whereAgrupacion(curAgrupar) {
		return this.ctx.euromoda_whereAgrupacion(curAgrupar);
	}
	function groupByAgrupacion(cursor) {
		return this.ctx.euromoda_groupByAgrupacion(cursor);
	}
	function selectAgrupacion(cursor) {
		return this.ctx.euromoda_selectAgrupacion(cursor);
	}
	function dameDatosAgrupacionAlbaranes(curAgruparAlbaranes) {
		return this.ctx.euromoda_dameDatosAgrupacionAlbaranes(curAgruparAlbaranes);
	}
	function masWhereFactura(qryAgruparAlbaranes, curAgruparAlbaranes) {
		return this.ctx.euromoda_masWhereFactura(qryAgruparAlbaranes, curAgruparAlbaranes);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;

	_i.__init();
// 	connect(this.child("toolButtonPrint"), "clicked()", _i, "tbnImprimir_clicked");
  connect(this.child("tbnImprimirMembrete"), "clicked()", _i, "tbnImprimirMembrete_clicked");
}

function euromoda_commonCalculateField(fN, cursor)
{
  var _i = this.iface;
  var valor;

  switch (fN) {
		case "em_vencimientos": {
			var q = new AQSqlQuery;
			q.setSelect("fechav, SUM(importe)");
			q.setFrom("reciboscli");
			q.setWhere("idfactura = " + cursor.valueBuffer("idfactura") + " GROUP BY fechav ORDER BY fechav");
			if (!q.exec()) {
				return false;
			}
			valor = "";
			while (q.next()) {
				valor += q.value("fechav") + "*" + q.value("SUM(importe)") + ";";
			}
			break;
		}
	case "pordtoesp_fp": {
      valor = AQUtil.sqlSelect("formaspago", "pordtoesp", "codpago = '" + cursor.valueBuffer("codpago") + "'");
      valor = parseFloat(AQUtil.roundFieldValue(valor, "presupuestoscli", "pordtoesp"));
      break;
    }
  case "codserie": {
      if (cursor.modeAccess() != cursor.Insert) {
        MessageBox.warning(sys.translate("Est� tratando de cambiar la serie de una factura cuyo c�digo ya ha sido generado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
        return cursor.valueBuffer("codserie");
      }
      if (cursor.valueBuffer("deabono") || cursor.valueBuffer("em_deabono")) {
        valor = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli gc ON c.codgrupocontablecli = gc.codgrupo", "gc.codserieabo", "c.codcliente = '" + cursor.valueBuffer("codcliente") + "'", "clientes");
      } else {
        valor = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli gc ON c.codgrupocontablecli = gc.codgrupo", "gc.codseriefac", "c.codcliente = '" + cursor.valueBuffer("codcliente") + "'", "clientes");
      }
      break;
    }
	case "bultos": {
			valor = parseFloat(AQUtil.sqlSelect("albaranescli","sum(bultos)","idalbaran in (select idalbaran from lineasfacturascli where idfactura = " +  cursor.valueBuffer("idfactura") + ")"));
			if(!valor)
				valor = "";
		break;
	}
	case "volumen": {
		valor = parseFloat(AQUtil.sqlSelect("albaranescli","sum(volumen)","idalbaran in (select idalbaran from lineasfacturascli where idfactura = " +  cursor.valueBuffer("idfactura") + ")"));
		if(!valor)
			valor = "";
		break;
	}
	case "pesoneto": {
		valor = parseFloat(AQUtil.sqlSelect("albaranescli","sum(pesoneto)","idalbaran in (select idalbaran from lineasfacturascli where idfactura = " +  cursor.valueBuffer("idfactura") + ")"));
		if(!valor)
			valor = "";
		break;
	}
	case "pesobruto": {
		valor = parseFloat(AQUtil.sqlSelect("albaranescli","sum(pesobruto)","idalbaran in (select idalbaran from lineasfacturascli where idfactura = " +  cursor.valueBuffer("idfactura") + ")"));
		if(!valor)
			valor = "";
		break;
	}
		case "provinciae": {
      valor = AQUtil.sqlSelect("dirclientes", "provincia", "id = " + cursor.valueBuffer("coddire"));
      if (!valor) {
        valor = cursor.valueBuffer("provinciae");
			}
      break;
    }
    case "codpaise": {
      valor = AQUtil.sqlSelect("dirclientes", "codpais", "id = " + cursor.valueBuffer("coddire"));
      if (!valor) {
        valor = cursor.valueBuffer("codpaise");
			}
      break;
    }
		default: {
			valor = _i.__commonCalculateField(fN, cursor);
			break;
		}
	}
  return valor;
}

function euromoda_imprimir(codFactura, membrete)
{
	if (sys.isLoadedModule("flfactinfo")) {
		var util = new FLUtil();

		var nombreInforme = "i_facturascli";

		var codigo;
		var idFactura;
		if (codFactura) {
			codigo = codFactura;
			idFactura = util.sqlSelect("facturascli", "idfactura", "codigo = '" + codFactura + "'");
		} else {
			if (!this.cursor().isValid())
				return;
			codigo = this.cursor().valueBuffer("codigo");
			idFactura = this.cursor().valueBuffer("idfactura");
		}
		var paisEmpresa = flfactppal.iface.pub_valorDefectoEmpresa("codpais");
		var paisFactura = util.sqlSelect("facturascli", "codpais", "idfactura = '" + idFactura + "'");
		if(paisFactura && paisFactura != "" && paisFactura != paisEmpresa)
				nombreInforme = "i_facturascli_int";
		else
			nombreInforme = "i_facturascli";
		var curImprimir = new FLSqlCursor("i_facturascli");
		curImprimir.setModeAccess(curImprimir.Insert);
		curImprimir.refreshBuffer();
		curImprimir.setValueBuffer("descripcion", "temp");
		curImprimir.setValueBuffer("d_facturascli_codigo", codigo);
		curImprimir.setValueBuffer("h_facturascli_codigo", codigo);

		flfactinfo.iface.pub_ponerMembrete(membrete);
		flfactinfo.iface.pub_lanzarInforme(curImprimir, nombreInforme);
		flfactinfo.iface.pub_ponerMembrete(false);
	} else
		flfactppal.iface.pub_msgNoDisponible("Informes");
}

function euromoda_dameParamInforme(idFactura)
{
	var _i = this.iface;
  var oParam = _i.__dameParamInforme(idFactura);
  oParam.orderBy = "facturascli.idfactura, lineasfacturascli.codarancelario DESC, lineasfacturascli.numlinea";
  return oParam;
}

function euromoda_tbnImprimirMembrete_clicked()
{
	var _i = this.iface;
	_i.imprimir(false, true);
}


function euromoda_whereAgrupacion(curAgrupar)
{
	var codCliente = curAgrupar.valueBuffer("codcliente");
	var nombreCliente = curAgrupar.valueBuffer("nombrecliente");
	var cifNif = curAgrupar.valueBuffer("cifnif");
	var codAlmacen = curAgrupar.valueBuffer("codalmacen");
	var codPago = curAgrupar.valueBuffer("codpago");
	var codDivisa = curAgrupar.valueBuffer("coddivisa");
	var codSerie = curAgrupar.valueBuffer("codserie");
	var codEjercicio = curAgrupar.valueBuffer("codejercicio");
	var fechaDesde = curAgrupar.valueBuffer("fechadesde");
	var fechaHasta = curAgrupar.valueBuffer("fechahasta");
	var codDropshipping = curAgrupar.valueBuffer("emcoddropshipping");

  	var where = "albaranescli.ptefactura = 'true'";

  	if(codDropshipping) {

  		//where += " AND albaranescli.em_coddropshipping = '" + codDropshipping + "'";
  		var aCodDrop = codDropshipping.split(",");
  		where += " AND albaranescli.em_coddropshipping IN ('" + aCodDrop.join("', '") + "')";
  	} 
  	else {
		if (codCliente && !codCliente.isEmpty())
		where += " AND albaranescli.codcliente = '" + codCliente + "'";
		if (cifNif && !cifNif.isEmpty())
		where += " AND albaranescli.cifnif = '" + cifNif + "'";
		if (codAlmacen && !codAlmacen.isEmpty())
		where = where + " AND albaranescli.codalmacen = '" + codAlmacen + "'";
		where = where + " AND albaranescli.fecha >= '" + fechaDesde + "'";
		where = where + " AND albaranescli.fecha <= '" + fechaHasta + "'";
		if (codPago && !codPago.isEmpty())
		where = where + " AND albaranescli.codpago = '" + codPago + "'";
		if (codDivisa && !codDivisa.isEmpty())
		where = where + " AND albaranescli.coddivisa = '" + codDivisa + "'";
		if (codSerie && !codSerie.isEmpty())
		where = where + " AND albaranescli.codserie = '" + codSerie + "'";
	}

    
    where += " AND tipodeposito NOT IN ('Entrega dep�sito', 'Devoluci�n dep�sito')";
  return where;
}

function euromoda_groupByAgrupacion(cursor)
{
	var _i = this.iface;
	var groupBy = _i.__groupByAgrupacion(cursor);
	var optFechaValor = cursor.valueBuffer("em_optfechavalor");
	if(optFechaValor == "Agrupar por fecha valor") {
		groupBy +=",fechavalor";
	}
	return groupBy;
}

function euromoda_selectAgrupacion(cursor)
{
	var _i = this.iface;
	var sSelect = _i.__selectAgrupacion(cursor);
	var optFechaValor = cursor.valueBuffer("em_optfechavalor");
	if(optFechaValor == "Agrupar por fecha valor") {
		sSelect +=",fechavalor";
	}
	return sSelect;
}

	
	
function euromoda_dameDatosAgrupacionAlbaranes(curAgruparAlbaranes)
{
	var _i = this.iface;
	var res = _i.__dameDatosAgrupacionAlbaranes(curAgruparAlbaranes);
	if (!res) {
		return false;
	}	
	res["optFechaValor"] = curAgruparAlbaranes.valueBuffer("em_optfechavalor");
	return res;
}	

function euromoda_masWhereFactura(qryAgruparAlbaranes, curAgruparAlbaranes)
{
	var _i = this.iface;
	var where = _i.__masWhereFactura(qryAgruparAlbaranes, curAgruparAlbaranes);

	var optFechaValor = curAgruparAlbaranes.valueBuffer("em_optfechavalor");
	debug("optFechaValor: "+optFechaValor);
	if(optFechaValor == "Agrupar por fecha valor") {
		var fechaValor = qryAgruparAlbaranes.value("fechavalor");
		if(!fechaValor || fechaValor == "") {
			where += " AND fechavalor is null";
		}  else {
			where += " AND fechavalor = '" + fechaValor + "'";
		}
	}
	return where;
}



//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

