var form = this;
/***************************************************************************
                 em_masterasignacionesconf.qs  -  description
                             -------------------
    begin                : mar may 14 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var oColorLinea_, codAsigConfAnt_;
	//var enProduccion_;
	function oficial( context ) { interna( context ); }
	function toolButtonDelete_clicked() {
		return this.ctx.oficial_toolButtonDelete_clicked();
	}
	function tbnInventario_clicked() {
		return this.ctx.oficial_tbnInventario_clicked();
	}
	function eliminaAsignacion(oParam) {
		return this.ctx.oficial_eliminaAsignacion(oParam);
	}
	function imprimir(oParam) {
		return this.ctx.oficial_imprimir(oParam);
	}
	function tbnImprimir_clicked() {
		return this.ctx.oficial_tbnImprimir_clicked();
	}
	function tbnImprimirNecesidades_clicked() {
		return this.ctx.oficial_tbnImprimirNecesidades_clicked();
	}
	function dameParamInforme(codAsigConf) {
		return this.ctx.oficial_dameParamInforme(codAsigConf);
	}
	function dameParamInformeNecesidades(codAsigConf) {
		return this.ctx.oficial_dameParamInformeNecesidades(codAsigConf);
	}
	function enviaOrdenes(oParam) {
		return this.ctx.oficial_enviaOrdenes(oParam);
	}
	function cantidadPositiva(nodo,campo) {
		return this.ctx.oficial_cantidadPositiva(nodo,campo);
	}
	function tbnEnviar_clicked() {
		return this.ctx.oficial_tbnEnviar_clicked();
	}
	function dameColorLinea(fN, fV, cursor, sel, fT) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, sel, fT);
	}
	function asignacionActual() {
		return this.ctx.oficial_asignacionActual();
	}
	function tbnTransferir_clicked() {
		return this.ctx.oficial_tbnTransferir_clicked();
	}
	function trasfiereMatConf(codAsigConf) {
		return this.ctx.oficial_trasfiereMatConf(codAsigConf);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_asignacionActual() {
    return this.asignacionActual();
  }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	
	//_i.enProduccion_ = sys.nameBD() == "abanq_creaciones";

	var cursor = this.cursor();

	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("tbnImprimir"), "clicked()", _i, "tbnImprimir_clicked");
	connect(this.child("tbnImprimirNecesidades"), "clicked()", _i, "tbnImprimirNecesidades_clicked");
	connect(this.child("tbnEnviar"), "clicked()", _i, "tbnEnviar_clicked");
	connect(this.child("tbnTransferir"), "clicked()", _i, "tbnTransferir_clicked");
	connect(this.child("tbnInventario"), "clicked()", _i, "tbnInventario_clicked");

}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnInventario_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codConfec = cursor.valueBuffer("codconfeccionista");
	if (!codConfec) {
		MessageBox.warning(sys.translate("No ha establecido el confeccionista asociado a la asignaci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	flprodppal.iface.pub_lanzaInventarioConf(codConfec);
}

function oficial_toolButtonDelete_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codAsigConf = cursor.valueBuffer("codasigconf");
	if (!codAsigConf) {
		return;
	}

	var qComp = new AQSqlQuery;
	qComp.setSelect("op.codorden, op.estado, COUNT(p.idpedido)");
	qComp.setFrom("pr_ordenesproduccion op LEFT OUTER JOIN pedidosprov p ON op.codorden = p.codordenprod");
	qComp.setWhere("op.codasigconf = '" + codAsigConf + "' GROUP BY op.codorden, op.estado");
	if (!qComp.exec()) {
		return false;
	}
	var oEstados = [], oPedidos = [];
	var estado
	while (qComp.next()) {
		estado = qComp.value("op.estado");
		if (estado != "PTE" && estado != "EN CURSO" && estado != "PTE CONFECCION") {
			oEstados.push(qComp.value("op.codorden"));
		}
		if (qComp.value("COUNT(p.idpedido)") != 0) {
			oPedidos.push(qComp.value("op.codorden"));
		}
	}
	if (oEstados.length > 0) {
		sys.warnMsgBox(sys.translate("Hay �rdenes con estados distintos de PTE, EN CURSO o PTE CONFECCION:\n%1").arg(oEstados.join(", ")));
		return false;
	}
	if (oPedidos.length > 0) {
		sys.warnMsgBox(sys.translate("Hay �rdenes con pedidos de proveedor asociados:\n%1").arg(oPedidos.join(", ")));
		return false;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al desvincular las �rdenes de la asignaci�n %1").arg(codAsigConf);
	oParam.codAsigConf = codAsigConf;
	var f = new Function("oParam", "return formem_asignacionesconf.iface.eliminaAsignacion(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	this.child("tableDBRecords").refresh();
}

function oficial_eliminaAsignacion(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAsigConf = oParam.codAsigConf;
	var q = new AQSqlQuery;
	q.setSelect("codorden");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere("codasigconf = '" + codAsigConf + "'");
	if (!q.exec()) {
		return false;
	}
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Desvinculando �rdenes"), q.size());
	var oP = new Object;
	var p = 0;
	while (q.next()) {
		AQUtil.setProgress(++p);
		oP.codOrden = q.value("codorden");
		AQUtil.setLabelText(sys.translate("Desvinculando orden %1").arg(oP.codOrden));
		if (!formRecordem_asignacionesconf.iface.pub_eliminaAsignacion(oP)) {
			AQUtil.destroyProgressDialog();
			oParam.errorMsg = sys.translate("Error al desvincular la orden").arg(oP.codOrden);
			return false;
		}
	}
	if (!AQSql.del("em_asignacionesconf", "codasigconf = '" + codAsigConf + "'")) {
		AQUtil.destroyProgressDialog();
		oParam.errorMsg = sys.translate("Error al eliminar el registro de asignaci�n");
		return false;
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_imprimir(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (!oParam) {
		return false;
	}

	flfactinfo.iface.pub_lanzaInforme(cursor, oParam);
}

function oficial_tbnImprimir_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAsigConf = cursor.valueBuffer("codasigconf");

	var oParam = _i.dameParamInforme(codAsigConf);
	_i.imprimir(oParam);
}

function oficial_tbnImprimirNecesidades_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAsigConf = cursor.valueBuffer("codasigconf");

	var oParam = _i.dameParamInformeNecesidades(codAsigConf)
	_i.imprimir(oParam);
}

function oficial_dameParamInforme(codAsigConf)
{
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "pr_i_asignacionesconf";
	oParam.whereFijo = "em_asignacionesconf.codasigconf = '" + codAsigConf + "'";

	return oParam;
}

function oficial_dameParamInformeNecesidades(codAsigConf)
{
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "pr_i_necesidadesorden";

	var listaFamEstampado = flfactalma.iface.pub_dameFamEstampado();
	var listaFamCrudo = flfactalma.iface.pub_dameFamCrudo();

	oParam.whereFijo = "em_asignacionesconf.codasigconf = '" + codAsigConf + "' AND articulos.codfamilia NOT IN (" + listaFamEstampado + ") AND articulos.codfamilia NOT IN (" + listaFamCrudo+ ")";

	oParam.groupBy
	= "movistock.referencia,articulos.descripcion,em_asignacionesconf.codasigconf,em_asignacionesconf.nombreconfeccionista,em_asignacionesconf.codconfeccionista,em_asignacionesconf.fecha,stocks.disponible,stocks.cantidad,(stocks.reservada + stocks.reservadapterecibir + stocks.afaltas),(stocks.cantidad - (stocks.reservada + stocks.reservadapterecibir + stocks.afaltas)),empresa.nombre,empresa.cifnif,empresa.direccion,empresa.apartado,empresa.codpostal,empresa.ciudad,empresa.provincia,empresa.codpais,articulos.codfamilia, articulos.codsubfamilia,articulos.descripcion,articulos.codtamanoem, articulos.codcolorem, em_colores.codigogit";

	return oParam;
}

function oficial_tbnEnviar_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAsigConf = cursor.valueBuffer("codasigconf");
	if (!codAsigConf) {
		return;
	}

	var estado = cursor.valueBuffer("estado");
	if (estado != "Asignada") {
		sys.warnMsgBox(sys.translate("Para enviar la orden su estado debe ser Asignada"));
		return false;
	}
	var res = MessageBox.information(sys.translate("Va a generar los pedidos de las �rdenes asociadas a la asignaci�n %1.\n�Est� seguro?").arg(codAsigConf), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
	if (res != MessageBox.Yes) {
		return false;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al generar los pedidos asociados a la asignaci�n %1").arg(codAsigConf);
	oParam.codAsigConf = codAsigConf;
	var f = new Function("oParam", "return formem_asignacionesconf.iface.enviaOrdenes(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	this.child("tableDBRecords").refresh();
	sys.infoMsgBox(sys.translate("Pedidos generados con �xito"));
}

function oficial_enviaOrdenes(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codAsigConf = oParam.codAsigConf;
	
	//if (!_i.enProduccion_) {
		if (!_i.trasfiereMatConf(codAsigConf)) {
			return false;
		}
	//}
	AQUtil.destroyProgressDialog();
	
	var oParamPC = new Object;
	oParamPC.codPedido = false;

	var curO = new FLSqlCursor("pr_ordenesproduccion");
	curO.select("codasigconf = '" + codAsigConf + "'");
	AQUtil.createProgressDialog(sys.translate("Enviando �rdenes"), curO.size());
	while (curO.next()) {
		curO.setModeAccess(curO.Edit);
		curO.refreshBuffer();
		curO.setValueBuffer("materialconfok", true);
		oParamPC.codOrden = curO.valueBuffer("codorden");
		if (!formem_districonf.iface.pub_creaPedidoConf(oParamPC)) {
			oParam.errorMsg = sys.translate("Error al enviar la orden").arg(oParamPC.codOrden);
			return false;
		}
		if (!curO.commitBuffer()) {
			oParam.errorMsg = sys.translate("Error al marcar el material listo de la orden").arg(oParamPC.codOrden);
			return false;
		}
	}
	if (!AQSql.update("em_asignacionesconf", ["estado"], ["Enviada"], "codasigconf = '" + codAsigConf + "'")) {
		return false;
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_trasfiereMatConf(codAsigConf)
{
	var _i = this.iface;
	
	if (AQUtil.sqlSelect("transstock", "idtrans", "codasigconf = '" + codAsigConf + "'")) {
		sys.infoMsgBox(sys.translate("Ya hay una transferencia de stock ligada a la asignaci�n %1.\nNo se generar� una nueva transferencia").arg(codAsigConf));
		return true;
	}
	var codAlmaOrigen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
	var codAlmaDestino = AQUtil.sqlSelect("em_asignacionesconf ac INNER JOIN proveedores p ON ac.codconfeccionista = p.codproveedor", "p.codalmacen", "ac.codasigconf = '" + codAsigConf + "'", "em_asignacionesconf");
	
	var ahora = new Date;
	var curTS = new FLSqlCursor("transstock");
	curTS.setModeAccess(curTS.Insert);
	curTS.refreshBuffer();
	curTS.setValueBuffer("fecha", ahora.toString().left(10));
	curTS.setValueBuffer("hora", ahora.toString().right(8));
	curTS.setValueBuffer("codalmaorigen", codAlmaOrigen);
	curTS.setValueBuffer("codalmadestino", codAlmaDestino);
	curTS.setValueBuffer("codasigconf", codAsigConf);
	var idTrans = curTS.valueBuffer("idtrans");
	if (!idTrans) {
		return false;
	}
	if (!curTS.commitBuffer()) {
		return false;
	}
	if (!formRecordtransstock.iface.pub_creaLineasTransConf(curTS)) {
		return false;
	}
	return true;
}

function oficial_dameColorLinea(fN, fV, cursor, sel, fT)
{
return;
	debug("oficial_dameColorLinea");
  var _i = this.iface;
  var codAsigConf = cursor.valueBuffer("codasigconf");
  if (!sel && codAsigConf == _i.codAsigConfAnt_) {
    return _i.oColorLinea_;
  }
  if (!sel) {
    _i.codAsigConfAnt_ = codAsigConf;
	} else {
    _i.codAsigConfAnt_ = -1;
	}
	var color = "";
  if (cursor.valueBuffer("estado") == "Enviada") {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_azul_sel" : "fondo_azul");
  } else {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_gris_sel" : "fondo_gris");
  }
  if (color != "") {
    _i.oColorLinea_ = [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
    return _i.oColorLinea_;
  } else
    _i.codAsigConfAnt_ = -1;
}

function oficial_asignacionActual()
{
  var cursor = this.cursor();
  var codAsigConf = cursor.valueBuffer("codasigconf");
  return codAsigConf;
}

function oficial_tbnTransferir_clicked()
{
  var cursor = this.cursor();
  var f = new FLFormSearchDB("em_transstock_ac");
  var curTS = f.cursor();

  var codAsigConf = cursor.valueBuffer("codasigconf");
  if (!codAsigConf) {
    return;
  }

  var filtro = "codasigconf = '" + codAsigConf + "'";
  curTS.setMainFilter(filtro);

  f.setMainWidget();
  f.exec();
}

function oficial_cantidadPositiva(nodo, campo)
{
	var v = nodo.attributeValue("sum(movistock.cantidad)");
	v = parseFloat(v);
	v = isNaN(v) ? 0 : v;
	//v = (v < 0) ? (v *= -1) : v; pineboo 21-08-2019
	if (v < 0) {
		v = v*-1;
	}	
	return v;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
