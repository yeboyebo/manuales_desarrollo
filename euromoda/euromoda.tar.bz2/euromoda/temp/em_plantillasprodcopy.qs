/***************************************************************************
                 em_plantillasprodcopy.qs  -  description
                             -------------------
    begin                : lun dic 4 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var curLinea_;
	function oficial( context ) { interna( context ); }
	function aceptarFormulario() {
		return this.ctx.oficial_aceptarFormulario();
	}
	function copiaPlantilla(cursor) {
		return this.ctx.oficial_copiaPlantilla(cursor);
	}
	function datosLineaPlantilla(cursorOrigen, campo) {
		return this.ctx.oficial_datosLineaPlantilla(cursorOrigen, campo);
	}
	function copiarTablaLineasPlantilla(curP, idPlantillaOri) {
		return this.ctx.oficial_copiarTablaLineasPlantilla(curP, idPlantillaOri);
	}
	function crearPlantilla(cursor) {
		return this.ctx.oficial_crearPlantilla(cursor);
	}
	
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El Al copiar un art�culo se copian tambi�n sus tarifas y sus precios por proveedor.
\end */
function interna_init()
{
	var _i = this.iface;	
	if (this.child("pushButtonAccept")){
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
		connect(this.child("pushButtonAccept"), "clicked()", _i, "aceptarFormulario"); 
	}
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_aceptarFormulario()
{
 	
 	var _i = this.iface;
 	var cursor = this.cursor();
 	if(!_i.copiaPlantilla(cursor)) {
 		return false;
 	}
 	this.obj().accept();
}

function oficial_copiaPlantilla(cursor)
{
	var _i = this.iface;
	var curP = new FLSqlCursor("em_plantillasprod");
	curP.setModeAccess(curP.Insert);
	curP.refreshBuffer();
	
	curP.setValueBuffer("codsubfamilia", cursor.valueBuffer("codsubfamilia"));
	curP.setValueBuffer("codtamanoem", cursor.valueBuffer("codtamanoem"));	
	curP.setValueBuffer("codcolorem", cursor.valueBuffer("codcolorem"));
	curP.setValueBuffer("codcoleccionem", cursor.valueBuffer("codcoleccionem"));
	curP.setValueBuffer("desccoleccion", AQUtil.sqlSelect("em_colecciones","descripcion","codcoleccionem = '" + cursor.valueBuffer("codcoleccionem") + "'"));
	curP.setValueBuffer("nombre", formRecordem_plantillasprod.iface.pub_commonCalculateField("nombre", curP));
	if (!curP.commitBuffer()) {
		return false;
	}
	if(!_i.copiarTablaLineasPlantilla(curP, cursor.valueBuffer("idplantillaori"))) {
		return false;
	}
	debug("se va por el true");
	return true;
}

function oficial_copiarTablaLineasPlantilla(curP,idPlantillaOri)
{
	debug("oficial_copiarTablaLineasPlantilla");
	var _i = this.iface;
	var idPlantillaNueva = curP.valueBuffer("idplantilla");
	debug("oficial_copiarTablaLineasPlantilla idPlantillaNueva: "+idPlantillaNueva);
	debug("oficial_copiarTablaLineasPlantilla idPlantillaOri: "+idPlantillaOri);
	if (!_i.curLinea_) {
		_i.curLinea_ = new FLSqlCursor("em_lineasplantillaprod");
	}
	
	var campos = AQUtil.nombreCampos("em_lineasplantillaprod");
	var totalCampos = campos[0];

	var curLineaOrigen = new FLSqlCursor("em_lineasplantillaprod");
	curLineaOrigen.select("idplantilla= " + idPlantillaOri);
	while (curLineaOrigen.next()) {
		debug("entra");
		_i.curLinea_.setModeAccess(_i.curLinea_.Insert);
		_i.curLinea_.refreshBuffer();
		_i.curLinea_.setValueBuffer("idplantilla", curP.valueBuffer("idplantilla"));
		_i.curLinea_.setValueBuffer("codcoleccionplan", curP.valueBuffer("codcoleccionem"));
		_i.curLinea_.setValueBuffer("codsubfamiliaplan", curP.valueBuffer("codsubfamilia"));
		_i.curLinea_.setValueBuffer("codtamanoplan", curP.valueBuffer("codtamanoem"));
		_i.curLinea_.setValueBuffer("codcolorplan", curP.valueBuffer("codcolorem"));
		_i.curLinea_.setValueBuffer("nombreplan", curP.valueBuffer("nombre"));

	
		for (var i = 1; i <= totalCampos; i++) {
			debug("campos: "+campos[i]);
			if (!_i.datosLineaPlantilla(curLineaOrigen, campos[i])) {
				return false;
			}
		}

		if (!_i.curLinea_.commitBuffer()) {
			return false;
		}
	}

	return true;
}

function oficial_datosLineaPlantilla(cursorOrigen, campo)
{
	var _i = this.iface;
	if (!campo || campo == "") {
		return false;
	}

	switch (campo) {
		case "idlinea":
		case "idplantilla":
		case "codcoleccionplan": 
		case "codsubfamiliaplan":
		case "codtamanoplan":
		case "codcolorplan":
		case "nombreplan":{
			return true;
			break;
		}
		default: {
			if (cursorOrigen.isNull(campo)) {
				_i.curLinea_.setNull(campo);
			} else {
				_i.curLinea_.setValueBuffer(campo, cursorOrigen.valueBuffer(campo));
			}
		}
	}
	return true;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////