/***************************************************************************
                 masteremsubfamiliasrutareservas.qs  -  description
                             -------------------
    begin                : mar may 14 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
		
	function oficial( context ) { interna( context ); }
	
	function ordenaCols() {
    return this.ctx.oficial_ordenaCols();
  }
	function marcaSeleccionado() {
    return this.ctx.oficial_marcaSeleccionado();
  }
  function seleccionarTodo(){
    return this.ctx.oficial_seleccionarTodo();
  }
  function deseleccionarTodo(){
    return this.ctx.oficial_deseleccionarTodo();
  }
  function imprimir(){
    return this.ctx.oficial_imprimir();
  }
  function lanzarInforme(q){
    return this.ctx.oficial_lanzarInforme(q);
  }
	function encabezadoInforme() {
		return this.ctx.oficial_encabezadoInforme();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
    
	function pub_encabezadoInforme() {
		return this.encabezadoInforme();
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El Al copiar un art�culo se copian tambi�n sus tarifas y sus precios por proveedor.
\end */
function interna_init()
{
	var _i = this.iface;
	
	_i.ordenaCols();
	_i.marcaSeleccionado();
  connect(this.child("pbnSeleccionar"), "clicked()", _i, "seleccionarTodo");
	connect(this.child("pbnDeseleccionar"), "clicked()", _i, "deseleccionarTodo");
	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "imprimir");
	
	
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_ordenaCols()
{
	var oC = ["descripcion", "codsubfamilia"];
	this.child("tableDBRecords").setOrderCols(oC);
}

function oficial_marcaSeleccionado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var seleccionado = formem_stocktejidos.iface.pub_dameRegistroSeleccionado();
	this.child("tableDBRecords").setPrimaryKeyChecked(seleccionado, true);
	
}

function oficial_seleccionarTodo()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
	var filtro = formem_stocktejidos.iface.pub_dameFiltro();

  var q = new FLSqlQuery();
  q.setSelect("codsubfamilia");
  q.setFrom("subfamilias");
  q.setWhere(filtro);

  if (!q.exec()){
    return;
	}
  while (q.next()) {
    this.child("tableDBRecords").setPrimaryKeyChecked(q.value("codsubfamilia"), true);
  }
  this.child("tableDBRecords").refresh();
}

function oficial_deseleccionarTodo()
{
  this.child("tableDBRecords").clearChecked();
  this.child("tableDBRecords").refresh();
}

function oficial_imprimir()
{
	var _i = this.iface;
	var cursor = this.cursor()

	var clavesSeleccionadas = this.child("tableDBRecords").primarysKeysChecked();
	clavesSeleccionadas = clavesSeleccionadas.join("','");
	
  var q = new FLSqlQuery("qryem_stocksrutas");
  q.setWhere("subfamilias.codsubfamilia IN ('" + clavesSeleccionadas + "')");
	
	_i.lanzarInforme(q);
	this.close();
}

function oficial_lanzarInforme(q)
{
	var rptViewer = new FLReportViewer();
	rptViewer.setReportData(q);
	rptViewer.setReportTemplate("em_stocksrutas");
	rptViewer.renderReport();
	rptViewer.exec();
}

function oficial_encabezadoInforme()
{
	var hoy = new Date();
	var hora = hoy.toString().right(8);
	
	var texto = "Usuario: " + sys.nameUser() + "     Fecha: " + AQUtil.dateAMDtoDMA(hoy) + "  Hora: " + hora;
	
	return texto;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////