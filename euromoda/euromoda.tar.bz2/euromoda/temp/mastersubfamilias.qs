
/** @class_declaration euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
class euromoda extends oficial {
	var curSubfamilia_;
	var curTamano_;
	var curDibujo_;
	var curRuta_;
	function euromoda( context ) { oficial( context ); } 
	function init() {
		return this.ctx.euromoda_init();
	}
	function controlBusqueda() {
		return this.ctx.euromoda_controlBusqueda();
	}
	function copiarSubfamilia_clicked() {
		return this.ctx.euromoda_copiarSubfamilia_clicked();
	}
	function copiarSubfamilia(subFamOriginal) {
		return this.ctx.euromoda_copiarSubfamilia(subFamOriginal);
	}
	function copiarAnexosSubfamilias(subFamOriginal, nuevaSubfam, clonarDibujos) {
		return this.ctx.euromoda_copiarAnexosSubfamilias(subFamOriginal, nuevaSubfam, clonarDibujos);
	}
	function datosSubfamilia(cursor, campo) {
		return this.ctx.euromoda_datosSubfamilia(cursor, campo);
	}
	function copiarTablaTamanos(subFamOriginal, subFamNueva) {
		return this.ctx.euromoda_copiarTablaTamanos(subFamOriginal, subFamNueva);
	}
	function datosTamanos(cursor, campo) {
		return this.ctx.euromoda_datosTamanos(cursor, campo);
	}
	function copiarTablaDibujos(subFamOriginal, subFamNueva){
		return this.ctx.euromoda_copiarTablaDibujos(subFamOriginal, subFamNueva)
	}
	function datosDibujos(cursor, campo) {
		return this.ctx.euromoda_datosDibujos(cursor, campo);
	}
	function copiarTablaRutas(subFamOriginal, subFamNueva){
		return this.ctx.euromoda_copiarTablaRutas(subFamOriginal, subFamNueva)
	}
	function datosRutas(cursor, campo) {
		return this.ctx.euromoda_datosRutas(cursor, campo);
	}
	function anadirConfAlmacen(subFamOriginal, subFamNueva){
		return this.ctx.euromoda_anadirConfAlmacen(subFamOriginal, subFamNueva)
	}
}
//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	connect(this.child("toolButtonCopy"), "clicked()", _i, "copiarSubfamilia_clicked()");
	_i.controlBusqueda();
	

}

function euromoda_controlBusqueda()
{
	var _i = this.iface;
	
	var t = this.mainWidget().parentWidget().rtti();
// 	debug("Esto es un " + t);
	if (t != "FormSearchDB") {
		return true;
	}
	sys.runObjMethod(this, "tableDBRecords", "setOnlyTable", true);
// 	this.child("tableDBRecords").setOnlyTable(true);
	if (this.child("barraBotones")) {
		this.child("barraBotones").close();
	}
}

function euromoda_copiarSubfamilia_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (!cursor.isValid()) {
		return;
	}	
	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var curTransaccion = new FLSqlCursor("empresa");
	curTransaccion.transaction(false);

	if (!codSubfamilia) {
		flfactppal.iface.ponMsgError(sys.translate("No hay ningún registro seleccionado"),"warn",this);		
		return;
	}

	// Esto es para insertar en este cursor
	_i.curSubfamilia_ = this.cursor();
	disconnect(_i.curSubfamilia_, "bufferChanged(QString)", formRecordsubfamilias.iface, "bufferChanged");

	var nSub;
	try {
		nSub = _i.copiarSubfamilia(codSubfamilia);
		if (nSub) {
			curTransaccion.commit();
		} else {
			curTransaccion.rollback();
			flfactppal.iface.ponMsgError(sys.translate("Hubo un error al copiar la subfamilia %1").arg(codSubfamilia),"warn",this);			
			return;
		}
	} catch (e) {
		curTransaccion.rollback();
		flfactppal.iface.ponMsgError(sys.translate("Hubo un error al copiar el subfamilia %1").arg(codSubfamilia)+ ":\n" + e,"warn",this);			
		return;
	}

	var curS = this.cursor();
	curS.editRecord();


	return true;
}

function euromoda_copiarSubfamilia(subFamOriginal)
{
	var _i  = this.iface;

	var dialog = new Dialog;
	dialog.okButtonText = sys.translate("Aceptar");
	dialog.cancelButtonText = sys.translate("Cancelar");

	var codSub = new LineEdit;
	codSub.label = sys.translate("Introduzca la nueva subfamilia: ");
	dialog.add(codSub);

	var clonDib = new CheckBox;	
	clonDib.text = "Clonar los dibujos asociados";
	clonDib.checked = false;
	dialog.add( clonDib );	
	
	if(!dialog.exec() ) {
		return;
	}
	
	var subFamNueva = codSub.text;
	var clonarDibujos = clonDib.checked;	
	
	if (!subFamNueva || subFamNueva == "") {
		flfactppal.iface.ponMsgError(sys.translate("Debe introducir una subfamilia."),"warn",this);		
		return false;
	}

	if (AQUtil.sqlSelect("subfamilias", "codsubfamilia", "codsubfamilia = '" + subFamNueva + "'")) {
		flfactppal.iface.ponMsgError(sys.translate("Ya existe una subfamilia con ese código."),"warn",this);			
		return false;
	}

	var curSubfamiliaOrigen = new FLSqlCursor("subfamilias");
	curSubfamiliaOrigen.select("codsubfamilia = '" + subFamOriginal + "'");
	if (!curSubfamiliaOrigen.first()) {
		return false;
	}
	curSubfamiliaOrigen.setModeAccess(curSubfamiliaOrigen.Browse);
	curSubfamiliaOrigen.refreshBuffer();

	if (!_i.curSubfamilia_) {
		_i.curSubfamilia_ = new FLSqlCursor("subfamilias");
	}
	_i.curSubfamilia_.setModeAccess(_i.curSubfamilia_.Insert);
	_i.curSubfamilia_.refreshBuffer();
	_i.curSubfamilia_.setValueBuffer("codsubfamilia", subFamNueva);

	var campos = AQUtil.nombreCampos("subfamilias");
	var totalCampos = campos[0];
	for (var i = 1; i <= totalCampos; i++) {
		if (!_i.datosSubfamilia(curSubfamiliaOrigen, campos[i])) {
			return false;
		}
	}

	if (!_i.curSubfamilia_.commitBuffer()) {
		return false;
	}

	if (!_i.copiarAnexosSubfamilias(subFamOriginal, subFamNueva, clonarDibujos)) {
		return false;
	}

	return subFamNueva;
}

function euromoda_copiarAnexosSubfamilias(subFamOriginal, subFamNueva, clonarDibujos)
{
	var _i = this.iface;
	//tamaños	
	if(!_i.copiarTablaTamanos(subFamOriginal, subFamNueva)) {
		return false;
	}	
	//si check dibujos
	if(clonarDibujos) {
		if(!_i.copiarTablaDibujos(subFamOriginal, subFamNueva)) {
			return false;
		}
	}
	//rutas	
	if(!_i.copiarTablaRutas(subFamOriginal, subFamNueva)) {
		return false;
	}
	// comprobar en configuraconn: En caso de que la subfamilia origen esta en alguna de las listas del formulario Configuracion de Almacén (Subfamilia de estampado generico, Subfamilias por piezas, ...la nueva subfamilia se incluira en la misma lista.
	if(!_i.anadirConfAlmacen(subFamOriginal, subFamNueva)) {
		return false;
	}
	return true;
}

function euromoda_datosSubfamilia(cursor, campo) 
{
	var _i = this.iface;
	if (!campo || campo == "") {
		return false;
	}
	switch (campo) {
		case "codsubfamilia": {
			return true;
			break;
		}		
		default: {
			if (cursor.isNull(campo)) {
				_i.curSubfamilia_.setNull(campo);
			} else {
				_i.curSubfamilia_.setValueBuffer(campo, cursor.valueBuffer(campo));
			}
		}
	}
	return true;
}

function euromoda_copiarTablaTamanos(subFamOriginal, subFamNueva)
{
	var _i = this.iface;
	if (!_i.curTamano_) {
		_i.curTamano_ = new FLSqlCursor("em_tamanossubfam");
	}
	
	var campos = AQUtil.nombreCampos("em_tamanossubfam");
	var totalCampos = campos[0];

	var curTamanoOrigen = new FLSqlCursor("em_tamanossubfam");
	curTamanoOrigen.select("codsubfamilia = '" + subFamOriginal + "'");
	while (curTamanoOrigen.next()) {
		_i.curTamano_.setModeAccess(_i.curTamano_.Insert);
		_i.curTamano_.refreshBuffer();
		_i.curTamano_.setValueBuffer("codsubfamilia", subFamNueva);
	
		for (var i = 1; i <= totalCampos; i++) {
			if (!_i.datosTamanos(curTamanoOrigen, campos[i])) {
				return false;
			}
		}
		if (!_i.curTamano_.commitBuffer()) {
			return false;
		}
	}
	return true;
}

function euromoda_datosTamanos(cursor, campo) 
{
	var _i = this.iface;
	if (!campo || campo == "") {
		return false;
	}
	switch (campo) {
		case "idtamanosubfam":
		case "codsubfamilia": {
			return true;
			break;
		}
		default: {
			if (cursor.isNull(campo)) {
				_i.curTamano_.setNull(campo);
			} else {
				_i.curTamano_.setValueBuffer(campo, cursor.valueBuffer(campo));
			}
		}
	}
	return true;
}

function euromoda_copiarTablaDibujos(subFamOriginal, subFamNueva)
{
	
	var _i = this.iface;
	if (!_i.curDibujo_) {
		_i.curDibujo_ = new FLSqlCursor("em_dibujossubfam");
	}
	
	var campos = AQUtil.nombreCampos("em_dibujossubfam");
	var totalCampos = campos[0];

	var curDibujoOrigen = new FLSqlCursor("em_dibujossubfam");
	curDibujoOrigen.select("codsubfamilia = '" + subFamOriginal + "'");
	while (curDibujoOrigen.next()) {
		_i.curDibujo_.setModeAccess(_i.curDibujo_.Insert);
		_i.curDibujo_.refreshBuffer();
		_i.curDibujo_.setValueBuffer("codsubfamilia", subFamNueva);
	
		for (var i = 1; i <= totalCampos; i++) {
			if (!_i.datosDibujos(curDibujoOrigen, campos[i])) {
				return false;
			}
		}
		if (!_i.curDibujo_.commitBuffer()) {
			return false;
		}
	}
	return true;
}

function euromoda_datosDibujos(cursor, campo) 
{
	var _i = this.iface;
	if (!campo || campo == "") {
		return false;
	}
	switch (campo) {
		case "iddibujosubfam":
		case "codsubfamilia": {
			return true;
			break;
		}
		default: {
			if (cursor.isNull(campo)) {
				_i.curDibujo_.setNull(campo);
			} else {
				_i.curDibujo_.setValueBuffer(campo, cursor.valueBuffer(campo));
			}
		}
	}
	return true;
}

function euromoda_copiarTablaRutas(subFamOriginal, subFamNueva)
{	
	var _i = this.iface;
	if (!_i.curRuta_) {
		_i.curRuta_ = new FLSqlCursor("em_rutastpsubfam");
	}
	
	var campos = AQUtil.nombreCampos("em_rutastpsubfam");
	var totalCampos = campos[0];

	var curRutaOrigen = new FLSqlCursor("em_rutastpsubfam");
	curRutaOrigen.select("codsubfamilia = '" + subFamOriginal + "'");
	while (curRutaOrigen.next()) {
		_i.curRuta_.setModeAccess(_i.curRuta_.Insert);
		_i.curRuta_.refreshBuffer();
		_i.curRuta_.setValueBuffer("codsubfamilia", subFamNueva);
	
		for (var i = 1; i <= totalCampos; i++) {
			if (!_i.datosRutas(curRutaOrigen, campos[i])) {
				return false;
			}
		}
		if (!_i.curRuta_.commitBuffer()) {
			return false;
		}
	}
	return true;
}

function euromoda_datosRutas(cursor, campo) 
{
	var _i = this.iface;
	if (!campo || campo == "") {
		return false;
	}
	switch (campo) {
		case "idrutatp":
		case "codsubfamilia": {
			return true;
			break;
		}
		default: {
			if (cursor.isNull(campo)) {
				_i.curRuta_.setNull(campo);
			} else {
				_i.curRuta_.setValueBuffer(campo, cursor.valueBuffer(campo));
			}
		}
	}
	return true;
}

function euromoda_anadirConfAlmacen(subFamOriginal, subFamNueva)
{
	var _i = this.iface;
	subFamNueva = ","+subFamNueva;
	if(flfactalma.iface.pub_esSubfamiliaCrudo(subFamOriginal)) {
		debug("entra en crudo");
		if (!AQUtil.execSql("update factalma_general set codsubfamiliacrudo = codsubfamiliacrudo  ||  '" + subFamNueva + "'")) {
			return false;
		}		
	}

	if(flfactalma.iface.pub_esSubfamEstampadoGen(subFamOriginal)) {
		debug("entra en esSubfamEstampadoGen");
		if (!AQUtil.execSql("update factalma_general set subfamestampadogen = subfamestampadogen  ||  '" + subFamNueva + "'")) {
			return false;
		}		
	}

	if(flfactalma.iface.pub_esSubfamiliaEstampado(subFamOriginal)) {
		debug("entra en esSubfamiliaEstampado");
		if (!AQUtil.execSql("update factalma_general set codsubfamiliaestampado = codsubfamiliaestampado  ||  '" + subFamNueva + "'")) {
			return false;
		}		
	}
	
	if(flfactalma.iface.pub_esSubfamiliaLaminas(subFamOriginal)) {
		debug("entra en esSubfamiliaLaminas");
		if (!AQUtil.execSql("update factalma_general set codsubfamilialaminas = codsubfamilialaminas  || '" + subFamNueva + "'")) {
			return false;
		}		
	}	
	return true;	
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
