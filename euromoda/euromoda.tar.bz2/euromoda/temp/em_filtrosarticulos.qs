/***************************************************************************
                 em_filtrosarticulos.qs  -  description
                             -------------------
    begin                : mie nov 23 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  function oficial(context)
  {
    interna(context);
  }
  function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
  function construirFiltro(cursor) {
	  return this.ctx.oficial_construirFiltro(cursor);
  }
  function construirFiltroVista(cursor) {
	  return this.ctx.oficial_construirFiltroVista(cursor);
  }
  function construirFiltroAlmacen(cursor) {
	  return this.ctx.oficial_construirFiltroAlmacen(cursor);
  }
  function construirFiltroAlmacenVista(cursor) {
	  return this.ctx.oficial_construirFiltroAlmacenVista(cursor);
  }
  function tbnLimpiarFiltro_clicked() {
	  return this.ctx.oficial_tbnLimpiarFiltro_clicked();
  }
  function limpiarFiltro(form) {
	  return this.ctx.oficial_limpiarFiltro(form);
  }
  function dameOperando(operando) {
  	return this.ctx.oficial_dameOperando(operando);
  }

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
  function pub_construirFiltro(cursor) {
		return this.construirFiltro(cursor);
	}
	function pub_limpiarFiltro(form) {
		return this.limpiarFiltro(form);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;

  connect(this.cursor(), "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
  connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_construirFiltro(cursor)
{
	var _i = this.iface;
	var filtro = "";

	var referencia = cursor.valueBuffer("referencia");
	//A�adido 15/02/2018 , para Estad�sticas Compra
	var refArtProv = AQUtil.sqlSelect("articulosprov","referencia","refproveedor = '" + cursor.valueBuffer("refproveedor") + "' AND codproveedor = '" + cursor.valueBuffer("codproveedor") + "' AND refproveedor IS NOT NULL");	
	if(refArtProv && refArtProv != ""){
		if(referencia && referencia != "") {
			referencia = referencia + "," + refArtProv;	
		} else {
			referencia = refArtProv;
		}
		
	}
	//Fin
	debug("referencia: "+referencia);
	if (referencia && referencia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (referencia.find(",") >= 0) {
			filtro += ("articulos.referencia IN ('" + referencia.split(",").join("', '") + "')");
		} else {
			if (referencia.find("-") >= 0) {
				var min = referencia.split("-")[0];
				var max = referencia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					//filtro += ("articulos.referencia SIMILAR TO '[0-9]+' AND CAST(articulos.referencia AS INTEGER) BETWEEN '" + min + "' AND '" + max + "'");
					filtro += ("articulos.referencia >=  '" + min + "' AND articulos.referencia <= '" + max + "' AND length(articulos.referencia) >= length('" + min + "') AND length(articulos.referencia) <= length('" + max + "')");
				}
			} else {
				filtro += "articulos.referencia = '" + referencia + "'";
			}
		}
	}

	var tamano = cursor.valueBuffer("codtamanoem");
	debug("tamano: "+tamano);
	if(tamano && tamano != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.codtamanoem = '" + tamano + "'";
	}

	var color = cursor.valueBuffer("codcolorem");
	debug("color: "+color);
	if(color && color != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.codcolorem = '" + color + "'";
	}

	var familia = cursor.valueBuffer("codfamilia");
	debug("familia: "+familia);
	if (familia && familia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (familia.find(",") >= 0) {
			filtro += ("articulos.codfamilia IN ('" + familia.split(",").join("', '") + "')");
		} else {
			if (familia.find("-") >= 0) {
				var min = familia.split("-")[0];
				var max = familia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.codfamilia IN (SELECT familias.codfamilia FROM familias WHERE familias.codfamilia SIMILAR TO '[0-9]+' AND CAST(familias.codfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.codfamilia = '" + familia + "'";
			}
		}
	}

	var subFamilia = cursor.valueBuffer("codsubfamilia");
	debug("subFamilia: "+subFamilia);
	if(subFamilia && subFamilia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (subFamilia.find(",") >= 0) {
			filtro += ("articulos.codsubfamilia IN ('" + subFamilia.split(",").join("', '") + "')");
		} else {
			if (subFamilia.find("-") >= 0) {
				var min = subFamilia.split("-")[0];
				var max = subFamilia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.codsubfamilia IN (SELECT subfamilias.codsubfamilia FROM subfamilias WHERE subfamilias.codsubfamilia SIMILAR TO '[0-9]+' AND CAST(subfamilias.codsubfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.codsubfamilia = '" + subFamilia + "'";
			}
		}
	}

// 	var dibujo = cursor.valueBuffer("coddibestamp");
// 	if (dibujo && dibujo != "") {
// 		if (filtro != "") {
// 			filtro += " AND ";
// 		}
// 		filtro += "coddibestamp = " + dibujo;
// 	}

	var dibujos = cursor.valueBuffer("dibujos");
	debug("dibujos: "+dibujos);
	if (dibujos && dibujos != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (dibujos.find(",") >= 0) {
			filtro += ("articulos.coddibestamp IN (" + dibujos + ")");
		} else {
			if (dibujos.find("-") >= 0) {
				var min = dibujos.split("-")[0];
				var max = dibujos.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.coddibestamp IN (SELECT em_dibujos.coddibujoem FROM em_dibujos WHERE em_dibujos.coddibujoem  BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.coddibestamp = " + dibujos;
			}
		}
	}
// 		if(filtro != "")
// 			filtro += " AND ";
// 		filtro += "coddibestamp = '" + dibujo + "'";
// 	}

	var coleccion = cursor.valueBuffer("codcoleccionem");
	debug("coleccion: "+subFamilia);
	if (coleccion && coleccion != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (coleccion.find(",") >= 0) {
			filtro += ("articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem IN ('" + coleccion.split(",").join("', '") + "'))");
		} else {
			if (coleccion.find("-") >= 0) {
				var min = coleccion.split("-")[0];
				var max = coleccion.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart WHERE em_coleccionesart.codcoleccionem SIMILAR TO '[0-9]+' AND  CAST(em_coleccionesart.codcoleccionem AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem = '" + coleccion + "')";
			}
		}
	}

	var refCliente = cursor.valueBuffer("aliasart");
	debug("refCliente: "+refCliente);
	if(refCliente && refCliente != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.aliasart = '" + refCliente + "'";
	}

	var refComponente = cursor.valueBuffer("refcomponente");
	debug("refComponente: "+refComponente);
	if (refComponente && refComponente != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "articulos.referencia IN (SELECT articuloscomp.refcompuesto FROM articuloscomp WHERE articuloscomp.refcomponente = '" + refComponente + "')";
	}

	var descatalogado = cursor.valueBuffer("descatalogado");
	debug("descatalogado: "+descatalogado);
	if (descatalogado && descatalogado != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (descatalogado){
			case "No": {
				filtro += "NOT articulos.descatalogado";
				break;
			}
			default:
				filtro += "articulos.descatalogado";
				break;
		}
	}

	var deBaja = cursor.valueBuffer("debaja");
	debug("deBaja: "+deBaja);
	if (deBaja && deBaja != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (deBaja){
			case "No": {
				filtro += "NOT articulos.debaja";
				break;
			}
			default:
				filtro += "articulos.debaja";
				break;
		}
	}

	var aLiquidar = cursor.valueBuffer("aliquidar");
	debug("aLiquidar: "+aLiquidar);
	if (aLiquidar && aLiquidar != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (aLiquidar){
			case "No": {
				filtro += "articulos.fechaliq is null";
				break;
			}
			default:
				filtro += "articulos.fechaliq is not null";
				break;
		}
	}

	/********************************** AMPLIACION P0052D Costes e inventsario ***************/

	var descatalogadoF = cursor.valueBuffer("descatalogadof");
	debug("descatalogadoF: "+descatalogadoF);
	if (descatalogadoF && descatalogadoF != "N/A"){
		if (filtro != "") {
			filtro += " AND ";
		}
		if(descatalogadoF == "No") {
			filtro += "NOT articulos.descatalogado";	
		} else {
			filtro += "articulos.descatalogado";
			var fechaDesF = cursor.valueBuffer("fechadesf");
			debug("fechaDesF: "+fechaDesF);
			if(fechaDesF && fechaDesF != "") {
				filtro += " AND articulos.fechades = '" + fechaDesF + "'";
			}			
		}	
	}

	var deBajaF = cursor.valueBuffer("debajaf");
	debug("deBajaF: "+deBajaF);
	if (deBajaF && deBajaF != "N/A"){
		if (filtro != "") {
			filtro += " AND ";
		}
		if (deBajaF == "No"){			
			filtro += "NOT articulos.debaja";
		} else {
			filtro += "articulos.debaja";
			var fechaFajaF = cursor.valueBuffer("fechabajaf");
			debug("fechaFajaF: "+fechaFajaF);
			if(fechaFajaF && fechaFajaF != "") {
				filtro += " AND articulos.fechabaja = '" + fechaFajaF + "'";
			}	
		
		}
	}

	var aLiquidarF = cursor.valueBuffer("aliquidarf");
	debug("aLiquidarF: "+aLiquidarF);
	if (aLiquidarF && aLiquidarF != "N/A"){
		if (filtro != "") {
			filtro += " AND ";
		}
		if (aLiquidarF == "No"){
			filtro += "articulos.fechaliq is null";
			
		} else {			
			filtro += "articulos.fechaliq is not null";		
			var fechaLiqF = cursor.valueBuffer("fechaliqf");
			debug("fechaLiqF: "+fechaLiqF);
			if(fechaLiqF && fechaLiqF != "") {
				filtro += " AND articulos.fechaliq = '" + fechaLiqF + "'";
			}	
		}
	}

	var fechaAltaF = cursor.valueBuffer("fechaaltaf");
	debug("fechaAltaF: "+fechaAltaF);
	if(fechaAltaF && fechaAltaF != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += " articulos.fechaalta < '" + fechaAltaF + "'";
	}

	var fechaUltVtaF = cursor.valueBuffer("fechaultvtaf");
	debug("fechaUltVtaF: "+fechaUltVtaF);
	if(fechaUltVtaF && fechaUltVtaF != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += " articulos.em_fechaultventa < '" + fechaUltVtaF + "'";
	}

	var descripcionComoF = cursor.valueBuffer("descripcioncomof");
	debug("descripcionComoF: "+descripcionComoF);
	if(descripcionComoF && descripcionComoF != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += " UPPER(articulos.descripcion) like '%" + descripcionComoF.toUpperCase() + "%'";
	}

	var tipoCosteF = cursor.valueBuffer("em_tipocostef");
	debug("tipoCosteF: "+tipoCosteF);
	if(tipoCosteF && tipoCosteF != "Todos") {
		if (filtro != "") {
			filtro += " AND ";
		}		
		filtro += " articulos.em_tipocoste = '" + tipoCosteF + "'";		
	}

	var tipoMargenF = cursor.valueBuffer("em_tipomargenf");
	debug("tipoMargenF: "+tipoMargenF);
	if(tipoMargenF && tipoMargenF != "Todos") {
		if (filtro != "") {
			filtro += " AND ";
		}		
		filtro += " articulos.em_tipomargen = '" + tipoMargenF + "'";		
	}

	var conCosteF = cursor.valueBuffer("concostef");
	debug("conCosteF: "+conCosteF);
	if(conCosteF) {
		if (filtro != "") {
			filtro += " AND ";
		}	
		var costeProdF = cursor.valueBuffer("em_costeprodf");
		debug("costeProdF: "+costeProdF);

		if(costeProdF && costeProdF != "" && !cursor.isNull("em_costeprodf")) {
			var operCosteF = cursor.valueBuffer("opercostef");
			debug("operCosteF: "+operCosteF);
			operCosteF = _i.dameOperando(operCosteF);			
			debug("operCosteF: "+operCosteF);
			filtro += " articulos.em_costeprod IS NOT NULL AND articulos.em_costeprod " + operCosteF + costeProdF;
			
		} else {
			filtro += " articulos.em_costeprod IS NOT NULL";
		}
	}
	var sinCosteF = cursor.valueBuffer("sincostef");
	debug("sinCosteF: "+sinCosteF);
	if(sinCosteF) {
		if (filtro != "") {
			filtro += " AND ";
		}	
		filtro += " articulos.em_costeprod IS NULL";
	}

	var conMargenF = cursor.valueBuffer("conmargenf");
	debug("conMargenF: "+conMargenF);
	if(conMargenF) {
		if (filtro != "") {
			filtro += " AND ";
		}	
		var margenProdF = cursor.valueBuffer("em_margenprodf");
		debug("margenProdF: "+margenProdF);

		if(margenProdF && margenProdF != "" && !cursor.isNull("em_margenprodf")) {
			var operMargenF = cursor.valueBuffer("opermargenf");
			debug("operMargenF: "+operMargenF);
			operMargenF = _i.dameOperando(operMargenF);			
			debug("operMargenF: "+operMargenF);
			filtro += " articulos.em_margenprod IS NOT NULL AND articulos.em_margenprod " + operMargenF + margenProdF;
			
		} else {
			filtro += " articulos.em_margenprod IS NOT NULL";
		}
	}

	var sinMargenF = cursor.valueBuffer("sinmargenf");
	debug("sinMargenF: "+sinMargenF);
	if(sinMargenF) {
		if (filtro != "") {
			filtro += " AND ";
		}	
		filtro += " articulos.em_margenprod IS NULL";
	}

	var codAlmacenF = cursor.valueBuffer("codalmacenf");
	debug("codAlmacenF: "+codAlmacenF);

	var conExisF = cursor.valueBuffer("conexispterecf");
	debug("conExisF: "+conExisF);

	var sinStockF = cursor.valueBuffer("sinstockf");
	debug("sinStockF: "+sinStockF);
	if(codAlmacenF && codAlmacenF!= "") {
		if(conExisF) {
			if (filtro != "") {
				filtro += " AND ";
			}
			if (codAlmacenF.find(",") >= 0) {
				filtro += ("articulos.referencia IN (SELECT stocks.referencia from stocks WHERE (stocks.cantidad <> 0 OR stocks.pterecibir <>0 OR stocks.afaltas <>0) AND stocks.codalmacen IN ('" + codAlmacenF.split(",").join("', '") + "'))");
			} else {
				if (codAlmacenF.find("-") >= 0) {
					var min = codAlmacenF.split("-")[0];
					var max = codAlmacenF.split("-")[1];
					if (!isNaN(min) && !isNaN(min)) {
						filtro += ("articulos.referencia IN (SELECT stocks.referencia from stocks WHERE (stocks.cantidad <> 0 OR stocks.pterecibir <>0 OR stocks.afaltas <>0) AND stocks.codalmacen SIMILAR TO '[0-9]+' AND  CAST(stocks.codalmacen AS INTEGER) BETWEEN " + min + " AND " + max + ")");
					}
				} else {
					filtro += "articulos.referencia IN (SELECT stocks.referencia from stocks WHERE (stocks.cantidad <> 0 OR stocks.pterecibir <>0 OR stocks.afaltas <>0) AND stocks.codalmacen = '" + codAlmacenF + "')";
				}
			}
		}
		if(sinStockF) {
			if (filtro != "") {
				filtro += " AND ";
			}
			if (codAlmacenF.find(",") >= 0) {
				filtro += ("articulos.referencia IN (SELECT stocks.referencia from stocks WHERE (stocks.cantidad IS NULL OR stocks.cantidad = 0) AND stocks.codalmacen IN ('" + codAlmacenF.split(",").join("', '") + "'))");
			} else {
				if (codAlmacenF.find("-") >= 0) {
					var min = codAlmacenF.split("-")[0];
					var max = codAlmacenF.split("-")[1];
					if (!isNaN(min) && !isNaN(min)) {
						filtro += ("articulos.referencia IN (SELECT stocks.referencia from stocks WHERE (stocks.cantidad IS NULL OR stocks.cantidad = 0) AND stocks.codalmacen SIMILAR TO '[0-9]+' AND  CAST(stocks.codalmacen AS INTEGER) BETWEEN " + min + " AND " + max + ")");
					}
				} else {
					filtro += "articulos.referencia IN (SELECT stocks.referencia from stocks WHERE (stocks.cantidad IS NULL OR stocks.cantidad = 0) AND stocks.codalmacen = '" + codAlmacenF + "')";
				}
			}
		}
	} else {
		if(conExisF) {
			if (filtro != "") {
				filtro += " AND ";
			}
			filtro += " articulos.referencia IN (SELECT stocks.referencia FROM stocks INNER JOIN almacenes ON almacenes.codalmacen = stocks.codalmacen WHERE almacenes.em_tipoalmacen = 'Interno' AND ( stocks.cantidad <> 0 OR stocks.pterecibir <>0 OR stocks.afaltas <>0))";
		}

		if(sinStockF) {
			if (filtro != "") {
				filtro += " AND ";
			}
			filtro += " articulos.referencia IN (SELECT stocks.referencia FROM stocks INNER JOIN almacenes ON almacenes.codalmacen = stocks.codalmacen WHERE almacenes.em_tipoalmacen = 'Interno' AND (stocks.cantidad IS NULL OR stocks.cantidad = 0))";
		}
	}

	/********************************************************************************************/

	debug("Filtro " + filtro);
	return filtro;
}
function oficial_construirFiltroVista(cursor)
{
	var filtro = "";

	var referencia = cursor.valueBuffer("referencia");
	if (referencia && referencia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (referencia.find(",") >= 0) {
			filtro += ("v_stocksext.referencia IN ('" + referencia.split(",").join("', '") + "')");
		} else {
			if (referencia.find("-") >= 0) {
				var min = referencia.split("-")[0];
				var max = referencia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					//filtro += ("v_stocksext.referencia SIMILAR TO '[0-9]+' AND CAST(v_stocksext.referencia AS INTEGER) BETWEEN '" + min + "' AND '" + max + "'");
					filtro += ("v_stocksext.referencia >=  '" + min + "' AND v_stocksext.referencia <= '" + max + "' AND length(v_stocksext.referencia) >= length('" + min + "') AND length(v_stocksext.referencia) <= length('" + max + "')");
				}
			} else {
				filtro += "v_stocksext.referencia = '" + referencia + "'";
			}
		}
	}

	var tamano = cursor.valueBuffer("codtamanoem");
	if(tamano && tamano != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "v_stocksext.codtamanoem = '" + tamano + "'";
	}

	var color = cursor.valueBuffer("codcolorem");
	if(color && color != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "v_stocksext.codcolorem = '" + color + "'";
	}

	var familia = cursor.valueBuffer("codfamilia");
	if (familia && familia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (familia.find(",") >= 0) {
			filtro += ("v_stocksext.codfamilia IN ('" + familia.split(",").join("', '") + "')");
		} else {
			if (familia.find("-") >= 0) {
				var min = familia.split("-")[0];
				var max = familia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_stocksext.codfamilia IN (SELECT familias.codfamilia FROM familias WHERE familias.codfamilia SIMILAR TO '[0-9]+' AND CAST(v_stocksext.codfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");					
				}
			} else {
				filtro += "v_stocksext.codfamilia = '" + familia + "'";
			}
		}
	}

	var subFamilia = cursor.valueBuffer("codsubfamilia");
	if(subFamilia && subFamilia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (subFamilia.find(",") >= 0) {
			filtro += ("v_stocksext.codsubfamilia IN ('" + subFamilia.split(",").join("', '") + "')");
		} else {
			if (subFamilia.find("-") >= 0) {
				var min = subFamilia.split("-")[0];
				var max = subFamilia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_stocksext.codsubfamilia IN (SELECT subfamilias.codsubfamilia FROM subfamilias WHERE subfamilias.codsubfamilia SIMILAR TO '[0-9]+' AND CAST(subfamilias.codsubfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");				
				}
			} else {
				filtro += "v_stocksext.codsubfamilia = '" + subFamilia + "'";
			}
		}
	}

// 	var dibujo = cursor.valueBuffer("coddibestamp");
// 	if (dibujo && dibujo != "") {
// 		if (filtro != "") {
// 			filtro += " AND ";
// 		}
// 		filtro += "coddibestamp = " + dibujo;
// 	}

	var dibujos = cursor.valueBuffer("dibujos");
	if (dibujos && dibujos != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (dibujos.find(",") >= 0) {
			filtro += ("v_stocksext.coddibestamp IN (" + dibujos + ")");
		} else {
			if (dibujos.find("-") >= 0) {
				var min = dibujos.split("-")[0];
				var max = dibujos.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_stocksext.coddibestamp IN (SELECT em_dibujos.coddibujoem FROM em_dibujos WHERE em_dibujos.coddibujoem  BETWEEN " + min + " AND " + max + ")");
				
				}
			} else {
				filtro += "v_stocksext.coddibestamp = " + dibujos;
			}
		}
	}
// 		if(filtro != "")
// 			filtro += " AND ";
// 		filtro += "coddibestamp = '" + dibujo + "'";
// 	}

	var coleccion = cursor.valueBuffer("codcoleccionem");
	
	if (coleccion && coleccion != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (coleccion.find(",") >= 0) {
			filtro += ("v_stocksext.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem IN ('" + coleccion.split(",").join("', '") + "'))");			
		} else {
			if (coleccion.find("-") >= 0) {
				var min = coleccion.split("-")[0];
				var max = coleccion.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_stocksext.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart WHERE em_coleccionesart.codcoleccionem SIMILAR TO '[0-9]+' AND  CAST(em_coleccionesart.codcoleccionem AS INTEGER) BETWEEN " + min + " AND " + max + ")");					
				}
			} else {
				filtro += "v_stocksext.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem = '" + coleccion + "')";				
			}
		}
	}

	var refCliente = cursor.valueBuffer("aliasart");
	if(refCliente && refCliente != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "v_stocksext.aliasart = '" + refCliente + "'";
	}

	var refComponente = cursor.valueBuffer("refcomponente");
	if (refComponente && refComponente != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "v_stocksext.referencia IN (SELECT articuloscomp.refcompuesto FROM articuloscomp WHERE articuloscomp.refcomponente = '" + refComponente + "')";
	}

	var descatalogado = cursor.valueBuffer("descatalogado");
	if (descatalogado && descatalogado != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (descatalogado){
			case "No": {
				filtro += "NOT v_stocksext.descatalogado";
				break;
			}
			default:
				filtro += "v_stocksext.descatalogado";
				break;
		}
	}

	var deBaja = cursor.valueBuffer("debaja");
	if (deBaja && deBaja != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (deBaja){
			case "No": {
				filtro += "NOT v_stocksext.debaja";
				break;
			}
			default:
				filtro += "v_stocksext.debaja";
				break;
		}
	}

	var aLiquidar = cursor.valueBuffer("aliquidar");
	if (aLiquidar && aLiquidar != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (aLiquidar){
			case "No": {
				filtro += "v_stocksext.fechaliq is null";
				break;
			}
			default:
				filtro += "v_stocksext.fechaliq is not null";
				break;
		}
	}

	debug("Filtro " + filtro);
	return filtro;
}
function oficial_construirFiltroAlmacen(cursor)
{
	var filtro = "";

	var codAlmacen = cursor.valueBuffer("codalmacen");
	if (codAlmacen && codAlmacen != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "stocks.codalmacen = '" + codAlmacen + "'";
	}
	
	var conFaltas = cursor.valueBuffer("confaltas");
	if (conFaltas) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "stocks.afaltas > 0";
	}
	
	var conNecesidad = cursor.valueBuffer("connecesidad");
	if (conNecesidad) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "stocks.necesidad > 0";
	}
	
	var conDisponible = cursor.valueBuffer("condisponible");
	if (conDisponible) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "(stocks.disponible > 0 OR stocks.disponiblepterecibir > 0)";
	}

debug("Filtro " + filtro);
	return filtro;
}
function oficial_construirFiltroAlmacenVista(cursor)
{
	var filtro = "";

	var codAlmacen = cursor.valueBuffer("codalmacen");
	if (codAlmacen && codAlmacen != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "v_stocksext.codalmacen = '" + codAlmacen + "'";
	}
	
	var conFaltas = cursor.valueBuffer("confaltas");
	if (conFaltas) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "v_stocksext.afaltas > 0";
	}
	
	var conNecesidad = cursor.valueBuffer("connecesidad");
	if (conNecesidad) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "v_stocksext.necesidad > 0";
	}
	
	var conDisponible = cursor.valueBuffer("condisponible");
	if (conDisponible) {
		filtro += (filtro != "") ? " AND " : "";
		filtro += "(v_stocksext.disponible > 0 OR v_stocksext.disponiblepterecibir > 0)";
	}

debug("Filtro " + filtro);
	return filtro;
}
function oficial_bufferChanged(fN)
{
	var cursor = this.cursor();
	switch(fN) {
		case "coddibestamp":{
			cursor.setValueBuffer("dibujos", cursor.valueBuffer("coddibestamp"));
			break;
		}
	}
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var accion = cursor.valueBuffer("accion");
	debug("accion: "+accion);
	var filtro;
	var filtroA;
	if(accion == "v_stocksext") {
		filtro = _i.construirFiltroVista(cursor);
	} else {
	
		filtro = _i.construirFiltro(cursor);
	}
	
	if (!filtro) {
		filtro = "";
	}
	cursor.setValueBuffer("filtro", filtro);
	if(accion == "v_stocksext") {
		filtroA = _i.construirFiltroAlmacenVista(cursor);
	} else {	
		filtroA = _i.construirFiltroAlmacen(cursor);
	}
	if (!filtroA) {
		filtroA = "";
	}
	cursor.setValueBuffer("filtroalmacen", filtroA);
	this.obj().accept();
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var cursor = miForm.cursor();
	var campos = "fdbReferencia,fdbDesArticulo,fdbFamilia,fdbDescFamilia,fdbSubfamilia,fdbDescSubfamilia,fdbColeccion,fdbDescColeccion,fdbDibujo,fdbDibujos,fdbDescDibujo,fdbRefComponente,fdbDesComponente,fdbTamano,fdbColor,fdbRefCliente,fdbCodAlmacen,fdbAlmacen,fdbConFaltas,fdbConNecesidad,fdbConDisponible";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(miForm, aCampos[i], "");
	}
	cursor.setNull("coddibestamp");
	cursor.setValueBuffer("descatalogado", "Todos");
	cursor.setValueBuffer("debaja", "Todos");
	cursor.setValueBuffer("aliquidar", "Todos");

	debug("dibujo " + cursor.valueBuffer("coddibestamp"));
}

function oficial_dameOperando(operando)
{
	var oper = "";
	if(operando == "Igual") {
		oper = " = ";
	} else if(operando == "Distinto") {
		oper = " <> ";
	} else if(operando == "Menor") {
		oper = " < ";
	} else if(operando == "Menor o igual") {
		oper = " <= ";
	} else if(operando == "Mayor") {
		oper = " > ";
	} else if(operando == "Mayor o igual") {
		oper = " >= ";	
	}
	return oper;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
