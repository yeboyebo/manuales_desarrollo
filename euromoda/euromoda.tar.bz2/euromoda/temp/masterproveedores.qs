
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function tbnCompruebaSaldos_clicked() {
		return this.ctx.euromoda_tbnCompruebaSaldos_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	connect(this.child("tbnCompruebaSaldos"), "clicked()", _i, "tbnCompruebaSaldos_clicked");
}

function euromoda_tbnCompruebaSaldos_clicked()
{
	var cursor = new FLSqlCursor("proveedores");
	cursor.select("1 = 1");
	AQUtil.createProgressDialog(sys.translate("Comprobando saldos"), cursor.size());
	var p = 0;
	var saldoConta, saldoFact, sRec, sAnt, sPar;
// 	var codSubcuenta;
	var _fC = formRecordproveedores.iface;
	var lista = "";
	var subcuentas;
	while (cursor.next()) {
		AQUtil.setProgress(p++);
		cursor.setModeAccess(cursor.Edit);
		cursor.refreshBuffer();
		subcuentas = _fC.commonCalculateField("listasubcuentas", cursor);
// 		codSubcuenta = _fC.commonCalculateField("codsubcuenta", cursor);
// 		cursor.setValueBuffer("codsubcuenta", codSubcuenta);
		saldoConta = _fC.commonCalculateField("saldoanticipos", cursor);
		cursor.setValueBuffer("saldoanticipos",saldoConta);
		sRec = AQUtil.sqlSelect("recibosprov", "SUM(importeeuros)", "codproveedor = '" + cursor.valueBuffer("codproveedor") + "' AND " + _fC.dameWhereRecibosSaldo());
		sRec = isNaN(sRec) ? 0 : sRec;
		sAnt = AQUtil.sqlSelect("anticiposprov", "SUM(pendienteeuros)", "codproveedor = '" + cursor.valueBuffer("codproveedor") + "' AND pendienteeuros <> 0");
		sAnt = isNaN(sAnt) ? 0 : sAnt;
		sPar = AQUtil.sqlSelect("co_partidas", "SUM(importependiente)", "codproveedor = '" + cursor.valueBuffer("codproveedor") + "' AND importependiente <> 0 AND codsubcuenta IN (" + subcuentas + ")");
		sPar = isNaN(sPar) ? 0 : sPar;
		saldoFact = sAnt - sRec + sPar;
		debug("sRec = " + sRec + ", sAnt = " + sAnt + ", sPar = " + sPar);
// 		saldoFact = Math.round(saldoFact);
// 		saldoConta = Math.round(saldoConta);
		debug("saldoFact " + saldoFact + " = saldoConta " + saldoConta);
		if (saldoFact != saldoConta) {
			if (Math.abs(saldoFact - saldoConta) < 0.01) continue
			lista += ("\n" + cursor.valueBuffer("codproveedor") + "- " + cursor.valueBuffer("nombre") + "SF " + saldoFact + " SC " + saldoConta);
// 			AQUtil.destroyProgressDialog();
// 			MessageBox.warning(sys.translate("Los saldos del codproveedor  %1 - %2 no coinciden").arg(cursor.valueBuffer("codproveedor")).arg(cursor.valueBuffer("nombre")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 			return false;
		}
		if(!cursor.commitBuffer()) {
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	if (lista != "") {
		MessageBox.warning(sys.translate("Los saldos de los siguientes proveedores no coinciden:%1").arg(lista), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	} else {
		MessageBox.information(sys.translate("Comprobaci�n completada. No hay desajustes."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
