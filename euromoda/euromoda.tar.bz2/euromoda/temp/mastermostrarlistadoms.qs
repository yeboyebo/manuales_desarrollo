
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function identificarDocumento(qry) {
		return this.ctx.euromoda_identificarDocumento(qry);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_identificarDocumento(qry)
{
	var _i = this.iface;
	return _i.__identificarDocumento(qry);
	
	/// Falta mostrar los datos de la orden de producci�n en lugar de los del proceso de producci�n. Y sobrecargar verDocumento para este caso
// 	var datosDoc:Array = [];
// 	datosDoc["tipo"] = "";
// 	datosDoc["codigo"] = "";
// 	datosDoc["origen"] = "";
// 	var util:FLUtil = new FLUtil();
// 	var qryCodigo:FLSqlQuery = new FLSqlQuery;	
// 	var idLineaPedido:Number = "";
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////