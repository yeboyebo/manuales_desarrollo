
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();		
	}
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function controlAvisoMargen(cursor) {
		return this.ctx.euromoda_controlAvisoMargen(cursor);
	}
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	_i.controlAvisoMargen(cursor);
}
function euromoda_bufferChanged(fN)
{
	var _i = this.iface
	var cursor = this.cursor();
	if(fN == "em_evaluarmargen") {		
		_i.controlAvisoMargen(cursor);				
	} else {
		_i.__bufferChanged(fN);
	}
}
function euromoda_controlAvisoMargen(cursor)
{
	var evaluarMargen = cursor.valueBuffer("em_evaluarmargen");
	if(!evaluarMargen) {
		sys.disableObj(this, "fdbEmAvisoMargen");		
		sys.setObjText(this, "fdbEmAvisoMargen", false);
		sys.enableObj(this, "fdbEmAprDocCostes");
	} else {
		sys.enableObj(this, "fdbEmAvisoMargen");
		sys.disableObj(this, "fdbEmAprDocCostes");		
		sys.setObjText(this, "fdbEmAprDocCostes", false);
	}
}

//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
