/***************************************************************************
                 em_ordenesptes.qs  -  description
                             -------------------
    begin                : vie mar 02 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var oColorLinea_, idOrdenAnt_;
	function oficial( context ) { interna( context ); }
	function tbnRefrescar_clicked() {
		return this.ctx.oficial_tbnRefrescar_clicked();
	}
	function dameColorLinea(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, fT, sel);
	}
	function formatoTabla() {
		return this.ctx.oficial_formatoTabla();
	}
	function cargaDatos(referencia) {
    return this.ctx.oficial_cargaDatos(referencia);
  }
  function tbnVerOrden_clicked() {
    return this.ctx.oficial_tbnVerOrden_clicked();
  }
  function tbnFiltro_clicked() {
    return this.ctx.oficial_tbnFiltro_clicked();
	}
	function tbnQuitarFiltro_clicked() {
		return this.ctx.oficial_tbnQuitarFiltro_clicked();
	}
	function actualizaUltimaCarga() {
		return this.ctx.oficial_actualizaUltimaCarga();
	}
	function pintaUltimaCarga() {
		return this.ctx.oficial_pintaUltimaCarga();
	}
	function compruebaUsuario(tipo) {
		return this.ctx.oficial_compruebaUsuario(tipo);
	}
	function actualizaUsuarioCargando() {
		return this.ctx.oficial_actualizaUsuarioCargando();
	}
	function pintaCargaActual() {
		return this.ctx.oficial_pintaCargaActual();
	}
	function refrescaLabels() {
		return this.ctx.oficial_refrescaLabels();
	}
	/*function preloadMainFilter() {
		return this.ctx.interna_preloadMainFilter();
	}*/

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	_i.idOrdenAnt_ = 0;

	connect(this.child("tdbEmOrdenesPtes").cursor(), "newBuffer()", _i, "refrescaLabels()");
	connect(this.child("tbnRefrescar"), "clicked()", _i, "tbnRefrescar_clicked");
	connect(this.child("tbnBorrar"), "clicked()", _i, "tbnBorrar_clicked");
	connect(this.child("tbnVerOrden"), "clicked()", _i, "tbnVerOrden_clicked");
	connect(this.child("tbnFiltro"), "clicked()", _i, "tbnFiltro_clicked");
	connect(this.child("tbnQuitarFiltro"), "clicked()", _i, "tbnQuitarFiltro_clicked");

	_i.formatoTabla();

	_i.pintaUltimaCarga();
	//_i.pintaCargaActual();

	this.child("lblEstado").close();

/// 	_i.tbnRefrescar_clicked(); Petici�n de Jos� Ruiz
}

/*function interna_preloadMainFilter()
{
	var _i = this.iface;		
	var q = new AQSqlQuery;	
	q.setSelect("em_fechainicargaop, em_horainicargaop, em_usucargaop");
	q.setFrom("prodppal_general");
	q.setWhere("1 = 1"); 		
	if (!q.exec()){
		return true;
	}  
	if(!q.first()) {
		return true;
	}

	var usuarioCargaOP = q.value("em_usucargaop");
	if(usuarioCargaOP && usuarioCargaOP) {
		formUI.ponMsgWarn(sys.translate("La pantalla est� siendo recargada por otro usuario, deber� cerrarla y volverla a abrir cuando termine la recarga"));
	}
}*/

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnFiltro_clicked()
 {
	var _i = this.iface;
	_i.refrescaLabels();
	var cursor = this.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();
	var usuario = sys.nameUser();

	var f = new FLFormSearchDB("em_filtroordenesptes");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);

	f.setMainWidget();

	var filtro = f.exec("filtro");
	if (!filtro) {
		filtro = "1 = 1";
	}
	if (filtro) {
		curF.commitBuffer();
		cursor.setMainFilter(filtro);
	} else {
		cursor.setMainFilter("");
	}

	if (this.child("tdbEmOrdenesPtes")) {
		this.child("tdbEmOrdenesPtes").refresh();
	}
}

function oficial_tbnQuitarFiltro_clicked()
{
	var _i = this.iface;
	_i.refrescaLabels();
	this.cursor().setMainFilter("");
	if (this.child("tdbEmOrdenesPtes")) {
		this.child("tdbEmOrdenesPtes").refresh();
	}
}

function oficial_tbnVerOrden_clicked()
{
	var _i = this.iface;
	_i.refrescaLabels();
	var cursor = this.cursor();
	var codOrden = cursor.valueBuffer("codorden");
	var curOrden = new FLSqlCursor("pr_ordenesproduccion");
	curOrden.select("codorden = '" + codOrden + "'");
	if (curOrden.first()) {
		curOrden.browseRecord();
	}
}
function oficial_formatoTabla()
{
	var o = ["lblFecha", "tbnBorrar", "dedDesde", "lblGuion", "dedHasta"];
	for (var c = 0; c < o.length; c++) {
		if (this.child(o[c])) {
			this.child(o[c]).close();
		}
	}

	var t = this.child("tdbEmOrdenesPtes");
	t.setReadOnly(true);
	var cols = [["pedido",140],["cantidad", 70], ["canpendiente", 70], ["canpedida", 70], ["canprogramada", 70], ["numlinea", 40], ["codcliente", 60], ["referencia", 60], ["fechaservicio", 80], ["fechaentrega", 110], ["fechacliente", 80], ["fechacorte", 80], ["fechapedido", 80], ["fechaenvioconf", 80], ["canpterec", 70], ["canfaltas", 70], ["canptefal", 70], ["canptetot", 70]];
	for (var c = 0; c < cols.length; c++) {
		t.setColumnWidth(cols[c][0], cols[c][1]);
	}
}

function oficial_tbnRefrescar_clicked()
{
	var _i = this.iface;

	if(!_i.compruebaUsuario("recarga")) { 
		return false;	
	}

	_i.actualizaUsuarioCargando();


	if (!AQSql.del("em_ordenesptes", "")) {
		return false;
	}

	_i.cargaDatos()

	_i.actualizaUltimaCarga();
}

function oficial_cargaDatos()
{
	var _i = this.iface;
	var masWhere = "";
	var desde = this.child("dedDesde").date;
	if (desde) {
		masWhere += "AND p.fechaservicio >= '" + desde + "'";
	}
	var hasta = this.child("dedHasta").date;
	if (hasta) {
		masWhere += "AND p.fechaservicio <= '" + hasta + "'";
	}
	var q = new FLSqlQuery;
	q.setSelect("o.codorden, o.emobservaciones, o.estado, o.codconfeccionista, o.nombreconfeccionista, l.codcliente, pc.nombrecliente, l.referencia, l.codlote, a.descripcion, a.codtamanoem, a.codcolorem, l.canlote, l.canprogramada, lp.numlinea, lp.cantidad, pc.codigo, pc.fechaservicio, pc.fechasalida, pc.fecha, o.fechaentrega");
	q.setFrom("pr_ordenesproduccion o INNER JOIN lotesstock l ON o.codorden = l.codordenproduccion INNER JOIN articulos a ON l.referencia = a.referencia LEFT OUTER JOIN lineaspedidoscli lp ON l.idlineapc = lp.idlinea LEFT OUTER JOIN pedidoscli pc ON lp.idpedido = pc.idpedido");
	q.setWhere("o.estado <> 'TERMINADA'");
debug(q.sql());
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	var empresa = flfactppal.iface.pub_valorDefectoEmpresa("nombre");

	AQUtil.createProgressDialog(sys.translate("Cargando �rdenes..."), q.size());
	var p = 0;
	var curO = new FLSqlCursor("em_ordenesptes");

	var canPendiente, fechaCorte, fechaEnvioConf, pteServirConf, proveedor, canPteRec, codConfec, codOrden, canFaltas, canPteFal, canPteTot, referencia, codLote;
	while (q.next()) {
		AQUtil.setProgress(p);

		codLote = q.value("l.codlote");
		referencia = q.value("l.referencia");
		codConfec = q.value("o.codconfeccionista");
		codOrden = q.value("o.codorden");
		canPendiente = AQUtil.sqlSelect("movistock", "SUM(cantidad)", "codlote = '" + codLote + "' AND cantidad > 0 AND estado = 'PTE'");
		canPendiente = isNaN(canPendiente) ? 0 : canPendiente;
		fechaCorte = AQUtil.sqlSelect("pr_tareas", "diafin", "idobjeto = '" + codOrden + "' AND idtipotarea IN ('ACE', 'ACO', 'CO', 'J1')");
		fechaEnvioConf = AQUtil.sqlSelect("pedidosprov", "MIN(fecha)", "codordenprod = '" + q.value("o.codorden") + "' AND codproveedor = '" + codConfec + "'");
		pteServirConf = AQUtil.sqlSelect("pedidosprov", "idpedido", "codordenprod = '" + codOrden + "' AND codproveedor = '" + codConfec + "' AND servido <> 'S�'");
		canPteRec = AQUtil.quickSqlSelect("pedidosprov p INNER JOIN lineaspedidosprov lp ON p.idpedido = lp.idpedido INNER JOIN movistock ms ON lp.idlinea = ms.idlineapp", "SUM(ms.cantidad)", "p.codordenprod = '" + codOrden + "' AND p.codproveedor = '" + codConfec + "' AND ms.estado = 'PTE' AND lp.referencia = '" + referencia + "' AND lp.codloteprod = '" + codLote + "'");
		canPteRec = isNaN(canPteRec) ? 0 : canPteRec;
		canFaltas = AQUtil.quickSqlSelect("pedidosprov p INNER JOIN lineaspedidosprov lp ON p.idpedido = lp.idpedido", "SUM(lp.cantidad)", "p.codordenprod = '" + codOrden + "' AND p.codproveedor <> '" + codConfec + "' AND lp.referencia = '" + referencia + "' AND lp.codloteprod = '" + codLote + "'");
		canFaltas = isNaN(canFaltas) ? 0 : canFaltas;
		canPteFal = AQUtil.quickSqlSelect("pedidosprov p INNER JOIN lineaspedidosprov lp ON p.idpedido = lp.idpedido INNER JOIN movistock ms ON lp.idlinea = ms.idlineapp", "SUM(ms.cantidad)", "p.codordenprod = '" + codOrden + "' AND p.codproveedor <> '" + codConfec + "' AND ms.estado = 'PTE' AND lp.referencia = '" + referencia + "' AND lp.codloteprod = '" + codLote + "'");
		canPteFal = isNaN(canPteFal) ? 0 : canPteFal;
		canPteTot = parseFloat(canPteRec) + parseFloat(canPteFal);

		if (codConfec && codConfec != "" && canPteRec == 0 && canPteFal == 0) {
			continue;
		}
		var codPedido = q.value("pc.codigo");
		var fechaServicio = q.value("pc.fechaservicio");
		var fechaSalida = q.value("pc.fechasalida");
		var fechaPedido = q.value("pc.fecha");
		var nombreCliente = q.value("pc.nombrecliente");
		
		if(!codPedido || codPedido == "") {
			codPedido = AQUtil.sqlSelect("pr_ordenesproduccion","codpedidocli","codorden = '" + q.value("o.codorden") + "'");
			if(codPedido && codPedido != "") {	
				var qP = new AQSqlQuery;	
				qP.setSelect("fechaservicio, fechasalida, fecha, nombrecliente");
				qP.setFrom("pedidoscli");
				qP.setWhere("codigo = '" + codPedido + "' "); 			
				if (!qP.exec()){
					return;
				}  
				if(qP.first())
				{
					fechaServicio = qP.value("fechaservicio");
					fechaSalida = qP.value("fechasalida");
					fechaPedido = qP.value("fecha");
					nombreCliente = qP.value("nombrecliente");
				}	
			}
		}
		curO.setModeAccess(curO.Insert);
		curO.refreshBuffer();
		curO.setValueBuffer("idorden", ++p);
		curO.setValueBuffer("codorden", q.value("o.codorden"));
		curO.setValueBuffer("pedido", codPedido);
		if (q.value("lp.numlinea")) {
			curO.setValueBuffer("numlinea", q.value("lp.numlinea"));
		}
		curO.setValueBuffer("observaciones", q.value("o.emobservaciones"));
		curO.setValueBuffer("estado", q.value("o.estado"));
		curO.setValueBuffer("codcliente", q.value("l.codcliente"));
		curO.setValueBuffer("nombrecliente", nombreCliente);
		curO.setValueBuffer("referencia", q.value("l.referencia"));
		curO.setValueBuffer("descripcion", q.value("a.descripcion") + " " + q.value("a.codtamanoem") + " " + q.value("a.codcolorem"));
		curO.setValueBuffer("cantidad", q.value("l.canlote"));
		curO.setValueBuffer("canpedida", q.value("lp.cantidad"));
		curO.setValueBuffer("canprogramada", q.value("l.canprogramada"));
		curO.setValueBuffer("canpendiente", canPendiente);
		curO.setValueBuffer("canpterec", canPteRec);
		curO.setValueBuffer("canfaltas", canFaltas);
		curO.setValueBuffer("canptefal", canPteFal);
		curO.setValueBuffer("canptetot", canPteTot);
		curO.setValueBuffer("fechaservicio", fechaServicio);
		curO.setValueBuffer("fechacliente", fechaSalida);
		curO.setValueBuffer("fechapedido", fechaPedido);
		curO.setValueBuffer("fechacorte", fechaCorte);
		curO.setValueBuffer("fechaenvioconf", fechaEnvioConf);
		curO.setValueBuffer("codconfeccionista", codConfec);
		if (pteServirConf) {
			curO.setValueBuffer("confeccionista", q.value("o.nombreconfeccionista"));
		} else {
			if (fechaEnvioConf) { /// A faltas
				proveedor = AQUtil.sqlSelect("pedidosprov", "nombre", "codordenprod = '" + q.value("o.codorden") + "' AND codproveedor <> '" + q.value("o.codconfeccionista") + "'");
				proveedor = proveedor ? proveedor : empresa;
				curO.setValueBuffer("confeccionista", proveedor);
			}
		}
		curO.setValueBuffer("fechaentrega",q.value("o.fechaentrega"));
		if (!curO.commitBuffer()) {
			sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
			return false;
		}
	}
	sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);

	this.child("tdbEmOrdenesPtes").refresh();
}

function oficial_dameColorLinea(fN, fV, cursor, sel, fT)
{
  var _i = this.iface;
  var idOrden = cursor.valueBuffer("idorden");
  if (!sel && idOrden == _i.idOrdenAnt_) {
    return _i.oColorLinea_;
  }
  if (!sel)
    _i.idOrdenAnt_ = idOrden;
  else
    _i.idOrdenAnt_ = -1;
  var cortado = !cursor.isNull("fechacorte");
  var enviadoConf = !cursor.isNull("fechaenvioconf");
  var color = "";
  if (cursor.valueBuffer("canfaltas") > 0) {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_rojo_sel" : "fondo_rojo");
  } else if (enviadoConf) {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_azul_sel" : "fondo_azul");
  } else if (cortado) {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_verde_sel" : "fondo_verde");
  } else {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_gris_sel" : "fondo_gris");
  }
  if (color != "") {
    _i.oColorLinea_ = [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
    return _i.oColorLinea_;
  } else
    _i.idOrdenAnt_ = -1;
}

// function oficial_dameColorLinea(fN, fV, cursor, sel, fT)
// {
// debug("sel " + sel + " fT " + fT);
// // 	if (sel) {
// // 		return false;
// // 	}
// // debug("oficial_dameColorLinea");
// 	var _i = this.iface;
// // 	var idOrden = cursor.valueBuffer("idorden");
// // 	if (idOrden == _i.idOrdenAnt_) {
// // 		return _i.oColorLinea_;
// // 	}
// // 	_i.idOrdenAnt_ = idOrden;
// 	var cortado = !cursor.isNull("fechacorte");
// 	var enviadoConf = !cursor.isNull("fechaenvioconf");
// // debug("enviadoConf " + enviadoConf);
// 	var color = "";
// 	if (cursor.valueBuffer("canfaltas") > 0) {
// 		color = flfactppal.iface.pub_dameColor(sel ? "fondo_rojo_sel" : "fondo_rojo");
// 	} else if (enviadoConf) {
// 		//color = sel ? "#8DB4B4" : "#8DD4D4"; /// Azul
// 		color = flfactppal.iface.pub_dameColor(sel ? "fondo_azul_sel" : "fondo_azul");
// 	} else if (cortado) {
// 		//color = sel ? "#60D360" : "#80D380"; /// Verde
// 		color = flfactppal.iface.pub_dameColor(sel ? "fondo_verde_sel" : "fondo_verde");
// 	} else {
// 		//color = sel ? "#CCCCCC" : "#EEEEEE"; /// Gris claro
// 		color = flfactppal.iface.pub_dameColor(sel ? "fondo_gris_sel" : "fondo_gris");
// 	}
// // 	var estado = cursor.valueBuffer("estado");
// // 	debug("estado " + estado);
// // 	switch (estado) {
// // 		case "PTE": {
// // 			color = "#80D380"; /// Verde
// // 			break;
// // 		}
// // 		case "PTE CONFECCION": {
// // 			color = "#EEEE77"; /// Amarillo
// // 			break;
// // 		}
// // 		default: {
// // 			return;
// // 		}
// // 	}
// // debug("estado " + estado);
// 	if (color != "") {
// 		debug("Asignando color");
// 		return [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
// 	}
// }

function oficial_tbnBorrar_clicked()
{
	var _i = this.iface;
	_i.refrescaLabels();
	this.child("dedDesde").date = "";
	this.child("dedHasta").date = "";
}

function oficial_actualizaUltimaCarga()
{
	var _i = this.iface;

	var fecha = new Date();

	var hora = fecha.toString().right(8);
	var fecha = fecha.toString().left(10);
	var user = sys.nameUser();

	var curGen = new FLSqlCursor("prodppal_general");

	curGen.select("1 = 1");
	if (!curGen.first())
	{
		return false;
	}

	curGen.setModeAccess(curGen.Edit);
	curGen.refreshBuffer();
	curGen.setValueBuffer("fechacargaop", fecha);
	curGen.setValueBuffer("horacargaop", hora);
	curGen.setValueBuffer("usuariocargaop", user);
	curGen.setNull("em_usucargaop");
	curGen.setNull("em_fechainicargaop");
	curGen.setNull("em_horainicargaop");
	curGen.commitBuffer();

	_i.refrescaLabels();
}

function oficial_pintaUltimaCarga()
{
	var _i = this.iface;

	var curGen = new FLSqlCursor("prodppal_general");

	curGen.select("1 = 1");
	if (!curGen.first())
	{
		return false;
	}

	var fecha = curGen.valueBuffer("fechacargaop").toString().left(10);
	var hora = curGen.valueBuffer("horacargaop").toString().right(8);
	var user = curGen.valueBuffer("usuariocargaop");

	var anio = fecha.toString().left(4);
	var mes = fecha.toString().right(5);
	var mes = mes.left(2);
	var dia = fecha.toString().right(2);

	this.child("lblUltimaCarga").text = "�ltima carga: d�a " + dia + "/" + mes + "/" + anio + " a las " + hora + " por " + user;

}

function oficial_compruebaUsuario(tipo)
{
	var usuario = sys.nameUser();
	var usuarioCargaOP = AQUtil.sqlSelect("prodppal_general","em_usucargaop","1=1");
	if(usuarioCargaOP && usuarioCargaOP != "") {
		if(tipo == "recarga") {
			formUI.ponMsgWarn(sys.translate("El usuario %1 est� recargando actualmente, espere unos minutos y vuelva a intentarlo").arg(usuarioCargaOP));
		} 
		return false;
	}
	return true; 
}

function oficial_actualizaUsuarioCargando()
{
	var fecha = new Date();
	var hora = fecha.toString().right(8);
	var fecha = fecha.toString().left(10);
	var user = sys.nameUser();

	if(!AQUtil.execSql("UPDATE prodppal_general SET em_usucargaop = '" + user + "', em_fechainicargaop = '" + fecha + "', em_horainicargaop = '" + hora + "' WHERE 1 = 1")) {
   		return false;
   	}
   	return true;
}

function oficial_pintaCargaActual()
{
	var _i = this.iface;

	var curGen = new FLSqlCursor("prodppal_general");

	curGen.select("1 = 1");
	if (!curGen.first())
	{
		return false;
	}

	var fecha = curGen.valueBuffer("em_fechainicargaop").toString().left(10);
	var hora = curGen.valueBuffer("em_horainicargaop").toString().right(8);
	var user = curGen.valueBuffer("em_usucargaop");

	if(user && user != "") {
		var anio = fecha.toString().left(4);
		var mes = fecha.toString().right(5);
		var mes = mes.left(2);
		var dia = fecha.toString().right(2);
		this.child("lblEstado").show();
		this.child("lblEstado").text = "Recargando, inicio de carga: " + dia + "/" + mes + "/" + anio + " a las " + hora + " por " + user;

	} else {
		this.child("lblEstado").close();
	}
}

function oficial_refrescaLabels()
{
	var _i = this.iface;
	_i.pintaUltimaCarga();
	//_i.pintaCargaActual();
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////
