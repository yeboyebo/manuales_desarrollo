/***************************************************************************
                 em_masterdibujos.qs  -  description
                             -------------------
    begin                : mar oct 18 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); }
	function tbnActualizaDesc_clicked() {
		return this.ctx.oficial_tbnActualizaDesc_clicked();
	}
	function actualizaDescripciones(oParam) {
		return this.ctx.oficial_actualizaDescripciones(oParam);
	}
	function controlBusqueda() {
		return this.ctx.oficial_controlBusqueda();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.controlBusqueda();
	
	this.child("tableDBRecords").putFirstCol("descripcion");
	this.child("tableDBRecords").refresh();
	
	connect(this.child("tbnActualizaDesc"), "clicked()", _i, "tbnActualizaDesc_clicked");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnActualizaDesc_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codDibujo = cursor.valueBuffer("coddibujoem");
	var res = MessageBox.warning(sys.translate("Va a actualizar la descripci�n de todos los art�culos asociados al dibujo %1\n�Est� seguro?").arg(codDibujo), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		return true;
	}
	var oParam = new Object;
	oParam.codDibujo = codDibujo;
	oParam.totalArticulos = undefined;
	oParam.errorMsg = sys.translate("Error al actualizar las descripciones");
	var f = new Function("oParam", "return formem_dibujos.iface.actualizaDescripciones(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	MessageBox.information(sys.translate("Se ha actualizado la descripci�n de %1 art�culos").arg(oParam.totalArticulos), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
}

function oficial_actualizaDescripciones(oParam)
{
	var curA = new FLSqlCursor("articulos");
	curA.setActivatedCommitActions(false);
	curA.setActivatedCheckIntegrity(false);
	curA.select("coddibestamp = " + oParam.codDibujo);
	AQUtil.createProgressDialog(sys.translate("Actualizando descripciones"), curA.size());
	var p = 0;
	while (curA.next()) {
		AQUtil.setProgress(++p);
		curA.setModeAccess(curA.Edit);
		curA.refreshBuffer();
		curA.setValueBuffer("descripcion", formRecordarticulos.iface.pub_commonCalculateField("descripcion", curA));
		if (!curA.commitBuffer()) {
			oParam.errorMsg = sys.translate("Error al actualizar la descripci�n del art�culo %1").arg(curA.valueBuffer("referencia"));
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	oParam.totalArticulos = p;
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_controlBusqueda()
{
	var t = this.mainWidget().parentWidget().rtti();
// 	debug("Esto es un " + t);
	if (t != "FormSearchDB") {
		return true;
	}
	sys.runObjMethod(this, "tableDBRecords", "setOnlyTable", true);
// 	this.child("tableDBRecords").setOnlyTable(true);
	if (this.child("barraBotones")) {
		this.child("barraBotones").close();
	}
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////