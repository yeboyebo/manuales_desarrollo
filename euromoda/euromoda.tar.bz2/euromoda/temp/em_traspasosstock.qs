/***************************************************************************
                 em_traspasosstock.qs  -  description
                             -------------------
    begin                : jue may 31 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function calculateField(fN) {
		return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var xPartidas_;
	var accion_;
  function oficial( context ) { interna( context ); }
  function bufferChanged(fN) {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function validaCantidad() {
    return this.ctx.oficial_validaCantidad();
  }
  function validaPartida() {
    return this.ctx.oficial_validaPartida();
  }
  function controlPartida() {
    return this.ctx.oficial_controlPartida();
  }
  function validaFamilias() {
    return this.ctx.oficial_validaFamilias();
  }
//   function filtraRefHasta() {
//     return this.ctx.oficial_filtraRefHasta();
//   }
  function habilitaPorPartida() {
    return this.ctx.oficial_habilitaPorPartida();
  }
  function tbnStockDesde_clicked() {
    return this.ctx.oficial_tbnStockDesde_clicked();
  }
  function tbnStockHasta_clicked() {
    return this.ctx.oficial_tbnStockHasta_clicked();
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	debug("cursoraction: "+cursor.action());

	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("tbnStockDesde"), "clicked()", _i, "tbnStockDesde_clicked");
	connect(this.child("tbnStockHasta"), "clicked()", _i, "tbnStockHasta_clicked");

	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbIdUsuario", sys.nameUser());
			sys.setObjText(this, "fdbCodAlmacen", flfactppal.iface.pub_valorDefectoEmpresa("codalmacen"));
			break;
		}
		case cursor.Edit: {
			// 			_i.filtraRefHasta();
			sys.setObjText(this, "lblCanDesde", _i.calculateField("lblcandesde"));
			sys.setObjText(this, "lblCanHasta", _i.calculateField("lblcanhasta"));
		break;
		}
	}
	sys.disableObj(this, "fdbCodAlmacen");

	var refDesde = cursor.valueBuffer("refdesde");
	_i.xPartidas_ = flfactalma.iface.pub_esReferenciaXPartidas(refDesde);
	_i.habilitaPorPartida();
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "canlote": {
			valor = AQUtil.sqlSelect("lotesstock", "mptedist", "codlote = '" + cursor.valueBuffer("codlotedesde") + "'");
			valor = isNaN(valor) ? 0 : valor;
			break;
		}
		case "lblcandesde": {
			valor = AQUtil.sqlSelect("stocks", "disponible", "referencia = '" + cursor.valueBuffer("refdesde") + "' AND codalmacen = '" + cursor.valueBuffer("codalmacen") + "'");
			valor = !valor || isNaN(valor) ? 0 : valor;
			valor = sys.translate("Stock: %1").arg(valor);
			break;
		}
		case "lblcanhasta": {
			valor = AQUtil.sqlSelect("stocks", "disponible", "referencia = '" + cursor.valueBuffer("refhasta") + "' AND codalmacen = '" + cursor.valueBuffer("codalmacen") + "'");
			valor = !valor || isNaN(valor) ? 0 : valor;
			valor = sys.translate("Stock: %1").arg(valor);
			break;
		}
	}
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;

	if(_i.accion_ && _i.accion_ == "em_pedidosptes") {
		if(!formem_pedidosptes.iface.compruebaUsuario("traspasoStock")) { 
			return false;	
		}
	}
	if (!_i.validaCantidad()) {
		return false;
	}
	if (!_i.validaPartida()) {
		return false;
	}
	if (!_i.validaFamilias()) {
		return false;
	}
	_i.accion_ = "";
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "cstockmin": {
      break;
    }
		case "codalmacen": {
			_i.controlPartida();
			sys.setObjText(this, "lblCanDesde", _i.calculateField("lblcandesde"));
			sys.setObjText(this, "lblCanHasta", _i.calculateField("lblcanhasta"));
			break;
		}
		case "refdesde": {
			_i.controlPartida();
// 			_i.filtraRefHasta();
			sys.setObjText(this, "lblCanDesde", _i.calculateField("lblcandesde"));
			break;
		}
		case "refhasta": {
			sys.setObjText(this, "lblCanHasta", _i.calculateField("lblcanhasta"));
			break;
		}
		case "cantidad": {
			if (_i.xPartidas_) {
				sys.setObjText(this, "fdbCanHasta", cursor.valueBuffer("cantidad"));
			}
			break;
		}
  }
}

// function oficial_filtraRefHasta()
// {
// 	var _i = this.iface;
//   var cursor = this.cursor();
// 
// 	var refDesde = cursor.valueBuffer("refdesde");
// 	var codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + refDesde + "'");
// 	if (codFamilia) {
// 		this.child("fdbRefHasta").setFilter("codfamilia = '" + codFamilia + "'");
// 	} else {
// 		this.child("fdbRefHasta").setFilter("");
// 	}
// }

function oficial_controlPartida()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var refDesde = cursor.valueBuffer("refdesde");
	_i.xPartidas_ = flfactalma.iface.pub_esReferenciaXPartidas(refDesde);
	if (_i.xPartidas_) {
	} else {
		sys.setObjText(this, "fdbCodLoteDesde", "");
		sys.setObjText(this, "fdbCanHasta", "");
	}
	_i.habilitaPorPartida();
}

function oficial_habilitaPorPartida()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var refDesde = cursor.valueBuffer("refdesde");
	var codAlmacen = cursor.valueBuffer("codalmacen");
	if (_i.xPartidas_) {
		this.child("gbxLote").enabled = true;
		this.child("fdbCodLoteDesde").setFilter("referencia = '" + refDesde + "' AND codalmacen = '" + codAlmacen + "' AND candisponible > 0");
	} else {
		this.child("gbxLote").enabled = false;
	}
}

function oficial_validaCantidad()
{
	var _i = this.iface;
  var cursor = this.cursor();
  var refDesde = cursor.valueBuffer("refdesde");
	var codAlmacen = cursor.valueBuffer("codalmacen");
	var cantidad = cursor.valueBuffer("cantidad");
	var canPrevia = cursor.valueBufferCopy("cantidad");
	canPrevia = isNaN(canPrevia) ? 0 : canPrevia;
	var oArt = new Object;
	oArt.referencia = refDesde;
	var idStock = flfactalma.iface.pub_dameIdStock(codAlmacen, oArt);
	if (!idStock) {
		MessageBox.warning(sys.translate("Error al obtener el stock del art�culo %1").arg(refDesde), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var disponible = AQUtil.sqlSelect("stocks", "disponible", "idstock = " + idStock);
	disponible = isNaN(disponible) ? 0 : disponible;
	var incremento = cantidad - canPrevia;
	if (incremento > disponible) {
		var res = MessageBox.warning(sys.translate("La cantidad indicada es superior a la cantidad disponible en stock para %1\n�Desea continuar?").arg(refDesde), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	return true;
}

function oficial_validaPartida()
{
	var _i = this.iface;
  var cursor = this.cursor();
  var refDesde = cursor.valueBuffer("refdesde");
	var codLoteDesde = cursor.valueBuffer("codlotedesde");
	var codAlmacen = cursor.valueBuffer("codalmacen");

	if (flfactalma.iface.pub_esReferenciaXPartidas(refDesde)) {
		if (!AQUtil.sqlSelect("lotesstock", "codlote", "codlote = '" + codLoteDesde + "' AND referencia = '" + refDesde + "'")) {
			sys.warnMsgBox(sys.translate("La referencia de origen no corresponde a la partida indicada"));
			return false;
		}
		var codAlmaLote = AQUtil.sqlSelect("lotesstock", "codalmacen", "codlote = '" + codLoteDesde + "'");
		if (codAlmaLote != codAlmacen) {
			sys.warnMsgBox(sys.translate("Los almacenes del traspaso y la partida no coinciden"));
			return false;
		}
		var canLote = _i.calculateField("canlote");
		if (cursor.modeAccess() == cursor.Edit && codLoteDesde == cursor.valueBufferCopy("codlotedesde")) {
			canLote += parseFloat(cursor.valueBufferCopy("cantidad"));
		}
		if (cursor.valueBuffer("cantidad") > canLote) {
			sys.warnMsgBox(sys.translate("La cantidad traspasada es mayor que la cantidad disponible en el lote origen"));
			return false;
		}
	}
	return true;
}

function oficial_validaFamilias()
{
	var _i = this.iface;
	
	if (_i.xPartidas_) {
		return true;
	}
	
  var cursor = this.cursor();

	var codFamDesde = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + cursor.valueBuffer("refdesde") + "'");
	var codFamHasta = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + cursor.valueBuffer("refhasta") + "'");
	if (codFamDesde != codFamHasta) {
		sys.warnMsgBox(sys.translate("Las familias de los art�culos origen y destino no coinciden"));
		return false;
// 		var res = MessageBox.warning(sys.translate("Las familias de los art�culos origen y destino no coinciden.\n�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
// 		if (res != MessageBox.Yes) {
// 			return false;
// 		}
	}
	return true;
}

function oficial_tbnStockDesde_clicked()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var codAlmacen = cursor.valueBuffer("codalmacen");
	var referencia = cursor.valueBuffer("refdesde");
	var curS = new FLSqlCursor("stocks");
	curS.select("referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
	if (curS.first()) {
		curS.editRecord();
	} else {
		sys.warnMsgBox(sys.translate("No hay stock registrado para el art�culo %1 en el almac�n %2").arg(referencia).arg(codAlmacen));
	}
}

function oficial_tbnStockHasta_clicked()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var codAlmacen = cursor.valueBuffer("codalmacen");
	var referencia = cursor.valueBuffer("refhasta");
	var curS = new FLSqlCursor("stocks");
	curS.select("referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
	if (curS.first()) {
		curS.editRecord();
	} else {
		sys.warnMsgBox(sys.translate("No hay stock registrado para el art�culo %1 en el almac�n %2").arg(referencia).arg(codAlmacen));
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////