/***************************************************************************
                 em_filtropedidoscli.qs  -  description
                             -------------------
    begin                : mie may 08 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	var bloqueoProvincia = false;
  function oficial(context)
  {
    interna(context);
  }
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function construirFiltro(cursor) {
		return this.ctx.oficial_construirFiltro(cursor);
	}
	function tbnLimpiarFiltro_clicked() {
	  return this.ctx.oficial_tbnLimpiarFiltro_clicked();
	}
	function limpiarFiltro(form) {
		return this.ctx.oficial_limpiarFiltro(form);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function validarCodigoProvincia() {
		return this.ctx.oficial_validarCodigoProvincia();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
	function pub_limpiarFiltro(form) {
		return this.limpiarFiltro(form);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
	var cursor = this.cursor();
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
  connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_construirFiltro(cursor)
{
	var filtro = "";
	
	var servido = cursor.valueBuffer("servido");
	if (servido && servido != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (servido == "Pendientes") {
			filtro += "servido IN ('No', 'Parcial')";
		} else if (servido == "Todos") {
			filtro = "1 = 1";
		} else {
			filtro += "servido = '" + servido + "'";
		}
	}

	var codGrupo = cursor.valueBuffer("codgrupo");
	if (codGrupo && codGrupo != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (codGrupo.find(",") >= 0) {
			filtro += ("pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.codgrupo IN ('" + codGrupo.split(",").join("', '") + "'))");
		} else {
			filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.codgrupo = '" + codGrupo + "')";
		}
	}

	var bloqueado = cursor.valueBuffer("bloqueado");
	if (bloqueado && bloqueado != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (bloqueado){
			case "No": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE (clientes.bloqueado = 'No' OR clientes.bloqueado = ' '))";
				break;
			}
			case "Enviar": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.bloqueado = 'Enviar')";
				break;
			}
			case "Facturar": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.bloqueado = 'Facturar')";
				break;
			}
			default: {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.bloqueado = 'Todo')";
				break;
			}
		}
	}

	var riesgo = cursor.valueBuffer("riesgosuperado");
	if (riesgo && riesgo != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (riesgo){
			case "No": {
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE (clientes.riesgomax >= clientes.riesgoalcanzado OR clientes.riesgoalcanzado is null))";
				break;
			}
			default:
				filtro += "pedidoscli.codcliente IN (SELECT clientes.codcliente FROM clientes WHERE clientes.riesgomax < clientes.riesgoalcanzado)";
				break;
		}
	}

	var provincia = cursor.valueBuffer("idprovincia");
	if (provincia && provincia != ""){
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "pedidoscli.idprovincia = '" + provincia + "'";
	}

	var pais = cursor.valueBuffer("codpais");
	if (pais && pais != ""){
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "pedidoscli.codpais = '" + pais + "'";
	}

	return filtro;
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (!_i.validarCodigoProvincia()) {
		return false;
	}

	if (!flfactppal.iface.pub_validarProvincia(cursor)) {
		return false;
	}

	var tabla = cursor.valueBuffer("tabla");
	var filtro = _i.construirFiltro(cursor);
	if (!filtro) {
		filtro = "";
	}
	cursor.setValueBuffer("filtro", filtro);

	this.obj().accept();
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var cursor = miForm.cursor();
	var campos = "fdbNombreGrupo,fdbCodGrupo,fdbProvincia,fdbIdProvincia,fdbCodPais,fdbBanderaPais";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(miForm, aCampos[i], "");
	}

	cursor.setValueBuffer("bloqueado", "Todos");
	cursor.setValueBuffer("riesgosuperado", "Todos");
	cursor.setValueBuffer("servido", "Pendientes");
}

function oficial_bufferChanged(fN)
{
	var cursor = this.cursor();

	var cursor = this.cursor();
	switch (fN) {
		case "provincia": {
			if (!this.iface.bloqueoProvincia) {
				this.iface.bloqueoProvincia = true;
				flfactppal.iface.pub_obtenerProvincia(this);
				this.iface.bloqueoProvincia = false;
			}
			break;
		}
		case "idprovincia": {
			if (cursor.valueBuffer("idprovincia") == 0) {
				cursor.setNull("idprovincia");
			}
			break;
		}
	}
}

function oficial_validarCodigoProvincia()
{
	var cursor = this.cursor();

	var nomProvincia = cursor.valueBuffer("provincia");
	if (nomProvincia && nomProvincia != "") {
		nomProvincia.toUpperCase();
	}
	else {
		cursor.setValueBuffer("idprovincia","");
		return true;
	}

	var codProvincia = AQUtil.sqlSelect("provincias","idprovincia","provincia = '" + nomProvincia + "'");

	if(codProvincia) {
		cursor.setValueBuffer("idprovincia",codProvincia);
	}
	else {
		sys.warnMsgBox(sys.translate("La provincia %1 no se encuentra en la base de datos.").arg(nomProvincia));
		return false;
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////