
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function dibDestinoPedCli(codigo, fila) {
		return this.ctx.euromoda_dibDestinoPedCli(codigo, fila);
	}
	function dibOrigenFacCli(codigo, fila) {
		return this.ctx.euromoda_dibOrigenFacCli(codigo, fila);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_dibDestinoPedCli(codigo, fila)
{
	var _i = this.iface;
	var fA = _i.__dibDestinoPedCli(codigo, fila);
	if (fA == -1) {
		return fA;
	}
	var codFactura = AQUtil.sqlSelect("pedidoscli p INNER JOIN facturascli f ON p.idfactura = f.idfactura", "f.codigo", "p.codigo = '" + codigo + "'", "pedidoscli");
	if (codFactura) {
		if (!AQUtil.sqlSelect("pedidoscli p INNER JOIN lineasalbaranescli la ON p.idpedido = la.idpedido INNER JOIN albaranescli a ON la.idalbaran = a.idalbaran INNER JOIN facturascli f ON a.idfactura = f.idfactura", "f.idfactura", "p.codigo = '" + codigo + "' AND f.codigo = '" + codFactura + "'", "pedidoscli")) {
			fA++;
			if (_i.tblDocs.numRows() == fA) {
				_i.tblDocs.insertRows(fA);
			}
			_i.tblDocs.setText(fA, _i.FACTURAS, codFactura);
			fA = _i.dibDestinoFacCli(codFactura, fA);
			if (fA == -1) {
				return fA;
			}
		}
	}
	return fA;
}

function euromoda_dibOrigenFacCli(codigo, fila)
{
	var _i = this.iface;
	var fA = _i.__dibOrigenFacCli(codigo, fila);
	if (fA == -1) {
		return fA;
	}
	var codPedido = AQUtil.sqlSelect("facturascli f INNER JOIN pedidoscli p ON f.idfactura = p.idfactura", "p.codigo", "f.codigo = '" + codigo + "'", "pedidoscli");
	if (codPedido) {
		if (!AQUtil.sqlSelect("facturascli f INNER JOIN albaranescli a ON f.idfactura = a.idfactura INNER JOIN lineasalbaranescli la ON a.idalbaran = la.idalbaran INNER JOIN pedidoscli p ON la.idpedido = p.idpedido", "p.idpedido", "f.codigo = '" + codigo + "' AND p.codigo = '" + codPedido + "'", "pedidoscli")) {
			fA++;
			if (_i.tblDocs.numRows() == fA) {
				_i.tblDocs.insertRows(fA);
			}
			_i.tblDocs.setText(fA, _i.PEDIDOS, codPedido);
			fA = _i.dibOrigenPedCli(codPedido, fA);
			if (fA == -1) {
				return fA;
			}
		}
	}
	return fA;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
