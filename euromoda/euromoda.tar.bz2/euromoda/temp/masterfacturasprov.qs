
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends articuloscomp {
  function euromoda( context ) { articuloscomp ( context ); }
  function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function imprimir(codFactura) {
    return this.ctx.euromoda_imprimir(codFactura);
  }
	function dameSelectAgrAlbaranes() {
		return this.ctx.euromoda_dameSelectAgrAlbaranes();
	}
	function dameGroupByAgrAlbaranes() {
		return this.ctx.euromoda_dameGroupByAgrAlbaranes();
	}
	function dameWhereFactura(where, qryAgruparAlbaranes) {
		return this.ctx.euromoda_dameWhereFactura(where, qryAgruparAlbaranes);
	}
	function copiaCampoFactura(nombreCampo, cursor, campoInformado) {
		return this.ctx.euromoda_copiaCampoFactura(nombreCampo, cursor, campoInformado);
	}
	function dameWhereSerie(codSerie) {
		return this.ctx.euromoda_dameWhereSerie(codSerie);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_commonCalculateField(fN, cursor)
{
  var _i = this.iface;
  var valor;

  switch (fN) {
  case "codserie": {
      if (cursor.modeAccess() != cursor.Insert) {
        MessageBox.warning(sys.translate("Est� tratando de cambiar la serie de una factura cuyo c�digo ya ha sido generado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
        return cursor.valueBuffer("codserie");
      }
      if (cursor.valueBuffer("deabono")) {
        valor = AQUtil.sqlSelect("proveedores p INNER JOIN gruposcontablesprov gp ON p.codgrupocontableprov = gp.codgrupo", "gp.codserieabo", "p.codproveedor = '" + cursor.valueBuffer("codproveedor") + "'", "proveedores");
      } else {
        valor = AQUtil.sqlSelect("proveedores p INNER JOIN gruposcontablesprov gp ON p.codgrupocontableprov = gp.codgrupo", "gp.codseriefac", "p.codproveedor = '" + cursor.valueBuffer("codproveedor") + "'", "proveedores");
      }
      break;
    }
    case "fechaoperacion": {
    	valor = cursor.valueBuffer("fechavalor");
    	break;
    }
	case "fechaexpedicion": {
    	//valor = cursor.valueBuffer("fechavalor"); 23-11-2020 Se cambia a petici�n de Jose
    	valor = cursor.valueBuffer("fecha");
    	break;
    }
    case "ejercicio": {
    	valor = cursor.valueBuffer("fechaexpedicion").toString().left(4);
    	if (!valor || valor == "") {
    		valor = cursor.valueBuffer("ejercicio");
    	}
    	break;
    }
    case "periodo": {
    	valor = cursor.valueBuffer("fechaexpedicion").toString().mid(5, 2);
    	if (!valor || valor == "") {
    		valor = cursor.valueBuffer("periodo");
    	}
    	break;
    }
	default: {
      valor = _i.__commonCalculateField(fN, cursor);
      break;
    }
  }
  return valor;
}

function euromoda_imprimir(codFactura)
{
	oficial_imprimir(codFactura);
}

function euromoda_dameSelectAgrAlbaranes()
{
	var _i = this.iface;
	return "codproveedor";
}

function euromoda_dameGroupByAgrAlbaranes()
{
	var _i = this.iface;
	return " GROUP BY codproveedor";
}

function euromoda_dameWhereFactura(where, qryAgruparAlbaranes)
{
	var _i = this.iface;
	var whereFactura;
	codProveedor = qryAgruparAlbaranes.value(0);
	codAlmacen = qryAgruparAlbaranes.value(1);
	whereFactura = where;
	if(codProveedor && codProveedor != ""){
		whereFactura += " AND codproveedor = '" + codProveedor + "'";
	}
	
 	return whereFactura;
}

function euromoda_copiaCampoFactura(nombreCampo, cursor, campoInformado)
{
	var _i = this.iface;
	if (campoInformado[nombreCampo]) {
		return true;
	}
	var nulo =false;

	switch (nombreCampo) {
		case "fechavalor": {
			valor = "00-00-0000";
			break;
		}
		default: {
			return _i.__copiaCampoFactura(nombreCampo, cursor, campoInformado);
		}
	}
	if (nulo) {
		this.iface.curFactura.setNull(nombreCampo);
	} else {
		this.iface.curFactura.setValueBuffer(nombreCampo, valor);
	}
	campoInformado[nombreCampo] = true;
	
	return true;
}

function euromoda_dameWhereSerie(codSerie)
{
	return "";
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
