
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends numLineaProv
{
  var aAcabados_;
	var pK_;

  function euromoda(context)
  {
    numLineaProv(context);
  }
  function init()
  {
    return this.ctx.euromoda_init();
  }
  function pbnInsertarPlantillaTexto_clicked()
  {
    return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
  }
  function inicializarControles()
  {
    return this.ctx.euromoda_inicializarControles();
  }
  function bufferChanged(fN)
  {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function tbIPonAcabado_clicked()
  {
    return this.ctx.euromoda_tbIPonAcabado_clicked();
  }
  function cargaAcabados()
  {
    return this.ctx.euromoda_cargaAcabados();
  }
  function filtrarAcabados()
  {
    return this.ctx.euromoda_filtrarAcabados();
  }
  function verificarHabilitaciones()
  {
    return this.ctx.euromoda_verificarHabilitaciones();
  }
  function validateForm()
  {
    return this.ctx.euromoda_validateForm();
  }
  function controlBloqueo()
  {
    return this.ctx.euromoda_controlBloqueo();
  }
  function calcularTotales()
  {
    return this.ctx.euromoda_calcularTotales();
  }
  //  function guardaPedido(curLineas) {
  //    return this.ctx.euromoda_guardaPedido(curLineas);
  //  }
  function ordenarAcabadosLog(nombre)
  {
    return this.ctx.euromoda_ordenarAcabadosLog(nombre);
  }
	function guardaDocumentoCommit(curLineas)
  {
    return this.ctx.euromoda_guardaDocumentoCommit(curLineas);
  }
 	function tbnInsertBB_clicked() {
		return this.ctx.euromoda_tbnInsertBB_clicked();
	}   
	function asociarBobinaPedido(codBobina, idPedido) {
		return this.ctx.euromoda_asociarBobinaPedido(codBobina, idPedido);
	}
	function creaLineaPedido(idPedido, referenciaLin, cantidadLin) {
    	return this.ctx.euromoda_creaLineaPedido(idPedido, referenciaLin, cantidadLin);
    }
	function borraLineaPedido(idLinea) {
		return this.ctx.euromoda_borraLineaPedido(idLinea);
	}
	function quitarBobinaPedido(codBobina, idPedido) {
		return this.ctx.euromoda_quitarBobinaPedido(codBobina, idPedido);
	}
	function actualizarTramos(tramos,idLinea, codBobina, estado) {
		return this.ctx.euromoda_actualizarTramos(tramos,idLinea, codBobina, estado);
	}
	function toolButtonDeleteBB_clicked() {
		return this.ctx.euromoda_toolButtonDeleteBB_clicked();
	}
	function quitarLineaTramo(codBobina, idPedido) {
		return this.ctx.euromoda_quitarLineaTramo(codBobina, idPedido);
	}
	function habilitarBobinas() {
		return this.ctx.euromoda_habilitarBobinas();
	}
	function filtraBobinas() {
		return this.ctx.euromoda_filtraBobinas();
	}
	function pbnImportarCSV_clicked() {
		return this.ctx.euromoda_pbnImportarCSV_clicked();
	}
	function pbnImportarFaltas_clicked() {
		return this.ctx.euromoda_pbnImportarFaltas_clicked();
	}
	function importarFaltas(cursor) {
		return this.ctx.euromoda_importarFaltas(cursor);
	}
	
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
    function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_asociarBobinaPedido(codBobina, idPedido) {
		return this.asociarBobinaPedido(codBobina, idPedido);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();

  connect(this.child("tbIPonAcabado"), "clicked()", _i, "tbIPonAcabado_clicked");
  connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");

  //connect(this.child("tdbArticulosPedProv").cursor(), "commited()", _i, "guardaDocumentoCommit()");
  connect(this.child("tabWidget8"), "currentChanged(QString)", _i, "ordenarAcabadosLog()");
	disconnect(this.child("tdbArticulosPedProv").cursor(), "bufferCommited()", this, "iface.calcularTotales()");
	connect(this.child("tdbArticulosPedProv").cursor(), "commited()", _i, "calcularTotales");
  var cursor = this.cursor();
	_i.pK_ = cursor.valueBuffer(cursor.primaryKey());
  if (cursor.modeAccess() == cursor.Insert) {
    sys.setObjText(this, "fechaentrada", _i.calculateField("fechaentrada"));
  }
  if (this.child("gbxProduccion") && (!cursor.valueBuffer("codordenprod"))) {
    this.child("gbxProduccion").close();
  }
  	_i.habilitarBobinas();

	connect(this.child("tbnInsertBB"), "clicked()", _i, "tbnInsertBB_clicked");
	connect(this.child("toolButtonDeleteBB"), "clicked()", _i, "toolButtonDeleteBB_clicked");	
	if(formem_acabado.iface.pub_getDesdeAcabado()) {		
		this.child("tabWidget8").showPage("observaciones");
		formem_acabado.iface.pub_setDesdeAcabado(false);
	}
	_i.filtraBobinas();
	connect(this.child("pbnImportarCSV"), "clicked()", _i, "pbnImportarCSV_clicked");
	connect(this.child("pbnImportarFaltas"), "clicked()", _i, "pbnImportarFaltas_clicked");
	if(this.child("tbnCambiarAlmacen")) {
  		this.child("tbnCambiarAlmacen").close();
  	}

}

function euromoda_pbnInsertarPlantillaTexto_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbObservaciones").setValue(texto);
}

function euromoda_tbIPonAcabado_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  if (cursor.modeAccess() == cursor.Insert) {
    if (!this.child("tdbArticulosPedProv").cursor().commitBufferCursorRelation()) {
      return false;
    }
    _i.filtrarAcabados();
  }

  _i.aAcabados_ = false;
  if (!_i.cargaAcabados()) {
    return false;
  }

  var f = new FLFormSearchDB("em_selacabadospedprov");
  f.setMainWidget();
  f.exec();
  if (!f.accepted()) {
    return;
  }
  if (!_i.aAcabados_) {
    return;
  }
  var idPedido = cursor.valueBuffer("idpedido");
  if (!AQSql.del("em_acabadospedprov", "idpedido = " + idPedido)) {
    return false;
  }
  for (var i = 0; i < _i.aAcabados_.length; i++) {
    if (!AQSql.insert("em_acabadospedprov", ["idpedido", "em_codacabado"], [idPedido, _i.aAcabados_[i]])) {
      return false;
    }
  }
  this.child("tdbAcabadosPedProv").refresh();
}

function euromoda_cargaAcabados()
{
  var cursor = this.cursor();
  var _i = this.iface;

  var idPedido = cursor.valueBuffer("idpedido");
  var q = new FLSqlQuery();
  q.setTablesList("em_acabadospedprov");
  q.setSelect("em_codacabado");
  q.setFrom("em_acabadospedprov");
  q.setWhere("idpedido = " + idPedido);
  q.setForwardOnly(true);
  if (!q.exec()) {
    return false;
  }
  _i.aAcabados_ = [];
  var i = 0;
  while (q.next()) {
    _i.aAcabados_[i++] = q.value("em_codacabado");
  }
  return true;
}

function euromoda_bufferChanged(fN)
{
  debug("fN " + fN);
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
    case "codproveedor": {
      _i.__bufferChanged(fN);
      sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
      sys.setObjText(this, "fdbCodAlmaOrigen", _i.calculateField("codalmaorigen"));
      if (!flfacturac.iface.pub_controlBloqueoProveedor(cursor.valueBuffer("codproveedor"), "Todo")) {
        sys.AQTimer.singleShot(0, formRecordpedidosprov.reject)
      }
      break;
    }
    case "codproveedordestino": {
      sys.setObjText(this, "fdbCodAlmacenE", _i.calculateField("codalmacen"));
      break;
    }
    case "codalmacen": {
      sys.setObjText(this, "fdbDireccionE", _i.calculateField("direccione"));
      sys.setObjText(this, "fdbCiudadE", _i.calculateField("ciudade"));
      sys.setObjText(this, "fdbIdProvinciaE", _i.calculateField("idprovinciae"));
      sys.setObjText(this, "fdbCodPostalE", _i.calculateField("codpostale"));
      break;
    }
    case "fecha": {
      debug("fE " + _i.calculateField("fechaentrada"));
      sys.setObjText(this, "fechaentrada", _i.calculateField("fechaentrada"));
      break;
    }
    case "fechaentrada": {
      sys.setObjText(this, "fdbFechaComprobacion", _i.calculateField("fechacomprobacion"));
      break;
    }
    case "acabados":{
		_i.habilitarBobinas();
		break;
	}	
    default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_inicializarControles()
{
  var _i = this.iface;
  _i.__inicializarControles();

  var cursor = this.cursor();
  if (cursor.modeAccess() == cursor.Insert) {
    this.child("fdbIdContactoEnvio").setValue(sys.nameUser());
  }
  var aA = ["descripcion"];
  this.child("tdbAcabadosPedProv").setOrderCols(aA);
  _i.filtrarAcabados();
}

function euromoda_filtrarAcabados()
{
  var cursor = this.cursor();
  this.child("tdbAcabadosPedProv").setFilter("em_codacabado IN (SELECT em_codacabado FROM em_acabadospedprov WHERE idpedido = " + cursor.valueBuffer("idpedido") + ")");
}

function euromoda_verificarHabilitaciones()
{
  var _i = this.iface;
  var cursor = this.cursor();

  _i.__verificarHabilitaciones();

  var idLinea: Number = AQUtil.sqlSelect("lineaspedidosprov", "idpedido", "idpedido = " + cursor.valueBuffer("idpedido")); 
  if (!idLinea) {
    this.child("fdbCodAlmacenE").setDisabled(false);
    this.child("fdbCodProveedorDestino").setDisabled(false);
  } else {
    this.child("fdbCodAlmacenE").setDisabled(true);
    this.child("fdbCodProveedorDestino").setDisabled(true);
  }
}

function euromoda_validateForm()
{
  var _i = this.iface;
  if (!_i.__validateForm()) {
    return false;
  }
  if (!_i.controlBloqueo()) {
    return false;
  }
  _i.__calcularTotales();
  return true;
}

function euromoda_controlBloqueo()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var codProveedor = cursor.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
      return false;
    }
  }
  return true;
}

function euromoda_calcularTotales()
{
  var _i = this.iface;
  
  _i.guardaDocumentoCommit();
  
  _i.__calcularTotales();
  this.child("fdbEm_metros").setValue(_i.calculateField("em_metros"));

  //   _i.guardaPedido(this.child("tdbArticulosPedProv").cursor());
}


function euromoda_guardaDocumentoCommit()
{
	var _i = this.iface;
  	var cursor = this.cursor();

  	if (cursor.modeAccess() != cursor.Edit) {
    	return true;
  	}
  	var pk = cursor.valueBuffer(cursor.primaryKey());
  	formpedidosprov.iface.pK_ = cursor.valueBuffer("codigo");

  	if (!_i.validateForm()) {
    	return false;
  	}

  	if (!cursor.commitBuffer()) {
    	return false;
  	}

  	cursor.commit();
  	cursor.transaction(false);

   	cursor.select(cursor.primaryKey() + " = " + _i.pK_);
	if (!cursor.first()) {
		sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
		return false;
	}
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
}

function euromoda_guardaPedido(curLineas)
{
	return;
	
  var _i = this.iface;
  var cursor = this.cursor();

  var commitLineas = (cursor.transactionLevel() == 2);
   if (curLineas == undefined) {
     commitLineas = false;
   }

  if (cursor.modeAccess() != cursor.Edit) {
     return true;
   }
  if (!_i.validateForm()) {
     return false;
   }

   var indice = cursor.atFrom();
   if (!cursor.commitBuffer()) {
     return false;
   }

   if (commitLineas)
     curLineas.commit();
   if (!cursor.commit()) {
     if (commitLineas)
       curLineas.transaction(false);
     return false;
   }

   if (!cursor.transaction(false)) {
     if (commitLineas)
       curLineas.transaction(false);
     return false;
   }
   if (commitLineas)
     curLineas.transaction(false);

   if (!cursor.seek(indice)) {
     return false;
   }

   cursor.setModeAccess(cursor.Edit);
   cursor.refreshBuffer();

   return true;
 }
function euromoda_ordenarAcabadosLog(nombre)
{
  switch (nombre) {
    case "acabados": {
      var tdbLC = this.child("tdbEstadosLog");
      var dtbLC = this.mainWidget().child("tdbEstadosLog").tableRecords();

      tdbLC.autoSortColumn = false;
      var hHeader = dtbLC.horizontalHeader();
      hHeader.setClickEnabled(false);
      hHeader.setSortIndicator(-1, AQS.Ascending);
      dtbLC.setSort(["fecha DESC", "hora DESC"]);
      dtbLC.refresh(AQS.RefreshData);
      break;
    }
  }
}

function euromoda_tbnInsertBB_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var idPedido = cursor.valueBuffer("idpedido");	
	var fB = new FLFormSearchDB("em_bobinas");
	var curB = fB.cursor();
	
	var f = "idpedidoprov IS NULL";
	curB.setMainFilter(f);
	fB.setMainWidget();
	var codBobina = fB.exec("codbobina");
	if (!codBobina) {
		return;
	}

	idPedido = cursor.valueBuffer("idpedido");	
	if (!this.child("tdbArticulosPedProv").cursor().commitBufferCursorRelation()) {
			return false;
	}
	_i.asociarBobinaPedido(codBobina, idPedido);
	
	this.child("tdbBobinas").refresh();
	this.child("tdbArticulosPedProv").refresh();	
	
}
function euromoda_asociarBobinaPedido(codBobina, idPedido)
{
	var _i = this.iface;
	var referenciaLin="";
	var cantidadLin;
	var oLineas = [];
	var i=0;
	if(!idPedido || idPedido == "") {
	    return;
	}
	var codPedido = AQUtil.sqlSelect("pedidosprov", "codigo", "idpedido=" + idPedido);
	var estadoAct = AQUtil.sqlSelect("em_bobinas","estado","codbobina = '" + codBobina + "'");
	var estado = "ACABADO";
	if (estadoAct == "PARA REOPERAR") {
		estado = "REOPERANDO";
	}
	if (!AQSql.update("em_bobinas", ["idpedidoprov","estado","codpedidoprov"], [idPedido,estado,codPedido], "codbobina = '" + codBobina + "'")) {
		sys.warnMsgBox(sys.translate("Error al asociar la bobina %1 al pedido").arg(codBobina));
		return;
	}
	
	//las bobinas tienen tramos y los tramos referencias, para aquellas referencias con misms subfamilia, creamos una linea de pedido en la que la referencia ser� la referencia de estampaci�n de la subfamilia.
	var q = new AQSqlQuery;	
	//q.setSelect("s.refestampado,t.cantotal,t.caninicio, t.idtramo");
	q.setSelect("s.refestampado,t.candisponible,t.caninicio, t.idtramo");
	q.setFrom("em_bobinas b inner join em_tramostejido t on b.codbobina=t.codbobina inner join articulos a  on a.referencia=t.referencia inner join  subfamilias s on a.codsubfamilia=s.codsubfamilia");
	//q.setWhere("b.codbobina = '" + codBobina + "' order by t.caninicio"); 		
	q.setWhere("b.codbobina = '" + codBobina + "' and t.candisponible > 0 order by t.caninicio"); 		
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{		
		var referenciaEst = q.value("s.refestampado");
		//var canTotal = q.value("t.cantotal");
		var canDisponible = q.value("t.candisponible");
		var canInicio = q.value("t.caninicio");
		var idTramo = q.value("t.idtramo");
		if (referenciaLin == "" || referenciaLin != referenciaEst) {
			referenciaLin = referenciaEst;
			//cantidadLin = canTotal;
			cantidadLin = canDisponible;			
			oLineas[i] = new Array(2);
			oLineas[i]["referencia"] = referenciaLin;
			oLineas[i]["cantidad"] = cantidadLin;		
			oLineas[i]["idtramo"] = idTramo;
			
		} else {
				//cantidadLin +=canTotal;
				cantidadLin +=canDisponible;								
				i--;				
				oLineas[i]["cantidad"]= cantidadLin;	
				oLineas[i]["idtramo"]= oLineas[i]["idtramo"] +","+idTramo;	
		} 
		i++;
	}	

	//_i.numlinea = 0;
	for(var k=0; k<oLineas.length;k++) {
		//_i.numlinea++;
		var idLinea = _i.creaLineaPedido(idPedido, oLineas[k]["referencia"], oLineas[k]["cantidad"]);		
		if(idLinea == -1) {
			return false;
		}
		if(!_i.actualizarTramos(oLineas[k]["idtramo"],idLinea, codBobina, estado)) {
			return false;
		}
	}
	if (!AQSql.update("em_bobinas", ["idpedido"], [idPedido], "codbobina = '" + codBobina  + "'")) {
		return false;
	}
	return true;
}

function euromoda_creaLineaPedido(idPedido, referenciaLin, cantidadLin)
{
	var curLineaPed = new FLSqlCursor("lineaspedidosprov");
	curLineaPed.setModeAccess(curLineaPed.Insert);
	curLineaPed.refreshBuffer(); 
	curLineaPed.setValueBuffer("idpedido",idPedido);

	var numlinea = formRecordlineaspedidosprov.iface.pub_commonCalculateField("numlinea", curLineaPed);

	with (curLineaPed) {  
		setValueBuffer("numlinea", numlinea);
		setValueBuffer("referencia", referenciaLin);
		setValueBuffer("descripcion", AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + referenciaLin + "'"));
		setValueBuffer("cantidad",cantidadLin);
		setValueBuffer("pvpunitario", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpunitario", this));
		setValueBuffer("codimpuesto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("codimpuesto", this));
		iva = formRecordlineaspedidosprov.iface.pub_commonCalculateField("iva", this);
		if (!iva || isNaN(iva)) {
			iva = 0;
		}
		setValueBuffer("iva", iva);
		recargo = formRecordlineaspedidosprov.iface.pub_commonCalculateField("recargo", curLineaPed);
		if (!recargo || isNaN(recargo)) {
			recargo = 0;
		}
		setValueBuffer("recargo", recargo);
		setValueBuffer("dtolineal", 0);        
		setValueBuffer("dtopor", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpunitario", curLineaPed));
		setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLineaPed));
		setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLineaPed));
		setValueBuffer("codtamanoem",AQUtil.sqlSelect("articulos", "codtamanoem", "referencia = '" + referenciaLin + "'"));
		setValueBuffer("codcolorem",AQUtil.sqlSelect("articulos", "codcolorem", "referencia = '" + referenciaLin + "'"));
		
		//setValueBuffer("codpartida",);
		//setValueBuffer("codloteprod",);
		//setValueBuffer("texto",);
		//setValueBuffer("servidogit",);
		//setValueBuffer("xpartidas",);
				
		if (!commitBuffer()) {
			return -1;
		}
		
	}	
	var idLineaPed = curLineaPed.valueBuffer("idlinea");	
	return idLineaPed;
	
}
function euromoda_toolButtonDeleteBB_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbBobinas").cursor();
	var codBobina = cursor.valueBuffer("codBobina");
	var idPedido = cursor.valueBuffer("idpedidoprov");
	var res = MessageBox.information(sys.translate("Se eliminar� la asociaci�n de la bobina %1 con el pedido �Desea continuar?").arg(codBobina), MessageBox.Yes, MessageBox.No)
	if (res != MessageBox.Yes) {
		return;
	}
	//1. quitamos a la bobina el idpedido	
	if(!_i.quitarBobinaPedido(codBobina, idPedido)) {
		sys.warnMsgBox(sys.translate("Se ha producido un error al quitar la bobina %1 al pedido").arg(codBobina));
		return false;
	}
	//2. quitamos a los tramos de la bobina los idlinea y eliminamos las l�neas del pedido	
	if(!_i.quitarLineaTramo(codBobina, idPedido)) {
		sys.warnMsgBox(sys.translate("Se ha producido un error al quitar la relaci�n entre los tramos de tejido de la bobina %1 y el pedido").arg(codBobina));
		return false;
	}	
	this.child("tdbArticulosPedProv").refresh();
}
function euromoda_quitarBobinaPedido(codBobina, idPedido)
{
	var curBobinas = new FLSqlCursor("em_bobinas");
	curBobinas.select("codbobina = '" + codBobina + "' and idpedidoprov = " + idPedido);
	if (!curBobinas.first()) {
		return false;
	}
	curBobinas.setModeAccess(curBobinas.Edit);
	curBobinas.refreshBuffer(); 
	curBobinas.setNull("idpedidoprov");
	if (!curBobinas.commitBuffer()) {
		return false;
	}
	return true;
}
function euromoda_quitarLineaTramo(codBobina, idPedido)
{
	var  _i = this.iface;
	var q = new AQSqlQuery;	
	var lineasBorradas = [];
	var i=0;
	q.setSelect("t.idtramo, l.idlinea");
	q.setFrom("em_bobinas b inner join em_tramostejido t on b.codbobina=t.codbobina inner join lineaspedidosprov l on t.idlineapedacabado = l.idlinea");
	q.setWhere("b.codBobina = '" + codBobina + "' and l.idpedido = " +idPedido); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var idTramo= q.value("t.idtramo");
		var idLinea = q.value("l.idlinea");
		var curTramos = new FLSqlCursor("em_tramostejido");
		curTramos.select("idtramo = '" + idTramo + "' ");
		if (!curTramos.first()) {
			return false;
		}
		curTramos.setModeAccess(curTramos.Edit);
		curTramos.refreshBuffer(); 
		curTramos.setNull("idlineapedacabado");
		if (!curTramos.commitBuffer()) {
			return false;
		}		
		if(!_i.borraLineaPedido(idLinea)) {
			sys.warnMsgBox(sys.translate("Se ha producido un error al eliminar la l�nea %1 del pedido").arg(idLinea));
			return false;
		}		
	}	
	return true;
}
function euromoda_borraLineaPedido(idLinea) 
{
	var _i = this.iface;
	var curLinea = new FLSqlCursor("lineaspedidosprov");	                                                 
	curLinea.select("idlinea = " +idLinea);
	if (!curLinea.first()) {
		return true;
	}
	curLinea.setModeAccess(curLinea.Del);
	curLinea.refreshBuffer(); 	
	if (!curLinea.commitBuffer()) {
		return false;
	}
	return true;
}
function euromoda_actualizarTramos(tramos,idLinea, codBobina, estado)
{
	var codSoporte = AQUtil.sqlSelect("em_bobinas", "soporteactual", "codbobina = '" + codBobina + "'");
	var oTramos = tramos.toString().split(",");
	for (i=0; i<oTramos.length;i++) {		
		var idTramo = oTramos[i];
		if (estado == "REOPERANDO") {
			if (!AQUtil.execSql("UPDATE em_tramostejido SET idlineapedacabado = " + idLinea + ", codbobinareo = '" + codBobina + "', soportereo = '" + codSoporte + "' WHERE idtramo = " + idTramo)) {
				sys.warnMsgBox(sys.translate("Error al desasociar el tramo %1 al pedido").arg(idTramo));
				return false;
			}
		} else {
			if (!AQUtil.execSql("UPDATE em_tramostejido SET idlineapedacabado = " + idLinea + ", codbobinaaca = '" + codBobina + "', soporteaca = '" + codSoporte + "' WHERE idtramo = " + idTramo)) {
				sys.warnMsgBox(sys.translate("Error al desasociar el tramo %1 al pedido").arg(idTramo));
				return false;
			}
		}		
	}
	return true;
}
function euromoda_habilitarBobinas()
{
	if(this.cursor().valueBuffer("acabados")) {		
		this.child("tabWidget8").setTabEnabled("bobinas", true);
	}else {
		this.child("tabWidget8").setTabEnabled("bobinas", false);			
	}  

}

function euromoda_filtraBobinas()
{
  var cursor = this.cursor();
  this.child("tdbBobinas").setFilter("idalbaranprov is null");
} 

function euromoda_pbnImportarCSV_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbArticulosPedProv").cursor().commitBufferCursorRelation())
			return false;
	}	
	if(!formRecordpedidoscli.iface.importarDatosCSV(cursor)){
		return false;
	}
	_i.calcularTotales();
	this.child("tdbArticulosPedProv").refresh();	
	return true;

}

function euromoda_pbnImportarFaltas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbArticulosPedProv").cursor().commitBufferCursorRelation())
			return false;
	}	
	if(!formRecordpedidosprov.iface.importarFaltas(cursor)){
		return false;
	}
	_i.calcularTotales();
	this.child("tdbArticulosPedProv").refresh();	
	return true;
}

function euromoda_importarFaltas(cursor)
{
	var idTipoDoc;
	var codProveedor = "";
	var tipoDoc = cursor.table();
	if(tipoDoc == "pedidosprov") {
		idTipoDoc = cursor.valueBuffer("idpedido");
		codProveedor = cursor.valueBuffer("codproveedor");
	}
	var sesion = flfactalma.iface.pub_dameSesion();

	var f = new FLFormSearchDB("em_importarfaltas");
  	var curO = f.cursor();
  	curO.setModeAccess(curO.Insert);
  	curO.refreshBuffer();	

  	curO.setValueBuffer("sesion",sesion);
  	curO.setValueBuffer("accion",cursor.action());  
  	curO.setValueBuffer("codproveedor",codProveedor);
  	curO.setValueBuffer("iddocumento",idTipoDoc);
  	curO.setValueBuffer("codalmacenped",cursor.valueBuffer("codalmacen"));
  	f.setMainWidget();
   	f.exec();
  	if (!f.accepted()) {   		
        return false;
    }
    return curO;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
