/***************************************************************************
                 em_resumenpuestoprod.qs  -  description
                             -------------------
    begin                : jue may 11 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var usuarioActual_;
	var cREF, cDES, cTAM, cCOL, cLOT, cCPR, cCCO, cCC1;

	function oficial( context ) { interna( context ); }
	function cargaTabla() {
		return this.ctx.oficial_cargaTabla();
	}
	function iniciarTabla() {
		return this.ctx.oficial_iniciarTabla();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function terminaTareaProd(oParam) {
		return this.ctx.oficial_terminaTareaProd(oParam);
	}
	function terminaTarea(idTarea, usuario) {
		return this.ctx.oficial_terminaTarea(idTarea, usuario);
	}
	function muestraUsuarioActual() {
		return this.ctx.oficial_muestraUsuarioActual();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_gestionAlarmas(codOrden) {
		return this.gestionAlarmas(codOrden);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;

	this.child("pushButtonAccept").close();
	this.child("pushButtonCancel").close();

	connect(this.child("tbnAceptar"), "clicked()", _i, "pushButtonAccept_clicked");
	connect(this.child("tbnCancelar"), "clicked()", this.child("pushButtonCancel"), "animateClick()");

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");

	// 	var t = this.child("tblLotes");
	// 	connect(t, "clicked(int, int)", t, "editCell(int, int)");

	_i.muestraUsuarioActual();
	_i.iniciarTabla();
	_i.cargaTabla();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_muestraUsuarioActual()
{
	var _i = this.iface;
	_i.usuarioActual_ = formem_puestoprod.iface.usuarioActual_;
	var usuario;
	if (_i.usuarioActual_) {
		var n = AQUtil.sqlSelect("pr_trabajadores", "nombre", "idtrabajador = '" + _i.usuarioActual_ + "'");
		usuario = n + " (" + _i.usuarioActual_ + ")";
	} else {
		usuario = sys.translate("Usuario actual no establecido");
	}
	sys.setObjText(this, "lblUsuario", usuario);
}


function oficial_iniciarTabla()
{
	var _i = this.iface;

	var c = 0, cH = [];
	_i.cREF = c++;
	_i.cDES = c++;
	_i.cTAM = c++;
	_i.cCOL = c++;
	_i.cLOT = c++;
	_i.cCPR = c++;
	_i.cCCO = c++;
	_i.cCC1 = c++;

	cH[_i.cLOT] = sys.translate("Lote");
	cH[_i.cREF] = sys.translate("Ref.");
	cH[_i.cDES] = sys.translate("Producto");
	cH[_i.cTAM] = sys.translate("Tama�o");
	cH[_i.cCOL] = sys.translate("Color");
	cH[_i.cCPR] = sys.translate("Program.");
	cH[_i.cCCO] = sys.translate("Producida");
	cH[_i.cCC1] = sys.translate("Producida original");


	var t = this.child("tblLotes");
	t.setNumCols(c);
	t.setColumnWidth(_i.cLOT, 140);
	t.setColumnWidth(_i.cREF, 90);
	t.setColumnWidth(_i.cDES, 450);
	t.setColumnWidth(_i.cTAM, 130);
	t.setColumnWidth(_i.cCOL, 130);
	t.setColumnWidth(_i.cCPR, 100);
	t.setColumnWidth(_i.cCCO, 100);
	t.hideColumn(_i.cCC1);

	t.setColumnReadOnly(_i.cLOT, true);
	t.setColumnReadOnly(_i.cREF, true);
	t.setColumnReadOnly(_i.cDES, true);
	t.setColumnReadOnly(_i.cTAM, true);
	t.setColumnReadOnly(_i.cCOL, true);
	t.setColumnReadOnly(_i.cCPR, true);

	t.setColumnLabels("*", cH.join("*"));
}

function oficial_cargaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codOrden = cursor.valueBuffer("codorden");
	var t = this.child("tblLotes");
	
	var q = new AQSqlQuery;
	q.setSelect("ls.codlote, ls.referencia, ls.canprogramada, ls.canlote, a.descripcion, a.codtamanoem, a.codcolorem");
	q.setFrom("lotesstock ls INNER JOIN articulos a ON ls.referencia = a.referencia");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "'");
	if (!q.exec()) {
		return false;
	}
	var f = 0;
	while (q.next()) {
		t.insertRows(f);
		t.setRowHeight(f, 30);
		t.setText(f, _i.cLOT, q.value("ls.codlote"));
		t.setText(f, _i.cREF, q.value("ls.referencia"));
		t.setText(f, _i.cDES, q.value("a.descripcion"));
		t.setText(f, _i.cTAM, q.value("a.codtamanoem"));
		t.setText(f, _i.cCOL, q.value("a.codcolorem"));
		t.setText(f, _i.cCPR, q.value("ls.canprogramada"));
		t.setText(f, _i.cCCO, q.value("ls.canlote"));
		t.setText(f, _i.cCC1, q.value("ls.canlote"));
		f++;
	}
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al terminar la tarea");
	var f = new Function("oParam", "return formem_resumenpuestoprod.iface.terminaTareaProd(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	this.accept();
}

function oficial_terminaTareaProd(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var t = this.child("tblLotes");
	var codOrden = cursor.valueBuffer("codorden");
	
	var idUsuario = formem_puestoprod.iface.usuarioActual_;
	var codLote, canProducida, canProgramada, referencia;
	var canProducidaM;
	var oLote = new Object;
	for (var f = 0; f < t.numRows(); f++) {
		if (t.text(f, _i.cCCO) == t.text(f, _i.cCC1)) {
			continue;
		}
		codLote = t.text(f, _i.cLOT);
		oLote.idUsuario = idUsuario;
		canProducida = t.text(f, _i.cCCO);
		
		if (isNaN(canProducida)) {
			oParam.errorMsg = sys.translate("La cantidad indicada para el lote %1 no es v�lida").arg(codLote);
			return false;
		}
		oLote.canProducida = canProducida;
		oLote.codLote = codLote;
		oLote.estado = "PROCESADO";
		oLote.canProgramada = t.text(f, _i.cCPR);
		oLote.codOrden = cursor.valueBuffer("codordenproduccion");

		referencia = t.text(f, _i.cREF);

		if(referencia && referencia != "") {
			canProducidaM = formRecordarticulos.iface.prendasAMetros(referencia, canProducida);	
		}
		
		if(!canProducidaM) {
			canProducidaM = 0;
		}
		oLote.canProducidaM = canProducidaM;

		//debug("\n\n---------------canProducida: "+canProducida);
		//debug("canProducidaM: "+canProducidaM);

		if (!formem_puestoprod.iface.pub_trProduceLote(oLote)) {
			oParam.errorMsg = oLote.errorMsg;
			return false;
		}

	}
	var tipoTareas = formem_puestoprod.iface.pub_dameTipoTareasMaq();

	

	var idTarea = AQUtil.sqlSelect("pr_tareas", "idtarea", "idobjeto = '" + codOrden + "' AND idtipotarea IN (" + tipoTareas + ") AND (estado = 'PTE' OR estado = 'EN CURSO')");
	if (!idTarea) {
		oParam.errorMsg = sys.translate("No se ha encontrado una tarea de tipo %1 en estado PTE para la orden %2").arg(tipoTareas).arg(codOrden);
		return false;
	}
	if (!_i.terminaTarea(idTarea, idUsuario)) {
		oParam.errorMsg = sys.translate("Error al terminar la tarea %1").arg(idTarea);
		return false;
	}	

	return true;
}

function oficial_terminaTarea(idTarea, usuario)
{
	var curTarea = new FLSqlCursor("pr_tareas");
	curTarea.select("idtarea = '" + idTarea + "'");
	if (!curTarea.first()) {
		return false;
	}
	if (!flcolaproc.iface.pub_iniciarTarea(curTarea, usuario)) {
		return false;
	}
	if (!flcolaproc.iface.pub_terminarTarea(curTarea)) {
		return false;
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////