/***************************************************************************
                 em_costefinallote.qs  -  description
                             -------------------
    begin                : mie may 30 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }	
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); } 
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function pushButtonAccept_clicked() {
        return this.ctx.oficial_pushButtonAccept_clicked();
    }
    function validaCampos() {
    	return this.ctx.oficial_validaCampos();
    }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged"); 
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
    connect(this.child("pushButtonAccept"), "clicked()", this, "iface.pushButtonAccept_clicked");

}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(campo)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (campo) {
		case "sinfecha": {
			var sinFecha = cursor.valueBuffer("sinfecha");
			if(sinFecha) {				
				this.child("fdbFechaCosteFinal").setValue("");		
				cursor.setNull("em_fechacostefinal");	
				this.child("fdbCosteFinal").setValue("");		
				cursor.setNull("em_costefinaleur");	
				sys.disableObj(this, "fdbFechaCosteFinal");
				sys.disableObj(this, "fdbCosteFinal");
			} else {
				sys.enableObj(this, "fdbFechaCosteFinal");
				sys.enableObj(this, "fdbCosteFinal");
			}
			break;
		}
	}
}

function oficial_pushButtonAccept_clicked()
{
    var _i = this.iface;

    if (!_i.validaCampos()) {
        return false;
    }

    this.accept();
}

function oficial_validaCampos()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var fecha = this.child("fdbFechaCosteFinal").value();
	var coste = this.child("fdbCosteFinal").value();
	debug("fecha: "+fecha);
	debug("coste: "+coste);
	if(fecha && fecha != "" && coste && coste != "") {
		debug("1");
		return true
	} else if((!fecha || fecha == "") && (!coste || coste == "")) {
		debug("2");
		return true;
	} else {
		debug("3");
		flfactppal.iface.ponMsgError(sys.translate("Los valores de fecha y coste deben de estar los dos informados o los dos sin valor."),"warn",this);
		return false;
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
