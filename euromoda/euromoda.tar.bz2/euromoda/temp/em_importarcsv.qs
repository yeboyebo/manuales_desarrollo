/***************************************************************************
                 em_importarcsv.qs  -  description
                             -------------------
    begin                : vie feb 7 2020
    copyright            : (C) 2020 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() {
        return this.ctx.interna_init();
    }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {

	var cLIN_, cEAN_, cREF_, cSUREF_, cDES_, cCAN_, cPRE_, cENC_, cIMP_;
	var utf8_;
	var numLinea_;

    function oficial( context ) { interna( context ); }
    function cargarDatos() {
        return this.ctx.oficial_cargarDatos();
    }
    function cargaEsquema(cursor) {
    	return this.ctx.oficial_cargaEsquema(cursor);
    }
    function tbnBuscarFichero_clicked() {
    	return this.ctx.oficial_tbnBuscarFichero_clicked();
    }
    function pbPrevisualizar_clicked() {
    	return this.ctx.oficial_pbPrevisualizar_clicked();
    }
    function previsualizaLineas(oParam) {
    	return this.ctx.oficial_previsualizaLineas(oParam);
    }
    function limpiarTablas() {
    	return this.ctx.oficial_limpiarTablas();
    }
    function buscaReferencia(fila, codCliente) {
    	return this.ctx.oficial_buscaReferencia(fila, codCliente);
    }
    function pbImportar_clicked() {
    	return this.ctx.oficial_pbImportar_clicked();
    }
    function trImportarLineas(oParam) {
    	return this.ctx.oficial_trImportarLineas(oParam);
    }
	function crearLinea(oParam, fila) {
		return this.ctx.oficial_crearLinea(oParam, fila);
	}
	function totales(cursor) {
		return this.ctx.oficial_totales(cursor);
	}
    function pbCancelar_clicked() {
    	return this.ctx.oficial_pbCancelar_clicked();
    }
    function iniciarTablas() {
    	return this.ctx.oficial_iniciarTablas();
    }
    function cbSeparador_activated() {
    	return this.ctx.oficial_cbSeparador_activated();
    }
    function cbSimboloDecimal_activated() {
    	return this.ctx.oficial_cbSimboloDecimal_activated();
    }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
    var _i = this.iface;
    var cursor = this.cursor();

    _i.cargarDatos();
    
    if(this.child("pushButtonAccept")) {
    	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
    	this.child("pushButtonAccept").close();
    }

  	if(this.child("pushButtonAcceptContinue")) {
    	this.child("pushButtonAcceptContinue").close();
    }

    if(this.child("pushButtonCancel")) {
    	this.child("pushButtonCancel").close();
    }   

    connect(this.child("tbnBuscarFichero"), "clicked()", _i, "tbnBuscarFichero_clicked");
    connect(this.child("pbPrevisualizar"), "clicked()", _i, "pbPrevisualizar_clicked");
    connect(this.child("pbImportar"), "clicked()", _i, "pbImportar_clicked");
    connect(this.child("pbCancelar"), "clicked()", _i, "pbCancelar_clicked");
    connect(this.child("cbSeparador"), "activated(QString)", _i, "cbSeparador_activated");
    connect(this.child("cbSimboloDecimal"), "activated(QString)", _i, "cbSimboloDecimal_activated");

    _i.iniciarTablas();

}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciarTablas()
{
	var _i = this.iface;
	
	var c = 0, cH = [];

	_i.cLIN_ = c++;
	_i.cEAN_ = c++;
	_i.cREF_ = c++;  
	_i.cSUREF_ = c++;
	_i.cDES_ = c++;
	_i.cCAN_ = c++;
	_i.cPRE_ = c++;  
	_i.cENC_ = c++;
	_i.cIMP_ = c++;


	cH[_i.cLIN_] = AQUtil.translate("scripts", "LIN.");
	cH[_i.cEAN_] = AQUtil.translate("scripts", "EAN");
	cH[_i.cREF_] = AQUtil.translate("scripts", "REFERENCIA");
	cH[_i.cSUREF_] = AQUtil.translate("scripts", "SU REFERENCIA");
	cH[_i.cDES_] = AQUtil.translate("scripts", "DESCRIPCI�N");
	cH[_i.cCAN_] = AQUtil.translate("scripts", "CANTIDAD");
	cH[_i.cPRE_] = AQUtil.translate("scripts", "PRECIO UNIT");	
	cH[_i.cENC_] = AQUtil.translate("scripts", "REF.ENCONTRADA");
	cH[_i.cIMP_] = AQUtil.translate("scripts", "IMPORTABLE");


	var t = this.child("tblLineas");
	t.setNumCols(c);
	t.setColumnWidth(_i.cLIN_, 60);
	t.setColumnWidth(_i.cEAN_, 120);
	t.setColumnWidth(_i.cREF_, 120);
	t.setColumnWidth(_i.cSUREF_, 120);
	t.setColumnWidth(_i.cDES_, 400);
	t.setColumnWidth(_i.cCAN_, 150);
	t.setColumnWidth(_i.cPRE_, 120);
	t.setColumnWidth(_i.cENC_, 120);
	t.setColumnWidth(_i.cIMP_, 120);

	t.setColumnReadOnly(_i.cLIN_, true);
	t.setColumnReadOnly(_i.cEAN_, true);
	t.setColumnReadOnly(_i.cREF_, true);
	t.setColumnReadOnly(_i.cSUREF_, true);
	t.setColumnReadOnly(_i.cDES_, true);
	t.setColumnReadOnly(_i.cCAN_, true);
	t.setColumnReadOnly(_i.cPRE_, true);
	t.setColumnReadOnly(_i.cENC_, true);
	t.setColumnReadOnly(_i.cIMP_, true);
	t.hideColumn(_i.cIMP_);

	t.setColumnLabels("*", cH.join("*"));


	cH[_i.cENC_] = AQUtil.translate("scripts", "MOTIVO");
	


	var tN = this.child("tblLineasNoimp");
	tN.setNumCols(c);
	tN.setColumnWidth(_i.cLIN_, 60);
	tN.setColumnWidth(_i.cEAN_, 120);
	tN.setColumnWidth(_i.cREF_, 120);
	tN.setColumnWidth(_i.cSUREF_, 120);
	tN.setColumnWidth(_i.cDES_, 400);
	tN.setColumnWidth(_i.cCAN_, 150);
	tN.setColumnWidth(_i.cPRE_, 120);
	tN.setColumnWidth(_i.cENC_, 400);

	tN.setColumnReadOnly(_i.cLIN_, true);
	tN.setColumnReadOnly(_i.cEAN_, true);
	tN.setColumnReadOnly(_i.cREF_, true);
	tN.setColumnReadOnly(_i.cSUREF_, true);
	tN.setColumnReadOnly(_i.cDES_, true);
	tN.setColumnReadOnly(_i.cCAN_, true);
	tN.setColumnReadOnly(_i.cPRE_, true);
	tN.setColumnReadOnly(_i.cENC_, true);	
	tN.hideColumn(_i.cIMP_);
	tN.setColumnLabels("*", cH.join("*"));


	
}

function oficial_cargarDatos()
{
    var _i = this.iface;
    var cursor = this.cursor();
	this.child("cbSimboloDecimal").currentText =  cursor.valueBuffer("simbolodecimal");  
	_i.cargaEsquema(cursor); 

}
function oficial_tbnBuscarFichero_clicked()
{

	var fichero = FileDialog.getOpenFileName("*.csv", sys.translate( "scripts", "Fichero CSV importaci�n l�neas"));
	this.child("leFichero").text = fichero;	
	return true;
}

function oficial_cargaEsquema(cursor)
{
	var separador = cursor.valueBuffer("separador");
	this.child("lblEsquemaFichero").text = "EAN" + separador + "REFERENCIA" + separador + "SU REFERENCIA" + separador + "DESCRIPCION" + separador + "CANTIDAD" + separador + "PRECIO UNIT";	
}


function oficial_pbPrevisualizar_clicked() 
{

	var _i = this.iface;
	var cursor= this.cursor();
	var sep = cursor.valueBuffer("separador");

	if(sep == "Espacio") {
		sep = " ";
	} else if(sep == "Tabulador")  {
		sep = "\t";
	}


	var conCabecera = cursor.valueBuffer("expcabecera");
	

	var rutaF = this.child("leFichero").text;
	if (!rutaF) {
		return false;
	}
	var f = new File(rutaF);
	try {
		f.open(File.ReadOnly);
		if(f.size == 0) {
			formUI.ponMsgWarn(sys.translate("Fichero vac�o"));			
			return false;
		}
	} catch(e) {
		formUI.ponMsgWarn(sys.translate("Error al abrir el fichero:\n%1").arg(rutaF));		
		return false;
	}		
	
	var steps = 0;
	while (!f.eof) {
		f.readLine();
		++steps;
	}
	f.close();
	f.open(File.ReadOnly);
	var longLinea = 6;

	if(conCabecera) {
		var head = f.readLine().split(sep);	
	}
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al cargar el fichero csv %1.").arg(rutaF);
	oParam.cursor = cursor;
	oParam.f = f;
	oParam.steps = steps;
	oParam.sep = sep;
	oParam.longLinea = longLinea;

	if (!sys.runTransaction(formem_importarcsv.iface.previsualizaLineas, oParam)) {
		return false;
	}

	formUI.ponMsgInfo(sys.translate("Fichero cargado correctamente"));
	return true;
}

function oficial_previsualizaLineas(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;
	var codCliente = cursor.valueBuffer("codcliente");
	var f = oParam.f;
	_i.limpiarTablas();	
	var l = 0;
	AQUtil.createProgressDialog(sys.translate("Cargando fichero"), oParam.steps);
	var aLinea;
	var refInterna, importeCalculado, ean, estado, descInterna;
	var t = this.child("tblLineas");
	var tN = this.child("tblLineasNoimp");
	var fila = 0;
	var filaN = 0;
	var refInterna = "";
	var linea = "";
	var descripcion = "";
	var codificacion = cursor.valueBuffer("codificacion");


	while(!f.eof) {
		AQUtil.setProgress(++l);		
		linea = f.readLine();
		linea = linea.replace("\n","");
		linea = linea.replace("\r","");
		//aLinea = f.readLine().split(oParam.sep);
		aLinea = linea.split(oParam.sep);
		if(!aLinea || aLinea == "" || aLinea.length == 0 || (aLinea.length == 1 && (aLinea[0] == "" || !aLinea[0]))) {
			continue;	
						
		}
		
		if (!aLinea || aLinea.length != oParam.longLinea) {
			tN.insertRows(filaN);
      		tN.setText(filaN, _i.cLIN_, l);        		
      		tN.setText(filaN, _i.cENC_, "El n�mero de columnas es incorrecto");        		
      		filaN++;	
			continue;
		}

		var cantidad = aLinea[4];	
      	t.insertRows(fila);
      	t.setText(fila, _i.cLIN_, l);      
      	t.setText(fila, _i.cEAN_, aLinea[0]);
      	t.setText(fila, _i.cREF_, aLinea[1]);
      	t.setText(fila, _i.cSUREF_, aLinea[2]);

      	descripcion = aLinea[3];
 		if(codificacion == "UTF8") {
			descripcion = sys.toUnicode(descripcion, "UTF-8");	
		}
      	t.setText(fila, _i.cDES_, descripcion);
      	t.setText(fila, _i.cCAN_, formSTR.reemplazar(cantidad, " ", ""));
      	t.setText(fila, _i.cPRE_, formSTR.reemplazar(aLinea[5], " ", ""));
      	refInterna = _i.buscaReferencia(fila, codCliente);
      	
      	if(!refInterna || refInterna =="") {
      		t.setText(fila, _i.cENC_, "");  
      	} else {
      		t.setText(fila, _i.cENC_, refInterna);	
      	}     	
      	t.setText(fila, _i.cIMP_, "SI");	

      	if(!refInterna || refInterna == "") {
     		tN.insertRows(filaN);
      		tN.setText(filaN, _i.cLIN_, l);      
      		tN.setText(filaN, _i.cEAN_, aLinea[0]);
      		tN.setText(filaN, _i.cREF_, aLinea[1]);
      		tN.setText(filaN, _i.cSUREF_, aLinea[2]);
      		tN.setText(filaN, _i.cDES_, descripcion);
      		tN.setText(filaN, _i.cCAN_, formSTR.reemplazar(cantidad, " ", ""));
      		tN.setText(filaN, _i.cPRE_, formSTR.reemplazar(aLinea[5], " ", ""));
      		tN.setText(filaN, _i.cENC_, "NO SE HA ENCONTRADO REFERENCIA");  
      		t.setText(fila, _i.cIMP_, "NO");
      		filaN++;
      	} else if(!cantidad || cantidad == "" || cantidad == "0") {
     		tN.insertRows(filaN);
      		tN.setText(filaN, _i.cLIN_, l);      
      		tN.setText(filaN, _i.cEAN_, aLinea[0]);
      		tN.setText(filaN, _i.cREF_, aLinea[1]);
      		tN.setText(filaN, _i.cSUREF_, aLinea[2]);
      		tN.setText(filaN, _i.cDES_, descripcion);
      		tN.setText(filaN, _i.cCAN_, formSTR.reemplazar(cantidad, " ", ""));
      		tN.setText(filaN, _i.cPRE_, formSTR.reemplazar(aLinea[5], " ", ""));
      		tN.setText(filaN, _i.cENC_, "NO IMPORTABLE. CANTIDAD DESCONOCIDA");  
      		t.setText(fila, _i.cIMP_, "NO");
      		filaN++;
      	}
      	fila++;
      	
    	AQUtil.destroyProgressDialog();
  	}
	return true;
}

function oficial_buscaReferencia(fila, codCliente)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var refInterna = "";
	var t = this.child("tblLineas");
	var EAN = t.text(fila, _i.cEAN_);
	var referencia = t.text(fila, _i.cREF_);
	var suRefencia = t.text(fila, _i.cSUREF_);

	if(EAN && EAN != "") {
		refInterna = AQUtil.sqlSelect("articulos","referencia","codbarras = '" + EAN  + "'");			
	}	
	if((!refInterna || refInterna == "") && referencia && referencia != "") {
		refInterna = AQUtil.sqlSelect("articulos","referencia","referencia = '" + referencia  + "'");
	}
	if((!refInterna || refInterna == "") && suRefencia && suRefencia != "" && codCliente && codCliente != "") {
		refInterna = AQUtil.sqlSelect("em_articuloscli","referencia","codcliente = '" + codCliente + "' AND referenciacliente = '" + suRefencia + "'");
	}
	if((!refInterna || refInterna == "") && suRefencia && suRefencia != "") {
		refInterna = AQUtil.sqlSelect("articulos","referencia","aliasart = '" +  suRefencia + "'");
	}
	return refInterna;

}

function oficial_limpiarTablas()
{	
	this.child("tblLineas").setNumRows(0);
	this.child("tblLineasNoimp").setNumRows(0);	
}

    
function oficial_pbImportar_clicked() 
{
	var cursor = this.cursor();	
	var _i = this.iface;
	var t = this.child("tblLineas");
	var nF = t.numRows();
	if(nF == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No hay ninguna l�nea que importar. Se cancela el proceso."),"warn",this);
		return false;
	}
	var tipodoc = cursor.valueBuffer("tipodoc");

	var tablaLineas = "lineaspedidoscli";
	var campoIdDocumento = "idpedido";
	if(tipodoc == "albaranescli") {
		tablaLineas = "lineasalbaranescli";
		campoIdDocumento = "idalbaran";
	} else if(tipodoc == "facturascli") {
		tablaLineas = "lineasfacturascli";
		campoIdDocumento = "idfactura";
	} else if(tipodoc == "pedidosprov") {
		tablaLineas = "lineaspedidosprov";
		campoIdDocumento = "idpedido";
	} else if(tipodoc == "presupuestoscli") {
		tablaLineas = "lineaspresupuestoscli";
		campoIdDocumento = "idpresupuesto";
	}
	_i.numLinea_ = AQUtil.sqlSelect(tablaLineas,"MAX(numlinea)",campoIdDocumento + " = " + cursor.valueBuffer("iddocumento"));

	if(!_i.numLinea_ || _i.numLinea_ == "") {
		_i.numLinea_ = 0;
	}
	_i.numLinea_++;

	var simboloMillares = ",";
	if(cursor.valueBuffer("simbolodecimal") == ".") {
		simboloMillares = ",";
	} else {
		simboloMillares = ".";
	}
	var oParam = new Object;	
	oParam["cursor"] = cursor;	
	oParam["t"] = t;
	oParam["errorMsg"] = sys.translate("Error al crar las l�neas.");	
	oParam["curL"] = new FLSqlCursor(tablaLineas);
	oParam["campoIdDocumento"] = campoIdDocumento; 
	oParam["tablaLineas"] = tablaLineas;
	oParam["simboloMillares"] = simboloMillares;

	//if (!sys.runTransaction(formem_importarcsv.iface.trImportarLineas, oParam)) {
	if(!_i.trImportarLineas(oParam)) {
		return false;	
	}
	this.accept();
}

function oficial_trImportarLineas(oParam)
{
	var _i = this.iface;
	var cursor = oParam["cursor"];
	var tipodoc = cursor.valueBuffer("tipodoc");
	if(tipodoc == "pedidoscli") {
		oParam["modofabricacion"] = AQUtil.sqlSelect("pedidoscli","em_modofabricacion","idpedido = " + cursor.valueBuffer("iddocumento"));
	}
	var t = oParam["t"];
	var nF = t.numRows();
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Generando l�neas"), nF);
	var p = 0;
	for (var fila = 0; fila < nF; fila++) {
		AQUtil.setProgress(++p);	
		if(t.text(fila, _i.cIMP_) == "SI") {
			if(!_i.crearLinea(oParam,fila)) {
				AQUtil.destroyProgressDialog();
				debug("Error creando lineas");	
				return false;
			}			
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_crearLinea(oParam, fila)
{
	var _i = this.iface;
	var t = oParam["t"];	
	var cursor = oParam["cursor"];
	var codificacion = cursor.valueBuffer("codificacion");

	var importarDesc = cursor.valueBuffer("importardescripcion");
	var importarPVP = cursor.valueBuffer("importarprecios");
	var tipoDoc = cursor.valueBuffer("tipodoc");
	var idDocumento = cursor.valueBuffer("iddocumento"); 
	var _cFL = formRecordlineaspedidoscli.iface.pub_commonCalculateField;
	if(tipoDoc == "pedidosprov") {
		_cFL = formRecordlineaspedidosprov.iface.pub_commonCalculateField;
	}
	var pvpUnitario = t.text(fila, _i.cPRE_);
	var descripcion = t.text(fila, _i.cDES_); 
	var calculaPrecio = false;
	if(!importarPVP || pvpUnitario == "") {
		calculaPrecio = true;
	}
	var calcularDesc = false;
	if(!importarDesc || descripcion == "") {
		calcularDesc = true;
	}
	
	var referencia = t.text(fila, _i.cENC_);
	var cantidad = t.text(fila, _i.cCAN_);	
	var qArt = new FLSqlQuery;
	qArt.setSelect("codbarras, codarancelario, codtamanoem, codcolorem, descripcion");
	qArt.setFrom("articulos");
	qArt.setWhere("referencia = '" + referencia + "'");
	if (!qArt.exec()) {	
		debug("Error crearLinea 1");	
		return false;
	}
	if (!qArt.first()) {		
		debug("Error crearLinea 2");	
		return false;
	}

	var curL = oParam["curL"];
	var campoIdDocumento = oParam["campoIdDocumento"];

	curL.setModeAccess(curL.Insert);
	curL.refreshBuffer();
	curL.setValueBuffer(campoIdDocumento, idDocumento);
	curL.setValueBuffer("numlinea", _i.numLinea_++);
	curL.setValueBuffer("referencia", referencia);
	if(calcularDesc) {
		curL.setValueBuffer("descripcion", qArt.value("descripcion"));
	} else {
		curL.setValueBuffer("descripcion", descripcion);
	}
	curL.setValueBuffer("emcodbarras", qArt.value("codbarras"));
	curL.setValueBuffer("codtamanoem", qArt.value("codtamanoem"));
	curL.setValueBuffer("codcolorem", qArt.value("codcolorem"));



	var simboloMillares = oParam["simboloMillares"];
	var simboloDecimal = cursor.valueBuffer("simbolodecimal"); 
	if(cursor.valueBuffer("conmillares")) {
		if(simboloMillares == ".") {
			cantidad = formSTR.reemplazoAXB(cantidad, ".", ",");
		}		
		cantidad = formSTR.reemplazar(cantidad, ",", ""); 	
	} else {
		if(simboloDecimal == ",") {
			cantidad = formSTR.reemplazar(cantidad, ",", "."); 	
		}
	}	
	if(!cursor.valueBuffer("cantsindecimales")) {
		var numDecimalesImp = cursor.valueBuffer("numdecimalesimp");
		if(!numDecimalesImp || numDecimalesImp == "") {
			numDecimalesImp = 0;
		}
		cantidad = formUTIL.redondeaDecimales(cantidad, numDecimalesImp);
	} else {
		var aValor = cantidad.toString().split(".");
		cantidad = parseInt(aValor[0]);			
	}	

	curL.setValueBuffer("cantidad", cantidad);
	if(tipoDoc == "albaranescli") {
		//curL.setValueBuffer("candistribuida", _cFL("candistribuida", curL));
		curL.setValueBuffer("canfactura", _cFL("canfactura", curL));
	}
	if(calculaPrecio) {
		pvpUnitario = _cFL("pvpunitario", curL);
	} else {		
		if(cursor.valueBuffer("conmillares")) {
			if(simboloMillares == ".") {
				pvpUnitario = formSTR.reemplazoAXB(pvpUnitario, ".", ",");
			}
			pvpUnitario = formSTR.reemplazar(pvpUnitario, ",", ""); 			
		} else {
			if(simboloDecimal == ",") {
				pvpUnitario = formSTR.reemplazar(pvpUnitario, ",", "."); 	
			}
		}		
		
		if(cursor.valueBuffer("impdecimales")) {
			var numDecimalesImp = cursor.valueBuffer("numdecimalesimp");
			if(!numDecimalesImp || numDecimalesImp == "") {
				numDecimalesImp = 0;
			}
			pvpUnitario = formUTIL.redondeaDecimales(pvpUnitario, numDecimalesImp);
		} else {
			var aValor = pvpUnitario.toString().split(".");
			pvpUnitario = parseInt(aValor[0]);			
		}
	}
	curL.setValueBuffer("pvpunitario", pvpUnitario);
	if(tipoDoc == "pedidoscli") {
		formRecordlineaspedidoscli.iface.cargaDatosStock(curL);
	}
	curL.setValueBuffer("pvpsindto", _cFL("pvpsindto", curL));
	curL.setValueBuffer("pvptotal", _cFL("pvptotal", curL));
	curL.setValueBuffer("codimpuesto", _cFL("codimpuesto", curL));
	curL.setValueBuffer("iva", _cFL("iva", curL));
	curL.setValueBuffer("recargo", _cFL("recargo", curL));
	curL.setValueBuffer("diasservicio", _cFL("diasservicio", curL));
	curL.setValueBuffer("fechaservicio", _cFL("fechaservicio", curL));

 	curL.setValueBuffer("codsubcuenta", _cFL("codsubcuenta", curL));
 	curL.setValueBuffer("idsubcuenta", _cFL("idsubcuenta", curL));	
	curL.setValueBuffer("porcomision", _cFL("porcomision", curL));
	if(oParam && "modofabricacion" in oParam) {		
		if(oParam["modofabricacion"] == "Forzar a faltas"){
			curL.setValueBuffer("forzarafaltas", true);
		} else if(oParam["modofabricacion"] == "Agotar disponible de existencias (resto a faltas)"){
			curL.setValueBuffer("agotarexistencias" , true);
		}
	}
	var oParamLin = new Object;
	oParamLin.cursor = curL;
	oParamLin.ignorarAvisos = true;
	oParamLin.forzarReg = false;
	oParamLin.ignorarCalculoInsert = false; 

	if(tipoDoc != "pedidosprov") {
		var codCliente;
		var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(curL);
		if (!datosTP) {
			codCliente = false;
		} else {
			codCliente = datosTP["codcliente"];
		}	
		formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",codCliente);	
		formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);	
	}

	//var idLineaPedido = curL.valueBuffer("idlinea");
	if (!curL.commitBuffer()) {	
		debug("error al guardar la linea");	
		return false;
	}
	/*if(!calcularDesc && codificacion == "UTF8") {		
		
		var plataforma = AQUtil.getOS();		
		if (plataforma == "WIN32"){
			codificacion = "WIN1252";
		} else {
			codificacion = "LATIN9";
		}
		if(!AQUtil.execSql("update " + oParam["tablaLineas"] + " set descripcion = convert_from( convert_to(descripcion, '" + codificacion +"'),'UTF8') WHERE idlinea = " + idLineaPedido)) {
			formUI.ponMsgWarn(sys.translate("Error al codifcar la descripci�n"));	
			return false;
		}		
	}*/
	return true;	
}

function oficial_totales(cursor)
{
	var tipoDoc = cursor.valueBuffer("tipodoc");
	var curP = new FLSqlCursor(tipoDoc);	

	if(tipoDoc == "presupuestoscli") {
		curP.select("idpresupuesto = " + cursor.valueBuffer("iddocumento"));	
	}else if(tipoDoc == "pedidoscli") {
		curP.select("idpedido = " + cursor.valueBuffer("iddocumento"));	
	} else if(tipoDoc == "albaranescli") {
		curP.select("idalbaran = " + cursor.valueBuffer("iddocumento"));
	} else if(tipoDoc == "facturascli") {
		curP.select("idfactura = " + cursor.valueBuffer("iddocumento"));
	}			
	if (!curP.first()) {
		return false;
	}
	curP.setModeAccess(curP.Edit);
	curP.refreshBuffer();
	if(tipoDoc == "pedidoscli") {
		formpresupuestoscli.iface.curPedido = curP;
		formpresupuestoscli.iface.totalesPedido();		
	}
	if (!curP.commitBuffer()) {		
		debug("error en totales");	
		return false;
	}
	return true;	
}
    
function oficial_pbCancelar_clicked() 
{
	this.reject();
	
}

function oficial_cbSeparador_activated()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var separador = this.child("cbSeparador").currentText;
	if(separador == "Espacio") {
		separador = " ";
	} else if(separador == "Tabulador")  {
		separador = "\t";
	}
	cursor.setValueBuffer("separador",separador);
	_i.cargaEsquema(cursor);
}

function oficial_cbSimboloDecimal_activated()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.setValueBuffer("simbolodecimal",this.child("cbSimboloDecimal").currentText);
	
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
