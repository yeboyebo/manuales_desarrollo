
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA //////////////////////////////////////////////////
class euromoda extends anticipos
{
    var lblTotalTexto_;
    function euromoda(context) {
        anticipos(context);
    }
    function init() {
        return this.ctx.euromoda_init();
    }
    function controlPartidaSaldo() {
		return this.ctx.euromoda_controlPartidaSaldo();
	}
	function tbnDeshacerPagoPartida_clicked() {
		return this.ctx.euromoda_tbnDeshacerPagoPartida_clicked();
	}
}
//// EUROMODA //////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////

function euromoda_init()
{
	const _i = this.iface;
	_i.__init();
	_i.controlPartidaSaldo();
	connect(this.child("tableDBRecords"), "currentChanged()", _i, "controlPartidaSaldo");
	connect(this.child("tbnDeshacerPagoPartida"), "clicked()", _i, "tbnDeshacerPagoPartida_clicked");
}

function euromoda_controlPartidaSaldo()
{
	var _i = this.iface;
	const cursor = this.cursor();
	const idSaldoPartida = cursor.valueBuffer("em_idsaldopartida");
	if (idSaldoPartida == 0) {
        if(this.child("tbnDeshacerPagoPartida")) {
        	this.child("tbnDeshacerPagoPartida").setDisabled(true);
        }
    }else{
    	if(this.child("tbnDeshacerPagoPartida")) {
        	this.child("tbnDeshacerPagoPartida").setDisabled(false);
        }
    }
}

function euromoda_tbnDeshacerPagoPartida_clicked()
{
	const _i = this.iface;

	const cursor = this.cursor();
	const idSaldoPartida = cursor.valueBuffer("em_idsaldopartida");

	if (idSaldoPartida == 0) {
		formUI.ponMsgWarn(sys.translate("No se puede deshacer porque no hay un pago pago mediante partida"));
		return false;
	}

	var curSP = new FLSqlCursor("co_em_saldopartidas");
	curSP.select("idsaldo = " + idSaldoPartida);
	if(curSP.next()) {
		curSP.setModeAccess(curSP.Del);
    	curSP.refreshBuffer();
	    if (!curSP.commitBuffer()){
	    	return false;
	    }
	}

	this.child("tableDBRecords").refresh();
	_i.controlPartidaSaldo();

	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
