
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	var eventWatcher_, ultimaReferencia_;
  var longSubcuenta, bloqueoSubcuenta, ejercicioActual, posActualPuntoSubcuenta;
  var politicaCostes_;
  function euromoda( context ) { prod ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function modoTexto() {
    return this.ctx.euromoda_modoTexto();
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function pbnInsertarPlantillaTexto_clicked() {
    return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
  }
  function validateForm() {
    return this.ctx.euromoda_validateForm();
  }
  function initEventFilter()  {
    this.ctx.euromoda_initEventFilter();
  }
  function eventFilter(o, e)  {
    this.ctx.euromoda_eventFilter(o, e);
  }
  function initWatch(obj) {
    this.ctx.euromoda_initWatch(obj);
  }
  function finishWatch(obj)  {
    this.ctx.euromoda_finishWatch(obj);
  }
  function validaRepetidos() {
    return this.ctx.euromoda_validaRepetidos();
  }
  function dameFiltroReferencia() {
    return this.ctx.euromoda_dameFiltroReferencia();
  }
	function ledEmArticulo_returnPressed() {
    return this.ctx.euromoda_ledEmArticulo_returnPressed();
  }
  function aceptarFormulario() {
  	return this.ctx.euromoda_aceptarFormulario();
  }
  function aceptaContinuaFormulario() {
  	return this.ctx.euromoda_aceptaContinuaFormulario();
  }
  function habilitarBotonesAceptar() {
  	return this.ctx.euromoda_habilitarBotonesAceptar();
  }
	function evaluarCostes(oParamLin) {
  		return this.ctx.euromoda_evaluarCostes(oParamLin)	
  	}
	function anotarEstadoCostesLinea(oParam) {
  		return this.ctx.euromoda_anotarEstadoCostesLinea(oParam)	
  	}
	function anotarCostesLinea(oParam) {
  		return this.ctx.euromoda_anotarCostesLinea(oParam)	
  	}
	function vaciaCostesLinea(cursor, vaciaCostes, vaciaMargen) {
  		return this.ctx.euromoda_vaciaCostesLinea(cursor, vaciaCostes, vaciaMargen)	
  	}
	function cargaCostesLinea(cursor, cargaCostes, cargaMargen) {
  		return this.ctx.euromoda_cargaCostesLinea(cursor, cargaCostes, cargaMargen)	
  	}
	function dameParamCostesProdLin(cursor) {
  		return this.ctx.euromoda_dameParamCostesProdLin(cursor)	
  	}
	function evaluarCostesLinea(oParam) {
  		return this.ctx.euromoda_evaluarCostesLinea(oParam)	
  	}
	function dameImporteNetoH(cursor) {
  		return this.ctx.euromoda_dameImporteNetoH(cursor)	
  	}
	function damePrecioNetoQ(oParam) {
  		return this.ctx.euromoda_damePrecioNetoQ(oParam)	
  	}
  	function dameCosteProdMargen(oParam) {
  		return this.ctx.euromoda_dameCosteProdMargen(oParam);
  	}
	function avisarLinea(oParam) {
		return this.ctx.euromoda_avisarLinea(oParam);
	}
	function ponPoliticaCostes(tabla, codCliente) {
		return this.ctx.euromoda_ponPoliticaCostes(tabla, codCliente);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_ponPoliticaCostes(tabla, codCliente) {
		return this.ponPoliticaCostes(tabla, codCliente);
	}	
	function pub_evaluarCostes(oParamLin) {
  		return this.evaluarCostes(oParamLin);	
  	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
	var codCliente;
	var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(cursor);
	if (!datosTP) {
		codCliente = false;
	} else {
		codCliente = datosTP["codcliente"];
	}	
	_i.ponPoliticaCostes("presupuestoscli",codCliente);
  
 _i.ultimaReferencia_ = cursor.valueBuffer("referencia");
  switch (cursor.modeAccess()) {
  case cursor.Edit: {
      sys.disableObj(this, "fdbTipoConcepto");
      break;
    }
  }
	connect(this.child("ledEmArticulo"), "returnPressed()", _i, "ledEmArticulo_returnPressed");
  
  connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");
  _i.__init();
	formRecordlineaspedidoscli.iface.pub_habilitaTipoConcepto(this);
  _i.modoTexto();
  
  if (sys.isLoadedModule("flcontppal")) {
    _i.ejercicioActual = flfactppal.iface.pub_ejercicioActual();
    _i.longSubcuenta = AQUtil.sqlSelect("ejercicios", "longsubcuenta", "codejercicio = '" + _i.ejercicioActual + "'");
    _i.bloqueoSubcuenta = false;
    _i.posActualPuntoSubcuenta = -1;
    this.child("fdbIdSubcuenta").setFilter("codejercicio = '" + _i.ejercicioActual + "'");
  }
  try {
		AQS.setTabOrder(this.child("fdbReferencia").obj(), this.child("fdbCantidad").obj());
		AQS.setTabOrder(this.child("fdbCantidad").obj(), this.child("fdbPvpUnitario").obj());
	} catch (e) {}
	
	this.child("fdbCantidad").setDisabled(false); /// En presupuestos siempre dejamos modificar la cantidad
	//_i.initEventFilter();
  //_i.initWatch(this.child("fdbReferencia").editor());
	switch (cursor.modeAccess()) {
	case cursor.Insert: {
			this.child("ledEmArticulo").setFocus();
			break;
		}
  }

  	//Desconectamos el boton aceptar
	if(this.child("pushButtonAccept")){
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	  	connect(this.child("pushButtonAccept"), "clicked()", _i, "aceptarFormulario");
	}

	if(this.child("pushButtonAcceptContinue")){
  		disconnect(this.child("pushButtonAcceptContinue"), "clicked()", this.obj(), "acceptContinue()");
  		connect(this.child("pushButtonAcceptContinue"), "clicked()", _i, "aceptaContinuaFormulario");

  		_i.habilitarBotonesAceptar(); //this.child("pushButtonAcceptContinue").setDisabled(false);
  	}
}

function euromoda_ledEmArticulo_returnPressed()
{
	formRecordlineaspedidoscli.iface.pub_commonLedEmArticulo_returnPressed(this);
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "tipoconcepto": {
      _i.__bufferChanged(fN);
      _i.modoTexto();
      break;
    }
		case "referencia": {
			/// S�lo se calcula la descripci�n, el resto cuando se pierde el foco
			sys.setObjText(this, "fdbDescripcion", _i.calculateField("desarticulo"));
			_i.bufferChanged("referenciaLostFocus");
      break;
    }
		case "referenciaLostFocus": {
			if (cursor.valueBuffer("referencia") != _i.ultimaReferencia_) {
				_i.ultimaReferencia_ = cursor.valueBuffer("referencia");
				_i.__bufferChanged("referencia");
			}
			break;
		}
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_modoTexto()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
  case "Texto": {
      this.child("fdbReferencia").setValue("");
      this.child("fdbCantidad").setValue(0);
      this.child("fdbPvpUnitario").setValue(0);
      this.child("fdbCodImpuesto").setValue("");
      this.child("groupBox7").enabled = false;
      this.child("groupBox8").enabled = false;
      this.child("groupBox9").enabled = false;
      this.child("groupBox10").enabled = false;
      this.child("tbwLinea").setTabEnabled("texto", true);
      this.child("tbwLinea").showPage("texto");
      this.child("fdbTexto").setFocus();
      break;
    }
  default: {
      this.child("groupBox7").enabled = true;
      this.child("groupBox8").enabled = true;
      this.child("groupBox9").enabled = true;
      this.child("groupBox10").enabled = true;
      this.child("tbwLinea").showPage("movimientos");
      this.child("tbwLinea").setTabEnabled("texto", false);
      this.child("fdbTexto").setValue("");
      break;
    }
  }
}

function euromoda_pbnInsertarPlantillaTexto_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbTexto").setValue(texto);
}

function euromoda_validateForm()
{
	var cursor = this.cursor();
	var oParamLin = new Object;
	oParamLin.cursor = cursor;
	oParamLin.ignorarAvisos = false;
	oParamLin.forzarReg = false;
	oParamLin.ignorarCalculoInsert = false; 
	var _i = this.iface;
	if (!_i.__validateForm()) {
		_i.habilitarBotonesAceptar();
		return false;
	}
	if (!flfacturac.iface.pub_validaIvaLinea(cursor)) {
		_i.habilitarBotonesAceptar();
		return false;
	}
	if (!_i.validaRepetidos()) {
		_i.habilitarBotonesAceptar();
    	return false;
  	}
  	if(!_i.evaluarCostes(oParamLin)) {
  		_i.habilitarBotonesAceptar();
    return false;
  }
	return true;
}

function euromoda_validaRepetidos()
{
	var _i = this.iface;
  var cursor = this.cursor();
  var referencia  = cursor.valueBuffer("referencia");
	if (referencia) {
		var numLinea = AQUtil.sqlSelect("lineaspresupuestoscli", "numlinea", "idpresupuesto = " + cursor.valueBuffer("idpresupuesto") + " AND referencia = '" + referencia + "' AND idlinea <> " + cursor.valueBuffer("idlinea"));
		if (numLinea) {
			var res = MessageBox.warning(sys.translate("Ya existe una l�nea de presupuesto (n� %1) con esta referencia. �Desea continuar?").arg(numLinea), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
			if (res != MessageBox.Yes) {
				return false;
			}
		}
	}
	return true;
}

function euromoda_initEventFilter()
{
  var _i = this.iface;

  _i.eventWatcher_ = new QObject;
  _i.eventWatcher_.eventFilterFunction = this.name + ".iface.eventFilter";
  _i.eventWatcher_.allowedEvents = [ /**AQS.Enter, AQS.Leave AQS.FocusIn, */AQS.FocusOut/**, AQS.KeyPress*/];
}

function euromoda_eventFilter(o, e)
{
	var cursor = this.cursor();
	var _i = this.iface;
  var rtti = o.rtti();
	
  switch (e.type) {
    case AQS.FocusOut: {
debug("o.parentWidget().name " + o.parentWidget().name)
			if (o.parentWidget().name == "fdbReferencia") {
				_i.bufferChanged("referenciaLostFocus");
			}
      return true;
    }
  }
  return false;
}

function euromoda_initWatch(obj)
{
  if (obj == undefined)
    return;
  var _i = this.iface;
  obj.installEventFilter(_i.eventWatcher_);
}

function euromoda_finishWatch(obj)
{
  if (obj == undefined)
    return;
  var _i = this.iface;
  obj.removeEventFilter(_i.eventWatcher_);
}

function euromoda_dameFiltroReferencia()
{
	var _i = this.iface;
// 	var f = _i.__dameFiltroReferencia();
	var f = "NOT debaja";
	return f;
}

function euromoda_aceptarFormulario()
{
	var _i = this.iface;	
	this.child("pushButtonAccept").setDisabled(true);
	this.obj().accept();
}

function euromoda_aceptaContinuaFormulario()
{
	var _i = this.iface;	
	this.child("pushButtonAcceptContinue").setDisabled(true);
	this.obj().acceptContinue();
}

function euromoda_habilitarBotonesAceptar()
{
	this.child("pushButtonAccept").setDisabled(false);
	this.child("pushButtonAcceptContinue").setDisabled(false);
}

//function euromoda_evaluarCostes(cursor, ignorarAvisos, forzarReg)
function euromoda_evaluarCostes(oParamLin)
{
	var _i = this.iface;
	var cursor = oParamLin.cursor;
	var ignorarAvisos = oParamLin.ignorarAvisos;
	var forzarReg = oParamLin.forzarReg;
	var ignorarCalculoInsert = oParamLin.ignorarCalculoInsert; 

	var tipoConcepto = cursor.valueBuffer("tipoconcepto");
	
	if(tipoConcepto != "Producto") {
		return true;
	}
	var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(cursor);
	if (!datosTP) {
		return false;
	}
	
	var fechaDoc = datosTP.fecha;
	var autorizado = datosTP.em_autorizadocostes;

	var oParam = _i.dameParamCostesProdLin(cursor);
	oParam.cursor = cursor;
	
	//proceso1 --> anotarCostesLinea
	//proceso2 --> evaluarCostesLinea
	//proceso3 --> avisarLinea
	//proceso4 --> anotarEstadoCostesLinea
	if(ignorarAvisos) {
		oParam.ignorarAvisos = true;
	} 
	if(forzarReg) {
		oParam.forzarReg = true;
	} 
	if(ignorarCalculoInsert) {
		oParam.ignorarCalculoInsert = true;	
	}

	if(!_i.politicaCostes_ || _i.politicaCostes_.politica == "") {		
		oParam.caso = "L1";			
	} else if(_i.politicaCostes_.politica == "1-NO CONTROLADO") {
		oParam.caso = "L2";		
	} else  {
		var fechaPolitica = _i.politicaCostes_.fecha;
		if( fechaPolitica && fechaPolitica > fechaDoc) {			
			oParam.caso = "L3";		
			oParam.fechaDoc = fechaDoc;
		} else {			
			_i.anotarCostesLinea(oParam); //PROCESO1
			if(autorizado) {
				oParam.caso = "L4";								
			} else {
				oParam.tasaconv  = datosTP.tasaconv;
				oParam.pordtoesp  = datosTP.pordtoesp;
				oParam.recfinanciero  = datosTP.recfinanciero;
				var resEvaluar = _i.evaluarCostesLinea(oParam);//PROCESO2
				if(resEvaluar == "P1.1-1" || resEvaluar == "P1.1-2" || resEvaluar == "P1.4" || resEvaluar == "P1.9") {
					oParam.caso = "L5";					
				} else if(resEvaluar == "P1.2" || resEvaluar == "P1.3" || resEvaluar == "P1.6" || resEvaluar == "P1.8") {
					if(_i.politicaCostes_.politica == "2-No avisar y dejar continuar") {
						oParam.caso = "L6";							
					} else if(_i.politicaCostes_.politica != "3-Avisar y dejar continuar"){
						oParam.caso = "L7";						
					} else {
						oParam.caso = "L8";						
						_i.anotarEstadoCostesLinea(oParam);//PROCESO4
						oParam.resEvaluar = resEvaluar;
						if(!_i.politicaCostes_.avisoMargen && (resEvaluar == "P1.6" || resEvaluar == "P1.8")) {
							return true;
						}
						if(!_i.avisarLinea(oParam)) {
							return false;
						}					
  						return true;
					}					
				}

			}			
		}
	}	
	_i.anotarEstadoCostesLinea(oParam);//PROCESO4
	return true;

}

function euromoda_anotarEstadoCostesLinea(oParam)
{
	//PROCESO4
	var _i = this.iface;
	var hoy = new Date();	
	var fechaHora = AQUtil.dateAMDtoDMA(hoy.toString().left(10)) + " " + hoy.toString().right(8);
	var cursor = oParam.cursor;
	var caso = oParam.caso;
	if(caso == "L1") {
		//Se ha perdido la configuraci�n de la pol�tica de costes.
		oParam.estadoCostes = "SIN POLITICA";
		oParam.politicaCostes = "No encontrada";
		oParam.motivoCostes = "La configuraci�n de pol�tica no ten�a informaci�n para aplicarla";

	} else if (caso == "L2") {
		//No comprobar
		oParam.estadoCostes = "EXENTO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "En el d�a de emisi�n " + fechaHora + " la pol�tica era: No controlar";	

	} else if (caso == "L3") {
		oParam.estadoCostes = "EXENTO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "Fecha de documento " + AQUtil.dateAMDtoDMA(oParam.fechaDoc.toString().left(10)) + " menor a la fecha de control " + AQUtil.dateAMDtoDMA(_i.politicaCostes_.fecha.toString().left(10));	
		
	} else if (caso == "L4") {
		oParam.estadoCostes = "AUTORIZADO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "AUTORIZADO";		
	} else if (caso == "L5") {
		oParam.politicaCostes = _i.politicaCostes_.politica;
	} else if (caso == "L6") {
		oParam.politicaCostes = _i.politicaCostes_.politica;
	} else if (caso == "L7") {
		oParam.politicaCostes = "No encontrada";
	} else if (caso == "L8") {
		oParam.politicaCostes =_i.politicaCostes_.politica;
	}
	cursor.setValueBuffer("em_estadocostes",oParam.estadoCostes);
	cursor.setValueBuffer("em_politicacostes",oParam.politicaCostes);
	cursor.setValueBuffer("em_motivocostes",oParam.motivoCostes);
	//cursor.setValueBuffer("em_precionetoq",oParam.precioNetoQ);
}

function euromoda_anotarCostesLinea(oParam)
{
	
	//PROCESO1
	var _i = this.iface;
	var cursor = oParam.cursor;
	var costeProd = false;		
	var margenProd = false;
	if(cursor.isNull("em_costeprod")) {
		costeProd = true;
	}
	if(cursor.isNull("em_margenprod")) {
		margenProd = true;
	}
	if(cursor.modeAccess() == cursor.Insert && !oParam.ignorarCalculoInsert) {	
		if((costeProd && margenProd)) {			
			_i.vaciaCostesLinea(cursor, true, true);
			_i.cargaCostesLinea(cursor, true, true);				
		} else if(costeProd) {			
			_i.vaciaCostesLinea(cursor,true,false);
			_i.cargaCostesLinea(cursor,true,false);
		} else if(margenProd) {			
			_i.vaciaCostesLinea(cursor,false,true);
			_i.cargaCostesLinea(cursor,false,true);
		} 
	} else if(cursor.modeAccess() == cursor.Edit) {		
		if(cursor.valueBuffer("referencia") != cursor.valueBufferCopy("referencia")) {			
			_i.vaciaCostesLinea(cursor, true, true);
			_i.cargaCostesLinea(cursor, true, true);
		} else {	
			if((costeProd && margenProd) || oParam.forzarReg) {				
				_i.vaciaCostesLinea(cursor, true, true);
				_i.cargaCostesLinea(cursor, true, true);				
			} else if(costeProd) {				
				_i.vaciaCostesLinea(cursor,true,false);
				_i.cargaCostesLinea(cursor,true,false);
			} else if(margenProd) {				
				_i.vaciaCostesLinea(cursor,false,true);
				_i.cargaCostesLinea(cursor,false,true);
			} 			
		}
	}	
}

function euromoda_vaciaCostesLinea(cursor, vaciaCostes, vaciaMargen)
{
	var _i = this.iface;
	if(vaciaCostes) {		
		cursor.setNull("em_costeprod");
		cursor.setNull("em_fechacosteprod");
		cursor.setNull("em_horacosteprod");
		cursor.setNull("em_alarmaoff");
	}
	if(vaciaMargen) {		
		cursor.setNull("em_margenprod");
		cursor.setNull("em_fechamargenprod");
		cursor.setNull("em_horamargenprod");
		cursor.setNull("em_alarmaoff");
	}
}

function euromoda_cargaCostesLinea_old(cursor)
{
	
	var _i = this.iface;
	var q = new AQSqlQuery;	
	q.setSelect("COALESCE(em_costeprod,-99999999),em_fechacosteprod,em_horacosteprod,em_margenprod,em_fechamargenprod,em_horamargenprod");
	q.setFrom("articulos");
	q.setWhere("referencia = '" + cursor.valueBuffer("referencia") + "'"); 				
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{
		var coste = q.value(0);
		if(coste == "-99999999") {
			cursor.setNull("em_costesprod");
		} else {
			cursor.setValueBuffer("em_costeprod",coste);
		}	 		
		cursor.setValueBuffer("em_fechacosteprod",q.value("em_fechacosteprod"));
		cursor.setValueBuffer("em_horacosteprod",q.value("em_horacosteprod"));
		cursor.setValueBuffer("em_margenprod",q.value("em_margenprod"));
		cursor.setValueBuffer("em_fechamargenprod",q.value("em_fechamargenprod"));
		cursor.setValueBuffer("em_horamargenprod",q.value("em_horamargenprod"));		
	}	

}

function euromoda_cargaCostesLinea(cursor, cargaCostes, cargaMargen)
{
	
	var _i = this.iface;

	var curArticulos = new FLSqlCursor("articulos");   
	curArticulos.select("referencia = '" + cursor.valueBuffer("referencia") + "'");
	if (!curArticulos.first()) {
		return false;
	}
	if(cargaCostes) {		
		if(curArticulos.isNull("em_costeprod")) {
			cursor.setNull("em_costesprod");
		} else {
			cursor.setValueBuffer("em_costeprod",curArticulos.valueBuffer("em_costeprod"));
		}

		if(curArticulos.isNull("em_fechacosteprod")) {
			cursor.setNull("em_fechacosteprod");
		} else {
			cursor.setValueBuffer("em_fechacosteprod",curArticulos.valueBuffer("em_fechacosteprod"));
		}

		if(curArticulos.isNull("em_horacosteprod")) {
			cursor.setNull("em_horacosteprod");
		} else {
			cursor.setValueBuffer("em_horacosteprod",curArticulos.valueBuffer("em_horacosteprod"));
		}
	}
	if(cargaMargen) {		
		if(curArticulos.isNull("em_margenprod")) {
			cursor.setNull("em_margenprod");
		} else {
			cursor.setValueBuffer("em_margenprod",curArticulos.valueBuffer("em_margenprod"));
		}

		if(curArticulos.isNull("em_fechamargenprod")) {
			cursor.setNull("em_fechamargenprod");
		} else {
			cursor.setValueBuffer("em_fechamargenprod",curArticulos.valueBuffer("em_fechamargenprod"));
		}

		if(curArticulos.isNull("em_horamargenprod")) {
			cursor.setNull("em_horamargenprod");
		} else {
			cursor.setValueBuffer("em_horamargenprod",curArticulos.valueBuffer("em_horamargenprod"));
		}
	}
}

function euromoda_dameParamCostesProdLin(cursor)
{
	var _i = this.iface;
	var oParam = new Object;

	oParam.estadoCostes = "";
	oParam.politicaCostes = "";
	oParam.motivoCostes = "";
	oParam.avisoLinea = "";
	oParam.precioNetoQ = 0;
	oParam.ignorarAvisos = false;
	oParam.forzarReg = false;
	oParam.ignorarCalculoInsert = false;
	return oParam;
}

/*function euromoda_evaluarCostesLinea(oParam)
{
	//PROCESO2
	
	var _i = this.iface;
	var cursor = oParam.cursor
	var importeNetoH = _i.dameImporteNetoH(cursor);	
	
	var res;	
	var idLinea = cursor.valueBuffer("idlinea");
	
	if(importeNetoH < 0) {
		
		res = "P1.1-1";
		oParam.estadoCostes = "EXENTO";
		oParam.motivoCostes = "Importe negativo";
	} else if(cursor.isNull("em_costeprod")) {
		
		res = "P1.2";
		oParam.estadoCostes = "NO SUPERADO";
		oParam.motivoCostes = "No hay costes";
	} else if(cursor.valueBuffer("em_costeprod") == 0) {
		
		res = "P1.1-2"
		oParam.estadoCostes = "EXENTO";
		oParam.motivoCostes = "Coste prod = 0";
	} else {
	
		var precioNetoQ = _i.damePrecioNetoQ(oParam);	
		
		oParam.precioNetoQ = precioNetoQ;
		var costeProd = AQUtil.roundFieldValue(cursor.valueBuffer("em_costeprod"),"articulos","em_costeprod");	
		
		if(parseFloat(precioNetoQ) <= parseFloat(costeProd)) {
		
			res = "P1.3";
			oParam.estadoCostes = "NO SUPERADO";
			oParam.motivoCostes = "Por debajo de costes: " + precioNetoQ + "<="+ costeProd;			
			oParam.costeProd = costeProd;
		} else {
		
			res = "P1.4";
			oParam.estadoCostes = "APROBADO";
			oParam.motivoCostes = "APROBADO: precio "+ precioNetoQ + " mayor que coste "+costeProd;
		}
	}
	return res;
}*/

function euromoda_evaluarCostesLinea(oParam)
{
	//PROCESO2
	
	var _i = this.iface;
	var cursor = oParam.cursor
	var importeNetoH = _i.dameImporteNetoH(cursor);	
	
	var res;	
	var idLinea = cursor.valueBuffer("idlinea");
	
	if(importeNetoH < 0) {
		
		res = "P1.1-1";
		oParam.estadoCostes = "EXENTO";
		oParam.motivoCostes = "Importe negativo";
	} else if(cursor.isNull("em_costeprod")) {
		
		res = "P1.2";
		oParam.estadoCostes = "NO SUPERADO";
		oParam.motivoCostes = "No hay costes";
	} else if(cursor.valueBuffer("em_costeprod") == 0) {
		
		res = "P1.1-2"
		oParam.estadoCostes = "EXENTO";
		oParam.motivoCostes = "Coste prod = 0";
	} else {
	
		var precioNetoQ = _i.damePrecioNetoQ(oParam);			
		oParam.precioNetoQ = precioNetoQ;

		//20-01-2019 Redondeo a 2 decimaales . Correo de Jose 18-01-2019 #EUR #H1621
		//var costeProd = AQUtil.roundFieldValue(cursor.valueBuffer("em_costeprod"),"articulos","em_costeprod");	
		var costeProd = AQUtil.roundFieldValue(cursor.valueBuffer("em_costeprod"),"lineaspresupuestoscli","pvptotal");
		oParam.costeProd = costeProd;

		//if(parseFloat(precioNetoQ) <= parseFloat(costeProd)) { 20-01-2019 #EUR #H1621
		if(parseFloat(precioNetoQ) < parseFloat(costeProd)) {			
			res = "P1.3";
			oParam.estadoCostes = "NO SUPERADO";
			oParam.motivoCostes = "Por debajo de costes: " + precioNetoQ + "<"+ costeProd;			
			
		} else {		
			if(_i.politicaCostes_.evaluarMargen) {
				if(cursor.isNull("em_margenprod")) {
					res = "P1.6";
					oParam.estadoCostes = "NO SUPERADO";
					oParam.motivoCostes = "No hay m�rgenes";								
				} else {
					var costeProdMargen = _i.dameCosteProdMargen(oParam);
					oParam.costeProdMargen = costeProdMargen;
					//if(parseFloat(precioNetoQ) <= parseFloat(costeProdMargen)) {20-01-2019 #EUR #H1621
					if(parseFloat(precioNetoQ) < parseFloat(costeProdMargen)) {
						res = "P1.8";
						oParam.estadoCostes = "NO SUPERADO";
						oParam.motivoCostes = "El precio+dtos " + precioNetoQ + " es menor al coste+m�rgenes "+ costeProdMargen;								
					} else {
						res = "P1.9";
						oParam.estadoCostes = "APROBADO";
						oParam.motivoCostes = "El precio+dtos " + precioNetoQ + " es mayor o igual al coste+m�rgenes "+ costeProdMargen;							
					}
				}
			} else {
				res = "P1.4";
				oParam.estadoCostes = "APROBADO";
				oParam.motivoCostes = "APROBADO: precio "+ precioNetoQ + " mayor o igual que coste "+costeProd;
			}

		}
	}
	return res;
}


function euromoda_dameImporteNetoH(cursor)
{
	//no tengo claro que sea esto
	var H = cursor.valueBuffer("pvptotal"); 
	return H;
}

function euromoda_damePrecioNetoQ(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;
	//a --> Cantidad linea
	//b --> Precio linea
	//c --> %dto linea
	//d --> importe %dto d=(b*c)/100
	//e --> Precio neto e = (b-d)
	//f --> subtotal f = (a*e)
	//g --> Importe Dto lineal
	//h --> Importe linea neto 1 h =(f-g)

	//i --> %dto cabecera
	//j --> importe dto cabecera linea j=h*i
	//k --> importe linea neto 2 k=h-j o k=h*(1-i)
	//L --> %R.Financiero 
	//M --> importe R.Financiero linea M=k*L
	//N --> Importe linea neto total N=k+M o N=k*(1*L)

	//O --> Precio en moneda a evaluar O=N/a
	//P --> Tasa Conversion Moneda EUR  

	//Q --> Precio a evaluar en EUR Q=P*O 


	var a = parseFloat(cursor.valueBuffer("cantidad"));
	var b = parseFloat(cursor.valueBuffer("pvpunitario"));
	var c = parseFloat(cursor.valueBuffer("dtopor"));
	var d = AQUtil.roundFieldValue(parseFloat(b)*parseFloat(c)/100,"articulos","pvp");
	var e = AQUtil.roundFieldValue(parseFloat(b)-parseFloat(d),"articulos","pvp");
	var f = AQUtil.roundFieldValue(parseFloat(a)*parseFloat(e),"lineaspedidoscli","pvptotal");
	var g = parseFloat(cursor.valueBuffer("dtolineal"));
	var h = AQUtil.roundFieldValue(parseFloat(f)-parseFloat(g),"lineaspedidoscli","pvptotal");
	var i = parseFloat(oParam.pordtoesp);
	var j = AQUtil.roundFieldValue(parseFloat(h)*parseFloat(i)/100,"lineaspedidoscli","pvptotal");
	var k = AQUtil.roundFieldValue(parseFloat(h)-parseFloat(j),"lineaspedidoscli","pvptotal");
	var L = parseFloat(oParam.recfinanciero);
	var M = AQUtil.roundFieldValue(parseFloat(k)*parseFloat(L)/100,"lineaspedidoscli","pvptotal");
	var N = AQUtil.roundFieldValue(parseFloat(k)+parseFloat(M),"lineaspedidoscli","pvptotal");
	var O;
	if(a!=0) {
		O = AQUtil.roundFieldValue(parseFloat(N)/parseFloat(a),"articulos","pvp");
	} else {
		O = 0;	
	} 
	var P = parseFloat(oParam.tasaconv);
	var Q = AQUtil.roundFieldValue(parseFloat(P)*parseFloat(O),"lineaspresupuestoscli","pvptotal");
	/*debug("a: "+a);
	debug("b: "+b);
	debug("c: "+c);
	debug("d: "+d);
	debug("e: "+e);
	debug("f: "+f);
	debug("g: "+g);
	debug("h: "+h);
	debug("i: "+i);
	debug("j: "+j);
	debug("k: "+k);
	debug("L: "+L);
	debug("M: "+M);
	debug("N: "+N);
	debug("O: "+O);
	debug("P: "+P);
	debug("Q: "+Q);*/

	return Q;
}

function euromoda_dameCosteProdMargen(oParam)
{
	var cursor = oParam.cursor;
	var costeProd = oParam.costeProd;
	var margenProd = cursor.valueBuffer("em_margenprod");
	var costeProdMargen = parseFloat(costeProd) * parseFloat((1+(parseFloat(margenProd/100))));
	//costeProdMargen = AQUtil.roundFieldValue(costeProdMargen,"articulos","em_margenprod");
	//20-01-2019 Redondeo a 2 decimaales . Correo de Jose 18-01-2019 #EUR #H1621
	//costeProdMargen = AQUtil.roundFieldValue(costeProdMargen,"articulos","em_costeprod");
	costeProdMargen = AQUtil.roundFieldValue(costeProdMargen,"lineaspresupuestoscli","pvptotal");
	return costeProdMargen;
}

function euromoda_avisarLinea(oParam)
{
	//PROCESO3
	var _i = this.iface;
	if(oParam.ignorarAvisos) {
		return true;
	}
	var titulo1,titulo2,mensaje;
	titulo1 = "ATENCI�N: CONTROL DE COSTES NO SUPERADO";
	if(oParam.resEvaluar == "P1.2") {
		titulo2 ="Costes vac�o o nulo.";
		mensaje = "Es necesario un coste para superar el control de costes.\nAvise a la persona adecuada para corregir el problema y poder\nsuperar el control";
	} else if(oParam.resEvaluar == "P1.3") {
		titulo2 = "Precio por debajo del coste.";
		mensaje = "El precio+descuentos "+oParam.precioNetoQ+" est� por debajo del coste de producci�n de "+oParam.costeProd+" para el art�culo indicado.\n\nRevise precios y descuentos aplicados.";
	} else if(oParam.resEvaluar == "P1.6") {
		titulo2 = "Margen vac�o o nulo";
		mensaje = "Es necesario un margen para superar el control de costes.\nAvise a la persona adecuada para corregir el problema y poder\nsuperar el control";
	} else if(oParam.resEvaluar == "P1.8") {
		titulo2 = "Precio por debajo de m�rgenes.";
		mensaje = "El precio+descuentos "+oParam.precioNetoQ+" est� por debajo de los costes+m�rgenes de producci�n de "+oParam.costeProdMargen+" para el art�culo indicado.\n\nRevise precios y descuentos aplicados.";
	}

	var f = new FLFormSearchDB("em_preguntamsg");
  	var curC = f.cursor();
  	curC.setModeAccess(curC.Insert);
  	curC.refreshBuffer();
  	curC.setValueBuffer("titulo1",titulo1);  
  	curC.setValueBuffer("titulo2",titulo2);  
  	curC.setValueBuffer("mensaje",mensaje);  
  	f.setMainWidget();
   	f.exec();
  	if (!f.accepted()) {   		
        return false;
    }
    return true;

}

function euromoda_ponPoliticaCostes(tabla, codCliente)
{
	var _i = this.iface;
	_i.politicaCostes_ = new Object;
	if(tabla == "presupuestoscli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicaprescli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapoliprescli"); 		
	} else if (tabla == "pedidoscli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicapedcli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapolipedcli");

	} else if (tabla == "albaranescli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicaalbcli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapolialbcli");

	} else if (tabla == "facturascli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicafaccli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapolifaccli");
	}
	if(codCliente && codCliente != "") {
		var noEvaluarMargenCli = AQUtil.sqlSelect("clientes","em_noevaluarmargencli","codcliente = '" + codCliente + "'");		
		if(noEvaluarMargenCli) {		
			_i.politicaCostes_.evaluarMargen = false;
			_i.politicaCostes_.avisoMargen = false;
		} else {			
			_i.politicaCostes_.evaluarMargen = flfacturac.iface.pub_valorDefecto("em_evaluarmargen");
			_i.politicaCostes_.avisoMargen = flfacturac.iface.pub_valorDefecto("em_avisomargen");			
		}
	} else {	
		_i.politicaCostes_.evaluarMargen = flfacturac.iface.pub_valorDefecto("em_evaluarmargen");
		_i.politicaCostes_.avisoMargen = flfacturac.iface.pub_valorDefecto("em_avisomargen");		
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
