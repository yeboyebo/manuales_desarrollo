
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
  var numHojaEtiqueta_;	
  var numLineasDesc_;
  var numLineasOrden_;
  var numLineasSubfam_;
  var lineas_;
  function euromoda( context ) { oficial ( context ); }
  
  function observacionesCV(nodo, campo) {
    return this.ctx.euromoda_observacionesCV(nodo, campo);
  }
  function tacosCV(nodo, campo) {
    return this.ctx.euromoda_tacosCV(nodo, campo);
  }
  function pedidoOP(nodo, campo) {
    return this.ctx.euromoda_pedidoOP(nodo, campo);
  }
  function clienteOP(nodo, campo) {
    return this.ctx.euromoda_clienteOP(nodo, campo);
  }
  function plataformaCH(nodo, campo) {
    return this.ctx.euromoda_plataformaCH(nodo, campo);
  }
  function observacionesCHor(nodo, campo) {
    return this.ctx.euromoda_observacionesCHor(nodo, campo);
  }
	function observacionesAcol(nodo, campo) {
    return this.ctx.euromoda_observacionesAcol(nodo, campo);
  } 
  function observacionesDConf(nodo, campo) {
    return this.ctx.euromoda_observacionesDConf(nodo, campo);
  }
  function damePageHeader(nodo, campo) {
    return this.ctx.euromoda_damePageHeader(nodo, campo);
  }
  function observacionesAux(nodo, campo) {
    return this.ctx.euromoda_observacionesAux(nodo, campo);
  }
  function hayObservacionesAux(nodo, campo) {
  	return this.ctx.euromoda_hayObservacionesAux(nodo, campo);
  }
  function datosEtiDropShipping(nodo, campo) {
  	return this.ctx.euromoda_datosEtiDropShipping(nodo, campo);
  }
  function datosColaProduccion(nodo, campo) {
  	return this.ctx.euromoda_datosColaProduccion(nodo, campo);
  }  	
  function datosEmbalaje(nodo, campo) {
  	return this.ctx.euromoda_datosEmbalaje(nodo, campo);
  }
  function tamaColorPrenda(nodo, campo) {
  	return this.ctx.euromoda_tamaColorPrenda(nodo, campo);
  }
  	function dameDescCompNorm(nodo, campo) {
		return this.ctx.euromoda_dameDescCompNorm(nodo, campo);
	}
	function dameDescCodSerieDiseno(nodo, campo) {
		return this.ctx.euromoda_dameDescCodSerieDiseno(nodo, campo);
	}
	function observacionesAuxAg(nodo, campo) {
    	return this.ctx.euromoda_observacionesAuxAg(nodo, campo);
  	}
  	function dameCantidadMA(nodo, campo) {
  		return this.ctx.euromoda_dameCantidadMA(nodo, campo);
  	}
  	function dameCantidadSumaMA(nodo, campo) {
  		return this.ctx.euromoda_dameCantidadSumaMA(nodo, campo);
  	}
  	function dameCantidadSumaMAF(nodo, campo) {
  		return this.ctx.euromoda_dameCantidadSumaMAF(nodo, campo);
  	}
  	function dameDescPrepMat(nodo, campo) {
  		return this.ctx.euromoda_dameDescPrepMat(nodo, campo);
  	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////

function euromoda_observacionesCV(nodo, campo)
{
	var codOrden = nodo.attributeValue("pr_ordenesproduccion.codorden");
	var idSeccion = nodo.attributeValue("articuloscomp.idseccion");
	var referencia = nodo.attributeValue("articulos.referencia");
	
	var q = new FLSqlQuery;
	q.setSelect("ac.observaciones");
	q.setFrom("lotesstock ls INNER JOIN articuloscomp ac ON (ls.referencia = ac.refcompuesto AND ac.idseccion = '" + idSeccion + "')");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "' AND ac.refcomponente = '" + referencia + "' AND ac.observaciones IS NOT NULL AND ac.observaciones <> '' GROUP BY ac.observaciones");
	q.setForwardOnly(true);
	//debug("\n\nconsulta para observaciones CV:\n"+q.sql());
	if (!q.exec()) {
		return false;
	}
	var obs = "", ob;
	while (q.next()) {
		ob = q.value("ac.observaciones");
		obs += obs != "" ? "\n" : "";
		obs += ob;
	}
	return obs;
}

function euromoda_tacosCV(nodo, campo)
{
	var ancho = nodo.attributeValue("articuloscomp.ancho");
	//return (isNaN(ancho) || ancho == 0) ? 1 : Math.floor(280 / ancho);//20-11-2017

	var piezasAncho = nodo.attributeValue("articuloscomp.piezasancho");
	if(isNaN(piezasAncho) || piezasAncho == 0) {
		var anchoPiezaTej = nodo.attributeValue("articuloscomp.anchopiezatej");
		piezasAncho = (isNaN(anchoPiezaTej) || anchoPiezaTej == 0) ? 1 : Math.floor(anchoPiezaTej / ancho);
	}
	return piezasAncho;
}

function euromoda_observacionesCHor(nodo, campo)
{
	var referencia = nodo.attributeValue("lotesstock.referencia");
	var q = new FLSqlQuery;
	q.setSelect("ac.refcompuesto, ac.observaciones");
	q.setFrom("articuloscomp ac");
	q.setWhere("ac.refcompuesto = '" + referencia + "' AND ac.idseccion IN ('3', '4') AND ac.observaciones <> '' AND ac.observaciones IS NOT NULL GROUP BY ac.refcompuesto, ac.observaciones ORDER BY ac.refcompuesto")
	q.setForwardOnly(true);
	//debug("\n\nconsulta para observaciones CH:\n"+q.sql());
	if (!q.exec()) {
		return false;
	}
	var obs = "";
	while (q.next()) {
		obs += obs != "" ? "\n" : "";
		obs += q.value("ac.observaciones");
	}
	return obs;
}

function euromoda_observacionesAcol(nodo, campo)
{
	var referencia = nodo.attributeValue("lotesstock.referencia");
	var q = new FLSqlQuery;
	q.setSelect("ac.refcompuesto, ac.observaciones");
	q.setFrom("articuloscomp ac");
	q.setWhere("ac.refcompuesto = '" + referencia + "' AND ac.idseccion IN ('3', '4') GROUP BY ac.refcompuesto, ac.observaciones ORDER BY ac.refcompuesto")
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	var obs = "";
	while (q.next()) {
		obs += obs != "" ? "\n" : "";
		obs += q.value("ac.observaciones");
	}
	return obs;
}

/*function euromoda_observacionesDConf(nodo, campo)
{	
debug("euromoda_observacionesDConf");
	var _i = this.iface;
	var codOrden = nodo.attributeValue("pr_ordenesproduccion.codorden");
	var referencia = nodo.attributeValue("articulos.referencia");
	var q = new FLSqlQuery;
	q.setSelect("a.referencia, a.observacionesft, a.unidadesemb, t.descripcion, ts.unidadesemb");
	q.setFrom("lotesstock ls INNER JOIN articulos a ON ls.referencia = a.referencia LEFT OUTER JOIN em_tamanos t ON a.codtamanoem = t.codtamanoem LEFT OUTER JOIN em_tamanossubfam ts ON (a.codsubfamilia = ts.codsubfamilia AND a.codtamanoem = ts.codtamanoem)");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "' AND a.referencia = '" + referencia + "'");
	q.setForwardOnly(true);
	debug("\n\nconsulta para observaciones DConf:\n"+q.sql());
	if (!q.exec()) {
		return false;
	}
	var obs = "", unidadesArt, unidadesEmb;
	while (q.next()) {
		unidadesArt = parseFloat(q.value("a.unidadesemb"));
		unidadesArt = isNaN(unidadesArt) ? 0 : unidadesArt;
		unidadesEmb = unidadesArt != 0 ? unidadesArt : q.value("ts.unidadesemb");
		obs += obs != "" ? "\n" : "";
		obs += sys.translate("ART: %1 %2 : Uni/Emb: %3 %4").arg(q.value("a.referencia")).arg(q.value("t.descripcion")).arg(unidadesEmb).arg(q.value("a.observacionesft"));
		//miramos si hay observaciones que aparecerán en la hoja de materiales, si hay, añadimos [ OJO OBSERVACIONES EN LA HOJA DE MATERIALES ]
		var hayObsAux = _i.hayObservacionesAux(nodo, campo);
		if(hayObsAux) {
			obs += sys.translate(" [ OJO OBSERVACIONES EN LA HOJA DE MATERIALES ]");	
		}
	}
	return obs;
}*/

function euromoda_observacionesDConf(nodo, campo)
{
//debug("euromoda_observacionesDConf");
	var _i = this.iface;
	var codOrden = nodo.attributeValue("pr_ordenesproduccion.codorden");
	var referencia = nodo.attributeValue("articulos.referencia");
	var q = new FLSqlQuery;
	q.setSelect("a.referencia,a.observacionesft,a.unidadesemb,t.descripcion,ts.unidadesemb,clicol.em_unidadesemb,clicol2.em_unidadesemb,clicol3.em_unidadesemb");
	q.setFrom("lotesstock ls INNER JOIN pr_ordenesproduccion op ON op.codorden = ls.codordenproduccion INNER JOIN articulos a ON ls.referencia = a.referencia LEFT OUTER JOIN em_tamanos t ON a.codtamanoem = t.codtamanoem LEFT OUTER JOIN em_tamanossubfam ts ON (a.codsubfamilia = ts.codsubfamilia AND a.codtamanoem = ts.codtamanoem) LEFT OUTER JOIN em_embsubfamclicol clicol ON (op.codcliente = clicol.codcliente AND clicol.codsubfamilia = a.codsubfamilia AND clicol.codtamanoem = a.codtamanoem AND clicol.codcoleccionem = a.codcoleccionem) LEFT OUTER JOIN  em_embsubfamclicol clicol2 ON (clicol2.codsubfamilia = a.codsubfamilia AND clicol2.codtamanoem = a.codtamanoem AND clicol2.codcliente = op.codcliente AND (clicol2.codcoleccionem is null OR clicol2.codcoleccionem ='')) LEFT OUTER JOIN  em_embsubfamclicol clicol3 ON (clicol3.codsubfamilia = a.codsubfamilia AND clicol3.codtamanoem = a.codtamanoem AND clicol3.codcoleccionem = a.codcoleccionem AND (clicol3.codcliente is null OR clicol3.codcliente =''))");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "' AND a.referencia = '" + referencia + "'");
	q.setForwardOnly(true);
	//debug("\n\nconsulta para observaciones DConf:\n"+q.sql());
	if (!q.exec()) {
		return false;
	}
	var obs = "", unidadesArt, unidadesEmb, unidadesCliCol, unidadesCliCol2, unidadesCliCol3,unidadesSubFam;
	while (q.next()) {
		//1.referencia
		unidadesArt = parseFloat(q.value("a.unidadesemb"));
		unidadesArt = isNaN(unidadesArt) ? 0 : unidadesArt;
		//2.Busqueda por subfamilia-tama�o-coleccion-cliente
		unidadesCliCol = parseFloat(q.value("clicol.em_unidadesemb"));
		unidadesCliCol = isNaN(unidadesCliCol) ? 0 : unidadesCliCol;
		//3.Busqueda por subfamilia-tama�o-cliente
		unidadesCliCol2 = parseFloat(q.value("clicol2.em_unidadesemb"));
		unidadesCliCol2 = isNaN(unidadesCliCol2) ? 0 : unidadesCliCol2;
		//4. Busqueda por subfamilia-tama�o-coleccion
		unidadesCliCol3 = parseFloat(q.value("clicol3.em_unidadesemb"));
		unidadesCliCol3 = isNaN(unidadesCliCol3) ? 0 : unidadesCliCol3;
		//5. Busqueda por tama�o de subfamilia 
		unidadesSubFam = parseFloat(q.value("ts.unidadesemb"));
		unidadesSubFam = isNaN(unidadesSubFam) ? 0 : unidadesSubFam;

		if(unidadesArt !=0) {
			unidadesEmb = unidadesArt;
		} else if(unidadesCliCol != 0) {
			unidadesEmb = unidadesCliCol;
		} else if(unidadesCliCol2 != 0) {
			unidadesEmb = unidadesCliCol2;
		} else if(unidadesCliCol3 != 0) {
			unidadesEmb = unidadesCliCol3;
		} else {
			unidadesEmb = unidadesSubFam;
		}

		//unidadesEmb = unidadesArt != 0 ? unidadesArt : q.value("ts.unidadesemb");
		obs += obs != "" ? "\n" : "";
		obs += sys.translate("ART: %1 %2 : Uni/Emb: %3 %4").arg(q.value("a.referencia")).arg(q.value("t.descripcion")).arg(unidadesEmb).arg(q.value("a.observacionesft"));
		//miramos si hay observaciones que aparecerán en la hoja de materiales, si hay, añadimos [ OJO OBSERVACIONES EN LA HOJA DE MATERIALES ]
		var hayObsAux = _i.hayObservacionesAux(nodo, campo);
		if(hayObsAux) {
			obs += sys.translate(" [ OJO OBSERVACIONES EN LA HOJA DE MATERIALES ]");	
		}
	}
	return obs;
}

function euromoda_pedidoOP(nodo, campo)
{
	var codPedido = "";
	if(campo == "agrupado") {
		codPedido = nodo.attributeValue("v_ordenesprod_alag.codpedidocli")
	} else {
		codPedido = nodo.attributeValue("pr_ordenesproduccion.codpedidocli");
	}
	return codPedido;
}

function euromoda_clienteOP(nodo, campo)
{
	var obs = "";
	if(campo == "agrupado") {
		obs = nodo.attributeValue("v_ordenesprod_alag.observaciones");
		if (!obs || obs == "") {
			obs = nodo.attributeValue("v_ordenesprod_alag.codcliente");
		}
	} else {

		obs = nodo.attributeValue("pr_ordenesproduccion.emobservaciones");
	if (!obs || obs == "") {
		obs = nodo.attributeValue("pr_ordenesproduccion.codcliente");
		}
	}
	return obs;
}

function euromoda_plataformaCH(nodo, campo)
{
	return nodo.attributeValue("articuloscomp.largo") + " x " + nodo.attributeValue("articuloscomp.ancho");
}

function euromoda_damePageHeader(nodo, campo)
{
	var _i = this.iface;
	var fecha = new Date();
	var texFecha = fecha.toString();
	var hora = texFecha.right(8);
	var texto = "";
	var numPag = formpr_ordenesproduccion.iface.numPagina();

	texto += "P�gina: " + numPag + "   Fecha: " + AQUtil.dateAMDtoDMA(texFecha.left(10)) + "  Hora: " + hora.left(5) + "  ";
	
	return texto;
}

function euromoda_observacionesAux(nodo, campo)
{

	var codOrden = nodo.attributeValue("pr_ordenesproduccion.codorden");
	var idSeccion = nodo.attributeValue("articuloscomp.idseccion");
	var referencia = nodo.attributeValue("articulos.referencia");
	var q = new FLSqlQuery;
	q.setSelect("ac.observaciones");
	q.setFrom("lotesstock ls INNER JOIN articuloscomp ac ON (ls.referencia = ac.refcompuesto AND ac.idseccion = '" + idSeccion + "')");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "' AND ac.refcomponente = '" + referencia + "' AND ac.observaciones IS NOT NULL AND ac.observaciones <> '' GROUP BY ac.observaciones");
	q.setForwardOnly(true);
	//debug("\n\nconsulta para observaciones AUX:\n"+q.sql());
	if (!q.exec()) {
		return false;
	}
	var obs = "", ob;
	while (q.next()) {
		ob = q.value("ac.observaciones");
		obs += obs != "" ? "\n" : "";
		obs += ob;
	}
	return obs;
}

function euromoda_hayObservacionesAux(nodo, campo)
{
	var idSeccion = '9';
	var codOrden = nodo.attributeValue("pr_ordenesproduccion.codorden");
	var referencia = nodo.attributeValue("articulos.referencia");
	var q = new FLSqlQuery;
	q.setSelect("ac.observaciones");
	q.setFrom("lotesstock ls INNER JOIN articuloscomp ac ON (ls.referencia = ac.refcompuesto AND ac.idseccion = '" + idSeccion + "')");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "' AND ac.refcompuesto = '" + referencia + "' AND ac.observaciones IS NOT NULL AND ac.observaciones <> '' GROUP BY ac.observaciones");
	q.setForwardOnly(true);
	//debug("\n\nconsulta para observaciones AUX:\n"+q.sql());
	if (!q.exec()) {
		return false;
	}
	var obs = "", ob;
	while (q.next()) {
		ob = q.value("ac.observaciones");
		obs += obs != "" ? "\n" : "";
		obs += ob;
	}
	if(!obs && obs == "") {
		return false
	}
	return true;
}

function euromoda_datosEtiDropShipping(nodo, campo)
{
	var valor = "";
	var _i = this.iface;
	//debug("datosEtiDropShipping");
	//debug("campo: "+campo);

	var indice = campo.right(1);

	if(campo!= "fecha" && campo!= "telefono" && campo != "direccionRemitente" && campo !="pedidoalbaran") {
		campo = campo.left(campo.length-1);
	}

	switch(campo) {


		case "fecha": {
			//fecha de albaran (albaranescli)si no fecha de hoja de carga de pedido (em_pedidosptes.fecha)si no fecha cliente pedido abanq (pedidoscli.fechasalida) si no fecha pedido abanq (pedidoscli.fecha)

			var fechaAlbaran = nodo.attributeValue("albaranescli.fecha");
			var fechaHoja = nodo.attributeValue("pedidoscli.fechahc");
			var fechaSalida = nodo.attributeValue("pedidoscli.fechasalida");
			var fechaPedido = nodo.attributeValue("pedidoscli.fecha");		

			if(fechaAlbaran && fechaAlbaran != "") {
				valor = fechaAlbaran;
			} else if(fechaHoja && fechaHoja != "") {
				valor = fechaHoja;
			} else if(fechaSalida && fechaSalida != "") {
				valor = fechaSalida;
			} else {
				valor = fechaPedido;
			}

			break;	
		}
		case "pedidoalbaran": {
			var pedido = nodo.attributeValue("pedidoscli.codigo");
			var albaran = nodo.attributeValue("em_cargadropshipping.pedidoprivalia");
			
			valor = pedido;			
			valor += valor == "" ? "" : " / ";
			valor += albaran;	
			break;
		}
		case "telefono": {
			var telefono1 = nodo.attributeValue("em_cargadropshipping.telefono1");
			var telefono2 = nodo.attributeValue("em_cargadropshipping.telefono2");
			
			valor = telefono1;			
			if(valor != "" && telefono2 != "") {
				valor += " / "
			}			
			valor += telefono2;	
			break;
		}
		case "direccionRemitente": {
			var codPostal = nodo.attributeValue("dirclientes.codpostal");
			var poblacion = nodo.attributeValue("dirclientes.ciudad");
			var provincia = nodo.attributeValue("dirclientes.provincia");
			var pais = nodo.attributeValue("paises.nombre");

			valor = codPostal;			
			valor += valor == "" ? "" : " ";
			valor += poblacion;	

			if(provincia && provincia != "") {
				valor += valor == "" ? "(" : " (";
				valor += provincia;
				valor += ")";
			}
			valor += valor == "" ? "" : " - ";
			valor += pais;

			break;
		} 
		case "ean": {
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;			
			if(_i.lineas_.length > k) {
				valor = " " + _i.lineas_[k][0];
			}
			break;	
		}	
		case "referencia": {
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;
			
			if(_i.lineas_.length > k) {
				valor = " " + _i.lineas_[k][1];
			}
			break;
		}
		case "barcode": {
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;			
			if(_i.lineas_.length > k) {
				valor = _i.lineas_[k][0];
			} else {
				/*if(indice == 3) {
					valor = "\n\n\n";	
				} else if(indice ==4) {
					valor ="///////////";
				} else if(indice ==5) {
					valor ='\\\\\\\\\\';
				}*/
				
			}
			//debug("bascode: "+valor);
			break;	
		}	
		case "descripcion": {
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;
			
			if(_i.lineas_.length > k) {
				valor = " " +_i.lineas_[k][2];
			}
			break;	
		}
		case "pedida": {
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;
			
			if(_i.lineas_.length > k) {
				valor = _i.lineas_[k][3];
			}
			break;	
		}
		case "servida": {
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;
			
			if(_i.lineas_.length > k) {
				valor = _i.lineas_[k][4];
			}
			break;	
		}
		case "descA": {
			debug("descA");
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;
			debug("k: " + k);
			debug("_i.lineas_.length: " + _i.lineas_.length);
			if(_i.lineas_.length > k) {
				valor = " " +_i.lineas_[k][5];
			}
			debug("valor: " + valor);
			break;	
		}
		case "descB": {
			var k = parseInt(_i.numHojaEtiqueta_) + parseInt(indice) - 1;
			
			if(_i.lineas_.length > k) {
				valor = " " +_i.lineas_[k][6];
			}
			break;	
		}

	}

	return valor;
}

function euromoda_datosColaProduccion(nodo, campo)
{
	
	var _i = this.iface;
	var valor = "";
	switch(campo) {
		case "descripcion": {
	
			valor = formem_colaproduccion.iface.concatenaValorSiExiste(valor,  formem_colaproduccion.iface.dameDiaMes(nodo.attributeValue("pr_ordenesproduccion.fecha")), " ");
			valor = formem_colaproduccion.iface.concatenaValorSiExiste(valor, nodo.attributeValue("pr_ordenesproduccion.emobservaciones"), " ");
			valor = formem_colaproduccion.iface.concatenaValorSiExiste(valor, nodo.attributeValue("pr_ordenesproduccion.codpedidocli"), " ");
			valor = formem_colaproduccion.iface.concatenaValorSiExiste(valor, formem_colaproduccion.iface.dameDiaMes(nodo.attributeValue("pr_ordenesproduccion.fechaentrega")), " ");	


			var tama = valor.length;
			if(!tama || tama =="") {
				tama = 0;
			}
			_i.numLineasDesc_ = Math.ceil(tama/30);
			debug("\n\n");
			debug("*****************************************************************");

			debug("descripcion: "+valor);
			debug("tama: "+tama);
			debug("SaltosDesc: "+_i.numLineasDesc_);

			debug("*****************************************************************");
			debug("\n\n");
			


			break;
		}
		case "tiempoPrev": {	

			var codorden = nodo.attributeValue("pr_ordenesproduccion.codorden");						
			valor = nodo.attributeValue("pr_ordenesproduccion.em_horasbrutascola");		
			if(valor.left(1) == "0") {
				valor = valor.right(9);				
			}
			if(valor.left(1) == "0")  {
				valor = valor.right(8);			
			}
			break;
		}	
		case "fechaFinPrev": {
			
			var fechaFinPrev = nodo.attributeValue("pr_ordenesproduccion.em_fechafinprev");
			var horaFinPrev = nodo.attributeValue("pr_ordenesproduccion.em_horafinprev");
			if(fechaFinPrev && fechaFinPrev != "" && 	horaFinPrev && horaFinPrev != "") {		
				valor = new Date(Date.parse(fechaFinPrev.toString().left(10)+horaFinPrev.toString().right(9)));		
				valor = AQUtil.dateAMDtoDMA(valor)+" "+horaFinPrev;		
			}
			break;
		}
		case "unidades": {
			var codMaquina = nodo.attributeValue("pr_ordenesproduccion.em_codmaquinacol");
			var where = formem_colaproduccion.iface.dameFiltroCola(codMaquina);
			valor = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(udsptes)", where);	
			
			break;
		}
		case "metros": {
			var codMaquina = nodo.attributeValue("pr_ordenesproduccion.em_codmaquinacol");
			var where = formem_colaproduccion.iface.dameFiltroCola(codMaquina);
			valor = AQUtil.sqlSelect("pr_ordenesproduccion", "SUM(metrosptes)", where);	
			
			break;
		}
		case "fechabase": {
			valor = "Fecha base: " + formem_colaproduccion.iface.fechaBaseColaProd_;
			break;
		}
		/*case "canPendienteTPC": {
			var ordenes = [];
			var q = new AQSqlQuery;	
			q.setSelect("em_ordenesestampacion.codordenest");
			q.setFrom("em_ordenesestampacion	INNER JOIN subfamilias ON subfamilias.codsubfamilia = em_ordenesestampacion.codsubfamilia INNER JOIN em_lineasordenest ON em_ordenesestampacion.codordenest=em_lineasordenest.codordenest INNER JOIN movistock ON movistock.emidlineaest=em_lineasordenest.idlinea");
			q.setWhere("NOT tejidoconfirmado AND movistock.cantidad<0"); 			
			if (!q.exec()){
				return;
			}  
			while(q.next())
			{
				var codOrden = q.value("em_ordenesestampacion.codordenest");

				ordenes.push(codOrden);		
				
			}
			ordenes = "'" + ordenes.join("', '") + "'";		
		
			valor = AQUtil.sqlSelect("em_ordenesestampacion", "SUM(em_ordenesestampacion.canpendiente)", "em_ordenesestampacion.codordenest in  (" + ordenes + ") ", "em_ordenesestampacion");	
			//debug("valor: "+valor);
			break;
		}
		
		case "canPendienteTC": {
		
			valor = AQUtil.sqlSelect("em_ordenesestampacion", "SUM(em_ordenesestampacion.canpendiente)", formem_colaestampacion.iface.dameFiltroConfirmado());	
			//debug("valor: "+valor);
			break;
		}*/
		case "em_codmaquinacol": {
			valor = "COLA "+nodo.attributeValue("pr_ordenesproduccion.em_codmaquinacol");
			break;
		}
		case "codorden": {
			var cont = 1;
			var codOrden = nodo.attributeValue("pr_ordenesproduccion.codorden");		
			valor = codOrden;
			var codBobina,soporte;			
			var q = new AQSqlQuery;	
			q.setSelect("p.codbobinapiezaroll,b.soporteactual");
			q.setFrom("v_piezasrollbob p INNER JOIN em_bobinas b ON p.codbobinapiezaroll = b.codbobina");
			q.setWhere("p.codordenproduccion = '" + codOrden + "' GROUP BY p.codbobinapiezaroll,b.soporteactual");	
			if (!q.exec()){
				return;
			}  
			//debug("q: "+q.sql());
			while(q.next())
			{	
				codBobina = q.value("p.codbobinapiezaroll");
				soporte = q.value("b.soporteactual");		
				if(valor != "") {
					valor += "\n"
				}
				valor += soporte+"/"+codBobina;
				cont++;
			}
			_i.numLineasOrden_ = cont;


			var saltos = 0;
			if(_i.numLineasDesc_ >= _i.numLineasSubfam_ &&  _i.numLineasDesc_ >= _i.numLineasOrden_) {
				saltos = _i.numLineasDesc_ - _i.numLineasOrden_; 
			} else if (_i.numLineasSubfam_ >= _i.numLineasDesc_ && _i.numLineasSubfam_ >= _i.numLineasOrden_) {
				saltos = _i.numLineasSubfam_ - _i.numLineasOrden_;
			} 
			debug("\n\n");
			debug("*****************************************************************");

			debug("codorden: "+valor);
			debug("SaltosSubfam: "+_i.numLineasSubfam_);
			debug("SaltosDesc: "+_i.numLineasDesc_);
			debug("SaltosOrden: "+_i.numLineasOrden_);
			debug("saltosTotal: "+saltos);


			for(var i=0; i<saltos; i++) {
				valor += "\n ";
			}

			debug("codorden despu�s de los saltos: "+valor);
			debug("*****************************************************************");
			debug("\n\n");
			break;
		}
		case "adescsubfam": {

			valor = nodo.attributeValue("subfamilias.descripcion");
			var tama = valor.length;

			if(!tama || tama =="") {
				tama = 0;
			}
			_i.numLineasSubfam_ = Math.ceil(tama/20);


			debug("\n\n");
			debug("*****************************************************************");

			debug("subfam: "+valor);			
			debug("SaltosSubfam: "+_i.numLineasSubfam_);

			debug("*****************************************************************");
			debug("\n\n");

			break;
		}
		
	}
	return valor;

}

/*function euromoda_datosEmbalaje(nodo, campo)
{
	var referencia = nodo.attributeValue("articulos.referencia");
	var tipoEmb, unidadesEmb, codSubfamilia;
	var ret = "";
	
	var q = new FLSqlQuery;
	q.setSelect("em_codtipoemb,unidadesemb,codsubfamilia");
	q.setFrom("articulos");
	q.setWhere("referencia = '" + referencia + "'");		
	if (!q.exec()) {
		return false;
	}	
	if (q.first()) {
		tipoEmb = q.value("em_codtipoemb");
		unidadesEmb = q.value("unidadesemb");
		codSubfamilia = q.value("codsubfamilia"); 
	}
	if(!tipoEmb || tipoEmb == "") {
		var qT = new FLSqlQuery;
		qT.setSelect("em_codtipoemb,unidadesemb");
		qT.setFrom("em_tamanossubfam");
		q.setWhere("codtamanoem = '" + codTamano + "' and codsubfamilia = '" + codSubfamilia + "'");		
		if (!q.exec()) {
			return false;
		}	
		if (q.first()) {
			tipoEmb = q.value("em_codtipoemb");
			unidadesEmb = q.value("unidadesemb");
		}
	}
	if(tipoEmb && tipoEmb != "") {
		q.setSelect("a.descripcion,a.codtamanoem,t.referencia");
		q.setFrom("articulos a inner join em_tiposemb t ON a.referencia = t.referencia");
		q.setWhere("t.em_codtipoemb = '" + tipoEmb + "'");		
		if (!q.exec()) {
			return false;
		}	
		if (q.first()) {
			ret = q.value("t.referencia") + "      " + q.value("a.descripcion") + "      " + q.value("a.codtamanoem") + "      Uni/emb: " +unidadesEmb;			
		}
	}
	return ret;
}*/

function euromoda_datosEmbalaje(nodo, campo)
{
	var referencia = nodo.attributeValue("articulos.referencia");
	var codCliente = nodo.attributeValue("pr_ordenesproduccion.codcliente");


	var aDatosEmb = flfactalma.iface.pub_dameEmbalajeArticulo(referencia, codCliente, false);

	var unidadesEmb = aDatosEmb.capacidad;
	var refEmbalaje = aDatosEmb.referencia;	
	var ret = "";
	
	var q = new FLSqlQuery;
	q.setSelect("a.descripcion,a.codtamanoem");
	q.setFrom("articulos a");
	q.setWhere("a.referencia = '" + refEmbalaje + "'");		
	if (!q.exec()) {
		return false;
	}	
	if (q.first()) {
		ret = refEmbalaje + "      " + q.value("a.descripcion") + "      " + q.value("a.codtamanoem") + "      Uni/emb: " +unidadesEmb;			
	}
	
	return ret;
}

function euromoda_tamaColorPrenda(nodo, campo)
{
	var tama = nodo.attributeValue("em_tamanos.descripcion");
	//var color = nodo.attributeValue("em_colores.descripcion");
	var color = flfactinfo.iface.datoLineaProv(nodo, "em_colores.descripcion");
	var ret = "";

	if(tama && tama != "") {
		ret = tama;
	}

	if(color && color != "") {
		if(ret != "") {
			ret += "   ";
		}

		ret +=color;
	}
	return ret;
}

/*function euromoda_dameDescCompNorm(nodo, campo)
{
	var _i = this.iface;
	var componente = nodo.attributeValue("articuloscomp.componente");
	var compoNormal = nodo.attributeValue("articuloscomp.componormal");	
	var descripcion = nodo.attributeValue("articulos.descripcion");
	var codseriediseno = nodo.attributeValue("em_disenos.codseriediseno");	


	if(compoNormal && compoNormal != "") {
		descripcion = compoNormal+": "+descripcion;
	} else if(componente && componente != "") {	
		descripcion = componente + ": " + descripcion;
	}
	if (codseriediseno && codseriediseno != ""){
		descripcion += " - [" + codseriediseno + "]"
	}
	return descripcion;
}*/

function euromoda_dameDescCompNorm(nodo, campo)
{
	var _i = this.iface;
	var componente = "";
	var compoNormal = "";
	var descripcion = "";
	var codseriediseno = "";
	var ancho = "";

	if(campo == "agrupado") {
		componente = nodo.attributeValue("v_ordenesprod_alag.componente");
		compoNormal = nodo.attributeValue("v_ordenesprod_alag.componormal");	
		descripcion = nodo.attributeValue("v_ordenesprod_alag.articulodesc");
		codseriediseno = nodo.attributeValue("v_ordenesprod_alag.codseriediseno");	
		ancho = nodo.attributeValue("v_ordenesprod_alag.ancho");

	} else {
		componente = nodo.attributeValue("articuloscomp.componente");
		compoNormal = nodo.attributeValue("articuloscomp.componormal");	
		descripcion = nodo.attributeValue("articulos.descripcion");
		codseriediseno = nodo.attributeValue("em_disenos.codseriediseno");	
		ancho = nodo.attributeValue("articuloscomp.ancho");
	}

	if(compoNormal && compoNormal != "") {
		descripcion = compoNormal+": "+descripcion;
	} else if(componente && componente != "") {	
		descripcion = componente + ": " + descripcion;
	}
	if (codseriediseno && codseriediseno != ""){
		descripcion += " - [" + codseriediseno + "]"
	}

	if(ancho && ancho != "" && ancho != 0 && compoNormal == "BIES") {
	    descripcion = descripcion + " a tacos de " + ancho + " cm" ;
	}

	return descripcion;
}

function euromoda_dameDescCodSerieDiseno(nodo, campo)
{
	var _i = this.iface;
	var descripcion;
	var codseriediseno;
	if(campo == "articulos.descripcion") {
		descripcion = nodo.attributeValue("articulos.descripcion");
		codseriediseno = nodo.attributeValue("em_disenos.codseriediseno");	
	} else if(campo == "prod.descripcion") {
		descripcion = nodo.attributeValue("prod.descripcion");
		codseriediseno = nodo.attributeValue("disprod.codseriediseno");	
	}

	if (codseriediseno && codseriediseno != ""){
		descripcion += " - [" + codseriediseno + "]"
	}
	return descripcion;
}

function euromoda_observacionesAuxAg(nodo, campo)
{

	var codOrden = nodo.attributeValue("v_ordenesprod_alag.codorden");
	var idSeccion = nodo.attributeValue("v_ordenesprod_alag.idseccion");
	var aSecciones = idSeccion.split(",");
	var referencia = nodo.attributeValue("v_ordenesprod_alag.referencia");
	var q = new FLSqlQuery;
	q.setSelect("ac.observaciones,ac.componormal");
	q.setFrom("lotesstock ls INNER JOIN articuloscomp ac ON (ls.referencia = ac.refcompuesto AND ac.idseccion IN ('" + aSecciones.join("','") + "'))");
	q.setWhere("ls.codordenproduccion = '" + codOrden + "' AND ac.refcomponente = '" + referencia + "' AND ac.observaciones IS NOT NULL AND ac.observaciones <> '' GROUP BY ac.observaciones,ac.componormal");
	q.setForwardOnly(true);
	debug("\n\nconsulta para observaciones AUX:\n"+q.sql());
	if (!q.exec()) {
		return false;
	}
	var obs = "", ob, compoNormal;
	while (q.next()) {
		ob = q.value("ac.observaciones");
		compoNormal = q.value("ac.componormal");
		obs += obs != "" ? "\n" : "";
		if(compoNormal && compoNormal != "") {
			obs += obs != "" ? "\n" : "";
			obs += compoNormal + ": ";	
		}
		obs += ob;
	}
	return obs;
}

function euromoda_dameCantidadMA(nodo, campo)
{

	var valor = nodo.attributeValue(campo);
	var compoNormal = nodo.attributeValue("articuloscomp.componormal");
	if(compoNormal == "BIES") {
		/*var canLote = nodo.attributeValue("SUM(lotesstock.canlote)");
		var cantidadFT = nodo.attributeValue("articuloscomp.cantidad");
		var largoFT = nodo.attributeValue("largoCompo"); 

		if(!canLote || canLote == "") {
			canLote = 0;
		}

		if(!cantidadFT || cantidadFT == "") {
			cantidadFT = 0;
		}

		if(!largoFT || largoFT == "") {
			largoFT = 0;
		}

		valor = (canLote * cantidadFT * largoFT)/100;*/
		valor = nodo.attributeValue("SUM(lotesstock.canlote * articuloscomp.cantidad * articuloscomp.largo)/100");
	}
	return valor;
}

function euromoda_dameCantidadSumaMA(nodo, campo)
{

	var referencia = nodo.attributeValue("movistock.referencia");
	var codPrepMat = nodo.attributeValue("em_preparacionesmat.codpreparamat");
	var compoNormal = nodo.attributeValue("articuloscomp.componormal");


	var valor;
	var q = new AQSqlQuery;
	if(compoNormal == "BIES") {			
		q.setSelect("SUM(lotesstock.canlote*articuloscomp.cantidad*articuloscomp.largo/100)");				
	} else {			
		q.setSelect("SUM(movistock.cantidad*-1)");		
	}
	q.setFrom("em_preparacionesmat INNER JOIN pr_ordenesproduccion ON em_preparacionesmat.codpreparamat = pr_ordenesproduccion.codpreparamat INNER JOIN lotesstock ON pr_ordenesproduccion.codorden = lotesstock.codordenproduccion INNER JOIN movistock ON lotesstock.codlote = movistock.codloteprod INNER JOIN articulos ON movistock.referencia = articulos.referencia LEFT OUTER JOIN articuloscomp ON movistock.idarticulocomp = articuloscomp.id");
	q.setWhere("movistock.referencia = '" + referencia + "' AND em_preparacionesmat.codpreparamat = '" + codPrepMat + "' AND (articuloscomp.idseccion = '9' OR articuloscomp.id IS NULL OR articuloscomp.componormal = 'BIES')");
	// debug("q: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{
		valor = q.value(0);		
	}
	return valor;
}

function euromoda_dameCantidadSumaMAF(nodo, campo)
{

	var referencia = nodo.attributeValue("movistock.referencia");
	var compoNormal = nodo.attributeValue("articuloscomp.componormal");
	var codOrdenDesde = formem_preparacionmat.iface.codOrdenDesde_;
	var codOrdenHasta = formem_preparacionmat.iface.codOrdenHasta_;

	/*debug("referencia: "+referencia);
	debug("compoNormal: "+compoNormal);
	debug("codOrdenDesde: "+codOrdenDesde);
	debug("codOrdenHasta: "+codOrdenHasta);
*/
	var valor;
	var q = new AQSqlQuery;
	if(compoNormal == "BIES") {			
		q.setSelect("SUM(lotesstock.canlote * articuloscomp.cantidad * articuloscomp.largo)/100");						
	} else {			
		q.setSelect("SUM(movistock.cantidad*-1)");		
	}
	q.setFrom("em_preparacionesmat INNER JOIN pr_ordenesproduccion ON em_preparacionesmat.codpreparamat = pr_ordenesproduccion.codpreparamat INNER JOIN lotesstock ON pr_ordenesproduccion.codorden = lotesstock.codordenproduccion INNER JOIN movistock ON lotesstock.codlote = movistock.codloteprod INNER JOIN articulos ON movistock.referencia = articulos.referencia LEFT OUTER JOIN articuloscomp ON movistock.idarticulocomp = articuloscomp.id");
	q.setWhere("movistock.referencia = '" + referencia + "' AND NOT pr_ordenesproduccion.materialconfok AND pr_ordenesproduccion.estado <> 'TERMINADA' AND pr_ordenesproduccion.codorden >= '" + codOrdenDesde + "' AND pr_ordenesproduccion.codorden <= '" + codOrdenHasta + "' AND (articuloscomp.idseccion = '9' OR articuloscomp.id IS NULL OR articuloscomp.componormal = 'BIES')");
	// debug("q_dameCantidadSumaMAF: "+q.sql());
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{
		valor = q.value(0);		
	}
	return valor;
}

function euromoda_dameDescPrepMat(nodo, campo)
{
	var _i = this.iface;
	var compoNormal = "";
	var descripcion = "";
	var ancho = "";

	compoNormal = nodo.attributeValue("articuloscomp.componormal");
	descripcion = nodo.attributeValue("articulos.descripcion");
	ancho = nodo.attributeValue("articuloscomp.ancho");

	if(compoNormal && compoNormal != "") {
		descripcion = compoNormal + ": " + descripcion;
	}

	if(ancho && ancho != "" && ancho != 0 && compoNormal == "BIES") {
	    descripcion = descripcion + " a tacos de " + ancho + " cm" ;
	}

	return descripcion;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
