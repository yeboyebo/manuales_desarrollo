
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function ordenarCols() {
		return this.ctx.euromoda_ordenarCols();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	sys.disableObj(this, "fdbCodAlmacen");
// 	sys.setObjText(this, "fdbCodAlmacenDest", flfactppal.iface.pub_valorDefectoEmpresa("codalmacen"));
}

function euromoda_ordenarCols()
{
	var _i = this.iface;
	var lineas:Array = ["referencia", "descripcion", "codtamanoem", "codcolorem", "cantidad", "totalenalbaran","cerrada", "incluiralbaran", "canalbaran"];
	_i.tdbLineasPedidosProv.setOrderCols(lineas);
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
