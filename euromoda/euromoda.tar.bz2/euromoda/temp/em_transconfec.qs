/***************************************************************************
                 em_transconfec.qs  -  description
                             -------------------
    begin                : mar oct 18 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
/** \C
El formulario permite borrar �rdenes s�lo si est�n en estado PTE
\end */
/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var cREF_, cDES_, cDIO_, cDID_, cCAN_, cSEL_, cNEC_;
	var cNoSel_, cSel_;
	var t_;
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); } 
	function iniciarTabla() {
		return this.ctx.oficial_iniciarTabla();
	}
	function tblLineas_clicked(f, c) {
		return this.ctx.oficial_tblLineas_clicked(f, c);
	}
	function colores() {
		return this.ctx.oficial_colores();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function autorellena() {
		return this.ctx.oficial_autorellena();
	}
	function cargaTabla() {
		return this.ctx.oficial_cargaTabla();
	}
	function coloreaFila(f, clr) {
		return this.ctx.oficial_coloreaFila(f, clr);
	}
	function creaTransferencia(oParam) {
		return this.ctx.oficial_creaTransferencia(oParam);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}
const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.t_ = this.child("tblLineas");
	
	connect(_i.t_, "clicked(int, int)", _i, "tblLineas_clicked");
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked()");
	
	_i.colores();
	_i.iniciarTabla();
	_i.cargaTabla();
	
	var cursor = this.cursor();
	if (cursor.modeAccess() == cursor.Insert) {
//		connect(this, "formReady()", _i, "autorellena");
	}
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_autorellena()
{
	var _i = this.iface;
	var t = _i.t_;
	var nF = t.numRows();
	for (var f = 0; f < nF; f++) {
		_i.tblLineas_clicked(f, _i.cSEL_);
	}
	_i.pushButtonAccept_clicked();
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var nF = _i.t_.numRows();
	var haySel = false;
	for (var f = 0; f < nF; f++) {
		if (_i.t_.text(f, _i.cSEL_) == "X") {
			haySel = true;
			break;
		}
	}
	if (!haySel) {
		MessageBox.warning(sys.translate("No hay ninguna l�nea seleccionada"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al crear la transferencia de stock");
	var f;
	var verBuild = parseInt(ver.mid(ver.lastIndexOf("Build") + 6));
  if (!isNaN(verBuild) && verBuild > 34895) {
    f = new Function("oParam", "return formem_transconfec.iface.creaTransferencia(oParam)");
	} else {
    f = new Function("oParam", "return formSearchem_transconfec.iface.creaTransferencia(oParam)");
	}
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	MessageBox.information(sys.translate("Transferencia realizada"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	this.accept();
}

function oficial_creaTransferencia(oParam)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var hoy = new Date;
	var curT = new FLSqlCursor("transstock");
	curT.setModeAccess(curT.Insert);
	curT.refreshBuffer();
	curT.setValueBuffer("fecha", hoy.toString());
	curT.setValueBuffer("hora", hoy.toString().right(8));
	curT.setValueBuffer("codalmaorigen", cursor.valueBuffer("codalmaorigen"));
	curT.setValueBuffer("codalmadestino", cursor.valueBuffer("codalmadestino"));
	curT.setValueBuffer("codordenprod", cursor.valueBuffer("codordenprod"));
	var idTrans = curT.valueBuffer("idtrans");
	if (!curT.commitBuffer()) {
		return false;
	}
	var nF = _i.t_.numRows();
	var curLT = new FLSqlCursor("lineastransstock");
	for (var f = 0; f < nF; f++) {
		if (_i.t_.text(f, _i.cSEL_) == "X") {
			curLT.setModeAccess(curLT.Insert);
			curLT.refreshBuffer();
			curLT.setValueBuffer("idtrans", idTrans);
			curLT.setValueBuffer("referencia", _i.t_.text(f, _i.cREF_));
			curLT.setValueBuffer("descripcion", _i.t_.text(f, _i.cDES_));
			curLT.setValueBuffer("cantidad", _i.t_.text(f, _i.cCAN_));
			if (!curLT.commitBuffer()) {
				return false;
			}
		}
	}
	return true;
}

function oficial_colores()
{
	var _i = this.iface;
	
	_i.cNoSel_ = new Color("white");
	_i.cSel_ = new Color("green");
}

function oficial_tblLineas_clicked(f, c)
{
	var _i = this.iface;
	if (c != _i.cSEL_) {
		return;
	}
	if (_i.t_.text(f, c) == "") {
		//_i.t_.setText(f, _i.cCAN_
	} else {
	}
	
	if (_i.t_.text(f, c) == "") {
		_i.coloreaFila(f, _i.cSel_);
		_i.t_.setText(f, c, "X");
		var dispDestino = _i.t_.text(f, _i.cDID_);
		var necesario = _i.t_.text(f, _i.cNEC_);
		_i.t_.setText(f, _i.cCAN_, dispDestino - necesario > 0 ? 0 : (necesario - dispDestino));
	} else {
		_i.coloreaFila(f, _i.cNoSel_);
		_i.t_.setText(f, c, "");
		_i.t_.setText(f, _i.cCAN_, 0);
		
	}
}

function oficial_coloreaFila(f, clr)
{
	var _i = this.iface;
	var nC = _i.t_.numCols();
	for (var c = 0; c < nC; c++) {
		_i.t_.setCellBackgroundColor(f, c, clr);
		_i.t_.adjustColumn(c);
	}
}

function oficial_cargaTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var q = new FLSqlQuery();
	q.setSelect("ms.referencia, a.descripcion, SUM(ms.cantidad)");
	q.setFrom("movistock ms INNER JOIN articulos a ON ms.referencia = a.referencia INNER JOIN lotesstock ls ON ms.codloteprod = ls.codlote");
	q.setWhere("ls.codordenproduccion = '" + cursor.valueBuffer("codordenprod") + "' GROUP BY ms.referencia, a.descripcion");
debug(q.sql());
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	
	var t = _i.t_;
	t.setNumRows(0);
	var f = 0, referencia, codFamilia, dispOrigen, dispDestino, necesario;
	
	while (q.next()) {
		referencia = q.value("ms.referencia");
		if (flfactalma.iface.pub_esReferenciaXPiezas(referencia)) {
			continue;
		}
// 		codFamilia = AQUtil.sqlSelect("articulos", "codfamilia", "referencia = '" + referencia + "'");
// 		if (flfactalma.iface.pub_esFamiliaEstampado(codFamilia)) {
// 			continue;
// 		}
		necesario = q.value("SUM(ms.cantidad)");
		necesario = isNaN(necesario) ? 0 : necesario;
		necesario *= -1;
		dispOrigen = AQUtil.sqlSelect("stocks", "disponible", "referencia = '" + referencia + "' AND codalmacen = '" + cursor.valueBuffer("codalmaorigen") + "'");
		dispOrigen = isNaN(dispOrigen) ? 0 : dispOrigen;
		dispDestino = AQUtil.sqlSelect("stocks", "disponible", "referencia = '" + referencia + "' AND codalmacen = '" + cursor.valueBuffer("codalmadestino") + "'");
		dispDestino = (!dispDestino || isNaN(dispDestino)) ? 0 : dispDestino;
		dispDestino += necesario; /// Se suma el necesario porque dispDestino contiene ya la reserva del material necesario
		
		t.insertRows(f);
		t.setText(f, _i.cREF_, referencia);
		t.setText(f, _i.cDES_, q.value("a.descripcion"));
		t.setText(f, _i.cNEC_, necesario);
		t.setText(f, _i.cDIO_, dispOrigen);
		t.setText(f, _i.cDID_, dispDestino);
		t.setText(f, _i.cCAN_, 0);
		_i.coloreaFila(f, _i.cNoSel_);
		f++;
	}
}

function oficial_iniciarTabla() 
{
	var _i = this.iface;
	
	var c = 0, cH = [];
	_i.cSEL_ = c++;
	_i.cREF_ = c++;
	_i.cDES_ = c++;
	_i.cNEC_ = c++;
	_i.cDIO_ = c++;
	_i.cDID_ = c++;
	_i.cCAN_ = c++;
	
	cH[_i.cSEL_] = AQUtil.translate("scripts", "Sel.");
	cH[_i.cREF_] = AQUtil.translate("scripts", "Referencia");
	cH[_i.cDES_] = AQUtil.translate("scripts", "Art�culo");
	cH[_i.cNEC_] = AQUtil.translate("scripts", "Necesario");
	cH[_i.cDIO_] = AQUtil.translate("scripts", "C.Origen");
	cH[_i.cDID_] = AQUtil.translate("scripts", "C.Destino");
	cH[_i.cCAN_] = AQUtil.translate("scripts", "A transferir");
	
	var t = this.child("tblLineas");
	t.setNumCols(c);
	t.setColumnWidth(_i.cSEL_, 40);
	t.setColumnWidth(_i.cREF_, 100);
	t.setColumnWidth(_i.cDES_, 200);
	t.setColumnWidth(_i.cNEC_, 100);
	t.setColumnWidth(_i.cDIO_, 100);
	t.setColumnWidth(_i.cDID_, 100);
	t.setColumnWidth(_i.cCAN_, 100);
	
	t.setColumnReadOnly(_i.cSEL_, true);
	t.setColumnReadOnly(_i.cREF_, true);
	t.setColumnReadOnly(_i.cDES_, true);
	t.setColumnReadOnly(_i.cNEC_, true);
	t.setColumnReadOnly(_i.cDIO_, true);
	t.setColumnReadOnly(_i.cDID_, true);
	t.setColumnReadOnly(_i.cCAN_, false);
	
	t.setColumnLabels("*", cH.join("*"));
}


//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////