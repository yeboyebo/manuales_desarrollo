/***************************************************************************
                 em_articulosclihis.qs  -  description
                             -------------------
    begin                : mie oct 22 2014
    copyright            : (C) 2014 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() { 
		this.ctx.interna_init(); 
	}
	function calculateField(fN) { 
		return this.ctx.interna_calculateField(fN); 
	}
	function validateForm() {
	   return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	
	function oficial( context ) { 
		interna( context ); 
	} 
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}	
	function validacionEsq() {
	     return this.ctx.oficial_validacionEsq();
	}
	/*
	function validaEsqPvpEuromoda(pvpEuromoda, tipoEsquema) {
	     return this.ctx.oficial_validaEsqPvpEuromoda(pvpEuromoda, tipoEsquema);
	}*/
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
  function pub_commonCalculateField(fN, cursor) {
		return this.commonCalculateField(fN, cursor);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");	

}
function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		default: {
			valor = _i.commonCalculateField(fN, cursor);
		}
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;	
	if(!_i.validacionEsq()) {	
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_commonCalculateField(fN, cursor)
{
debug("oficial_commonCalculateField " + fN);
	var _i = this.iface;
	var valor;
	switch (fN) {
		case "pvpdto": {
      	var pvpBase = cursor.valueBuffer("pvpbase");
			var dtoPor = cursor.valueBuffer("dtopor");
      	if (isNaN(pvpBase) || pvpBase == 0)  {
        		valor = 0;
	    	} else if (isNaN(dtoPor) || dtoPor == 0) {
	     		valor = pvpBase;
			} else {
        		valor = pvpBase - ((pvpBase * dtoPor) / 100);
      	}
      	break;
		}
		case "pvpsiniva": {
			var pvpDto = cursor.valueBuffer("pvpdto");
			var referencia = AQUtil.sqlSelect("em_articuloscli", "referencia", "id = " + cursor.valueBuffer("idarticuloscli"));
			var codCliente = AQUtil.sqlSelect("em_articuloscli", "codcliente", "id = " + cursor.valueBuffer("idarticuloscli"));;
			var codImpuesto = AQUtil.sqlSelect("articulos", "codimpuesto", "referencia='" + referencia + "'");
			var codGrupoIvaNeg = AQUtil.sqlSelect("clientes", "codgrupoivaneg", "codcliente = '" + codCliente + "'");
			var fecha = new Date;
			var porcIva  = flfacturac.iface.pub_campoImpuesto("iva", codImpuesto, fecha, "cli", codGrupoIvaNeg);
			
			if (isNaN(pvpDto) || pvpDto == 0)  {
				valor = 0;
			} else if (isNaN(porcIva) || porcIva == 0) {
				valor = pvpDto;
			} else {
				valor = (100 * pvpDto) / (100 + parseFloat(porcIva))
			}
			break;
		}
		case "pvpeuromoda": {
			var dtoEmoda = cursor.valueBuffer("dtoemoda");
			var pvpSinIva = cursor.valueBuffer("pvpsiniva");
			if (isNaN(pvpSinIva) || pvpSinIva == 0)  {
				valor = 0;
			} else if (isNaN(dtoEmoda) || dtoEmoda == 0) {
				valor = pvpSinIva; 
			} else {
				valor = (pvpSinIva * dtoEmoda) / 100;
			}
			var esquema = AQUtil.sqlSelect("em_articuloscli ac INNER JOIN clientes c ON ac.codcliente = c.codcliente", "c.em_tipoesqexpcat", "ac.id = " + cursor.valueBuffer("idarticuloscli"), "clientes");
			valor = formRecordem_articuloscli.iface.pub_formateaValorEsquema("pvpeuromoda", valor, esquema);
		}
		default: {
		}
	}
			
	return valor;
}

function oficial_bufferChanged(fN)
{
debug("oficial_bufferChanged " + fN);
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "pvpbase": 
		case "dtopor": {
			 sys.setObjText(this, "fdbPvpDto", _i.calculateField("pvpdto"));
			 sys.setObjText(this, "fdbPvpSinIva", _i.calculateField("pvpsiniva"));
			 cursor.setValueBuffer("pvpeuromoda", _i.calculateField("pvpeuromoda"));
			break;
		}
		case "dtoemoda": {
			 cursor.setValueBuffer("pvpeuromoda", _i.calculateField("pvpeuromoda"));
			break;
		}
    
		default: {
		}
	}
}
function oficial_validacionEsq()
{
    var _i = this.iface;
    
	var cursor = this.cursor();
	var esquema = AQUtil.sqlSelect("em_articuloscli ac INNER JOIN clientes c ON ac.codcliente = c.codcliente", "c.em_tipoesqexpcat", "ac.id = " + cursor.valueBuffer("idarticuloscli"), "clientes");
	
	switch (esquema) {
		case "FLEX": {		
			if (!formRecordem_articuloscli.iface.pub_validaCampoEsquema("pvpeuromoda", cursor.valueBuffer("pvpeuromoda"), esquema)) {
				return false;
			}
			break;
		}	
		default: {		
		}
	}
	return true;
}

/*
function oficial_validaEsqPvpEuromoda(pvpEuromoda, tipoEsquema)
{
	var valor = pvpEuromoda*100;
	valor = valor%1;
	if(valor != 0) {
		sys.warnMsgBox(sys.translate("No se puede guardar el registro ya que para el tipo de esquema %1, el campo PVP Euromoda, debe de tener un 0 en el tercer decimal.").arg(tipoEsquema));
		return false;			
	}
	return true;
}
*/
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////
