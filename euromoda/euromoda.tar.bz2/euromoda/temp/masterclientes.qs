
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function tbnCompruebaSaldos_clicked() {
		return this.ctx.euromoda_tbnCompruebaSaldos_clicked();
	}
	function tbnQuitarFiltro_clicked() {
		return this.ctx.euromoda_tbnQuitarFiltro_clicked();
	}
	function tbnFiltroClientes_clicked() {
		return this.ctx.euromoda_tbnFiltroClientes_clicked();
	}

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();

	connect(this.child("tbnCompruebaSaldos"), "clicked()", _i, "tbnCompruebaSaldos_clicked");
	connect(this.child("tbnFiltroClientes"), "clicked()", _i, "tbnFiltroClientes_clicked");
	connect(this.child("tbnQuitarFiltro"), "clicked()", _i, "tbnQuitarFiltro_clicked");
}

function euromoda_tbnQuitarFiltro_clicked()
{
	var _i = this.iface;
	this.cursor().setMainFilter("");
	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_tbnFiltroClientes_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var sesion = flfactalma.iface.pub_dameSesion();

	var f = new FLFormSearchDB("em_filtrosclientes");
	var curF = f.cursor();

	curF.select("sesion = '" + sesion + "'");
	if (curF.first()) {
		curF.setModeAccess(curF.Edit);
	} else {
		curF.setModeAccess(curF.Insert);
	}
	curF.refreshBuffer();
	curF.setValueBuffer("sesion", sesion);
	curF.setValueBuffer("tabla", cursor.action());

	f.setMainWidget();

	var filtro = f.exec("filtro");
	if (!filtro) {
		filtro = "1 = 1";
	}
	if (filtro) {
		curF.commitBuffer();
		cursor.setMainFilter(filtro);
	} else {
		cursor.setMainFilter("");
	}

	if (this.child("tableDBRecords")) {
		this.child("tableDBRecords").refresh();
	}
}

function euromoda_tbnCompruebaSaldos_clicked()
{
	var cursor = new FLSqlCursor("clientes");
	cursor.select("1 = 1");
	AQUtil.createProgressDialog(sys.translate("Comprobando saldos"), cursor.size());
	var p = 0;
	var saldoConta, saldoFact, sRec, sAnt, sPar;
	var codSubcuenta;
	var _fC = formRecordclientes.iface;
	var lista = "";
	var subcuentas;
	while (cursor.next()) {
		AQUtil.setProgress(p++);
		cursor.setModeAccess(cursor.Edit);
		cursor.refreshBuffer();
		subcuentas = _fC.commonCalculateField("listasubcuentas", cursor);
// 		codSubcuenta = _fC.commonCalculateField("codsubcuenta", cursor);
// 		cursor.setValueBuffer("codsubcuenta", codSubcuenta);
		saldoConta = _fC.commonCalculateField("saldoanticipos", cursor);
		sRec = AQUtil.sqlSelect("reciboscli", "SUM(importeeuros)", "codcliente = '" + cursor.valueBuffer("codcliente") + "' AND " + _fC.dameWhereRecibosSaldo());
		sRec = isNaN(sRec) ? 0 : sRec;
		sAnt = AQUtil.sqlSelect("anticiposcli", "SUM(pendienteeuros)", "codcliente = '" + cursor.valueBuffer("codcliente") + "' AND pendienteeuros <> 0");
		sAnt = isNaN(sAnt) ? 0 : sAnt;
		sPar = AQUtil.sqlSelect("co_partidas", "SUM(importependiente)", "codcliente = '" + cursor.valueBuffer("codcliente") + "' AND importependiente <> 0 AND codsubcuenta IN (" + subcuentas + ")");
		sPar = isNaN(sPar) ? 0 : sPar;
		saldoFact = sRec - sAnt + sPar;
		debug("sRec = " + sRec + ", sAnt = " + sAnt + ", sPar = " + sPar);
// 		saldoFact = Math.round(saldoFact);
// 		saldoConta = Math.round(saldoConta);
		debug("saldoFact " + saldoFact + " = saldoConta " + saldoConta);
		if (saldoFact != saldoConta) {
			if (Math.abs(saldoFact - saldoConta) < 0.01) continue
			lista += ("\n" + cursor.valueBuffer("codcliente") + "- " + cursor.valueBuffer("nombre") + "SF " + saldoFact + " SC " + saldoConta);
// 			AQUtil.destroyProgressDialog();
// 			MessageBox.warning(sys.translate("Los saldos del cliente %1 - %2 no coinciden").arg(cursor.valueBuffer("codcliente")).arg(cursor.valueBuffer("nombre")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
// 			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	if (lista != "") {
		MessageBox.warning(sys.translate("Los saldos de los siguientes clientes no coinciden:%1").arg(lista), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	} else {
		MessageBox.information(sys.translate("Comprobaci�n completada. No hay desajustes."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
