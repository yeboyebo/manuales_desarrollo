/***************************************************************************
                 em_acabadosart.qs  -  description
                             -------------------
    begin                : mar abr 25 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function validateForm():Boolean { return this.ctx.interna_validateForm(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); } 
	function filtrarAcabados() {
		return this.ctx.oficial_filtrarAcabados();
	}
	function dameFiltroAcabadosFam() {
		return this.ctx.oficial_dameFiltroAcabadosFam();
	} 
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();

  _i.filtrarAcabados();  
 
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var referencia = cursor.valueBuffer("referencia");
	var acabado = cursor.valueBuffer("acabado"); 
	var codFamilia = AQUtil.sqlSelect("articulos","codfamilia", "referencia = '" + referencia + "'");
	if(!AQUtil.sqlSelect("em_acabadosfam","acabado","codfamilia = '" + codFamilia +"' and acabado = '" + acabado + "'")) {

		sys.warnMsgBox(sys.translate("El acabado %1 no pertenece a la familia %2").arg(acabado).arg(codFamilia));

		return false;
	}


	return true;
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_filtrarAcabados()
{
	var _i = this.iface;

	var filtroAcabadosFam = _i.dameFiltroAcabadosFam();	
	this.child("fdbAcabado").setFilter(filtroAcabadosFam);
}

function oficial_dameFiltroAcabadosFam()
{
	var _i = this.iface;
	var filtro = "1=2"
	var cursor = this.cursor();
	var referencia = cursor.valueBuffer("referencia");
	var codFamilia = AQUtil.sqlSelect("articulos","codfamilia", "referencia = '" + referencia + "'");

	if(codFamilia && codFamilia != "") {
		filtro = "codfamilia = '" + codFamilia + "'";
	}
	return filtro;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
