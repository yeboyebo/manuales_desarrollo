
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends articuloscomp {
  function euromoda( context ) { articuloscomp ( context ); }
  function init() {
    return this.ctx.euromoda_init();
  }
  function tbnProforma_clicked() {
    return this.ctx.euromoda_tbnProforma_clicked();
  }
  function tbnProformaMembrete_clicked() {
    return this.ctx.euromoda_tbnProformaMembrete_clicked();
  }
  function dameParamInformeProforma(codPedido) {
    return this.ctx.euromoda_dameParamInformeProforma(codPedido);
  }
  function datosPedido(curPresupuesto) {
    return this.ctx.euromoda_datosPedido(curPresupuesto);
  }
  function totalesPedido() {
    return this.ctx.euromoda_totalesPedido();
  }
  function commonCalculateField(fN, cursor) {
    return this.ctx.euromoda_commonCalculateField(fN, cursor);
  }
  function datosLineaPedido(curLineaPresupuesto) {
    return this.ctx.euromoda_datosLineaPedido(curLineaPresupuesto);
  }
  function imprimeProforma() {
    return this.ctx.euromoda_imprimeProforma();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();

  connect(this.child("tbnProforma"), "clicked()", _i, "tbnProforma_clicked");
	connect(this.child("tbnProformaMembrete"), "clicked()", _i, "tbnProformaMembrete_clicked");
}

function euromoda_tbnProforma_clicked()
{
  var _i = this.iface;
	flfactinfo.iface.pub_ponerMembrete(false);

	_i.imprimeProforma();
}

function euromoda_tbnProformaMembrete_clicked()
{
	var _i = this.iface;
	flfactinfo.iface.pub_ponerMembrete(true);

	_i.imprimeProforma();
}

function euromoda_imprimeProforma(){
	var _i = this.iface;
  var cursor = this.cursor();

  var codigo = cursor.valueBuffer("codigo");
  if (!codigo) {
    return;
  }

  var oParam = _i.dameParamInformeProforma(codigo);

  if (!oParam) {
    return;
  }
  var curImprimir: FLSqlCursor = new FLSqlCursor("i_presupuestoscli");
  curImprimir.setModeAccess(curImprimir.Insert);
  curImprimir.refreshBuffer();
  curImprimir.setValueBuffer("descripcion", "temp");
  curImprimir.setValueBuffer("d_presupuestoscli_codigo", codigo);
  curImprimir.setValueBuffer("h_presupuestoscli_codigo", codigo);

  flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
}

function euromoda_dameParamInformeProforma(codPresupuesto)
{
  var oParam = flfactinfo.iface.pub_dameParamInforme();

	var paisEmpresa = flfactppal.iface.pub_valorDefectoEmpresa("codpais");
	var idPresupuesto = AQUtil.sqlSelect("presupuestoscli", "idpresupuesto", "codigo = '" + codPresupuesto + "'");
	var paisPresupuesto = AQUtil.sqlSelect("presupuestoscli", "codpais", "idpresupuesto = '" + idPresupuesto + "'");

	if(paisPresupuesto && paisPresupuesto != "" && paisPresupuesto != paisEmpresa){
			nombreInforme = "i_proformas_int";
	} else {
		nombreInforme = "i_proformas";
	}
  oParam.nombreInforme = nombreInforme;
  return oParam;
}

function euromoda_datosPedido(curPresupuesto)
{
  var _i = this.iface;
  if (!_i.__datosPedido(curPresupuesto)) {
    return false;
  }

	
	_i.curPedido.setValueBuffer("em_codpago", curPresupuesto.valueBuffer("em_codpago"));
	_i.curPedido.setValueBuffer("docexterno", curPresupuesto.valueBuffer("docexterno"));
	_i.curPedido.setValueBuffer("pobincoterm", curPresupuesto.valueBuffer("pobincoterm"));
	_i.curPedido.setValueBuffer("fechasalida", curPresupuesto.valueBuffer("fechasalida"));
	_i.curPedido.setValueBuffer("fechaservicio", curPresupuesto.valueBuffer("fechasalida"));
	_i.curPedido.setValueBuffer("em_autorizadocostes", curPresupuesto.valueBuffer("em_autorizadocostes"));
	_i.curPedido.setValueBuffer("em_estadocostes", curPresupuesto.valueBuffer("em_estadocostes"));
	_i.curPedido.setValueBuffer("em_politicacostes", curPresupuesto.valueBuffer("em_politicacostes"));
	_i.curPedido.setValueBuffer("em_motivocostes", curPresupuesto.valueBuffer("em_motivocostes"));


  return true;
}

function euromoda_totalesPedido()
{
	var _i = this.iface;
	if (!_i.__totalesPedido()) {
		return false;
	}

	var fechaServicio = formpedidoscli.iface.pub_commonCalculateField("fechaservicio", _i.curPedido);
	if (fechaServicio) { /// Si no la hay se toma la fecha de salida del presupuesto
		_i.curPedido.setValueBuffer("fechaservicio", fechaServicio);
	}	

	formRecordpresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",_i.curPedido.valueBuffer("codcliente"));	
	if(!formRecordpresupuestoscli.iface.pub_evaluarCostesCab(_i.curPedido)) {
		return false;
	}
	return true;
}

function euromoda_commonCalculateField(fN, cursor)
{

  var _i = this.iface;
  var valor;

	if(fN == "pordtoesp_fp") {
		valor = AQUtil.sqlSelect("formaspago", "pordtoesp", "codpago = '" + cursor.valueBuffer("codpago") + "'");
		valor = parseFloat(AQUtil.roundFieldValue(valor, "presupuestoscli", "pordtoesp"));

	} else if(fN == "codserie") {
		valor = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli gc ON c.codgrupocontablecli = gc.codgrupo", "gc.codseriefac", "c.codcliente = '" + cursor.valueBuffer("codcliente") + "'", "clientes");
	} else if(fN == "dirfacturacion") {
		var codCliente = cursor.valueBuffer("codcliente");
		if (!codCliente) {
			valor = "";
		} else {			
		var q = new FLSqlQuery;
		q.setFrom("dirclientes d LEFT OUTER JOIN paises p ON d.codpais = p.codpais");
		q.setSelect("d.direccion, d.codpostal, d.ciudad, d.provincia, p.nombre");
		q.setWhere("codcliente = '" + codCliente + "' AND domfacturacion");
		if (!q.exec()) {
			return false;
		}
		if (!q.first()) {
			return false;
		}
		valor = q.value("d.direccion") + "\n" + q.value("d.ciudad");
		if (q.value("d.provincia") != "" && q.value("d.provincia") != q.value("d.ciudad")) {
			valor += " (" + q.value("d.provincia") + ")";
		}
		if (q.value("d.codpostal") != "") {
			valor += ". CP " + q.value("d.codpostal");
		}
		if (q.value("p.nombre") != "") {
			valor += ". " + q.value("p.nombre");
		}
	}
	} else if(fN == "em_netovscostes") {
		var globalNeto = cursor.valueBuffer("em_globalneto");
		var globalCostes = cursor.valueBuffer("em_globalcostes");
		if(!globalNeto || globalNeto == "") {
			globalNeto = 0;	
		}
		if(!globalCostes || globalCostes == "" || globalCostes == 0) {
			valor = 0;	
		} else {
			valor = ((parseFloat(globalNeto)-parseFloat(globalCostes))/parseFloat(globalCostes))*100;	
		}
	} else if(fN == "em_netovsmargenes") {
		var globalNeto = cursor.valueBuffer("em_globalneto");
		var globalMargenes = cursor.valueBuffer("em_globalMargenes");
		if(!globalNeto || globalNeto == "") {
			globalNeto = 0;	
		}
		if(!globalMargenes || globalMargenes == "" || globalMargenes == 0) {
			valor = 0;	
		} else {
			valor = ((parseFloat(globalNeto)-parseFloat(globalMargenes))/parseFloat(globalMargenes))*100;	
		}	
	} else {
      valor = _i.__commonCalculateField(fN, cursor);
    }
 
  return valor;
}

function euromoda_datosLineaPedido(curLineaPresupuesto)
{
  var _i = this.iface;
  if (!_i.__datosLineaPedido(curLineaPresupuesto)) {
    return false;
  }

  _i.curLineaPedido.setValueBuffer("tipoconcepto", curLineaPresupuesto.valueBuffer("tipoconcepto"));
  _i.curLineaPedido.setValueBuffer("texto", curLineaPresupuesto.valueBuffer("texto"));
  _i.curLineaPedido.setValueBuffer("codsubcuenta", curLineaPresupuesto.valueBuffer("codsubcuenta"));
  if (curLineaPresupuesto.valueBuffer("idsubcuenta")) {
    _i.curLineaPedido.setValueBuffer("idsubcuenta", curLineaPresupuesto.valueBuffer("idsubcuenta"));
  }
  _i.curLineaPedido.setValueBuffer("emcodbarras", curLineaPresupuesto.valueBuffer("emcodbarras"));
  _i.curLineaPedido.setValueBuffer("codamortizacion", curLineaPresupuesto.valueBuffer("codamortizacion"));
	_i.curLineaPedido.setValueBuffer("refcliente", curLineaPresupuesto.valueBuffer("refcliente"));
	_i.curLineaPedido.setValueBuffer("codtamanoem", curLineaPresupuesto.valueBuffer("codtamanoem"));
	_i.curLineaPedido.setValueBuffer("codcolorem", curLineaPresupuesto.valueBuffer("codcolorem"));
	_i.curLineaPedido.setValueBuffer("codarancelario", curLineaPresupuesto.valueBuffer("codarancelario"));
	formRecordlineaspedidoscli.iface.pub_cargaDatosStock(_i.curLineaPedido);
	_i.curLineaPedido.setValueBuffer("diasservicio", formRecordlineaspedidoscli.iface.pub_commonCalculateField("diasservicio", _i.curLineaPedido));
	_i.curLineaPedido.setValueBuffer("fechaservicio", formRecordlineaspedidoscli.iface.pub_commonCalculateField("fechaservicio", _i.curLineaPedido));

	if(curLineaPresupuesto.valueBuffer("tipoconcepto") == "Producto") {		
		//21-01-2019 Que vaya por separado el coste y el margen a la hora de evaluar si se recalcula o se copia.
		var costeProd = false;
		var margenProd = false;	
		if(curLineaPresupuesto.valueBuffer("em_costeprod") && curLineaPresupuesto.valueBuffer("em_costeprod") != "" && !curLineaPresupuesto.isNull("em_costeprod")) {
			_i.curLineaPedido.setValueBuffer("em_costeprod", curLineaPresupuesto.valueBuffer("em_costeprod"));
			_i.curLineaPedido.setValueBuffer("em_fechacosteprod", curLineaPresupuesto.valueBuffer("em_fechacosteprod"));
			_i.curLineaPedido.setValueBuffer("em_horacosteprod", curLineaPresupuesto.valueBuffer("em_horacosteprod"));

		} else {
			costeProd = true;
		}
		if(curLineaPresupuesto.valueBuffer("em_margenprod") && curLineaPresupuesto.valueBuffer("em_margenprod") != "" && !curLineaPresupuesto.isNull("em_margenprod")){
			_i.curLineaPedido.setValueBuffer("em_margenprod", curLineaPresupuesto.valueBuffer("em_margenprod"));
			_i.curLineaPedido.setValueBuffer("em_fechamargenprod", curLineaPresupuesto.valueBuffer("em_fechamargenprod"));
			_i.curLineaPedido.setValueBuffer("em_horamargenprod", curLineaPresupuesto.valueBuffer("em_horamargenprod"));

		} else {
			margenProd = true;
		}
		if(costeProd || margenProd) {
			var oParamLin = new Object;
			oParamLin.cursor = _i.curLineaPedido;
			oParamLin.ignorarAvisos = true;
			oParamLin.forzarReg = false;
			oParamLin.ignorarCalculoInsert = false; 
			var codCliente;
			var datosTP = formRecordlineaspedidoscli.iface.datosTablaPadre(_i.curLineaPedido);
			if (!datosTP) {
				codCliente = false;
			} else {
				codCliente = datosTP["codcliente"];
			}			 
			formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("pedidoscli",codCliente);	
			formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);		
		} else {
			_i.curLineaPedido.setValueBuffer("em_estadocostes", curLineaPresupuesto.valueBuffer("em_estadocostes"));
			_i.curLineaPedido.setValueBuffer("em_politicacostes", curLineaPresupuesto.valueBuffer("em_politicacostes"));
			_i.curLineaPedido.setValueBuffer("em_motivocostes", curLineaPresupuesto.valueBuffer("em_motivocostes"));
			_i.curLineaPedido.setValueBuffer("em_alarmaoff", curLineaPresupuesto.valueBuffer("em_alarmaoff"));
		}
	}
  return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
