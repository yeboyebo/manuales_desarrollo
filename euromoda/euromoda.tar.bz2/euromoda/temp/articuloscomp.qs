
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
	function euromoda( context ) { prod ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function habilitacionesEM() {
		return this.ctx.euromoda_habilitacionesEM();
	}
  function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
 function calculateField(fN) {
		return this.ctx.euromoda_calculateField(fN);
	}
 function filtraComponentes() {
   return this.ctx.euromoda_filtraComponentes();
 }
 function ordenTabulacion() {
   return this.ctx.euromoda_ordenTabulacion();
 }
 function validateForm() {
   return this.ctx.euromoda_validateForm();
 }
 function validaDescatalogado() {
   return this.ctx.euromoda_validaDescatalogado();
 }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
	var cursor = this.cursor();
	
  _i.__init();
	
  _i.habilitacionesEM();
  _i.filtraComponentes();
	
	
	switch (cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbOrden", _i.calculateField("orden"));
			sys.setObjText(this, "fdbIdSeccion", _i.calculateField("idseccion"));
			break;
		}
		case cursor.Edit: {
			this.child("fdbRefComponente").setDisabled(false);
			break;
		}
	}
	_i.ordenTabulacion();
}

function euromoda_filtraComponentes()
{
  this.child("fdbRefComponente").setFilter("em_tipoarticulo = 'M.Prima'");
}

function euromoda_habilitacionesEM()
{
	this.child("lblFamilia").close();
	this.child("lblComponente").close();
	this.child("fdbCodFamiliaComponente").close();
	this.child("fdbDesFamilia").close();
	this.child("groupBoxOpcion").close();
	this.child("fdbIdTipoTareaPro").close();
}

function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  switch (fN) {
  case "largo":
  case "piezasancho": {
      sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
      this.child("fdbFactor").setValue(_i.calculateField("factor"));
      break;
    }
  case "ancho": {
      sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
			this.child("fdbFactor").setValue(_i.calculateField("factor"));
      break;
    }
  case "anchopiezatej": {
      sys.setObjText(this,  "fdbPiezasAncho", _i.calculateField("piezasancho"));
		this.child("fdbFactor").setValue(_i.calculateField("factor"));
      break;
  }
  case "refcomponente": { /// Evita llamar a la inferior que inhabiita campos que no existen
      break;
    }
  
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
		case "orden": {
			valor = AQUtil.sqlSelect("articuloscomp", "MAX(orden)", "refcompuesto = '" + cursor.valueBuffer("refcompuesto") + "'");
			valor = isNaN(valor) ? 0 : valor;
			valor += 100;
			break;
		}
		case "idseccion": {
			valor = AQUtil.sqlSelect("articuloscomp", "idseccion", "refcompuesto = '" + cursor.valueBuffer("refcompuesto") + "' ORDER BY orden DESC");
			valor = valor ? valor : "";
			break;
		}
  case "factor": {
			var piezasAncho = cursor.valueBuffer("piezasancho") ;
			if (isNaN(piezasAncho) || piezasAncho == 0) {
				valor = 1;
			} else {
				valor = cursor.valueBuffer("largo") / piezasAncho / 100;
			}
			//valor = valor == 0 ? valor = 1 : valor; //pineboo 21-08-2019
			if (valor == 0) {
				valor = 1;
			}
			break;
		}
  case "piezasancho": {
      var ancho = cursor.valueBuffer("ancho");
      var anchoPiezaTej = cursor.valueBuffer("anchopiezatej"); 
      anchoPiezaTej = isNaN(anchoPiezaTej) ? 0 : anchoPiezaTej;
      if (!ancho || isNaN(ancho)) {
        valor = 0;
      } else {
        //valor = Math.floor(284 / ancho);
        valor = Math.floor(anchoPiezaTej / ancho);
      }
      break;
    }
  }
  return valor;
}

function euromoda_ordenTabulacion()
{
	var controles = ["fdbRefComponente", "fdbDescComponente", "fdbCantidad", "fdbLargo", "fdbAncho"];
	for (var i = 0; i < controles.length - 1; i++) {
		if (this.child(controles[i]) && this.child(controles[i + 1])) {
			AQS.setTabOrder(this.child(controles[i]).obj(), this.child(controles[i + 1]).obj());
		}
	}
}

function euromoda_validateForm()
{
	var _i = this.iface;
	if (!_i.__validateForm()) {
		return false;
	}
	if (!_i.validaDescatalogado()) {
		return false;
	}
	var orden = this.cursor().valueBuffer("orden");
	debug("\n\norden en articuloscomp: "+orden);
	formRecordem_cambiocomponente.iface.ordenFT_ = this.cursor().valueBuffer("orden");
	return true;
}

function euromoda_validaDescatalogado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var refComponente = cursor.valueBuffer("refcomponente");
	if (AQUtil.sqlSelect("articulos", "referencia", "referencia = '" + refComponente + "' AND (descatalogado OR debaja)")) {
		var res = MessageBox.warning(sys.translate("El componente est� descatalogado o de baja. �Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
