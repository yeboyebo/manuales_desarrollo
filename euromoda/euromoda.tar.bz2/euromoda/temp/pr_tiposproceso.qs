
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class euromoda extends prod {
	function euromoda( context ) { prod ( context ); }
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	switch (fN) {
		case "fabricacion": {
			if (cursor.valueBuffer("fabricacion")) {
				this.child("fdbTipoObjeto").setValue("pr_ordenesproduccion");
				this.child("fdbTipoObjeto").setDisabled(true);
				this.child("fdbTipoProduccion").setDisabled(false);
			} else {
				this.child("fdbTipoObjeto").setValue("");
				this.child("fdbTipoObjeto").setDisabled(false);
				this.child("fdbTipoProduccion").setDisabled(true);
			}
			break;
		}
		default: {
			_i.__bufferChanged(fN);
			break;
		}
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
