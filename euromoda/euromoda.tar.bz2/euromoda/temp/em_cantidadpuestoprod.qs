/***************************************************************************
                 em_cantidadpuestoprod.qs  -  description
                             -------------------
    begin                : mie may 10 2017
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); }
	function iniciaLabels() {
		return this.ctx.oficial_iniciaLabels();
	}
	function bufferChanged(fN:String) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  	var _i = this.iface;
  	var cursor = this.cursor();
  	connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");


	this.child("pushButtonAccept").close();
	this.child("pushButtonCancel").close();

	_i.iniciaLabels();
	connect(this.child("tbnAceptar"), "clicked()", this.child("pushButtonAccept"), "animateClick()");
	connect(this.child("tbnCancelar"), "clicked()", this.child("pushButtonCancel"), "animateClick()");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciaLabels() 
{
	var _i = this.iface;
	var cursor = this.cursor();

	var referencia = cursor.valueBuffer("referencia");
	var descripcion = AQUtil.sqlSelect("articulos","descripcion","referencia = '" + referencia + "'");
	this.child("lblDescripcion").text = sys.translate("%1 %2.").arg(referencia).arg(descripcion);
	var codPantalla = AQUtil.readSettingEntry("scripts/flprodppal/codPantalla");	
	
	this.child("fdbCanTotalNueva").setValue(_i.commonCalculateField("cantotalnueva", cursor));

	/*-----------------------------------*/
	var tipoProd = formem_puestoprod.iface.tipoProduccion_;
	if (tipoProd == "Metros") {	
		this.child("fdbCanProdAnt").setValue(_i.commonCalculateField("canprodantmetros", cursor));
		this.child("fdbCanProducida").setValue(_i.commonCalculateField("canproducidametros", cursor));
		this.child("fdbCanProgramada2").setValue(_i.commonCalculateField("canprogramada2", cursor));
		this.child("fdbCanTotalNueva2").setValue(_i.commonCalculateField("cantotalnueva2metros", cursor));
		this.child("fdbCanTotalNueva").setValue(_i.commonCalculateField("cantotalnuevametros", cursor));		

		sys.disableObj(this, "fdbCanProducida");
		sys.enableObj(this, "fdbCanProducida2");
	} else {
		this.child("fdbCanTotalNueva").setValue(_i.commonCalculateField("cantotalnueva", cursor));
	}
}

function oficial_bufferChanged(fN)
{
	var cursor = this.cursor();
	var _i = this.iface;
	switch (fN) {
		case "canproducida": {		
			if (formem_puestoprod.iface.tipoProduccion_ == "Prendas") {
				this.child("fdbCanTotalNueva").setValue(_i.commonCalculateField("cantotalnueva", cursor));
			}
			break;
		}
		case "canproducida2": {
			if (formem_puestoprod.iface.tipoProduccion_ == "Metros") {
				this.child("fdbCanProducida").setValue(_i.commonCalculateField("canproducidametros", cursor));		
				this.child("fdbCanTotalNueva2").setValue(_i.commonCalculateField("cantotalnueva2metros", cursor));
			}
			break;
		}
		case "cantotalnueva": {		
			/*if (formem_puestoprod.iface.tipoProduccion_ == "Metros") {
				this.child("fdbCanTotalNueva2").setValue(_i.commonCalculateField("cantotalnueva2", cursor));		
			}*/
			break;
		}
		case "cantotalnueva2": {		
			if (formem_puestoprod.iface.tipoProduccion_ == "Metros") {
				this.child("fdbCanTotalNueva").setValue(_i.commonCalculateField("cantotalnuevametros", cursor));		
			}
			break;
		}
		
	}
}

function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor ;
	var referencia = cursor.valueBuffer("referencia");
	switch (fN) {
		case "canproducidametros": {
			// Cantidad producida de prendas cuando trabajamos en prendas
			var canProducida2 = cursor.valueBuffer("canproducida2");
			valor = formRecordarticulos.iface.metrosAPrendas(referencia, canProducida2);
			if(!valor) {
				valor = 0;
			}
			break;
		}
		case "cantotalnueva": {	
			// Cantidad total de prendas cuando trabajamos en prendas
			var canProd = parseFloat(cursor.valueBuffer("canproducida"));
			var canProdAnt = parseFloat(cursor.valueBuffer("canproducidaant"));	
			valor = canProd + canProdAnt;
			break;
		}
		case "cantotalnuevametros": {
			// Cantidad total de prendas cuando trabajamos en metros
			var canTotalNueva = cursor.valueBuffer("cantotalnueva2");
			valor = formRecordarticulos.iface.metrosAPrendas(referencia, canTotalNueva);
			if(!valor) {
				valor = 0;
			}
			break;
		}
		case "canprogramada2": {
			// Cantidad programada de metros en cualquier caso
			var canProgramada = cursor.valueBuffer("canprogramada");
			valor = formRecordarticulos.iface.prendasAMetros(referencia, canProgramada);
			if(!valor) {
				valor = 0;
			}
			break;
		}
		case "canprodantmetros": {
			// Cantidad anterior de prendas cuando trabajamos en metros
			var canProducidaAntM = cursor.valueBuffer("canproducidaant2");
			valor = formRecordarticulos.iface.metrosAPrendas(referencia, canProducidaAntM);
			if(!valor) {
				valor = 0;
			}
			break;
		}
		case "canproducida2": {
			var canProducida = cursor.valueBuffer("canproducida");
			valor = formRecordarticulos.iface.prendasAMetros(referencia, canProducida);
			if(!valor) {
				valor = 0;
			}
			break;
		}
		case "cantotalnueva2": {
			// Cantidad total nueva en metros cuando trabajamos en prendas
			var canTotalNueva = cursor.valueBuffer("cantotalnueva");
			valor = formRecordarticulos.iface.prendasAMetros(referencia, canTotalNueva);
			if(!valor) {
				valor = 0;
			}
			break;
		}
		case "cantotalnueva2metros": {
			// Cantidad nueva en metros cuando trabajamos en metros
			var canProd = parseFloat(cursor.valueBuffer("canproducida2"));
			var canProdAnt = parseFloat(cursor.valueBuffer("canproducidaant2"));	
			valor = canProd + canProdAnt;
			break;
		}
	}

	return valor;
	
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////