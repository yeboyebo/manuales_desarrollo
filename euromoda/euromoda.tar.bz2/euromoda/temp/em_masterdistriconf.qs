/***************************************************************************
                 em_masterdistriconf.qs  -  description
                             -------------------
    begin                : lun jul 18 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  var tdbOrdenes_, curPedidoAlb_;
  function oficial( context ) { interna( context ); } 
  function ordenarCols() {
    return this.ctx.oficial_ordenarCols();
  }
  function controlOrdenAbierta() {
    return this.ctx.oficial_controlOrdenAbierta();
  }
  function tbnPedido_clicked() {
    return this.ctx.oficial_tbnPedido_clicked();
  }
  function creaPedidoConf(oParam) {
    return this.ctx.oficial_creaPedidoConf(oParam);
  }
  function filtraPorOrden() {
    return this.ctx.oficial_filtraPorOrden();
  }
  function tbnImprimirPedido_clicked() {
    return this.ctx.oficial_tbnImprimirPedido_clicked();
  }
  function filtraLineasPedido() {
    return this.ctx.oficial_filtraLineasPedido();
  }
  function filtraLineasAlbaran() {
    return this.ctx.oficial_filtraLineasAlbaran();
  }
  function tbnAlbaranPedido_clicked() {
    return this.ctx.oficial_tbnAlbaranPedido_clicked();
  }
  function tbnAbrirCerrarPedido_clicked() {
    return this.ctx.oficial_tbnAbrirCerrarPedido_clicked();
  }
  function refrescaPedidoAlbaran() {
    return this.ctx.oficial_refrescaPedidoAlbaran();
  }
  function tbnPedidoAFaltas_clicked() {
    return this.ctx.oficial_tbnPedidoAFaltas_clicked();
  }
  function creaPedidoAFaltas(oParam) {
    return this.ctx.oficial_creaPedidoAFaltas(oParam);
  }
  function dameProveedorAFaltas() {
    return this.ctx.oficial_dameProveedorAFaltas();
  }
  function filtraOrdenes() {
    return this.ctx.oficial_filtraOrdenes();
  }
  function terminaTareaDC(oParam) {
    return this.ctx.oficial_terminaTareaDC(oParam);
  }
  function tbnOK_clicked() {
    return this.ctx.oficial_tbnOK_clicked();
  }
  function crearConsumosPedFaltas(referencia, codLote, canBase) {
    return this.ctx.oficial_crearConsumosPedFaltas(referencia, codLote, canBase);
  }
  function tbnImprimeFaltas_clicked() {
    return this.ctx.oficial_tbnImprimeFaltas_clicked();
  }
  function dameParamInformeFaltas() {
    return this.ctx.oficial_dameParamInformeFaltas();
  }
  function toolButtonPrint_clicked() {
    return this.ctx.oficial_toolButtonPrint_clicked();
  }
  function tbnImprimeAA_clicked() {
    return this.ctx.oficial_tbnImprimeAA_clicked();
  }
  function chkVerTodas_clicked() {
    return this.ctx.oficial_chkVerTodas_clicked();
  }
  function tbnReabrirOrden_clicked() {
    return this.ctx.oficial_tbnReabrirOrden_clicked();
  }
  function reabrirOrdenTR(oParam) {
    return this.ctx.oficial_reabrirOrdenTR(oParam);
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
	function pub_creaPedidoConf(oParam) {
		return this.creaPedidoConf(oParam);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
  _i.tdbOrdenes_ = this.child("tdbOrdenes");
  _i.ordenarCols();
  _i.filtraOrdenes();

  connect(this.child("tdbOrdenes"), "currentChanged()", _i, "filtraPorOrden");
	try {
		connect(this.child("tdbOrdenes"), "refreshed()", _i, "filtraPorOrden");
	}	catch (e) {}
	
  connect(this.child("tdbPedidos"), "currentChanged()", _i, "filtraLineasPedido");
  connect(this.child("tdbAlbaranes"), "currentChanged()", _i, "filtraLineasAlbaran");
  connect(this.child("tbnPedido"), "clicked()", _i, "tbnPedido_clicked");
  connect(this.child("tbnImprimirPedido"), "clicked()", _i, "tbnImprimirPedido_clicked");
  connect(this.child("tbnAlbaranPedido"), "clicked()", _i, "tbnAlbaranPedido_clicked");
  connect(this.child("tbnAbrirCerrarPedido"), "clicked()", _i, "tbnAbrirCerrarPedido_clicked");
  connect(this.child("tbnPedidoAFaltas"), "clicked()", _i, "tbnPedidoAFaltas_clicked");
  connect(this.child("tbnOK"), "clicked()", _i, "tbnOK_clicked");
	connect(this.child("tbnImprimeFaltas"), "clicked()", _i, "tbnImprimeFaltas_clicked");
	connect(this.child("toolButtonPrint"), "clicked()", _i, "toolButtonPrint_clicked");
	connect(this.child("tbnImprimeAA"), "clicked()", _i, "tbnImprimeAA_clicked");
	connect(this.child("chkVerTodas"), "clicked()", _i, "chkVerTodas_clicked");
	connect(this.child("tbnReabrirOrden"), "clicked()", _i, "tbnReabrirOrden_clicked");
	
	this.child("tdbLineasPedido").setReadOnly(true); 
	this.child("tdbLineasAlbaran").setReadOnly(true); 
	
  _i.filtraPorOrden();
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnOK_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();
  var codOrden = cursor.valueBuffer("codorden");
  if (!codOrden) {
    return;
  }
  var numPrendas = AQUtil.sqlSelect("albaranesprov a INNER JOIN lineasalbaranesprov la ON a.idalbaran = la.idalbaran", "SUM(la.cantidad)", "a.codordenprod = '" + codOrden + "' AND la.cantidad > 0", "lineasalbaranesprov");
	numPrendas = isNaN(numPrendas) ? 0 : numPrendas;
	if (!numPrendas) {
		var res = MessageBox.warning(sys.translate("NO HAS RECEPCIONADO NADA. Estas intentando cerrar una orden a la que no has recepcionado nada �est�s seguro? ?").arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return;
		}
		res = MessageBox.warning(sys.translate("�Totalmente seguro, de que no quieres recepcionar nada?").arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return;
		}
	}
  var idTareaDC = AQUtil.sqlSelect("pr_tareas", "idtarea", "idobjeto = '" + codOrden + "' AND tipoobjeto = 'pr_ordenesproduccion' AND estado = 'PTE' AND idtipotarea = 'DC'");
  if (!idTareaDC) {
    MessageBox.warning(sys.translate("No hay una tarea de distribuci�n a confecciones pendiente para la orden %1").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return;
  }
  var res = MessageBox.warning(sys.translate("Ha recepcionado %1 prendas.\nVa a dar por concluida la distribuci�n a confecciones de la orden %2.\n�Est� seguro?").arg(numPrendas).arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
  if (res != MessageBox.Yes) {
    return;
  }
  var oParam = new Object;
  oParam.idTarea = idTareaDC;
  oParam.codOrden = codOrden;
  oParam.errorMsg = sys.translate("Error al terminar la tarea de distribuci�n a confecciones");
  var f = new Function("oParam", "return formem_districonf.iface.terminaTareaDC(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  _i.tdbOrdenes_.refresh();
  _i.filtraPorOrden();
}

function oficial_terminaTareaDC(oParam)
{
  var curTarea = new FLSqlCursor("pr_tareas");
  curTarea.select("idtarea = '" + oParam.idTarea + "'");
  if (!curTarea.first()) {
    return false;
  }
  if (!flcolaproc.iface.pub_iniciarTarea(curTarea, sys.nameUser())) {
    return false;
  }
  if (!flcolaproc.iface.pub_terminarTarea(curTarea)) {
    return false;
  }
  var codOrden = oParam.codOrden;
  /*
  if (!AQSql.update("lotesstock", ["estado"], ["TERMINADO"], "codordenproduccion = '" + codOrden + "'")) {
    return;
  }
  */
  return true;
}

function oficial_filtraOrdenes()
{
  var _i = this.iface;
  var filtro = "";
  var cursor = this.cursor();
	if (!this.child("chkVerTodas").checked) {
		filtro = "estado = 'PTE CONFECCION'";
	}
  cursor.setMainFilter(filtro);
  _i.tdbOrdenes_.refresh();
}

function oficial_filtraPorOrden()
{
  var _i = this.iface;
  var filtro = "";
  var cursor = this.cursor();
  var codOrden = cursor.size() > 0 ? cursor.valueBuffer("codorden") : "Ninguna";
  filtro = "codordenprod = '" + codOrden + "'";
  this.child("tdbPedidos").setFilter(filtro); 
  this.child("tdbPedidos").refresh();
  this.child("tdbAlbaranes").setFilter(filtro);  
  this.child("tdbAlbaranes").refresh();
  this.child("tdbLotes").setFilter("codordenproduccion = '" + codOrden + "'");  
  this.child("tdbLotes").refresh();
  
  _i.filtraLineasPedido();
  _i.filtraLineasAlbaran();
}

function oficial_filtraLineasPedido()
{
  var filtro = "";
  var cursor = this.child("tdbPedidos").cursor();
  var idPedido = cursor.size() > 0 ? cursor.valueBuffer("idpedido") : false;
	if (idPedido) {
		filtro = "idpedido = " + idPedido;
	} else {
		filtro = "1 = 2";
	}
  this.child("tdbLineasPedido").setFilter(filtro); 
  this.child("tdbLineasPedido").refresh();
}

function oficial_filtraLineasAlbaran()
{
  var filtro = "";
  var cursor = this.child("tdbAlbaranes").cursor();
  var idAlbaran = cursor.size() > 0 ? cursor.valueBuffer("idAlbaran") : false;
  if (idAlbaran) {
		filtro = "idalbaran = " + idAlbaran;
	} else {
		filtro = "1 = 2";
	}
  this.child("tdbLineasAlbaran").setFilter(filtro); 
  this.child("tdbLineasAlbaran").refresh();
}

function oficial_ordenarCols()
{
	var cols = ["codorden", "fecha", "codconfeccionista", "nombreconfeccionista", "codpedidoconf", "nombrecliente"];
	this.iface.tdbOrdenes_.setOrderCols(cols);
	this.iface.tdbOrdenes_.refresh();
  
  var colsLP = ["referencia", "descripcion", "cantidad", "totalenalbaran", "pendiente"];
  this.child("tdbLineasPedido").setOrderCols(colsLP);
  this.child("tdbLineasPedido").refresh();
}

function oficial_controlOrdenAbierta()
{
	var _i = this.iface;
	var cursor = this.cursor();
  if (cursor.valueBuffer("estado") != "PTE CONFECCION") {
		sys.warnMsgBox(sys.translate("No puede realizar esta acci�n sobre una orden en estado distinto de PTE CONFECCION"));
		return false;
	}
	return true;
}

function oficial_tbnPedido_clicked()
{
  var _i = this.iface;
	if (!_i.controlOrdenAbierta()) {
		return false;
	}
  var cursor = this.cursor();
  var codOrden = cursor.valueBuffer("codorden");
  if (!codOrden) {
    return;
  }
  var codConfec = cursor.valueBuffer("codconfeccionista");
  if (!codConfec) {
    MessageBox.warning(sys.translate("Debe indicar antes el confeccionista de la orden %1.").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return;
  }
  if (AQUtil.sqlSelect("pedidosprov", "idpedido", "codproveedor = '" + codConfec + "' AND codordenprod = '" + codOrden + "'")) {
    var res = MessageBox.warning(sys.translate("Ya existe un pedido para el proveedor %1 y la orden %2.\n�Desea continuar?").arg(codConfec).arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
    if (res != MessageBox.Yes) {
      return;
    }
  }
  var oParam = new Object;
  oParam.codPedido = false;
	oParam.codOrden = codOrden;
  oParam.errorMsg = sys.translate("Error al crear el pedido a confeccionista");
  var f = new Function("oParam", "return formem_districonf.iface.creaPedidoConf(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  
  MessageBox.information(sys.translate("Pedido %1 creado").arg(oParam.codPedido), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
}

function oficial_creaPedidoConf(oParam)
{
   var _i = this.iface;
  
  var hoy = new Date;
  var fecha = hoy.toString();
  var codOrden = oParam.codOrden;
  var codConfec = AQUtil.sqlSelect("pr_ordenesproduccion", "codconfeccionista", "codorden = '" + codOrden + "'");
  if (!codConfec) {
    return;
  }
	
  var codAlmacen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen"); //AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codConfec + "'");
  if (!codAlmacen) {
    MessageBox.warning(sys.translate("El confeccionista no tiene un almac�n asociado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  var qAlma = new FLSqlQuery;
  qAlma.setSelect("direccion, codpostal, poblacion, idprovincia, provincia, codpais, contacto");
  qAlma.setFrom("almacenes");
  qAlma.setWhere("codalmacen = '" + codAlmacen + "'");
  qAlma.setForwardOnly(true);
  if (!qAlma.exec()) {
    return false;
  }
  if (!qAlma.first()) {
    MessageBox.warning(sys.translate("Error al obtener los datos del almac�n %1").arg(codAlmacen), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  
  var codEjercicio = flfactppal.iface.pub_ejercicioActual();
  var datosDoc = flfacturac.iface.pub_datosDocFacturacion(fecha, codEjercicio, "albaranescli");
  if (!datosDoc.ok) {
    return false;
  }
  if (datosDoc.modificaciones) {
    codEjercicio = datosDoc.codEjercicio;
    fecha = datosDoc.fecha;
  }

  var codSerie = AQUtil.sqlSelect("proveedores","codserie","codproveedor = '" + codConfec + "'");
  if(!codSerie || codSerie == "") {
  	codSerie = AQUtil.sqlSelect("secuenciasejercicios", "codserie", "codejercicio = '" + codEjercicio + "' ORDER BY codserie");
  }	

  var idProvincia;
  var curP = new FLSqlCursor("pedidosprov");
  curP.setModeAccess(curP.Insert);
  curP.refreshBuffer();
  curP.setValueBuffer("fecha", fecha);
  curP.setValueBuffer("fechaentrada", AQUtil.sqlSelect("pr_ordenesproduccion", "fechaentrega", "codorden = '" + codOrden + "'"));
  curP.setValueBuffer("nombre", AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codConfec + "'"));
  curP.setValueBuffer("cifnif", AQUtil.sqlSelect("proveedores", "cifnif", "codproveedor = '" + codConfec + "'"));
  curP.setValueBuffer("codproveedor", codConfec);
  curP.setValueBuffer("coddivisa", flfactppal.iface.pub_valorDefectoEmpresa("coddivisa"));
  curP.setValueBuffer("codpago", AQUtil.sqlSelect("proveedores", "codpago", "codproveedor = '" + codConfec + "'"));
  curP.setValueBuffer("codalmacen", codAlmacen);
  curP.setValueBuffer("tasaconv", 1);
  curP.setValueBuffer("codejercicio", codEjercicio);
	curP.setValueBuffer("codgrupoivaneg", AQUtil.sqlSelect("proveedores", "codgrupoivaneg", "codproveedor = '" + codConfec + "'"));
  //curP.setValueBuffer("codserie", AQUtil.sqlSelect("secuenciasejercicios", "codserie", "codejercicio = '" + codEjercicio + "' ORDER BY codserie"));
	curP.setValueBuffer("codserie", codSerie);
  curP.setValueBuffer("idcontactoenvio", sys.nameUser());
  curP.setValueBuffer("contactoprov", qAlma.value("contacto"));
  curP.setValueBuffer("direccione", qAlma.value("direccion"));
  curP.setValueBuffer("codpostale", qAlma.value("codpostal"));
  curP.setValueBuffer("ciudade", qAlma.value("ciudad"));
  idProvincia = qAlma.value("idprovincia");
  if (idProvincia) {
    curP.setValueBuffer("idprovinciae", idProvincia);
  }
  curP.setValueBuffer("provinciae", qAlma.value("provincia"));
  curP.setValueBuffer("codpaise", qAlma.value("codpais"));
  curP.setValueBuffer("codordenprod", codOrden);
  var idPedido = curP.valueBuffer("idpedido");
  if (!curP.commitBuffer()) {
    return false;
  }
  var qLote = new FLSqlQuery;
  qLote.setSelect("l.codlote, l.canlote, l.referencia, a.descripcion");
  qLote.setFrom("lotesstock l INNER JOIN articulos a ON l.referencia = a.referencia");
  qLote.setWhere("l.codordenproduccion = '" + codOrden + "'");
  qLote.setForwardOnly(true);
  if (!qLote.exec()) {
    return false;
  }
  var curLinea = new FLSqlCursor("lineaspedidosprov");
  while (qLote.next()) {
    curLinea.setModeAccess(curLinea.Insert);
    curLinea.refreshBuffer();
    curLinea.setValueBuffer("idpedido", idPedido);
    curLinea.setValueBuffer("referencia", qLote.value("l.referencia"));
    curLinea.setValueBuffer("descripcion", formRecordlineaspedidosprov.iface.pub_commonCalculateField("desarticulo", curLinea));
		curLinea.setValueBuffer("codtamanoem", AQUtil.sqlSelect("articulos", "codtamanoem", "referencia = '" + qLote.value("l.referencia") + "'"));
		curLinea.setValueBuffer("codcolorem", AQUtil.sqlSelect("articulos", "codcolorem", "referencia = '" + qLote.value("l.referencia") + "'"));
    curLinea.setValueBuffer("cantidad", qLote.value("l.canlote"));
    curLinea.setValueBuffer("codloteprod", qLote.value("l.codlote"));
    curLinea.setValueBuffer("pvpunitario", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpunitario", curLinea));
    curLinea.setValueBuffer("codimpuesto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("codimpuesto", curLinea));
    curLinea.setValueBuffer("iva", formRecordlineaspedidosprov.iface.pub_commonCalculateField("iva", curLinea));
    curLinea.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLinea));
    curLinea.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLinea));
    curLinea.setValueBuffer("numlinea",formRecordlineaspedidosprov.iface.pub_commonCalculateField("numlinea", curLinea));
    if (!curLinea.commitBuffer()) {
      return false;
    }
  }
  
  /// Borra movimiento de recepci�n prevista asociado a la orden, ya que se ha creado el correspondiente para el pedido. Antes de crear la l�nea para que se libere la reserva y la l�nea la coja
  /* Nuevo 
	var curMoviStock = new FLSqlCursor("movistock");
	var idProceso = AQUtil.sqlSelect("pr_procesos", "idproceso", "tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "'");
	if (!idProceso) {
		sys.warnMsgBox(sys.translate("Error al localizar el proceso de producci�n asociado a la orden %1").arg(codOrden));
		return false;
	}
	curMoviStock.select("idproceso = " + idProceso + " AND estado = 'PTE'");
	while (curMoviStock.next()) {
		curMoviStock.setModeAccess(curMoviStock.Del);
		curMoviStock.refreshBuffer();
		if (!curMoviStock.commitBuffer()) {
			return false;
		}
	}
	FIN Nuevo  */
	
  curP.select("idpedido = " + idPedido);
  if (!curP.first()) {
    return false;
  }
  with (curP) {
    setModeAccess(curP.Edit);
    refreshBuffer();
    setValueBuffer("netosindtoesp", formpedidosprov.iface.pub_commonCalculateField("netosindtoesp", this));
    setValueBuffer("dtoesp", formpedidosprov.iface.pub_commonCalculateField("dtoesp", this));
    setValueBuffer("neto", formpedidosprov.iface.pub_commonCalculateField("neto", this));
    setValueBuffer("totaliva", formpedidosprov.iface.pub_commonCalculateField("totaliva", this));
    setValueBuffer("totalirpf", formpedidosprov.iface.pub_commonCalculateField("totalirpf", this));
    setValueBuffer("totalrecargo", formpedidosprov.iface.pub_commonCalculateField("totalrecargo", this));
    setValueBuffer("total", formpedidosprov.iface.pub_commonCalculateField("total", this));
    setValueBuffer("totaleuros", formpedidosprov.iface.pub_commonCalculateField("totaleuros", this));
  }
  oParam.codPedido = curP.valueBuffer("codigo");
  if (!curP.commitBuffer()) {
    return false;
  }
  
  return true;
}

function oficial_tbnImprimirPedido_clicked()
{
  var curPedido = this.child("tdbPedidos").cursor();
  if (!curPedido) {
    return false;
  }
  var codPedido = curPedido.valueBuffer("codigo");
  if (!formpedidosprov.iface.pub_imprimir(codPedido)) {
    return false;
  }
}

function oficial_tbnAlbaranPedido_clicked()
{
	var _i = this.iface;
	if (!_i.controlOrdenAbierta()) {
		return false;
	}
  var curPedido = this.child("tdbPedidos").cursor();
  if (!curPedido) {
    return false;
  }
  var idPedido = curPedido.valueBuffer("idpedido");
	if (!idPedido) {
		return false;
	}
	if (!_i.curPedidoAlb_) {
		_i.curPedidoAlb_ = new FLSqlCursor("pedidosprov");
	}
  
  _i.curPedidoAlb_.select("idpedido = " + idPedido);
  if (!_i.curPedidoAlb_.first()) {
    return;
  }
  _i.curPedidoAlb_.setAction("pedidosprovparciales");
	disconnect(_i.curPedidoAlb_, "bufferCommited()", _i, "refrescaPedidoAlbaran");
	connect(_i.curPedidoAlb_, "bufferCommited()", _i, "refrescaPedidoAlbaran");
  _i.curPedidoAlb_.editRecord();
  return;
}

function oficial_tbnAbrirCerrarPedido_clicked()
{
	var _i = this.iface;
	if (!_i.controlOrdenAbierta()) {
		return false;
	}
	
  var curPedido = this.child("tdbPedidos").cursor();
  if (!curPedido) {
    return false;
  }
  // var idPedido = curPedido.valueBuffer("idpedido");
  if (!formpedidosprov.iface.pub_abrirCerrarPedido(curPedido)) {
    return false;
  }
  this.child("tdbPedidos").refresh();
}

function oficial_refrescaPedidoAlbaran()
{
	this.child("tdbPedidos").refresh(true, true);
	this.child("tdbAlbaranes").refresh(true, true);
}

function oficial_tbnPedidoAFaltas_clicked()
{
  var _i = this.iface;
	if (!_i.controlOrdenAbierta()) {
		return false;
	}
  var curPedido = this.child("tdbPedidos").cursor();
  if (!curPedido) {
    return false;
  }
  if (curPedido.valueBuffer("editable")) {
    MessageBox.warning(sys.translate("El pedido seleccionado debe estar cerrado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return;
  }
  var cursor = this.cursor();
  var codOrden = cursor.valueBuffer("codorden");
  if (!codOrden) {
    return;
  }
  var codProveedor = _i.dameProveedorAFaltas();
  if (!codProveedor) {
    return;
  }
  if (AQUtil.sqlSelect("pedidosprov", "idpedido", "codproveedor = '" + codProveedor + "' AND codordenprod = '" + codOrden + "'")) {
    var res = MessageBox.warning(sys.translate("Ya existe un pedido para el proveedor %1 y la orden %2.\n�Desea continuar?").arg(codProveedor).arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
    if (res != MessageBox.Yes) {
      return;
    }
  }
  var oParam = new Object;
  oParam.codPedidoFaltas = false;
	oParam.codProveedor = codProveedor;
  oParam.idPedidoConf = curPedido.valueBuffer("idpedido");
  oParam.errorMsg = sys.translate("Error al crear el pedido a faltas");
  var f = new Function("oParam", "return formem_districonf.iface.creaPedidoAFaltas(oParam)");
  if (!sys.runTransaction(f, oParam)) {
    return false;
  }
  this.child("tdbPedidos").refresh();
  MessageBox.information(sys.translate("Pedido %1 creado").arg(oParam.codPedidoFaltas), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
}

function oficial_dameProveedorAFaltas()
{
	var dP = flfactppal.iface.pub_ejecutarQry("empresa", "codprovinternocon,codprovinternorel", "1 = 1");
	if (dP.result != 1) {
		sys.warnMsgBox(sys.translate("No se ha encontrado los datos de proveedores internos de confecci�n y relleno"));
		return false;
	}
	var pCon, pRel;
	pCon = dP.codprovinternocon ? AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + dP.codprovinternocon + "'") : false;
	pRel = dP.codprovinternorel ? AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + dP.codprovinternorel + "'") : false;
	if (!dP.codprovinternocon || !dP.codprovinternorel) {
		sys.warnMsgBox(sys.translate("No se ha encontrado los datos de proveedores internos de confecci�n y relleno"));
		return false;
	}
	var sel = Input.getItem(sys.translate("Seleccione proveedor"), [pCon, pRel], pCon, false);
	if (!sel) {
		return false;
	}
	return sel == pCon ? dP.codprovinternocon : dP.codprovinternorel;
}

function oficial_creaPedidoAFaltas(oParam)
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  var hoy = new Date;
  var fecha = hoy.toString();
  var codOrden = cursor.valueBuffer("codorden");
  var codProveedor = oParam.codProveedor;
  var codAlmacen = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codProveedor + "'");
  if (!codAlmacen) {
    MessageBox.warning(sys.translate("El proveedor interno no tiene un almac�n asociado"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  var qAlma = new FLSqlQuery;
  qAlma.setSelect("direccion, codpostal, poblacion, idprovincia, provincia, codpais, contacto");
  qAlma.setFrom("almacenes");
  qAlma.setWhere("codalmacen = '" + codAlmacen + "'");
  qAlma.setForwardOnly(true);
  if (!qAlma.exec()) {
    return false;
  }
  if (!qAlma.first()) {
    MessageBox.warning(sys.translate("Error al obtener los datos del almac�n %1").arg(codAlmacen), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  
  var codEjercicio = flfactppal.iface.pub_ejercicioActual();
  var datosDoc = flfacturac.iface.pub_datosDocFacturacion(fecha, codEjercicio, "albaranescli");
  if (!datosDoc.ok) {
    return false;
  }
  if (datosDoc.modificaciones) {
    codEjercicio = datosDoc.codEjercicio;
    fecha = datosDoc.fecha;
  }
  var codSerie = AQUtil.sqlSelect("proveedores","codserie","codproveedor = '" + codProveedor + "'");
  if(!codSerie || codSerie == "") {
  	codSerie = AQUtil.sqlSelect("secuenciasejercicios", "codserie", "codejercicio = '" + codEjercicio + "' ORDER BY codserie");
  }	
  
  var idProvincia;
  var curP = new FLSqlCursor("pedidosprov");
  curP.setModeAccess(curP.Insert);
  curP.refreshBuffer();
  curP.setValueBuffer("fecha", fecha);
  curP.setValueBuffer("fechaentrada", fecha);
  curP.setValueBuffer("nombre", AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'"));
  curP.setValueBuffer("cifnif", AQUtil.sqlSelect("proveedores", "cifnif", "codproveedor = '" + codProveedor + "'"));
  curP.setValueBuffer("codproveedor", codProveedor);
	curP.setValueBuffer("codgrupoivaneg", AQUtil.sqlSelect("proveedores", "codgrupoivaneg", "codproveedor = '" + codProveedor + "'"));
  curP.setValueBuffer("coddivisa", flfactppal.iface.pub_valorDefectoEmpresa("coddivisa"));
  curP.setValueBuffer("codpago", AQUtil.sqlSelect("proveedores", "codpago", "codproveedor = '" + codProveedor + "'"));
  curP.setValueBuffer("codalmacen", codAlmacen);
  curP.setValueBuffer("tasaconv", 1);
  curP.setValueBuffer("codejercicio", codEjercicio);
  //curP.setValueBuffer("codserie", AQUtil.sqlSelect("secuenciasejercicios", "codserie", "codejercicio = '" + codEjercicio + "' ORDER BY codserie"));
  curP.setValueBuffer("codserie", codSerie);
  curP.setValueBuffer("idcontactoenvio", sys.nameUser());
  curP.setValueBuffer("contactoprov", qAlma.value("contacto"));
  curP.setValueBuffer("direccione", qAlma.value("direccion"));
  curP.setValueBuffer("codpostale", qAlma.value("codpostal"));
  curP.setValueBuffer("ciudade", qAlma.value("poblacion"));
  idProvincia = qAlma.value("idprovincia");
  if (idProvincia) {
    curP.setValueBuffer("idprovinciae", idProvincia);
  }
  curP.setValueBuffer("provinciae", qAlma.value("provincia"));
  curP.setValueBuffer("codpaise", qAlma.value("codpais"));
  curP.setValueBuffer("codordenprod", codOrden);
  var idPedido = curP.valueBuffer("idpedido");
  if (!curP.commitBuffer()) {
    return false;
  }
  var qLineas = new FLSqlQuery;
  qLineas.setSelect("codloteprod, pendiente, referencia, descripcion, codtamanoem, codcolorem");
  qLineas.setFrom("lineaspedidosprov");
  qLineas.setWhere("idpedido = "  + oParam.idPedidoConf + " AND pendiente <> 0");
  qLineas.setForwardOnly(true);
  if (!qLineas.exec()) {
    return false;
  }
  var curLinea = new FLSqlCursor("lineaspedidosprov");
  var numLineas = 0, referencia, cantidad, codLoteProd;
  while (qLineas.next()) {
		referencia = qLineas.value("referencia");
		cantidad = qLineas.value("pendiente");
		codLoteProd = qLineas.value("codloteprod");
    curLinea.setModeAccess(curLinea.Insert);
    curLinea.refreshBuffer();
    curLinea.setValueBuffer("idpedido", idPedido);
    curLinea.setValueBuffer("referencia", referencia);
    curLinea.setValueBuffer("descripcion", qLineas.value("descripcion"));
		curLinea.setValueBuffer("codtamanoem", qLineas.value("codtamanoem"));
		curLinea.setValueBuffer("codcolorem", qLineas.value("codcolorem"));
    curLinea.setValueBuffer("cantidad", cantidad);
    curLinea.setValueBuffer("codloteprod", codLoteProd);
    curLinea.setValueBuffer("pvpunitario", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpunitario", curLinea));
    curLinea.setValueBuffer("codimpuesto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("codimpuesto", curLinea));
    curLinea.setValueBuffer("iva", formRecordlineaspedidosprov.iface.pub_commonCalculateField("iva", curLinea));
    curLinea.setValueBuffer("pvpsindto", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvpsindto", curLinea));
    curLinea.setValueBuffer("pvptotal", formRecordlineaspedidosprov.iface.pub_commonCalculateField("pvptotal", curLinea));
    curLinea.setValueBuffer("numlinea",formRecordlineaspedidosprov.iface.pub_commonCalculateField("numlinea", curLinea));
    if (!curLinea.commitBuffer()) {
      return false;
    }
//     if (!_i.crearConsumosPedFaltas(referencia, codLoteProd, cantidad)) {
// 			return false;
// 		}
    numLineas++;
  }
  if (numLineas == 0) {
    var res = MessageBox.warning(sys.translate("No hay l�neas de pedido a faltas que generar.\n�Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
  }
  curP.select("idpedido = " + idPedido);
  if (!curP.first()) {
    return false;
  }
  with (curP) {
    setModeAccess(curP.Edit);
    refreshBuffer();
    setValueBuffer("netosindtoesp", formpedidosprov.iface.pub_commonCalculateField("netosindtoesp", this));
    setValueBuffer("dtoesp", formpedidosprov.iface.pub_commonCalculateField("dtoesp", this));
    setValueBuffer("neto", formpedidosprov.iface.pub_commonCalculateField("neto", this));
    setValueBuffer("totaliva", formpedidosprov.iface.pub_commonCalculateField("totaliva", this));
    setValueBuffer("totalirpf", formpedidosprov.iface.pub_commonCalculateField("totalirpf", this));
    setValueBuffer("totalrecargo", formpedidosprov.iface.pub_commonCalculateField("totalrecargo", this));
    setValueBuffer("total", formpedidosprov.iface.pub_commonCalculateField("total", this));
    setValueBuffer("totaleuros", formpedidosprov.iface.pub_commonCalculateField("totaleuros", this));
  }
  oParam.codPedidoFaltas = curP.valueBuffer("codigo");
  if (!curP.commitBuffer()) {
    return false;
  }
  return true;
}

function oficial_crearConsumosPedFaltas(referencia, codLote, canBase)
{
	var _i = this.iface;
	var cursor = this.cursor();
  var codOrden = cursor.valueBuffer("codorden");
  
	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("codlote = '" + codLote + "'");
	if (!curLote.first()) {
		return false;
	}
	var idProceso = AQUtil.sqlSelect("pr_procesos", "idproceso", "idobjeto = '" + codOrden + "' AND tipoobjeto = 'pr_ordenesproduccion'");
	if (!idProceso) {
		return false;
	}
	var curComponentes = new FLSqlCursor("articuloscomp");
	curComponentes.select("refcompuesto = '" + referencia + "'");
	var canCompo;
	while (curComponentes.next()) {
		canCompo = canBase * curComponentes.valueBuffer("cantidad") * -1;
		if (!flfactalma.iface.pub_generarMoviStock(curLote, false, canCompo, curComponentes, idProceso)) {
			return false;
		}
	}
	return true;
}

function oficial_tbnImprimeFaltas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codOrden = cursor.valueBuffer("codorden");
	if (!codOrden || codOrden == "") {
		return;
	}
	var curPedido = this.child("tdbPedidos").cursor();
  if (!curPedido) {
    return false;
  }
  
	var oParam = _i.dameParamInformeFaltas();
	if (!oParam) {
		return;
	}
	oParam.whereFijo = "lineaspedidosprov.idpedido = " + curPedido.valueBuffer("idpedido");
	
	var curImprimir:FLSqlCursor = new FLSqlCursor("pr_i_ordenesproduccion");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	curImprimir.setValueBuffer("d_pr__ordenesproduccion_codorden", codOrden);
	curImprimir.setValueBuffer("h_pr__ordenesproduccion_codorden", codOrden);
	flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);
}

function oficial_dameParamInformeFaltas()
{
	var _i = this.iface;
  var util = new FLUtil;
  var oParam = flfactinfo.iface.pub_dameParamInforme();
  oParam.nombreInforme = "pr_i_ordenesprod_af";
	
	oParam.groupBy = "pr_ordenesproduccion.codorden, pr_ordenesproduccion.fecha, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.fechaentrega, pr_ordenesproduccion.subfamilia, pr_ordenesproduccion.dibujo, pr_ordenesproduccion.nombrecliente, pr_tareas.idtarea, articuloscomp.orden, lotesstock.referencia, prod.referencia, prod.descripcion, tamprod.descripcion, colprod.descripcion, articulos.referencia, articulos.descripcion, em_tamanos.descripcion, em_colores.descripcion, articuloscomp.largo, articuloscomp.ancho, em_componentes.descripcion, colprod.codigogit, em_colores.codigogit,em_disenos.codseriediseno,disprod.codseriediseno";
	return oParam;
}

function oficial_toolButtonPrint_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codOrden = cursor.valueBuffer("codorden");
	if (!codOrden) {
		return;
	}
	var oDH = new Object;
	oDH.codOrdenDesde = codOrden;
	oDH.codOrdenHasta = codOrden;
	oDH.cliente = undefined;
	formpr_ordenesproduccion.iface.pub_imprimeOrdenProd(oDH)
}

function oficial_tbnImprimeAA_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codOrden = cursor.valueBuffer("codorden");
	if (!codOrden) {
		return;
	}
	var oDH = new Object;
	oDH.codOrdenDesde = codOrden;
	oDH.codOrdenHasta = codOrden;
	oDH.cliente = undefined;
	formpr_ordenesproduccion.iface.pub_imprimeOrdenMat(oDH)
}

function oficial_chkVerTodas_clicked()
{
	var _i = this.iface;
	_i.filtraOrdenes()
}

function oficial_tbnReabrirOrden_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var estado = cursor.valueBuffer("estado");
	var codOrden = cursor.valueBuffer("codorden");
	
	if (estado != "TERMINADA") {
		sys.warnMsgBox(sys.translate("El estado de la orden no es TERMINADA"));
		return;		
	}
	var res = MessageBox.warning(sys.translate("Va a reabrir la orden %1.\n�Est� seguro?").arg(codOrden), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		return;
	}
	
	var curTarea = new FLSqlCursor("pr_tareas");
	curTarea.select("tipoobjeto = 'pr_ordenesproduccion' AND idobjeto = '" + codOrden + "' AND idtipotarea = 'DC'");
	if (!curTarea.first()) {
		sys.warnMsgBox(sys.translate("No se encuentra la tarea de distribuci�n a confecciones para la orden %1").arg(codOrden));
		return false;
	}
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al reabrir la orden %1").arg(codOrden);
	oParam.curTarea = curTarea;
	var f = new Function("oParam", "return formem_districonf.iface.reabrirOrdenTR(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	_i.tdbOrdenes_.refresh();
	sys.infoMsgBox(sys.translate("La orden %1 se ha reabierto correctamente").arg(codOrden));
	return true;
}

function oficial_reabrirOrdenTR(oParam)
{
	var _i = this.iface;
	if (flcolaproc.iface.pub_deshacerTareaTerminada(oParam.curTarea)) {
		if (!flcolaproc.iface.pub_deshacerTareaEnCurso(oParam.curTarea)) {
			return false;
		}
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
