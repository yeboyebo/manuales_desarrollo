# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa
import re
from datetime import datetime

# stocks = qsa.class_("stocks")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */
class Oficial(Base):

    def get(self, params, username=None):
        mapa = self.get_mapa()
        obj = qsa.from_project("formAPI").get_resources('stocks', params, mapa, username)
        return obj

    def regularizarPrenda(self, params, username=None):
        print(params)
        if not params["almacen"] or not params["articulo"] or not params["descripcion"] or not params["unidades"] or not params["stock"]:
            raise Exception("Debe buscar antes los datos de almacén y referencia")
        #patron = re.compile("/^-?[0-9]+$/")
        #if re.match("/^-?[0-9]+$/", params["nueva"]) is None:
        #    print('no pasa la expresion regular', int(params["nueva"]) , params["nueva"], re.search("/^-?[0-9]+$/", params["nueva"]), re.match("/^-?[0-9]+$/", params["nueva"]) )
        #    raise Exception("La cantidad tiene que ser un número entero igual o mayor que 0")
        if int(params["nueva"]) < 0:
            print('no pasa mayor que 0', int(params["nueva"]) , params["nueva"])
            raise Exception("La cantidad tiene que ser un número entero igual o mayor que 0")

        now = datetime.now()
        hoy = now.strftime("%Y-%m-%d")
        ahora = now.strftime("%H:%M:%S")
        desc = params["descripcion"]
        arrDesc = str(params["descripcion"]).split("/")
        if 0 in arrDesc:
            desc = arrDesc[0]
        Lineasregstocks = qsa.orm_("lineasregstocks")
        linea = Lineasregstocks()
        linea.idstock = params["stock"]
        linea.fecha = hoy
        linea.hora = ahora
        linea.cantidadini = params["unidades"]
        linea.cantidadfin = params["nueva"]
        linea.sincronizado = False
        linea.ptecalculo = True
        linea.motivo = "regularización por pistola"
        linea.save()

        q = qsa.FLSqlQuery()
        q.setSelect("fecha,hora,cantidadfin")
        q.setFrom("lineasregstocks")
        q.setWhere("idstock = " + str(params["stock"]))
        q.setOrderBy('fecha DESC, hora DESC')
        if not q.exec_():
            raise Exception("Error: No se pudo actualizar el stock")
        if not q.first():
            raise Exception("Error: No se pudo actualizar el stock")

        Stock = qsa.orm_("stocks")
        stock = Stock.get(params["stock"])
        print(type(q.value("fecha")), ' -------------- ', str(q.value("fecha")))
        stock.fechaultreg = str(q.value("fecha"))
        stock.horaultreg = q.value("hora")
        stock.cantidadultreg = q.value("cantidadfin")
        stock.save()

        Stocksptes = qsa.orm_("stocksptes")
        stocksptes = Stocksptes()
        stocksptes.idstock = params["stock"]
        stocksptes.fecha = hoy
        timestamp = datetime.now()
        timestamp = timestamp.replace(tzinfo=None)
        stocksptes.timestamp = timestamp
        stocksptes.idusuario = "stockdiferido"
        stocksptes.tipoactualizacion = "STOCK_FISICO"
        stocksptes.codsubfamiliatp = ""
        stocksptes.save()
        return {"nueva_cantidad": q.value("cantidadfin")}

    def get_mapa(self):
        return {
            'join': 'stocks INNER JOIN articulos on stocks.referencia = articulos.referencia',
            'order': 'idstock',
            'map': {
                'idstock': {'field': 'stocks.idstock', 'type': 'string'},
                'codalmacen': {'field': 'stocks.codalmacen', 'type': 'string'},
                'referencia': {'field': 'stocks.referencia', 'type': 'string'},
                'cantidad': {'field': 'stocks.cantidad', 'type': 'string'},
                'disponible': {'field': 'stocks.disponible', 'type': 'string'},
                'reservada': {'field': 'stocks.reservada', 'type': 'string'},
                'pterecibir': {'field': 'stocks.pterecibir', 'type': 'string'},
                'disponiblepterecibir': {'field': 'stocks.disponiblepterecibir', 'type': 'string'},
                'reservadapterecibir': {'field': 'stocks.reservadapterecibir', 'type': 'string'},
                'descripcion': {'field': 'articulos.descripcion', 'type': 'string'},
                'codcolorem': {'field': 'articulos.codcolorem', 'type': 'string'},
                'codtamanoem': {'field': 'articulos.codtamanoem', 'type': 'string'},
                'codbarras': {'field': 'articulos.codbarras', 'type': 'string'},
                'em_ubiactual': {'field': 'articulos.em_ubiactual', 'type': 'string'}
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
