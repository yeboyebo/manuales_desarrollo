
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends traducciones {
	var interruptorModoOper;
	var curS_;
	var pK_;
	var tblLogCostes_;
	var actualizaHerencia_;
	function euromoda( context ) { traducciones ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function filtrarModoOper() {
		return this.ctx.euromoda_filtrarModoOper();
	}
	function dameFiltroSeccion() {
		return this.ctx.euromoda_dameFiltroSeccion();
	}
	function validateForm() {
		return this.ctx.euromoda_validateForm();
	}
	function ordenaColsValMercado() {
		return this.ctx.euromoda_ordenaColsValMercado();
	}
	function toolButtonInsertEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonInsertEmValMercado_clicked()
	}
	function toolButtonEditEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonEditEmValMercado_clicked()
	}
	function toolButtonDeleteEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonDeleteEmValMercado_clicked();
	}
	function toolButtonZoomEmValMercado_clicked() {
		return this.ctx.euromoda_toolButtonZoomEmValMercado_clicked();
	}
	function curS_bufferCommited() {
		return this.ctx.euromoda_curS_bufferCommited()
	}
	function refrescaTabla() {
		return this.ctx.euromoda_refrescaTabla();
	}
	function tdbEmValoresMercado_recordChoosed() {
		return this.ctx.euromoda_tdbEmValoresMercado_recordChoosed();
	}
	function accionCursorExterno(accion) {
		return this.ctx.euromoda_accionCursorExterno(accion);
	}
	function tbwArticulos_currentChanged(nombre) {
		return this.ctx.euromoda_tbwArticulos_currentChanged(nombre);
	}
	function cargaDatosLogCostes() {
		return this.ctx.euromoda_cargaDatosLogCostes();
	}
	function dameTablaLogCostes() {
		return this.ctx.euromoda_dameTablaLogCostes();
	}
	function pbnActualizarMargenes_clicked() {
		return this.ctx.euromoda_pbnActualizarMargenes_clicked();
	}
  
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////



/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////

function euromoda_init() 
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	interruptorModoOper = true;
	var codSeccion = cursor.valueBuffer("em_codseccion");
	
	if(codSeccion == "NULL" || codSeccion == ""){
		//this.child("fdbCodModOper").setValue("");
		//this.child("fdbCodSeccion").setValue("");
	}else{
		interruptorModoOper = false;
	}
	this.child("fdbCodModOper").setDisabled(interruptorModoOper);
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("toolButtonInsertEmValMercado"), "clicked()", _i, "toolButtonInsertEmValMercado_clicked");
	connect(this.child("toolButtonEditEmValMercado"), "clicked()", _i, "toolButtonEditEmValMercado_clicked");
	connect(this.child("toolButtonDeleteEmValMercado"), "clicked()", _i, "toolButtonDeleteEmValMercado_clicked");
	connect(this.child("toolButtonZoomEmValMercado"), "clicked()", _i, "toolButtonZoomEmValMercado_clicked");	
	connect(this.child("tdbEmValoresMercado").cursor(), "recordChoosed()", _i, "tdbEmValoresMercado_recordChoosed");
	connect(this.child("tbwArticulos"), "currentChanged(QString)", _i, "tbwArticulos_currentChanged()");
	connect(this.child("pbnActualizarMargenes"), "clicked()", _i, "pbnActualizarMargenes_clicked");
	
	_i.tblLogCostes_ = undefined;
	_i.ordenaColsValMercado();
	formRecordarticulos.iface.habilitaCamposCostesProd(this, cursor);
	_i.cargaDatosLogCostes();
	_i.actualizaHerencia_ = false;
}

function euromoda_bufferChanged(fN) 
{
	var _i = this.iface;
	var cursor = this.cursor();
	//debug("///// entro en euromoda_bufferChanged(){ y el valor fN es:" + fN + "	}");
	if (fN == "em_codseccion") {			
		interruptorModoOper = false;
		_i.filtrarModoOper();
		this.child("fdbCodModOper").setValue("");
		this.child("fdbCodModOper").setDisabled(interruptorModoOper);	 		
	} else if(fN =="em_margenprod" || fN == "em_observmargenprod") {
		var d = new Date;
		this.child("fdbEmFechaMargenProd").setValue(d.toString());
		this.child("fdbHoraMargenProd").setValue(d.toString().right(8));
		this.child("fdbEmIdUsuarioMargenProd").setValue(sys.nameUser());					
	}
}

function euromoda_filtrarModoOper()
{
	var _i = this.iface;
	
	var filtroSeccion = _i.dameFiltroSeccion();

	this.child("fdbCodModOper").setFilter(filtroSeccion);
}

function euromoda_dameFiltroSeccion()
{
	var cursor = this.cursor();
	var filtro;
	var codSeccion = cursor.valueBuffer("em_codseccion");
	if(codSeccion && codSeccion != "") {
		filtro = "codseccion = '" + codSeccion + "'"
	} else {
		filtro = "1=1";
		interruptorModoOper = true;
	}

	return filtro;
}

function euromoda_validateForm() 
{
	var cursor = this.cursor();
	/*if(!flfactalma.iface.controlDatosModCosteProd(cursor)) {
		return false;
	} 
	if(!formRecordarticulos.iface.ponDatosLogCostes("familias", cursor)) {
		return false;
	}*/
	if(interruptorModoOper == true){
		//si no hay nada en el campo fdbSeccion, estando desabilitado el campofdbCodModOper
		//dejar� validar el formulario
		return true;
	}else{
		//1. cogermos del cursor el campo seccion y codmodoperacon
		var seccion = cursor.valueBuffer("em_codseccion");
		var codmodoperacon = cursor.valueBuffer("em_codmodooper");
		//2. consultamos
		if(!AQUtil.sqlSelect("em_modosoperacion","codseccion", "codseccion = '" + seccion + "' and codmodooper = '" + codmodoperacon + "'")){
			//mostramos mensaje
			sys.warnMsgBox(sys.translate("El modo de operaci�n no est� asociado a la secci�n."));
			return false;
		}
		return true;
	}
	return true;
}

function euromoda_ordenaColsValMercado()
{
	
    var tdbLC = this.child("tdbEmValoresMercado");
    var dtbLC = this.mainWidget().child("tdbEmValoresMercado").tableRecords();    
	var hHeader = dtbLC.horizontalHeader();	hHeader.setClickEnabled(false);
	hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbLC.setSort(["v_valoresmercado.referencia ASC", "v_valoresmercado.em_fechavalmercado ASC"]); 	
    dtbLC.refresh(AQS.RefreshData);   
    this.child("tdbEmValoresMercado").refresh();
}

function euromoda_tdbEmValoresMercado_recordChoosed()
{
	var _i = this.iface;
	_i.toolButtonEditEmValMercado_clicked();
}
function euromoda_toolButtonInsertEmValMercado_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("insert");
}

function euromoda_toolButtonEditEmValMercado_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("edit");
}

function euromoda_toolButtonDeleteEmValMercado_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("del");
}

function euromoda_toolButtonZoomEmValMercado_clicked()
{
	var _i = this.iface;
	_i.accionCursorExterno("browse");
}
function euromoda_accionCursorExterno(accion)
{
	var _i = this.iface;
	var cursor = this.child("tdbEmValoresMercado").cursor();
	
	if (_i.curS_) {
		disconnect(_i.curS_, "commited()", _i, "refrescaTabla");
		disconnect(_i.curS_, "commited()", _i, "curS_bufferCommited");
		_i.curS_ = undefined;
	}
	
	_i.curS_ = new FLSqlCursor("em_valoresmercado");
	_i.curS_.setAction("em_valoresmercado");
	switch (accion) {
		case "insert":
		case "copy": {
			break;
		}
		default: {
			_i.curS_.select(cursor.primaryKey() + " = " + cursor.valueBuffer(cursor.primaryKey()));
			if (!_i.curS_.first()) {
				return false;
			}
		}
	}
	
	switch (accion) {
		case "insert": {
			connect(_i.curS_, "commited()", _i, "curS_bufferCommited");
			_i.curS_.insertRecord();
			break;
		}
		case "edit": {
			connect(_i.curS_, "commited()", _i, "refrescaTabla");
			_i.curS_.editRecord();
			break;
		}
		case "del": {
			//eliminar registro pero de la tabla em_valoresmercado	

			var res = flfactppal.iface.preguntaMsg(sys.translate("El registro activo ser� borrado. �Est� seguro?"),"info",this,MessageBox.Yes, MessageBox.No);  
  			if (res != MessageBox.Yes) {
				return false;
  			}	
			_i.curS_.setModeAccess(_i.curS_.Del);
  			_i.curS_.refreshBuffer();
			if (!_i.curS_.commitBuffer()) {
				return false;
			}			
			this.child("tdbEmValoresMercado").refresh();
			break;
		}
		case "browse": {	
			_i.curS_.browseRecord();
			break;
		}
	}
}
function euromoda_curS_bufferCommited()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	this.child("tdbEmValoresMercado").refresh();
	var dtbLC = this.mainWidget().child("tdbEmValoresMercado").tableRecords();
	var hHeader = dtbLC.horizontalHeader();
	var asc = (hHeader.sortIndicatorOrder() == AQS.Ascending);
	//var pos = cursor.atFromBinarySearch("codigo", _i.pK_, asc);
	var pos = cursor.atFromBinarySearch("id", _i.pK_, asc);
	cursor.seek(pos);
	cursor.refresh()
}
function euromoda_refrescaTabla()
{
	var _i = this.iface;
	this.child("tdbEmValoresMercado").refresh();
}

function euromoda_tbwArticulos_currentChanged(nombre) 
{
	var _i = this.iface;
	if (nombre == "em_margenes") {
		//_i.cargaDatosLogCostes();
	}
}

function euromoda_cargaDatosLogCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var obj = _i.dameTablaLogCostes();	
	var miTabla = obj.miTabla;
	var q = new FLSqlQuery;
	q.setSelect(formRecordarticulos.iface.dameSelectLogCostes(cursor));		
	q.setFrom("v_logcostesmargenes");
	q.setWhere(formRecordarticulos.iface.dameWhereLogCostes(cursor));
	q.setOrderBy("v_logcostesmargenes.fechahis DESC, v_logcostesmargenes.horahis DESC");		
	miTabla.setQuery(q);	

	formRecordarticulos.iface.ponTamanosLogCostes(miTabla);
	miTabla.setColumnWidth("v_logcostesmargenes.em_observmargenprod", 450);

	miTabla.setReadOnly(true);	
	miTabla.refresh();
	
	return true;	
}

function euromoda_dameTablaLogCostes()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblLogCostes_ ? true : false;
	obj.tabla = this.child("mte_tblExt_LogCostes");
	obj.gb = this.child("mte_gbExt_LogCostes");

	if (!obj.creado) {
		_i.tblLogCostes_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblLogCostes_.checkColumnEnabled(false);
		_i.tblLogCostes_.setAliasCheckColumn("Sel.");
		_i.tblLogCostes_.setSearchEnabled(true);
		_i.tblLogCostes_.setOrderDesc(true);
		//_i.tblLogCostes_.setDoubleClickedFunction("formem_reservasop.iface.abrirOP");
	}
	
	obj.miTabla = _i.tblLogCostes_;

	return obj;
}

function euromoda_pbnActualizarMargenes_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.actualizaHerencia_ = true;
	flfactalma.iface.oMargenes_ = new Object();
	flfactalma.iface.oMargenes_["em_margenprod"] = cursor.valueBuffer("em_margenprod");
	flfactalma.iface.oMargenes_["em_observmargenprod"] = cursor.valueBuffer("em_observmargenprod");
	cursor.commitBuffer();
	if(!formRecordem_tamanossubfam.iface.actualizarMargenes(cursor)) {
		return false;
	}
	_i.tblLogCostes_.refresh();
	flfactalma.iface.oMargenes_ = false;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
