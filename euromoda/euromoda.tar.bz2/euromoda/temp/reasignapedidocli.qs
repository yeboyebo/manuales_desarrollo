/**************************************************************************
                 reasignapedidocli.qs  -  description
                             -------------------
    begin                : mar dic 27 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var cIDP, cIDL, cSEL, cCOD, cNOM, cCAN, cFS1, cFS2, cFP1, cFP2;
	var tblPedidos_;
	var cNoSel_, cSel_;
	var canLinea, canSel;
	function oficial( context ) { interna( context ); } 
	function tblPedidos_currentChanged(row, col) {
		return this.ctx.oficial_tblPedidos_currentChanged(row, col);
	}
	function poblarTabla() {
		return this.ctx.oficial_poblarTabla();
	}
	function generarTabla() {
		return this.ctx.oficial_generarTabla();
	}
	function datosLinea() {
		return this.ctx.oficial_datosLinea();
	}
	function calculaTotales() {
		return this.ctx.oficial_calculaTotales();
	}
	function dameFechaServicio(idPedido, idLinea, fLinea) {
		return this.ctx.oficial_dameFechaServicio(idPedido, idLinea, fLinea);
	}
	function coloreaFila(f, clr) {
		return this.ctx.oficial_coloreaFila(f, clr);
	}
	function colores() {
		return this.ctx.oficial_colores();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function validarForm() {
		return this.ctx.oficial_validarForm();
	}
	function cambiaFechas() {
		return this.ctx.oficial_cambiaFechas();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.tblPedidos_ = this.child("tblPedidos");
	var cursor = this.cursor();

// 	connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");
// 	connect(_i.tblPedidos_, "doubleClicked(int, int)", this, "iface.incluirFila");
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked()");
	connect(_i.tblPedidos_, "clicked(int, int)", _i, "tblPedidos_currentChanged");
	
	var hoy = new Date();
	
	_i.canSel = 0;
	_i.colores();
	_i.generarTabla();
	_i.poblarTabla();
	_i.datosLinea();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_datosLinea()
{
	var _i = this.iface;
	var curLP = formRecordlineaspedidoscli.cursor();
	if (!curLP) {
		return;
	}
	this.child("lblDesReferencia").text = curLP.valueBuffer("referencia") + " - " + curLP.valueBuffer("descripcion");
	_i.canLinea = curLP.valueBuffer("cantidad");
	this.child("lblCantidad").text = sys.translate("Cantidad %1").arg(_i.canLinea);
	this.child("dedServLinea").date = curLP.valueBuffer("fechaservicio");
	this.child("dedServPedido").date = curLP.cursorRelation().valueBuffer("fechaservicio");
}

function oficial_tblPedidos_currentChanged(f, c)
{
	var _i = this.iface;
	var s = _i.tblPedidos_.text(f, _i.cSEL);
	var s = s == "X" ? " " : "X";
	_i.tblPedidos_.setText(f, _i.cSEL, s);
	if (s == "X") {
		var fLinea = this.child("dedServLinea").date;
		_i.tblPedidos_.setText(f, _i.cFS2, AQUtil.dateAMDtoDMA(fLinea));
		var fPedido = _i.dameFechaServicio(_i.tblPedidos_.text(f, _i.cIDP), _i.tblPedidos_.text(f, _i.cIDL), fLinea);
		_i.tblPedidos_.setText(f, _i.cFP2, AQUtil.dateAMDtoDMA(fPedido));
		_i.coloreaFila(f, _i.cSel_);
	} else {
		_i.tblPedidos_.setText(f, _i.cFS2, "");
		_i.tblPedidos_.setText(f, _i.cFP2, "");
		_i.coloreaFila(f, _i.cNoSel_);
	}
	_i.calculaTotales();
}

function oficial_dameFechaServicio(idPedido, idLinea, fLinea)
{
	var f = AQUtil.sqlSelect("lineaspedidoscli", "fechaservicio", "idpedido = " + idPedido + " AND idlinea <> " + idLinea + " ORDER BY fechaservicio DESC");
	if (!f) {
		return fLinea;
	}
	if (AQUtil.daysTo(f, fLinea) > 0) {
		f = fLinea;
	}
	return f;
}


function oficial_calculaTotales()
{
	var _i = this.iface;
	var curLP = formRecordlineaspedidoscli.cursor();
	if (!curLP) {
		return;
	}
	var nF = _i.tblPedidos_.numRows();
	_i.canSel = 0;
	var maxFecha = new Date(Date.parse("2000-01-01")), fD;
	for (var f = 0; f < nF; f++) {
		if (_i.tblPedidos_.text(f, _i.cSEL) != "X") {
			continue;
		}
		_i.canSel += parseFloat(_i.tblPedidos_.text(f, _i.cCAN));
		fD = AQUtil.dateDMAtoAMD(_i.tblPedidos_.text(f, _i.cFS1));
		if (AQUtil.daysTo(maxFecha, fD) > 0) {
			maxFecha = fD;
		}
	}
	this.child("lblCanSel").text = sys.translate("Seleccionada %1").arg(_i.canSel);
	if (_i.canSel >= _i.canLinea) {
		this.child("dedServLineaSel").date = maxFecha;
		this.child("dedServPedidoSel").date = _i.dameFechaServicio(curLP.valueBuffer("idpedido"), curLP.valueBuffer("idlinea"), maxFecha);
	} else {
		this.child("dedServLineaSel").date = "";
		this.child("dedServPedidoSel").date = "";
	}
}

function oficial_bufferChanged(fN:String)
{
	switch (fN) {
		case "codejercicio": {
			break;
		}
	}
}

function oficial_poblarTabla()
{
	var _i = this.iface;
	var curLP = formRecordlineaspedidoscli.cursor();
	if (!curLP) {
		return;
	}
	var q = new FLSqlQuery;
	q.setSelect("p.idpedido, p.codigo, p.nombrecliente, p.fecha, p.fechaservicio, lp.idlinea, (lp.cantidad - lp.totalenalbaran), lp.fechaservicio");
	q.setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido");
	//q.setWhere("(lp.cantidad - lp.totalenalbaran) >= " + curLP.valueBuffer("cantidad") + " AND lp.referencia = '" + curLP.valueBuffer("referencia") + "' AND lp.idlinea <> " + curLP.valueBuffer("idlinea") + " AND NOT lp.cerrada");
	q.setWhere("lp.referencia = '" + curLP.valueBuffer("referencia") + "' AND lp.idlinea <> " + curLP.valueBuffer("idlinea") + " AND NOT lp.cerrada");
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	var f = 0;
	while (q.next()) {
		_i.tblPedidos_.insertRows(f);
		_i.tblPedidos_.setText(f, _i.cIDP, q.value("p.idpedido"));
		_i.tblPedidos_.setText(f, _i.cIDL, q.value("lp.idlinea"));
		_i.tblPedidos_.setText(f, _i.cCOD, q.value("p.codigo"));
		_i.tblPedidos_.setText(f, _i.cNOM, q.value("p.nombrecliente"));
		_i.tblPedidos_.setText(f, _i.cCAN, q.value("(lp.cantidad - lp.totalenalbaran)"));
		_i.tblPedidos_.setText(f, _i.cFS1, AQUtil.dateAMDtoDMA(q.value("lp.fechaservicio")));
		_i.tblPedidos_.setText(f, _i.cFP1, AQUtil.dateAMDtoDMA(q.value("p.fechaservicio")));
		f++;                                                      
	}
}

function oficial_generarTabla()
{
	var _i = this.iface;
	var cab = "", s = "*";
	var c = 0;
	cab += sys.translate("IdP");
	cab += s;
	_i.cIDP = c++;
	cab += sys.translate("IdL");
	cab += s;
	_i.cIDL = c++;
	cab += sys.translate("Sel");
	cab += s;
	_i.cSEL = c++;
	cab += sys.translate("Pedido");
	cab += s;
	_i.cCOD = c++;
	cab += sys.translate("Cliente");
	cab += s;
	_i.cNOM = c++;
	cab += sys.translate("Cantidad");
	cab += s;
	_i.cCAN = c++;
	cab += sys.translate("F.Lin.Actual");
	cab += s;
	_i.cFS1 = c++;
	cab += sys.translate("F.Ped.Actual");
	cab += s;
	_i.cFP1 = c++;
	cab += sys.translate("F.Lin.Nueva");
	cab += s;
	_i.cFS2 = c++;
	cab += sys.translate("F.Ped.Nueva");
	cab += s;
	_i.cFP2 = c++;

	_i.tblPedidos_.setNumCols(c);
	_i.tblPedidos_.hideColumn(_i.cIDP);
	_i.tblPedidos_.hideColumn(_i.cIDL);
	_i.tblPedidos_.hideColumn(_i.cSEL);
	_i.tblPedidos_.setColumnWidth(_i.cSEL, 30);
	_i.tblPedidos_.setColumnWidth(_i.cCOD, 100);
	_i.tblPedidos_.setColumnWidth(_i.cNOM, 200);
	_i.tblPedidos_.setColumnWidth(_i.cCAN, 80);
	_i.tblPedidos_.setColumnWidth(_i.cFS1, 90);
	_i.tblPedidos_.setColumnWidth(_i.cFS2, 90);
	_i.tblPedidos_.setColumnWidth(_i.cFP1, 90);
	_i.tblPedidos_.setColumnWidth(_i.cFP2, 90);
	_i.tblPedidos_.setColumnLabels(s, cab);
}

function oficial_coloreaFila(f, clr)
{
	var _i = this.iface;
	var nC = _i.tblPedidos_.numCols();
	for (var c = 0; c < nC; c++) {
		_i.tblPedidos_.setCellBackgroundColor(f, c, clr);
		_i.tblPedidos_.setText(f, c,_i.tblPedidos_.text(f, c));
		//_i.tblPedidos_.adjustColumn(c);
	}
}

function oficial_colores()
{
	var _i = this.iface;
	
	_i.cNoSel_ = new Color("white");
	_i.cSel_ = new Color("green");
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	if (!_i.validarForm()) {
		return;
	}
	if (!_i.cambiaFechas()) {
		return false;
	}
	var cursor = this.cursor();
	var fS = this.child("dedServLineaSel").date;
	cursor.setValueBuffer("fechaservicio", fS);
	this.accept();
}

function oficial_validarForm()
{
	var _i = this.iface;
	if (_i.canLinea < _i.canSel) {
		MessageBox.warning(sys.translate("scripts", "La cantidad total seleccionada en las l�neas debe ser mayor o igual que la cantidad de la l�nea de pedido"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function oficial_cambiaFechas()
{
	var _i = this.iface;
	var nF = _i.tblPedidos_.numRows();
	var fD, idPedido, idLinea;
	var curP = new FLSqlCursor("pedidoscli");
	var curLP = new FLSqlCursor("lineaspedidoscli");
	for (var f = 0; f < nF; f++) {
		if (_i.tblPedidos_.text(f, _i.cSEL) != "X") {
			continue;
		}
		fD = AQUtil.dateDMAtoAMD(_i.tblPedidos_.text(f, _i.cFS2));
		idPedido = _i.tblPedidos_.text(f, _i.cIDP);
		idLinea = _i.tblPedidos_.text(f, _i.cIDL);
		curLP.select("idlinea = " + idLinea);
		if (!curLP.first()) {
			return false;
		}
		curLP.setModeAccess(curLP.Edit);
		curLP.refreshBuffer();
		curLP.setValueBuffer("fechaservicio", fD);
		if (!curLP.commitBuffer()) {
			return false;
		}
		curP.select("idpedido = " + idPedido);
		if (!curP.first()) {
			return false;
		}
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		curP.setValueBuffer("fechaservicio", formpedidoscli.iface.pub_commonCalculateField("fechaservicio", curP));
		if (!curP.commitBuffer()) {
			return false;
		}
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
