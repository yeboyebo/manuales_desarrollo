var form = this;
/***************************************************************************
         em_dropshipping.qs  -  description
                             -------------------
    begin                : lun ene 09 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna { 
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblPedidos_, tblClientes_, tblLineas_;
	var curOrden_;
	var lineaColaActual_;
	var timerId;
	var activado_;
	var intervalo_;
	var filaVacia_;
	var cMAQD_,cMCD_,cFID_,cFFD_,cMAQH_,cMCH_,cFEME_,cFEMY_;
	var enviables_;
	var noEnviablesAF_;
	var noEnviablesPR_;
	var enviados_;
	var linEnviables_ = [];
	var linNoEnviablesAF_;
	var linNoEnviablesPR_;
	var linEnviados_;
	var aCamposPedidosV_, aColsPedidosV_, aTiposPedidosV_;
	var aCamposClientesV_, aColsClientesV_, aTiposClientesV_;
	var utf8_;
    function oficial( context ) { interna( context ); }
    function iniciaTablas() {
		return this.ctx.oficial_iniciaTablas();
	}
	function formateaTblPedidos(f, c, v) {
		return this.ctx.oficial_formateaTblPedidos(f, c, v);
	}
	function formateaTblLineas(f, c, v) {
		return this.ctx.oficial_formateaTblLineas(f, c, v)
	}
	function listaOrdenesLineas(f, c, v) {
		return this.ctx.oficial_listaOrdenesLineas(f, c, v);		
	}
	function dimeProgramado(f, c, v) {
		return this.ctx.oficial_dimeProgramado(f, c, v);
	}
	function listaOrdenes(f, c, v) {
		return this.ctx.oficial_listaOrdenes(f, c, v);		
	}
	function tblClientes_clicked(f, c) {
		return this.ctx.oficial_tblClientes_clicked(f, c);
	}
	function tblClientes_currentChanged(f,c) {
		return this.ctx.oficial_tblClientes_currentChanged(f,c);
	}
	function colorLineas(f,c){
		return this.ctx.oficial_colorLineas(f,c);
	}
	function colorClientes(f,c){
		return this.ctx.oficial_colorClientes(f,c);
	}	
	function toolButtomInsert_clicked() {
		return this.ctx.oficial_toolButtomInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.oficial_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.oficial_toolButtonDelete_clicked();
	}
	function borraEnvio(oParam) {
		return this.ctx.oficial_borraEnvio(oParam);
	}
	function toolButtonZoom_clicked() {
		return this.ctx.oficial_toolButtonZoom_clicked();
	}
	function dameColor(fN, fV, cursor, fT, sel){
		return this.ctx.oficial_dameColor(fN, fV, cursor, fT, sel);
	}
	function pbnCargaPedidos_clicked() {
		return this.ctx.oficial_pbnCargaPedidos_clicked();
	}
	function dameColorCarga(fN, fV, cursor, fT, sel) {
		return this.ctx.oficial_dameColorCarga(fN, fV, cursor, fT, sel);
	}
	function totalizaCarga(cursor) {
		return this.ctx.oficial_totalizaCarga(cursor);
	}
	function cargaPedidos(oParam) {
		return this.ctx.oficial_cargaPedidos(oParam);
	}
	function pbnGenerarPedidos_clicked() {
		return this.ctx.oficial_pbnGenerarPedidos_clicked();
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function filtraAlbaranes() {
		return this.ctx.oficial_filtraAlbaranes();
	}
	function dameFiltroAlbaranes() {
		return this.ctx.oficial_dameFiltroAlbaranes();
	}
	function generarPedidos(oParam) {
		return this.ctx.oficial_generarPedidos(oParam);
	}
	function iniciaTablaClientes() {
		return this.ctx.oficial_iniciaTablaClientes();
	}
	function iniciaTablaPedidos() {
		return this.ctx.oficial_iniciaTablaPedidos();
	}
	function deshabilitarPorPedido()  {
		return this.ctx.oficial_deshabilitarPorPedido();
	}
	function deshabilitarBotones() {
		return this.ctx.oficial_deshabilitarBotones();
	}
	function tbnAsociarAlbaranes_clicked() {
		return this.ctx.oficial_tbnAsociarAlbaranes_clicked();
	}
	function tbnQuitarAlbaranes_clicked() {
		return this.ctx.oficial_tbnQuitarAlbaranes_clicked();
	}
	function tbnTodosAlbSel_clicked() {
		return this.ctx.oficial_tbnTodosAlbSel_clicked();
	}
	function tbnNingunAlbSel_clicked() {
		return this.ctx.oficial_tbnNingunAlbSel_clicked();
	}
	function pbnCambiarDesc_clicked(){
		return this.ctx.oficial_pbnCambiarDesc_clicked();
	}
	function imprimirCSV(){
		return this.ctx.oficial_imprimirCSV();
	}
	function imprimirEnvio(){
		return this.ctx.oficial_imprimirEnvio();
	}
	function dameParamEnvioDropShipping(codigo){
		return this.ctx.oficial_dameParamEnvioDropShipping(codigo);
	}
	function filtrarClientes() {
		return this.ctx.oficial_filtrarClientes();
	}
	function iniciaValoresArrays() {
		return this.ctx.oficial_iniciaValoresArrays();
	}
	function dameFiltroClientes() {
		return this.ctx.oficial_dameFiltroClientes();
	}
	function dameOrderByClientes() {
		return this.ctx.oficial_dameOrderByClientes();
	}
	function dameGroupByClientes() {
		return this.ctx.oficial_dameGroupByClientes();
	}
	function dameFiltroNoEnviablesAF() {
		return this.ctx.oficial_dameFiltroNoEnviablesAF();
	}
	function dameFiltroNoEnviablesPR() {
		return this.ctx.oficial_dameFiltroNoEnviablesPR();
	}
	function dameFiltroEnviables() {
		return this.ctx.oficial_dameFiltroEnviables();
	}
	function dameFiltroEnviados() {
		return this.ctx.oficial_dameFiltroEnviados();
	}
	function iniciaTablaLineas() {
		return this.ctx.oficial_iniciaTablaLineas();
	}
	function tbnExcelResumen_clicked() {
		return this.ctx.oficial_tbnExcelResumen_clicked();
	}
	function tbnExcelClientes_clicked() {
		return this.ctx.oficial_tbnExcelClientes_clicked();
	}
	function tbnExcelLineas_clicked() {
		return this.ctx.oficial_tbnExcelLineas_clicked();
	}
	function dameParamExcelResumen() {
		return this.ctx.oficial_dameParamExcelResumen();
	}
	function dameParamExcelClientes() {
		return this.ctx.oficial_dameParamExcelClientes();
	}
	function dameParamExcelLineas() {
		return this.ctx.oficial_dameParamExcelLineas();
	}
	function tblClientes_doubleClicked(f, c) {
		return this.ctx.oficial_tblClientes_doubleClicked(f, c);
	}
	function rellenaComboClientes() {
		return this.ctx.oficial_rellenaComboClientes();
	}
	function cbCampoClientes_activated(){
		return this.ctx.oficial_cbCampoClientes_activated();
	}
	function leCampoClientes_returnPressed() {
		return this.ctx.oficial_leCampoClientes_returnPressed();
	}
	function rellenaComboPedidos() {
		return this.ctx.oficial_rellenaComboPedidos();
	}
	function cbCampoPedidos_activated(){
		return this.ctx.oficial_cbCampoPedidos_activated();
	}
	function leCampoPedidos_returnPressed() {
		return this.ctx.oficial_leCampoPedidos_returnPressed();
	}
	function rellenaCombos() {
		return this.ctx.oficial_rellenaCombos();
	}
	function tbnHojaCompleta_clicked() {
		return this.ctx.oficial_tbnHojaCompleta_clicked();
	}
	function tbnImprimirPedido_clicked() {
		return this.ctx.oficial_tbnImprimirPedido_clicked();
	}
	function tbnEtiqueta_clicked() {
		return this.ctx.oficial_tbnEtiqueta_clicked();
	}
	/*function replace(str, searchValue, newValue) {
		return this.ctx.oficial_replace(str, searchValue, newValue);
	}
	function formateaCadena(sCadena) {
		return this.ctx.oficial_formateaCadena(sCadena);
	}*/
	function compruebaUTF8(cadena) 	 {
		return this.ctx.oficial_compruebaUTF8(cadena);
	}
	function imprimirCSVNoEnviadas(){
		return this.ctx.oficial_imprimirCSVNoEnviadas();
	}
	function exportarCSV(tipo, todas){
		return this.ctx.oficial_exportarCSV(tipo, todas);
	}
	function dameQueryExportar(cursor, curEnvio, tipo, todas){
		return this.ctx.oficial_dameQueryExportar(cursor, curEnvio, tipo, todas);
	}
	function calculateCounter() {
		return this.ctx.oficial_calculateCounter();
	}
	function dameAlmacenPedido(codCliente) {
		return this.ctx.oficial_dameAlmacenPedido(codCliente);
	}
	function calcularTotales() {
		return this.ctx.oficial_calcularTotales();
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}
const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.iniciaTablas();

	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("tblClientes"), "clicked(int, int)", _i, "tblClientes_clicked");
	connect (this.child("tblClientes"), "currentChanged(int, int)", _i, "tblClientes_currentChanged");
	connect (this.child("tdbEnvios"), "currentChanged()", _i, "filtraAlbaranes");
	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	connect(this.child("pbnCargaPedidos"), "clicked()", _i, "pbnCargaPedidos_clicked");
	connect(this.child("pbnGenerarPedidos"), "clicked()", _i, "pbnGenerarPedidos_clicked");	
	connect(this.child("tbnAsociarAlbaranes"), "clicked()", _i, "tbnAsociarAlbaranes_clicked");
	connect(this.child("tbnQuitarAlbaranes"), "clicked()", _i, "tbnQuitarAlbaranes_clicked");
	connect(this.child("tbnTodosAlbSel"), "clicked()", _i, "tbnTodosAlbSel_clicked");
	connect(this.child("tbnNingunAlbSel"), "clicked()", _i, "tbnNingunAlbSel_clicked");
	connect(this.child("pbnCambiarDesc"), "clicked()", _i, "pbnCambiarDesc_clicked");
	connect(this.child("toolButtonPrint"), "clicked()", _i, "imprimirEnvio");
	connect(this.child("toolButtonCSV"), "clicked()", _i, "imprimirCSV");
	connect(this.child("toolButtonCSVNoEnviadas"), "clicked()", _i, "imprimirCSVNoEnviadas");


	connect(this.child("tdbEnvios").cursor(), "bufferCommited()", _i, "calcularTotales");



	//cursor.setValueBuffer("mostraralbaranes", "Todos");
	
	this.child("tdbAlbaranes").cursor().setMainFilter("deabono is true AND em_coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	this.child("tdbAlbaranesCli").cursor().setMainFilter("deabono is false AND em_coddropshipping = '" + cursor.valueBuffer("codigo") + "'");

	connect(this.child("chkNoEnviablesAF"), "clicked()", _i, "filtrarClientes");
	connect(this.child("chkNoEnviablesPR"), "clicked()", _i, "filtrarClientes");
	connect(this.child("chkEnviables"), "clicked()", _i, "filtrarClientes");
	connect(this.child("chkEnviados"), "clicked()", _i, "filtrarClientes");

	connect(this.child("tbnExcelResumen"), "clicked()", _i, "tbnExcelResumen_clicked");
	connect(this.child("tbnExcelClientes"), "clicked()", _i, "tbnExcelClientes_clicked");
	connect(this.child("tbnExcelLineas"), "clicked()", _i, "tbnExcelLineas_clicked");
	connect(this.child("tblClientes"), "doubleClicked(int, int)", _i, "tblClientes_doubleClicked");

	connect(this.child("cbCampoPedidos"), "activated(QString)", _i, "cbCampoPedidos_activated");
	connect(this.child("leCampoPedidos"), "returnPressed()", _i, "leCampoPedidos_returnPressed");
	connect(this.child("cbCampoClientes"), "activated(QString)", _i, "cbCampoClientes_activated");
	connect(this.child("leCampoClientes"), "returnPressed()", _i, "leCampoClientes_returnPressed");

	connect(this.child("tbnHojaCompleta"), "clicked()", _i, "tbnHojaCompleta_clicked");
	connect(this.child("tbnImprimirPedido"), "clicked()", _i, "tbnImprimirPedido_clicked");
	connect(this.child("tbnEtiqueta"), "clicked()", _i, "tbnEtiqueta_clicked");
	connect(this.child("cbMostrarAlbaranes"), "activated(QString)", _i, "filtraAlbaranes");

	_i.rellenaCombos();
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_rellenaCombos()
{
	var _i = this.iface;
	_i.rellenaComboPedidos();
	_i.rellenaComboClientes();
}

function oficial_tblClientes_doubleClicked(f, c)
{
	var _i = this.iface;
	var idPedido = _i.tblClientes_.cellValue(f, "em_cargadropshipping.idpedido");

    if (!idPedido) {
		return false;
    }
    var curPedido = new FLSqlCursor("pedidoscli");
    curPedido.select("idpedido = " + idPedido);
    if (!curPedido.first()) {
		return false;
    }   
   curPedido.editRecord();   
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();

	switch (fN) {
		case "mostraralbaranes": {
			_i.filtraAlbaranes();
			break;
		}
	}
}

function oficial_filtraAlbaranes()
{
	var _i = this.iface;
	
	var f = _i.dameFiltroAlbaranes();
	this.child("tdbAlbaranesCli").cursor().setMainFilter(f);
	this.child("tdbAlbaranesCli").refresh();
}

function oficial_dameFiltroAlbaranes()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var curE = this.child("tdbEnvios").cursor();
	var codEnvio = curE.valueBuffer("emcodenviodrop");
	if (!codEnvio || codEnvio == "") {
		codEnvio = false;
	}

	var f = "";
	//var mA = cursor.valueBuffer("mostraralbaranes");
	var mA = this.child("cbMostrarAlbaranes").currentText;
	if (mA == "Asociados al envio") {
		//debug("codenvio = " + codEnvio);
		if (codEnvio) {
			f = "emcodenviodrop = '" + codEnvio + "'";
		} else {
			f = "1 = 2";
		}
	} else if (mA == "No enviados") {
		f = "emcodenviodrop IS NULL";
	}
	return f;
}

function oficial_pbnGenerarPedidos_clicked()
{
	/* Falta: 
	- Meter en funci�n y transacci�n (ver el otro clicked())
	- Barra de progreso
	- Refrescar y deshabilitar cuando termine correctamente
	*/
	var _i = this.iface;
	var cursor = this.cursor();

	if (AQUtil.sqlSelect("em_cargadropshipping", "id", "coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND refinterna IS NULL")) {
		sys.warnMsgBox(sys.translate("Hay l�neas del fichero sin producto identificado. Debe solucionar este problema antes de continuar"));
		return false;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al generar pedidos.");
	oParam.cursor = cursor;	
	var f = new Function("oParam", "return formRecordem_dropshipping.iface.generarPedidos(oParam)");
	if (!sys.runTransaction(f, oParam)) {									
		return false;
	}
	_i.iniciaValoresArrays();
	_i.iniciaTablaLineas();
	_i.iniciaTablaClientes();
	_i.iniciaTablaPedidos();
	_i.deshabilitarPorPedido();
	this.child("fdbNumeroPedidos").setValue(_i.commonCalculateField("numeropedidos",cursor));
	sys.infoMsgBox(sys.translate("Pedidos generados correctamente, las reservas se realizar�n al aceptar el formulario."));
}

function oficial_generarPedidos(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;

	var codDrop = cursor.valueBuffer("codigo");
	var codCliente = cursor.valueBuffer("codcliente");
	//var codAlmacen = flfactppal.iface.pub_valorDefectoEmpresa("codalmacen"); 
	// #H2114 SPRINT2019 P0065/M2 si el cliente tiene indicado almac�n depostio en su ficha el pedido tendr� ese almacen (solamente generar� reservas de producto) si no lo har� como antes.	
	var codAlmacen = _i.dameAlmacenPedido(codCliente);

	var diasServicio = cursor.valueBuffer("diasservicio");
	var fechaPedidos = cursor.valueBuffer("fechapedidos");
	var fechaSalida = AQUtil.addDays(fechaPedidos, diasServicio);

	var fecha;
	if (cursor.isNull("fechapedidos")) {
		var hoy = new Date;
		fecha = hoy.toString().left(10);
		cursor.setValueBuffer("fechapedidos", fecha);
	} else {
		fecha = cursor.valueBuffer("fechapedidos");
	}

	var codEjercicio = AQUtil.sqlSelect("ejercicios", "codejercicio", "fechainicio <= '" + fecha + "' AND fechafin >= '" + fecha + "'");
	if (!codEjercicio) {
		sys.warnMsgBox(sys.translate("No hay un ejercicio para la fecha %1").arg(AQUtil.dateAMDtoDMA(fecha)));
		return false;
	}

	var qCliente = new FLSqlQuery;
	qCliente.setSelect("nombre, cifnif, coddivisa, codpago, em_codpago, codagente, codgrupoivaneg");
	qCliente.setFrom("clientes");
	qCliente.setWhere("codcliente = '" + codCliente + "'")
	if (!qCliente.exec()) {
		return false;
	}
	if (!qCliente.first()) {
		return false;
	}

	var qArt = new FLSqlQuery;
	qArt.setSelect("codbarras, codarancelario, codtamanoem, codcolorem");
	qArt.setFrom("articulos");
	
	var cddAlmacen = "1";
	var _cFP = formpedidoscli.iface.pub_commonCalculateField;
	var _cFL = formRecordlineaspedidoscli.iface.pub_commonCalculateField;

	var curCarga = new FLSqlCursor("em_cargadropshipping");
	curCarga.select("coddropshipping = '" + codDrop + "' AND em_cargadropshipping.idpedido IS NULL ORDER BY pedidoprivalia");
	var p = 0;
	flfactppal.iface.creaDialogoProgreso(sys.translate("Creando pedidos"), curCarga.size());
	var curP = new FLSqlCursor("pedidoscli");
	var curL = new FLSqlCursor("lineaspedidoscli");
	var codPedidoAnt = false, codPedido, idPedido, numLinea, referencia, pvpUnitario;
	var observaciones = cursor.valueBuffer("descripcion") +" / ";
	while (curCarga.next()) {
		AQUtil.setProgress(++p);
		curCarga.setModeAccess(curCarga.Browse);
		curCarga.refreshBuffer();
		codPedido = curCarga.valueBuffer("pedidoprivalia");
		if (codPedido != codPedidoAnt) {
			if (codPedidoAnt) {
				curP.select("idpedido = " + idPedido);
				if (!curP.first()) {
					AQUtil.destroyProgressDialog();
					return false;
				}
				curP.setModeAccess(curP.Edit);
				curP.refreshBuffer();
				formpresupuestoscli.iface.curPedido = curP;
				formpresupuestoscli.iface.totalesPedido();
				if (!curP.commitBuffer()) {
					AQUtil.destroyProgressDialog();
					return false;
				}
			}
			curP.setModeAccess(curP.Insert);
			curP.refreshBuffer();
			curP.setValueBuffer("fecha", cursor.valueBuffer("fechapedidos"));
			curP.setValueBuffer("codcliente", cursor.valueBuffer("codcliente"));
			curP.setValueBuffer("nombrecliente", curCarga.valueBuffer("nombre"));
			curP.setValueBuffer("cifnif", qCliente.value("cifnif"));
			//curP.setValueBuffer("fechasalida", cursor.valueBuffer("fechapedidos"));
			curP.setValueBuffer("fechasalida", fechaSalida);			
			curP.setValueBuffer("fechaservicio", cursor.valueBuffer("fechapedidos"));
			curP.setValueBuffer("coddivisa", qCliente.value("coddivisa"));
			curP.setValueBuffer("codserie", _cFP("codserie", curP));
			curP.setValueBuffer("codpago", qCliente.value("codpago"));
			curP.setValueBuffer("em_codpago", qCliente.value("em_codpago"));
			curP.setValueBuffer("codagente", qCliente.value("codagente"));
			curP.setValueBuffer("codalmacen", codAlmacen);
			curP.setValueBuffer("direccion", curCarga.valueBuffer("direccion"));
			curP.setValueBuffer("codpostal", curCarga.valueBuffer("codpostal"));
			curP.setValueBuffer("ciudad", curCarga.valueBuffer("localidad"));
			curP.setValueBuffer("provincia", curCarga.valueBuffer("provincia"));
			curP.setValueBuffer("codejercicio", codEjercicio);
			curP.setValueBuffer("tasaconv", AQUtil.sqlSelect("divisas", "tasaconv", "coddivisa = '" + curP.valueBuffer("coddivisa") + "'"));
			curP.setValueBuffer("docexterno", cursor.valueBuffer("descripcion"));
			curP.setValueBuffer("codgrupoivaneg", qCliente.value("codgrupoivaneg"));
			curP.setValueBuffer("em_coddropshipping", cursor.valueBuffer("codigo"));
			curP.setValueBuffer("obsinternas", observaciones + curCarga.valueBuffer("pedidoprivalia"));
			idPedido = curP.valueBuffer("idpedido");			

			if (!curP.commitBuffer()) {
				AQUtil.destroyProgressDialog();
				return false;
			}
			numLinea = 1;
			codPedidoAnt = codPedido;
		}
		referencia = curCarga.valueBuffer("refinterna");
		qArt.setWhere("referencia = '" + referencia + "'");
		if (!qArt.exec()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		if (!qArt.first()) {
			debug("!qArt");
			AQUtil.destroyProgressDialog();
			return false;
		}
		pvpUnitario = curCarga.valueBuffer("costeunitario");
		if (isNaN(pvpUnitario) || pvpUnitario == 0) {
			pvpUnitario = curCarga.valueBuffer("importecalculado");
		}
		curL.setModeAccess(curL.Insert);
		curL.refreshBuffer();
		curL.setValueBuffer("idpedido", idPedido);
		curL.setValueBuffer("numlinea", numLinea++);
		curL.setValueBuffer("referencia", referencia);
		curL.setValueBuffer("descripcion", curCarga.valueBuffer("descinterna"));
		curL.setValueBuffer("emcodbarras", qArt.value("codbarras"));
		curL.setValueBuffer("codtamanoem", qArt.value("codtamanoem"));
		curL.setValueBuffer("codcolorem", qArt.value("codcolorem"));

		curL.setValueBuffer("cantidad", curCarga.valueBuffer("unidadespedidas"))
		curL.setValueBuffer("pvpunitario", pvpUnitario);

		formRecordlineaspedidoscli.iface.cargaDatosStock(curL);


		curL.setValueBuffer("pvpsindto", _cFL("pvpsindto", curL));
		curL.setValueBuffer("pvptotal", _cFL("pvptotal", curL));
		curL.setValueBuffer("codimpuesto", _cFL("codimpuesto", curL));
		curL.setValueBuffer("iva", _cFL("iva", curL));
		curL.setValueBuffer("recargo", _cFL("recargo", curL));
		curL.setValueBuffer("diasservicio", _cFL("diasservicio", curL));
		curL.setValueBuffer("fechaservicio", _cFL("fechaservicio", curL));
		if(cursor.valueBuffer("modofabricacion") == "Forzar a faltas"){
			//debug("entra en forazar a faltas");
			curL.setValueBuffer("forzarafaltas", true);
		}
		else if(cursor.valueBuffer("modofabricacion") == "Agotar disponible de existencias (resto a faltas)"){
			//debug("entra agotar exsitencais");
			curL.setValueBuffer("agotarexistencias" , true);
		}
		var idLineaPedido = curL.valueBuffer("idlinea");
		if (!curL.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}

		curCarga.setModeAccess(curCarga.Edit);
		curCarga.refreshBuffer();
		curCarga.setValueBuffer("idlineapedido", idLineaPedido);
		curCarga.setValueBuffer("idpedido",idPedido);
		if (!curCarga.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	if (codPedidoAnt) {
		curP.select("idpedido = " + idPedido);
		if (!curP.first()) {
			return false;
		}
		curP.setModeAccess(curP.Edit);
		curP.refreshBuffer();
		formpresupuestoscli.iface.curPedido = curP;
		formpresupuestoscli.iface.totalesPedido();
		if (!curP.commitBuffer()) {			
			return false;
		}
	}	
	return true;
}


function oficial_deshabilitarPorPedido() 
{
	return true;
}

function oficial_pbnCargaPedidos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbCargaDropshipping").cursor().commitBufferCursorRelation())
			return false;
	}

	var rutaF = FileDialog.getOpenFileName("*.csv", sys.translate("Selecciona el fichero .csv a cargar"));
	if (!rutaF) {
		return false;
	}
	var f = new File(rutaF);
	try {
		f.open(File.ReadOnly);
		if(f.size == 0) {
			sys.infoMsgBox("Fichero vac�o");
			return false;
		}
	} catch(e) {
		MessageBox.warning(sys.translate("Error al abrir el fichero:\n%1").arg(rutaF), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
		
	
	var steps = 0;
	while (!f.eof) {
		f.readLine();
		++steps;
	}

	var sep = cursor.valueBuffer("camposeparador");
	var longLinea = 26;

	f.close();
	f.open(File.ReadOnly);
	var head = f.readLine().split(sep);
	if (head.length != longLinea) {
		MessageBox.warning(sys.translate("El fichero csv %1 no contiene %2 columnas").arg(rutaF).arg(longLinea), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		f.close();
		return false;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al cargar el fichero csv %1.").arg(rutaF);
	oParam.cursor = cursor;
	oParam.f = f;
	oParam.steps = steps;
	oParam.sep = sep;
	oParam.longLinea = longLinea;

	if (!sys.runTransaction(formRecordem_dropshipping.iface.cargaPedidos, oParam)) {
		f.close();
		return false;
	}
	f.close();	
	this.child("tdbCargaDropshipping").refresh();

	_i.iniciaTablas();
	

	sys.infoMsgBox(sys.translate("Fichero cargado correctamente"));
}

function oficial_cargaPedidos(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;
	var f = oParam.f;
	_i.utf8_ = this.child("cbCodificacion").currentText;
	//debug("\n\n\n UTF8: "+_i.utf8_);
	if (!AQUtil.execSql("DELETE FROM em_cargadropshipping WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'")) {
		MessageBox.warning(sys.translate("Error al borrar la carga anterior"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}

	var i = {"pedidoprivalia" : 0, "cliente" : 1, "nombre" : 2, "direccion" : 3, "localidad" : 4, "provincia" : 5, "codpostal" : 6, "telefono1" : 7, "telefono2" : 8, "refstockprivalia" : 9, "ean" : 10, "sku" : 11, "articulo" : 12, "costeunitario" : 13, "costetotal" : 14, "descripcion" : 15, "unidadespedidas" : 16, "unidadesservidas" : 17, "carrier" : 18, "tracking" : 19, "infocarrier1" : 20, "infocarrier2" : 21, "infocarrier3" : 22, "infocarrier4" : 23, "infocarrier5" : 24, "pais" : 25};

	var l = 1;
	var codCliente = cursor.valueBuffer("codcliente");
	var fecha = cursor.valueBuffer("fecha");

	AQUtil.createProgressDialog(sys.translate("Cargando fichero"), oParam.steps);
	var aLinea;
	var curCD = new FLSqlCursor("em_cargadropshipping");
	var refInterna, importeCalculado, ean, estado, descInterna;
	var sLinea = "";
	var qAC = new FLSqlQuery;
	qAC.setSelect("referencia, pvpeuromoda, descripcioncliente");
	qAC.setFrom("em_articuloscli");

	while(!f.eof) {
		AQUtil.setProgress(++l);
		//aLinea = f.readLine().split(oParam.sep);
		sLinea = f.readLine();
		sLinea = sLinea.replace("\n","");
		sLinea = sLinea.replace("\r","");
		if(!sLinea || sLinea == "") {
			continue;
		}
		aLinea = sLinea.split(oParam.sep);

		
		if (!aLinea || aLinea.length != oParam.longLinea) {
			AQUtil.destroyProgressDialog();
			MessageBox.warning(sys.translate("La l�nea %1 del fichero no contiene %2 columnas").arg(l).arg(oParam.longLinea), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		if (aLinea[i["pedidoprivalia"]] == "") { /// Viene una �ltima l�nea solo con separadores
			continue;
		}
		curCD.setModeAccess(curCD.Insert);
		curCD.refreshBuffer();
		curCD.setValueBuffer("coddropshipping", cursor.valueBuffer("codigo"));
		for (col in i) {
			//if (col == "direccion") {	
			//	debug("\ndireccion: "+aLinea[i[col]]);
			//}
			/*if(!_i.utf8_) {
				debug("comprobar utf8: "+_i.compruebaUTF8(aLinea[i[col]]));
				_i.utf8_ = _i.compruebaUTF8(aLinea[i[col]]); 
			}*/
 			//aLinea[i[col]] = flfactppal.iface.formateaCadenaUTF8(aLinea[i[col]]);





			curCD.setValueBuffer(col, aLinea[i[col]].replace("\n",""));
		}		

		refInterna = false;
		importeCalculado = false;
		qAC.setWhere("codcliente = '" + codCliente + "' AND referenciacliente = '" + aLinea[i["sku"]] + "'");
		//debug("qAC: "+qAC.sql());
		if (qAC.exec() && qAC.first()) {
			refInterna = qAC.value("referencia");
			//debug("1 refInterna: "+refInterna);
			importeCalculado = qAC.value("pvpeuromoda");
			descInterna = qAC.value("descripcioncliente");
			if(!descInterna || descInterna == "") {
				ean = aLinea[i["ean"]].left(13);
				descInterna = AQUtil.sqlSelect("articulos", "descripcion", "codbarras = '" + ean + "'");	
			}
		} else {
			ean = aLinea[i["ean"]].left(13);
			//debug("2 ean: "+ean);
			//refInterna = AQUtil.sqlSelect("articulos", "referencia", "codbarras = '" + ean + "'");

			var qRef = new AQSqlQuery;	
			qRef.setSelect("referencia, descripcion");
			qRef.setFrom("articulos");
			qRef.setWhere("codbarras = '" + ean + "'");				
			if (!qRef.exec()){
				return;
			}  
			if(qRef.first())
			{
				refInterna = qRef.value("referencia");
				//debug("3 refInterna: "+refInterna);
				descInterna = qRef.value("descripcion");
			} else {
			    
			    var refCSV = aLinea[i["articulo"]];
			   // debug("4 refCSV: "+refCSV);
			    var esNumero = true;
			    var digito;
			    referencia = "";
			    for (var k=0; k< refCSV.length && esNumero; k++) {
					digito = refCSV.charAt(k);
					if (!isNaN(digito)) {
				    
				    	referencia +=digito.toString();
					} else {
				    	esNumero = false;
					}			
			    }
			    var qRefAC = new AQSqlQuery;	
			    qRefAC.setSelect("referencia, codbarras");
			    qRefAC.setFrom("em_articuloscli");
			    qRefAC.setWhere("codcliente = '" + codCliente + "' AND (referencia = '" + referencia + "' OR referenciacliente = '" + referencia + "' OR codbarras = '" + referencia + "')");	
			   // debug("q2: "+qRefAC.sql());
			    if (!qRefAC.exec()){
					return;
			    }  
			    if(qRefAC.first())
			    {
					ean = qRefAC.value("codbarras");
					refInterna = qRefAC.value("referencia");
					//debug("5 ean: "+ean);
					//debug("6 refInterna: "+refInterna);
					descInterna = qAC.value("descripcioncliente");
					if(!descInterna || descInterna == "") {				   
				    	descInterna = AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + refInterna + "'");	
					}
			    } else {
			    	//debug("7A ean: "+ean);
			    	var qRef = new AQSqlQuery;	
					qRef.setSelect("referencia, descripcion, codbarras");
					qRef.setFrom("articulos");
					qRef.setWhere("referencia = '" + refCSV + "'");				
					//debug("qRef: "+qRef.sql());
					if (!qRef.exec()){
						return;
					}  
					if(qRef.first())
					{
						refInterna = qRef.value("referencia");
						descInterna = qRef.value("descripcion");
						ean = qRef.value("codbarras");
						//debug("7 ean: "+ean);
						//debug("8 refInterna: "+refInterna);
					}
			    }
				
			}	
			//debug("refInterna: "+refInterna);
			if (refInterna) {
				importeCalculado = formRecordlineaspedidoscli.iface.pub_damePrecioArticulo(refInterna, codCliente, fecha);
			}
		}
		if (refInterna) {
			curCD.setValueBuffer("refinterna", refInterna);
			curCD.setValueBuffer("descinterna", descInterna);

			estado = "Precio incorrecto";
		} else {
			//debug("no encontrado");
			estado = "No encontrado";
		}
		/*debug("importeCalculado: "+importeCalculado);
		debug("costeunitario: "+aLinea[i["costeunitario"]]);
		debug("parsefloat(costeunitario): "+parseFloat(aLinea[i["costeunitario"]]));
		debug("puntosxcomas(costeunitario): "+flfactppal.iface.reemplazoPuntosXcomas(aLinea[i["costeunitario"]]));
		debug("parseFloat(puntosxcomas(costeunitario)): "+parseFloat(flfactppal.iface.reemplazoPuntosXcomas(aLinea[i["costeunitario"]])));*/
		if (parseFloat(importeCalculado) && !isNaN(importeCalculado)) {
			curCD.setValueBuffer("importecalculado", importeCalculado);	
			if (importeCalculado == parseFloat(flfactppal.iface.reemplazoPuntosXcomas(aLinea[i["costeunitario"]]))) {
				estado = "OK";
			}
		}
		curCD.setValueBuffer("estado", estado);	

		if (!curCD.commitBuffer()) {
			AQUtil.destroyProgressDialog();
			MessageBox.warning(sys.translate("Error al guardar la l�nea %1").arg(l), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
	}
	if (!_i.totalizaCarga(cursor)) {
		return false;
	}

	//AQUtil.execSql("update em_cargadropshipping set descripcion = convert_to(descripcion, 'latin-1') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	//AQUtil.execSql("update em_cargadropshipping set direccion = convert_from(   convert(   convert_to(direccion, 'utf-8'), 'utf-8', 'ISO-8859-1'), 'ISO-8859-1' ) WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	//AQUtil.execSql("update em_cargadropshipping set descripcion = convert(descripcion, 'UTF8','LATIN1') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	//AQUtil.execSql("update em_cargadropshipping set descripcion = convert_from(descripcion, UTF8) WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'");


	if(_i.utf8_  == "UTF8") {	

		var codificacion = "";
		var plataforma = AQUtil.getOS();
		
		if (plataforma == "WIN32"){
			codificacion = "WIN1252";
		} else {
			codificacion = "LATIN9";
		}



		if(!AQUtil.execSql("update em_cargadropshipping set descripcion = convert_from( convert_to(descripcion, '" + codificacion +"'),'UTF8') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea descripcion"),"warn",this);
			return false;
		}
		
		if(!AQUtil.execSql("update em_cargadropshipping set direccion = convert_from( convert_to(direccion, '" + codificacion +"'),'UTF8') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea direccion"),"warn",this);
			return false;
		}

		
		
		if(!AQUtil.execSql("update em_cargadropshipping set nombre = convert_from( convert_to(nombre, '" + codificacion +"'),'UTF8') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea nombre"),"warn",this);
			//return false;
		}		

		if(!AQUtil.execSql("update em_cargadropshipping set localidad = convert_from( convert_to(localidad, '" + codificacion +"'),'UTF8') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea localidad"),"warn",this);
			return false;
		}

		if(!AQUtil.execSql("update em_cargadropshipping set provincia = convert_from( convert_to(provincia, '" + codificacion +"'),'UTF8') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea provincia"),"warn",this);
			return false;
		}

		if(!AQUtil.execSql("update em_cargadropshipping set infocarrier2 = convert_from( convert_to(infocarrier2, '" + codificacion +"'),'UTF8') WHERE coddropshipping = '" + cursor.valueBuffer("codigo") + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Codificaci�n del fichero err�nea infoc2"),"warn",this);
			return false;
		}

		
		
	}





	//select descripcion, convert_from( convert_to(descripcion, 'LATIN9'),'UTF8') from em_cargadropshipping where coddropshipping = '000002';
//convert('text_in_utf8', 'UTF8', 'LATIN1')
//convert_from('text_in_utf8', 'UTF8')
	
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_compruebaUTF8(cadena) 
{
	//debug("\n\n\n\n")
	var aConv =	["Ñ","ñ" ,"Ç", "�"];

	for (var i = 0; i < aConv.length; i++) {		
		 if(cadena.find(aConv[i])  >= 0 ) {
		 	//debug("cadena: "+cadena);
		 	//debug("aconv: "+aConv[i]);
		 	return true;
		 }
	}
	return false;
}
/*function oficial_formateaCadenaUTF8(sCadena)
{
	var _i = this.iface;


	var aConv =
		[["Ñ","�"],
		["ñ" , "�"],
		["Ç", "�"],
		["ç", "�"],
		["Á", "�"],
		["á", "�"],
		["É", "�"],
		["é", "�"],
		["Í", "�"],
		["í", "�"],
		["Ó", "�"],
		["ó", "�"],
		["Ú", "�"],
		["ú", "�"],
		["À", "�"],
		["�", "�"],
		["È", "�"],
		["�", "�"],
		["Ì", "�"],
		["ì", "�"],
		["Ò", "�"],
		["ò", "�"],
		["Ù", "�"],
		["ù", "�"],
		["Â", "�"],
		["â", "�"],
		["Ê", "�"],
		["ê", "�"],
		["Î", "�"],
		["î", "�"],
		["Ô", "�"],
		//["ô", "�"],
		["Û", "�"],
		["û", "�"],
		["Ä", "�"],
		//["ä", "�"],
		["Ë", "�"],
		["ë", "�"],
		["Ï", "�"],
		["ï", "�"],
		["Ö", "�"],
		["ö", "�"],
		["Ü", "�"],
		//["ü", "�"]
		];

	for (var i = 0; i < aConv.length; i++) {
		//debug("\n\naConv0: "+aConv[i][0]);
		//debug("aConv1: "+aConv[i][1]);
		//debug("sCadena: "+sCadena);
		//debug("i: "+i);
		sCadena = _i.replace(sCadena, aConv[i][0], aConv[i][1]);
		//debug("cadenades: "+sCadena);
	}	

	//var conv = {, "ñ" : "�", "Ç" : "�", "ç" : "�", "Á" : "�", "á" : "�", "É" : "�", "é" : "�", "Í" : "�", "í" : "�", "Ó" : "�", "ó" : "�", "Ú" : "�", "ú" : "�", "À" : "�", "�" : "�", "È" : "�", "�" : "�", "Ì" : "�", "ì" : "�", "Ò" : "�", "ò" : "�", "Ù" : "�", "ù" : "�", "Â" : "�","â" : "�", "Ê" : "�", "ê" : "�", "Î" : "�", "î" : "�", "Ô" : "�", "ô" : "�", "Û" : "�", "û" : "�", "Ä" : "�", "ä" : "�", "Ë" : "�", "ë" : "�", "Ï" : "�", "ï" : "�", "Ö" : "�", "ö" : "�", "Ü" : "�", "ü": "�" }

	//for (col in conv) {
	//	debug("\n\n col: "+col);
	//	debug("conv[col]: "+conv[col]);
	//	sCadena = _i.replace(sCadena, col, conv[col]);
	//}	

	return sCadena;
}*/

/*function oficial_replace(str, searchValue, newValue)
{
	var regExp = new RegExp(searchValue);
	regExp.global = true;

	return str.replace(regExp, newValue);
}*/


function oficial_dameColorCarga(fN, fV, cursor, fT, sel)
{
	var color = "";
	switch (fN) {
		default: {
			switch(cursor.valueBuffer("estado")) {
				case "OK": {
					color = flfactppal.iface.pub_dameColor("fondo_verde");
					break;
				}
				case "Precio incorrecto": {
					color = flfactppal.iface.pub_dameColor("fondo_naranja");
					break;
				}
				case "No encontrado": {
					color = flfactppal.iface.pub_dameColor("fondo_rojo");
					break;
				}
			}
		}
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}
function oficial_formateaTblLineas(f, c, v)
{
	var _i = this.iface;
	var nombreCol = _i.tblLineas_.nombreCol(c)
	switch(nombreCol) {
		case "em_cargadropshipping.listaordenes": {
			return _i.listaOrdenesLineas(f, c, v);
			break;
		} 		
		default: {			
			return _i.tblLineas_.formateaValor(v, c);
		}	
	}
}

function oficial_listaOrdenesLineas(f, c, v)
{
	var _i =  this.iface;
	var cursor = this.cursor();	
	var q = _i.tblLineas_.query();

	var lista = "";

	var idLinea = q.value("lineaspedidoscli.idlinea");

	var qryFabricado = new FLSqlQuery;
	qryFabricado.setSelect("codordenproduccion");
	qryFabricado.setFrom("lineaspedidoscli inner join em_reservaslotepedido ON lineaspedidoscli.idlinea = em_reservaslotepedido.idlineapc INNER JOIN lotesstock ON em_reservaslotepedido.codlote = lotesstock.codlote");
	qryFabricado.setWhere("lineaspedidoscli.idlinea = " + idLinea + " GROUP BY codordenproduccion");

	if(!qryFabricado.exec()){
		return false;
	}
	while(qryFabricado.next()){
		if(lista == ""){
			lista = qryFabricado.value(0);
		}
		else{
			lista += "," + qryFabricado.value(0);
		}
	} 
	return lista;
}

function oficial_formateaTblPedidos(f, c, v)
{
	var _i = this.iface;
	var nombreCol = _i.tblPedidos_.nombreCol(c)
	switch(nombreCol) {
		case "em_cargadropshipping.programado" : {
			return _i.dimeProgramado(f, c, v);		
			break;
		}
		case "em_cargadropshipping.listaordenes": {
			return _i.listaOrdenes(f, c, v);
			break;
		} 
		default: {			
			return _i.tblPedidos_.formateaValor(v, c);
		}	
	}
}

function oficial_dimeProgramado(f, c, v)
{
	var _i =  this.iface;
	var cursor = this.cursor();
	var aLineas = [];
	var q = _i.tblPedidos_.query();

	var cantidad = 0;
	
	var codDropshipping = cursor.valueBuffer("codigo");
	var referencia = q.value("em_cargadropshipping.refinterna");

	var qLin = new AQSqlQuery;	
	qLin.setSelect("lineaspedidoscli.idlinea");
	qLin.setFrom("pedidoscli INNER JOIN lineaspedidoscli ON pedidoscli.idpedido = lineaspedidoscli.idpedido INNER JOIN em_cargadropshipping ON em_cargadropshipping.coddropshipping = pedidoscli.em_coddropshipping AND  em_cargadropshipping.idlineapedido = lineaspedidoscli.idlinea");
	qLin.setWhere("em_cargadropshipping.coddropshipping = '" + codDropshipping + "' and lineaspedidoscli.referencia = '" + referencia + "'"); 			

	//debug("qLin: "+qLin.sql());
	if (!qLin.exec()){
		return;
	}  
	while(qLin.next())
	{
		aLineas.push(qLin.value("lineaspedidoscli.idlinea"));
	}

	if(aLineas.length == 0) {
		return 0;
	}

	var listaLineas = aLineas.join(",");



	var qryFabricado = new FLSqlQuery;
	qryFabricado.setSelect("SUM(cantidad)");
	qryFabricado.setFrom("em_reservaslotepedido");
	qryFabricado.setWhere("idlineapc IN (" + listaLineas +")");

	if(!qryFabricado.exec()){
		return false;
	}
	if(qryFabricado.first()){
		cantidad = qryFabricado.value(0);
	} 
	return cantidad;	
}

function oficial_listaOrdenes(f, c, v)
{
	var _i =  this.iface;
	var cursor = this.cursor();
	var aLineas = [];
	var q = _i.tblPedidos_.query();

	var lista = "";


	var codDropshipping = cursor.valueBuffer("codigo");
	var referencia = q.value("em_cargadropshipping.refinterna");

	var qLin = new AQSqlQuery;	
	qLin.setSelect("lineaspedidoscli.idlinea");
	qLin.setFrom("pedidoscli INNER JOIN lineaspedidoscli ON pedidoscli.idpedido = lineaspedidoscli.idpedido INNER JOIN em_cargadropshipping ON em_cargadropshipping.coddropshipping = pedidoscli.em_coddropshipping AND  em_cargadropshipping.idlineapedido = lineaspedidoscli.idlinea");
	qLin.setWhere("em_cargadropshipping.coddropshipping = '" + codDropshipping + "' and lineaspedidoscli.referencia = '" + referencia + "'"); 			

	//debug("qLin: "+qLin.sql());
	if (!qLin.exec()){
		return;
	}  
	while(qLin.next())
	{
		aLineas.push(qLin.value("lineaspedidoscli.idlinea"));
	}	

	if(aLineas.length == 0) {
		return "";
	}

	var listaLineas = aLineas.join(",");


	var qryFabricado = new FLSqlQuery;
	qryFabricado.setSelect("codordenproduccion");
	qryFabricado.setFrom("lineaspedidoscli inner join em_reservaslotepedido ON lineaspedidoscli.idlinea = em_reservaslotepedido.idlineapc INNER JOIN lotesstock ON em_reservaslotepedido.codlote = lotesstock.codlote");
	qryFabricado.setWhere("lineaspedidoscli.idlinea IN (" + listaLineas +") GROUP BY codordenproduccion");

	if(!qryFabricado.exec()){
		return false;
	}
	while(qryFabricado.next()){
		if(lista == ""){
			lista = qryFabricado.value(0);
		}
		else{
			lista += "," + qryFabricado.value(0);
		}
	} 
	return lista;
}

/*function oficial_obsAcabado(f, c, v, q)
{
	var _i = this.iface;
	var valor = "";	
	var obsAcabado = q.value("em_ordenesestampacion.observacabado");
	if(obsAcabado && obsAcabado != "") {
		valor = "X";
	} else {
		valor = "";
	}
	return valor;
}

function oficial_formateaConfirmado(f, c, v)
{
	var _i = this.iface;
	var nombreCol = _i.tblConfirmado_.nombreCol(c)
	switch(nombreCol) {
		case "em_ordenesestampacion.descripcion" : {
			return _i.descripcionConfirmado(f, c, v);		
			break;
		}
		case "em_ordenesestampacion.enespera": {
			var q = _i.tblConfirmado_.query();
			return _i.enEspera(f, c, v, q);
			break;
		} 
		case "em_ordenesestampacion.observacabado": {
			var q = _i.tblConfirmado_.query();
			return _i.obsAcabado(f, c, v, q);
			break;
		}	
		default: {			
			return _i.tblConfirmado_.formateaValor(v, c);
		}	
	}
}

function oficial_descripcionConfirmado(f, c, v)
{
			
	var _i = this.iface;
	var q = _i.tblConfirmado_.query();
	var fecha = q.value("em_ordenesestampacion.fecha");	
	var fechaEntrega = q.value("em_ordenesestampacion.fechaentrega");
	var descripcion = q.value("em_ordenesestampacion.descripcion");	
	var valor = "";

	if(fecha && fecha !="") {
		fecha = fecha.toString().left(10);
		valor = fecha.toString().right(2)+"/"+fecha.toString().right(5).left(2)+" ";
	}
	valor += descripcion+" ";
	if(fechaEntrega && fechaEntrega !="") {
		fechaEntrega = fechaEntrega.toString().left(10);
		valor += fechaEntrega.toString().right(2)+"/"+fechaEntrega.toString().right(5).left(2);
	}

	return valor;	
}

function oficial_formateaCola(f, c, v)
{
	var _i = this.iface;
	var nombreCol = _i.tblCola_.nombreCol(c)
	switch(nombreCol) {
		case "em_ordenesestampacion.descripcion" : {
			return _i.descripcionCola(f, c, v);		
			break;	
		}
		case "em_ordenesestampacion.enespera": {
			var q = _i.tblCola_.query();
			return _i.enEspera(f, c, v, q);
			break;
		} 
		case "em_ordenesestampacion.observacabado": {
			var q = _i.tblCola_.query();
			return _i.obsAcabado(f, c, v, q);
			break;
		}	
		default: {			
			return _i.tblCola_.formateaValor(v, c);
		}	
	}
}

function oficial_descripcionCola(f, c, v)
{
			
	var _i = this.iface;
	var q = _i.tblCola_.query();
	var fecha = q.value("em_ordenesestampacion.fecha");	
	var fechaEntrega = q.value("em_ordenesestampacion.fechaentrega");
	var descripcion = q.value("em_ordenesestampacion.descripcion");	
	var valor = "";

	if(fecha && fecha !="") {
		fecha = fecha.toString().left(10);
		valor = fecha.toString().right(2)+"/"+fecha.toString().right(5).left(2)+" ";
	}
	valor += descripcion+" ";
	if(fechaEntrega && fechaEntrega !="") {
		fechaEntrega = fechaEntrega.toString().left(10);
		valor += fechaEntrega.toString().right(2)+"/"+fechaEntrega.toString().right(5).left(2);
	}

	return valor;	
}*/

function oficial_iniciaTablas()
{
	var _i = this.iface;	
	_i.iniciaValoresArrays();
	_i.iniciaTablaLineas();
	_i.iniciaTablaPedidos();
	_i.iniciaTablaClientes();
	
}

function oficial_iniciaValoresArrays() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.enviables_ = [];
	_i.noEnviablesAF_ = [];
	_i.noEnviablesPR_ = [];
	_i.enviados_ = [];
	_i.linNoEnviablesAF_ = [];
	_i.linNoEnviablesPR_ = [];
	_i.linEnviados_ = [];
	_i.linEnviables_ = [];

	var aFaltas =false;
	var pteRecibir =false;
	var enviado =false;
	var enviable =false;
	var idPedidoAnt = false;

	var q = new AQSqlQuery;	
	q.setSelect("movistock.reservaex, movistock.reservaaf, movistock.reservapr,lineaspedidoscli.totalenalbaran, lineaspedidoscli.idpedido, lineaspedidoscli.idlinea");
	q.setFrom("pedidoscli inner join lineaspedidoscli on pedidoscli.idpedido = lineaspedidoscli.idpedido left outer join movistock on lineaspedidoscli.idlinea = movistock.idlineapc");
	q.setWhere("pedidoscli.em_coddropshipping = '" + cursor.valueBuffer("codigo") + "' order by pedidoscli.idpedido"); 				
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		
		var totalEnAlbaran = q.value("lineaspedidoscli.totalenalbaran");
		var reservaEx = q.value("movistock.reservaex");
		var reservaAFaltas = q.value("movistock.reservaaf");
		var reservasPte = q.value("movistock.reservapr");
		var idLinea = q.value("lineaspedidoscli.idlinea");
		var idPedido = q.value("lineaspedidoscli.idpedido");

		if (idPedido != idPedidoAnt) {
			if (idPedidoAnt) {
				if(aFaltas) {
					_i.noEnviablesAF_.push(idPedidoAnt);
				} else if(pteRecibir) {
					_i.noEnviablesPR_.push(idPedidoAnt);
				} else if(enviable) {
					_i.enviables_.push(idPedidoAnt);
				} else {
					_i.enviados_.push(idPedidoAnt);
				}				
				aFaltas =false;
				pteRecibir =false;
				enviado =false;
				enviable =false;		
			}
		}

		if(reservaAFaltas && reservaAFaltas > 0) {			
			aFaltas = true;
			_i.linNoEnviablesAF_.push(idLinea);
		} else if(reservasPte && reservasPte >0) {
			pteRecibir = true;		
			_i.linNoEnviablesPR_.push(idLinea);
		} else if(totalEnAlbaran && totalEnAlbaran >0) {	
			enviado = true;
			_i.linEnviados_.push(idLinea);
		} else {
			enviable = true;			
			_i.linEnviables_.push(idLinea);
		}
		idPedidoAnt = idPedido;

	}
	if (idPedidoAnt) {
		if(aFaltas) {
			_i.noEnviablesAF_.push(idPedidoAnt);
		} else if(pteRecibir) {
			_i.noEnviablesPR_.push(idPedidoAnt);
		} else if(enviable) {
			_i.enviables_.push(idPedidoAnt);
		} else {
			_i.enviados_.push(idPedidoAnt);
		}
	}


}

function oficial_iniciaTablaPedidos()
{


	var _i = this.iface;
	var cursor = this.cursor()
	_i.tblPedidos_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblPedidos"));
	
	/*_i.tblPteConfirmar_.setColorFunction("formem_colaestampacion.iface.colorPendiente");*/
	_i.tblPedidos_.setFormatFunction("formRecordem_dropshipping.iface.formateaTblPedidos");
	var q = new AQSqlQuery;	

	//q.setSelect("lineaspedidoscli.referencia,em_cargadropshipping.sku,lineaspedidoscli.descripcion,em_cargadropshipping.descripcion,SUM(lineaspedidoscli.cantidad) AS \"Cantidad\",stocks.disponible,em_cargadropshipping.programado,em_cargadropshipping.listaordenes,familias.descripcion, subfamilias.descripcion, em_dibujos.descripcion, em_tamanos.codtamanoem, em_colores.descripcion");
	q.setSelect("em_cargadropshipping.refinterna,em_cargadropshipping.sku,em_cargadropshipping.descinterna,em_cargadropshipping.descripcion,SUM(em_cargadropshipping.unidadespedidas) AS \"Cantidad\",stocks.disponible,em_cargadropshipping.programado,em_cargadropshipping.listaordenes,familias.descripcion, subfamilias.descripcion, em_dibujos.descripcion, em_tamanos.codtamanoem, em_colores.descripcion");
	//q.setFrom("pedidoscli INNER JOIN lineaspedidoscli ON pedidoscli.idpedido = lineaspedidoscli.idpedido INNER JOIN stocks ON lineaspedidoscli.referencia = stocks.referencia AND stocks.codalmacen = '1' INNER JOIN em_cargadropshipping ON em_cargadropshipping.coddropshipping = pedidoscli.em_coddropshipping AND  em_cargadropshipping.idlineapedido = lineaspedidoscli.idlinea INNER JOIN articulos ON articulos.referencia = lineaspedidoscli.referencia INNER JOIN familias ON familias.codfamilia = articulos.codfamilia INNER JOIN subfamilias ON articulos.codsubfamilia = subfamilias.codsubfamilia LEFT OUTER JOIN em_dibujos ON (articulos.coddibestamp = em_dibujos.coddibujoem OR articulos.coddibjacquard = em_dibujos.coddibujoem) LEFT OUTER JOIN em_colores ON articulos.codcolorem = em_colores.codcolorem LEFT OUTER JOIN em_tamanos ON articulos.codtamanoem = em_tamanos.codtamanoem LEFT OUTER JOIN em_reservaslotepedido ON em_cargadropshipping.idlineapedido = em_reservaslotepedido.idlineapc");
	
	q.setFrom("em_cargadropshipping INNER JOIN articulos ON articulos.referencia = em_cargadropshipping.refinterna INNER JOIN familias ON familias.codfamilia = articulos.codfamilia INNER JOIN subfamilias ON articulos.codsubfamilia = subfamilias.codsubfamilia INNER JOIN stocks ON articulos.referencia = stocks.referencia AND stocks.codalmacen = '1' LEFT OUTER JOIN em_dibujos ON (articulos.coddibestamp = em_dibujos.coddibujoem OR articulos.coddibjacquard = em_dibujos.coddibujoem) LEFT OUTER JOIN em_colores ON articulos.codcolorem = em_colores.codcolorem LEFT OUTER JOIN em_tamanos ON articulos.codtamanoem = em_tamanos.codtamanoem LEFT OUTER JOIN em_reservaslotepedido ON em_cargadropshipping.idlineapedido = em_reservaslotepedido.idlineapc LEFT OUTER JOIN lineaspedidoscli ON em_cargadropshipping.idlineapedido = lineaspedidoscli.idlinea ");


	q.setWhere("em_cargadropshipping.coddropshipping = '" + cursor.valueBuffer("codigo") + "' group by em_cargadropshipping.refinterna, em_cargadropshipping.sku, em_cargadropshipping.descinterna, em_cargadropshipping.descripcion, stocks.disponible,em_cargadropshipping.programado,em_cargadropshipping.listaordenes,familias.descripcion, subfamilias.descripcion, em_dibujos.descripcion, em_tamanos.codtamanoem, em_colores.descripcion  order by familias.descripcion, subfamilias.descripcion, em_dibujos.descripcion, em_tamanos.codtamanoem, em_colores.descripcion");

	//debug("\n\ntablapedidos: "+q.sql());
	_i.tblPedidos_.setQuery(q);
	//connect(_i.tblPteConfirmar_.table(), "doubleClicked(int, int)", _i, "tblPteConfirmar_doubleClicked");
	
	var cHPTE = [];
	
	cHPTE[1] = "Referencia";
	cHPTE[2] = "SKU";
	cHPTE[3] = "Descripci�n";
	cHPTE[4] = "Desc. carga";
	cHPTE[5] = "Cantidad";
	cHPTE[6] = "Disponible";
	cHPTE[7] = "Programado";
	cHPTE[8] = "Ordenes de producci�n";
	cHPTE[9] = "Familia";
	cHPTE[10] = "Subfamilia";
	cHPTE[11] = "Dibujo";
	cHPTE[12] = "Tama�o";
	cHPTE[13] = "Color";



	_i.aCamposPedidosV_ = [];
	for(var k=0; k<cHPTE.length-1;k++) {
		_i.aCamposPedidosV_[k] = cHPTE[k+1];	
	}
	

	this.child("tblPedidos").setColumnLabels("*", cHPTE.join("*"));		
	_i.tblPedidos_.setColumnWidth("em_cargadropshipping.refinterna", 70);	
	_i.tblPedidos_.setColumnWidth("em_cargadropshipping.sku", 100);
	_i.tblPedidos_.setColumnWidth("em_cargadropshipping.descinterna", 300);
	_i.tblPedidos_.setColumnWidth("em_cargadropshipping.descripcion", 300);
	_i.tblPedidos_.setColumnWidth("SUM(em_reservaslotepedido.cantidad)", 200);
	_i.tblPedidos_.setColumnWidth("stocks.disponible", 70);
	_i.tblPedidos_.refresh();
	_i.deshabilitarBotones();
}

function oficial_iniciaTablaClientes()
{
	var _i = this.iface;
	var cursor = this.cursor()	

	_i.tblClientes_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblClientes"));
	_i.tblClientes_.setColorFunction("formRecordem_dropshipping.iface.colorClientes");
	//_i.tblClientes_.setFormatFunction("formRecordem_dropshipping.iface.formateaClientes");
	q = new AQSqlQuery;
	q.setSelect("em_cargadropshipping.pedidoprivalia,pedidoscli.codigo,pedidoscli.fecha,pedidoscli.fechaservicio,albaranescli.codigo, em_cargadropshipping.nombre, em_cargadropshipping.direccion, em_cargadropshipping.localidad, em_cargadropshipping.provincia,em_cargadropshipping.pais,em_cargadropshipping.codpostal,em_cargadropshipping.telefono1,em_cargadropshipping.telefono2, SUM(em_cargadropshipping.unidadespedidas) AS \"Unidades\", SUM(em_cargadropshipping.costetotal) AS \"Coste total\", em_cargadropshipping.carrier,em_cargadropshipping.tracking,em_cargadropshipping.infocarrier1,em_cargadropshipping.infocarrier2,em_cargadropshipping.infocarrier3,em_cargadropshipping.infocarrier4, em_cargadropshipping.infocarrier5, em_cargadropshipping.idpedido");
	q.setFrom("em_cargadropshipping LEFT OUTER JOIN pedidoscli on em_cargadropshipping.idpedido = pedidoscli.idpedido LEFT OUTER JOIN lineasalbaranescli ON em_cargadropshipping.idlineapedido = lineasalbaranescli.idlineapedido LEFT OUTER JOIN albaranescli on lineasalbaranescli.idalbaran = albaranescli.idalbaran");
	//q.setWhere("em_cargadropshipping.coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND em_cargadropshipping.idpedido IS NOT NULL GROUP BY em_cargadropshipping.pedidoprivalia, em_cargadropshipping.nombre, em_cargadropshipping.direccion, em_cargadropshipping.localidad, em_cargadropshipping.provincia,em_cargadropshipping.pais,em_cargadropshipping.codpostal,em_cargadropshipping.telefono1,em_cargadropshipping.telefono2,em_cargadropshipping.carrier,em_cargadropshipping.tracking,em_cargadropshipping.estado,em_cargadropshipping.infocarrier1,em_cargadropshipping.infocarrier2,em_cargadropshipping.infocarrier3,em_cargadropshipping.infocarrier4, em_cargadropshipping.infocarrier5, em_cargadropshipping.idpedido ORDER BY em_cargadropshipping.pedidoprivalia ASC");
	q.setWhere(_i.dameFiltroClientes() + _i.dameGroupByClientes() + _i.dameOrderByClientes());


	//debug("q.sql: "+q.sql());
	_i.tblClientes_.setQuery(q);
	//connect(_i.tblConfirmado_.table(), "doubleClicked(int, int)", _i, "tblConfirmado_doubleClicked");
	
	var cHCON = [];	
	cHCON[1] = "Ped. Privalia";
	cHCON[2] = "Ped. Euromoda";
	cHCON[3] = "Fecha Doc.";
	cHCON[4] = "Fecha servicio";
	cHCON[5] = "Albar�n";
	cHCON[6] = "Nombre";
	cHCON[7] = "Direcci�n";
	cHCON[8] = "Localidad";
	cHCON[9] = "Provincia";
	cHCON[10] = "Pa�s";
	cHCON[11] = "Cod. Postal";	
	cHCON[12] = "Tel�fono 1";
	cHCON[13] = "Tel�fono 2";
	cHCON[14] = "Unidades";
	cHCON[15] = "Coste total";
	cHCON[16] = "Carrier";	
	cHCON[17] = "Tracking";	
	cHCON[18] = "Info 1";
	cHCON[19] = "Info 2";
	cHCON[20] = "Info 3";
	cHCON[21] = "Info 4";
	cHCON[22] = "Info 5";

	_i.aCamposClientesV_ = [];
	for(var k=0; k<cHCON.length-1;k++) {
		_i.aCamposClientesV_[k] = cHCON[k+1];	
	}



	this.child("tblClientes").setColumnLabels("*", cHCON.join("*"));		
	
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.pedidoprivalia", 100);	
	_i.tblClientes_.setColumnWidth("albaranescli.codigo", 100);	
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.nombre", 250);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.direccion", 250);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.localidad", 100);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.provincia", 100);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.pais", 60);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.codpostal", 75);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.telefono1", 85);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.telefono2", 85);
	_i.tblClientes_.setColumnWidth("\"Coste total\"", 100);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.carrier", 75);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.tracking", 200);
	_i.tblClientes_.setColumnWidth("em_cargadropshipping.infocarrier1", 120);

	_i.tblClientes_.refresh();

//debug("tblClientes_.numRows(): "+_i.tblClientes_.numRows());

	if(_i.tblClientes_.numRows() != 0){
		_i.tblClientes_currentChanged(0,0);
	}

}

function oficial_iniciaTablaLineas()
{
	var _i = this.iface;
	_i.tblLineas_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblLineas"));
	_i.tblLineas_.setColorFunction("formRecordem_dropshipping.iface.colorLineas");
	_i.tblLineas_.setFormatFunction("formRecordem_dropshipping.iface.formateaTblLineas");

	

	q = new AQSqlQuery;
	q.setSelect("lineaspedidoscli.referencia, lineaspedidoscli.descripcion, lineaspedidoscli.cantidad, em_cargadropshipping.refstockprivalia, lineaspedidoscli.emcodbarras,em_cargadropshipping.sku,em_cargadropshipping.listaordenes, em_cargadropshipping.articulo,em_cargadropshipping.descripcion,em_cargadropshipping.costeunitario,em_cargadropshipping.unidadespedidas,em_cargadropshipping.unidadesservidas,movistock.reservaex, movistock.reservapr, movistock.reservaaf, lineaspedidoscli.totalenalbaran,lineaspedidoscli.idlinea");
	q.setFrom("em_cargadropshipping INNER JOIN lineaspedidoscli ON em_cargadropshipping.idpedido = lineaspedidoscli.idpedido AND em_cargadropshipping.idlineapedido = lineaspedidoscli.idlinea LEFT OUTER JOIN movistock ON movistock.idlineapc = lineaspedidoscli.idlinea");
	q.setWhere("1=2");
	_i.tblLineas_.setQuery(q);


	var cHCON = [];	
	cHCON[1] = "Referencia";
	cHCON[2] = "Descripci�n";
	cHCON[3] = "Cantidad";
	cHCON[4] = "Ref.Stock Privalia";
	cHCON[5] = "EAN";
	cHCON[6] = "SKU";
	cHCON[7] = "�rdenes de producci�n";
	cHCON[8] = "Art�culo";

	cHCON[9] = "Desc. Carga";
	cHCON[10] = "Coste unitario";
	cHCON[11] = "Unidades carga";
	cHCON[12] = "Unidades servidas";

	cHCON[13] = "Reserva EX.";
	cHCON[14] = "Reserva PR.";
	cHCON[15] = "Reserva AF.";
	cHCON[16] = "En Albar�n";

	this.child("tblLineas").setColumnLabels("*", cHCON.join("*"));
	_i.tblLineas_.setColumnWidth("lineaspedidoscli.referencia", 100);
	_i.tblLineas_.setColumnWidth("lineaspedidoscli.descripcion", 300);
	_i.tblLineas_.setColumnWidth("lineaspedidoscli.cantidad", 70);
	_i.tblLineas_.setColumnWidth("em_cargadropshipping.refstockprivalia", 100);
	_i.tblLineas_.setColumnWidth("lineaspedidoscli.emcodbarras", 100);
	_i.tblLineas_.setColumnWidth("em_cargadropshipping.sku", 100);
	_i.tblLineas_.setColumnWidth("em_cargadropshipping.descripcion", 300);
	_i.tblLineas_.setColumnWidth("em_cargadropshipping.costeunitario", 100);
	_i.tblLineas_.setColumnWidth("em_cargadropshipping.unidadespedidas", 100);
	_i.tblLineas_.setColumnWidth("em_cargadropshipping.unidadesservidas", 100);
	_i.tblLineas_.setColumnWidth("movistock.reservaex", 100);
	_i.tblLineas_.setColumnWidth("movistock.reservapr", 100);
	_i.tblLineas_.setColumnWidth("movistock.reservaaf", 100);
	_i.tblLineas_.setColumnWidth("lineaspedidoscli.totalenalbaran", 100);
	

	_i.tblLineas_.refresh();
}

function oficial_filtrarClientes()
{
	var _i = this.iface;
	_i.tblClientes_.setFilter(_i.dameFiltroClientes() + _i.dameGroupByClientes(), true);
	if(_i.tblClientes_.numRows() != 0){
		_i.tblClientes_currentChanged(0,0);
	} else {
		_i.tblLineas_.setFilter("1=2", true);
	}
}

function oficial_dameFiltroClientes()
{
	var _i = this.iface;
	var cursor = this.cursor()	
	var filtro = "(em_cargadropshipping.coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND em_cargadropshipping.idpedido IS NOT NULL)"

	var filtroNEAF = _i.dameFiltroNoEnviablesAF();
	var filtroNEPR = _i.dameFiltroNoEnviablesPR();
	var filtroEnviables = _i.dameFiltroEnviables();
	var filtroEnviados = _i.dameFiltroEnviados();

	var filtros = "";

	if(filtroNEAF && filtroNEAF != "") {
		filtros += filtros == "" ? "" : " OR ";
		filtros += filtroNEAF;		
	}

	if(filtroNEPR && filtroNEPR != "") {
		filtros += filtros == "" ? "" : " OR ";
		filtros += filtroNEPR;		
	}

	if(filtroEnviables && filtroEnviables != "") {
		filtros += filtros == "" ? "" : " OR ";
		filtros += filtroEnviables;		
	}

	if(filtroEnviados && filtroEnviados != "") {
		filtros += filtros == "" ? "" : " OR ";
		filtros += filtroEnviados;		
	}


	if(filtros && filtros != "") {
		filtro += " AND ("+ filtros +")";
	} else {
		filtro = "1=2";
	}

	return filtro; 

}

function oficial_dameGroupByClientes()
{
	var groupBy = " GROUP BY em_cargadropshipping.pedidoprivalia,pedidoscli.codigo,pedidoscli.fecha,pedidoscli.fechaservicio, albaranescli.codigo, em_cargadropshipping.nombre, em_cargadropshipping.direccion, em_cargadropshipping.localidad, em_cargadropshipping.provincia,em_cargadropshipping.pais,em_cargadropshipping.codpostal,em_cargadropshipping.telefono1,em_cargadropshipping.telefono2,em_cargadropshipping.carrier,em_cargadropshipping.tracking,em_cargadropshipping.infocarrier1,em_cargadropshipping.infocarrier2,em_cargadropshipping.infocarrier3,em_cargadropshipping.infocarrier4, em_cargadropshipping.infocarrier5, em_cargadropshipping.idpedido ";

	return groupBy;
}

function oficial_dameOrderByClientes()
{
	var orderBy = " ORDER BY em_cargadropshipping.pedidoprivalia ASC";

	return orderBy;
}

function oficial_dameFiltroNoEnviablesAF()
{
	var _i = this.iface;
	var filtro = "";
	
	if (this.child("chkNoEnviablesAF").checked) {
		if(_i.noEnviablesAF_.length > 0) {
			var listaPedidos = _i.noEnviablesAF_.join(",");
			filtro += "em_cargadropshipping.idpedido IN (" + listaPedidos +")";
		}
	}
	return filtro;
}

function oficial_dameFiltroNoEnviablesPR()
{
	var _i = this.iface;
	var filtro = "";
	
	if (this.child("chkNoEnviablesPR").checked) {
		if(_i.noEnviablesPR_.length > 0) {
			var listaPedidos = _i.noEnviablesPR_.join(",");
			filtro += "em_cargadropshipping.idpedido IN (" + listaPedidos +")";
		}
	}
	return filtro;
}

function oficial_dameFiltroEnviables()
{
	var _i = this.iface;
	var filtro = "";
	
	if (this.child("chkEnviables").checked) {
		if(_i.enviables_.length > 0) {
			var listaPedidos = _i.enviables_.join(",");
			filtro += "em_cargadropshipping.idpedido IN (" + listaPedidos +")";
		}
	}
	return filtro;
}

function oficial_dameFiltroEnviados()
{
	var _i = this.iface;
	var filtro = "";
	
	if (this.child("chkEnviados").checked) {
		if(_i.enviados_.length > 0) {
			var listaPedidos = _i.enviados_.join(",");
			filtro += "em_cargadropshipping.idpedido IN (" + listaPedidos +")";
		}
	}
	return filtro;
}

function oficial_tblClientes_clicked(f, c)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codDropshipping = cursor.valueBuffer("codigo");
	var pedido = _i.tblClientes_.cellValue(f, "em_cargadropshipping.pedidoprivalia");
	var idPedido = AQUtil.sqlSelect("em_cargadropshipping", "idpedido", "pedidoprivalia = '" + pedido + "' and coddropshipping = '" + codDropshipping + "'");
	//debug("pedido: " + pedido);
	//debug("idPedido: " + idPedido);

	var where = "1 = 2";

	if(idPedido && idPedido != "") {
		where = "em_cargadropshipping.idpedido = " + idPedido + " group by lineaspedidoscli.referencia, lineaspedidoscli.descripcion, lineaspedidoscli.cantidad,em_cargadropshipping.refstockprivalia,lineaspedidoscli.emcodbarras,em_cargadropshipping.sku, em_cargadropshipping.articulo,em_cargadropshipping.descripcion,em_cargadropshipping.costeunitario,em_cargadropshipping.unidadespedidas,em_cargadropshipping.unidadesservidas,movistock.reservaex, movistock.reservapr, movistock.reservaaf, lineaspedidoscli.totalenalbaran, em_cargadropshipping.listaordenes,lineaspedidoscli.idlinea";
	}

	_i.tblLineas_.setFilter(where, true);



	/*_i.tblLineas_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblLineas"));
	_i.tblLineas_.setColorFunction("formRecordem_dropshipping.iface.colorLineas");
	var cHCON = [];	
	cHCON[1] = "Referencia";
	cHCON[2] = "Descripci�n";
	cHCON[3] = "Cantidad";
	cHCON[4] = "Stock Privalia";
	cHCON[5] = "EAN";
	cHCON[6] = "SKU";
	cHCON[7] = "Art�culo";	
	cHCON[8] = "Desc. Carga";
	cHCON[9] = "Coste unitario";
	cHCON[10] = "Unidades carga";
	cHCON[11] = "Unidades servidas";

	cHCON[12] = "Reserva EX.";
	cHCON[13] = "Reserva PR.";
	cHCON[14] = "Reserva AF.";
	cHCON[15] = "En Albar�n";

	this.child("tblLineas").setColumnLabels("*", cHCON.join("*"));

	q = new AQSqlQuery;
	q.setSelect("lineaspedidoscli.referencia, lineaspedidoscli.descripcion, lineaspedidoscli.cantidad,em_cargadropshipping.refstockprivalia,em_cargadropshipping.ean,em_cargadropshipping.sku, em_cargadropshipping.articulo,em_cargadropshipping.descripcion,em_cargadropshipping.costeunitario,em_cargadropshipping.unidadespedidas,em_cargadropshipping.unidadesservidas,movistock.reservaex, movistock.reservapr, movistock.reservaaf, lineaspedidoscli.totalenalbaran");
	q.setFrom("em_cargadropshipping INNER JOIN lineaspedidoscli ON em_cargadropshipping.idpedido = lineaspedidoscli.idpedido AND em_cargadropshipping.refinterna = lineaspedidoscli.referencia LEFT OUTER JOIN movistock ON movistock.idlineapc = lineaspedidoscli.idlinea");
	q.setWhere(where);
	_i.tblLineas_.setQuery(q);
	_i.tblLineas_.refresh();*/



}

function oficial_tblClientes_currentChanged(f,c){

	var _i = this.iface;

	//if(f == _i.tblClientes_.numRows() - 1){
		_i.tblClientes_clicked(f,c);
	//}
}

function oficial_colorLineas(f, c)
{
	
	
	var _i = this.iface;
	
	var color;
	var totalEnAlbaran = _i.tblLineas_.cellValue(f, "lineaspedidoscli.totalenalbaran");
	var reservaEx = _i.tblLineas_.cellValue(f, "movistock.reservaex");
	var reservaAFaltas = _i.tblLineas_.cellValue(f, "movistock.reservaaf");
	var reservasPte = _i.tblLineas_.cellValue(f, "movistock.reservapr");


	if(reservaAFaltas && reservaAFaltas >0) {
		//rojo
		return new Color(255, 50, 50);
	} else if (reservasPte && reservasPte >0) {	
		// blanco
		return  new Color(255, 255, 255);
	}  else if(reservaEx && reservaEx > 0) {
		//verde

		return new Color("green");

		//return  new Color(204, 255, 51);	
	} else if(totalEnAlbaran && totalEnAlbaran > 0) {
		//azul
		return  new Color(204, 255, 255);
	} else {
		return  new Color(255, 255, 255);
	}


	/*if(totalEnAlbaran && totalEnAlbaran > 0) {
		//azul
		return  new Color(204, 255, 255);
	} else if(reservaAFaltas && reservaAFaltas >0) {
		//rojo
		return new Color(255, 50, 50);
	}  else if(reservaEx && reservaEx > 0) {
		//verde
		return  new Color(204, 255, 51);	
	} else {
		return  new Color(255, 255, 255);
	}*/

	/*Blanco: L�nea no enviable reservada de pendiente de recibir.
	Rojo: L�nea no enviable reservada total o parcialmente a faltas.
	Verde: L�nea enviable (reservada de existencias)
	Azul claro: L�nea enviada (asociada a albar�n)*/
}

function oficial_colorClientes(f, c)
{
	
	
	var _i = this.iface;	
	var color;
	var idPedido = _i.tblClientes_.cellValue(f, "em_cargadropshipping.idpedido");

	var q = new AQSqlQuery;	
	q.setSelect("SUM(movistock.reservaex), SUM(movistock.reservaaf), SUM(movistock.reservapr),SUM(lineaspedidoscli.totalenalbaran)");
	q.setFrom("lineaspedidoscli left outer join movistock on lineaspedidoscli.idlinea = movistock.idlineapc");
	q.setWhere("lineaspedidoscli.idpedido = " + idPedido); 				
	if (!q.exec()){
		return;
	}  
	if(!q.first())
	{
		return  new Color(255, 255, 255);
	}	

	var totalEnAlbaran = q.value("SUM(lineaspedidoscli.totalenalbaran)");
	var reservaEx = q.value("SUM(movistock.reservaex)");
	var reservaAFaltas = q.value("SUM(movistock.reservaaf)");
	var reservasPte = q.value("SUM(movistock.reservapr)");


	if(reservaAFaltas && reservaAFaltas >0) {
		//rojo
		return new Color(255, 50, 50);
	} else if (reservasPte && reservasPte >0) {	
		// blanco
		return  new Color(255, 255, 255);
	}  else if(reservaEx && reservaEx > 0) {
		//verde
		return new Color("green");
		//return  new Color(204, 255, 51);	
	} else if(totalEnAlbaran && totalEnAlbaran > 0) {
		//azul
		return  new Color(204, 255, 255);
	} else {
		return  new Color(255, 255, 255);
	}

}

/*function oficial_colorClientes(f, c)
{
	
	
	var _i = this.iface;	
	var color;
	var idPedido = _i.tblClientes_.cellValue(f, "em_cargadropshipping.idpedido");



	for(var i=0; i<_i.noEnviablesAF_; i++) {
		if(_i.noEnviablesAF_[i] == idPedido) {
			return new Color(255, 50, 50);
		}
	}

	for(var i=0; i<_i.noEnviablesPR_; i++) {
		if(_i.noEnviablesPR_[i] == idPedido) {
			return  new Color(255, 255, 255);
		}
	}

	for(var i=0; i<_i.enviables_; i++) {
		if(_i.enviables_[i] == idPedido) {
			return  new Color(204, 255, 51);
		}
	}

	for(var i=0; i<_i.enviados_; i++) {
		if(_i.enviados_[i] == idPedido) {
			return  new Color(204, 255, 255);
		}
	}

	return  new Color(255, 255, 255);	
}*/

function oficial_toolButtomInsert_clicked() 
{
	var _i = this.iface;
	var cursor = this.child("tdbEnvios").cursor();
	cursor.insertRecord();

}

function oficial_toolButtonEdit_clicked()
{
	var _i = this.iface; 

	var cursor = this.child("tdbEnvios").cursor();
	cursor.editRecord();
}

function oficial_toolButtonDelete_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbEnvios").cursor();

	var res = MessageBox.information(sys.translate("Va a borrar el env�o seleccionado.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
	if (res != MessageBox.Yes) {
		return false;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al borrar el env�o");
	oParam.cursor = cursor;	
	var f = new Function("oParam", "return formRecordem_dropshipping.iface.borraEnvio(oParam)");
	if (!sys.runTransaction(f, oParam)) {									
		return false;
	}

	this.child("tdbEnvios").refresh();
}

function oficial_borraEnvio(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;

	if (!AQUtil.execSql("UPDATE albaranescli SET emcodenviodrop = NULL WHERE emcodenviodrop = '" + cursor.valueBuffer("emcodenviodrop") + "'")) {
		return false;
	}
	cursor.setModeAccess(cursor.Del);
	cursor.refreshBuffer();
	if (!cursor.commitBuffer()) {
		return false;
	}
	return true;
}

function oficial_toolButtonZoom_clicked()
{
	var _i = this.iface;
	var cursor = this.child("tdbEnvios").cursor();
	cursor.browseRecord();
}

function oficial_dameColor(fN, fV, cursor, fT, sel)
{
	var color = "";
	switch (cursor.valueBuffer("estado")) {
		case "T. INCOMPLETA": {
			color = flfactppal.iface.pub_dameColor("fondo_rojo");
			break;
		}
		case "TERMINADA": {
			color = flfactppal.iface.pub_dameColor("fondo_verde");
			break;
		}
		case "EN CURSO": {
			color = flfactppal.iface.pub_dameColor("fondo_amarillo");
			break;
		}
		default: {
			return;
		}
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}

function oficial_totalizaCarga(cursor)
{
	var _i = this.iface;
	
	var totalPrendas = 0, totalEuromoda = 0, totalCliente = 0;

	var qT = new FLSqlQuery;
	qT.setSelect("SUM(unidadespedidas), SUM(costetotal), SUM(importecalculado*unidadespedidas), SUM(costetotal-importecalculado)");
	qT.setFrom("em_cargadropshipping");
	qT.setWhere("coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	if (qT.exec() && qT.first()) {
		totalPrendas = AQUtil.roundFieldValue(qT.value("SUM(unidadespedidas)"), "em_dropshipping", "totalprendas");
		totalEuromoda = AQUtil.roundFieldValue(qT.value("SUM(importecalculado*unidadespedidas)"), "em_dropshipping", "totaleuromoda");
		totalCliente = AQUtil.roundFieldValue(qT.value("SUM(costetotal)"), "em_dropshipping", "totalcliente");
	}
	cursor.setValueBuffer("totalprendas", totalPrendas);
	cursor.setValueBuffer("totaleuromoda", totalEuromoda);
	cursor.setValueBuffer("totalcliente", totalCliente);
	cursor.setValueBuffer("diferenciaimportes", cursor.valueBuffer("totaleuromoda") - cursor.valueBuffer("totalcliente"));
	cursor.setValueBuffer("unidadespendientes",totalPrendas);
	return true;
}

function oficial_deshabilitarBotones()
{
	var _i = this.iface;
	var cursor = this.cursor();
	//var pedidos = _i.tblPedidos_.numRows();
	var pedidos = AQUtil.sqlSelect("pedidoscli","count(*)","em_coddropshipping = '" + cursor.valueBuffer("codigo")  + "'");
	var lineas = AQUtil.sqlSelect("em_cargadropshipping", "COUNT(id)", "coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	var numPedidos = AQUtil.sqlSelect("em_cargadropshipping", "COUNT(id)", "coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND idpedido is null");
	if(lineas == 0){
		sys.enableObj(this, "pbnCargaPedidos");
		sys.enableObj(this, "pbnGenerarPedidos");
		sys.enableObj(this, "fdbModoFabricacion");
	}
	else if(numPedidos == 0) {
		sys.disableObj(this, "pbnCargaPedidos");
		sys.disableObj(this, "pbnGenerarPedidos");
		sys.disableObj(this, "fdbModoFabricacion");
	} else if(pedidos > 0) {
		sys.disableObj(this, "pbnCargaPedidos");
		sys.enableObj(this, "pbnGenerarPedidos");
		sys.disableObj(this, "fdbModoFabricacion");
	}
}

function oficial_tbnAsociarAlbaranes_clicked()
{
	var aAlbaranes = this.child("tdbAlbaranesCli").primarysKeysChecked();
	if (!aAlbaranes || aAlbaranes.length == 0) {
		sys.warnMsgBox(sys.translate("No ha seleccionado ning�n albar�n"));
		return false;
	}
	var curE = this.child("tdbEnvios").cursor();
	var codEnvio = curE.valueBuffer("emcodenviodrop");
	if (!codEnvio || codEnvio == "") {
		sys.warnMsgBox(sys.translate("No ha seleccionado ning�n env�o"));
		return false;
	}
	var sAlbaranes = aAlbaranes.join(",");
	if (AQUtil.sqlSelect("albaranescli", "idalbaran", "idalbaran IN (" + sAlbaranes + ") AND emcodenviodrop IS NOT NULL")) {
		sys.warnMsgBox(sys.translate("Ha seleccionado albaranes que ya tienen env�o asociado"));
		return false;
	}
	var codAgencia = curE.valueBuffer("codagencia");
	if (AQUtil.sqlSelect("albaranescli", "idalbaran", "idalbaran IN (" + sAlbaranes + ") AND (codagencia IS NULL OR codagencia <> '" + codAgencia + "')")) {
		sys.warnMsgBox(sys.translate("Alguno de los albaranes seleccionados no corresponde a la agencia de transporte del env�o"));
		return false;
	}

	if (!AQUtil.execSql("UPDATE albaranescli SET emcodenviodrop = '" + codEnvio + "' WHERE idalbaran IN (" + sAlbaranes + ");")) {
		sys.warnMsgBox(sys.translate("Error al asociar los albaranes al env�o"));
		return false;	
	}

	this.child("tdbAlbaranesCli").clearChecked();
	this.child("tdbAlbaranesCli").refresh();
	sys.infoMsgBox(sys.translate("Los albaranes se han asociado al env�o correctamente"));

	return true;
}

function oficial_tbnQuitarAlbaranes_clicked()
{
	var aAlbaranes = this.child("tdbAlbaranesCli").primarysKeysChecked();
	if (!aAlbaranes || aAlbaranes.length == 0) {
		sys.warnMsgBox(sys.translate("No ha seleccionado ning�n albar�n"));
		return false;
	}
	var res = MessageBox.information(sys.translate("Va a desvincular los albaranes seleccionados de sus env�os.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
	if (res != MessageBox.Yes) {
		return false;
	}
	var sAlbaranes = aAlbaranes.join(",");
	if (!AQUtil.execSql("UPDATE albaranescli SET emcodenviodrop = NULL WHERE idalbaran IN (" + sAlbaranes + ");")) {
		sys.warnMsgBox(sys.translate("Error al asociar los albaranes al env�o"));
		return false;	
	}
	this.child("tdbAlbaranesCli").clearChecked();
	this.child("tdbAlbaranesCli").refresh();
	sys.infoMsgBox(sys.translate("Los albaranes se han desvinculado correctamente"));
}


function oficial_tbnNingunAlbSel_clicked()
{
	this.child("tdbAlbaranesCli").clearChecked();
	this.child("tdbAlbaranesCli").refresh();
}

function oficial_tbnTodosAlbSel_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var filtro = "em_coddropshipping = '" + cursor.valueBuffer("codigo") + "'";

	var mF = this.child("tdbAlbaranesCli").cursor().mainFilter();
	var fF = this.child("tdbAlbaranesCli").findFilter();
	var f = this.child("tdbAlbaranesCli").filter();

	if (mF && mF != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += mF;
	}
	if (fF && fF != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += fF;
	}
	if (f && f != "") {
		filtro += filtro != "" ? " AND " : "";
		filtro += f;
	}
	
	if (!filtro || filtro == "") {
		return;
	}

	var qA = new FLSqlQuery();
	qA.setTablesList("albaranescli");
	qA.setSelect("idalbaran");
	qA.setFrom("albaranescli");
	qA.setWhere(filtro);
	qA.setForwardOnly(true);
	if (!qA.exec()) {
		return false;
	}
	while (qA.next()) {
		this.child("tdbAlbaranesCli").setPrimaryKeyChecked(qA.value("idalbaran"), true);
	}
	this.child("tdbAlbaranesCli").refresh();
}

function oficial_pbnCambiarDesc_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codDropshipping = cursor.valueBuffer("codigo");

	var dialogo = new Dialog;
	dialogo.okButtonText = sys.translate("scripts", "Aceptar");
	dialogo.cancelButtonText = sys.translate("scripts", "Cancelar");

	var nuevaDescripcion = new LineEdit;
	nuevaDescripcion.label = "Nueva descripci�n:";
	nuevaDescripcion.text = "";

	dialogo.add(nuevaDescripcion);

	if (!dialogo.exec()) {
		return false;
	}

	if (!nuevaDescripcion.text) {
		sys.infoMsgBox(sys.translate("No se permite una descripci�n vac�a."));
		return _i.pbnCambiarDesc_clicked();
	}

	var descripcionNueva = nuevaDescripcion.text;
	

	/*if (!AQUtil.execSql("UPDATE pedidoscli SET docexterno = '" + descripcionNueva + "' WHERE em_coddropshipping = '" + codDropshipping + "'")) {
  		return false;
  	}*/

  	var q = new AQSqlQuery;	
	q.setSelect("em_cargadropshipping.pedidoprivalia,pedidoscli.idpedido");
	q.setFrom("em_cargadropshipping left outer join pedidoscli on em_cargadropshipping.idpedido = pedidoscli.idpedido");
	q.setWhere("em_cargadropshipping.coddropshipping = '" + codDropshipping + "'"); 			
	q.setOrderBy
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		var observaciones = descripcionNueva + " / " + q.value("em_cargadropshipping.pedidoprivalia");
		if (!AQUtil.execSql("UPDATE pedidoscli SET docexterno = '" + descripcionNueva + "', obsinternas = '" + observaciones + "' WHERE em_coddropshipping = '" + codDropshipping + "' and idpedido = " + q.value("pedidoscli.idpedido"))) {
  			return false;
  		}	
	}	

  	if (!AQUtil.execSql("UPDATE albaranescli SET docexterno = '" + descripcionNueva + "' WHERE em_coddropshipping = '" + codDropshipping + "'")) {
  		return false;
  	}
  	if (!AQUtil.execSql("UPDATE facturascli SET docexterno = '" + descripcionNueva + "' WHERE em_coddropshipping = '" + codDropshipping + "'")) {
  		return false;
  	}

  	cursor.setValueBuffer("descripcion", descripcionNueva);
  	flfactppal.iface.ponMsgError(sys.translate("Descripci�n actualizada correctamente"),"info",this);
	return true;
}

function oficial_imprimirCSV()
{
	var _i =  this.iface;
	var tipo = "todasLineas";
	var todas = this.child("chkExportarTodasEnv").checked; 
	if(!_i.exportarCSV(tipo, todas)){
		return false;
	}

	return true;
}
function oficial_imprimirEnvio()
{
	var _i = this.iface;

	var cursor = this.cursor();
	var curEnvio = this.child("tdbEnvios").cursor();

	var codigo = curEnvio.valueBuffer("emcodenviodrop");

	if (!codigo) {
		return false;
	}

	var oParam = _i.dameParamEnvioDropShipping(codigo);
	if (!oParam) {
		return;
	}
	var curImprimir = new FLSqlCursor("i_enviosdropshipping");
	curImprimir.setModeAccess(curImprimir.Insert);
	curImprimir.refreshBuffer();
	curImprimir.setValueBuffer("descripcion", "temp");
	//curImprimir.setValueBuffer("d_em_enviodropshipping_emcodenviodrop", codigo);
	//curImprimir.setValueBuffer("h_em_enviodropshipping_emcodenviodrop", codigo);
	if (!flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam)) {
		debug("falla li");
		return false;
	}
}

function oficial_dameParamEnvioDropShipping(codigo)
{
	var _i = this.iface;	

	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "i_em_enviodropshipping";
	oParam.whereFijo = "em_enviodropshipping.emcodenviodrop = '" + codigo + "'";
	oParam.groupBy = "em_enviodropshipping.emcodenviodrop,albaranescli.codigo, albaranescli.fecha, empresa.nombre, empresa.cifnif, empresa.direccion, empresa.provincia, empresa.ciudad, empresa.codpais, empresa.codpostal, em_cargadropshipping.pedidoprivalia, em_cargadropshipping.nombre, em_cargadropshipping.tracking,em_enviodropshipping.codagencia,em_enviodropshipping.tipobulto,em_enviodropshipping.numbultos,em_enviodropshipping.kilos,em_enviodropshipping.volumen,em_enviodropshipping.numeropalets, em_dropshipping.descripcion,em_dropshipping.codigo, em_dropshipping.codcliente, clientes.nombre, proveedores.nombre,em_cargadropshipping.idpedido";
	oParam.orderBy = "em_cargadropshipping.idpedido";
	return oParam;
}

function oficial_tbnExcelResumen_clicked() 
{
	var _i = this.iface;
	var oParamExcel = _i.dameParamExcelResumen(); 
	_i.tblPedidos_.exportarTablaExcel(oParamExcel);
}
function oficial_tbnExcelClientes_clicked()
{
	var _i = this.iface;
	var oParamExcel = _i.dameParamExcelClientes(); 
	_i.tblClientes_.exportarTablaExcel(oParamExcel);
}
function oficial_tbnExcelLineas_clicked() 
{
	var _i = this.iface;
	var oParamExcel = _i.dameParamExcelLineas(); 
	_i.tblLineas_.exportarTablaExcel(oParamExcel);
}
function oficial_dameParamExcelResumen() 
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var codDropshipping = cursor.valueBuffer("codigo");
  	var oParam = flfactppal.iface.pub_dameParamExcel();	
	var fecha = new Date;	
	var prefijo = "Dropshipping_" + codDropshipping + "_pedido_resumen"
  	oParam.nombreFichero = fleumoesta.iface.pub_dameNombreFecha(prefijo);
  	oParam.titulo = "Dropshipping " + codDropshipping + " pedido resumen ";
  	return oParam;

}
function oficial_dameParamExcelClientes() 
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var codDropshipping = cursor.valueBuffer("codigo");
  	var oParam = flfactppal.iface.pub_dameParamExcel();	
	var fecha = new Date;	
	var prefijo = "Dropshipping_" + codDropshipping + "_pedido_detalle";
  	oParam.nombreFichero = fleumoesta.iface.pub_dameNombreFecha(prefijo);
  	oParam.titulo = "Dropshipping " + codDropshipping + " pedido detalle ";
  	return oParam;

}
function oficial_dameParamExcelLineas() 
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var codDropshipping = cursor.valueBuffer("codigo");
	var row = this.child("tblLineas").currentRow(); 
	var pedPrivalia = _i.tblClientes_.cellValue(row, "em_cargadropshipping.pedidoprivalia");

  	var oParam = flfactppal.iface.pub_dameParamExcel();	
	var fecha = new Date;	
	var prefijo = "Dropshipping_" + codDropshipping + "_lineas_pedido_detalle_" + pedPrivalia;
  	oParam.nombreFichero = fleumoesta.iface.pub_dameNombreFecha(prefijo);
  	oParam.titulo = "Dropshipping " + codDropshipping + " lineas pedido detalle " + pedPrivalia
  	return oParam;

}

function oficial_rellenaComboPedidos()
{

	//hayq ue rellenar el combo

	var _i = this.iface;
	var aCampos = _i.tblPedidos_.getCabeceras();	
	var aColsN = _i.tblPedidos_.getColsN();	
	var aMtd = _i.tblPedidos_.getColsMtd();	
	//_i.aCamposPedidosV_ = [];
	_i.aColsPedidosV_ = [];
	_i.aTiposPedidosV_ = [];
	for(var i = 0; i < aMtd.length; i++){	
		if(aMtd[i] == 19) {
			_i.aColsPedidosV_.push(aColsN[i]);			 
			//_i.aCamposPedidosV_.push(aCampos[i]);									
			_i.aTiposPedidosV_.push(19);	
		}else {
			var visible = aMtd[i].visibleGrid();
			if(visible) {
				_i.aColsPedidosV_.push(aColsN[i]);				
				//_i.aCamposPedidosV_.push(aCampos[i]); 		
				_i.aTiposPedidosV_.push(aMtd[i].type());			
			}				
		}	
		
	}	

	this.child("cbCampoPedidos").clear();
	this.child("cbCampoPedidos").insertStringList(_i.aCamposPedidosV_);
}

function oficial_cbCampoPedidos_activated()
{
	//debug("valor combo: "+this.child("cbCampoPedidos").currentText);
	//debug("indice combo: "+this.child("cbCampoPedidos").currentItem);
	var indice = this.child("cbCampoPedidos").currentItem;
	this.child("tblPedidos").sortColumn(indice, true, true);
}

function oficial_leCampoPedidos_returnPressed()
{
	var _i = this.iface;
	var indice = this.child("cbCampoPedidos").currentItem;
	var valor = this.child("leCampoPedidos").text;
	var columna = _i.aColsPedidosV_[indice];
	var tipo = _i.aTiposPedidosV_[indice];
	var sF = "";

	if(valor && valor != "") {
		if(tipo == 3) {
			sF = "( upper("+columna  + ") like '%" + valor.upper() + "%' )";			
		} else {
			if(isNaN(valor)) {
				return ;
			}
			sF = "("+columna  + " = " + valor+ ")";
		}
		//debug("sF: "+sF);
	} 
	_i.tblPedidos_.setSearchFilter(sF, true); 
}

function oficial_rellenaComboClientes()
{

	//hayq ue rellenar el combo

	var _i = this.iface;
	var aCampos = _i.tblClientes_.getCabeceras();	
	var aColsN = _i.tblClientes_.getColsN();	
	var aMtd = _i.tblClientes_.getColsMtd();	
	//_i.aCamposClientesV_ = [];
	_i.aColsClientesV_ = [];
	_i.aTiposClientesV_ = [];
	for(var i = 0; i < aMtd.length; i++){	
		if(aMtd[i] == 19) {
			_i.aColsClientesV_.push(aColsN[i]);			 
			//_i.aCamposClientesV_.push(aCampos[i]);									
			_i.aTiposClientesV_.push(19);	
		}else {
			var visible = aMtd[i].visibleGrid();
			if(visible) {
				_i.aColsClientesV_.push(aColsN[i]);				
				//_i.aCamposClientesV_.push(aCampos[i]); 		
				_i.aTiposClientesV_.push(aMtd[i].type());			
			}				
		}	
		
	}	
	this.child("cbCampoClientes").clear();
	this.child("cbCampoClientes").insertStringList(_i.aCamposClientesV_);
}


function oficial_cbCampoClientes_activated()
{
	//debug("valor combo: "+this.child("cbCampoClientes").currentText);
	//debug("indice combo: "+this.child("cbCampoClientes").currentItem);
	var indice = this.child("cbCampoClientes").currentItem;
	this.child("tblClientes").sortColumn(indice, true, true);
}

function oficial_leCampoClientes_returnPressed()
{
	var _i = this.iface;
	var indice = this.child("cbCampoClientes").currentItem;
	var valor = this.child("leCampoClientes").text;
	var columna = _i.aColsClientesV_[indice];
	var tipo = _i.aTiposClientesV_[indice];
	var sF = "";

	if(valor && valor != "") {
		if(tipo == 3) {
			sF = "( upper("+columna  + ") like '%" + valor.upper() + "%' )";			
		} else {
			if(isNaN(valor)) {
				return ;
			}
			sF = "("+columna  + " = " + valor+ ")";
		}
		//debug("sF: "+sF);
	} 
	_i.tblClientes_.setSearchFilter(sF, true); 
}

function oficial_tbnHojaCompleta_clicked()
{
	var _i = this.iface;
	var f = this.child("tblClientes").currentRow(); 
	var idPedido = _i.tblClientes_.cellValue(f, "em_cargadropshipping.idpedido");
	var codigo = AQUtil.sqlSelect("pedidoscli", "codigo","idpedido = " + idPedido);
	formem_pedidosptes.iface.imprimirHojaCompleta(codigo);
}

function oficial_tbnImprimirPedido_clicked()
{
	var _i = this.iface;
	var f = this.child("tblClientes").currentRow(); 
	var idPedido = _i.tblClientes_.cellValue(f, "em_cargadropshipping.idpedido");
	var codigo = AQUtil.sqlSelect("pedidoscli", "codigo","idpedido = " + idPedido);
	formpedidoscli.iface.imprimir(codigo);
}

function oficial_tbnEtiqueta_clicked()
{
	var _i = this.iface;
	var f = this.child("tblClientes").currentRow(); 
	var idPedido = _i.tblClientes_.cellValue(f, "em_cargadropshipping.idpedido");
	var codigo = AQUtil.sqlSelect("pedidoscli", "codigo","idpedido = " + idPedido);
	formem_pedidosptes.iface.imprimirEtiqueta(codigo);
}

function oficial_imprimirCSVNoEnviadas()
{
	var _i =  this.iface;
	var tipo = "lineasConCero";
	var todas = this.child("chkExportarTodasDet").checked; 
	if(!_i.exportarCSV(tipo, todas)){
		return false;
	}

	return true;
}

function oficial_exportarCSV(tipo, todas)
{	
	var _i =  this.iface;
	var cursor = this.cursor();
	var curEnvio = this.child("tdbEnvios").cursor();

	var dialogo = new Dialog;
	dialogo.okButtonText = sys.translate("scripts", "Aceptar");
	dialogo.cancelButtonText = sys.translate("scripts", "Cancelar");

	var separador = new LineEdit;
	separador.label = "Separador:";
	separador.text = cursor.valueBuffer("camposeparador");

	dialogo.add(separador);

	if (!dialogo.exec()) {
		return false;
	}

	if (!separador.text) {
		sys.infoMsgBox(sys.translate("Indica un campo separador."));
		return _i.imprimirCSV(exportar);
	}

	var campoSep = separador.text;

	var nombreFichero = FileDialog.getSaveFileName("*.csv", sys.translate("scripts", "Indique el archivo csv a guardar"));
	if (!nombreFichero) {
		return;
	}

	var fichero = new File(nombreFichero + ".csv");
	fichero.open(File.WriteOnly);

	var qryAlb = _i.dameQueryExportar(cursor, curEnvio, tipo, todas);
	
	if(!qryAlb.exec()){
		return false;
	}

//debug(qryAlb.sql());
//debug("resultados: " + qryAlb.size());

	var select = qryAlb.select();
	var aCampos = select.split(",");
	var numCampos = aCampos.length;
	var linea;
	var cabecera = "PRIVALIA_SO_NUMBER;PRIVALIA_CUSTOMER;NAME_SURNAME;ADDRESS;LOCATION;STATE;ZIP_CODE;TELEPHONE_1;TELEPHONE_2;PRIVALIA_REFERENCE_STOCK;EAN;PRIVALIA_SKU;MATERIAL;UNIT_COST;TOTAL_COST;DESCRIPTION;UNIT_REQUESTED;UNIT_SERVED;CARRIER;TRACKING;CARRIER_INFO_1;CARRIER_INFO_2;CARRIER_INFO_3;CARRIER_INFO_4;CARRIER_INFO_5;COUNTRY";
	fichero.writeLine(cabecera);
	while (qryAlb.next()){	
		linea = "";
		for (var i = 0; i < numCampos; i++) {
			if(i == 13 ||  i == 14) {				
				linea += AQUtil.roundFieldValue(parseFloat(qryAlb.value(i)), "em_cargadropshipping", "costetotal");
			} else {
				linea += qryAlb.value(i);	
			}
			
			if(i<numCampos-1){
				linea += campoSep;
			}
		}
		linea = linea.replace("\n","");
		fichero.writeLine(linea);
	}
	fichero.close();

	MessageBox.information(sys.translate("scripts", "Fichero %1 generado correctamente").arg(fichero.name), MessageBox.Ok, MessageBox.NoButton);
	return true;
}

function oficial_dameQueryExportar(cursor, curEnvio, tipo, todas)
{
	var _i = this.iface;
	var qry = new FLSqlQuery;

	switch(tipo) {
		case "todasLineas": {
			var from, where;
			qry.setSelect("cd.pedidoprivalia,cd.cliente,cd.nombre,cd.direccion,cd.localidad,cd.provincia,cd.codpostal,cd.telefono1,cd.telefono2,cd.refstockprivalia,cd.ean,cd.sku,cd.articulo,cd.costeunitario,cd.costetotal,cd.descripcion,cd.unidadespedidas,cd.unidadesservidas,cd.carrier,cd.tracking,cd.infocarrier1,cd.infocarrier2,cd.infocarrier3,cd.infocarrier4,cd.infocarrier5,cd.pais");
			if(todas) {		
				qry.setFrom("em_cargadropshipping cd");
				qry.setWhere("cd.pedidoprivalia IN (SELECT cd2.pedidoprivalia from albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran INNER JOIN em_cargadropshipping cd2 ON l.idlineapedido = cd2.idlineapedido WHERE a.emcodenviodrop ='" + curEnvio.valueBuffer("emcodenviodrop") + "' AND a.em_coddropshipping = '" + cursor.valueBuffer("codigo") + "') ORDER BY cd.id");
			} else {
				qry.setFrom("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran INNER JOIN em_cargadropshipping cd ON l.idlineapedido = cd.idlineapedido");
				qry.setWhere("a.emcodenviodrop = '" + curEnvio.valueBuffer("emcodenviodrop") + "' AND a.em_coddropshipping = '" + cursor.valueBuffer("codigo") + "' order by cd.id");
			}
			
			/*qry.setFrom("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran INNER JOIN em_cargadropshipping cd ON l.idlineapedido = cd.idlineapedido");
			qry.setWhere("a.emcodenviodrop = '" + curEnvio.valueBuffer("emcodenviodrop") + "' AND a.em_coddropshipping = '" + cursor.valueBuffer("codigo") + "' order by cd.id");*/
 
			//debug("query ficha envios: "+qry.sql());
			break;
		} 
		case "lineasConCero": {
			var where = "cd.coddropshipping = '" + cursor.valueBuffer("codigo") + "'";
			if(!todas) {
				where += " AND cd.unidadesservidas = 0";
			} else {
				where += " AND cd.pedidoprivalia IN (SELECT cd2.pedidoprivalia from em_cargadropshipping cd2 WHERE cd2.coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND cd2.unidadesservidas = 0)";
			}
			qry.setSelect("cd.pedidoprivalia,cd.cliente,cd.nombre,cd.direccion,cd.localidad,cd.provincia,cd.codpostal,cd.telefono1,cd.telefono2,cd.refstockprivalia,cd.ean,cd.sku,cd.articulo,cd.costeunitario,cd.costetotal,cd.descripcion,cd.unidadespedidas,cd.unidadesservidas,cd.carrier,cd.tracking,cd.infocarrier1,cd.infocarrier2,cd.infocarrier3,cd.infocarrier4,cd.infocarrier5,cd.pais");
			qry.setFrom("em_cargadropshipping cd LEFT OUTER JOIN lineaspedidoscli l ON l.idlinea = cd.idlineapedido LEFT OUTER JOIN pedidoscli p ON p.idpedido = l.idpedido");
			//qry.setWhere("cd.coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND cd.unidadesservidas = 0 ORDER BY cd.id");
			qry.setWhere(where + " ORDER BY cd.id")

			//debug("query ficha pedidos detalle: "+qry.sql());
			break;
		} 
	}				

	return qry;
}

function oficial_calculateCounter()
{
	var codDS = formdat_procesosesp.iface.dameCodLote("DS");
	codDS = codDS.right(6)
	codDS = flfacturac.iface.pub_cerosIzquierda(codDS.toString(), 6);

	return codDS;
}

function oficial_dameAlmacenPedido(codCliente)
{
	var _i = this.iface;
	var codAlmacenCli = AQUtil.sqlSelect("clientes","codalmadeposito","codcliente = '" + codCliente + "'");
	if(codAlmacenCli && codAlmacenCli != "") {
		return codAlmacenCli;
	}
	return flfactppal.iface.pub_valorDefectoEmpresa("codalmacen");
}

function oficial_calcularTotales()
{
	var _i = this.iface;
	var cursor = this.cursor();
	this.child("fdbNumeroEnvios").setValue(_i.commonCalculateField("numeroenvios",cursor));
	this.child("fdbUnidadesServidas").setValue(_i.commonCalculateField("unidadesservidas",cursor));
	this.child("fdbUnidadesPendientes").setValue(_i.commonCalculateField("unidadespendientes",cursor));
	this.child("fdbNumLinParcial").setValue(_i.commonCalculateField("numlinparcial",cursor));	
	this.child("fdbNumLinCero").setValue(_i.commonCalculateField("numlincero",cursor));
	this.child("tdbCargaDropshipping").refresh();
	return true;
}

function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
  	var valor;

	var cx; try { cx = cursor.connectionName();} catch(e) { cx = ""; }
	if(fN == "numeroenvios") {
		valor = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran","count(distinct(a.idalbaran))","a.em_coddropshipping = '" + cursor.valueBuffer("codigo") + "'","albaranescli");
		if(!valor || valor == "") {
			valor = 0;
		}
	} else if(fN == "unidadesservidas") {
		valor = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran","SUM(l.cantidad)","a.em_coddropshipping = '" + cursor.valueBuffer("codigo") + "'","albaranescli");
		if(!valor || valor == "") {
			valor = 0;
		}
	} else if(fN == "unidadespendientes") {
		var codDrop = cursor.valueBuffer("codigo"); 
		var pedidasTotal = AQUtil.sqlSelect("pedidoscli p INNER JOIN lineaspedidoscli l ON l.idpedido = p.idpedido","SUM(l.cantidad)","p.em_coddropshipping = '" + codDrop + "'","pedidoscli");
		if(!pedidasTotal || pedidasTotal == "") {
			pedidasTotal = 0;
		}
		var servidasTotal = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran","SUM(l.cantidad)","a.em_coddropshipping = '" + codDrop + "'","albaranescli");
		if(!servidasTotal || servidasTotal == "") {
			servidasTotal = 0;
		}

		valor = parseFloat(pedidasTotal) - parseFloat(servidasTotal);
	} else if(fN == "numlinparcial") {
		valor = AQUtil.sqlSelect("em_cargadropshipping","COUNT(*)","coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND unidadesservidas <> 0 AND  unidadespedidas > unidadesservidas");
		if(!valor || valor == "") {
			valor = 0;
		}
	} else if(fN == "numlincero") {
		valor = AQUtil.sqlSelect("em_cargadropshipping","COUNT(*)","coddropshipping = '" + cursor.valueBuffer("codigo") + "' AND unidadesservidas = 0 ");
		if(!valor || valor == "") {
			valor = 0;
		}
	} else if(fN == "numeropedidos") {
		var codDrop = cursor.valueBuffer("codigo"); 
		valor = AQUtil.sqlSelect("pedidoscli p INNER JOIN lineaspedidoscli l ON l.idpedido = p.idpedido","count(distinct(p.idpedido))","p.em_coddropshipping = '" + codDrop + "'","pedidoscli");
		if(!valor || valor == "") {
			valor = 0;
		}
	}
	return valor;
}
//// OFICIAL  ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
