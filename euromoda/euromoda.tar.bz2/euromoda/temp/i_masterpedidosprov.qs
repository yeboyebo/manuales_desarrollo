
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////
class euromoda extends categorizacion {
	function euromoda( context ) { categorizacion ( context ); }
	function lanzar() {
		return this.ctx.euromoda_lanzar();
	}	
	function eliminarObserv(aPedidos) {
		return this.ctx.euromoda_eliminarObserv(aPedidos);
	}	
}
//// EUROMODA /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////
function euromoda_lanzar()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var oParam = _i.obtenerParamInforme();
	if (!oParam) {
		return;
	}
  	if (oParam.nombreInforme == "i_respedidosprov") {
  		return _i.__lanzar();
  	}
  	oParam.nombreReport = "i_pedidosprov_det";
	var idPedidoAnt;
	var idPedido, codigo, observaciones, observacionesAuto;
	var aPedidos = [];
	var oPedidos = new Object;
	var q = flfactinfo.iface.estableceConsulta(cursor, oParam);
	q.setOrderBy("pedidosprov.idpedido");
	debug("------ CONSULTA MASIVA ------- " + q.sql());
  	if (!q.exec()) {
    	sys.errorMsgBox(sys.translate("Ha fallado la consulta"));
    	return false;
  	} 
    while(q.next()) {
    	idPedido = q.value("pedidosprov.idpedido");
    	if(idPedidoAnt == "") {
    		idPedidoAnt = idPedido;
    	}
    	if(idPedidoAnt != idPedido) {
    		idPedidoAnt = idPedido;
    		aPedidos.push(idPedido);
    		observaciones = q.value("pedidosprov.observaciones");
   			observacionesAuto = q.value("pedidosprov.em_obsacabadoauto");

   			if(!observacionesAuto) {
				observacionesAuto = "";
			}		
    		observaciones += observacionesAuto == "" ? "" : "\n";
			observaciones += observacionesAuto;
			debug("observaciones: "+observaciones);
			formpedidosprov.iface.acabados(idPedido, observaciones);	
    	}   
    } 	
    debug("1");
  /*  if (oParam.nombreInforme != "i_respedidosprov") {
    	oParam.nombreReport = "i_pedidosprov_det";
    }*/


	oParam.orderBy = "pedidosprov.idpedido,lineaspedidosprov.numlinea, lineaspedidosprov.idlinea,em_acabadospedprov.id desc";

    flfactinfo.iface.pub_lanzaInforme(cursor, oParam);
    //_i.__lanzar();
    debug("2");
	_i.eliminarObserv(aPedidos);
	debug("3");
}

function euromoda_eliminarObserv(aPedidos)
{
	var _i = this.iface;
	var sPedidos = aPedidos.join(",")
	AQUtil.sqlDelete("em_acabadospedprov", "em_codacabado is null and idpedido IN (" + sPedidos + ")");
}

//// EUROMODA /////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
