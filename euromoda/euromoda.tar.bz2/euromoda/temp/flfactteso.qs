
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends modelo340 {
  function euromoda( context ) { modelo340 ( context ); }
  function fechaValorFacturaCli(curFactura) {
    return this.ctx.euromoda_fechaValorFacturaCli(curFactura);
  }
  function dameFechaEmisionProv(curFactura) {
    return this.ctx.euromoda_dameFechaEmisionProv(curFactura);
  }
  function siGenerarRecibosProv(curFactura, masCampos) {
    return this.ctx.euromoda_siGenerarRecibosProv(curFactura, masCampos);
  }
  function datosReciboCli(curFactura, oRecibo) {
    return this.ctx.euromoda_datosReciboCli(curFactura, oRecibo);
  }
  function datosReciboProv(curFactura, oRecibo) {
    return this.ctx.euromoda_datosReciboProv(curFactura, oRecibo);
  }
//   function generarPartidasCli(curPD, valoresDefecto, datosAsiento, recibo) {
//     return this.ctx.euromoda_generarPartidasCli(curPD, valoresDefecto, datosAsiento, recibo);
//   }
  function datosPartidaHaberAnticipo(curPartida, curA) {
    return this.ctx.euromoda_datosPartidaHaberAnticipo(curPartida, curA);
  }
  function generarPartidasProv(curPD, valoresDefecto, datosAsiento, recibo) {
    return this.ctx.euromoda_generarPartidasProv(curPD, valoresDefecto, datosAsiento, recibo);
  }
  function datosPartidaDebeAnticipoProv(curPartida, curA) {
    return this.ctx.euromoda_datosPartidaDebeAnticipoProv(curPartida, curA);
  }
  function actualizaSaldoCliente(curRA) {
    return this.ctx.euromoda_actualizaSaldoCliente(curRA);
  }
  function actualizaSaldoProveedor(curRA) {
    return this.ctx.euromoda_actualizaSaldoProveedor(curRA);
  }
  function datosPartidaPagoDevolCli(curPartida, curPD, valoresDefecto, datosAsiento, recibo) {
    return this.ctx.euromoda_datosPartidaPagoDevolCli(curPartida, curPD, valoresDefecto, datosAsiento, recibo);
  }
  function dameSubcuentaCliPD(curPD, valoresDefecto, datosAsiento, recibo) {
    return this.ctx.euromoda_dameSubcuentaCliPD(curPD, valoresDefecto, datosAsiento, recibo);
  }
  function cancelaReciboPartidaTR(curR, curP) {
    return this.ctx.euromoda_cancelaReciboPartidaTR(curR, curP);
  }
  function cancelaReciboProvPartidaTR(curR, curP) {
    return this.ctx.euromoda_cancelaReciboProvPartidaTR(curR, curP);
  }
  function cancelaAnticipoPartidaTR(curA, curP) {
    return this.ctx.euromoda_cancelaAnticipoPartidaTR(curA, curP);
  }
  function cancelaAnticipoProvPartidaTR(curA, curP) {
    return this.ctx.euromoda_cancelaAnticipoProvPartidaTR(curA, curP);
  }
  function cancelaPartidaPartidaTR(curP1, curP2) {
    return this.ctx.euromoda_cancelaPartidaPartidaTR(curP1, curP2);
  }
  function creaSaldoPartida(curPartida, curContrapartida, importe) {
    return this.ctx.euromoda_creaSaldoPartida(curPartida, curContrapartida, importe);
  }
  function desvincularReciboPartida(idRecibo, idPartida) {
    return this.ctx.euromoda_desvincularReciboPartida(idRecibo, idPartida);
  }
  function desvincularReciboProvPartida(idRecibo, idPartida) {
    return this.ctx.euromoda_desvincularReciboProvPartida(idRecibo, idPartida);
  }
  function datosReciboPos(curFactura) {
    return this.ctx.euromoda_datosReciboPos(curFactura);
  }
  function datosReciboNeg2(curFactura) {
    return this.ctx.euromoda_datosReciboNeg2(curFactura);
  }
  function calcularEstadoFacturaCli(idRecibo, idFactura) {
    return this.ctx.euromoda_calcularEstadoFacturaCli(idRecibo, idFactura);
  }
  function calcularEstadoFacturaProv(idRecibo, idFactura) {
    return this.ctx.euromoda_calcularEstadoFacturaProv(idRecibo, idFactura);
  }
  function regenerarRecibosCli(curFactura) {
    return this.ctx.euromoda_regenerarRecibosCli(curFactura);
  }
  function datosPartidaClienteRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa) {
    return this.ctx.euromoda_datosPartidaClienteRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa);
  }
  function datosPartidaProvRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa) {
    return this.ctx.euromoda_datosPartidaProvRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa);
  }
  function controlCompensacion(curFactura) {
  	return this.ctx.euromoda_controlCompensacion(curFactura);
  }
  function afterCommit_recibosprov(curR) {
  	return this.ctx.euromoda_afterCommit_recibosprov(curR);
  }
	function calcFechaVencimientoCli(curFactura, numPlazo, diasAplazado) {
		return this.ctx.euromoda_calcFechaVencimientoCli(curFactura, numPlazo, diasAplazado);
	}
	function fechaVencimientoEuromoda(fechaVencimiento, codCliente) {
		return this.ctx.euromoda_fechaVencimientoEuromoda(fechaVencimiento, codCliente);
	}
	function dameFechaVtoVacaciones(oParam) {
		return this.ctx.euromoda_dameFechaVtoVacaciones(oParam);
	}

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends pubAnticipos
{
  function pubEuromoda(context)
  {
    pubAnticipos(context);
  }
  function pub_cancelaReciboPartidaTR(curR, curP)
  {
    return this.cancelaReciboPartidaTR(curR, curP);
  }
  function pub_cancelaReciboProvPartidaTR(curR, curP)
  {
    return this.cancelaReciboProvPartidaTR(curR, curP);
  }
  function pub_cancelaAnticipoPartidaTR(curA, curP)
  {
    return this.cancelaAnticipoPartidaTR(curA, curP);
  }
  function pub_cancelaAnticipoProvPartidaTR(curA, curP)
  {
    return this.cancelaAnticipoProvPartidaTR(curA, curP);
  }
  function pub_cancelaPartidaPartidaTR(curP1, curP2)
  {
    return this.cancelaPartidaPartidaTR(curP1, curP2);
  }
  function pub_desvincularReciboPartida(idRecibo, idPartida)
  {
    return this.desvincularReciboPartida(idRecibo, idPartida);
  }
  function pub_desvincularReciboProvPartida(idRecibo, idPartida)
  {
    return this.desvincularReciboProvPartida(idRecibo, idPartida);
  }
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_fechaValorFacturaCli(curFactura)
{
  var f = curFactura.isNull("fechavalor") ? curFactura.valueBuffer("fecha") : curFactura.valueBuffer("fechavalor");
	return f;
}

function euromoda_dameFechaEmisionProv(curFactura)
{
  var f = curFactura.isNull("fechavalor") ? curFactura.valueBuffer("fecha") : curFactura.valueBuffer("fechavalor");
	return f;
}

function euromoda_siGenerarRecibosProv(curFactura, masCampos)
{
	var _i = this.iface;
	var aMasCampos = ["fechavalor"];
	return _i.__siGenerarRecibosProv(curFactura, aMasCampos);
}

function euromoda_datosReciboCli(curFactura, oRecibo)
{
	var _i = this.iface;
  if (!_i.__datosReciboCli(curFactura, oRecibo)) {
    return false;
  }
  this.iface.curReciboCli.setValueBuffer("em_codpago", curFactura.valueBuffer("em_codpago"));
  return true;
}

function euromoda_datosReciboProv(curFactura, oRecibo)
{
	var _i = this.iface;
  if (!_i.__datosReciboProv(curFactura, oRecibo)) {
    return false;
  }
  this.iface.curReciboProv.setValueBuffer("em_codpago", curFactura.valueBuffer("em_codpago"));
  return true;
}

/// A�ade el c�digo de cliente a la partida y cambia la forma de obtener la subcuenta de cliente
// function euromoda_generarPartidasCli(curPD, valoresDefecto, datosAsiento, recibo)
// {
// 	var util= new FLUtil();
// 	
// 	var haber= 0;
// 	var haberME= 0;
// 	var tasaconvHaber= 1;
// 
// 	if (valoresDefecto.coddivisa == recibo.coddivisa) {
// 		haber = recibo.importe;
// 		haberMe = 0;
// 	} else {
// 		tasaconvHaber = util.sqlSelect("reciboscli r INNER JOIN facturascli f ON r.idfactura = f.idfactura ", "tasaconv", "idrecibo = " + curPD.valueBuffer("idrecibo"), "reciboscli,facturascli");
// 		haber = parseFloat(recibo.importeeuros);
// 		haberME = parseFloat(recibo.importe);
// 	}
// 	haber = util.roundFieldValue(haber, "co_partidas", "haber");
// 	haberME = util.roundFieldValue(haberME, "co_partidas", "haberme");
// 	
// 	var esAbono= util.sqlSelect("reciboscli r INNER JOIN facturascli f ON r.idfactura = f.idfactura", "deabono", "idrecibo = " + curPD.valueBuffer("idrecibo"), "reciboscli,facturascli");
// 	var esPago= this.iface.esPagoEstePagoDevol(curPD);
// 	
// 	var curPartida= new FLSqlCursor("co_partidas");
// 	with(curPartida) {
// 		setModeAccess(curPartida.Insert);
// 		refreshBuffer();
// 		try {
// 			setValueBuffer("concepto", datosAsiento.concepto);
// 		} catch (e) {
// 			setValueBuffer("concepto", curPD.valueBuffer("tipo") + " recibo " + recibo.codigo + " - " + recibo.nombrecliente);
// 		}
// 		setValueBuffer("idsubcuenta", ctaHaber.idsubcuenta);
// 		setValueBuffer("codsubcuenta", ctaHaber.codsubcuenta);
// 		setValueBuffer("idasiento", datosAsiento.idasiento);
// 		if (esPago) {
// 			if (esAbono) {
// 				setValueBuffer("debe", haber * -1);
// 				setValueBuffer("haber", 0);
// 			} else {
// 				setValueBuffer("debe", 0);
// 				setValueBuffer("haber", haber);
// 			}
// 		} else {
// 			if (esAbono) {
// 				setValueBuffer("haber", haber * -1);
// 				setValueBuffer("debe", 0);
// 			} else {
// 				setValueBuffer("haber", 0);
// 				setValueBuffer("debe", haber);
// 			}
// 		}
// 		setValueBuffer("coddivisa", recibo.coddivisa);
// 		setValueBuffer("tasaconv", tasaconvHaber);
// 		setValueBuffer("debeME", 0);
// 		setValueBuffer("haberME", haberME);
// 		setValueBuffer("codcliente", recibo.codcliente);
// 	}
// 	if (!curPartida.commitBuffer())
// 		return false;
// 
// 	return true;
// }

function euromoda_datosPartidaHaberAnticipo(curPartida, curA)
{
	var _i = this.iface;
	if (!_i.__datosPartidaHaberAnticipo(curPartida, curA)) {
		return false;
	}
	curPartida.setValueBuffer("codcliente", curA.valueBuffer("codcliente"));
	return true;
}

function euromoda_datosPartidaDebeAnticipoProv(curPartida, curA)
{
	var _i = this.iface;
	if (!_i.__datosPartidaDebeAnticipoProv(curPartida, curA)) {
		return false;
	}
	curPartida.setValueBuffer("codproveedor", curA.valueBuffer("codproveedor"));
	return true;
}

/// A�ade el c�digo de proveedor a la partida
function euromoda_generarPartidasProv(curPD, valoresDefecto, datosAsiento, recibo)
{
	var util= new FLUtil();
	var ctaDebe= [];
	var codEjercicioFac:String;

	/** \C La cuenta del debe del asiento de pago ser� la misma cuenta de tipo PROVEE que se us� para realizar el asiento de la correspondiente factura
	\end */
	var idAsientoFactura= util.sqlSelect("recibosprov r INNER JOIN facturasprov f" + " ON r.idfactura = f.idfactura", "f.idasiento", "r.idrecibo = " + curPD.valueBuffer("idrecibo"), "facturasprov,recibosprov");
	if (!idAsientoFactura) {
		codEjercicioFac = false;
	} else {
		codEjercicioFac = util.sqlSelect("co_asientos", "codejercicio", "idasiento = " + idAsientoFactura);
	}
	var codProveedor= recibo["codproveedor"];
	/*if (codEjercicioFac == valoresDefecto.codejercicio) {
		ctaDebe.codsubcuenta = util.sqlSelect("co_subcuentasprov", "codsubcuenta", "codproveedor = '" + codProveedor + "' AND codejercicio = '" + codEjercicioFac + "'");
		if(!ctaDebe.codsubcuenta) {
			ctaDebe.codsubcuenta = util.sqlSelect("co_partidas p INNER JOIN co_subcuentas s ON p.idsubcuenta = s.idsubcuenta INNER JOIN co_cuentas c ON c.idcuenta = s.idcuenta", "s.codsubcuenta", "p.idasiento = " + idAsientoFactura + " AND c.idcuentaesp = 'PROVEE'", "co_partidas,co_subcuentas,co_cuentas");
		} else {
			ctaDebe.codsubcuenta = util.sqlSelect("co_partidas p INNER JOIN co_subcuentas s ON p.idsubcuenta = s.idsubcuenta", "s.codsubcuenta", "p.idasiento = " + idAsientoFactura + " AND s.codsubcuenta = '" + ctaDebe.codsubcuenta + "'", "co_partidas,co_subcuentas");
		}
		if (!ctaDebe.codsubcuenta) {
			MessageBox.warning(util.translate("scripts", "No se ha encontrado la subcuenta de proveedor del asiento contable correspondiente a la factura a pagar"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
			return false;
		}
	} else {*/
		if (codProveedor && codProveedor != "") {
			ctaDebe = flfactppal.iface.pub_datosCtaProveedor( codProveedor, valoresDefecto );
			if (!ctaDebe.codsubcuenta) {
				MessageBox.warning(util.translate("scripts", "El proveedor %1 no tiene definida ninguna subcuenta en el ejercicio %2.\nEspecifique la subcuenta en la pesta�a de contabilidad del formulario de proveedores").arg(codProveedor).arg(valoresDefecto.codejercicio), MessageBox.Ok, MessageBox.NoButton);
				return false;
			}
		} else {
			ctaDebe = flfacturac.iface.pub_datosCtaEspecial("PROVEE", valoresDefecto.codejercicio);
			if (!ctaDebe.codsubcuenta) {
				MessageBox.warning(util.translate("scripts", "No tiene definida ninguna cuenta de tipo PROVEE.\nDebe crear este tipo especial y asociarlo a una cuenta\nen el m�dulo principal de contabilidad"), MessageBox.Ok, MessageBox.NoButton);
				return false;
			}
		}
	//}

	ctaDebe.idsubcuenta = util.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + ctaDebe.codsubcuenta +  "' AND codejercicio = '" + valoresDefecto.codejercicio + "'");
	if (!ctaDebe.idsubcuenta) {
		MessageBox.warning(util.translate("scripts", "No existe la subcuenta ")  + ctaDebe.codsubcuenta + util.translate("scripts", " correspondiente al ejercicio ") + valoresDefecto.codejercicio + util.translate("scripts", ".\nPara poder realizar el pago debe crear antes esta subcuenta"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}

	var debe= 0;
	var debeME= 0;
	var tasaconvDebe= 1;
	
	if (valoresDefecto.coddivisa == recibo.coddivisa) {
		debe = parseFloat(recibo.importe);
		debeME = 0;
	} else {
		tasaconvDebe = util.sqlSelect("recibosprov r INNER JOIN facturasprov f ON r.idfactura = f.idfactura ", "tasaconv", "idrecibo = " + curPD.valueBuffer("idrecibo"), "recibosprov,facturasprov");
		debe = parseFloat(recibo.importeeuros);
		debeME = parseFloat(recibo.importe);
	}

	debe = util.roundFieldValue(debe, "co_partidas", "debe");
	debeME = util.roundFieldValue(debeME, "co_partidas", "debeme");
	var esAbono= util.sqlSelect("recibosprov r INNER JOIN facturasprov f ON r.idfactura = f.idfactura", "deabono", "idrecibo = " + curPD.valueBuffer("idrecibo"), "recibosprov,facturasprov");

	var curPartida= new FLSqlCursor("co_partidas");
	with(curPartida) {
		setModeAccess(curPartida.Insert);
		refreshBuffer();
		try {
			setValueBuffer("concepto", datosAsiento.concepto);
		} catch (e) {
			setValueBuffer("concepto", curPD.valueBuffer("tipo") + " recibo prov. " + recibo.codigo + " - " + recibo.nombreproveedor);
		}
		setValueBuffer("idsubcuenta", ctaDebe.idsubcuenta);
		setValueBuffer("codsubcuenta", ctaDebe.codsubcuenta);
		setValueBuffer("idasiento", datosAsiento.idasiento);
		if (esAbono) {
			setValueBuffer("debe", 0);
			setValueBuffer("haber", debe * -1);
		} else {
			setValueBuffer("debe", debe);
			setValueBuffer("haber", 0);
		}
		setValueBuffer("coddivisa", recibo.coddivisa);
		setValueBuffer("tasaconv", tasaconvDebe);
		setValueBuffer("debeME", debeME);
		setValueBuffer("haberME", 0);
		setValueBuffer("codproveedor", recibo.codproveedor);
	}
	if (!curPartida.commitBuffer())
		return false;

	return true;
}

function euromoda_actualizaSaldoCliente(curRA)
{
	var _i = this.iface;
	if (curRA.table() != "co_partidas") {
		return true;
	}
	return _i.__actualizaSaldoCliente(curRA);
}

function euromoda_actualizaSaldoProveedor(curRA)
{
	var _i = this.iface;
	if (curRA.table() != "co_partidas") {
		return true;
	}
	return _i.__actualizaSaldoProveedor(curRA);
}

function euromoda_datosPartidaPagoDevolCli(curPartida, curPD, valoresDefecto, datosAsiento, recibo)
{
	var _i = this.iface;
	if (!_i.__datosPartidaPagoDevolCli(curPartida, curPD, valoresDefecto, datosAsiento, recibo)) {
		return false;
	}
	if ("codcliente" in recibo) {
		curPartida.setValueBuffer("codcliente", recibo.codcliente);
	}
	return true;
}

function euromoda_cancelaReciboPartidaTR(curR, curP)
{
debug("euromoda_cancelaReciboPartidaTR 1");
  var _i = this.iface;
  var idRecibo = curR.valueBuffer("idrecibo");
  var idPartida = curP.valueBuffer("idpartida");
  var codCliente = curR.valueBuffer("codcliente");
  var importeR = curR.valueBuffer("importeeuros");
	var importeRME = curR.valueBuffer("importe");
  var importeP = parseFloat(curP.valueBuffer("importependiente"));
debug("importeP1 " + importeP);

	if (!_i.curReciboCli) {
		_i.curReciboCli = new FLSqlCursor("reciboscli");
	}
	if (curR.valueBuffer("codcliente") != curP.valueBuffer("codcliente")) {
		MessageBox.warning(sys.translate("Los clientes de recibo y partida no coinciden"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
  var curRecibo = _i.curReciboCli;
  curRecibo.select("idrecibo = " + idRecibo);
  if (!curRecibo.first()) {
    return false;
  }
  curRecibo.setModeAccess(curRecibo.Edit);
  curRecibo.refreshBuffer();
	var idFactura = curRecibo.valueBuffer("idfactura");
	var idRecibo = curRecibo.valueBuffer("idrecibo");
	var importeCancelado = importeR;
	importeP *= -1;
	importeP = AQUtil.roundFieldValue(importeP, "co_partidas", "debe");
	importeR = AQUtil.roundFieldValue(importeR, "co_partidas", "debe");
  	if (parseFloat(importeP) < parseFloat(importeR)) { /// parseFloat porque con importeA = 100.000 y importeR = 99.000 no va bien
		if (curR.isNull("idfactura")) {
			MessageBox.warning(sys.translate("El importe en Euros de la partida (%1) es menor que el del recibo %2 (%3). Dado que el recibo es agrupado, �ste no puede dividirse").arg(AQUtil.formatoMiles(AQUtil.roundFieldValue(importeP, "anticiposcli", "pendiente"))).arg(curRecibo.valueBuffer("codigo")).arg(AQUtil.formatoMiles(AQUtil.roundFieldValue(curRecibo.valueBuffer("importe"), "reciboscli", "importe"))), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		importeCancelado = importeP;
    var res = MessageBox.warning(sys.translate("Los importes de anticipo y partida no coinciden. El recibo se dividir�.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No);
    if (res != MessageBox.Yes) {
      return false;
    }
    var tasaConv = AQUtil.sqlSelect("facturascli", "tasaconv", "idfactura = " + curR.valueBuffer("idfactura"));
	tasaConv = isNaN(tasaConv) ? 1 : tasaConv;
    var importeME = importeP / tasaConv;
	importeME = AQUtil.roundFieldValue(importeME, "co_partidas", "debeme");
    curRecibo.setValueBuffer("importe", importeME);
	curRecibo.setValueBuffer("importesingd", importeME); /// importeP - curRecibo.valueBuffer("gastodevol")); /// Ext. gasto_devol_cli
    if (!formRecordreciboscli.iface.pub_divisionRecibo(curRecibo, importeRME)) {
      return false;
    }
  }
  importeCancelado *= -1;
	importeCancelado = AQUtil.roundFieldValue(importeCancelado, "co_partidas", "debe");
  var idSaldoPartida = _i.creaSaldoPartida(curP, curR, importeCancelado);
  if (!idSaldoPartida) {
		return false;
  }

  curRecibo.setValueBuffer("estado", "Pagado");
  curRecibo.setValueBuffer("em_idsaldopartida", idSaldoPartida);
  if (!flfactteso.iface.totalesReciboCli()) {
    return true;
  }
  if (!curRecibo.commitBuffer()) {
    return false;
  }
  if (!_i.calcularEstadoFacturaCli(idRecibo, idFactura)) {
		return false;
	}

  return true;
}

function euromoda_cancelaReciboProvPartidaTR(curR, curP)
{
debug("euromoda_cancelaReciboProvPartidaTR 1");
  var _i = this.iface;
  var idRecibo = curR.valueBuffer("idrecibo");
  var idPartida = curP.valueBuffer("idpartida");
  var codCliente = curR.valueBuffer("codcliente");
  var importeR = curR.valueBuffer("importeeuros");
	var importeRME = curR.valueBuffer("importe");
  var importeP = parseFloat(curP.valueBuffer("importependiente"));
	importeP = isNaN(importeP) ? 0 : importeP * -1;
	if (!_i.curReciboProv) {
		_i.curReciboProv = new FLSqlCursor("recibosprov");
	}
	if (curR.valueBuffer("codproveedor") != curP.valueBuffer("codproveedor")) {
		MessageBox.warning(sys.translate("Los proveedores de recibo y partida no coinciden"), MessageBox.Ok, MessageBox.NoButton);
		return false;
	}
  var curRecibo = _i.curReciboProv;
  curRecibo.select("idrecibo = " + idRecibo);
  if (!curRecibo.first()) {
    return false;
  }
  curRecibo.setModeAccess(curRecibo.Edit);
  curRecibo.refreshBuffer();
	var idFactura = curRecibo.valueBuffer("idfactura");
	var importeCancelado = importeR;
	importeP *= -1;
	importeP = AQUtil.roundFieldValue(importeP, "co_partidas", "debe");
  if (importeP < importeR) {
		importeCancelado = importeP;
    var res = MessageBox.warning(sys.translate("Los importes en Euros de recibo y partida no coinciden. El recibo se dividir�.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No);
    if (res != MessageBox.Yes) {
      return false;
    }
    var tasaConv = AQUtil.sqlSelect("facturasprov", "tasaconv", "idfactura = " + curR.valueBuffer("idfactura"));
		tasaConv = isNaN(tasaConv) ? 1 : tasaConv;
    var importeME = importeP / tasaConv;
		importeME = AQUtil.roundFieldValue(importeME, "co_partidas", "debeme");
    curRecibo.setValueBuffer("importe", importeME);
		curRecibo.setValueBuffer("importesingd", importeME); /// importeP - curRecibo.valueBuffer("gastodevol")); /// Ext. gasto_devol_cli
		
    if (!formRecordrecibosprov.iface.pub_divisionRecibo(curRecibo, importeR)) {
      return false;
    }
  }
  var idSaldoPartida = _i.creaSaldoPartida(curP, curR, importeCancelado);
  if (!idSaldoPartida) {
		return false;
  }

  curRecibo.setValueBuffer("estado", "Pagado");
  curRecibo.setValueBuffer("em_idsaldopartida", idSaldoPartida);
  if (!flfactteso.iface.totalesReciboProv()) {
    return true;
  }
  if (!curRecibo.commitBuffer()) {
    return false;
  }
  if (!_i.calcularEstadoFacturaProv(false, idFactura)) {
		return false;
	}

  return true;
}

function euromoda_cancelaAnticipoPartidaTR(curA, curP)
{
  var _i = this.iface;
  var idAnticipo = curA.valueBuffer("idanticipo");
  var idPartida = curP.valueBuffer("idpartida");
  var codCliente = curA.valueBuffer("codcliente");
  var importeA = curA.valueBuffer("pendienteeuros");
  var importeP = parseFloat(curP.valueBuffer("importependiente"));
	var importeCancelado = (importeP < importeA) ? importeP : importeA;
  var idSaldoPartida = _i.creaSaldoPartida(curP, curA, importeCancelado);
  if (!idSaldoPartida) {
		return false;
  }
  return true;
}

function euromoda_cancelaAnticipoProvPartidaTR(curA, curP)
{
  var _i = this.iface;
  var idAnticipo = curA.valueBuffer("idanticipo");
  var idPartida = curP.valueBuffer("idpartida");
  var codProveedor = curA.valueBuffer("codproveedor");
  var importeA = curA.valueBuffer("pendienteeuros");
  var importeP = parseFloat(curP.valueBuffer("importependiente"));
	importeP = isNaN(importeP) ? 0 : importeP * -1;
	var importeCancelado = (importeP < importeA) ? importeP * -1 : importeA * -1;
  var idSaldoPartida = _i.creaSaldoPartida(curP, curA, importeCancelado);
  if (!idSaldoPartida) {
		return false;
  }
  return true;
}

function euromoda_cancelaPartidaPartidaTR(curP1, curP2)
{
  var _i = this.iface;
  var idPartida1 = curP1.valueBuffer("idpartida");
  var idPartida1 = curP2.valueBuffer("idpartida");
//   var codCliente = curP1.valueBuffer("codcliente");
// 	var codProveedor = curP1.valueBuffer("codproveedor");
  var importeP1 = parseFloat(curP1.valueBuffer("importependiente"));
  var importeP2 = parseFloat(curP2.valueBuffer("importependiente"));
	if ((importeP1 > 0 && importeP2 > 0) || (importeP1 < 0 && importeP2 < 0)) {
		MessageBox.warning(sys.translate("Debe cancelar una partida positiva con una negativa"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	var importeCancelado, idSaldoPartida;
	if (importeP1 > 0) {
		importeP2 *= -1;
		importeP2 = AQUtil.roundFieldValue(importeP2, "co_partidas", "debe");
		importeCancelado = (importeP1 < importeP2) ? importeP1 : importeP2;
		idSaldoPartida = _i.creaSaldoPartida(curP1, curP2, importeCancelado);
	} else {
		importeP1 *= -1;
		importeP1 = AQUtil.roundFieldValue(importeP1, "co_partidas", "debe");
		importeCancelado = (importeP1 < importeP2) ? importeP1 : importeP2;
		idSaldoPartida = _i.creaSaldoPartida(curP2, curP1, importeCancelado);
	}
  if (!idSaldoPartida) {
		return false;
  }
  return true;
}

function euromoda_creaSaldoPartida(curPartida, curContrapartida, importe)
{
	var _i = this.iface;
	var hoy = new Date;
	var curSP = new FLSqlCursor("co_em_saldopartidas");
	curSP.setModeAccess(curSP.Insert);
	curSP.refreshBuffer();
	curSP.setValueBuffer("idpartida1", curPartida.valueBuffer("idpartida"));
	importe = AQUtil.roundFieldValue(importe, "co_em_saldopartidas", "importe");
	curSP.setValueBuffer("importe", importe);
	curSP.setValueBuffer("fecha", hoy.toString().left(10));
	var qAsiento = new FLSqlQuery;
	qAsiento.setSelect("codejercicio, numero");
	qAsiento.setFrom("co_asientos");
	qAsiento.setWhere("idasiento = " + curPartida.valueBuffer("idasiento"));
	if (!qAsiento.exec()) {
		return false;
	}
	if (!qAsiento.first()) {
		return false;
	}
	var codEjercicio = qAsiento.value("codejercicio");
	var numero = qAsiento.value("numero");
	switch (curContrapartida.table()) {
		case "reciboscli": {
			curSP.setValueBuffer("codcliente", curContrapartida.valueBuffer("codcliente"));
			curSP.setValueBuffer("idrecibocli", curContrapartida.valueBuffer("idrecibo"));
			curSP.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Recibo cliente %3").arg(codEjercicio).arg(numero).arg(curContrapartida.valueBuffer("codigo")));
			break;
		}
		case "recibosprov": {
			curSP.setValueBuffer("codproveedor", curContrapartida.valueBuffer("codproveedor"));
			curSP.setValueBuffer("idreciboprov", curContrapartida.valueBuffer("idrecibo"));
			curSP.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Recibo proveedor %3").arg(codEjercicio).arg(numero).arg(curContrapartida.valueBuffer("codigo")));
			break;
		}
		case "anticiposcli": {
			curSP.setValueBuffer("codcliente", curContrapartida.valueBuffer("codcliente"));
			curSP.setValueBuffer("idanticipocli", curContrapartida.valueBuffer("idanticipo"));
			curSP.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Anticipo cliente %3").arg(codEjercicio).arg(numero).arg(curContrapartida.valueBuffer("codigo")));
			break;
		}
		case "anticiposprov": {
			curSP.setValueBuffer("codproveedor", curContrapartida.valueBuffer("codproveedor"));
			curSP.setValueBuffer("idanticipoprov", curContrapartida.valueBuffer("idanticipo"));
			curSP.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Anticipo proveedor %3").arg(codEjercicio).arg(numero).arg(curContrapartida.valueBuffer("codigo")));
			break;
		}
		case "co_partidas": {
			curSP.setValueBuffer("codcliente", curContrapartida.valueBuffer("codcliente"));
			curSP.setValueBuffer("codproveedor", curContrapartida.valueBuffer("codproveedor"));
			qAsiento.setWhere("idasiento = " + curContrapartida.valueBuffer("idasiento"));
			if (!qAsiento.exec()) {
				return false;
			}
			if (!qAsiento.first()) {
				return false;
			}
			var codEjercicio2 = qAsiento.value("codejercicio");
			var numero2 = qAsiento.value("numero");
			curSP.setValueBuffer("idpartida2", curContrapartida.valueBuffer("idpartida"));
			curSP.setValueBuffer("concepto", sys.translate("Asiento %1/%2 - Asiento %3/4").arg(codEjercicio).arg(numero).arg(codEjercicio2).arg(numero2));
			break;
		}
	}
	if (!curSP.commitBuffer()) {
		return false;
	}
	return curSP.valueBuffer("idsaldo");
}

function euromoda_desvincularReciboPartida(idRecibo, idPartida)
{
  var _i = this.iface;
  if (!_i.curReciboCli) {
    _i.curReciboCli = new FLSqlCursor("reciboscli");
  }
  _i.curReciboCli.select("idrecibo = " + idRecibo);
  if (!_i.curReciboCli.first()) {
    return true;
  }
  _i.curReciboCli.setModeAccess(_i.curReciboCli.Edit);
  _i.curReciboCli.refreshBuffer();
	var idFactura = _i.curReciboCli.valueBuffer("idfactura");
	var idRecibo = _i.curReciboCli.valueBuffer("idrecibo");
  if (idPartida != _i.curReciboCli.valueBuffer("em_idsaldopartida")) {
    return false;
  }
  _i.curReciboCli.setValueBuffer("em_idsaldopartida", 0);
  _i.curReciboCli.setValueBuffer("estado", "Emitido");
  if (!_i.totalesReciboCli()) {
    return false;
  }
  if (!_i.curReciboCli.commitBuffer()) {
    return false;
  }
  if (!_i.calcularEstadoFacturaCli(idRecibo, idFactura)) {
		return false;
	}
  return true;
}

function euromoda_desvincularReciboProvPartida(idRecibo, idPartida)
{
  var _i = this.iface;
  if (!_i.curReciboProv) {
    _i.curReciboProv = new FLSqlCursor("recibosprov");
  }
  _i.curReciboProv.select("idrecibo = " + idRecibo);
  if (!_i.curReciboProv.first()) {
    return true;
  }
  _i.curReciboProv.setModeAccess(_i.curReciboProv.Edit);
  _i.curReciboProv.refreshBuffer();
	var idFactura = _i.curReciboProv.valueBuffer("idfactura");
  if (idPartida != _i.curReciboProv.valueBuffer("em_idsaldopartida")) {
    return false;
  }
  _i.curReciboProv.setValueBuffer("em_idsaldopartida", 0);
  _i.curReciboProv.setValueBuffer("estado", "Emitido");
  if (!_i.totalesReciboProv()) {
    return false;
  }
  if (!_i.curReciboProv.commitBuffer()) {
    return false;
  }
  if (!_i.calcularEstadoFacturaProv(false, idFactura)) {
		return false;
	}
  return true;
}

function euromoda_datosReciboPos(curFactura)
{
	var _i = this.iface;
	if (!_i.__datosReciboPos(curFactura)) {
		return false;
	}
	_i.curReciboPos.setValueBuffer("em_codpago", curFactura.valueBuffer("em_codpago"));
	return true;
}

function euromoda_datosReciboNeg2(curFactura)
{
	var _i = this.iface;
	if (!_i.__datosReciboNeg2(curFactura)) {
		return false;
	}
	_i.curReciboNeg2.setValueBuffer("em_codpago", curFactura.valueBuffer("em_codpago"));
	return true;
}

function euromoda_calcularEstadoFacturaCli(idRecibo, idFactura)
{
	var _i = this.iface;
	if (!idFactura) {
		idFactura = AQUtil.sqlSelect("reciboscli", "idfactura", "idrecibo = " + idRecibo);
		if (!idFactura) { /// Recibo agrupado
			return true;
		}
	}
  
	if (!AQUtil.sqlSelect("reciboscli", "idrecibo", "idfactura = " + idFactura + " AND estado = 'Pagado' AND em_idsaldopartida <> 0")) {
		return _i.__calcularEstadoFacturaCli(idRecibo, idFactura);
	}
	var curFactura = new FLSqlCursor("facturascli");
	curFactura.select("idfactura = " + idFactura);
	curFactura.first();
	curFactura.setUnLock("editable", false);
	return true;
}

function euromoda_calcularEstadoFacturaProv(idRecibo, idFactura)
{
	var _i = this.iface;
	if (!idFactura) {
		idFactura = AQUtil.sqlSelect("recibosprov", "idfactura", "idrecibo = " + idRecibo);
	}
  
	/*if (!AQUtil.sqlSelect("recibosprov", "idrecibo", "idfactura = " + idFactura + " AND estado = 'Pagado' AND em_idsaldopartida <> 0")) {*/
	
	if (!AQUtil.sqlSelect("recibosprov", "idrecibo", "idfactura = " + idFactura + " AND ((estado = 'Pagado' AND em_idsaldopartida <> 0) OR (estado = 'Compensado'))")) {	
	
		return _i.__calcularEstadoFacturaProv(idRecibo, idFactura);
	}
	
	var curFactura = new FLSqlCursor("facturasprov");
	curFactura.select("idfactura = " + idFactura);
	curFactura.first();
	curFactura.setUnLock("editable", false);
	return true;
}

function euromoda_regenerarRecibosCli(curFactura)
{
	var _i = this.iface;
	if (!_i.__regenerarRecibosCli(curFactura)) {
		return false;
	}
	var vencimientos = formfacturascli.iface.pub_commonCalculateField("em_vencimientos", curFactura);
	var curF = new FLSqlCursor("facturascli");
	curF.setActivatedCommitActions(false);
	curF.setActivatedCheckIntegrity(false);
	
	var idFactura = curFactura.valueBuffer("idfactura");
	curF.select("idfactura = " + idFactura);
	if (!curF.first()) {
		return false;
	}
	var editable = curF.valueBuffer("editable");
	if (!editable) {
		curF.setUnLock("editable", true);
		curF.select("idfactura = " + idFactura);
		if (!curF.first()) {
			return false;
		}
	}
	curF.setModeAccess(curFactura.Edit);
	curF.refreshBuffer();
	curF.setValueBuffer("em_vencimientos", vencimientos);
	if (!curF.commitBuffer()) {
		return false;
	}
	if (!editable) {
		curF.select("idfactura = " + idFactura);
		if (!curF.first()) {
			return false;
		}
		curF.setUnLock("editable", false);
	}
	return true;
}

function euromoda_datosPartidaClienteRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa)
{
	var _i = this.iface;
	if (!_i.__datosPartidaClienteRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa)) {
		return false;
	}
	var codCliente = AQUtil.sqlSelect("reciboscli", "codcliente", "idrecibo = " + curPD.valueBuffer("idrecibo"));
	curPartida.setValueBuffer("codcliente", codCliente);
	return true;
}

function euromoda_datosPartidaProvRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa)
{
	var _i = this.iface;
	if (!_i.__datosPartidaProvRem(curPartida, curPD, valoresDefecto, datosAsiento, remesa)) {
		return false;
	}
	var codProveedor = AQUtil.sqlSelect("recibosprov", "codproveedor", "idrecibo = " + curPD.valueBuffer("idrecibo"));
	curPartida.setValueBuffer("codproveedor", codProveedor);
	return true;
}

function euromoda_dameSubcuentaCliPD(curPD, valoresDefecto, datosAsiento, recibo)
{
	var oSubcuenta = new Object;
	var codCliente = AQUtil.sqlSelect("reciboscli", "codcliente", "idrecibo = " + curPD.valueBuffer("idrecibo"));
	if (!codCliente) {
		return false;
	}
	oSubcuenta.codsubcuenta = AQUtil.sqlSelect("clientes c INNER JOIN gruposcontablescli g ON c.codgrupocontablecli = g.codgrupo", "g.codsubcuentacli", "c.codcliente = '" + codCliente + "'", "clientes");
	if (!oSubcuenta.codsubcuenta) {
		MessageBox.warning(sys.translate("No es posible encontrar la subcuenta de cliente asociada al cliente %1.\nVerifique que su grupo de contable cliente est� correctamente asignado").arg(codCliente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	oSubcuenta.idsubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + oSubcuenta.codsubcuenta + "' AND codejercicio = '" + valoresDefecto.codejercicio + "'");
	if (!oSubcuenta.idsubcuenta) {
		MessageBox.warning(sys.translate("No existe la subcuenta %1 correspondiente al ejercicio.\nPara poder realizar el pago debe crear antes esta subcuenta.").arg(oSubcuenta.codsubcuenta).arg(valoresDefecto.codejercicio), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return oSubcuenta;
}

function euromoda_controlCompensacion(curFactura)
{
	//#bloqueo facturas por serie
	var _i = this.iface;

	var codCliente = curFactura.valueBuffer("codcliente");
	if (!codCliente || codCliente == "") {
		return true;
	}
	
	var totalF = curFactura.valueBuffer("total");
	if (totalF == 0) {
		return true;
	}
	
	if (curFactura.transactionLevel() > 0) {
		curFactura.commit(); 
		curFactura.transaction(false);
	}
	if(!_i.__controlCompensacion(curFactura)) {
		return false;
	}
	return true;
}


function euromoda_afterCommit_recibosprov(curR)
{
	var _i = this.iface;

	if (!_i.__afterCommit_recibosprov(curR)) {
		return false;
	}

	switch(curR.modeAccess()) {
		case curR.Insert:
		case curR.Edit: {
			if (curR.valueBuffer("estado") == "Compensado" || curR.valueBufferCopy("estado") == "Compensado") {
				if (!_i.calcularEstadoFacturaProv(curR.valueBuffer("idrecibo")))
					return false;
			}
		break;
		}
		case curR.Del: {
			if (curR.valueBuffer("estado") == "Compensado") {
				if (!_i.calcularEstadoFacturaProv(curR.valueBuffer("idrecibo")))
					return false;
					
				if (parseFloat(curR.valueBuffer("importe")) < 0) {
					var codReciboComp = AQUtil.sqlSelect("recibosprov", "codigo", "idrecibo = " + curR.valueBuffer("idrecibocomp"));
					var res = MessageBox.warning(sys.translate("Va a borrar el recibo ") + curR.valueBuffer("codigo") + sys.translate(" que est� compensado con el recibo ") + codReciboComp + sys.translate("\nEl recibo compensado pasar� a estado Emitido. �Desea continuar?"), MessageBox.Yes, MessageBox.No)
					if (res != MessageBox.Yes)
						return false;
				}
				if (!AQUtil.sqlUpdate("recibosprov", "estado,idrecibocomp", "Emitido,NULL", "idrecibo = " + curR.valueBuffer("idrecibocomp")))
					return false;
			}
			break;
		}
	}
	return true;
}

function euromoda_calcFechaVencimientoCli(curFactura, numPlazo, diasAplazado)
{

	var _i = this.iface;

	//OFICIAL
	var fechaVencimiento = _i.fechaValorFacturaCli(curFactura);	
	fechaVencimiento =  AQUtil.addDays(fechaVencimiento, diasAplazado);

	//DIAS PAGO
	var codCliente = curFactura.valueBuffer("codcliente");
	if (!codCliente || codCliente == "") {
		return fechaVencimiento;
	}

	return _i.fechaVencimientoEuromoda(fechaVencimiento, codCliente);
}

function euromoda_fechaVencimientoEuromoda(fechaVencimiento, codCliente)
{
	var _i = this.iface;	
	var diasPago;
	var f = fechaVencimiento;
	var cadenaDiasPago = AQUtil.sqlSelect("clientes", "diaspago", "codcliente = '" + codCliente + "'");
	if (!cadenaDiasPago || cadenaDiasPago == "") {
		diasPago = "";
	} else {
		diasPago = cadenaDiasPago.split(",");
	}

	var vacDesde = AQUtil.sqlSelect("clientes", "vacdesde", "codcliente = '" + codCliente + "'");
	var vacHasta = AQUtil.sqlSelect("clientes", "vachasta", "codcliente = '" + codCliente + "'");
	var oParam = new Object;
	oParam["vacDesde"] = vacDesde;
	oParam["vacHasta"] = vacHasta;
	oParam["codCliente"] = codCliente;
	if(!diasPago || diasPago == "") {	
		if(vacDesde && vacDesde != "") {
			oParam["fechaVencimiento"] = fechaVencimiento;
			oParam["diasPago"] = "";			
			fechaVencimiento = _i.dameFechaVtoVacaciones(oParam);
		}

	} else {

		var buscarDia = AQUtil.sqlSelect("clientes", "buscardia", "codcliente = '" + codCliente + "'");
		if (buscarDia == "Anterior") {
			fechaVencimiento = _i.procesarDiasPagoCliAnt(f, diasPago);
			if (AQUtil.daysTo(fechaVencimiento, fechaFactura) > 0) {
				fechaVencimiento = _i.procesarDiasPagoCli(f, diasPago);
			}
		} else {
			fechaVencimiento = _i.procesarDiasPagoCli(f, diasPago);
		}
		if(vacDesde && vacDesde != "") {
			oParam["fechaVencimiento"] = fechaVencimiento;
			oParam["diasPago"] = diasPago;
			fechaVencimiento = _i.dameFechaVtoVacaciones(oParam);
		}

	}	
	return fechaVencimiento;

}

function euromoda_dameFechaVtoVacaciones(oParam)
{
	var _i = this.iface;
	var fechaVencimiento = oParam["fechaVencimiento"];
	var vacDesde = oParam["vacDesde"];
	var vacHasta = oParam["vacHasta"];
	var diasPago = oParam["diasPago"]; 
	var codCliente = oParam["codCliente"];  

	var fechaV = new Date (Date.parse(fechaVencimiento.toString()));
	var diaMesDesde = vacDesde.split("-");
	var diaMesHasta = vacHasta.split("-");
	var annoDesde, annoHasta;
	var diaV = fechaV.getDate();
	var mesV = fechaV.getMonth();
	var annoV = fechaV.getYear();

	annoDesde = annoV;
	if (parseFloat(diaMesHasta[1]) >= parseFloat(diaMesDesde[1])) {
		annoHasta = annoDesde;
	} else {
		annoHasta = annoDesde + 1;
	}

	var fechaDesde = annoDesde + "-" + diaMesDesde[1] + "-" + diaMesDesde[0];
	var fechaHasta = annoHasta + "-" + diaMesHasta[1] + "-" + diaMesHasta[0];

	// Comprobaci�n de si la fecha de vencimiento cae en el intervalo de vacaciones. Si no es as�, la fecha de vencimiento sigue igual
	if (AQUtil.daysTo(fechaVencimiento, fechaDesde) > 0) {
		return fechaVencimiento;
	}
	if (AQUtil.daysTo(fechaHasta, fechaVencimiento) >= 0) {
		return fechaVencimiento;
	}

	//si cae en periodo vacacional, le sumamos un mes y volvemos a mirar por si cae en otro periodo vacacional
	var fechaResultado;
	if(!diasPago || diasPago == "") {
		fechaResultado = AQUtil.addMonths(fechaVencimiento, 1);	
	} else {
		fechaVencimiento = AQUtil.addDays(fechaHasta, 1);
		fechaResultado = _i.fechaVencimientoEuromoda(fechaVencimiento, codCliente);
	}
	oParam["fechaVencimiento"] = fechaResultado;
	return _i.dameFechaVtoVacaciones(oParam);	
}


//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
