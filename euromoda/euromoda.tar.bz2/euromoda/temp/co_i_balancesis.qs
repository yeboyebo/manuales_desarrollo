
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var bloqueoCliProv_;
  function euromoda( context ) { oficial ( context ); }
  function habilitaPorCliProv() {
		return this.ctx.euromoda_habilitaPorCliProv();
	}
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function init() {
		return this.ctx.euromoda_init();
	}
	function validaFechas() {
		return this.ctx.euromoda_validaFechas();
	}
	function desactivarPorCliProv() {
		return this.ctx.euromoda_desactivarPorCliProv();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
debug("euromoda_init");
	var _i = this.iface;
	_i.__init();
	
	_i.bloqueoCliProv_ = false;
	_i.habilitaPorCliProv();
}

function euromoda_bufferChanged(fN)
{
debug("euromoda_bufferChanged " + fN);
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "clientes": {
			if (!_i.bloqueoCliProv_) {
				_i.bloqueoCliProv_ = true;
				_i.desactivarPorCliProv();
				sys.setObjText(this, "fdbProveedores", false);
				_i.habilitaPorCliProv();
				_i.bloqueoCliProv_ = false;
			}
			break;
		}
		case "proveedores": {
			if (!_i.bloqueoCliProv_) {
				_i.bloqueoCliProv_ = true;
				_i.desactivarPorCliProv();
				sys.setObjText(this, "fdbClientes", false);
				_i.habilitaPorCliProv();
				_i.bloqueoCliProv_ = false;
			}
			break;
		}
		default: {
			try { _i.__bufferChanged(fN); } catch(e) {}
		}
	}
}

function euromoda_desactivarPorCliProv()
{
	var cursor = this.cursor();
	if (cursor.valueBuffer("clientes") || cursor.valueBuffer("proveedores")) {
		cursor.setValueBuffer("todassubcuentas", false);
		cursor.setValueBuffer("todassubcuentas", true);
		cursor.setValueBuffer("ejercicioanterior", false);
		cursor.setValueBuffer("resumido", false);
		cursor.setValueBuffer("ignorarcierre", false);
		cursor.setValueBuffer("ignorarapertura", false);
		cursor.setValueBuffer("saldoinicial", false);
	}
}

function euromoda_habilitaPorCliProv()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var habilita = !(cursor.valueBuffer("clientes") || cursor.valueBuffer("proveedores"));
	if (this.child("groupBox3")) { 
		this.child("groupBox3").enabled = habilita; 
	}
	if (this.child("gbxNivel")) { 
		this.child("gbxNivel").enabled = habilita; 
	}
	if (this.child("gbEjAnt")) { 
		this.child("gbEjAnt").enabled = habilita; 
	}
	if (habilita) {
		sys.enableObj(this, "fdbIgnorarCierre");
		sys.enableObj(this, "fdbIgnorarApertura");
		sys.enableObj(this, "fdbSaldoInicial");
	} else {
		sys.disableObj(this, "fdbIgnorarCierre");
		sys.disableObj(this, "fdbIgnorarApertura");
		sys.disableObj(this, "fdbSaldoInicial");
	}
	
	var clienteHabilitado = cursor.valueBuffer("clientes");
	this.child("fdbCodCliente").setDisabled(!clienteHabilitado);
	this.child("fdbCodGrupoContableCli").setDisabled(!clienteHabilitado);
	if(!clienteHabilitado){
		sys.setObjText(this, "fdbCodCliente", "");
		sys.setObjText(this, "fdbCodGrupoContableCli", "");
	}
	
	var proveedorHabilitado = cursor.valueBuffer("proveedores");
	this.child("fdbCodProveedor").setDisabled(!proveedorHabilitado);
	this.child("fdbCodGrupoContableProv").setDisabled(!proveedorHabilitado);
	if(!proveedorHabilitado){
		sys.setObjText(this, "fdbCodProveedor", "");
		sys.setObjText(this, "fdbCodGrupoContableProv", "");
	}
}

function euromoda_validaFechas()
{
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
