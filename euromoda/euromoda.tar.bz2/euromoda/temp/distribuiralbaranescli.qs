
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function ponValorPorcentaje() {
		return this.ctx.euromoda_ponValorPorcentaje();
	}
	function pbnCalcular_clicked() {
		return this.ctx.euromoda_pbnCalcular_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_ponValorPorcentaje()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var p = cursor.valueBuffer("emcatservicio");
	p = isNaN(p) ? 0 : p;
	this.child("txtPorcentaje").setText(p);
	if (_i.t_.numRows() <= 12) {
		_i.pbnCalcular_clicked();
	}
}

function euromoda_pbnCalcular_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var t = _i.t_;
	var nF = t.numRows();
	
	_i.comprobarNumero();
	var porcentaje = parseFloat(this.child("txtPorcentaje").text);
	if(porcentaje <= 0){
		return;
	}
	var numL = nF - 2;
	var canDis, cantidad;
	for (var f = 0; f < numL; f++) {
		cantidad = parseFloat(t.text(f, _i.cCAN));
		canDis = Math.floor(cantidad * porcentaje / 100);
		t.setText(f, _i.cDIS, canDis);
		_i.tblLineas_valueChanged(f, _i.cDIS);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
