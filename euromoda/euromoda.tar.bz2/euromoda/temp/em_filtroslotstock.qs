/***************************************************************************
                 em_filtroslotstock.qs  -  description
                             -------------------
    begin                : mie nov 23 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  var valorComboFiltro_;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	
	function oficial(context)
	{
		interna(context);
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function construirFiltro(cursor) {
		return this.ctx.oficial_construirFiltro(cursor);
	}
	function construirFiltroVista(cursor) {
		return this.ctx.oficial_construirFiltroVista(cursor);
	}
	function tbnLimpiarFiltro_clicked() {
		return this.ctx.oficial_tbnLimpiarFiltro_clicked();
	}
	function limpiarFiltro(form) {
		return this.ctx.oficial_limpiarFiltro(form);
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
  function pub_construirFiltro(cursor) {
		return this.construirFiltro(cursor);
	}
	function pub_limpiarFiltro(form) {
		return this.limpiarFiltro(form);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;

	connect(this.cursor(), "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");

	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");	
	debug("valor master: "+_i.valorComboFiltro_);
	this.child("cbOpcionEM").currentText = _i.valorComboFiltro_;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
/*function oficial_construirFiltro(cursor)
{
	var filtro = "";

	var referencia = cursor.valueBuffer("referencia");
	if (referencia && referencia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (referencia.find(",") >= 0) {
			filtro += ("articulos.referencia IN ('" + referencia.split(",").join("', '") + "')");
		} else {
			if (referencia.find("-") >= 0) {
				var min = referencia.split("-")[0];
				var max = referencia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.referencia SIMILAR TO '[0-9]+' AND CAST(articulos.referencia AS INTEGER) BETWEEN '" + min + "' AND '" + max + "'");
				}
			} else {
				filtro += "articulos.referencia = '" + referencia + "'";
			}
		}
	}

	var tamano = cursor.valueBuffer("codtamanoem");
	if(tamano && tamano != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.codtamanoem = '" + tamano + "'";
	}

	var color = cursor.valueBuffer("codcolorem");
	if(color && color != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.codcolorem = '" + color + "'";
	}

	var familia = cursor.valueBuffer("codfamilia");
	if (familia && familia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (familia.find(",") >= 0) {
			filtro += ("articulos.codfamilia IN ('" + familia.split(",").join("', '") + "')");
		} else {
			if (familia.find("-") >= 0) {
				var min = familia.split("-")[0];
				var max = familia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.codfamilia IN (SELECT familias.codfamilia FROM familias WHERE familias.codfamilia SIMILAR TO '[0-9]+' AND CAST(familias.codfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.codfamilia = '" + familia + "'";
			}
		}
	}

	var subFamilia = cursor.valueBuffer("codsubfamilia");
	if(subFamilia && subFamilia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (subFamilia.find(",") >= 0) {
			filtro += ("articulos.codsubfamilia IN ('" + subFamilia.split(",").join("', '") + "')");
		} else {
			if (subFamilia.find("-") >= 0) {
				var min = subFamilia.split("-")[0];
				var max = subFamilia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.codsubfamilia IN (SELECT subfamilias.codsubfamilia FROM subfamilias WHERE subfamilias.codsubfamilia SIMILAR TO '[0-9]+' AND CAST(subfamilias.codsubfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.codsubfamilia = '" + subFamilia + "'";
			}
		}
	}

// 	var dibujo = cursor.valueBuffer("coddibestamp");
// 	if (dibujo && dibujo != "") {
// 		if (filtro != "") {
// 			filtro += " AND ";
// 		}
// 		filtro += "coddibestamp = " + dibujo;
// 	}

	var dibujos = cursor.valueBuffer("dibujos");
	if (dibujos && dibujos != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (dibujos.find(",") >= 0) {
			filtro += ("articulos.coddibestamp IN (" + dibujos + ")");
		} else {
			if (dibujos.find("-") >= 0) {
				var min = dibujos.split("-")[0];
				var max = dibujos.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.coddibestamp IN (SELECT em_dibujos.coddibujoem FROM em_dibujos WHERE em_dibujos.coddibujoem  BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.coddibestamp = " + dibujos;
			}
		}
	}
// 		if(filtro != "")
// 			filtro += " AND ";
// 		filtro += "coddibestamp = '" + dibujo + "'";
// 	}

	var coleccion = cursor.valueBuffer("codcoleccionem");
	if (coleccion && coleccion != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (coleccion.find(",") >= 0) {
			filtro += ("articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem IN ('" + coleccion.split(",").join("', '") + "'))");
		} else {
			if (coleccion.find("-") >= 0) {
				var min = coleccion.split("-")[0];
				var max = coleccion.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart WHERE em_coleccionesart.codcoleccionem SIMILAR TO '[0-9]+' AND  CAST(em_coleccionesart.codcoleccionem AS INTEGER) BETWEEN " + min + " AND " + max + ")");
				}
			} else {
				filtro += "articulos.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem = '" + coleccion + "')";
			}
		}
	}

	var refCliente = cursor.valueBuffer("aliasart");
	if(refCliente && refCliente != "") {
		if(filtro != "")
			filtro += " AND ";
		filtro += "articulos.aliasart = '" + refCliente + "'";
	}

	var refComponente = cursor.valueBuffer("refcomponente");
	if (refComponente && refComponente != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += "articulos.referencia IN (SELECT articuloscomp.refcompuesto FROM articuloscomp WHERE articuloscomp.refcomponente = '" + refComponente + "')";
	}

	var descatalogado = cursor.valueBuffer("descatalogado");
	if (descatalogado && descatalogado != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (descatalogado){
			case "No": {
				filtro += "NOT articulos.descatalogado";
				break;
			}
			default:
				filtro += "articulos.descatalogado";
				break;
		}
	}

	var deBaja = cursor.valueBuffer("debaja");
	if (deBaja && deBaja != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (deBaja){
			case "No": {
				filtro += "NOT articulos.debaja";
				break;
			}
			default:
				filtro += "articulos.debaja";
				break;
		}
	}

	var aLiquidar = cursor.valueBuffer("aliquidar");
	if (aLiquidar && aLiquidar != "Todos"){
		if (filtro != "") {
			filtro += " AND ";
		}
		switch (aLiquidar){
			case "No": {
				filtro += "articulos.fechaliq is null";
				break;
			}
			default:
				filtro += "articulos.fechaliq is not null";
				break;
		}
	}

	debug("Filtro " + filtro);
	return filtro;
}*/
function oficial_construirFiltroVista(cursor)
{
	var filtro = "";

	var referencia = cursor.valueBuffer("referencia");
	if (referencia && referencia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (referencia.find(",") >= 0) {
			filtro += ("v_lotesstock.referencia IN ('" + referencia.split(",").join("', '") + "')");
		} else {
			if (referencia.find("-") >= 0) {
				var min = referencia.split("-")[0];
				var max = referencia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_lotesstock.referencia SIMILAR TO '[0-9]+' AND CAST(v_lotesstock.referencia AS INTEGER) BETWEEN '" + min + "' AND '" + max + "'");
				}
			} else {
				filtro += "v_lotesstock.referencia = '" + referencia + "'";
			}
		}
	}


	var familia = cursor.valueBuffer("codfamilia");
	if (familia && familia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (familia.find(",") >= 0) {
			filtro += ("v_lotesstock.codfamilia IN ('" + familia.split(",").join("', '") + "')");
		} else {
			if (familia.find("-") >= 0) {
				var min = familia.split("-")[0];
				var max = familia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_lotesstock.codfamilia IN (SELECT familias.codfamilia FROM familias WHERE familias.codfamilia SIMILAR TO '[0-9]+' AND CAST(v_lotesstock.codfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");					
				}
			} else {
				filtro += "v_lotesstock.codfamilia = '" + familia + "'";
			}
		}
	}

	var subFamilia = cursor.valueBuffer("codsubfamilia");
	if(subFamilia && subFamilia != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (subFamilia.find(",") >= 0) {
			filtro += ("v_lotesstock.codsubfamilia IN ('" + subFamilia.split(",").join("', '") + "')");
		} else {
			if (subFamilia.find("-") >= 0) {
				var min = subFamilia.split("-")[0];
				var max = subFamilia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_lotesstock.codsubfamilia IN (SELECT subfamilias.codsubfamilia FROM subfamilias WHERE subfamilias.codsubfamilia SIMILAR TO '[0-9]+' AND CAST(subfamilias.codsubfamilia AS INTEGER) BETWEEN " + min + " AND " + max + ")");				
				}
			} else {
				filtro += "v_lotesstock.codsubfamilia = '" + subFamilia + "'";
			}
		}
	}

	var dibujos = cursor.valueBuffer("dibujos");
	if (dibujos && dibujos != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (dibujos.find(",") >= 0) {
			filtro += ("v_lotesstock.coddibestamp IN (" + dibujos + ")");
		} else {
			if (dibujos.find("-") >= 0) {
				var min = dibujos.split("-")[0];
				var max = dibujos.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_lotesstock.coddibestamp IN (SELECT em_dibujos.coddibujoem FROM em_dibujos WHERE em_dibujos.coddibujoem  BETWEEN " + min + " AND " + max + ")");
				
				}
			} else {
				filtro += "v_lotesstock.coddibestamp = " + dibujos;
			}
		}
	}

	var coleccion = cursor.valueBuffer("codcoleccionem");
	
	if (coleccion && coleccion != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (coleccion.find(",") >= 0) {
			filtro += ("v_lotesstock.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem IN ('" + coleccion.split(",").join("', '") + "'))");			
		} else {
			if (coleccion.find("-") >= 0) {
				var min = coleccion.split("-")[0];
				var max = coleccion.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_lotesstock.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart WHERE em_coleccionesart.codcoleccionem SIMILAR TO '[0-9]+' AND  CAST(em_coleccionesart.codcoleccionem AS INTEGER) BETWEEN " + min + " AND " + max + ")");					
				}
			} else {
				filtro += "v_lotesstock.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem = '" + coleccion + "')";				
			}
		}
	}

    /******** #EUR #H3623 Mejora filtro de lotes de stock *********************************************/

    var descatalogado = cursor.valueBuffer("descatalogado");
    if (descatalogado && descatalogado != "Todos"){
        if (filtro != "") {
            filtro += " AND ";
        }
        switch (descatalogado){
            case "No": {
                filtro += "NOT v_lotesstock.descatalogado";
                break;
            }
            default:
                filtro += "v_lotesstock.descatalogado";
                break;
        }
    }

    var deBaja = cursor.valueBuffer("debaja");
    if (deBaja && deBaja != "Todos"){
        if (filtro != "") {
            filtro += " AND ";
        }
        switch (deBaja){
            case "No": {
                filtro += "NOT v_lotesstock.debaja";
                break;
            }
            default:
                filtro += "v_lotesstock.debaja";
                break;
        }
    }

    var aLiquidar = cursor.valueBuffer("aliquidar");
    if (aLiquidar && aLiquidar != "Todos"){
        if (filtro != "") {
            filtro += " AND ";
        }
        switch (aLiquidar){
            case "No": {
                filtro += "v_lotesstock.fechaliq is null";
                break;
            }
            default:
                filtro += "v_lotesstock.fechaliq is not null";
                break;
        }
    }

    /**********************************************************************************************/

	
	var almacen = cursor.valueBuffer("codalmacen");
	if (almacen && almacen != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (almacen.find(",") >= 0) {
			filtro += ("v_lotesstock.codalmacen IN ('" + almacen.split(",").join("', '") + "')");
		} else {
			if (almacen.find("-") >= 0) {
				var min = almacen.split("-")[0];
				var max = almacen.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtro += ("v_lotesstock.codalmacen SIMILAR TO '[0-9]+' AND CAST(v_lotesstock.codalmacen AS INTEGER) BETWEEN '" + min + "' AND '" + max + "'");
				}
			} else {
				filtro += "v_lotesstock.codalmacen = '" + almacen + "'";
			}
		}
	}

	return filtro;
}

function oficial_bufferChanged(fN)
{
	var cursor = this.cursor();
	switch(fN) {
		case "coddibestamp":{
			cursor.setValueBuffer("dibujos", cursor.valueBuffer("coddibestamp"));
			break;
		}
	}
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	//var accion = cursor.valueBuffer("accion");
	//debug("accion: "+accion);
	var filtro;
	var filtroA;
	//if(accion == "v_lotesstock") {
		filtro = _i.construirFiltroVista(cursor);
	//} else {
	
		//filtro = _i.construirFiltro(cursor);
	//}
	
	if (!filtro) {
		filtro = "";
	}
	cursor.setValueBuffer("filtro", filtro);
	formv_lotesstock.iface.valorCombo_ = this.child("cbOpcionEM").currentText;
	this.obj().accept();
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var cursor = miForm.cursor();
	var campos = "fdbReferencia,fdbDesArticulo,fdbFamilia,fdbDescFamilia,fdbSubfamilia,fdbDescSubfamilia,fdbColeccion,fdbDescColeccion,fdbDibujo,fdbDibujos,fdbDescDibujo,fdbCodAlmacen,fdbAlmacenes";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(miForm, aCampos[i], "");
	}
	cursor.setNull("coddibestamp");

    cursor.setValueBuffer("descatalogado", "Todos");
    cursor.setValueBuffer("debaja", "Todos");
    cursor.setValueBuffer("aliquidar", "Todos");
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
