/***************************************************************************
                 em_masterpartidas.qs  -  description
                             -------------------
    begin                : dom feb 19 2012
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  function oficial( context ) { interna( context ); } 
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
  var codAlmaFiltro_;
  function euromoda( context ) { oficial ( context ); }
  function init() {
    return this.ctx.euromoda_init();
  }
  function tbnBuscar_clicked() {
    return this.ctx.euromoda_tbnBuscar_clicked();
  }
  function filtra() {
    return this.ctx.euromoda_filtra();
  }
  function dameFiltro() {
    return this.ctx.euromoda_dameFiltro();
  }
  function calcularTotales(where) {
	  return this.ctx.euromoda_calcularTotales(where);
  }
  function anchoCols() {
	  return this.ctx.euromoda_anchoCols();
  }
  function preloadMainFilter() {
	  return this.ctx.euromoda_preloadMainFilter();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends euromoda {
    function head( context ) { euromoda ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C La tabla de regularizaciones de stocks se muestra en modo de s�lo lectura
\end */
function interna_init()
{
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  _i.__init();
  
  /*connect(this.child("tbnBuscar"), "clicked()", _i, "tbnBuscar_clicked");
	
// 	var cols = ["fechaentradaem", "codlote", "descripcion", "codtamanoem", "codcolorem", "cantotal", "mptedist", "mmerma", "pormerma", "codigogit"];
// 	this.child("tdbPartidas").setOrderCols(cols);
	
  var cursor = this.cursor();
	cursor.setModeAccess(cursor.Insert);
	cursor.refreshBuffer();
//   if (cursor.action() == "em_seleccionpartida") {
//     this.child("gbxCriteriosBusqueda").close();
//   } else {
    _i.codAlmaFiltro_ = false;
    _i.filtra();
//   }
	_i.anchoCols();
	this.child("fdbReferencia").setFilter("NOT debaja");*/
	  
	  
	connect(this.child("tbnBuscar"), "clicked()", _i, "tbnBuscar_clicked");
	var cursor = this.cursor();
	if(cursor.modeAccess() != cursor.Insert) {	
		cursor.setModeAccess(cursor.Insert);
		cursor.refreshBuffer();
	}
	_i.codAlmaFiltro_ = false;
   _i.filtra();
	_i.anchoCols();
	this.child("fdbReferencia").setFilter("NOT debaja");
}

function euromoda_tbnBuscar_clicked()
{
  var _i = this.iface;
//   var f = new FLFormSearchDB("proveedores");
//   f.setMainWidget();
//   var codProveedor = f.exec("codproveedor");
//   var nombre = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + codProveedor + "'");
// 	sys.setObjText(this, "txtProveedor", nombre);
//   var codAlmacen = AQUtil.sqlSelect("proveedores", "codalmacen", "codproveedor = '" + codProveedor + "'");
//   if (codAlmacen) {
//     this.child("fdbCodAlmacen").setValue(codAlmacen);
//   }
  _i.filtra();
}

function euromoda_filtra()
{
	debug("euromoda_filtra");
  var _i = this.iface;
  var filtro = _i.dameFiltro();
  debug("filtro " + filtro);
  this.child("tdbPartidas").cursor().setMainFilter(filtro);
  this.child("tdbPartidas").refresh();
  
  _i.calcularTotales(filtro);
}

function euromoda_calcularTotales(where)
{debug("where " + where);
	var mDist = parseFloat(AQUtil.sqlSelect("lotesstock INNER JOIN articulos ON lotesstock.referencia = articulos.referencia","SUM(mdistribuidos)",where,"lotesstock,articulos"));
	mDist = isNaN(mDist) ? 0 : mDist;
	mDist = parseFloat(AQUtil.roundFieldValue(mDist, "lotesstock", "mdistribuidos"));
	
	var mMerma = parseFloat(AQUtil.sqlSelect("lotesstock INNER JOIN articulos ON lotesstock.referencia = articulos.referencia","SUM(mmerma)",where,"lotesstock,articulos"));
	mMerma = isNaN(mMerma) ? 0 : mMerma;
	
	var porMerma = mDist != 0 ? (mMerma / mDist) * 100 : 0;
	porMerma = isNaN(porMerma) ? 0 : porMerma;
		
	var cantidad = parseFloat(AQUtil.sqlSelect("lotesstock INNER JOIN articulos ON lotesstock.referencia = articulos.referencia","SUM(cantotal)",where,"lotesstock,articulos"));
	
	var pteDist = parseFloat(AQUtil.sqlSelect("lotesstock INNER JOIN articulos ON lotesstock.referencia = articulos.referencia","SUM(mptedist)",where,"lotesstock,articulos"));
	
	var pteRec = parseFloat(AQUtil.sqlSelect("lotesstock INNER JOIN articulos ON lotesstock.referencia = articulos.referencia","SUM(mpterec)",where,"lotesstock,articulos"));
	  
	porMerma = parseFloat(AQUtil.roundFieldValue(porMerma, "lotesstock", "pormerma"));
	mMerma = parseFloat(AQUtil.roundFieldValue(mMerma, "lotesstock", "mmerma"));
	cantidad = parseFloat(AQUtil.roundFieldValue(cantidad, "lotesstock", "cantotal"));
	pteDist = parseFloat(AQUtil.roundFieldValue(pteDist, "lotesstock", "mptedist"));
	pteRec = parseFloat(AQUtil.roundFieldValue(pteRec, "lotesstock", "mpterec"));
	
	this.child("fdbMerma").setValue(mMerma);
	this.child("fdbPorMerma").setValue(porMerma);
	this.child("fdbCantidad").setValue(cantidad);
	this.child("fdbPteDist").setValue(pteDist);
	this.child("fdbPteRx").setValue(pteRec);
}

function euromoda_preloadMainFilter()
{
  return "lotesstock.codlote LIKE 'PT%'";
}

function euromoda_dameFiltro()
{
  var _i = this.iface;
	var cursor = this.cursor();
	var filtro = _i.preloadMainFilter();
	
	var codProveedor = cursor.valueBuffer("codproveedor");
	if (codProveedor) {
		filtro += " AND lotesstock.codproveedor = '" + codProveedor + "'";
	}
	
	var codAlmacen = cursor.valueBuffer("codalmacen");
  if (codAlmacen) {
    filtro += " AND lotesstock.codalmacen = '" + codAlmacen + "'";
  }
  var referencia = cursor.valueBuffer("referencia");
  if (referencia) {
    filtro += " AND lotesstock.referencia = '" + referencia + "'";
  }
  if (!cursor.isNull("pormermamin")) {
		var porMermaMin = cursor.valueBuffer("pormermamin");
		if (porMermaMin) {
			filtro += " AND lotesstock.pormerma >= " + porMermaMin;
		}
	}
	if (!cursor.valueBuffer("incluyefin")) {
		filtro += " AND NOT lotesstock.distribucionfin";
	}
	
	if (cursor.valueBuffer("ptedistribuir")) {
		filtro += " AND NOT lotesstock.distribucionfin AND mptedist > 0";
	}
	if (cursor.valueBuffer("pterecibir")) {
		filtro += " AND NOT lotesstock.distribucionfin AND mpterec > 0";
	}
	
// 	var mPteDist = cursor.valueBuffer("mptedist");
// 	if (mPteDist) {
// 		filtro += " AND mptedist = " + mPteDist;
// 	}
// 	
// 	var canTotal = cursor.valueBuffer("cantotal");
// 	if (canTotal) {
// 		filtro += " AND cantotal = " + canTotal;
// 	}
// 	
// 	var mMerma = cursor.valueBuffer("mmerma");
// 	if (mMerma) {
// 		filtro += " AND mmerma = " + mMerma;
// 	}
// 	
// 	var mPteRec = cursor.valueBuffer("mpterec");
// 	if (mPteRec) {
// 		filtro += " AND mpterec = " + mPteRec;
// 	}
  return filtro;
}

function euromoda_anchoCols()
{
	var oC
	var oCAncho = [["codalmacen", 30], ["referencia", 60], ["codlote", 90], ["codproveedor", 60], ["nombre", 170]];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tdbPartidas").setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
}                       
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
