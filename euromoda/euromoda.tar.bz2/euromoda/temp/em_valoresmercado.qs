/***************************************************************************
                 em_valoresmercado.qs  -  description
                             -------------------
    begin                : mar abril 03 2018
    copyright            : (C) 2014 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() { 
		this.ctx.interna_init(); 
	}
	function calculateField(fN) { 
		return this.ctx.interna_calculateField(fN); 
	}
	function validateForm() {
	   return this.ctx.interna_validateForm();
	}
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {	
	function oficial( context ) { 
		interna( context ); 
	} 	
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	var bloqueovalor_;
  	function ifaceCtx( context ) { head( context ); }
  	function bufferChanged(fN) {
  		return this.ctx.oficial_bufferChanged(fN);
  	}
  
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	if (cursor.modeAccess() == cursor.Insert) {
		var hoy = new Date();
		cursor.setValueBuffer("em_fechavalmercado", hoy);	
		cursor.setValueBuffer("em_coddivisamercado","USD");	
		var referencia = formRecordarticulos.iface.referenciaVM_;
		if(referencia && referencia != "") {
			cursor.setValueBuffer("referencia",referencia);
			sys.disableObj(this, "fdbReferencia");
		} else {
			sys.enableObj(this, "fdbReferencia");				
		}
		_i.bufferChanged("em_coddivisamercado");
	} else if (cursor.modeAccess() == cursor.Edit) {
		sys.disableObj(this, "fdbReferencia");
	}	
	_i.bloqueovalor_ = false;
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "em_valmercadoeur": {
			
				
			var valorMercado = cursor.valueBuffer("em_valmercado");
			var tasa = cursor.valueBuffer("em_tasaconvmercado"); 	
			if(valorMercado && tasa) {
				valor = valorMercado * tasa;					
			} else {
				valor = 0;
			}
				
			
			break;
		}	
		case "em_tasaconvmercado": {
				
			var valorMercado = cursor.valueBuffer("em_valmercado");
			var valorMercadoEur = cursor.valueBuffer("em_valmercadoeur");
				

			if(valorMercado && valorMercado != "" && valorMercadoEur && valorMercadoEur != 0) {
				valor = valorMercadoEur / valorMercado;
			} else {
				valor = 0;
			}			
			
			break;
		}	
	}
			
	return valor;
}

function interna_validateForm()
{
	var _i = this.iface;	
	
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();		
	switch (fN) {
		case "em_tasaconvmercado":
		case "em_valmercado": {
			if(!_i.bloqueovalor_) {
				_i.bloqueovalor_ = true;
				this.child("fdbEmValMercadoEur").setValue(_i.calculateField("em_valmercadoeur"));	
				_i.bloqueovalor_ = false;
			}
			
			break;
		}
		case "em_valmercadoeur": {
			if(!_i.bloqueovalor_) {
				_i.bloqueovalor_ = true;
				this.child("fdbTasaConv").setValue(_i.calculateField("em_tasaconvmercado"));
				_i.bloqueovalor_ = false;
			}
			break;
		}	
		case "codproveedor": {
			if(cursor.valueBuffer("codproveedor") != "") {
				this.child("fdbEmTipoMercado").setValue("Proveedor");	
			}
		}	
	}		
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////
