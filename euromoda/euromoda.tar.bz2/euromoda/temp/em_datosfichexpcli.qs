/***************************************************************************
                 em_datosfichexpcli.qs  -  description
                             -------------------
    begin                : mie feb 5 2020
    copyright            : (C) 2020 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx;
    function interna( context ) { this.ctx = context; }
    function init() {
        return this.ctx.interna_init();
    }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
    function oficial( context ) { interna( context ); }
    function cargarDatos() {
        return this.ctx.oficial_cargarDatos();
    }
    function pushButtonAccept_clicked() {
        return this.ctx.oficial_pushButtonAccept_clicked();
    }
    function comprobacionesFormulario() {
        return this.ctx.oficial_comprobacionesFormulario();
    }
    function habilitaCamposXTipo(tipoDoc) {
    	return this.ctx.oficial_habilitaCamposXTipo(tipoDoc);
    }
    function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function bChPreCursor(fN, cursor) {
		return this.ctx.oficial_bChPreCursor(fN, cursor);
	}
	function bChCursor(fN, cursor) {
		return this.ctx.oficial_bChCursor(fN, cursor);
	}
	function bChPostCursor(fN, cursor) {
		return this.ctx.oficial_bChPostCursor(fN, cursor);
	}
	function cargaDatosCliente(cursor) {
		return this.ctx.oficial_cargaDatosCliente(cursor);
	}
	function cargaDatosProveedor(cursor) {
		return this.ctx.oficial_cargaDatosProveedor(cursor);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
    var _i = this.iface;
    var cursor = this.cursor();

    _i.cargarDatos();
    connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
    disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
    connect(this.child("pushButtonAccept"), "clicked()", this, "iface.pushButtonAccept_clicked");
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_cargarDatos()
{
    var _i = this.iface;
    var cursor = this.cursor();
    var tipoFichero = cursor.valueBuffer("tipofichero");
    debug("tipoFichero: "+tipoFichero);
    //_i.habilitaCamposXTipo(tipofichero);

    if(tipoFichero == "Cantidades_Articulos") {
    	this.child("lblTitulo").text = "Exportar cantidades de art�culos";
    	this.child("fdbCodProveedor").close();
    	this.child("fdbNombreProveedor").close();
    } else if(tipoFichero == "Maestro_Articulos") {
    	this.child("lblTitulo").text = "Exportar datos de art�culos";
    	this.child("fdbCodProveedor").close();
    	this.child("fdbNombreProveedor").close();
    } else if(tipoFichero == "Orden_Distribucion_A_Euromoda") {
    	this.child("lblTitulo").text = "Exportar datos de �rdenes de distribuci�n a Euromoda";
    	this.child("fdbCodCliente").close();
    	this.child("fdbNombreCliente").close();    	
    }  	
	this.child("cbSimboloDecimal").currentText =  cursor.valueBuffer("simbolodecimal");    
	this.child("cbSeparador").currentText =  cursor.valueBuffer("separador");
}

function oficial_pushButtonAccept_clicked()
{
    var _i = this.iface;

    if (!_i.comprobacionesFormulario()) {
        return false;
    }

    this.accept();
}

function oficial_comprobacionesFormulario()
{
	var cursor = this.cursor();
	cursor.setValueBuffer("simbolodecimal",this.child("cbSimboloDecimal").currentText);
	cursor.setValueBuffer("separador",this.child("cbSeparador").currentText);
    return true;
}

function oficial_habilitaCamposXTipo(tipoDoc)
{
	if (tipoDoc != "FP") {
        this.child("lblNumProveedor").close();
        this.child("fdbNumProveedor").close();
    }
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();

	_i.bChPreCursor(fN, cursor);
	_i.bChCursor(fN, cursor);
	_i.bChPostCursor(fN, cursor);
}

function oficial_bChPreCursor(fN, cursor)
{
	var _i = this.iface;	
}

function oficial_bChCursor(fN, cursor)
{
	var _i = this.iface;
	var _fP = flfactppal.iface;

	if (fN == "codcliente") {
		_i.cargaDatosCliente(cursor);	
	} else if(fN == "codproveedor") {
		_i.cargaDatosProveedor(cursor);
	}
}

function oficial_bChPostCursor(fN, cursor)
{
	var _i = this.iface;	
}

function oficial_cargaDatosCliente(cursor)
{
	var codCliente = cursor.valueBuffer("codcliente");
	if(!codCliente || codCliente == "") {
		return true;
	}
	var tipoFichero = cursor.valueBuffer("tipofichero");
	var q = new AQSqlQuery;	
	q.setSelect("codificacion,separador,simbolodecimal,expcabecera,impdecimales,numdecimalesimp,cantsindecimales,conmillares");
	q.setFrom("em_ficherosexpcli");
	q.setWhere("codcliente = '" + codCliente + "' and tipofichero = '" + tipoFichero + "'"); 				
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{		
	  	cursor.setValueBuffer("codificacion",q.value("codificacion"));	  	
	  	this.child("cbSeparador").currentText =  q.value("separador");
	  	this.child("cbSimboloDecimal").currentText =  q.value("simbolodecimal");  	  	
	  	cursor.setValueBuffer("expcabecera",q.value("expcabecera"));
	  	cursor.setValueBuffer("impdecimales",q.value("impdecimales"));
	  	cursor.setValueBuffer("numdecimalesimp",q.value("numdecimalesimp"));
	  	cursor.setValueBuffer("cantsindecimales",q.value("cantsindecimales"));
	  	cursor.setValueBuffer("conmillares",q.value("conmillares"));	
	} 
}

function oficial_cargaDatosProveedor(cursor)
{
	var codProveedor = cursor.valueBuffer("codproveedor");
	if(!codProveedor || codProveedor == "") {
		return true;
	}
	var tipoFichero = cursor.valueBuffer("tipofichero");
	var q = new AQSqlQuery;	
	q.setSelect("codificacion,separador,simbolodecimal,expcabecera,impdecimales,numdecimalesimp,cantsindecimales,conmillares");
	q.setFrom("em_ficherosexpprov");
	q.setWhere("codproveedor = '" + codProveedor + "' and tipofichero = '" + tipoFichero + "'"); 				
	if (!q.exec()){
		return;
	}  
	if(q.first())
	{		
	  	cursor.setValueBuffer("codificacion",q.value("codificacion"));	  	
	  	this.child("cbSeparador").currentText =  q.value("separador");
	  	this.child("cbSimboloDecimal").currentText =  q.value("simbolodecimal");  	  	
	  	cursor.setValueBuffer("expcabecera",q.value("expcabecera"));
	  	cursor.setValueBuffer("impdecimales",q.value("impdecimales"));
	  	cursor.setValueBuffer("numdecimalesimp",q.value("numdecimalesimp"));
	  	cursor.setValueBuffer("cantsindecimales",q.value("cantsindecimales"));
	  	cursor.setValueBuffer("conmillares",q.value("conmillares"));	
	} 
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
