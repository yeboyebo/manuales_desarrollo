/***************************************************************************
                 masteralbaranescli.qs  -  description
                             -------------------
    begin                : lun abr 26 2004
    copyright            : (C) 2004 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	var opcionImp_;
	var cantidadImp_;
  function oficial(context)
  {
    interna(context);
  }
  	function init() {
    	return this.ctx.oficial_init();
  	}
  	function toolButtomInsert_clicked() {
		return this.ctx.oficial_toolButtomInsert_clicked()
	}
	function toolButtonEdit_clicked() {
		return this.ctx.oficial_toolButtonEdit_clicked()
	}
	function toolButtonDelete_clicked() {
		return this.ctx.oficial_toolButtonDelete_clicked();
	}
	function toolButtonZoom_clicked() {
		return this.ctx.oficial_toolButtonZoom_clicked();
	}
	function borraDropshipping(oParam) {
		return this.ctx.oficial_borraDropshipping(oParam);
	}
	function tbnEtiqueta_clicked() {
		return this.ctx.oficial_tbnEtiqueta_clicked();
	}
	function marcarEtiquetasNoImpresas(codigo) {
		return this.ctx.oficial_marcarEtiquetasNoImpresas(codigo);
	}
	function marcarPedidosEtiImp(sPedidos) {
		return this.ctx.oficial_marcarPedidosEtiImp(sPedidos);
	}
	function guardaValoresImpresion(opcion,cantidad) {
		return this.ctx.oficial_guardaValoresImpresion(opcion,cantidad);
	}
	function dameOpcionImp() {
		return this.ctx.oficial_dameOpcionImp();
	}
	function dameCantidadImp() {
		return this.ctx.oficial_dameCantidadImp();
	}
	function ordenColumnas() {
		return this.ctx.oficial_ordenColumnas();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////


function oficial_init()
{
  	var _i = this.iface;
	
	connect(this.child("toolButtomInsert"), "clicked()", _i, "toolButtomInsert_clicked");
	connect(this.child("toolButtonEdit"), "clicked()", _i, "toolButtonEdit_clicked");
	connect(this.child("toolButtonDelete"), "clicked()", _i, "toolButtonDelete_clicked");
	connect(this.child("toolButtonZoom"), "clicked()", _i, "toolButtonZoom_clicked");
	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "toolButtonEdit_clicked");
	connect(this.child("tbnEtiqueta"), "clicked()", _i, "tbnEtiqueta_clicked");
	_i.ordenColumnas();
	
}

function oficial_toolButtomInsert_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.insertRecord();

}

function oficial_toolButtonEdit_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.editRecord();
}

function oficial_toolButtonDelete_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var codD = cursor.valueBuffer("codigo");

	var hayOrdenesNoPtes = AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", "em_coddropshipping = '" + codD + "' AND estado <> 'PTE'");
	if (hayOrdenesNoPtes) {
		sys.warnMsgBox(sys.translate("El dropshipping seleccionado contiene �rdenes de producci�n iniciadas, no es posible eliminarlo"));
		return false;
	}

	var res = MessageBox.information(sys.translate("Va a borrar el dropshipping seleccionado junto con sus �rdenes de producci�n y pedidos asociados.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
	if (res != MessageBox.Yes) {
		return false;
	}

	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al borrar el dropshipping.");
	oParam.cursor = cursor;	
	var f = new Function("oParam", "return formem_dropshipping.iface.borraDropshipping(oParam)");
	if (!sys.runTransaction(f, oParam)) {									
		return false;
	}
	this.child("tableDBRecords").refresh();
}

function oficial_borraDropshipping(oParam)
{
	var _i = this.iface;
	var cursor = oParam.cursor;
	
	var qO = new FLSqlQuery;
	qO.setSelect("codorden");
	qO.setFrom("pr_ordenesproduccion");
	qO.setWhere("em_coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	if (!qO.exec()) {
		return false;
	}
	while (qO.next()) {
		if (!formpr_ordenesproduccion.iface.borrarOrden(qO.value("codorden"))) {
			return false;
		}
	}
	
	var curCD = new FLSqlCursor("em_cargadropshipping");
	curCD.select("coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	while (curCD.next()) {
		curCD.setModeAccess(curCD.Del);
		curCD.refreshBuffer();
		if (!curCD.commitBuffer()) {
			return false;
		}
	}
	var curP = new FLSqlCursor("pedidoscli");
	curP.select("em_coddropshipping = '" + cursor.valueBuffer("codigo") + "'");
	while (curP.next()) {
		curP.setModeAccess(curP.Del);
		curP.refreshBuffer();
		if (!curP.commitBuffer()) {
			return false;
		}
	}cursor.setModeAccess(cursor.Del);
	cursor.refreshBuffer();
	if (!cursor.commitBuffer()) {
		return false;
	}
	return true;
}

function oficial_toolButtonZoom_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.browseRecord();
}

/*function euromoda_dameColor(fN, fV, cursor, fT, sel)
{
	var color = "";
	switch (fN) {
		case "codigo": {
			if (cursor.valueBuffer("idfactura")) {
				color = flfactppal.iface.pub_dameColor("fondo_facturado");
			}
			break;
		}
		default: {
			return;
		}
	}
	if (color != "") {
		var a:Array = [color, "#000000", "SolidPattern", "SolidPattern"];
		return a;
	}
}*/

function oficial_tbnEtiqueta_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor(); 
	var codigo = cursor.valueBuffer("codigo");
	var aPedidos = [];
	var aCodPedidos = [];

	var f = new FLFormSearchDB("em_opcionesimpdrop");
  	var curO = f.cursor();
  	curO.setModeAccess(curO.Insert);
  	curO.refreshBuffer();
  	var opcionImp = _i.dameOpcionImp();
  	var cantidadImp = _i.dameCantidadImp(); 
  	if(opcionImp && opcionImp != "") {
  		curO.setValueBuffer(opcionImp,true);
  		if(cantidadImp && cantidadImp !="") {
  			curO.setValueBuffer("cantidad",cantidadImp);
  		}
  	}
  	f.setMainWidget();
   	f.exec();
  	if (!f.accepted()) {   		
        return false;
    }
    var impTodos = curO.valueBuffer("imprimirtodos");
    var impPtes = curO.valueBuffer("imprimirptes");
    var impCant = curO.valueBuffer("imprimircant");
    var cantidad = curO.valueBuffer("cantidad");
    var marcarNoImpreso = curO.valueBuffer("marcarnoimpreso");

    var sSelect = "p.codigo, p.idpedido";
    var sFrom = "pedidoscli p inner join em_cargadropshipping c ON c.idpedido = p.idpedido";
    var sWhere = "p.em_coddropshipping = '" + codigo + "'";
    var sGroupBy = " GROUP BY p.codigo,p.idpedido,c.pedidoprivalia";
    var sOrderBy = " ORDER BY c.pedidoprivalia ASC"; 
    var sLimit = "";
    var sMensaje = "";
    var imprimir = false;
    if(impTodos) {
    	imprimir = true;
    	_i.guardaValoresImpresion("imprimirtodos","");
    	sMensaje = sys.translate("No se ha encontrado ning�n pedido");    	
    } else if(impPtes) {
    	imprimir = true;
    	_i.guardaValoresImpresion("imprimirptes","");
    	sWhere  = sWhere + " AND (NOT c.etiquetaimpresa OR c.etiquetaimpresa is null)";
    	sMensaje = sys.translate("No se ha encontrado ning�n pedido con sus etiquetas no impresas para el dropshipping %1").arg(codigo);    	
    } else if(impCant) {
    	imprimir = true;    	
    	_i.guardaValoresImpresion("imprimircant",cantidad);
    	sWhere  = sWhere + " AND (NOT c.etiquetaimpresa OR c.etiquetaimpresa is null)";
    	sLimit = " LIMIT " + cantidad;
    	sMensaje = sys.translate("No se ha encontrado ning�n pedido con sus etiquetas no impresas para el dropshipping %1").arg(codigo);
    	
    } else if(marcarNoImpreso) {
    	_i.guardaValoresImpresion("marcarnoimpreso","");
    	imprimir = false;
    	if(!_i.marcarEtiquetasNoImpresas(codigo)) {
    		return false;
    	}
    	flfactppal.iface.ponMsgError(sys.translate("Registros marcados como etiquetas no impresas"),"info",this);
    }

    if(imprimir) {    	
    	var q = new AQSqlQuery;	
		q.setSelect(sSelect);
		q.setFrom(sFrom);
		q.setWhere(sWhere + sGroupBy + sOrderBy + sLimit);	
		debug("consulta:" +q.sql());
		if (!q.exec()){
			return;
		}  
		
		while(q.next())
		{
			aPedidos.push(q.value("p.idpedido"));
			aCodPedidos.push(q.value("p.codigo"));	
		}
		if(aCodPedidos.length >0) {
			formem_pedidosptes.iface.imprimirEtiqueta(aCodPedidos.join("','"));	
			_i.marcarPedidosEtiImp(aPedidos.join(","));  
		} else {
			flfactppal.iface.ponMsgError(sMensaje,"warn",this);
		}
			 
    }   

}

function oficial_marcarEtiquetasNoImpresas(codigo)
{
	var _i = this.iface;
	if(!AQUtil.execSql("UPDATE em_cargadropshipping SET etiquetaimpresa = false WHERE coddropshipping = '" + codigo + "'")) {
		return false;
	}
	return true;
}

function oficial_marcarPedidosEtiImp(sPedidos)
{
	debug("")
	var _i = this.iface;
	if(!AQUtil.execSql("UPDATE em_cargadropshipping SET etiquetaimpresa = true WHERE idpedido IN (" + sPedidos + ")")) {
		return false;
	}
	return true;
}

function oficial_guardaValoresImpresion(opcion,cantidad)
{
	var _i = this.iface;
	_i.opcionImp_ = opcion;    	
    _i.cantidadImp_ = cantidad;
}

function oficial_dameOpcionImp()
{
	var _i = this.iface;
	return _i.opcionImp_;
}

function oficial_dameCantidadImp()
{
	var _i = this.iface;
	return _i.cantidadImp_;	
}

function oficial_ordenColumnas()
{
    var _i = this.iface;
    var t = this.child("tableDBRecords");
   // var listaCampos = ["codproveedor","nombre","costereal","pvp","pvpbnp","disponible","refproveedor","codbarras"];
   //t.setOrderCols(listaCampos);
    var aColumnas = [["descgestionadopor",100]];	 
    for (var i = 0; i < aColumnas.length; i++) {
		t.setColumnWidth(aColumnas[i][0], aColumnas[i][1]);
    } 
    
    this.child("tableDBRecords").refresh();
    
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////