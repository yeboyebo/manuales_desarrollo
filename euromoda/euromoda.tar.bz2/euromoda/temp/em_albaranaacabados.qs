/***************************************************************************
                 em_albaranaacabados.qs  -  description
                             -------------------
    begin                : jue mar 28 2014
    copyright            : (C) 2014 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tblBobinas_, tblPartidas_;
	var oPartidas_;
    function oficial( context ) { interna( context ); } 
    function iniciaTablas() {
    	return this.ctx.oficial_iniciaTablas();
    }
    function colorPartida(f, c) {
    	return this.ctx.oficial_colorPartida(f, c);
    }
    function tblPartidas_doubleClicked(f, c) {
    	return this.ctx.oficial_tblPartidas_doubleClicked(f, c);
    }
    function pushButtonAccept_clicked() {
    	return this.ctx.oficial_pushButtonAccept_clicked();
    }
    function damePartidas() {
    	return this.ctx.oficial_damePartidas();
    }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	
	_i.iniciaTablas();	
	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciaTablas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var idPedido = cursor.valueBuffer("idpedido");

	_i.oPartidas_ = new Object;
	
	_i.tblBobinas_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblBobinas"));
	var q = new AQSqlQuery;
	//q.setSelect("em_bobinas.codbobina, em_bobinas.candisponible, em_bobinas.idlineapp");
	//q.setFrom("lineaspedidosprov INNER JOIN em_bobinas ON lineaspedidosprov.idlinea = em_bobinas.idlineapp");
	//q.setWhere("lineaspedidosprov.idpedido = "+ idPedido + " ORDER BY em_bobinas.codbobina");
	q.setSelect("em_bobinas.codbobina, em_bobinas.candisponible");
	q.setFrom("lineaspedidosprov INNER JOIN em_tramostejido ON lineaspedidosprov.idlinea = em_tramostejido.idlineapedacabado INNER JOIN em_bobinas ON em_tramostejido.codbobina = em_bobinas.codbobina");
	q.setWhere("lineaspedidosprov.idpedido = "+ idPedido + " GROUP BY em_bobinas.codbobina, em_bobinas.candisponible ORDER BY em_bobinas.codbobina");
	_i.tblBobinas_.setQuery(q);
	_i.tblBobinas_.refresh();

	_i.tblPartidas_ = fleumoesta.iface.pub_dameObjetoTabla(this.child("tblPartidas"));
	_i.tblPartidas_.setColorFunction("formem_albaranaacabados.iface.colorPartida");
	var q = new AQSqlQuery;
	q.setSelect("lotesstock.codbobina, lotesstock.codlote, lotesstock.referencia, lotesstock.articulo, lotesstock.candisponible, lotesstock.idlinea");
	//q.setFrom("lineaspedidosprov INNER JOIN em_bobinas ON lineaspedidosprov.idlinea = em_bobinas.idlineapp INNER JOIN lotesstock ON em_bobinas.codbobina = lotesstock.codbobina");
	q.setFrom("lineaspedidosprov INNER JOIN em_tramostejido ON lineaspedidosprov.idlinea = em_tramostejido.idlineapedacabado INNER JOIN em_bobinas ON em_tramostejido.codbobina = em_bobinas.codbobina INNER JOIN lotesstock ON em_bobinas.codbobina = lotesstock.codbobina");
	//q.setWhere("lineaspedidosprov.idpedido = "+ idPedido + " ORDER BY em_bobinas.codbobina, lotesstock.codlote");
	q.setWhere("lineaspedidosprov.idpedido = "+ idPedido + " GROUP BY lotesstock.codbobina, lotesstock.codlote, lotesstock.referencia, lotesstock.articulo, lotesstock.candisponible, lotesstock.idlinea ORDER BY lotesstock.codbobina, lotesstock.codlote");
	_i.tblPartidas_.setQuery(q);
	_i.tblPartidas_.refresh();
	
	
	connect(this.child("tblPartidas"), "clicked(int, int)", _i,  "tblPartidas_doubleClicked");

}

function oficial_colorPartida(f, c)
{
	var _i = this.iface;
	var idLineaA = _i.tblPartidas_.cellValue(f, "lotesstock.idlinea");
	if (idLineaA && idLineaA != 0) {
	
		return  new Color(200, 200, 200);
	}
	var codPartida = _i.tblPartidas_.cellValue(f, "lotesstock.codlote");
	if (codPartida in _i.oPartidas_ && _i.oPartidas_[codPartida] == true) {
		
		return  new Color(50, 200, 50);
		
	} else {
	
		return  new Color(250, 250, 250);
	}
}

function oficial_tblPartidas_doubleClicked(f, c)
{
	var _i = this.iface;
	if (f < 0) {
		return;
	}
	var idLineaA = _i.tblPartidas_.cellValue(f, "lotesstock.idlinea");
	if (idLineaA && idLineaA != 0) {
		return;
	}
	var codPartida = _i.tblPartidas_.cellValue(f, "lotesstock.codlote");
	if (codPartida in _i.oPartidas_) {
		_i.oPartidas_[codPartida] = _i.oPartidas_[codPartida] ? false : true;
	} else {
		_i.oPartidas_[codPartida] = true;
	}
	_i.tblPartidas_.coloreaFila(f);
	
	var lista = [];
	for (p in _i.oPartidas_) {
		lista.push(p);
	}
	debug("Partidas " + lista);
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	if(_i.damePartidas() == "''") {
	    sys.warnMsgBox(sys.translate("Debe de seleccionar al menos una l�nea."));  
	    return;
	}

	//if (!_i.oPartidas_ || _i.oPartidas_.length == 0) {
	//	sys.warnMsgBox(sys.translate("Debe de seleccionar al menos una línea."));
	//}
	var _pp = formpedidosprov.iface;
	var cursor = this.cursor();
	
	var where = "idpedido = " + cursor.valueBuffer("idpedido");
	var idAlbaran = _pp.generarAlbaran(where,cursor);
	//_pp.generarAlbaran(where,cursor);
	debug("ID ALBARAN: "+idAlbaran);
	if(idAlbaran) {	
	     if (!AQSql.update("em_bobinas", ["estado"], ["PARA ROLLAR"], "idpedidoprov = " + cursor.valueBuffer("idpedido"))) {
		 sys.warnMsgBox(sys.translate("Error al camibar de estado la bobina."));
		 return;
	     }
	}

	
	this.accept();
}

function oficial_damePartidas()
{
	var _i = this.iface;
	
	var lista = [];
	for (p in _i.oPartidas_) {
		if (_i.oPartidas_[p] == true) {
			lista.push(p);
		}
	}
	debug("partidas " + lista);
	return "'" + lista.join("', '") + "'"; //pineboo 21-08-2019
}

//// OFICIAL ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////
