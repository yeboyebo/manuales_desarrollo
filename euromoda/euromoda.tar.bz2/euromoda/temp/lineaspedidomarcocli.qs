
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial
{
  function euromoda(context)
  {
    oficial(context);
  }
  function init() {
		return this.ctx.euromoda_init();
	}
	function fitraMovimientos() {
		return this.ctx.euromoda_fitraMovimientos();
	}
	function validateForm() {
    return this.ctx.euromoda_validateForm();
  }
  function validaRepetidos() {
    return this.ctx.euromoda_validaRepetidos();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	_i.fitraMovimientos();
}

function euromoda_fitraMovimientos()
{
	var cursor = this.cursor();
	this.child("tdbMoviStock").cursor().setMainFilter("idlineapm = " + cursor.valueBuffer("idlinea"));
	this.child("tdbLotesStock").cursor().setMainFilter("codlote IN (SELECT codlote FROM movistock WHERE idlineapm = " + cursor.valueBuffer("idlinea") + ")");
	this.child("tdbMoviStock").refresh();
	this.child("tdbLotesStock").refresh();
}

function euromoda_validateForm()
{
  var _i = this.iface;
  var cursor = this.cursor();
  if (!_i.__validateForm()) {
    return false;
  }
  if (!_i.validaRepetidos()) {
    return false;
  }
  return true;
}

function euromoda_validaRepetidos()
{
	var _i = this.iface;
  var cursor = this.cursor();
  var referencia  = cursor.valueBuffer("referencia");
	if (referencia) {
		var idLinea = AQUtil.sqlSelect("lineaspedidomarcocli", "idlinea", "codpedidomarco = '" + cursor.valueBuffer("codpedidomarco") + "' AND referencia = '" + referencia + "' AND idlinea <> " + cursor.valueBuffer("idlinea"));
		if (idLinea) {
			var res = MessageBox.warning(sys.translate("Ya existe una l�nea de pedido con esta referencia. �Desea continuar?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton);
			if (res != MessageBox.Yes) {
				return false;
			}
		}
	}
	return true;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

	
