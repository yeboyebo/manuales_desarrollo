/***************************************************************************
                 em_filtropedidosprov.qs  -  description
                             -------------------
    begin                : vie jul 12 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  function oficial(context)
  {
    interna(context);
  }
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function construirFiltro(cursor) {
		return this.ctx.oficial_construirFiltro(cursor);
	}
	function tbnLimpiarFiltro_clicked() {
	  return this.ctx.oficial_tbnLimpiarFiltro_clicked();
	}
	function limpiarFiltro(form) {
		return this.ctx.oficial_limpiarFiltro(form);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
	function pub_limpiarFiltro(form) {
		return this.limpiarFiltro(form);
	}
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
	var cursor = this.cursor();
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
	
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
  connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_construirFiltro(cursor)
{
	var filtro = "";
	
	var servido = cursor.valueBuffer("servido");
	if (servido && servido != "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (servido == "Pendientes") {
			filtro += "servido IN ('No', 'Parcial')";
		} else if (servido == "Todos") {
			filtro = "1 = 1";
		} else {
			filtro += "servido = '" + servido + "'";
		}
	}

	return filtro;
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var tabla = cursor.valueBuffer("tabla");
	var filtro = _i.construirFiltro(cursor);
	if (!filtro) {
		filtro = "";
	}
	cursor.setValueBuffer("filtro", filtro);

	this.obj().accept();
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var cursor = miForm.cursor();

	cursor.setValueBuffer("servido", "Pendientes");
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////