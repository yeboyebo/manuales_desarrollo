/***************************************************************************
                 pr_generarordenesprodem.qs  -  description
                             -------------------
    begin                : mar jun 21 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
/** \C
El formulario permite borrar �rdenes s�lo si est�n en estado PTE
\end */
/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
	var ref_, lot_, lotPR_, refPR_, EPRini_;
	var ultimaOrden_;
	var cIDP, cPED, cLIN, cCCL, cCLI, cSFM, cDIB, cCOL, cART, cCAN, cAFA, cPRE, cFAB, cMAX, cRLP, cFPE, cFSE, cFPR, cSTD, cSEL, cLOT, cTAM, cREF, cEPR, cCANP;
	var cCSF, cCDIB;
	var cCODCOL;
	var cLEST;
	var cMOVHIJO, cIDARTCOMP, cCONSUMO;
	var oMovLoteCompProd_;
	var oMovLote_;
	var aMovHijos_;
	var cOrdSDT,cOrdSTD;
	var cNoSel, cSel, cCan, cFab, cMax, cCanp;
	var t_, tdbOrdenes_;
	var aSDP_, bloqueo_, _curLPL_;
	const sep_ = "-/-";
	var ctx: Object;
	function interna(context)
	{
		this.ctx = context;
	}
	function init()
	{
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	var stocksARevisar_;
	var curReservaPteRx_;
	var cORD;
  function oficial(context)
  {
    interna(context);
  }
  function iniciarTabla()
  {
    return this.ctx.oficial_iniciarTabla();
  }
  function tbnBuscar_clicked()
  {
    return this.ctx.oficial_tbnBuscar_clicked();
  }
	function buscar()
  {
    return this.ctx.oficial_buscar();
  }
  function tblLineas_clicked(f, c)
  {
    return this.ctx.oficial_tblLineas_clicked(f, c);
  }
  function colSelClicked(f)
  {
    return this.ctx.oficial_colSelClicked(f);
  }
  function colRefClicked(f)
  {
    return this.ctx.oficial_colRefClicked(f);
  }
  function colores()
  {
    return this.ctx.oficial_colores();
  }
  function filtraOrdenes()
  {
    return this.ctx.oficial_filtraOrdenes();
  }
  function datosSDP()
  {
    return this.ctx.oficial_datosSDP();
  }
  function anadeFilaOP(f)
  {
    return this.ctx.oficial_anadeFilaOP(f);
  }
  function trAnadeFilaOP(oParam)
  {
    return this.ctx.oficial_trAnadeFilaOP(oParam);
  }
  function quitaFilaOP(f)
  {
    return this.ctx.oficial_quitaFilaOP(f);
  }
  function trQuitaFilaOP(oParam)
  {
    return this.ctx.oficial_trQuitaFilaOP(oParam);
  }
  function quitaLotesOrden(f, codOrden)
  {
    return this.ctx.oficial_quitaLotesOrden(f, codOrden);
  }
  function modificaCanLote(codLote, cantidad)
  {
    return this.ctx.oficial_modificaCanLote(codLote, cantidad);
  }
  function creaOrdenProd(f)
  {
    return this.ctx.oficial_creaOrdenProd(f);
  }
  function anadeLotesOrden(codOrden, f)
  {
    return this.ctx.oficial_anadeLotesOrden(codOrden, f);
  }
  function revisaCanLote(f)
  {
    return this.ctx.oficial_revisaCanLote(f);
  }
  function dameCanLote(codLote, referencia)
  {
    return this.ctx.oficial_dameCanLote(codLote, referencia);
  }
  function dameCanResLinPed(referencia)
  {
    return this.ctx.oficial_dameCanResLinPed(referencia);
  }
  function creaLote(f, codOrden)
  {
    return this.ctx.oficial_creaLote(f, codOrden);
  }
  function tbnLanzar_clicked()
  {
    return this.ctx.oficial_tbnLanzar_clicked();
  }
  function lanzaProcesos()
  {
    return this.ctx.oficial_lanzaProcesos();
  }
  function comprobarProcesosDuplicados()
  {
    return this.ctx.oficial_comprobarProcesosDuplicados();
  }
  function creaConsumosLotesFT(codOrden)
  {
    return this.ctx.oficial_creaConsumosLotesFT(codOrden);
  }
  function reservaStocksPedido(codOrden)
  {
    return this.ctx.oficial_reservaStocksPedido(codOrden);
  }
  function reservaStocksLineaPedido(curLote)
  {
    return this.ctx.oficial_reservaStocksLineaPedido(curLote);
  }
  function tbnCrearLinea_clicked()
  {
    return this.ctx.oficial_tbnCrearLinea_clicked();
  }
  function tbnPedidoProv_clicked()
  {
    return this.ctx.oficial_tbnPedidoProv_clicked();
  }
  function dameMaximoFabricable(referencia)
  {
    return this.ctx.oficial_dameMaximoFabricable(referencia);
  }
  function fabricableLineaPedido(idLinea)
  {
    return this.ctx.oficial_fabricableLineaPedido(idLinea);
  }
  function colMaxClicked(f)
  {
    return this.ctx.oficial_colMaxClicked(f);
  }
  function dameReferencia()
  {
    return this.ctx.oficial_dameReferencia();
  }
  function tbnSelTodo_clicked()
  {
    return this.ctx.oficial_tbnSelTodo_clicked();
  }
  function dameLote()
  {
    return this.ctx.oficial_dameLote();
  }
  function restaStockLote(referencia, cantidad)
  {
    return this.ctx.oficial_restaStockLote(referencia, cantidad);
  }
  function sumaStockLote(referencia, cantidad)
  {
    return this.ctx.oficial_sumaStockLote(referencia, cantidad);
  }
  function actualizaMaximos()
  {
    return this.ctx.oficial_actualizaMaximos();
  }
  function ordenar()
  {
    return this.ctx.oficial_ordenar();
  }
  function bufferChanged(fN)
  {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function tblLineas_valueChanged(f, c)
  {
    return this.ctx.oficial_tblLineas_valueChanged(f, c);
  }
  function creaConsumosFT(curLote)
  {
    return this.ctx.oficial_creaConsumosFT(curLote);
  }
  function apuntaStockARevisar(idStock)
  {
    return this.ctx.oficial_apuntaStockARevisar(idStock);
  }
  function revisaStocks()
  {
    return this.ctx.oficial_revisaStocks();
  }
  function tbnReservas_clicked()
  {
    return this.ctx.oficial_tbnReservas_clicked();
  }
  function habilitaPorDropshipping()
  {
    return this.ctx.oficial_habilitaPorDropshipping();
  }
//   function creaDialogoProgreso(mensaje, tamano)
//   {
//     return this.ctx.oficial_creaDialogoProgreso(mensaje, tamano);
//   }
  function cancelarFormulario()
  {
    return this.ctx.oficial_cancelarFormulario()
  }
  function tbnBorraOrden_clicked()
  {
    return this.ctx.oficial_tbnBorraOrden_clicked()
  }
  function tbnLimpiarFiltro_clicked()
  {
    return this.ctx.oficial_tbnLimpiarFiltro_clicked()
  }
  function habilitarCampos()
  {
    return this.ctx.oficial_habilitarCampos()
  }
  function copiaReservasEstampacionPed(idLineaPC, codLote)
  {
    return this.ctx.oficial_copiaReservasEstampacionPed(idLineaPC, codLote);
  }
  function quitaReservasEstampacionPed(idLineaPC, codLote)
  {
    return this.ctx.oficial_quitaReservasEstampacionPed(idLineaPC, codLote);
  }
  function buscarPorEstampacion()
  {
    return this.ctx.oficial_buscarPorEstampacion();
  }
	function revisaReservasPedidos() {
  		return this.ctx.oficial_revisaReservasPedidos();
  	}
  	function extraPR(referencia) {
  		return this.ctx.oficial_extraPR(referencia);
  	}
  	 function dameReferenciaPR() {
    return this.ctx.oficial_dameReferenciaPR();
  }
   function actualizaEPR() {
    return this.ctx.oficial_actualizaEPR();
  }
  function sumaStockLotePR(referencia, cantidad) {
    return this.ctx.oficial_sumaStockLotePR(referencia, cantidad);
  }
  function restaStockLotePR(referencia, cantidad) {
    return this.ctx.oficial_restaStockLotePR(referencia, cantidad);
  }
  	/*function calculaMetrosOP(codOrden, totalMetros) {
  		return this.ctx.oficial_calculaMetrosOP(codOrden, totalMetros);
  	}*/
	function agruparOrdenes(whereOrdenes) {
		return this.ctx.oficial_agruparOrdenes(whereOrdenes);
	}
	function agrupaOrdenesSubfamilia(whereOrdenes) {
		return this.ctx.oficial_agrupaOrdenesSubfamilia(whereOrdenes);
	}
	function creaGrupoSubfamilia(codSubfamilia) {
		return this.ctx.oficial_creaGrupoSubfamilia(codSubfamilia);
	}
	function agrupaOrdenesSeccion(whereOrdenes) {
		return this.ctx.oficial_agrupaOrdenesSeccion(whereOrdenes);
	}
	function creaGrupoSeccion(codSeccion) {
		return this.ctx.oficial_creaGrupoSeccion(codSeccion);
	}
  function cargaObjetoAdicionales(codOrden) {
    return this.ctx.oficial_cargaObjetoAdicionales(codOrden);
  }
	function calculaAdicionalesRet(oAdicionales) {
		return this.ctx.oficial_calculaAdicionalesRet(oAdicionales);
	}
	function gramajesOrdenesProd(oAdicionales,referencia){
		return this.ctx.oficial_gramajesOrdenesProd(oAdicionales,referencia);
	}
	function dameCantAFabricar(qryProcesos) {
		return this.ctx.oficial_dameCantAFabricar(qryProcesos);
	}
	function dameCantAFabricarComp(qryProcesos){
		return this.ctx.oficial_dameCantAFabricarComp(qryProcesos);
	}
	function habilitaPorFabPorcentaje() {
		return this.ctx.oficial_habilitaPorFabPorcentaje();
	}
	function valoresPorDefecto() {
		return this.ctx.oficial_valoresPorDefecto();
	}
	function criterioAgrupacion(oParamOrd) {
		return this.ctx.oficial_criterioAgrupacion(oParamOrd);
	}
	function limpiarTabla() {
		return this.ctx.oficial_limpiarTabla();
	}
	function actualizaPedOP() {
		return this.ctx.oficial_actualizaPedOP();
	}
	function compruebaCampoPedido(codPedido) {
		return this.ctx.oficial_compruebaCampoPedido(codPedido);
	}
	function compruebaCampoFamEx(famExcluidas) {
		return this.ctx.oficial_compruebaCampoFamEx(famExcluidas)
	}
	function compruebaCampoSubFamEx(subFamExcluidas) {
		return this.ctx.oficial_compruebaCampoSubFamEx(subFamExcluidas);
	}
	function compruebaCampoCliente(codCliente) {
		return this.ctx.oficial_compruebaCampoCliente(codCliente);
	}
	function compruebaCampoGrupoCli(codGrupoCli) {
		return this.ctx.oficial_compruebaCampoGrupoCli(codGrupoCli);
	}
	function ordenSTD(oParamOrd, ascDesc) {
		return this.ctx.oficial_ordenSTD(oParamOrd, ascDesc);
	}
	function ordenSDT(oParamOrd, ascDesc) {
		return this.ctx.oficial_ordenSDT(oParamOrd, ascDesc);
	}
	function compruebaCampoTamano(codTamanoEM) {
		return this.ctx.oficial_compruebaCampoTamano(codTamanoEM);
	}
	function compruebaCampoColor(codColorEM) {
		return this.ctx.oficial_compruebaCampoColor(codColorEM);
	}
	function copiaReservasEstampacionNoPed(idLineaEst, codLote) {
    	return this.ctx.oficial_copiaReservasEstampacionNoPed(idLineaEst, codLote);
  	}
  	function quitaReservasEstampacionNoPed(idLineaEst, codLote) {
    	return this.ctx.oficial_quitaReservasEstampacionNoPed(idLineaEst, codLote);
  	}
  	function habilitaSoloComponentes() {
  		return this.ctx.oficial_habilitaSoloComponentes();
  	}
  	function debugReservasPedido(desc) {
  		return this.ctx.oficial_debugReservasPedido(desc);
  	}
	function tbnPonerFechaNulo_clicked() {
		return this.ctx.oficial_tbnPonerFechaNulo_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
  function pub_creaConsumosFT(curLote) {
		return creaConsumosFT(curLote);
	}
}
const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.t_ = this.child("tblLineas");
	_i.tdbOrdenes_ = this.child("tdbOrdenes");
	_i.bloqueo_ = false;
	_i.ultimaOrden_ = AQUtil.sqlSelect("pr_ordenesproduccion", "codorden", "1 = 1 ORDER BY codorden DESC");

	connect(_i.t_, "doubleClicked(int, int)", _i, "tblLineas_clicked");
	connect(_i.t_, "valueChanged(int, int)", _i, "tblLineas_valueChanged");
	disconnect(this.child("pushButtonCancel"), "clicked()", this.obj(), "reject()");
	connect(this.child("pushButtonCancel"), "clicked()", _i, "cancelarFormulario");
	connect(this.child("tbnBuscar"), "clicked()", _i, "tbnBuscar_clicked");
	connect(this.child("tbnLanzar"), "clicked()", _i, "tbnLanzar_clicked");
	connect(this.child("tbnCrearLinea"), "clicked()", _i, "tbnCrearLinea_clicked");
	connect(this.child("tbnPedidoProv"), "clicked()", _i, "tbnPedidoProv_clicked");
	connect(this.child("tbnSelTodo"), "clicked()", _i, "tbnSelTodo_clicked");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("tbnReservas"), "clicked()", _i, "tbnReservas_clicked()");
	connect(this.child("tbnBorraOrden"), "clicked()", _i, "tbnBorraOrden_clicked()");
	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked()");
	connect(this.child("tbnPonerFechaNulo"), "clicked()", _i, "tbnPonerFechaNulo_clicked");
	//connect(this.child("chkBuscarStocks"), "clicked()", _i, "habilitarCampos()");
	//connect(this.child("chkBuscarFechas"), "clicked()", _i, "habilitarCampos()");
	//connect(this.child("chkBuscarPedidos"), "clicked()", _i, "habilitaPorFabPorcentaje()");


	this.child("pushButtonAccept").close();

	_i.colores();
	_i.iniciarTabla();
	_i.filtraOrdenes();
	_i.aSDP_ = [];
	_i.ref_ = [];
	_i.lot_ = [];
	_i.lotPR_ = []; //28-09-2015
	_i.refPR_ = [];
	_i.EPRini_ = [];
	_i.aMovHijos_ = [];
	//connect(this, "formReady()", _i, "tbnBuscar_clicked");

	_i.habilitarCampos();
	if(cursor.valueBuffer("nuevo"))   {
		_i.valoresPorDefecto();		
	} else {
		var busqStocks = cursor.valueBuffer("busqstocks");
		var busqEntreFechas = cursor.valueBuffer("busqentrefechas");
		if(busqStocks || busqEntreFechas) {
			_i.habilitarCampos();	
		}		
		var busqPedidos = cursor.valueBuffer("busqpedidos");
		if(busqPedidos) {
			_i.habilitaPorFabPorcentaje();	
			_i.habilitaSoloComponentes();
		}
		var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
		if(fabPorcentaje) {
			_i.habilitaPorFabPorcentaje();
		}
		var codDropshipping = cursor.valueBuffer("em_coddropshipping");
		if(codDropshipping && codDropshipping!= "") {
			_i.habilitaPorDropshipping();	
		}			
	}

	
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_valoresPorDefecto()
{
	var codConsola = AQUtil.sqlSelect("em_consolasprod","codconsola","tabla = 'pr_generarordenesprodem'");
	if(codConsola && codConsola != "") {
		var codTipoProdInd = AQUtil.sqlSelect("em_tiposprodind","codtipo","codconsola = '" + codConsola + "' and predeterminado");
		if(codTipoProdInd && codTipoProdInd != "") {
			this.child("fdbCodTipoProdInd").setValue(codTipoProdInd);
		}
	}
	this.child("fdbCodTipoProdInd").setFilter("codconsola = '" + codConsola + "'");
	this.child("fdbFusionarPedidos").setValue(false);
	this.child("fdbUnLoteXop").setValue(false);
}

function oficial_cancelarFormulario()
{
	var _i = this.iface;
	
	if (_i.tdbOrdenes_.cursor().size() > 0) {
		var res = MessageBox.warning(sys.translate("Va a cerrar la ventana, los cambios realizados no se guardar�n.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return;
		}
	}
	this.reject();
}

function oficial_filtraOrdenes()
{
  var _i = this.iface;
  var filtro = "estado = 'PTE' AND codorden > '" + _i.ultimaOrden_ + "'";
  _i.tdbOrdenes_.cursor().setMainFilter(filtro);
  _i.tdbOrdenes_.refresh();
}

function oficial_colores()
{
	var _i = this.iface;

	_i.cNoSel = new Color("grey");
	_i.cSel = new Color("green");
	_i.cCan = new Color(170,191,255);
	_i.cFab = new Color(112,182,117);
	_i.cMax = new Color(200,100,150);
	_i.cCanp = new Color(255,198,170);
}

function oficial_tblLineas_clicked(f, c)
{
  var _i = this.iface;
	switch (c) {
		case _i.cSEL: {
			_i.colSelClicked(f);
			break;
		}
		case _i.cREF: {
			_i.colRefClicked(f);
			break;
		}
		case _i.cMAX: {
			_i.colMaxClicked(f);
			break;
		}
  }
}

function oficial_colRefClicked(f)
{
	var _i = this.iface;
  var c = _i.cREF;
	var referencia = _i.t_.text(f, c);
	var curArt = new FLSqlCursor("articulos");
	curArt.select("referencia = '" + referencia + "'");
	if (!curArt.first()) {
		return;
	}
	curArt.editRecord();
}

function oficial_colMaxClicked(f)
{
	var _i = this.iface;
  var c = _i.cMAX;
	var referencia = _i.t_.text(f, _i.cREF);
	var curStock = new FLSqlCursor("stocks");
	curStock.select("referencia = '" + referencia + "' AND codalmacen = '1'");
	if (!curStock.first()) {
		return;
	}
	curStock.editRecord();
}

function oficial_colSelClicked(f)
{
	var _i = this.iface;
  var c = _i.cSEL;
  if (_i.t_.text(f, c) == "") {
    _i.t_.setText(f, c, "X");
		if (!_i.anadeFilaOP(f)) {
			_i.t_.setText(f, c, "");
    	MessageBox.warning(sys.translate("scripts", "Error al a�adir la fila seleccionada a las �rdenes de producci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			
      return false;
    }
  } else {
		_i.t_.setText(f, c, "");
		if (!_i.quitaFilaOP(f)) {
			_i.t_.setText(f, c, "X");
      MessageBox.warning(sys.translate("scripts", "Error al quitar la fila seleccionada de las �rdenes de producci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
  }

  if (_i.t_.text(f, c) == "X") {
    _i.t_.setCellBackgroundColor(f, c, _i.cSel);
		_i.t_.setRowReadOnly(f, true);
  } else {
    _i.t_.setCellBackgroundColor(f, c, _i.cNoSel);
		_i.t_.setRowReadOnly(f, false);
  }
  _i.tdbOrdenes_.refresh();



  var whereOrdenes = _i.tdbOrdenes_.cursor().mainFilter();
  var curOrdenes = new FLSqlCursor("pr_ordenesproduccion");
  curOrdenes.select(whereOrdenes);
   if (!curOrdenes.first()) {
		 this.child("tbnBuscar").enabled = true;
		 this.child("fdbFusionarPedidos").setDisabled(false);	
		 this.child("fdbUnLoteXop").setDisabled(false);	
		 this.child("tbnLimpiarFiltro").setDisabled(false);
		 this.child("fdbSeparadoPor").setDisabled(false);	

	} else {
		 this.child("tbnBuscar").enabled = false;
		 this.child("fdbFusionarPedidos").setDisabled(true);
		 this.child("fdbUnLoteXop").setDisabled(true);
		 this.child("tbnLimpiarFiltro").setDisabled(true);
		 this.child("fdbSeparadoPor").setDisabled(true);	
	}	
	return true;
}

function oficial_datosSDP()
{
  var a = [];
  a["codorden"] = undefined;
  return a;
}

function oficial_anadeFilaOP(f)
{
  var _i = this.iface;
	
	if (_i.bloqueo_) {
		return false;
	}
	_i.bloqueo_ = true;
	
  var oParam = new Object;
	oParam.f = f;
	oParam.errorMsg = sys.translate("Error al asociar el lote a la orden");
	var f;
	var ver = sys.version();
	var verBuild = parseInt(ver.mid(ver.lastIndexOf("Build") + 6));
	if (!isNaN(verBuild) && verBuild > 34895 || true) {
		f = new Function("oParam", "return formpr_generarordenesprodem.iface.trAnadeFilaOP(oParam)");
	} else {
	     f = new Function("oParam", "return formSearchpr_generarordenesprodem.iface.trAnadeFilaOP(oParam)");
	}

	if (!sys.runTransaction(f, oParam)) {
	//if (!formSearchpr_generarordenesprodem.iface.trAnadeFilaOP(oParam)) {
		_i.bloqueo_ = false;
		return false;
	}
  _i.bloqueo_ = false;
	return true;
}

function oficial_trAnadeFilaOP(oParam)
{
	var _i = this.iface;
	var f = oParam.f;

	var std = _i.t_.text(f, _i.cSTD);
	var datos = _i.aSDP_[std];
	if (datos == undefined) {
		oParam.errorMsg = sys.translate("Error al obtener los datos STD de la fila");
		return false;
	}
	var codOrden = datos["codorden"];
	var codOrdenOriginal = codOrden;
	if (codOrden == undefined) {
		codOrden = _i.creaOrdenProd(f);
		if (!codOrden) {
			oParam.errorMsg = sys.translate("Error al crear la orden");
			return false;
		}
		datos["codorden"] = codOrden;
	}
	if (!_i.anadeLotesOrden(codOrden, f)) {
		datos["codorden"] = codOrdenOriginal;
		oParam.errorMsg = sys.translate("Error al asociar el lote a la orden");
		return false;
	}
	return true;
}

function oficial_quitaFilaOP(f)
{
	//debug("quitaFilaOP 1");
  var _i = this.iface;
	
	if (_i.bloqueo_) {
		return false;
	}
	_i.bloqueo_ = true;
	
  var oParam = new Object;
	oParam.f = f;
	oParam.errorMsg = sys.translate("Error al desvincular la fila seleccionada de su orden de producci�n");
	var f;
	var ver = sys.version();
	var verBuild = parseInt(ver.mid(ver.lastIndexOf("Build") + 6));
	if (!isNaN(verBuild) && verBuild > 34895  || true) {
		f = new Function("oParam", "return formpr_generarordenesprodem.iface.trQuitaFilaOP(oParam)");
	} else {
	     f = new Function("oParam", "return formSearchpr_generarordenesprodem.iface.trQuitaFilaOP(oParam)");
	}
	if (!sys.runTransaction(f, oParam)) {	
	//if(!_i.trQuitaFilaOP(oParam)) {
		_i.bloqueo_ = false;
		return false;
	}
  _i.bloqueo_ = false;
  
	return true;
}

function oficial_trQuitaFilaOP(oParam)
{
	var _i = this.iface;
	var f = oParam.f;

	var std = _i.t_.text(f, _i.cSTD);
	var datos = _i.aSDP_[std];
	if (datos == undefined) {
		return false;
	}
	var codOrden = datos["codorden"];
	if (codOrden == undefined) {
		return false;
	}

	if (!_i.quitaLotesOrden(f, codOrden)) {
		return false;
	}
	return true;
}

function oficial_modificaCanLote(codLote, cantidad)
{
	var curLote = new FLSqlCursor("lotesstock");
	curLote.setActivatedCommitActions(false); /// Desactiva comprobaciones de movimientos de stock que todav�a no se han creado
	curLote.select("codlote = '" + codLote + "'");
	if (!curLote.first()) {
		return false;
	}
	curLote.setModeAccess(curLote.Edit);
	curLote.refreshBuffer();
	curLote.setValueBuffer("canlote", cantidad);
	curLote.setValueBuffer("canprogramada", cantidad);
	var codOrden = curLote.valueBuffer("codordenproduccion");
	if (!curLote.commitBuffer()) {
		return false;
	}
	if (!flfactalma.iface.pub_actualizaOrdenLote(codOrden)) {
		return false;
	}
	return true;
}

function oficial_quitaLotesOrden(f, codOrden)
{
	
	var _i = this.iface;
	var cursor = this.cursor();

	var codLote = _i.t_.text(f, _i.cLOT);
	if (!codLote) {
		return false;
	}

	var canResta = _i.t_.text(f, _i.cFAB);
	var referencia = _i.t_.text(f, _i.cREF);
	var canLote = _i.dameCanLote(codLote, referencia);

	// 	var canNueva = canLote - canResta;
	if (canLote > 0 ) {
		if (!_i.modificaCanLote(codLote, canLote)) {
			return false;
		}
	} else {
		if (!AQSql.del("lotesstock", "codlote = '" + codLote + "'")) {
			return false;
		}
		var totalLotes = AQUtil.sqlSelect("pr_ordenesproduccion", "totallotes", "codorden = '" + codOrden + "'");
		totalLotes = isNaN(totalLotes) ? 0 : totalLotes;
		if (totalLotes == 0) {
			if (!AQSql.del("pr_ordenesproduccion", "codorden = '" + codOrden + "'")) {
				return false;
			}
			var std = _i.t_.text(f, _i.cSTD);
			var datos = _i.aSDP_[std];
			if (datos == undefined) {
				return false;
			}
			datos["codorden"] = undefined;
		}
	}
	_i.t_.setText(f, _i.cLOT, "");

	var canResLinPed = _i.dameCanResLinPed(referencia);
	var canPrevia = parseFloat(canLote) + parseFloat(canResta);
	var fabDisp = canLote - canResLinPed > 0 ? canLote - canResLinPed : 0;
	var fabDispPrevia = canPrevia - canResLinPed > 0 ? canPrevia - canResLinPed : 0;
	var maxIni = _i.t_.text(f, _i.cMAX);
	if (!_i.sumaStockLote(referencia, fabDispPrevia - fabDisp)) {
		return false;
	}


	var extraPRini = _i.EPRini_[referencia];

	var extraPR = _i.t_.text(f, _i.cEPR);

	var faltas = _i.t_.text(f, _i.cAFA); 

	var max = _i.t_.text(f, _i.cMAX);
	max = isNaN(max) ? 0 : max;
	//debug("\n\nextraPRini: "+extraPRini);
	//debug("canResLinPed: "+canResLinPed);
	//debug("canPrevia: "+canPrevia);
	//debug("canResta: "+canResta);
	//debug("fabDisp: "+fabDisp);
	//debug("faltas: "+faltas);
	//debug("max: "+max);
	//debug("maxIni: "+maxIni);

	//debug("extraPR: "+extraPR+"\n\n");
	/*	if(extraPR < extraPRini) {			
	if (max < 0) {
	max = 0;
	}		
	var resta = canResta - max - faltas;
	debug("resta: "+resta);
	resta = Math.abs(resta);

	if (!_i.sumaStockLotePR(referencia, resta)) {
	return false;
	}

	}*/

	if(maxIni < 0) {	
		if(max >= 0) {		
			if (!_i.sumaStockLotePR(referencia, maxIni*(-1))) {
				return false;
			}				
		} else {				
			if (!_i.sumaStockLotePR(referencia, canResta)) {
				return false;
			}			
		}
	}

	/* 
	var idLineaPC = _i.t_.text(f, _i.cLIN);
	if (idLineaPC && idLineaPC != "") {
	if (!AQSql.del("em_lineaspedlote", "idlineapc = " + idLineaPC + " AND codlote = '" + codLote + "'")) {
	return false;
	}
	}
	*/
	var idLineaPC = _i.t_.text(f, _i.cLIN);
	var idLineaEst = _i.t_.text(f, _i.cLEST);
	if (idLineaPC && idLineaPC != "") {
		var codD = cursor.valueBuffer("em_coddropshipping");
		if (codD && codD != "") {
			
			aLineas = idLineaPC.split(", ");
			//var resto = canLote;
			//var canLinea;
			var curMS = new FLSqlCursor("movistock");
			for (var i = 0; i < aLineas.length; i++) {
				if (!AQSql.del("em_reservaslotepedido", "codlote = '" + codLote + "' AND idlineapc = " + aLineas[i])) {
					return false;
				}
				var idMov = AQUtil.sqlSelect("movistock", "idmovimiento", "idlineapc = " + aLineas[i]);
		
				if (idMov) {
					curMS.select("idmovimiento = " + idMov);
					if (curMS.first()) {
						curMS.setModeAccess(curMS.Browse);
						curMS.refreshBuffer();
						
						if (!flfactalma.iface.pub_revisaReservasMSAFaltas(curMS)) {
							return false;
						}
					}
				}
				// NUEVO
				if (!_i.quitaReservasEstampacionPed(aLineas[i], codLote)) {
					return false;
				}
			}
		} else {
			//debug("quita 1");
			//debug("codLote: "+codLote);
			//debug("idLineaPC: "+ idLineaPC);
			if (!AQSql.del("em_reservaslotepedido", "codlote = '" + codLote + "' AND idlineapc = " + idLineaPC)) {
				return false;
			}
			//debug("quita 2");
			var curMS = new FLSqlCursor("movistock");
			/// Hay que volver a crearlas al haberlas borrado al seleccionar la l�nea
			var idMov = AQUtil.sqlSelect("movistock", "idmovimiento", "idlineapc = " + idLineaPC);
			//debug("idMov: "+idMov);
			if (idMov) {
				curMS.select("idmovimiento = " + idMov);
				if (curMS.first()) {
					curMS.setModeAccess(curMS.Browse);
					curMS.refreshBuffer();
					if (!flfactalma.iface.pub_revisaReservasMSAFaltas(curMS)) {
						return false;
					}
				}
			}
			//debug("quita 3");
			// NUEVO
			if (!_i.quitaReservasEstampacionPed(idLineaPC, codLote)) {
				return false;
			}
			//debug("quita 4");
			// FIN NUEVO
		}
	} else if(idLineaEst && idLineaEst != "") {
		if (!_i.quitaReservasEstampacionNoPed(idLineaEst, codLote)) {
			return false;
		}
	}
	return true;
}

function oficial_creaOrdenProd(f)
{
	var _i = this.iface;
	var hoy = new Date;
	var cursor = this.cursor();

	var std = _i.t_.text(f, _i.cSTD);
	var aStd;
	var codSubfamilia, codDibujo;
	if (!std.toString().startsWith("GR")) {
		//aStd = std.split(_i.sep_);
		//codSubfamilia = aStd[0];
		//codDibujo = aStd[1];
		codSubfamilia = _i.t_.text(f, _i.cCSF);
		codDibujo = _i.t_.text(f, _i.cCDIB);

	}

	var codOrden = formRecordpr_ordenesproduccion.iface.calculateCounter();

	var curO = new FLSqlCursor("pr_ordenesproduccion");
	curO.setModeAccess(curO.Insert);
	curO.refreshBuffer();
	curO.setValueBuffer("codorden", codOrden);
	curO.setValueBuffer("fecha", hoy.toString());
	curO.setValueBuffer("codsubfamilia", codSubfamilia);
	curO.setValueBuffer("subfamilia", _i.t_.text(f, _i.cSFM));
	curO.setValueBuffer("coddibujo", codDibujo);
	curO.setValueBuffer("dibujo", _i.t_.text(f, _i.cDIB));
	curO.setValueBuffer("estado", "PTE");
	curO.setValueBuffer("totallotes", 0);
	curO.setValueBuffer("totaluds", 0);
	//var codPedido = cursor.valueBuffer("codpedido");
	var codPedido = _i.t_.text(f, _i.cPED);
	var nuevaFechaEntrega = cursor.valueBuffer("nuevafechaentrega");
	var fechaEntrega;

	if(codPedido && codPedido != "") {
		curO.setValueBuffer("codpedidocli", codPedido);
		curO.setValueBuffer("codcliente", AQUtil.sqlSelect("pedidoscli", "codcliente", "codigo = '" + codPedido + "'"));
	}

	if(nuevaFechaEntrega && nuevaFechaEntrega != "") {
		fechaEntrega = nuevaFechaEntrega;
	} else if (codPedido && codPedido != "") {
		fechaEntrega = AQUtil.sqlSelect("pedidoscli", "fechasalida", "codigo = '" + codPedido + "'");
	} else {
		var hoy = new Date;
		fechaEntrega = AQUtil.addDays(hoy, 20);
	}
	curO.setValueBuffer("fechaentrega", fechaEntrega);
	curO.setValueBuffer("em_fechaentregaoriginal", fechaEntrega);

	var oGit = this.child("lblOrdenGit").text;
	if (oGit != "") {
		curO.setValueBuffer("emobservaciones", oGit);
		curO.setValueBuffer("nombrecliente", oGit);
	}
	var agrupacion = cursor.valueBuffer("agrupacion");
	if(agrupacion && agrupacion !="") {
		curO.setValueBuffer("em_agrupacion", agrupacion);
	}
	if (cursor.valueBuffer("em_coddropshipping") && cursor.valueBuffer("em_coddropshipping") != "") {
		curO.setValueBuffer("em_coddropshipping", cursor.valueBuffer("em_coddropshipping"));
	}
	curO.setValueBuffer("em_codmodooper", formRecordpr_ordenesproduccion.iface.commonCalculateField("em_codmodooper", curO));

	

	/*var idMovimientoHijo = _i.t_.text(f, _i.cMOVHIJO);

	if(idMovimientoHijo && idMovimientoHijo != "") {
		curO.setValueBuffer("idmovhijo", idMovimientoHijo);
	}*/

	var idArticuloComp = _i.t_.text(f, _i.cIDARTCOMP);

	if(idArticuloComp && idArticuloComp != "") {
		curO.setValueBuffer("idmovhijo", idArticuloComp);
	}

	if (!curO.commitBuffer()) {
		return false;
	}
	return codOrden;
}

function oficial_actualizaPedOP()
{
	var _i = this.iface;

	var whereOrdenes = _i.tdbOrdenes_.cursor().mainFilter();	
	var qO = new AQSqlQuery;	
	qO.setSelect("codorden");
	qO.setFrom("pr_ordenesproduccion");	
	qO.setWhere(whereOrdenes); 			
	if (!qO.exec()){
		return;
	}  
	while(qO.next())
	{	
		var codOrden = qO.value("codorden");		

		var aPedidos = [];
		var q = new AQSqlQuery;	
		q.setSelect("p.codigo");
		q.setFrom("pedidoscli p inner join lineaspedidoscli lp on p.idpedido =lp.idpedido inner join  em_reservaslotepedido rp on rp.idlineapc = lp.idlinea inner join lotesstock ls on ls.codlote = rp.codlote");
		q.setWhere("ls.codordenproduccion = '" + codOrden + "' group by p.codigo"); 				
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{				
			aPedidos.push(q.value("p.codigo"));		
		}		

		
		var curO = new FLSqlCursor("pr_ordenesproduccion");
		curO.setActivatedCommitActions(false);
	 	curO.setActivatedCheckIntegrity(false);
		curO.select("codorden = '" + codOrden + "'");
		curO.setModeAccess(curO.Edit);
		curO.refreshBuffer();
		if(!curO.first()) {
			return true;
		}
		if(aPedidos.length>1) {
			var sPedidos = aPedidos.join(", ");
			if(sPedidos.length >1000) {
				sPedidos = "Varios pedidos";
			}
			curO.setValueBuffer("codpedidocli", sPedidos); 		
	 		curO.setValueBuffer("codcliente", "Varios clientes");			
		} else if (aPedidos.length == 1) {
			curO.setValueBuffer("codpedidocli", aPedidos.join(",")); 		
	 		curO.setValueBuffer("codcliente", AQUtil.sqlSelect("pedidoscli", "codcliente", "codigo = '" + aPedidos.join(",") + "'"));
		} 
	 	if(!curO.commitBuffer()) {
	 		return false;
	 	}
	}	
 	return true;

}
function oficial_anadeLotesOrden(codOrden, f)
{
	//este es el c�digo que hab�a en emodat2_anadeLotesOrden
  var _i = this.iface;

  _i.debugReservasPedido("oficial_anadelotes 1");

  var cursor = this.cursor();
	var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
	var canPrevia;
	var referencia = _i.t_.text(f, _i.cREF);
  	var codLote = AQUtil.sqlSelect("lotesstock", "codlote", "codordenproduccion = '" + codOrden + "' AND referencia = '" + referencia + "'");
	if (!codLote) {
		codLote = _i.creaLote(f, codOrden);
		if (!codLote) {
		  return false;
		}
		canPrevia = 0;
	} else {
		canPrevia = AQUtil.sqlSelect("lotesstock", "canlote", "codlote = '" + codLote + "'");
	}
	canPrevia = isNaN(canPrevia) ? 0 : canPrevia;
	_i.t_.setText(f, _i.cLOT, codLote);
	var canLote = _i.dameCanLote(codLote, referencia);
	
	var canResLinPed = _i.dameCanResLinPed(referencia);
	
	var fabDispPrevia = canPrevia - canResLinPed > 0 ? canPrevia - canResLinPed : 0;
	var fabDisp = canLote - canResLinPed > 0 ? canLote - canResLinPed : 0;
	
	if (fabDisp != fabDispPrevia) {
		var maxIni = _i.t_.text(f, _i.cMAX);
		if (!_i.restaStockLote(referencia, fabDisp - fabDispPrevia)) {
			return false;
		}
		var max = _i.t_.text(f, _i.cMAX);
		max = isNaN(max) ? 0 : max;
		var canResta = _i.t_.text(f, _i.cFAB);
		canResta = isNaN(canResta) ? 0 : canResta;		
		if(max < 0) {				
			if(maxIni >0) {					
				if (!_i.restaStockLotePR(referencia, max*(-1))) {
					return false;
				}							
			} else {				
				if (!_i.restaStockLotePR(referencia, canResta)) {
					return false;
				}					
			}
		}
	}
	if (!_i.modificaCanLote(codLote, canLote)) {
		return false;
	}
	
	var referencia = _i.t_.text(f, _i.cREF);
  
	var idLineaPC = _i.t_.text(f, _i.cLIN);
	var idLineaEst = _i.t_.text(f, _i.cLEST);
	var idMovimientoHijo = _i.t_.text(f, _i.cMOVHIJO);
	var idArticuloComp = _i.t_.text(f, _i.cIDARTCOMP);
	 _i.debugReservasPedido("oficial_anadelotes 2");
	if (idLineaPC && idLineaPC != "") {
		//25-09-2018
		//Aqui hace un borrado que es lo que hace que se eliminen, si quito esto funciona pero claro, quitarlo.... y entonces no se que sentido tiene lo que se hace al final
		/*if (!flfactalma.iface.borraReservasLoteProd(codLote)) {
			return false;
		}*/
		var codD = cursor.valueBuffer("em_coddropshipping");
		if (codD && codD != "") {
			aLineas = idLineaPC.split(", ");
			var resto = canLote;
			var canLinea;
			var curR = new FLSqlCursor("em_reservaslotepedido");
			for (var i = 0; i < aLineas.length; i++) {
				if(fabPorcentaje) {
					canLinea = AQUtil.sqlSelect("movistock", "cantidad", "idlineapc = " + aLineas[i]);
					canLinea = isNaN(canLinea) ? 0 : canLinea;
					canLinea = canLinea *(-1);
				} else {
					canLinea = AQUtil.sqlSelect("movistock", "reservaaf", "idlineapc = " + aLineas[i]);
					canLinea = isNaN(canLinea) ? 0 : canLinea;
				}
				if (canLinea > 0) {
					curR.setActivatedCheckIntegrity(false);
					curR.setModeAccess(curR.Insert);
					curR.refreshBuffer();
					curR.setValueBuffer("codlote", codLote);
					curR.setValueBuffer("idlineapc", aLineas[i]);
					curR.setValueBuffer("cantidad", Math.min(canLinea, resto));
					if (!curR.commitBuffer()) {
						return false;
					}
					resto -= canLinea;
					if (resto == 0) { // No vamos a fabricar todo lo que hay a faltas
						break;
					}
				}
			}
		} else {
			//cambio 20-10-2017
			//var canLinea = AQUtil.sqlSelect("movistock", "reservaaf", "idlineapc = " + idLineaPC);
			var canLinea;
			/*if(fabPorcentaje) {
				if(idMovimientoHijo && idMovimientoHijo != "") {
					canLinea = AQUtil.sqlSelect("movistock", "cantidad", "idmovimiento = " + idMovimientoHijo);
				} else {
					canLinea = AQUtil.sqlSelect("movistock", "cantidad", "idlineapc = " + idLineaPC);
				}
				canLinea = isNaN(canLinea) ? 0 : canLinea;
				canLinea = canLinea *(-1);
			} else {
				if(idMovimientoHijo && idMovimientoHijo != "") {
					canLinea = AQUtil.sqlSelect("movistock", "reservaaf", "idmovimiento = " + idMovimientoHijo);
				} else {
					canLinea = AQUtil.sqlSelect("movistock", "reservaaf", "idlineapc = " + idLineaPC);	
				}
				canLinea = isNaN(canLinea) ? 0 : canLinea;
			}	*/

			if(idMovimientoHijo && idMovimientoHijo != "") {
				//debug("---------1");
				if(fabPorcentaje) {
					//debug("---------2");
					canLinea = AQUtil.sqlSelect("movistock", "cantidad", "idmovimiento = " + idMovimientoHijo);
					canLinea = isNaN(canLinea) ? 0 : canLinea;
					canLinea = canLinea *(-1);
				} else {
					//debug("---------3");
					//canLinea = AQUtil.sqlSelect("movistock", "reservaaf", "idmovimiento = " + idMovimientoHijo);
					canLinea = parseFloat(_i.t_.text(f, _i.cFAB));
					canLinea = isNaN(canLinea) ? 0 : canLinea;
				}
			} else {
				//debug("---------4");
				if(fabPorcentaje) {
				//debug("---------5");					
					canLinea = AQUtil.sqlSelect("movistock", "cantidad", "idlineapc = " + idLineaPC);
					canLinea = isNaN(canLinea) ? 0 : canLinea;
					canLinea = canLinea *(-1);
				} else {
					//debug("---------6");
					//canLinea = AQUtil.sqlSelect("movistock", "reservaaf", "idlineapc = " + idLineaPC);	
					canLinea = parseFloat(_i.t_.text(f, _i.cFAB));
					canLinea = isNaN(canLinea) ? 0 : canLinea;
				}
			}
			//debug("canLinea: "+canLinea);
			
			_i.debugReservasPedido("oficial_anadelotes 3");

			if (canLinea > 0) {
				var curR = new FLSqlCursor("em_reservaslotepedido");
				curR.setActivatedCheckIntegrity(false);
				curR.setModeAccess(curR.Insert);
				curR.refreshBuffer();
				curR.setValueBuffer("codlote", codLote);
				curR.setValueBuffer("idlineapc", idLineaPC);
				curR.setValueBuffer("cantidad", Math.min(canLinea, canLote));

				if(idMovimientoHijo && idMovimientoHijo != "") {	//si es un producto que tiene que colgar de otro, apuntamos el id de articuloscomp correspondiente.
					curR.setValueBuffer("idarticulocomp",idArticuloComp);
				}
				if (!curR.commitBuffer()) {
					return false;
				}
			}
			 _i.debugReservasPedido("oficial_anadelotes 4");
			if(idMovimientoHijo && idMovimientoHijo != "") {
				if(!_i.oMovLote_) {
					_i.oMovLote_ = new Object();
				}
				_i.oMovLote_[codLote] = new Object;
				_i.oMovLote_[codLote]["cantidad"] = canLinea;
				_i.oMovLote_[codLote]["idMovimientoHijo"] = idMovimientoHijo;					
			}
			 _i.debugReservasPedido("oficial_anadelotes 5");

		} 
		 _i.debugReservasPedido("oficial_anadelotes 6");
		aLineas = idLineaPC.split(", ");
		for (var i = 0; i < aLineas.length; i++) {
			if(!_i.copiaReservasEstampacionPed(aLineas[i], codLote)) {
				return false;
			}
		}
		/// Hay que borrarlos ya para que los movimientos de consumo que se generen se asocien a las l�neas de orden de estampaci�n
		var idMov = AQUtil.sqlSelect("movistock", "idmovimiento", "idlineapc IN (" + idLineaPC + ")");
		//if (idMov) {
			/*if (!AQSql.del("movistock", "idmovproducto = " + idMov)) {
				return false;
			}*/
			
			//Aqui tengo una duda de si son hijos producto no habr�a que borrarlos o como hacerlo.	
		//	if(!idMovimientoHijo || idMovimientoHijo == "") {
		//		debug("----------borro los movimeintos hijos");
		//		if (!AQSql.del("movistock", "idmovproducto = " + idMov)) {
		//			return false;
		//		}
		//	}
		//}
		if (idMov) {	
		 _i.debugReservasPedido("oficial_anadelotes 7");	

		 	if(!AQUtil.sqlSelect("em_reservasestlote","idrel","codlote = '" + codLote + "'")) {
				var q = new AQSqlQuery;	
				q.setSelect("res.idmovreserva,res.idmovpterx,res.cantidad,m.idarticulocomp,res.idrlp");
				q.setFrom("movistock m INNER JOIN em_reservaspterx res ON res.idmovreserva = m.idmovimiento");
				q.setWhere("m.idmovproducto = " + idMov); 								
				if (!q.exec()){
					return;
				}  
				while(q.next())
				{
					if(!_i.oMovLoteCompProd_) {
						_i.oMovLoteCompProd_ = new Object();
					}	
					var codLoteCompProd = AQUtil.sqlSelect("movistock","codlote","idmovimiento = " + q.value("res.idmovpterx"));		


					_i.oMovLoteCompProd_[idMov] = new Object;
					_i.oMovLoteCompProd_[idMov]["codLoteCompProd"] = codLoteCompProd;
					_i.oMovLoteCompProd_[idMov]["cantidad"] = q.value("res.cantidad");
					_i.oMovLoteCompProd_[idMov]["idmovreserva"] = q.value("res.idmovreserva");
					_i.oMovLoteCompProd_[idMov]["idmovpterx"] = q.value("res.idmovpterx");
					_i.oMovLoteCompProd_[idMov]["idarticulocomp"] = q.value("m.idarticulocomp");

					if(q.value("res.idrlp") && q.value("res.idrlp") != "" && q.value("res.idrlp") != 0) {
						_i.oMovLoteCompProd_[idMov]["idrlp"] = q.value("res.idrlp");	
					} else {
						_i.oMovLoteCompProd_[idMov]["idrlp"] = "";
					}					
				}
		 	}

			/*if (!AQSql.del("movistock", "idmovproducto = " + idMov)) {
				return false;
			}*/
			var where = "idmovproducto = " + idMov;
			if(_i.aMovHijos_ && _i.aMovHijos_.length >0) {
				where += " AND idmovimiento NOT IN (" + _i.aMovHijos_ + ")";
			}
			 _i.debugReservasPedido("oficial_anadelotes 8");
			if (!AQSql.del("movistock", where)) {
				return false;
			}
			 _i.debugReservasPedido("oficial_anadelotes 9");
		}

	} else if(idLineaEst && idLineaEst != "") {
		if(!_i.copiaReservasEstampacionNoPed(idLineaEst, codLote)) {
			return false;
		}

	}
	 _i.debugReservasPedido("oficial_anadelotes 10");
  	return true;
}

function oficial_dameCanLote(codLote, referencia)
{
	var _i = this.iface;
	var nF = _i.t_.numRows();
	var can = 0, total = 0;
	for (var f = 0; f < nF; f++) {
		if (_i.t_.text(f, _i.cSEL) != "X" || _i.t_.text(f, _i.cLOT) != codLote || _i.t_.text(f, _i.cREF) != referencia) {
			continue;
		}
		can = parseFloat(_i.t_.text(f, _i.cFAB));
		can = isNaN(can) ? 0 : can;
		total += parseFloat(can);
	}
	return total;
}

function oficial_dameCanResLinPed(referencia)
{
	var _i = this.iface;
	var nF = _i.t_.numRows();
	var can = 0, total = 0;
	for (var f = 0; f < nF; f++) {
		if (_i.t_.text(f, _i.cREF) != referencia) {
			continue;
		}
		can = parseFloat(_i.t_.text(f, _i.cRLP));
		can = isNaN(can) ? 0 : can;
		total += parseFloat(can);
	}
	return total;
}

function oficial_revisaCanLote(f)
{
  var _i = this.iface;

  var codLote = _i.t_.text(f, _i.cLOT);
  var canFabrica = _i.t_.text(f, _i.cFAB);
  if (!AQUtil.sqlSelect("lotesstock", "codlote", "codlote = '" + codLote + "' AND canlote = " + canFabrica)) {
		if (!_i.modificaCanLote(codLote, canFabrica)) {
			return false;
		}
  }
  return true;
}

function oficial_creaLote(f, codOrden)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var idMovimientoHijo = _i.t_.text(f, _i.cMOVHIJO);
	var curLote = new FLSqlCursor("lotesstock");

	curLote.setModeAccess(curLote.Insert);
	curLote.refreshBuffer();
	curLote.setValueBuffer("referencia", _i.t_.text(f, _i.cREF));
	var codLote = formRecordlotesstock.iface.pub_calculateCounter(curLote);
	curLote.setValueBuffer("codlote", codLote);
	curLote.setValueBuffer("articulo", formRecordlotesstock.iface.pub_commonCalculateField("articulo", curLote));
	curLote.setValueBuffer("estado", "PTE");
	curLote.setValueBuffer("codalmacen", "1");
	curLote.setValueBuffer("canlote", _i.t_.text(f, _i.cFAB));
	curLote.setValueBuffer("canprogramada", _i.t_.text(f, _i.cFAB));
	curLote.setValueBuffer("codcliente", _i.t_.text(f, _i.cCCL));
	if (_i.t_.text(f, _i.cLIN)) {
		var codD = cursor.valueBuffer("em_coddropshipping");
		if (codD && codD != "") {
		} else {
			if(!idMovimientoHijo || idMovimientoHijo == "") {
				curLote.setValueBuffer("idlineapc", _i.t_.text(f, _i.cLIN));	
			}			
		}
	}
	var fechaEntrega;
	if (_i.t_.text(f, _i.cFSE) != "") {
		fechaEntrega = AQUtil.dateDMAtoAMD(_i.t_.text(f, _i.cFSE));
	} else {
		var hoy = new Date;
		fechaEntrega = AQUtil.addDays(hoy, 20);
	}
	curLote.setValueBuffer("fechafabricacion", fechaEntrega);
	curLote.setValueBuffer("codordenproduccion", codOrden);
	/// ESTO ES LO NUEVO
	curLote.setValueBuffer("emordenoe", _i.t_.text(f, _i.cORD)); 
	/// ESTO ES LO NUEVO FIN

	if (!curLote.commitBuffer()) {
		return false;
	}

	return codLote;
}

function oficial_tbnBuscar_clicked()
{
  var _i = this.iface;
	_i.buscar();
	_i.ordenar();
}
	
function oficial_buscar()
{
  var _i = this.iface;
  var cursor = this.cursor();
  _i.aSDP_ = [];
	_i.ref_ = [];
	_i.lot_ = [];
	_i.lotPR_ = []; //28-09-2015
	_i.refPR_ = [];
	_i.EPRini_ = [];
	
	//var soloMPDisponible = this.child("chkSoloMPDisponible").checked;
	//var stocksBajoMin = this.child("chkStocksBajoMin").checked;
	
	var soloMPDisponible = cursor.valueBuffer("busqmpdisponible");
	var stocksBajoMin = cursor.valueBuffer("busqstocksbajomin");

	
	
	var codOrdenEst = cursor.valueBuffer("codordenest");
	if (codOrdenEst && codOrdenEst != "") {
		return _i.buscarPorEstampacion();
	}
	var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
	
	var criteriosBusqueda = "";
  var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	if (codSubfamilia) {
		criteriosBusqueda += " AND a.codsubfamilia = '" + codSubfamilia + "'";
	}
	var codFamilia = cursor.valueBuffer("codfamilia");
	if (codFamilia) {
		criteriosBusqueda += " AND a.codfamilia = '" + codFamilia + "'";
	}
	var codDibujo = cursor.valueBuffer("coddibujoem");
	if (codDibujo) {
		criteriosBusqueda += " AND a.coddibestamp = '" + codDibujo + "'";
	}
	var refDesde = cursor.valueBuffer("refdesde");
	if (refDesde) {
		criteriosBusqueda += " AND a.referencia >= '" + refDesde + "'";
	}
	var refHasta = cursor.valueBuffer("refhasta");
	if (refHasta) {
		criteriosBusqueda += " AND a.referencia <= '" + refHasta + "'";
	}
	var codColeccionEm = cursor.valueBuffer("codcoleccionem");
	if (codColeccionEm && codColeccionEm != "") {
		criteriosBusqueda += " AND a.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem = '" + codColeccionEm + "')";
	}
	/*var codPedido = cursor.valueBuffer("codpedido");
	if (codPedido) {
		criteriosBusqueda += " AND p.codigo = '" + codPedido + "'";
	}*/

	var criterioBusquedaPed = "";
	var codPedido = cursor.valueBuffer("codpedido");
	if (codPedido && codPedido != "") {
		if(!_i.compruebaCampoPedido(codPedido)) {
			return false;
		}
		if (codPedido.find(",") >= 0) {
			criterioBusquedaPed += (" AND p.codigo IN ('" + codPedido.split(",").join("', '") + "')");
		} else {
			if (codPedido.find("-") >= 0) {
				var min = codPedido.split("-")[0];
				var max = codPedido.split("-")[1];
				criterioBusquedaPed += (" AND p.codigo >= '" + min + "' AND p.codigo <= '" + max + "'");
			} else {
				criterioBusquedaPed += " AND p.codigo = '" + codPedido + "'";
			}
		}
	} 

	var codTipoProdInd = cursor.valueBuffer("em_codtipoprodind");
	if(codTipoProdInd && codTipoProdInd != "") {
		criteriosBusqueda += " AND sf.em_codtipoprodind = '" + codTipoProdInd + "'";
	}

	var famExcluidas = cursor.valueBuffer("codfamiliaex");
	if(famExcluidas && famExcluidas != "") {	
		if(!_i.compruebaCampoFamEx(famExcluidas)) {
			return false;
		}	
		criteriosBusqueda += " AND fam.codfamilia NOT IN ('" + famExcluidas.split(",").join("', '") + "')";
	}

	var subFamExcluidas = cursor.valueBuffer("codsubfamiliaex");
	if(subFamExcluidas && subFamExcluidas != "") {
		if(!_i.compruebaCampoSubFamEx(subFamExcluidas)) {
			return false;
		}	
		criteriosBusqueda += " AND sf.codsubfamilia NOT IN ('" + subFamExcluidas.split(",").join("', '") + "')";
	}

	var seccionFamProd = cursor.valueBuffer("em_codseccionfam");
	if(seccionFamProd && seccionFamProd != "") {
		
		var aFamiliasSec = [];
		var q = new AQSqlQuery;		
		q.setSelect("codfamilia");		
		q.setFrom("familias");		
		q.setWhere("em_codseccion = '" + seccionFamProd + "'");
		if (!q.exec()) {
			return false;
		}
    	while(q.next()) {
    		aFamiliasSec.push("'"+q.value("codfamilia")+"'");
    	}
		if(aFamiliasSec.length == 0) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Secci�n Fam.Prod., no existen familias que perternezcan a la secci�n %1").arg(seccionFamProd),"warn",this);
			return false;
		}
		var lFamSecc = aFamiliasSec.join(","); 
		criteriosBusqueda += " AND fam.codfamilia IN (" + lFamSecc + ")";	
	}

	var seccionSubFamProd = cursor.valueBuffer("em_codseccionsubfam");
	if(seccionSubFamProd && seccionSubFamProd != "") {
		
		var aSubFamiliasSec = [];
		var q = new AQSqlQuery;		
		q.setSelect("codsubfamilia");		
		q.setFrom("subfamilias");		
		q.setWhere("em_codseccion = '" + seccionSubFamProd + "'");
		if (!q.exec()) {
			return false;
		}
    	while(q.next()) {
    		aSubFamiliasSec.push("'"+q.value("codsubfamilia")+"'");
    	}
		if(aSubFamiliasSec.length == 0) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Secci�n Sub.Prod., no existen subfamilias que perternezcan a la secci�n %1").arg(seccionSubFamProd),"warn",this);
			return false;
		}
		var lSubFamSecc = aSubFamiliasSec.join(","); 
		criteriosBusqueda += " AND sf.codsubfamilia IN (" + lSubFamSecc + ")";		
	}


	//var criterioBusquedaTamano = "";
	var codTamanoEM = cursor.valueBuffer("codtamanoem");
	if (codTamanoEM && codTamanoEM != "") {
		if(!_i.compruebaCampoTamano(codTamanoEM)) {
			return false;
		}
		if (codTamanoEM.find(",") >= 0) {
			criteriosBusqueda += (" AND ta.codtamanoem IN ('" + codTamanoEM.split(",").join("', '") + "')");
		} else {
			if (codTamanoEM.find("-") >= 0) {
				var min = codTamanoEM.split("-")[0];
				var max = codTamanoEM.split("-")[1];
				criteriosBusqueda += (" AND ta.codtamanoem >= '" + min + "' AND ta.codtamanoem <= '" + max + "'");
			} else {
				criteriosBusqueda += " AND ta.codtamanoem = '" + codTamanoEM + "'";
			}
		}
	} 

	//var criterioBusquedaColor = "";
	var codColorEM = cursor.valueBuffer("codcolorem");
	if (codColorEM && codColorEM != "") {
		if(!_i.compruebaCampoColor(codColorEM)) {
			return false;
		}
		if (codColorEM.find(",") >= 0) {
			criteriosBusqueda += (" AND co.codcolorem  IN ('" + codColorEM.split(",").join("', '") + "')");
		} else {
			if (codColorEM.find("-") >= 0) {
				var min = codColorEM.split("-")[0];
				var max = codColorEM.split("-")[1];
				criteriosBusqueda += (" AND co.codcolorem >= '" + min + "' AND co.codcolorem <= '" + max + "'");
			} else {
				criteriosBusqueda += " AND co.codcolorem = '" + codColorEM + "'";
			}
		}
	} 




	
	//if(this.child("chkBuscarFechas").checked) {
	if(cursor.valueBuffer("busqentrefechas")) {
		var tipoFecha = cursor.valueBuffer("tipofecha");
		var campoFecha = "";
		switch(tipoFecha) {
			case "Servicio": {
				campoFecha = "fechaservicio";
				break;
			}
			case "Cliente": {
				campoFecha = "fechasalida";
				break;
			}
			case "Pedido": {
				campoFecha = "fecha";
				break;
			}
		}
		
		if(campoFecha && campoFecha != "") {
			var desde = cursor.valueBuffer("fechadesde");
			var hasta = cursor.valueBuffer("fechahasta");
			if(desde && desde != "") {
				criteriosBusqueda += " AND p." + campoFecha + " >= '" + desde + "'";
			}
			if(hasta && hasta != "") {
				criteriosBusqueda += " AND p." + campoFecha + " <= '" + hasta + "'";
			}
		}
	}
	
	debug("criteriosBusqueda " + criteriosBusqueda);
	
	var t = _i.t_;
	t.setNumRows(0);
	var f = 0, std, codLote, referencia;
	var p = 0;
	var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
	//if (this.child("chkBuscarPedidos").checked) {
	if(cursor.valueBuffer("busqpedidos")) {
		var codSerie = cursor.valueBuffer("codserie");
		if (codSerie && codSerie != "") {
			criteriosBusqueda += " AND p.codserie = '" + codSerie + "'";
		}

		var criteriosBusquedaPorc = "";
		if(!fabPorcentaje) {	
			criteriosBusquedaPorc =  " AND ms.reservaaf > 0 ";	
		}

		var criterioBusquedaCli = "";
		var codCliente = cursor.valueBuffer("codcliente");
		if (codCliente && codCliente != "") {
			if(!_i.compruebaCampoCliente(codCliente)) {
				return false;
			}
			if (codCliente.find(",") >= 0) {
				criterioBusquedaCli += (" AND (p.codcliente IN ('" + codCliente.split(",").join("', '") + "') OR cli.codclientefac IN ('" + codCliente.split(",").join("', '") + "'))");
			} else {
				if (codCliente.find("-") >= 0) {
					var min = codCliente.split("-")[0];
					var max = codCliente.split("-")[1];
					criterioBusquedaCli += (" AND (p.codcliente >= '" + min + "' AND p.codcliente <= '" + max + "') OR (cli.codclientefac >= '" + min + "' AND cli.codclientefac <= '" + max + "')");
				} else {
					criterioBusquedaCli += " AND (p.codcliente = '" + codCliente + "' OR cli.codclientefac = '" + codCliente + "')";
				}
			}
		} 

		var criterioBusquedaGrupoCli = "";
		var codGrupoCli = cursor.valueBuffer("codgrupocli");
		if (codGrupoCli && codGrupoCli != "") {
			if(!_i.compruebaCampoGrupoCli(codGrupoCli)) {
				return false;
			}
			if (codGrupoCli.find(",") >= 0) {
				criterioBusquedaGrupoCli += (" AND gc.codgrupo IN ('" + codGrupoCli.split(",").join("', '") + "')");
			} else {
				if (codGrupoCli.find("-") >= 0) {
					var min = codGrupoCli.split("-")[0];
					var max = codGrupoCli.split("-")[1];
					criterioBusquedaGrupoCli += (" AND gc.codgrupo >= '" + min + "' AND gc.codgrupo <= '" + max + "'");
				} else {
					criterioBusquedaGrupoCli += " AND gc.codgrupo = '" + codGrupoCli + "'";
				}
			}
		} 

		var criterioBusquedaDrop = "";
		if (this.child("chkOmitirDropships").checked) {	
			criterioBusquedaDrop = " AND p.em_coddropshipping IS NULL ";
		}	

		var criterioBusquedaColec = "";
		if (this.child("chkOmitirColOcultas").checked) {				
			criterioBusquedaColec += " AND (NOT col.ocultarnecesidades OR col.ocultarnecesidades IS NULL)";			
		}

		if(!cursor.valueBuffer("solocomponentes")) {

			var qryProcesos = new FLSqlQuery();
			with(qryProcesos) {
				setSelect("p.codigo, lp.idlinea, p.codcliente, p.nombrecliente, p.fecha, p.fechaservicio, p.fechasalida, p.idpedido, se.exportprod, ms.reservaaf, sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.referencia, a.descripcion, s.prevision, s.afaltas, s.cantidad, s.disponiblepterecibir, lp.cantidad, co.codcolorem");
				setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN series se ON p.codserie = se.codserie INNER JOIN movistock ms ON (lp.idlinea = ms.idlineapc AND lp.referencia = ms.referencia) INNER JOIN articulos a ON lp.referencia = a.referencia INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia INNER JOIN familias fam ON a.codfamilia = fam.codfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') LEFT OUTER JOIN clientes cli ON cli.codcliente = p.codcliente LEFT OUTER JOIN gruposclientes gc ON gc.codgrupo = cli.codgrupo LEFT OUTER JOIN em_colecciones col ON col.codcoleccionem = a.codcoleccionem");
				//setWhere("ms.estado = 'PTE' " + criteriosBusquedaPorc +" AND a.em_tipoarticulo = 'Producto' AND p.em_coddropshipping IS NULL" + criteriosBusqueda + criterioBusquedaCli + criterioBusquedaGrupoCli); 21-10-2019 a petici�n de Jose
				setWhere("ms.estado = 'PTE' " + criteriosBusquedaPorc +" AND a.em_tipoarticulo = 'Producto' " + criteriosBusqueda + criterioBusquedaCli + criterioBusquedaGrupoCli + criterioBusquedaDrop + criterioBusquedaColec + criterioBusquedaPed);
				setForwardOnly(true);
			}
			debug("pedidos****************************************************************************: "+qryProcesos.sql());
			if (!qryProcesos.exec()) {
				return;
			}
			var idPed;
			flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando pedidos pendientes"), qryProcesos.size());
			var cantidad, disponible, disponibleRx, aFabricar, aFaltas, maxFabricable, maxLinea, extraPR;
			while (qryProcesos.next()) {
				AQUtil.setProgress(p++);
				cantidad = parseFloat(qryProcesos.value("s.cantidad"));
				referencia = qryProcesos.value("a.referencia");
				maxFabricable = _i.dameMaximoFabricable(referencia); 
				
				maxLinea = _i.fabricableLineaPedido(qryProcesos.value("lp.idlinea"));
	// 			maxFabricable += parseFloat(maxLinea);
				//aFabricar = qryProcesos.value("ms.reservaaf");
				aFabricar = _i.dameCantAFabricar(qryProcesos);

				if ((maxFabricable + parseFloat(maxLinea)) < aFabricar  && soloMPDisponible) {
					continue;
				}
				aFaltas = parseFloat(qryProcesos.value("s.afaltas"));
				codLote = qryProcesos.value("ls.codlote");
				t.insertRows(f);
				t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
				t.setText(f, _i.cSFM, qryProcesos.value("sf.descripcion"));
				t.setText(f, _i.cDIB, qryProcesos.value("di.descripcion"));
				t.setText(f, _i.cCOL, qryProcesos.value("co.descripcion"));
				t.setText(f, _i.cCODCOL, qryProcesos.value("co.codcolorem"));			
				t.setText(f, _i.cREF, qryProcesos.value("a.referencia"));
				t.setText(f, _i.cART, qryProcesos.value("a.descripcion"));
				t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
				t.setText(f, _i.cCAN, cantidad);
				t.setText(f, _i.cAFA, aFaltas);
				t.setText(f, _i.cPRE, qryProcesos.value("s.prevision"));
				if(aFabricar != qryProcesos.value("ms.reservaaf") && fabPorcentaje) {
					t.setCellBackgroundColor(f, _i.cFAB, _i.cCanp);
				} else {
					t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);	
				}
				
				t.setText(f, _i.cFAB, aFabricar);
				t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
				t.setText(f, _i.cMAX, maxFabricable);
				t.setText(f, _i.cRLP, maxLinea);
				t.setText(f, _i.cTAM, qryProcesos.value("ta.codtamanoem"));

				t.setText(f, _i.cPED, qryProcesos.value("p.codigo"));
				t.setText(f, _i.cIDP, qryProcesos.value("p.idpedido"));
				t.setText(f, _i.cLIN, qryProcesos.value("lp.idlinea"));
				t.setText(f, _i.cCCL, qryProcesos.value("p.codcliente"));
				t.setText(f, _i.cCLI, qryProcesos.value("p.nombrecliente"));

				/*******************#EUR #H1235 #P0039**************/

				var oParamOrd = new Object;
				oParamOrd.descSubfamilia = qryProcesos.value("sf.descripcion");
				oParamOrd.descDibujo = qryProcesos.value("di.descripcion");
				oParamOrd.codTamano = qryProcesos.value("ta.codtamanoem");


				var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
				t.setText(f, _i.cOrdSTD, sOrdenSTD);  

				var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
				t.setText(f, _i.cOrdSDT, sOrdenSDT);  



				/*******************#EUR #H1235 #P0039**************/


				if (qryProcesos.value("p.fecha")) {
					t.setText(f, _i.cFPE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fecha")));
				}
				if (qryProcesos.value("p.fechaservicio")) {
					t.setText(f, _i.cFSE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechaservicio")));
				}
				if (qryProcesos.value("p.fechasalida")) {
					t.setText(f, _i.cFPR, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechasalida")));
				}
				
				idPed = qryProcesos.value("se.exportprod") ? qryProcesos.value("p.idpedido") : "0";
				

				//std = qryProcesos.value("sf.codsubfamilia") + _i.sep_ + qryProcesos.value("di.coddibujoem") + _i.sep_ + idPed; 08-03-2018


				t.setText(f, _i.cCSF, qryProcesos.value("sf.codsubfamilia"));
				t.setText(f, _i.cCDIB, qryProcesos.value("di.coddibujoem"));

				var oParamOrd = new Object;
				oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
				oParamOrd.codDibujo = t.text(f, _i.cCDIB);
				oParamOrd.idPedido = t.text(f, _i.cIDP);
				oParamOrd.referencia = t.text(f, _i.cREF);
				oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
				oParamOrd.tamanio = t.text(f, _i.cTAM);

	      		std = _i.criterioAgrupacion(oParamOrd);



				if (!(std in _i.aSDP_)) {
					_i.aSDP_[std] = _i.datosSDP();
				}
				t.setText(f, _i.cSTD, std);
				//t.setText(f, _i.cEPR, qryProcesos.value("s.disponiblepterecibir"));
				t.setText(f, _i.cEPR, _i.extraPR(referencia))
				t.setCellBackgroundColor(f, _i.cCANP, _i.cCanp);
				t.setText(f, _i.cCANP, parseFloat(qryProcesos.value("lp.cantidad")));			
				f++;
			}
			AQUtil.destroyProgressDialog();
		}


	/******************************* #EUR #H2176 #P0067*/
		if(cursor.valueBuffer("busqcomponentes")) {
			criteriosBusquedaPorc = "";

			if(!fabPorcentaje) {
				criteriosBusquedaPorc =  " AND ms2.reservaaf > 0 ";	
			}
			var qryProcesos = new FLSqlQuery();
			with(qryProcesos) {
				setSelect("p.codigo, lp.idlinea, lp.referencia, p.codcliente, p.nombrecliente, p.fecha, p.fechaservicio, p.fechasalida, p.idpedido, se.exportprod, ms2.reservaaf, sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.referencia, a.descripcion, s.prevision, s.afaltas, s.cantidad, s.disponiblepterecibir, abs(ms2.cantidad) as cantidad, co.codcolorem, lp.cantidad, ac.cantidad*ac.factor, ac.id, ac.piezasancho, ac.cantidad, ms2.idmovproducto, ms2.idmovimiento");
				setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN series se ON p.codserie = se.codserie INNER JOIN movistock ms ON (lp.idlinea = ms.idlineapc AND lp.referencia = ms.referencia) INNER JOIN movistock ms2 ON (ms.idmovimiento=ms2.idmovproducto) INNER JOIN articulos a ON ms2.referencia = a.referencia INNER JOIN articuloscomp ac ON ac.id = ms2.idarticulocomp INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia INNER JOIN familias fam ON a.codfamilia = fam.codfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') LEFT OUTER JOIN clientes cli ON cli.codcliente = p.codcliente LEFT OUTER JOIN gruposclientes gc ON gc.codgrupo = cli.codgrupo LEFT OUTER JOIN em_colecciones col ON col.codcoleccionem = a.codcoleccionem");
				//setWhere("ms.estado = 'PTE' " + criteriosBusquedaPorc +" AND a.em_tipoarticulo = 'Producto' AND p.em_coddropshipping IS NULL" + criteriosBusqueda + criterioBusquedaCli + criterioBusquedaGrupoCli); 21-10-2019 a petici�n de Jose
				setWhere("ms2.estado = 'PTE' " + criteriosBusquedaPorc +" AND a.em_tipoarticulo = 'Producto' " + criteriosBusqueda + criterioBusquedaCli + criterioBusquedaGrupoCli + criterioBusquedaDrop + criterioBusquedaColec + criterioBusquedaPed);
				setForwardOnly(true);
			}
			debug("pedidos componentes ****************************************************************************: "+qryProcesos.sql());
			if (!qryProcesos.exec()) {
				return;
			}
			var idPed;
			flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando componentes pendientes"), qryProcesos.size());
			var cantidad, disponible, disponibleRx, aFabricar, aFaltas, maxFabricable, maxLinea, extraPR;
			while (qryProcesos.next()) {
				AQUtil.setProgress(p++);
				cantidad = parseFloat(qryProcesos.value("s.cantidad"));
				referencia = qryProcesos.value("a.referencia");
				maxFabricable = _i.dameMaximoFabricable(referencia); 
				
				maxLinea = _i.fabricableLineaPedido(qryProcesos.value("lp.idlinea"));
	// 			maxFabricable += parseFloat(maxLinea);
				//aFabricar = qryProcesos.value("ms.reservaaf");
				aFabricar = _i.dameCantAFabricarComp(qryProcesos);

				if ((maxFabricable + parseFloat(maxLinea)) < aFabricar  && soloMPDisponible) {
					continue;
				}
				aFaltas = parseFloat(qryProcesos.value("s.afaltas"));
				codLote = qryProcesos.value("ls.codlote");
				t.insertRows(f);
				t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
				t.setText(f, _i.cSFM, qryProcesos.value("sf.descripcion"));
				t.setText(f, _i.cDIB, qryProcesos.value("di.descripcion"));
				t.setText(f, _i.cCOL, qryProcesos.value("co.descripcion"));
				t.setText(f, _i.cCODCOL, qryProcesos.value("co.codcolorem"));			
				t.setText(f, _i.cREF, qryProcesos.value("a.referencia"));
				t.setText(f, _i.cART, qryProcesos.value("a.descripcion"));
				t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
				t.setText(f, _i.cCAN, cantidad);
				t.setText(f, _i.cAFA, aFaltas);
				t.setText(f, _i.cPRE, qryProcesos.value("s.prevision"));
				if(aFabricar != qryProcesos.value("ms2.reservaaf") && fabPorcentaje) {
					t.setCellBackgroundColor(f, _i.cFAB, _i.cCanp);
				} else {
					t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);	
				}
				
				t.setText(f, _i.cFAB, aFabricar);
				t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
				t.setText(f, _i.cMAX, maxFabricable);
				t.setText(f, _i.cRLP, maxLinea);
				t.setText(f, _i.cTAM, qryProcesos.value("ta.codtamanoem"));

				t.setText(f, _i.cPED, qryProcesos.value("p.codigo"));
				t.setText(f, _i.cIDP, qryProcesos.value("p.idpedido"));
				t.setText(f, _i.cLIN, qryProcesos.value("lp.idlinea"));
				t.setText(f, _i.cCCL, qryProcesos.value("p.codcliente"));
				t.setText(f, _i.cCLI, qryProcesos.value("p.nombrecliente"));			

				var oParamOrd = new Object;
				oParamOrd.descSubfamilia = qryProcesos.value("sf.descripcion");
				oParamOrd.descDibujo = qryProcesos.value("di.descripcion");
				oParamOrd.codTamano = qryProcesos.value("ta.codtamanoem");


				var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
				t.setText(f, _i.cOrdSTD, sOrdenSTD);  

				var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
				t.setText(f, _i.cOrdSDT, sOrdenSDT);  



				


				if (qryProcesos.value("p.fecha")) {
					t.setText(f, _i.cFPE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fecha")));
				}
				if (qryProcesos.value("p.fechaservicio")) {
					t.setText(f, _i.cFSE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechaservicio")));
				}
				if (qryProcesos.value("p.fechasalida")) {
					t.setText(f, _i.cFPR, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechasalida")));
				}
				
				idPed = qryProcesos.value("se.exportprod") ? qryProcesos.value("p.idpedido") : "0";

				t.setText(f, _i.cCSF, qryProcesos.value("sf.codsubfamilia"));
				t.setText(f, _i.cCDIB, qryProcesos.value("di.coddibujoem"));

				var oParamOrd = new Object;
				oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
				oParamOrd.codDibujo = t.text(f, _i.cCDIB);
				oParamOrd.idPedido = t.text(f, _i.cIDP);
				oParamOrd.referencia = t.text(f, _i.cREF);
				oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
				oParamOrd.tamanio = t.text(f, _i.cTAM);

	      		std = _i.criterioAgrupacion(oParamOrd);



				if (!(std in _i.aSDP_)) {
					_i.aSDP_[std] = _i.datosSDP();
				}
				t.setText(f, _i.cSTD, std);
				//t.setText(f, _i.cEPR, qryProcesos.value("s.disponiblepterecibir"));
				t.setText(f, _i.cEPR, _i.extraPR(referencia))
				t.setCellBackgroundColor(f, _i.cCANP, _i.cCanp);
				t.setText(f, _i.cCANP, parseFloat(qryProcesos.value("abs(ms2.cantidad) as cantidad")));			
				t.setText(f, _i.cMOVHIJO, qryProcesos.value("ms2.idmovimiento"));
				t.setText(f, _i.cIDARTCOMP, qryProcesos.value("ac.id"));


				_i.aMovHijos_.push(qryProcesos.value("ms2.idmovimiento"));
				f++;
			}
			AQUtil.destroyProgressDialog();


			//buscamos componentes en los que ya se ha creado la OP del producto por lo que el no cuelgan del movimiento de padre de la linea si no del lote padre

			criteriosBusquedaPorc = "";

			if(!fabPorcentaje) {
				criteriosBusquedaPorc =  " AND ms2.reservaaf > 0 ";	
			}
			var qryProcesos = new FLSqlQuery();
			with(qryProcesos) {
				setSelect("p.codigo, lp.idlinea, lp.referencia, p.codcliente, p.nombrecliente, p.fecha, p.fechaservicio, p.fechasalida, p.idpedido, se.exportprod, ms2.reservaaf, sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.referencia, a.descripcion, s.prevision, s.afaltas, s.cantidad, s.disponiblepterecibir, abs(ms2.cantidad) as cantidad, co.codcolorem, lp.cantidad, ac.cantidad*ac.factor, ac.id, ac.piezasancho, ac.cantidad, ms2.idmovproducto, ms2.idmovimiento");
				setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN series se ON p.codserie = se.codserie INNER JOIN movistock ms ON (lp.idlinea = ms.idlineapc AND lp.referencia = ms.referencia) INNER JOIN em_reservaslotepedido rlp ON rlp.idlineapc = lp.idlinea INNER JOIN movistock ms2 ON (rlp.codlote = ms2.codloteprod) INNER JOIN articulos a ON ms2.referencia = a.referencia INNER JOIN articuloscomp ac ON ac.id = ms2.idarticulocomp INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia INNER JOIN familias fam ON a.codfamilia = fam.codfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem INNER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') INNER JOIN stocks s2 ON (ms2.idstock = s2.idstock AND s2.codalmacen = '1') LEFT OUTER JOIN clientes cli ON cli.codcliente = p.codcliente LEFT OUTER JOIN gruposclientes gc ON gc.codgrupo = cli.codgrupo LEFT OUTER JOIN em_colecciones col ON col.codcoleccionem = a.codcoleccionem");
				//setWhere("ms.estado = 'PTE' " + criteriosBusquedaPorc +" AND a.em_tipoarticulo = 'Producto' AND p.em_coddropshipping IS NULL" + criteriosBusqueda + criterioBusquedaCli + criterioBusquedaGrupoCli); 21-10-2019 a petici�n de Jose
				setWhere("ms2.estado = 'PTE' " + criteriosBusquedaPorc +" AND a.em_tipoarticulo = 'Producto' " + criteriosBusqueda + criterioBusquedaCli + criterioBusquedaGrupoCli + criterioBusquedaDrop + criterioBusquedaColec + criterioBusquedaPed);
				setForwardOnly(true);
			}
			debug("pedidos****************************************************************************: "+qryProcesos.sql());
			if (!qryProcesos.exec()) {
				return;
			}
			var idPed;
			flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando componentes pendientes"), qryProcesos.size());
			var cantidad, disponible, disponibleRx, aFabricar, aFaltas, maxFabricable, maxLinea, extraPR;
			while (qryProcesos.next()) {
				AQUtil.setProgress(p++);
				cantidad = parseFloat(qryProcesos.value("s.cantidad"));
				referencia = qryProcesos.value("a.referencia");
				maxFabricable = _i.dameMaximoFabricable(referencia); 
				
				maxLinea = _i.fabricableLineaPedido(qryProcesos.value("lp.idlinea"));
	// 			maxFabricable += parseFloat(maxLinea);
				//aFabricar = qryProcesos.value("ms.reservaaf");
				aFabricar = _i.dameCantAFabricarComp(qryProcesos);

				if ((maxFabricable + parseFloat(maxLinea)) < aFabricar  && soloMPDisponible) {
					continue;
				}
				aFaltas = parseFloat(qryProcesos.value("s.afaltas"));
				codLote = qryProcesos.value("ls.codlote");
				t.insertRows(f);
				t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
				t.setText(f, _i.cSFM, qryProcesos.value("sf.descripcion"));
				t.setText(f, _i.cDIB, qryProcesos.value("di.descripcion"));
				t.setText(f, _i.cCOL, qryProcesos.value("co.descripcion"));
				t.setText(f, _i.cCODCOL, qryProcesos.value("co.codcolorem"));			
				t.setText(f, _i.cREF, qryProcesos.value("a.referencia"));
				t.setText(f, _i.cART, qryProcesos.value("a.descripcion"));
				t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
				t.setText(f, _i.cCAN, cantidad);
				t.setText(f, _i.cAFA, aFaltas);
				t.setText(f, _i.cPRE, qryProcesos.value("s.prevision"));
				if(aFabricar != qryProcesos.value("ms2.reservaaf") && fabPorcentaje) {
					t.setCellBackgroundColor(f, _i.cFAB, _i.cCanp);
				} else {
					t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);	
				}
				
				t.setText(f, _i.cFAB, aFabricar);
				t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
				t.setText(f, _i.cMAX, maxFabricable);
				t.setText(f, _i.cRLP, maxLinea);
				t.setText(f, _i.cTAM, qryProcesos.value("ta.codtamanoem"));

				t.setText(f, _i.cPED, qryProcesos.value("p.codigo"));
				t.setText(f, _i.cIDP, qryProcesos.value("p.idpedido"));
				t.setText(f, _i.cLIN, qryProcesos.value("lp.idlinea"));
				t.setText(f, _i.cCCL, qryProcesos.value("p.codcliente"));
				t.setText(f, _i.cCLI, qryProcesos.value("p.nombrecliente"));			

				var oParamOrd = new Object;
				oParamOrd.descSubfamilia = qryProcesos.value("sf.descripcion");
				oParamOrd.descDibujo = qryProcesos.value("di.descripcion");
				oParamOrd.codTamano = qryProcesos.value("ta.codtamanoem");


				var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
				t.setText(f, _i.cOrdSTD, sOrdenSTD);  

				var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
				t.setText(f, _i.cOrdSDT, sOrdenSDT);  



				


				if (qryProcesos.value("p.fecha")) {
					t.setText(f, _i.cFPE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fecha")));
				}
				if (qryProcesos.value("p.fechaservicio")) {
					t.setText(f, _i.cFSE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechaservicio")));
				}
				if (qryProcesos.value("p.fechasalida")) {
					t.setText(f, _i.cFPR, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechasalida")));
				}
				
				idPed = qryProcesos.value("se.exportprod") ? qryProcesos.value("p.idpedido") : "0";

				t.setText(f, _i.cCSF, qryProcesos.value("sf.codsubfamilia"));
				t.setText(f, _i.cCDIB, qryProcesos.value("di.coddibujoem"));

				var oParamOrd = new Object;
				oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
				oParamOrd.codDibujo = t.text(f, _i.cCDIB);
				oParamOrd.idPedido = t.text(f, _i.cIDP);
				oParamOrd.referencia = t.text(f, _i.cREF);
				oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
				oParamOrd.tamanio = t.text(f, _i.cTAM);

	      		std = _i.criterioAgrupacion(oParamOrd);



				if (!(std in _i.aSDP_)) {
					_i.aSDP_[std] = _i.datosSDP();
				}
				t.setText(f, _i.cSTD, std);
				//t.setText(f, _i.cEPR, qryProcesos.value("s.disponiblepterecibir"));
				t.setText(f, _i.cEPR, _i.extraPR(referencia))
				t.setCellBackgroundColor(f, _i.cCANP, _i.cCanp);
				t.setText(f, _i.cCANP, parseFloat(qryProcesos.value("abs(ms2.cantidad) as cantidad")));			
				t.setText(f, _i.cMOVHIJO, qryProcesos.value("ms2.idmovimiento"));
				t.setText(f, _i.cIDARTCOMP, qryProcesos.value("ac.id"));
				t.setText(f, _i.cCONSUMO, "SI");
				_i.aMovHijos_.push(qryProcesos.value("ms2.idmovimiento"));
				f++;
			}
			AQUtil.destroyProgressDialog();
		}

		/*********************************/

		
		if (codPedido || codSerie) {
			return true;
		}
	}
	
	//if (this.child("chkBuscarStocks").checked) {
	if(cursor.valueBuffer("busqstocks")) {
		/// Productos bajo m�nimo
		var whereMin = "a.em_tipoarticulo = 'Producto'";
		//whereMin += (stocksBajoMin ? " AND s.stockmin > (s.disponible + s.disponiblepterecibir) AND (s.stockmax + s.afaltas - s.disponible - s.disponiblepterecibir) > 0" : "");
		whereMin += (stocksBajoMin ? " AND s.stockmin > (s.disponible + s.disponiblepterecibir - s.afaltas)" : "");
		

		var criterioBusquedaColec = "";
		if (this.child("chkOmitirColOcultas").checked) {				
			criterioBusquedaColec += " AND (NOT col.ocultarnecesidades OR col.ocultarnecesidades IS NULL)";			
		}


		
		var qrySMin = new FLSqlQuery();
		with(qrySMin) {
			setTablesList("lotesstock,articulos,pr_procesos");
			setSelect("sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.descripcion, s.stockmax, s.stockmin, s.afaltas, s.cantidad, s.reservada, s.pterecibir, s.prevision, s.disponible, s.disponiblepterecibir, co.codcolorem");
			setFrom("articulos a INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia INNER JOIN familias fam ON a.codfamilia = fam.codfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') LEFT OUTER JOIN em_colecciones col ON col.codcoleccionem = a.codcoleccionem");
			setWhere(whereMin + criteriosBusqueda  + criterioBusquedaColec); /// Revisar, creo que no es correcto
			setForwardOnly(true);
		}
		debug("stocks********************************************************************************************: "+qrySMin.sql());
		if (!qrySMin.exec()) {
			return;
		}
		flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando productos con rotura de stock"), qrySMin.size());
		var p = 0;

		while (qrySMin.next()) {
			AQUtil.setProgress(p++);
			referencia = qrySMin.value("a.referencia");
			maxFabricable = _i.dameMaximoFabricable(referencia);
			
			cantidad = parseFloat(qrySMin.value("s.cantidad"));
			disponible = parseFloat(qrySMin.value("s.disponible"));
			disponibleRx = parseFloat(qrySMin.value("s.disponiblepterecibir"));
			aFaltas = parseFloat(qrySMin.value("s.afaltas"));
			aFabricar = Math.max(parseFloat(qrySMin.value("s.stockmin")), parseFloat(qrySMin.value("s.stockmax"))) + aFaltas - disponible - disponibleRx;
			aFabricar = aFabricar < 0 ? 0 : aFabricar;
			if (maxFabricable < aFabricar && soloMPDisponible) {
				continue;
			}




			t.insertRows(f);

			//std = qrySMin.value("sf.codsubfamilia") + _i.sep_ + qrySMin.value("di.coddibujoem") + _i.sep_ + "0";

			t.setText(f, _i.cCSF, qrySMin.value("sf.codsubfamilia"));
			t.setText(f, _i.cCDIB, qrySMin.value("di.coddibujoem"));
			t.setText(f, _i.cCOL, qrySMin.value("co.descripcion"));
			t.setText(f, _i.cCODCOL, qrySMin.value("co.codcolorem"));
			
			t.setText(f, _i.cTAM, qrySMin.value("ta.codtamanoem"));

			var oParamOrd = new Object;
			oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
			oParamOrd.codDibujo = t.text(f, _i.cCDIB);
			oParamOrd.idPedido = "0";
			oParamOrd.referencia = referencia;
			oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
			oParamOrd.tamanio = t.text(f, _i.cTAM);

      		std = _i.criterioAgrupacion(oParamOrd);


			if (!(std in _i.aSDP_)) {
				_i.aSDP_[std] = _i.datosSDP();
			}

			t.setText(f, _i.cSTD, std);
			t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
			t.setText(f, _i.cPED, "");
			t.setText(f, _i.cIDP, "");
			t.setText(f, _i.cLIN, "");
			t.setText(f, _i.cCCL, "");
			t.setText(f, _i.cCLI, "Stock M�nimo");
			t.setText(f, _i.cSFM, qrySMin.value("sf.descripcion"));
			t.setText(f, _i.cDIB, qrySMin.value("di.descripcion"));
			
			t.setText(f, _i.cREF, referencia);
			t.setText(f, _i.cART, qrySMin.value("a.descripcion"));
			t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
			t.setText(f, _i.cCAN, cantidad);
			t.setText(f, _i.cAFA, aFaltas);
			t.setText(f, _i.cPRE, qrySMin.value("s.prevision"));
			t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);
			t.setText(f, _i.cFAB, aFabricar);
			t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
			t.setText(f, _i.cMAX, maxFabricable);
			t.setText(f, _i.cRLP, 0);
			t.setText(f, _i.cFPE, "");
			t.setText(f, _i.cFSE, "");
			t.setText(f, _i.cFPR, "");
			
			t.setText(f, _i.cEPR, _i.extraPR(referencia));



			/*******************#EUR #H1235 #P0039**************/

			var oParamOrd = new Object;
			oParamOrd.descSubfamilia = qrySMin.value("sf.descripcion");
			oParamOrd.descDibujo = qrySMin.value("di.descripcion");
			oParamOrd.codTamano = qrySMin.value("ta.codtamanoem");


			var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
			t.setText(f, _i.cOrdSTD, sOrdenSTD);  

			var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
			t.setText(f, _i.cOrdSDT, sOrdenSDT);  



			/*******************#EUR #H1235 #P0039**************/





			
			f++;
		}
		AQUtil.destroyProgressDialog();
    return true;
	}


		var criterioBusquedaDrop = "";
		if (this.child("chkOmitirDropships").checked) {	
			criterioBusquedaDrop = " AND p.em_coddropshipping IS NULL ";
		}	

		var criterioBusquedaColec = "";
		if (this.child("chkOmitirColOcultas").checked) {				
			criterioBusquedaColec += " AND (NOT col.ocultarnecesidades OR col.ocultarnecesidades IS NULL)";			
		}



  var codD = cursor.valueBuffer("em_coddropshipping");
  if (codD && codD != "") {
    var qryD = new FLSqlQuery();
    qryD.setSelect("p.codigo, lp.idlinea, d.codcliente, c.nombre, d.fechapedidos, ms.reservaaf, sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.descripcion, s.prevision, s.afaltas, s.cantidad, s.disponiblepterecibir, co.codcolorem");
    qryD.setFrom("pedidoscli p INNER JOIN em_dropshipping d ON p.em_coddropshipping = d.codigo INNER JOIN clientes c ON d.codcliente = c.codcliente INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN movistock ms ON (lp.idlinea = ms.idlineapc AND lp.referencia = ms.referencia) INNER JOIN articulos a ON lp.referencia = a.referencia INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia INNER JOIN familias fam ON a.codfamilia = fam.codfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') LEFT OUTER JOIN em_colecciones col ON col.codcoleccionem = a.codcoleccionem");
    qryD.setWhere("p.em_coddropshipping = '" + codD + "' AND ms.estado = 'PTE' AND ms.reservaaf > 0 AND a.em_tipoarticulo = 'Producto'" + criteriosBusqueda + criterioBusquedaDrop + criterioBusquedaColec + criterioBusquedaPed + " ORDER BY a.referencia");
    qryD.setForwardOnly(true);
    
    debug(qryD.sql());
    if (!qryD.exec()) {
      return;
    }
    var idPed;
    flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando pedidos de dropshipping"), qryD.size());

    var cantidad, disponible, disponibleRx, aFabricar, aFaltas, maxFabricable, maxLinea, extraPR;
    var idLinea, referencia, referenciaAnt = false;
    var totalAFabricar = 0, listaIdLinea = "", listaIdPedido = "", listaCodPedido = "";

    f = -1;
    while (qryD.next()) {
      AQUtil.setProgress(p++);
      
      idLinea = qryD.value("lp.idlinea");
      referencia = qryD.value("a.referencia");

      if (referencia != referenciaAnt) {
        cantidad = parseFloat(qryD.value("s.cantidad"));
        aFaltas = parseFloat(qryD.value("s.afaltas"));
        if (f >= 0) {
          maxFabricable = _i.dameMaximoFabricable(referenciaAnt); 
          maxLinea = _i.fabricableLineaPedido(listaIdLinea);
          
          t.setText(f, _i.cFAB, totalAFabricar);
          t.setText(f, _i.cLIN, listaIdLinea);
          t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
          t.setText(f, _i.cMAX, maxFabricable);
          t.setText(f, _i.cRLP, maxLinea);
        }
        f++;
        totalAFabricar = 0;
        listaIdLinea = "";
        t.insertRows(f);
        t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
        t.setText(f, _i.cSFM, qryD.value("sf.descripcion"));
        t.setText(f, _i.cDIB, qryD.value("di.descripcion"));
        t.setText(f, _i.cCOL, qryD.value("co.descripcion"));
        t.setText(f, _i.cCODCOL, qryD.value("co.codcolorem"));
        
        t.setText(f, _i.cREF, referencia);
        t.setText(f, _i.cART, qryD.value("a.descripcion"));
        t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
        t.setText(f, _i.cCAN, cantidad);
        t.setText(f, _i.cAFA, aFaltas);
        t.setText(f, _i.cPRE, qryD.value("s.prevision"));
        t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);
        t.setText(f, _i.cTAM, qryD.value("ta.codtamanoem"));

      //t.setText(f, _i.cPED, qryD.value("p.codigo")); �listas de c�digos como para las l�neas?
      //t.setText(f, _i.cIDP, qryD.value("p.idpedido"));



			/*******************#EUR #H1235 #P0039**************/

			var oParamOrd = new Object;
			oParamOrd.descSubfamilia = qryD.value("sf.descripcion");
			oParamOrd.descDibujo = qryD.value("di.descripcion");
			oParamOrd.codTamano = qryD.value("ta.codtamanoem");


			var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
			t.setText(f, _i.cOrdSTD, sOrdenSTD);  

			var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
			t.setText(f, _i.cOrdSDT, sOrdenSDT);  



			/*******************#EUR #H1235 #P0039**************/




      
        t.setText(f, _i.cCCL, qryD.value("d.codcliente"));
        t.setText(f, _i.cCLI, qryD.value("c.nombre"));
        if (qryD.value("d.fechapedidos")) {
          t.setText(f, _i.cFPE, AQUtil.dateAMDtoDMA(qryD.value("d.fechapedidos")));
        }
        idPed = "0";
       // std = qryD.value("sf.codsubfamilia") + _i.sep_ + qryD.value("di.coddibujoem") + _i.sep_ + idPed;

        t.setText(f, _i.cCSF, qryD.value("sf.codsubfamilia"));
		t.setText(f, _i.cCDIB, qryD.value("di.coddibujoem"));

		var oParamOrd = new Object;
		oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
		oParamOrd.codDibujo = t.text(f, _i.cCDIB);
		oParamOrd.idPedido = idPed;
		oParamOrd.referencia = referencia;
		oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
		oParamOrd.tamanio = t.text(f, _i.cTAM);

      	std = _i.criterioAgrupacion(oParamOrd);




        if (!(std in _i.aSDP_)) {
          _i.aSDP_[std] = _i.datosSDP();
        }
        t.setText(f, _i.cSTD, std);
        t.setText(f, _i.cEPR, _i.extraPR(referencia))
        referenciaAnt = referencia;
      } else {
        listaIdLinea += ", ";
      }
      aFabricar = qryD.value("ms.reservaaf");
      if (!isNaN(aFabricar)) {
        totalAFabricar += parseFloat(aFabricar);
      }
      listaIdLinea += idLinea;
    }
    if (f >= 0) {
      maxFabricable = _i.dameMaximoFabricable(referenciaAnt); 
      maxLinea = _i.fabricableLineaPedido(listaIdLinea);
      
      t.setText(f, _i.cFAB, totalAFabricar);
      t.setText(f, _i.cLIN, listaIdLinea);
      t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
      t.setText(f, _i.cMAX, maxFabricable);
      t.setText(f, _i.cRLP, maxLinea);
    }
    AQUtil.destroyProgressDialog();
  }
	
}

function oficial_iniciarTabla()
{
	var _i = this.iface;

	var c = 0, cH = [];
	_i.cSTD = c++;
	_i.cIDP = c++;
	_i.cPED = c++;
	_i.cLIN = c++;
	_i.cCCL = c++;
	_i.cCLI = c++;
	_i.cREF = c++;
	_i.cSFM = c++;
	_i.cDIB = c++;
	_i.cCOL = c++;
	_i.cTAM = c++;
	_i.cCANP = c++;
	_i.cCAN = c++;
	_i.cAFA = c++;
	_i.cPRE = c++;
	_i.cFAB = c++;
	_i.cSEL = c++;
	_i.cMAX = c++;
	_i.cEPR = c++;
	_i.cRLP = c++;
	_i.cFPE = c++;
	_i.cFSE = c++;
	_i.cFPR = c++;
	_i.cLOT = c++;
	_i.cART = c++;
	_i.cORD = c++;
	_i.cCSF = c++;
	_i.cCDIB = c++;
	_i.cOrdSDT = c++;
	_i.cOrdSTD = c++;
	_i.cCODCOL = c++;
	_i.cLEST = c++;
	_i.cMOVHIJO = c++;
	_i.cIDARTCOMP = c++;
	_i.cCONSUMO = c++;

	cH[_i.cSTD] = AQUtil.translate("scripts", "STD");
	cH[_i.cSEL] = AQUtil.translate("scripts", "Sel.");
	cH[_i.cPED] = AQUtil.translate("scripts", "Pedido");
	cH[_i.cIDP] = AQUtil.translate("scripts", "Id.Pedido");
	cH[_i.cLIN] = AQUtil.translate("scripts", "L�nea");
	cH[_i.cCCL] = AQUtil.translate("scripts", "C�d.Cliente");
	cH[_i.cCLI] = AQUtil.translate("scripts", "Cliente");
	cH[_i.cSFM] = AQUtil.translate("scripts", "Subfam.");
	cH[_i.cDIB] = AQUtil.translate("scripts", "Dibujo");
	cH[_i.cCOL] = AQUtil.translate("scripts", "Color");
	cH[_i.cART] = AQUtil.translate("scripts", "Art�culo");
	cH[_i.cCANP] = AQUtil.translate("scripts", "Pedida");
	cH[_i.cCAN] = AQUtil.translate("scripts", "Existencias");
	cH[_i.cAFA] = AQUtil.translate("scripts", "A Faltas");
	cH[_i.cPRE] = AQUtil.translate("scripts", "Previsi�n");
	cH[_i.cFAB] = AQUtil.translate("scripts", "A Fabricar");
	cH[_i.cMAX] = AQUtil.translate("scripts", "+Extra");
	cH[_i.cEPR] = AQUtil.translate("scripts", "+Extra P.R.");
	cH[_i.cRLP] = AQUtil.translate("scripts", "M�x.L�nea");
	cH[_i.cFPE] = AQUtil.translate("scripts", "F.Pedido");
	cH[_i.cFSE] = AQUtil.translate("scripts", "F.Servicio");
	cH[_i.cFPR] = AQUtil.translate("scripts", "F.Cliente");
	cH[_i.cLOT] = AQUtil.translate("scripts", "Lote");
	cH[_i.cTAM] = AQUtil.translate("scripts", "Tama�o");
	cH[_i.cREF] = AQUtil.translate("scripts", "Referencia");
	cH[_i.cORD] = AQUtil.translate("scripts", "Orden");
	cH[_i.cCSF] = AQUtil.translate("scripts", "Cod.Subfam.");
	cH[_i.cCDIB] = AQUtil.translate("scripts", "Cod.Dibujo");
	cH[_i.cOrdSDT] = AQUtil.translate("scripts", "Subfamilia-Dibujo-Tama�o");
	cH[_i.cOrdSTD] = AQUtil.translate("scripts", "Subfamilia-Tama�o-Dibujo");
	cH[_i.cCODCOL] = AQUtil.translate("scripts", "C�digo Color");
	cH[_i.cLEST] = AQUtil.translate("scripts", "Idlinea est.");
	cH[_i.cMOVHIJO] = AQUtil.translate("scripts", "Movimiento hijo");
	cH[_i.cIDARTCOMP] = AQUtil.translate("scripts", "Id Articulo Comp.");
	cH[_i.cCONSUMO] = AQUtil.translate("scripts", "Consumo");
	

	

	var t = this.child("tblLineas");
	t.setNumCols(c);
	t.setColumnWidth(_i.cSEL, 40);
	t.hideColumn(_i.cIDP);
	t.setColumnWidth(_i.cPED, 90);
	t.setColumnWidth(_i.cLIN, 50);
	t.hideColumn(_i.cCCL);
	t.setColumnWidth(_i.cCLI, 140);
	t.setColumnWidth(_i.cSFM, 100);
	t.setColumnWidth(_i.cDIB, 100);
	t.setColumnWidth(_i.cCOL, 90);
	t.setColumnWidth(_i.cART, 150);
	t.setColumnWidth(_i.cCAN, 60);
	t.setColumnWidth(_i.cAFA, 60);
	t.setColumnWidth(_i.cPRE, 60);
	t.setColumnWidth(_i.cFAB, 70);
	t.setColumnWidth(_i.cMAX, 55);
	t.setColumnWidth(_i.cEPR, 70);
	t.setColumnWidth(_i.cRLP, 60);
	t.setColumnWidth(_i.cFPE, 75);
	t.setColumnWidth(_i.cFSE, 75);
	t.setColumnWidth(_i.cFPR, 75);
	t.setColumnWidth(_i.cLOT, 80);
	t.setColumnWidth(_i.cTAM, 80);
	t.setColumnWidth(_i.cREF, 75);
	t.setColumnWidth(_i.cORD, 50);
	t.setColumnWidth(_i.cCANP, 55);
	t.setColumnWidth(_i.cMOVHIJO, 100);
	t.setColumnWidth(_i.cIDARTCOMP, 100);
	t.setColumnWidth(_i.cCONSUMO, 100);
	

	t.setColumnReadOnly(_i.cSEL, true);
	t.setColumnReadOnly(_i.cPED, true);
	t.setColumnReadOnly(_i.cIDP, true);
	t.setColumnReadOnly(_i.cLIN, true);
	t.setColumnReadOnly(_i.cCLI, true);
	t.setColumnReadOnly(_i.cCCL, true);
	t.setColumnReadOnly(_i.cSFM, true);
	t.setColumnReadOnly(_i.cDIB, true);
	t.setColumnReadOnly(_i.cCOL, true);
	t.setColumnReadOnly(_i.cCAN, true);
	t.setColumnReadOnly(_i.cMAX, true);
	t.setColumnReadOnly(_i.cEPR, true);
	t.setColumnReadOnly(_i.cRLP, true);
	t.setColumnReadOnly(_i.cFPE, true);
	t.setColumnReadOnly(_i.cFSE, true);
	t.setColumnReadOnly(_i.cFPR, true);
	t.setColumnReadOnly(_i.cLOT, true);
	t.setColumnReadOnly(_i.cTAM, true);
	t.setColumnReadOnly(_i.cREF, true);
	t.setColumnReadOnly(_i.cORD, true);
	t.setColumnReadOnly(_i.cCANP, true);
	t.setColumnReadOnly(_i.cCSF, true);
	t.setColumnReadOnly(_i.cCDIB, true);
	t.setColumnReadOnly(_i.cOrdSDT, true);
	t.setColumnReadOnly(_i.cOrdSTD, true);
	t.setColumnReadOnly(_i.cCODCOL, true);
	t.setColumnReadOnly(_i.cLEST, true);
	t.setColumnReadOnly(_i.cMOVHIJO, true);
	t.setColumnReadOnly(_i.cIDARTCOMP, true);	
	t.setColumnReadOnly(_i.cCONSUMO, true);


	t.hideColumn(_i.cOrdSDT);
   	t.hideColumn(_i.cOrdSTD);
   	//t.hideColumn(_i.cCODCOL);
   	

	t.setColumnLabels("*", cH.join("*"));
}

function oficial_tbnLanzar_clicked()
{
  var _i = this.iface;

	/*
	if (!_i.lanzaProcesos()) {
      return false;
    } 
    return true;
    */
    
  var curT = new FLSqlCursor("empresa");
  curT.transaction(false);

	AQS.Application_setOverrideCursor(AQS.WaitCursor);
  try {
    if (_i.lanzaProcesos()) {
      curT.commit();
    } else {
			curT.rollback();
      AQS.Application_restoreOverrideCursor();
      MessageBox.warning(sys.translate("scripts", "Error al lanzar los procesos de fabricaci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return;
    }
  } catch (e) {
    curT.rollback();
    AQS.Application_restoreOverrideCursor();
		MessageBox.warning(sys.translate("scripts", "Error al lanzar los procesos de fabricaci�n: ") + e, MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return;
  }
  AQS.Application_restoreOverrideCursor();
  if (!_i.comprobarProcesosDuplicados()) {
  	return false;
  }
  _i.oMovLote_ = false;
  _i.oMovLoteCompProd_ = false;
  this.accept();
}

function oficial_comprobarProcesosDuplicados()
{
	return true; // Da error de campo estado ambiguo
 	var _i = this.iface;
	var whereOrdenes = _i.tdbOrdenes_.cursor().mainFilter();
	
	var codOrden = AQUtil.sqlSelect("pr_ordenesproduccion INNER JOIN pr_procesos ON pr_ordenesproduccion.codorden = pr_procesos.idobjeto", "codorden", whereOrdenes + " GROUP BY codorden HAVING COUNT(*) > 1", "pr_ordenesproduccion");
	if (codOrden) {
		sys.warnMsgBox(sys.translate("Error: Al menos la orden %1 tiene m�s de un procesos de fabricaci�n asociado").arg(codOrden));
		return false
	}
	//debug("No hay duplicados________________________");
	return true;
}

function oficial_lanzaProcesos()
{
	debug("\n\noficial_lanzaProcesos");
	var _i = this.iface;
	var whereOrdenes = _i.tdbOrdenes_.cursor().mainFilter();

	var curOrdenes = new FLSqlCursor("pr_ordenesproduccion");
	curOrdenes.select(whereOrdenes + " ORDER BY idmovhijo DESC");
	var numProcesos, codOrden, idTipoProceso, idProceso;

	var curProceso = new FLSqlCursor("pr_procesos");
	var qProcesos = new FLSqlQuery;
	qProcesos.setSelect("a.idtipoproceso");
	qProcesos.setFrom("lotesstock ls INNER JOIN articulos a ON ls.referencia = a.referencia");
	qProcesos.setForwardOnly(true);
	var p = 0;
	while (curOrdenes.next()) {
		curOrdenes.setModeAccess(curOrdenes.Edit);
		curOrdenes.refreshBuffer();
		codOrden = curOrdenes.valueBuffer("codorden");

		//debug("\n\n----------------------------------------Cordenre: "+codOrden);
		qProcesos.setWhere("ls.codordenproduccion = '" + codOrden + "' GROUP BY a.idtipoproceso");
		if (!qProcesos.exec()) {
			debug("error 1");
			return false;
		}
		if (!qProcesos.first()) {
			debug("error 2");
			return false;
		}
		numProcesos = qProcesos.size();
		if (numProcesos > 1) {
			MessageBox.warning(sys.translate("scripts", "La orden %1 no puede lanzarse. Contiene lotes con distintos procesos de fabricaci�n").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			debug("error 3");
			return false;
		}
		idTipoProceso = qProcesos.value("a.idtipoproceso");
		if (!idTipoProceso) {
			sys.warnMsgBox(sys.translate("Alguno de los art�culos de la orden %1 no tiene proceso de producci�n asociado").arg(codOrden));
			debug("error 4");
			return false;
		}
		debug("\n\n********************** oficial_lanzaProcesos 1 *********************\n\n");
		idProceso = flcolaproc.iface.pub_crearProceso(idTipoProceso, "pr_ordenesproduccion", codOrden)
		if (!idProceso) {
			MessageBox.warning(sys.translate("scripts", "Error al crear el proceso de fabricaci�n para la orden %1").arg(codOrden), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			debug("error 5");
			return false;
		}
		debug("\n\n********************** oficial_lanzaProcesos 2 *********************\n\n");
		curProceso.select("idproceso = " + idProceso);
		if (!curProceso.first()) {
			debug("error 6");
			return false;
		}
		curProceso.setModeAccess(curProceso.Browse);
		curProceso.refreshBuffer();

		var qLote = new FLSqlQuery;
		qLote.setSelect("l.codlote, l.canlote, l.referencia, a.em_situaciongenft, a.referencia");
		qLote.setFrom("lotesstock l inner join articulos a on l.referencia = a.referencia");
		qLote.setWhere("l.codordenproduccion = '" + codOrden + "'");
		qLote.setForwardOnly(true);
		if (!qLote.exec()) {
			debug("error 7");
			return false;
		}
		var codLote, cantidad, referencia, situacion;
		var totalMetros = 0;
		var metros = 0;
	
		var oAdicionales = _i.cargaObjetoAdicionales(codOrden);

		while (qLote.next()) {

			situacion = qLote.value("a.em_situaciongenft");
			if(situacion == "EN REVISI�N") {
				sys.warnMsgBox(sys.translate("La FT del producto %1 est� EN REVISI�N").arg(qLote.value("a.referencia")));			
				debug("error 4.5");
				return false;	
			}


			codLote = qLote.value("l.codlote");
			cantidad = qLote.value("l.canlote");


			debug("\n\n********************** oficial_lanzaProcesos 3 *********************\n\n");
			//debug("codLote: "+codLote);
			//debug("cantidad: "+cantidad);
			if (!flfactalma.iface.pub_generarMoviStock(curProceso, codLote, cantidad)) {
				return false;
			}
			//       if (!flfactalma.iface.pub_revisarStocksComponentesLote(codLote)) {
			// 				return false;
			// 			}
			debug("\n\n********************** oficial_lanzaProcesos 4 *********************\n\n");
			referencia = qLote.value("l.referencia");
			metros = formRecordarticulos.iface.prendasAMetros(referencia, cantidad);
			if(!metros) {
				metros = 0;
			}
			totalMetros = parseFloat(totalMetros) + parseFloat(metros);
			debug("\n\n********************** oficial_lanzaProcesos 4b *********************\n\n");

			_i.gramajesOrdenesProd(oAdicionales, referencia);

      		debug("\n\n********************** oficial_lanzaProcesos 4c *********************\n\n");

		}
		debug("\n\n********************** oficial_lanzaProcesos 5 *********************\n\n");
		oAdicionales.totalMetros = totalMetros;
		if(!_i.calculaAdicionalesRet(oAdicionales)) {
			debug("error 7b")
			return false;
		}
		debug("\n\n********************** oficial_lanzaProcesos 6 *********************\n\n");

		if (!_i.creaConsumosLotesFT(codOrden)) {
			debug("error 8");
			return false;
		}
		debug("\n\n********************** oficial_lanzaProcesos 7 *********************\n\n");

		if (!_i.reservaStocksPedido(codOrden)) {
			return false;
		}
		debug("\n\n********************** oficial_lanzaProcesos 8 *********************\n\n");

		if (!_i.revisaStocks()) {
			debug("error 9");
			return false;
		}
		
		debug("\n\n********************** oficial_lanzaProcesos 9 *********************\n\n");
	}
	debug("\n\n********************** oficial_lanzaProcesos 10 *********************\n\n");	

	if(!_i.agruparOrdenes(whereOrdenes)) {
		return false
	} 
	debug("\n\n********************** oficial_lanzaProcesos 11 *********************\n\n");
	AQS.Application_restoreOverrideCursor();
	var res = MessageBox.information(sys.translate("Los procesos de producci�n han sido lanzados correctamente"), MessageBox.Ok, MessageBox.Cancel, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Ok) {
		return false;
	}
	debug("\n\n********************** oficial_lanzaProcesos 12 *********************\n\n");
	if (!_i.revisaReservasPedidos()) {
		return false;
	}	
	if(!_i.actualizaPedOP()) {		
		return false;
	}
	debug("\n\n********************** oficial_lanzaProcesos 14 FIN *********************\n\n");

	return true;
}

function oficial_cargaObjetoAdicionales(codOrden)
{
    var oAdicionales = new Object;
    oAdicionales.gramajes = [];
    oAdicionales.acabados = [];
    oAdicionales.tejidos = [];
    oAdicionales.totalMetros = 0;
    oAdicionales.codOrden = codOrden;

    return oAdicionales;
}


/*function oficial_calculaMetrosOP(codOrden, totalMetros)
{
	var _i = this.iface;
	if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET totalmetros = " + totalMetros + ", metrosptes = " + totalMetros + ", udsptes = totaluds WHERE codorden = '" + codOrden + "'")) {
		return false;
	}
	return true;
}*/

function oficial_calculaAdicionalesRet(oAdicionales)
{//////////////////////////////////////////////////////////////////////////////////////////////////

	var codOrden = oAdicionales.codOrden;
	var totalMetros = oAdicionales.totalMetros;
	var referencia = AQUtil.sqlSelect("lotesstock","referencia", "codordenproduccion = '" + codOrden + "' order by codlote desc");
	
	if(!referencia){
		return false;
	}

	var refCompAnv = AQUtil.sqlSelect("articuloscomp","refcomponente", "refcompuesto ='" + referencia + "' AND componormal IN ('ANVERSO', 'ANVERSO COJIN') ORDER BY componormal");
	
	if(!refCompAnv){
		refCompAnv = null;
	} else {
		refCompAnv = "'" + refCompAnv + "'";
	}
	var refCompRevColor = "";
	var refCompRev = AQUtil.sqlSelect("articuloscomp","refcomponente", "refcompuesto ='" + referencia + "' AND componormal IN ('REVERSO', 'REVERSO COJIN') ORDER BY componormal");	
	if(!refCompRev){
		refCompRev = null;
	} else {
		refCompRevColor = refCompRev;
		refCompRev = "'" + refCompRev + "'";
	}
/*-----------------------------------------------------------------------------------------------*/
	//color campo codcolorem de la ficha de articulos
	var colorDibujo = null;
	var codColorAnv = AQUtil.sqlSelect("articulos","codcolorem", "referencia = " + refCompAnv + " ");
	var codColorRev = AQUtil.sqlSelect("articulos","codcolorem", "referencia = " + refCompRev + " ");

	var lisoAnv= AQUtil.sqlSelect("em_dibujos INNER JOIN articulos ON em_dibujos.coddibujoem = articulos.coddibestamp","liso", "referencia = " + refCompAnv + " ","em_dibujos,articulos");
	var lisoRev = AQUtil.sqlSelect("em_dibujos INNER JOIN articulos ON em_dibujos.coddibujoem = articulos.coddibestamp","liso", "referencia = " + refCompRev + " ","em_dibujos,articulos");
	

	if(codColorAnv == 'BLANCO' && codColorRev == 'BLANCO') {
		colorDibujo = "'BLANCO'";
	} else if(lisoAnv && lisoRev) {
		colorDibujo = "'BICOLOR'";		
	} else if(!lisoAnv) {
		var panotContAnv = AQUtil.sqlSelect("articulos","panotcont", "referencia = " + refCompAnv + " ");
	
		if(panotContAnv == "Continuo") {
			colorDibujo = "'Est. Continuo'";
		}else if(panotContAnv == "Panot") {
			colorDibujo = "'Est. Panot'";
		}
 	}		
 	

// para el anchopiezatejido hay que ir a articuloscomp where refcomponente = '" + refCompAnv + "' and refcompuesto = 'referencia';	
	var anchoPiezaTejido = null;
	var anchoPiezaTejido = AQUtil.sqlSelect("articuloscomp","anchopiezatej", "refcomponente = " + refCompAnv + " and refcompuesto = '"+referencia+"'");

	
//referencia - color
	var colorReverso = null;
	if(refCompRevColor && refCompRevColor != ""){
		colorReverso =  "'" + refCompRevColor + " - " + codColorRev + "'";
	}


	 

	/*var qh=new AQSqlQuery;
	qh.setSelect("em_acabadosfam.acabado");
	qh.setFrom("em_acabadosfam inner join articulos on em_acabadosfam.codfamilia = articulos.codfamilia");
	qh.setWhere("articulos.referencia ='"+referencia+"'");
	if (!qh.exec()) {
		return false;
	}
	var acabado = "";
	var primero = true;
	while(qh.next()){		
		if(primero){
			acabado = qh.value("em_acabadosfam.acabado");
			primero = false;
		}else{
			acabado = acabado + "," + qh.value("em_acabadosfam.acabado");
		}	
	}	*/

	/*var qh=new AQSqlQuery;
	qh.setSelect("subfamilias.em_alias");
	qh.setFrom("subfamilias inner join articulos on subfamilias.codsubfamilia = articulos.codsubfamilia");
	qh.setWhere("articulos.referencia ='"+referencia+"'");
	var tejido;
	if (!qh.exec()) {
		tejido = "";
	}
	qh.next();
	tejido = qh.value("subfamilias.em_alias");
	if(!tejido){
		tejido = null;
	} else {
		tejido ="'" + tejido +"'";
	}*/


	var sGramajes = "";
	for(gramaje in oAdicionales.gramajes) {
		sGramajes += sGramajes == "" ? "" : "-";
		sGramajes += gramaje;	
	}

	if(sGramajes == "") {
		sGramajes = null;
	} else {
		sGramajes = "'" + sGramajes + "'";
	}

	var sAcabados = "";
	for(acabado in oAdicionales.acabados) {
		sAcabados += sAcabados == "" ? "" : ",";
		sAcabados += acabado;	
	}

	if(sAcabados == "") {
		sAcabados = null;
	} else {
		sAcabados = "'" + sAcabados + "'";
	}

	var sTejidos = "";
	for(tejido in oAdicionales.tejidos) {
		sTejidos += sTejidos == "" ? "" : ",";
		sTejidos += tejido;	
	}

	if(sTejidos == "") {
		sTejidos = null;
	} else {
		sTejidos = "'" + sTejidos + "'";
	}

	if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_acabados = " + sAcabados + ", em_alias = " + sTejidos + ", em_anverso = " + refCompAnv + ", em_reverso = " + refCompRev + ", em_colordibujo = " + colorDibujo + ", em_anchotejido = " + anchoPiezaTejido + ", em_colorreverso = " + colorReverso + ",totalmetros = " + totalMetros + ", metrosptes = " + totalMetros + ", udsptes = totaluds, em_gramaje = " + sGramajes + " WHERE codorden = '" + codOrden + "'")) {
		return false;
	}


	return true;


}

function oficial_agruparOrdenes(whereOrdenes)
{
	var _i = this.iface;
	var criterio = AQUtil.sqlSelect("prodppal_general", "em_agrupacionop", "1 = 1"); 
	if (criterio == "Seccion") {
 		if (!_i.agrupaOrdenesSeccion(whereOrdenes)) {
			return false;
		}
	} else if(criterio == "Subfamilia") {
 		if (!_i.agrupaOrdenesSubfamilia(whereOrdenes)) {
			return false;
		}
	}
	return true;
}


function oficial_agrupaOrdenesSeccion(whereOrdenes)
{
	var _i = this.iface;	

	var where = whereOrdenes.replace("estado", "op.estado");
	where = where.replace("codorden", "op.codorden");
	var qG = new FLSqlQuery;
	qG.setSelect("op.codorden, COALESCE(s.em_codseccion, f.em_codseccion)");
	qG.setFrom("pr_ordenesproduccion op INNER JOIN subfamilias s ON op.codsubfamilia = s.codsubfamilia INNER JOIN familias f ON s.codfamilia = f.codfamilia");
	qG.setWhere(where + " ORDER BY COALESCE(s.em_codseccion, f.em_codseccion), op.codorden");
	if (!qG.exec()) {
		return false;
	}
	var codSeccionAnt = false, codSeccion, codGrupo, codOrden;
	while (qG.next()) {
    codOrden = qG.value("op.codorden");
		codSeccion = qG.value(1);
    if (!codSeccion || codSeccion == "") {
      continue;
    }
		if (codSeccion != codSeccionAnt) {
			codGrupo = _i.creaGrupoSeccion(codSeccion);
			if (!codGrupo) {
        sys.warnMsgBox(sys.translate("Error al crear el grupo asociado a la secci�n %1").arg(codSeccion));
				return false;
			}
			codSeccionAnt = codSeccion;
		}
		if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_codgruposeccion = '" + codGrupo + "' WHERE codorden = '" + codOrden + "'")) {
			return false;
		}
	}
  	return true;
}

function oficial_creaGrupoSeccion(codSeccion)
{
	var curGS = new FLSqlCursor("em_gruposordenseccion");
	curGS.setModeAccess(curGS.Insert);
	curGS.refreshBuffer();
	curGS.setValueBuffer("em_codseccion", codSeccion);
	if (!curGS.commitBuffer()) {
		return false;
	}
	return curGS.valueBuffer("em_codgruposeccion");
}

function oficial_agrupaOrdenesSubfamilia(whereOrdenes)
{
	var _i = this.iface;	

	var where = whereOrdenes.replace("estado", "op.estado");
	where = where.replace("codorden", "op.codorden");
	var qG = new FLSqlQuery;
	qG.setSelect("op.codorden, s.codsubfamilia");
	qG.setFrom("pr_ordenesproduccion op INNER JOIN subfamilias s ON op.codsubfamilia = s.codsubfamilia");
	qG.setWhere(where + " ORDER BY s.codsubfamilia, op.codorden");
	if (!qG.exec()) {
		return false;
	}
	var codSumfamAnt = false, codSubfamilia, codGrupo;
	while (qG.next()) {
		codSubfamilia = qG.value(1);
		if (codSubfamilia != codSumfamAnt) {
			codGrupo = _i.creaGrupoSubfamilia(codSubfamilia);
			if (!codGrupo) {
        sys.warnMsgBox(sys.translate("Error al crear el grupo asociado a la subfamilia %1").arg(codSubfamilia));
				return false;
			}
			codSumfamAnt = codSubfamilia;
		}
		if (!AQUtil.execSql("UPDATE pr_ordenesproduccion SET em_codgruposeccion = '" + codGrupo + "' WHERE codorden = '" + qG.value("op.codorden") + "'")) {
			return false;
		}
	}
  	return true;
}

function oficial_creaGrupoSubfamilia(codSubfamilia)
{
	var curGS = new FLSqlCursor("em_gruposordenseccion");
	curGS.setModeAccess(curGS.Insert);
	curGS.refreshBuffer();
	curGS.setValueBuffer("codsubfamilia", codSubfamilia);
	if (!curGS.commitBuffer()) {
		return false;
	}
	return curGS.valueBuffer("em_codgruposeccion");
}

function oficial_reservaStocksPedido(codOrden)
{
	return true;
	
	var _i = this.iface;
	var cursor = this.cursor();
	var codPedido = cursor.valueBuffer("codpedido");
	if (!codPedido) {
		return true;
	}
	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("codordenproduccion = '" + codOrden + "'");
	while (curLote.next()) {
		curLote.setModeAccess(curLote.Browse);
		curLote.refreshBuffer();
		if (!_i.reservaStocksLineaPedido(curLote)) {
			return false;
		}
	}
	return true;
}

function oficial_reservaStocksLineaPedido(curLote)
{
	var idLinea = curLote.valueBuffer("idlineapc");
	if (!AQUtil.sqlUpdate("movistock", ["reservamanual", "usuarioreserva"], [true, sys.nameUser()], "idlineapc = " + idLinea)) {
		return false;
	}
	return true;
}

function oficial_creaConsumosLotesFT(codOrden)
{
	var _i = this.iface;
	var curLote = new FLSqlCursor("lotesstock");
	curLote.select("codordenproduccion = '" + codOrden + "'");
	while (curLote.next()) {
		curLote.setModeAccess(curLote.Browse);
		curLote.refreshBuffer();
		if (!_i.creaConsumosFT(curLote)) {
			return false;
		}
	}
	return true;
}

function oficial_tbnCrearLinea_clicked()
{
	var _i = this.iface;
	var t = _i.t_;
	var f = new FLFormSearchDB("articulos");
	f.setMainWidget();
	var curA = f.cursor()
	curA.setMainFilter("em_tipoarticulo = 'Producto'");
	var referencia = f.exec("referencia");
	if (!referencia) {
		return;
	}

	var qrySMin = new FLSqlQuery();
	with(qrySMin) {
		setTablesList("lotesstock,articulos,pr_procesos");
		setSelect("sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.descripcion, s.stockmax, s.stockmin, s.afaltas, s.cantidad, s.reservada, s.pterecibir, s.prevision, co.codcolorem");
		setFrom("articulos a INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1')");
		setWhere("a.referencia = '" + referencia + "'");
		setForwardOnly(true);
	}
	debug(qrySMin.sql());
	if (!qrySMin.exec()) {
		return;
	}

	var cantidad, aFabricar, aFaltas, f = 0;
	while (qrySMin.next()) {
		cantidad = parseFloat(qrySMin.value("s.cantidad"));
		aFaltas = parseFloat(qrySMin.value("s.afaltas"));
		aFabricar = parseFloat(qrySMin.value("s.stockmax")) - cantidad - parseFloat(qrySMin.value("s.pterecibir"));
		aFabricar = aFabricar < 0 ? 0 : aFabricar;

		t.insertRows(f);

		//std = qrySMin.value("sf.codsubfamilia") + _i.sep_ + qrySMin.value("di.coddibujoem") + _i.sep_ + "0";

		t.setText(f, _i.cCSF, qrySMin.value("sf.codsubfamilia"));
		t.setText(f, _i.cCDIB, qrySMin.value("di.coddibujoem"));
		t.setText(f, _i.cTAM, qrySMin.value("ta.codtamanoem"));
		t.setText(f, _i.cCOL, qrySMin.value("co.descripcion"));
		t.setText(f, _i.cCODCOL, qrySMin.value("co.codcolorem"));
		

		var oParamOrd = new Object;
		oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
		oParamOrd.codDibujo = t.text(f, _i.cCDIB);
		oParamOrd.idPedido = "0";
		oParamOrd.referencia = qrySMin.value("a.referencia");
		oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
		oParamOrd.tamanio = t.text(f, _i.cTAM);

      	std = _i.criterioAgrupacion(oParamOrd);

      	if (!(std in _i.aSDP_)) {
			_i.aSDP_[std] = _i.datosSDP();
		}


		t.setText(f, _i.cSTD, std);
		t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
		t.setText(f, _i.cPED, "");
		t.setText(f, _i.cLIN, "");
		t.setText(f, _i.cCCL, "");
		t.setText(f, _i.cCLI, "Manual");
		t.setText(f, _i.cSFM, qrySMin.value("sf.descripcion"));
		t.setText(f, _i.cDIB, qrySMin.value("di.descripcion"));
		
		t.setText(f, _i.cREF, qrySMin.value("a.referencia"));
		t.setText(f, _i.cART, qrySMin.value("a.descripcion"));
		t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
		t.setText(f, _i.cCAN, cantidad);
		t.setText(f, _i.cAFA, aFaltas);
		t.setText(f, _i.cPRE, qrySMin.value("s.prevision"));
		t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);
		t.setText(f, _i.cFAB, 0);
		t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
		t.setText(f, _i.cMAX, _i.dameMaximoFabricable(qrySMin.value("a.referencia"))); 
		t.setText(f, _i.cRLP, 0);
		t.setText(f, _i.cFPE, "");
		t.setText(f, _i.cFSE, "");
		t.setText(f, _i.cFPR, "");
		
		f++;
	}
	_i.ordenar();
}

function oficial_tbnPedidoProv_clicked()
{
	var _i = this.iface;
	var t = _i.t_;
	var f = new FLFormSearchDB("em_buspedprov");
	f.setMainWidget();
	var curA = f.cursor()
	curA.setMainFilter("codigo LIKE '400%' AND servido IN ('No', 'Parcial')");
	var idPedido = f.exec("idpedido");
	if (!idPedido) {
		sys.setObjText(this, "lblOrdenGit", "");
		return;
	}
	sys.setObjText(this, "lblOrdenGit", curA.valueBuffer("observaciones"));

	var qrySMin = new FLSqlQuery();
	with(qrySMin) {
		setTablesList("lotesstock,articulos,pr_procesos");
		setSelect("sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.descripcion, s.stockmax, s.stockmin, s.afaltas, s.cantidad, s.reservada, s.pterecibir, s.prevision, lp.cantidad, lp.totalenalbaran, co.codcolorem");
		setFrom("lineaspedidosprov lp INNER JOIN articulos a ON lp.referencia = a.referencia INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1')");
		setWhere("lp.idpedido = " + idPedido);
		setForwardOnly(true);
	}
	debug(qrySMin.sql());
	if (!qrySMin.exec()) {
		return;
	}

	var cantidad, aFabricar, aFaltas, f = 0;
	while (qrySMin.next()) {
		cantidad = parseFloat(qrySMin.value("s.cantidad"));
		aFaltas = parseFloat(qrySMin.value("s.afaltas"));
		aFabricar = parseFloat(qrySMin.value("lp.cantidad")) - parseFloat(qrySMin.value("lp.totalenalbaran"));
		aFabricar = aFabricar < 0 ? 0 : aFabricar;

		t.insertRows(f);

		//std = qrySMin.value("sf.codsubfamilia") + _i.sep_ + qrySMin.value("di.coddibujoem") + _i.sep_ + "0";

		t.setText(f, _i.cCSF, qrySMin.value("sf.codsubfamilia"));
		t.setText(f, _i.cCDIB, qrySMin.value("di.coddibujoem"));
		t.setText(f, _i.cCOL, qrySMin.value("co.descripcion"));
		t.setText(f, _i.cCODCOL, qrySMin.value("co.codcolorem"));
		
		t.setText(f, _i.cTAM, qrySMin.value("ta.codtamanoem"));

		var oParamOrd = new Object;
		oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
		oParamOrd.codDibujo = t.text(f, _i.cCDIB);
		oParamOrd.idPedido = "0";
		oParamOrd.referencia = qrySMin.value("a.referencia");
		oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
		oParamOrd.tamanio = t.text(f, _i.cTAM);


      	std = _i.criterioAgrupacion(oParamOrd);

		if (!(std in _i.aSDP_)) {
			_i.aSDP_[std] = _i.datosSDP();
		}


		t.setText(f, _i.cSTD, std);
		t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
		t.setText(f, _i.cPED, "");
		t.setText(f, _i.cLIN, "");
		t.setText(f, _i.cCCL, "");
		t.setText(f, _i.cCLI, "Manual");
		t.setText(f, _i.cSFM, qrySMin.value("sf.descripcion"));
		t.setText(f, _i.cDIB, qrySMin.value("di.descripcion"));
		
		t.setText(f, _i.cREF, qrySMin.value("a.referencia"));
		t.setText(f, _i.cART, qrySMin.value("a.descripcion"));
		t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
		t.setText(f, _i.cCAN, cantidad);
		t.setText(f, _i.cAFA, aFaltas);
		t.setText(f, _i.cPRE, qrySMin.value("s.prevision"));
		t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);
		t.setText(f, _i.cFAB, aFabricar);
		t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
		t.setText(f, _i.cMAX, _i.dameMaximoFabricable(qrySMin.value("a.referencia"))); 
		t.setText(f, _i.cRLP, 0);
		t.setText(f, _i.cFPE, "");
		t.setText(f, _i.cFSE, "");
		t.setText(f, _i.cFPR, "");
		


		/*******************#EUR #H1235 #P0039**************/

		var oParamOrd = new Object;
		oParamOrd.descSubfamilia = qrySMin.value("sf.descripcion");
		oParamOrd.descDibujo = qrySMin.value("di.descripcion");
		oParamOrd.codTamano = qrySMin.value("ta.codtamanoem");


		var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
		t.setText(f, _i.cOrdSTD, sOrdenSTD);  

		var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
		t.setText(f, _i.cOrdSDT, sOrdenSDT);  



		/*******************#EUR #H1235 #P0039**************/






		f++;
	}
	_i.ordenar();
}

function oficial_tbnSelTodo_clicked()
{
	var res = MessageBox.warning(sys.translate("Va a seleccionar todas las l�neas para su producci�n. �Est� seguro?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
	if (res != MessageBox.Yes) {
		return;
	}
	
	var _i = this.iface;
	var t = _i.t_;
	var nF = t.numRows();
	var c = _i.cSEL;
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Generando �rdenes"), nF);
	var p = 0;
  for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		if (t.text(f, c) == "" && t.text(f, _i.cFAB) != 0) {
			if (!_i.colSelClicked(f)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}
	}
	AQUtil.destroyProgressDialog();
}

function oficial_dameReferencia()
{
	var ref = [];
	ref["stock"] = 0;
	ref["disp"] = 0;	
	return ref;
}

function oficial_dameLote()
{
	var lote = [];
// 	lote["stock"] = 0;
	return lote;
}

function oficial_dameMaximoFabricable(referencia)
{
  var _i = this.iface;
	
	var min = Number.MAX_VALUE;
	if (referencia in _i.lot_) {
		var canCompuesto, comp;
// debug("analizando ref " + referencia);
		for (var comp in _i.lot_[referencia]) {
			if (!(comp in _i.ref_)) {
				_i.ref_[comp] = _i.dameReferencia();
			}
			canCompuesto = _i.ref_[comp]["disp"] / _i.lot_[referencia][comp];
// debug("disp " + _i.ref_[comp]["disp"] + ", factor " + _i.lot_[referencia][comp] + " cantidad " + canCompuesto);
			if (canCompuesto < min) {
				min = canCompuesto;
			}
		}
	} else {
		_i.lot_[referencia] = _i.dameLote();
		var codAlmacen = "1";
		var qComp = new FLSqlQuery;
		qComp.setTablesList("articuloscomp,stocks");
		qComp.setSelect("ac.refcomponente, SUM(ac.cantidad * ac.factor), s.disponible");
		qComp.setFrom("articuloscomp ac LEFT OUTER JOIN stocks s ON (ac.refcomponente = s.referencia AND s.codalmacen = '" + codAlmacen + "')");
		qComp.setWhere("ac.refcompuesto = '" + referencia + "' AND ac.reservar GROUP BY ac.refcomponente, s.disponible");
		qComp.setForwardOnly(true);
		if (!qComp.exec()) {
			return false;
		}
		var c, f, d, canCompuesto, comp;
		while (qComp.next()) {
			comp = qComp.value("ac.refcomponente");
			f  = qComp.value("SUM(ac.cantidad * ac.factor)");
			f  = f ? f : 1;
			_i.lot_[referencia][comp] = f; /// Factor del componente respecto al compuesto
			
			d = qComp.value("s.disponible");
			d = d ? d : 0;
			
			if (!(comp in _i.ref_)) {
				_i.ref_[comp] = _i.dameReferencia();
			}
			_i.ref_[comp]["stock"] = d;
			_i.ref_[comp]["disp"] = d;
			
			
			canCompuesto = d / f;
			if (canCompuesto < min) {
				min = canCompuesto;
			}
		}
	}
  min = min == Number.MAX_VALUE ? 0 : min;
  min=  AQUtil.roundFieldValue(min,"movistock", "reservaaf");
	min = Math.floor(min);
  return min;
}

function oficial_fabricableLineaPedido(idLinea)
{
  var _i = this.iface;
	
	var min = Number.MAX_VALUE;
	
	var qComp = new AQSqlQuery;
	qComp.setSelect("ac.refcomponente,SUM(ac.cantidad * ac.factor), msc.reservaex");
	qComp.setFrom("movistock ms INNER JOIN movistock msc ON ms.idmovimiento = msc.idmovproducto LEFT OUTER JOIN articuloscomp ac ON msc.referencia = ac.refcomponente AND ms.referencia = ac.refcompuesto");
	qComp.setWhere("ms.idlineapc IN (" + idLinea + ") AND ac.reservar GROUP BY ac.refcomponente, msc.reservaex");
	qComp.setForwardOnly(true);
	if (!qComp.exec()) {
		return false;
	}
//debug(qComp.sql());
	var c, f, d, canCompuesto, comp;
	while (qComp.next()) {
		comp = qComp.value("ac.refcomponente");
		f  = qComp.value("SUM(ac.cantidad * ac.factor)");
		f  = f ? f : 1;
		
		d = qComp.value("msc.reservaex");
		d = d ? d : 0;

		canCompuesto = d / f;
		canCompuesto += 0.01;
		if (canCompuesto < min) {
			min = canCompuesto;
		}
	}
	min = min == Number.MAX_VALUE ? 0 : min;
	min = Math.floor(min);
  return min;
}


function oficial_restaStockLote(referencia, cantidad)
{
	var _i = this.iface;
	for (var comp in _i.lot_[referencia]) {
		_i.ref_[comp]["disp"] -= (cantidad * _i.lot_[referencia][comp]);
// 		debug("Ref " + comp + " antes " + _i.ref_[comp]["stock"] + " ahora " + _i.ref_[comp]["disp"]);
	}
	if (!_i.actualizaMaximos()) {
		return false;
	}
	return true;
}

function oficial_sumaStockLote(referencia, cantidad)
{
	var _i = this.iface;
	for (var comp in _i.lot_[referencia]) {
		_i.ref_[comp]["disp"] += (cantidad * _i.lot_[referencia][comp]);
// 		debug("Ref " + comp + " antes " + _i.ref_[comp]["stock"] + " ahora " + _i.ref_[comp]["disp"]);
	}
	if (!_i.actualizaMaximos()) {
		return false;
	}
	return true;
}

function oficial_actualizaMaximos()
{
	var _i = this.iface;
	var t =  _i.t_;
	
	var nF = t.numRows();
	var maxLinea, maxFab;
	for (var f = 0; f < nF; f++) {
// 		maxLinea = parseFloat(t.text(f, _i.cRLP));
// 		maxLinea = isNaN(maxLinea) ? 0 : maxLinea;
		maxFab = _i.dameMaximoFabricable(t.text(f, _i.cREF)); 
// 		maxFab += parseFloat(maxLinea);
		t.setText(f, _i.cMAX, maxFab);
	}
	return true;
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	switch (fN) {
		case "orden": {
			_i.ordenar();
			break;
		}
		case "refdesde": {
			sys.setObjText(this, "fdbRefHasta", cursor.valueBuffer("refdesde"));
			break;
		}
		case "em_coddropshipping": {
			_i.habilitaPorDropshipping();
			break;
		}
		case "fabporcentaje": {
			_i.habilitaPorFabPorcentaje();
			_i.limpiarTabla();
			break;
		}
		case "fusionarpedidos": {
			_i.limpiarTabla();
			break;
		}
		case "unlotexop": {
			_i.limpiarTabla();
			break;
		}	
		case "separadopor": {
			_i.limpiarTabla();
			break;
		}
		case "busqstocks": 
		case "busqentrefechas": {	
			_i.habilitarCampos();
			break;
		}
		case "busqpedidos": {
			_i.habilitaPorFabPorcentaje();
			break;
		}
		case "busqcomponentes": {
			_i.habilitaSoloComponentes();
			break;
		}
	}
}

//tbnLimpiarFiltro

function oficial_habilitaPorDropshipping()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var fdBs = ["fdbCodDibujo", "fdbCodColeccion", "fdbCodPedido", "fdbRefDesde", "fdbRefHasta", "fdbTipoFecha", "fdbFechaDesde", "fdbFechaHasta", "fdbAgrupacion", "fdbCodOrdenEst", "fdbDesDibujo", "fdbDesFamilia", "fdbDesColeccion", "fdbDesArticuloDesde", "fdbDesArticuloHasta", "tbnPedidoProv", "tbnCrearLinea","fdbCodTipoProdInd","fdbCodFamiliaEx","fdbCodSubfamiliaEx"];

	var codD = cursor.valueBuffer("em_coddropshipping");
	for (var i = 0; i < fdBs.length; i++) {
		if (codD && codD != "") {
			sys.setObjText(this, fdBs[i], "");
			sys.disableObj(this, fdBs[i]);
			sys.disableObj(this,"fdbFusionarPedidos");
			sys.disableObj(this,"fdbUnLoteXop");
			sys.disableObj(this,"chkBuscarPedidos");
			sys.disableObj(this,"chkBuscarComponentes");
			sys.disableObj(this,"chkSoloComponentes");
			sys.disableObj(this,"chkBuscarStocks");
			sys.disableObj(this,"chkStocksBajoMin");
			sys.disableObj(this,"chkSoloMPDisponible");
			sys.disableObj(this,"chkBuscarFechas");
			this.child("fdbFusionarPedidos").setValue(false);
			this.child("fdbUnLoteXop").setValue(false);
			this.child("chkBuscarPedidos").setValue(false);
			this.child("chkBuscarComponentes").setValue(false);
			this.child("chkSoloComponentes").setValue(false);
			this.child("chkBuscarStocks").setValue(false);
			this.child("chkStocksBajoMin").setValue(false);
			this.child("chkSoloMPDisponible").setValue(false);
			this.child("chkBuscarFechas").setValue(false);
		} else {
			sys.enableObj(this, fdBs[i]);
			sys.enableObj(this,"fdbFusionarPedidos");
			sys.enableObj(this,"fdbUnLoteXop");
			sys.enableObj(this,"chkBuscarPedidos");
			sys.enableObj(this,"chkBuscarComponentes");
			sys.enableObj(this,"chkSoloComponentes");
			sys.enableObj(this,"chkBuscarStocks");
			sys.enableObj(this,"chkStocksBajoMin");
			sys.enableObj(this,"chkSoloMPDisponible");
			sys.enableObj(this,"chkBuscarFechas");
		}
	}
	/*var chks = ["chkBuscarPedidos", "chkBuscarStocks", "chkStocksBajoMin", "chkSoloMPDisponible", "chkBuscarFechas"];
	for (var i = 0; i < chks.length; i++) {
		if (codD && codD != "") {
			this.child(chks[i]).checked = false;
			this.child(chks[i]).enabled = false;
		} else {
			this.child(chks[i]).enabled = true;
		}
	}*/
}

function oficial_ordenar()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var c;
	switch (cursor.valueBuffer("orden")) {
		case "Dibujo": {
			c = _i.cDIB;
			break;
		}
		case "Cliente": {
			c = _i.cCLI;
			break;
		}
		case "Referencia": {
			c = _i.cREF;
			break;
		}
		case "Seleccionados": {
			c = _i.cSEL;
			break;
		}
	    case "Subfamilia-Dibujo-Tama�o": {
	    	c = _i.cOrdSDT;
	    	break;
	    }
	    case "Subfamilia-Tama�o-Dibujo": {
	    	c = _i.cOrdSTD;
	    	break;
	    }
		default: {
			return false;
		}
	}
	_i.t_.sortColumn(c, true, true);
}

function oficial_tblLineas_valueChanged(f, c)
{
	var _i = this.iface;
	switch (c) {
		case _i.cFAB: {
			var max = _i.t_.text(f, _i.cMAX);
			max = isNaN(max) ? 0 : max;
			var maxLinea = _i.t_.text(f, _i.cRLP);
			maxLinea = isNaN(maxLinea) ? 0 : maxLinea;
			if (_i.t_.text(f, _i.cFAB) > (parseFloat(max) + parseFloat(maxLinea)))  {
				MessageBox.warning(sys.translate("El valor indicado es mayor que el m�ximo"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				break;
			}
			break;
		}
	}
}

function oficial_creaConsumosFT(curLote)
{

	var _i = this.iface;
	var saltar = false;
	_i.stocksARevisar_ = new Object;
	var referencia, cantidad;
	
	_i.debugReservasPedido("oficial_creaConsumosFT 1");

	
	var codLote = curLote.valueBuffer("codlote");
	var idMovProducto = AQUtil.sqlSelect("movistock","idmovimiento","codlote = '" + codLote + "'");

	var idLineaPc = curLote.valueBuffer("idlineapc");	
	var idMov = AQUtil.sqlSelect("movistock", "idmovimiento", "idlineapc = " + idLineaPc);		
	if(idMov) {		
		var q = new AQSqlQuery;	
		q.setSelect("res.idmovreserva,res.idmovpterx,res.cantidad,m.idarticulocomp, res.idrlp");
		q.setFrom("movistock m INNER JOIN em_reservaspterx res ON res.idmovreserva = m.idmovimiento");
		q.setWhere("m.idmovproducto = " + idMov); 					
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			if(!_i.oMovLoteCompProd_) {
				_i.oMovLoteCompProd_ = new Object();
			}	
			var codLoteCompProd = AQUtil.sqlSelect("movistock","codlote","idmovimiento = " + q.value("res.idmovpterx"));	
			_i.oMovLoteCompProd_[idMov] = new Object;
			_i.oMovLoteCompProd_[idMov]["codLoteCompProd"] = codLoteCompProd;
			_i.oMovLoteCompProd_[idMov]["cantidad"] = q.value("res.cantidad");
			_i.oMovLoteCompProd_[idMov]["idmovreserva"] = q.value("res.idmovreserva");
			_i.oMovLoteCompProd_[idMov]["idmovpterx"] = q.value("res.idmovpterx");
			_i.oMovLoteCompProd_[idMov]["idarticulocomp"] = q.value("m.idarticulocomp");
			if(q.value("res.idrlp") && q.value("res.idrlp") != "" && q.value("res.idrlp") != 0) {
				_i.oMovLoteCompProd_[idMov]["idrlp"] = q.value("res.idrlp");	
			} else {
				_i.oMovLoteCompProd_[idMov]["idrlp"] = "";
			}
				
		}	
	}
	_i.debugReservasPedido("oficial_creaConsumosFT 2");

	if (!AQSql.del("movistock", "codloteprod = '" + codLote + "'")) {
		return false;
	}
	_i.debugReservasPedido("oficial_creaConsumosFT 3");

	referencia = curLote.valueBuffer("referencia");
	cantidad = curLote.valueBuffer("canlote");

	if (!cantidad || isNaN(cantidad) || cantidad == 0) {
// 		MessageBox.warning(sys.translate("Error: Intenta crear una composici�n con cantidad 0"), MessageBox.Ok, MessageBox.NoButton);
// 		return false;
		cantidad = 0;
	}
	var l = curLote.valueBuffer;

	_i.debugReservasPedido("oficial_creaConsumosFT 4");
	if (!flfactalma.iface.pub_generaConsumosProducto(referencia, cantidad, false, codLote, l("codalmacen"), false)) {
		return false;		
	}	
	_i.debugReservasPedido("oficial_creaConsumosFT 5");

	if(_i.oMovLoteCompProd_ && idMovProducto) {
		var q = new AQSqlQuery;	
		q.setSelect("m.idmovimiento,m.idarticulocomp");
		q.setFrom("movistock m");
		q.setWhere("m.codloteprod = '" + codLote + "'"); 					
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			var idArticuloComp = q.value("m.idarticulocomp");
			var nuevoMov = q.value("m.idmovimiento");
			for(idMov in _i.oMovLoteCompProd_) {
				if(idArticuloComp == _i.oMovLoteCompProd_[idMov]["idarticulocomp"]) {
					var id = AQUtil.sqlSelect("em_reservaspterx","id","idmovreserva = " + _i.oMovLoteCompProd_[idMov]["idmovreserva"]);
					if(id) {
						if (!AQSql.del("em_reservaspterx", "id = " + id)) {
							return false;
						}	

					}
					_i.debugReservasPedido("oficial_creaConsumosFT 5.1");
					if(!flfactalma.iface.borraReservasPRLote(_i.oMovLoteCompProd_[idMov]["codLoteCompProd"])) {
						return false;
					}	
					_i.debugReservasPedido("oficial_creaConsumosFT 5.2");
					if (!AQUtil.execSql("UPDATE movistock SET cantidad = " + _i.oMovLoteCompProd_[idMov]["cantidad"] + ", enreserva = 0 WHERE idmovimiento = " + _i.oMovLoteCompProd_[idMov]["idmovpterx"])) {
						return false;
					}
					_i.debugReservasPedido("oficial_creaConsumosFT 5.3");
					if (!AQSql.update("movistock", ["cantidad", "enreserva"], [_i.oMovLoteCompProd_[idMov]["cantidad"], 0], "idmovimiento = " + _i.oMovLoteCompProd_[idMov]["idmovpterx"])) { // Debe lanzar aftercommit para recalcular reservas
						return false;
					}
					_i.debugReservasPedido("oficial_creaConsumosFT 5.4");
					if (!AQSql.del("em_reservaspterx", "idmovpterx = " + _i.oMovLoteCompProd_[idMov]["idmovpterx"])) {
						return false;
					}
					var curRes = new FLSqlCursor("em_reservaspterx");
					curRes.setModeAccess(curRes.Insert);
					curRes.refreshBuffer();
					curRes.setValueBuffer("idmovreserva", nuevoMov);
					curRes.setValueBuffer("idmovpterx", _i.oMovLoteCompProd_[idMov]["idmovpterx"]);
					curRes.setValueBuffer("cantidad", _i.oMovLoteCompProd_[idMov]["cantidad"]);
					var idRlp = _i.oMovLoteCompProd_[idMov]["idrlp"];

					if(idRlp && idRlp != "" && idRlp != 0) {
						curRes.setValueBuffer("idrlp",idRlp);						
					} 					
					if (!curRes.commitBuffer()) {
						return false;
					}
					_i.debugReservasPedido("oficial_creaConsumosFT 5.5");
					if (!flfactalma.iface.pub_revisaReservasLoteProd(_i.oMovLoteCompProd_[idMov]["codLoteCompProd"])) {
						return false;
					}	
					_i.debugReservasPedido("oficial_creaConsumosFT 5.6");
					if (!flfactalma.iface.pub_reservasConsumoLote(_i.oMovLoteCompProd_[idMov]["codLoteCompProd"])) {
						return false;
					}
					_i.debugReservasPedido("oficial_creaConsumosFT 5.7");
					saltar = true;					
				}					
			}
		}
	}
	_i.debugReservasPedido("oficial_creaConsumosFT 6");

	if(_i.oMovLote_ && codLote in _i.oMovLote_ && _i.oMovLote_[codLote]["cantidad"] > 0) {	
		_i.debugReservasPedido("oficial_creaConsumosFT 7");
		debug("me salto el borrado");
	} else {
		_i.debugReservasPedido("oficial_creaConsumosFT 8");
		var idMovEntrada = AQUtil.sqlSelect("movistock", "idmovimiento", "codlote = '" + codLote + "' AND estado = 'PTE' AND cantidad > 0");
		if (!idMovEntrada) {
			MessageBox.warning(sys.translate("No se ha encontrado el movimiento pendiente de entrada para el lote %1").arg(codLote), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
			return false;
		}
		//26-02-2018 a�adimos esta llamada para que borre las reservas antes para que no de el mensaje de cantidad reservada xxx excede... cuando estamos cambiando la cantidad de un lote desde el corte horizontal
		_i.debugReservasPedido("oficial_creaConsumosFT 9");
		if(!flfactalma.iface.borraReservasPRLote(codLote)) {
			return false;
		}
		_i.debugReservasPedido("oficial_creaConsumosFT 10");
		if (!AQSql.update("movistock", ["cantidad", "enreserva"], [curLote.valueBuffer("canlote"), 0], "idmovimiento = " + idMovEntrada)) { // Debe lanzar aftercommit para recalcular reservas
			return false;
		}
		_i.debugReservasPedido("oficial_creaConsumosFT 11");
	}
	_i.debugReservasPedido("oficial_creaConsumosFT 12");
	if (!flfactalma.iface.pub_revisaReservasLoteProd(codLote)) {
		return false;
	}
	_i.debugReservasPedido("oficial_creaConsumosFT 13");
	if(!saltar) {
		if (!flfactalma.iface.pub_reservasConsumoLote(codLote)) {
			return false;
		}
	}

	_i.debugReservasPedido("oficial_creaConsumosFT 14");

	
	return true;
}

function oficial_apuntaStockARevisar(idStock)
{
	var _i = this.iface;
	if (idStock in _i.stocksARevisar_) {
		return;
	}
	_i.stocksARevisar_[idStock] = true;
}

function oficial_revisaStocks()
{
	var _i = this.iface;
	var where = "";
	for (var idStock in _i.stocksARevisar_) {
		where += (where != "") ? ", " : "";
		where += idStock.toString();
	}
	if (where != "") {
		where = "idstock IN (" + where + ")";
		if (!formregstocks.iface.pub_revisarStock(where, true)) {
			return false;
		}
	}
	return true;
}

function oficial_tbnReservas_clicked()
{
	var _i = this.iface;
	var t = _i.t_;
	var codAlmacen = "1";
	var f = t.currentRow();
	if (isNaN(f) || f < 0) {
		return;
	}
	var referencia = t.text(f, _i.cREF);
	var curReserva = new FLSqlCursor("stocks");
	curReserva.select("referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'")
	if (!curReserva.first()) {
		MessageBox.warning(sys.translate("No hay un registro de stock para la referencia y almacén indicados"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return;
	}
	curReserva.editRecord();
}

function oficial_tbnBorraOrden_clicked()
{
	var _i = this.iface;
	var curOrden = this.child("tdbOrdenes").cursor();
	var codOrden = curOrden.valueBuffer("codorden");
	if (!codOrden) {
		return false;
	}
	var t =  _i.t_;
	var nF = t.numRows();
	
	var q = new AQSqlQuery;
	q.setSelect("codlote");
	q.setFrom("lotesstock");
	q.setWhere("codordenproduccion = '" + codOrden + "'");
	if (!q.exec()) {
		return false;
	}
	var codLote;
	while (q.next()) {
		codLote = q.value("codlote");
		for (var f = 0; f < nF; f++) {
			if (t.text(f, _i.cLOT) == codLote) {
				_i.t_.setRowReadOnly(f, false);
				_i.t_.setText(f, _i.cSEL, "");
				_i.t_.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
				if (!_i.quitaFilaOP(f)) {
					_i.t_.setText(f, _i.cSEL, "X");
					_i.t_.setRowReadOnly(f, true);
					_i.t_.setCellBackgroundColor(f, _i.cSEL, _i.cSel);
					sys.warnMsgBox(sys.translate("Error al quitar la fila %1 de las �rdenes de producci�n").arg(f));
					return false;
				}
			}
		}
	}
	var codLoteNoDebeHaber = AQUtil.sqlSelect("lotesstock", "codlote", "codordenproduccion = '" + codOrden + "'");
	if (codLoteNoDebeHaber) {
		sys.warnMsgBox(sys.translate("Error al borrar la orden de producci�n %1").arg(codOrden));
		return false;
	}
	if (!AQSql.del("pr_ordenesproduccion", "codorden = '" + codOrden + "'")) {
		sys.warnMsgBox(sys.translate("Error al borrar la orden de producci�n %1").arg(codOrden));
		return false;
	}
	_i.tdbOrdenes_.refresh();

  var whereOrdenes = _i.tdbOrdenes_.cursor().mainFilter();
  var curOrdenes = new FLSqlCursor("pr_ordenesproduccion");
  curOrdenes.select(whereOrdenes);
   if (!curOrdenes.first()) {
		 this.child("tbnBuscar").enabled = true;
		 this.child("fdbFusionarPedidos").setDisabled(false);	
		 this.child("fdbUnLoteXop").setDisabled(false);	
		 this.child("tbnLimpiarFiltro").setDisabled(false);
		 this.child("fdbSeparadoPor").setDisabled(false);
	} else {
		 this.child("tbnBuscar").enabled = false;
		 this.child("fdbFusionarPedidos").setDisabled(true);
		 this.child("fdbUnLoteXop").setDisabled(true);
		 this.child("tbnLimpiarFiltro").setDisabled(true);
		 this.child("fdbSeparadoPor").setDisabled(true);
	}	


}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var campos = "fdbCodDibujo,fdbDesDibujo,fdbCodFamilia,fdbDesFamilia,fdbCodSubfamilia,fdbDesSubfamilia,fdbCodColeccion,fdbDesColeccion,fdbCodPedido,fdbRefDesde,fdbDesArticuloDesde,fdbRefHasta,fdbDesArticuloHasta,fdbCodOrdenEst,fdbAgrupacion,fdbCodDropshipping,fdbCodFamiliaEx,fdbCodSubfamiliaEx,fdbSeccionFam,fdbSeccionSub";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(this, aCampos[i], "");
	}
	_i.valoresPorDefecto();
	_i.habilitaPorDropshipping();
}

/*function oficial_habilitarCampos()
{
	var _i = this.iface;
	if(this.child("chkBuscarFechas").checked) {
		this.child("chkBuscarStocks").enabled = false;
		this.child("chkStocksBajoMin").enabled = false;
		
		this.child("chkBuscarStocks").checked = false;
		this.child("chkStocksBajoMin").checked = false;
		
		this.child("fdbTipoFecha").setDisabled(false);
		this.child("fdbFechaDesde").setDisabled(false);
		this.child("fdbFechaHasta").setDisabled(false);
	} else {
		this.child("fdbTipoFecha").setDisabled(true);
		this.child("fdbFechaDesde").setDisabled(true);
		this.child("fdbFechaHasta").setDisabled(true);
		
		this.child("fdbTipoFecha").setValue("Servicio");
		this.child("fdbFechaDesde").setValue("");
		this.child("fdbFechaHasta").setValue("");
		
		this.child("chkBuscarStocks").enabled = true;
		if (this.child("chkBuscarStocks").checked) {
			this.child("chkStocksBajoMin").enabled = true;
		} else {
			this.child("chkStocksBajoMin").enabled = false;
			this.child("chkStocksBajoMin").checked = false;
		}
	}
	_i.habilitaPorFabPorcentaje();

}*/

function oficial_habilitarCampos()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.valueBuffer("busqentrefechas")) {
		
		this.child("chkBuscarStocks").enabled = false;
		this.child("chkStocksBajoMin").enabled = false;
		
		this.child("chkBuscarStocks").setValue(false);
		this.child("chkStocksBajoMin").setValue(false);
		
		this.child("fdbTipoFecha").setDisabled(false);
		this.child("fdbFechaDesde").setDisabled(false);
		this.child("fdbFechaHasta").setDisabled(false);
	} else {
		
		this.child("fdbTipoFecha").setDisabled(true);
		this.child("fdbFechaDesde").setDisabled(true);
		this.child("fdbFechaHasta").setDisabled(true);
		
		this.child("fdbTipoFecha").setValue("Servicio");
		this.child("fdbFechaDesde").setValue("");
		this.child("fdbFechaHasta").setValue("");
		
		this.child("chkBuscarStocks").enabled = true;
		if (cursor.valueBuffer("busqstocks")) {
			
			this.child("chkStocksBajoMin").enabled = true;			
		} else {
			
			this.child("chkStocksBajoMin").enabled = false;
			this.child("chkStocksBajoMin").setValue(false);
		}
	}
	_i.habilitaPorFabPorcentaje();
	_i.habilitaSoloComponentes();

}

//esta funcion hay que llamarla en algun momento para pasar las reservas que tiene el pedido al lote �justo despu�s de lanzar procesos? 18-10-2017
function oficial_copiaReservasEstampacionPed(idLineaPC, codLote)
{
	var qRep = new AQSqlQuery;
	qRep.setSelect("idlineaest");
	qRep.setFrom("em_reservasestpedido");
	qRep.setWhere("idlineapc = " + idLineaPC + " order by idlineaest desc");
	if (!qRep.exec()) {	
		return false;
	}
	
	var curRel = new FLSqlCursor("em_reservasestlote");
	curRel.setActivatedCheckIntegrity(false);
	while (qRep.next()) {
		curRel.setModeAccess(curRel.Insert);
		curRel.refreshBuffer();
		curRel.setValueBuffer("idlineaest", qRep.value("idlineaest"));
		curRel.setValueBuffer("codlote", codLote);
		if (!curRel.commitBuffer()) {
			return false;
		}
	}
	return true
}

//#EUR #H1194
function oficial_copiaReservasEstampacionNoPed(idLineaEst, codLote)
{
	var curRel = new FLSqlCursor("em_reservasestlote");
	curRel.setActivatedCheckIntegrity(false);	
	curRel.setModeAccess(curRel.Insert);
	curRel.refreshBuffer();
	curRel.setValueBuffer("idlineaest", idLineaEst);
	curRel.setValueBuffer("codlote", codLote);
	if (!curRel.commitBuffer()) {
		return false;
	}	
	return true
}

function oficial_quitaReservasEstampacionPed(idLineaPC, codLote)
{
	 
	var qRep = new AQSqlQuery;
	qRep.setSelect("idlineaest");
	qRep.setFrom("em_reservasestpedido");
	qRep.setWhere("idlineapc = " + idLineaPC  + " order by idlineaest desc");
	if (!qRep.exec()) {	
		return false;
	}
	var curRel = new FLSqlCursor("em_reservasestlote");
	curRel.setActivatedCheckIntegrity(false);
	while (qRep.next()) {
		curRel.select("idlineaest = " + qRep.value("idlineaest") + " AND codlote = '" + codLote + "'");
		if (curRel.first()) {
			curRel.setModeAccess(curRel.Del);
			curRel.refreshBuffer();
			if (!curRel.commitBuffer()) {
				return false;
			}
		}
	}
	return true
}

function oficial_quitaReservasEstampacionNoPed(idLineaEst, codLote)
{ 

	var curRel = new FLSqlCursor("em_reservasestlote");
	curRel.setActivatedCheckIntegrity(false);	
	curRel.select("idlineaest = " + idLineaEst + " AND codlote = '" + codLote + "'");
	if (curRel.first()) {
		curRel.setModeAccess(curRel.Del);
		curRel.refreshBuffer();
		if (!curRel.commitBuffer()) {
			return false;
		}
	}
	
	return true
}

function oficial_buscarPorEstampacion()
{
	var _i = this.iface;
	_i.lotPR_ = []; //24-10-2017	
	var cursor = this.cursor();
	var codOrdenEst = cursor.valueBuffer("codordenest");
	
	//var criteriosBusqueda = " AND loe.codordenest = '" + codOrdenEst + "' ORDER BY loe.grupo, loe.ordengrupo";
	var criteriosBusqueda = " AND loe.codordenest = '" + codOrdenEst + "'";

	var criterioBusquedaDrop = "";
	if (this.child("chkOmitirDropships").checked) {	
		criterioBusquedaDrop = " AND p.em_coddropshipping IS NULL ";
	}

	var criterioBusquedaColec = "";
	if (this.child("chkOmitirColOcultas").checked) {				
		criterioBusquedaColec += " AND (NOT col.ocultarnecesidades OR col.ocultarnecesidades IS NULL)";			
	}
	
	var t = _i.t_;
	t.setNumRows(0);
	var f = 0, std, codLote, referencia;
	var p = 0;
	
	var grupo, ordenGrupo, orden;
	var qryProcesos = new FLSqlQuery();
	with(qryProcesos) {
		setSelect("p.codigo, lp.idlinea, p.codcliente, p.nombrecliente, p.fecha, p.fechaservicio, p.fechasalida, p.idpedido, se.exportprod, ms.reservaaf, sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.referencia, a.descripcion, s.prevision, s.afaltas, s.cantidad,s.disponiblepterecibir, co.codcolorem");
		setFrom("pedidoscli p INNER JOIN lineaspedidoscli lp ON p.idpedido = lp.idpedido INNER JOIN series se ON p.codserie = se.codserie INNER JOIN movistock ms ON (lp.idlinea = ms.idlineapc AND lp.referencia = ms.referencia) INNER JOIN articulos a ON lp.referencia = a.referencia INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') INNER JOIN em_reservasestpedido rep ON lp.idlinea = rep.idlineapc INNER JOIN em_lineasordenest loe ON rep.idlineaest = loe.idlinea LEFT OUTER JOIN em_colecciones col ON col.codcoleccionem = a.codcoleccionem");
		setWhere("ms.estado = 'PTE' AND ms.reservaaf > 0 AND a.em_tipoarticulo = 'Producto'" + criteriosBusqueda + criterioBusquedaDrop + criterioBusquedaColec +" GROUP BY p.codigo, lp.idlinea, p.codcliente, p.nombrecliente, p.fecha, p.fechaservicio, p.fechasalida, p.idpedido, se.exportprod, ms.reservaaf, sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.referencia, a.descripcion, s.prevision, s.afaltas, s.cantidad,s.disponiblepterecibir, co.codcolorem");
		setForwardOnly(true);
	}
	debug(qryProcesos.sql());
	if (!qryProcesos.exec()) {
		return;
	}
	var idPed;
	var idLineaPC;
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando pedidos"), qryProcesos.size());
	var cantidad, disponible, disponibleRx, aFabricar, aFaltas, maxFabricable, maxLinea;
	while (qryProcesos.next()) {
		AQUtil.setProgress(p++);
		cantidad = parseFloat(qryProcesos.value("s.cantidad"));
		referencia = qryProcesos.value("a.referencia");
		maxFabricable = _i.dameMaximoFabricable(referencia); 
		
		maxLinea = _i.fabricableLineaPedido(qryProcesos.value("lp.idlinea"));

		aFabricar = qryProcesos.value("ms.reservaaf");

		aFaltas = parseFloat(qryProcesos.value("s.afaltas"));
		codLote = qryProcesos.value("ls.codlote");
		t.insertRows(f);
		t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
		t.setText(f, _i.cSFM, qryProcesos.value("sf.descripcion"));
		t.setText(f, _i.cDIB, qryProcesos.value("di.descripcion"));
		t.setText(f, _i.cCOL, qryProcesos.value("co.descripcion"));
		t.setText(f, _i.cCODCOL, qryProcesos.value("co.codcolorem"));
		
		t.setText(f, _i.cREF, qryProcesos.value("a.referencia"));
		t.setText(f, _i.cART, qryProcesos.value("a.descripcion"));
		t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
		t.setText(f, _i.cCAN, cantidad);
		t.setText(f, _i.cAFA, aFaltas);
		t.setText(f, _i.cPRE, qryProcesos.value("s.prevision"));
		t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);
		t.setText(f, _i.cFAB, aFabricar);
		t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
		t.setText(f, _i.cMAX, maxFabricable);
		t.setText(f, _i.cRLP, maxLinea);
		t.setText(f, _i.cTAM, qryProcesos.value("ta.codtamanoem"));

		t.setText(f, _i.cPED, qryProcesos.value("p.codigo"));
		t.setText(f, _i.cIDP, qryProcesos.value("p.idpedido"));
		t.setText(f, _i.cLIN, qryProcesos.value("lp.idlinea"));
		t.setText(f, _i.cCCL, qryProcesos.value("p.codcliente"));
		t.setText(f, _i.cCLI, qryProcesos.value("p.nombrecliente"));
		if (qryProcesos.value("p.fecha")) {
			t.setText(f, _i.cFPE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fecha")));
		}
		if (qryProcesos.value("p.fechaservicio")) {
			t.setText(f, _i.cFSE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechaservicio")));
		}
		if (qryProcesos.value("p.fechasalida")) {
			t.setText(f, _i.cFPR, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechasalida")));
		}
		
		idPed = qryProcesos.value("se.exportprod") ? qryProcesos.value("p.idpedido") : "0";

		//std = qryProcesos.value("sf.codsubfamilia") + _i.sep_ + qryProcesos.value("di.coddibujoem") + _i.sep_ + idPed;
		
		t.setText(f, _i.cCSF, qryProcesos.value("sf.codsubfamilia"));
		t.setText(f, _i.cCDIB, qryProcesos.value("di.coddibujoem"));

		var oParamOrd = new Object;
		oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
		oParamOrd.codDibujo = t.text(f, _i.cCDIB);
		oParamOrd.idPedido = idPed;
		oParamOrd.referencia = t.text(f, _i.cREF);
		oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
		oParamOrd.tamanio = t.text(f, _i.cTAM);

      	std = _i.criterioAgrupacion(oParamOrd);

		if (!(std in _i.aSDP_)) {
			_i.aSDP_[std] = _i.datosSDP();
		}
		t.setText(f, _i.cSTD, std);
		t.setText(f, _i.cEPR, qryProcesos.value("s.disponiblepterecibir"));
		t.setText(f, _i.cEPR, _i.extraPR(referencia));


		/*******************#EUR #H1235 #P0039**************/

		var oParamOrd = new Object;
		oParamOrd.descSubfamilia = qryProcesos.value("sf.descripcion");
		oParamOrd.descDibujo = qryProcesos.value("di.descripcion");
		oParamOrd.codTamano = qryProcesos.value("ta.codtamanoem");


		var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
		t.setText(f, _i.cOrdSTD, sOrdenSTD);  

		var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
		t.setText(f, _i.cOrdSDT, sOrdenSDT);  



		/*******************#EUR #H1235 #P0039**************/





		f++;
	}
	
	AQUtil.destroyProgressDialog();
	
	
	// 07-08-2015 buscar l�neas de orden de estampaci�n que no vengan de un pedido.	

	var criteriosBusqueda = "";
 	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	if (codSubfamilia) {
		criteriosBusqueda += " AND a.codsubfamilia = '" + codSubfamilia + "'";
	}
	var codFamilia = cursor.valueBuffer("codfamilia");
	if (codFamilia) {
		criteriosBusqueda += " AND a.codfamilia = '" + codFamilia + "'";
	}
	var codDibujo = cursor.valueBuffer("coddibujoem");
	if (codDibujo) {
		criteriosBusqueda += " AND a.coddibestamp = '" + codDibujo + "'";
	}
	var refDesde = cursor.valueBuffer("refdesde");
	if (refDesde) {
		criteriosBusqueda += " AND a.referencia >= '" + refDesde + "'";
	}
	var refHasta = cursor.valueBuffer("refhasta");
	if (refHasta) {
		criteriosBusqueda += " AND a.referencia <= '" + refHasta + "'";
	}
	var codColeccionEm = cursor.valueBuffer("codcoleccionem");
	if (codColeccionEm && codColeccionEm != "") {
		criteriosBusqueda += " AND a.referencia IN (SELECT em_coleccionesart.referencia from em_coleccionesart where em_coleccionesart.codcoleccionem = '" + codColeccionEm + "')";
	}
	criteriosBusqueda += " AND loe.codordenest = '" + codOrdenEst + "' ORDER BY loe.grupo, loe.ordengrupo";

	f=0;
	p=0;	
	var q = new FLSqlQuery();
	q.setSelect("ms.reservaaf, sf.codsubfamilia, sf.descripcion, di.coddibujoem, di.descripcion, co.descripcion, ta.codtamanoem, a.referencia, a.referencia, a.descripcion, s.prevision, s.afaltas, s.cantidad, loe.grupo, loe.ordengrupo, s.disponiblepterecibir, co.codcolorem, loe.idlinea");
	q.setFrom("em_lineasordenest loe inner join movistock ms on (loe.idlinea = ms.emidlineaest and ms.referencia=loe.referencia) inner join articuloscomp ac on ac.refcomponente=ms.referencia INNER JOIN articulos a ON ac.refcompuesto = a.referencia INNER JOIN subfamilias sf ON a.codsubfamilia = sf.codsubfamilia LEFT OUTER JOIN em_dibujos di ON (a.coddibestamp = di.coddibujoem OR a.coddibjacquard = di.coddibujoem) LEFT OUTER JOIN em_colores co ON a.codcolorem = co.codcolorem LEFT OUTER JOIN em_tamanos ta ON a.codtamanoem = ta.codtamanoem LEFT OUTER JOIN stocks s ON (a.referencia = s.referencia AND s.codalmacen = '1') LEFT OUTER JOIN em_colecciones col ON col.codcoleccionem = a.codcoleccionem");
	//q.setWhere(" ms.estado = 'PTE' and loe.idlinea NOT IN (SELECT idlineaest from em_reservasestpedido) " + criteriosBusqueda);
	q.setWhere("loe.idlinea NOT IN (SELECT idlineaest from em_reservasestpedido) " + criterioBusquedaColec + criteriosBusqueda );
	q.setForwardOnly(true);
	
	debug(q.sql());
	if (!q.exec()) {
		return;
	}
	var idPed;

	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando pedidos"), q.size());
	var cantidad, disponible, disponibleRx, aFabricar, aFaltas, maxFabricable, maxLinea;
	while (q.next()) {
		AQUtil.setProgress(p++);
		cantidad = parseFloat(q.value("s.cantidad"));
		referencia = q.value("a.referencia");
		maxFabricable = _i.dameMaximoFabricable(referencia); 
		maxFabricable =0;
		//maxLinea = _i.fabricableLineaPedido(qryProcesos.value("lp.idlinea"));
		aFabricar = q.value("ms.reservaaf");
		aFaltas = parseFloat(q.value("s.afaltas"));
		//codLote = qryProcesos.value("ls.codlote");
		t.insertRows(f);
		t.setCellBackgroundColor(f, _i.cSEL, _i.cNoSel);
		t.setText(f, _i.cSFM, q.value("sf.descripcion"));
		t.setText(f, _i.cDIB, q.value("di.descripcion"));
		t.setText(f, _i.cCOL, q.value("co.descripcion"));
		t.setText(f, _i.cCODCOL, q.value("co.codcolorem"));
		
		t.setText(f, _i.cREF, q.value("a.referencia"));
		t.setText(f, _i.cART, q.value("a.descripcion"));
		t.setCellBackgroundColor(f, _i.cCAN, _i.cCan);
		t.setText(f, _i.cCAN, cantidad);
		t.setText(f, _i.cAFA, aFaltas);
		t.setText(f, _i.cPRE, q.value("s.prevision"));
		t.setCellBackgroundColor(f, _i.cFAB, _i.cFab);
		t.setText(f, _i.cFAB, aFabricar);
		t.setCellBackgroundColor(f, _i.cMAX, _i.cMax);
		t.setText(f, _i.cMAX, maxFabricable);
		t.setText(f, _i.cRLP, maxLinea);
		t.setText(f, _i.cTAM, q.value("ta.codtamanoem"));		
		

		//t.setText(f, _i.cPED, qryProcesos.value("p.codigo"));
		//t.setText(f, _i.cIDP, qryProcesos.value("p.idpedido"));
		//t.setText(f, _i.cLIN, qryProcesos.value("lp.idlinea"));
		//t.setText(f, _i.cCCL, qryProcesos.value("p.codcliente"));
		//t.setText(f, _i.cCLI, qryProcesos.value("p.nombrecliente"));
		//if (qryProcesos.value("p.fecha")) {
		//	t.setText(f, _i.cFPE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fecha")));
		//}
		//if (qryProcesos.value("p.fechaservicio")) {
		//	t.setText(f, _i.cFSE, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechaservicio")));
		//}
		//if (qryProcesos.value("p.fechasalida")) {
		//	t.setText(f, _i.cFPR, AQUtil.dateAMDtoDMA(qryProcesos.value("p.fechasalida")));
		//}
		
		grupo = q.value("loe.grupo");
		grupo = isNaN(grupo) ? 0 : grupo;
		ordenGrupo = q.value("loe.ordengrupo");
		ordenGrupo = isNaN(ordenGrupo) ? 0 : ordenGrupo;
		orden = (grupo * 1000) + ordenGrupo;
		t.setText(f, _i.cORD, orden);
		
		//idPed = qryProcesos.value("se.exportprod") ? qryProcesos.value("p.idpedido") : "0";
		if (grupo && grupo > 0) {
			std = "GR" + grupo.toString();
		} else {

			//std = q.value("sf.codsubfamilia") + _i.sep_ + q.value("di.coddibujoem");

			t.setText(f, _i.cCSF, q.value("sf.codsubfamilia"));
			t.setText(f, _i.cCDIB, q.value("di.coddibujoem"));

			var oParamOrd = new Object;
			oParamOrd.codSubfamilia = t.text(f, _i.cCSF);
			oParamOrd.codDibujo = t.text(f, _i.cCDIB);
			oParamOrd.idPedido = "0";
			oParamOrd.referencia = t.text(f, _i.cREF);
			oParamOrd.colorPrenda = t.text(f, _i.cCODCOL);
			oParamOrd.tamanio = t.text(f, _i.cTAM);

      		std = _i.criterioAgrupacion(oParamOrd);
		}
		if (!(std in _i.aSDP_)) {
			_i.aSDP_[std] = _i.datosSDP();
		}
		t.setText(f, _i.cSTD, std);
		//t.setText(f, _i.cEPR, q.value("s.disponiblepterecibir"));
		t.setText(f, _i.cEPR, _i.extraPR(referencia));


		/*******************#EUR #H1235 #P0039**************/
		var oParamOrd = new Object;
		oParamOrd.descSubfamilia = q.value("sf.descripcion");
		oParamOrd.descDibujo = q.value("di.descripcion");
		oParamOrd.codTamano = q.value("ta.codtamanoem");


		var sOrdenSTD = _i.ordenSTD(oParamOrd, "ASC");
		t.setText(f, _i.cOrdSTD, sOrdenSTD);  

		var sOrdenSDT = _i.ordenSDT(oParamOrd, "ASC");
		t.setText(f, _i.cOrdSDT, sOrdenSDT);  
		/*******************#EUR #H1235 #P0039**************/

		/*******************#EUR #H1235 #P1124**************/
		t.setText(f, _i.cLEST, q.value("loe.idlinea"));
		/*******************#EUR #H1235 #P1124**************/

		
		f++;
	}
	AQUtil.destroyProgressDialog();
	//FIN 07-08-2015
	
	
}

function oficial_revisaReservasPedidos()
{
	//debug("\n\nrevisaReservasPedidos");
	var _i = this.iface;
	
	var whereOrdenes = _i.tdbOrdenes_.cursor().mainFilter();
	whereOrdenes = whereOrdenes.replace("estado", "op.estado");
	
	var qL = new AQSqlQuery;
	qL.setSelect("ls.codlote, ls.referencia, ms.cantidad, ms.enreserva, ls.idlineapc, op.idmovhijo");
	qL.setFrom("lotesstock ls INNER JOIN pr_ordenesproduccion op ON ls.codordenproduccion = op.codorden INNER JOIN movistock ms ON ls.codlote = ms.codlote");
	qL.setWhere(whereOrdenes);
	debug("qL.sql() " + qL.sql());
	if (!qL.exec()) {
		return false;
	}
	AQUtil.createProgressDialog(sys.translate("Revisando stocks y reservas de pedido"), qL.size());
	var p = 0;
	
	var qRes = new AQSqlQuery;
	qRes.setSelect("lp.idlinea, ms.reservapr, ms.reservaaf, lp.referencia");
	qRes.setFrom("lineaspedidoscli lp INNER JOIN movistock ms ON lp.idlinea = ms.idlineapc");
	
	var codAlmacen = flfactalma.iface.pub_almacenFabricacion();
	var idStock, referencia;
	var sigue;
	while (qL.next()) {
		AQUtil.setProgress(++p);
		
		if (qL.value("ls.idlineapc")) {
			if (!flfactalma.iface.revisaReservasPedidoProd(qL.value("ls.idlineapc"), qL.value("op.idmovhijo"))) {
				AQUtil.destroyProgressDialog();
				return false;
			}
		}		
		var referencia = qL.value("ls.referencia");
		var idStock = AQUtil.sqlSelect("stocks", "idstock", "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "'");
		if (!flfactalma.iface.pub_revisarReservasStock(idStock)) {
			AQUtil.destroyProgressDialog();
			return false;
		}
		qRes.setWhere("lp.referencia = '" + referencia + "' AND ms.reservapr > 0 ORDER BY lp.idpedido, lp.idlinea");
		if (!qRes.exec()) {
			AQUtil.destroyProgressDialog();
			return false;
		}
debug(qRes.sql());
	
		var enReservaPr = 0, disponibleRx;
		var yaReservadoRx, porReservar;

		sigue = qRes.next();
		if (!sigue) {
			AQUtil.destroyProgressDialog();
			return true;
		}
		var reservaPR = qRes.value("ms.reservapr");
		reservaPR = isNaN(reservaPR) ? 0 : reservaPR;

		//no se si habr�a que hacer algo aqu�, cuando sea una componente no va a encontrar nada porque el movimineto no tien tiene idlineapc.

		yaReservadoRx =  AQUtil.sqlSelect("movistock mres INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva INNER JOIN movistock mpterx ON rpr.idmovpterx = mpterx.idmovimiento", "SUM(rpr.cantidad)", "mres.idlineapc = " + qRes.value("lp.idlinea") + " AND mpterx.estado = 'PTE'", "movistock");
		yaReservadoRx = isNaN(yaReservadoRx) ? 0 : yaReservadoRx;
		
		porReservar = reservaPR - yaReservadoRx;
		//debug("porReservar  " + porReservar );

		enReservaPr = qL.value("ms.enreserva");
		enReservaPr = isNaN(enReservaPr) ? 0 : enReservaPr;
		disponibleRx = qL.value("ms.cantidad") - enReservaPr;
		disponibleRx = isNaN(disponibleRx) ? 0 : disponibleRx;
			
		var cantidad;
		while (sigue) {
			//debug("idLinea  " + qRes.value("lp.idlinea") + " cantidad " + porReservar + " Lote " +  qL.value("ls.codlote") + " cantidad " + disponibleRx);

			if (Math.round(disponibleRx) > 0) {
				cantidad = Math.min(disponibleRx, porReservar);
				if (cantidad > 0) {
					if (!AQSql.insert("em_reservaslotepedido", ["idlineapc", "codlote", "cantidad"], [qRes.value("lp.idlinea") , qL.value("ls.codlote"), cantidad])) {
						AQUtil.destroyProgressDialog();
						return false;
					}
					if (!flfactalma.iface.revisaReservasPedidoProd(qRes.value("lp.idlinea"), qL.value("op.idmovhijo"))) {
						AQUtil.destroyProgressDialog();
						return false;
					}
				}
			}
			var saldo = porReservar - disponibleRx;
			//debug("Saldo "+ saldo);
			if (saldo >= 0) {
				sigue = false;
			}
			if (saldo < 0) {
				disponibleRx = disponibleRx - porReservar;
				sigue = sigue && qRes.next();
				if (sigue) {
					reservaPR = qRes.value("ms.reservapr");
					reservaPR = isNaN(reservaPR) ? 0 : reservaPR;
	
					yaReservadoRx =  AQUtil.sqlSelect("movistock mres INNER JOIN em_reservaspterx rpr ON mres.idmovimiento = rpr.idmovreserva INNER JOIN movistock mpterx ON rpr.idmovpterx = mpterx.idmovimiento", "SUM(rpr.cantidad)", "mres.idlineapc = " + qRes.value("lp.idlinea") + " AND mpterx.estado = 'PTE'", "movistock");
					yaReservadoRx = isNaN(yaReservadoRx) ? 0 : yaReservadoRx;
			
					porReservar = reservaPR - yaReservadoRx;
//debug("reservaPR " + reservaPR + " a faltas " + qRes.value("ms.reservaaf") + " yaReservadoRx " + yaReservadoRx + " porReservar " + porReservar);
				}
			}
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_extraPR(referencia)
{
  	var _i = this.iface;  	
	
	var min = Number.MAX_VALUE;
	if (referencia in _i.lotPR_) {	
	
		var canCompuesto, comp;

		for (var comp in _i.lotPR_[referencia]) {
			if (!(comp in _i.refPR_)) {
				_i.refPR_[comp] = _i.dameReferenciaPR();				
			}			
			canCompuesto = _i.refPR_[comp]["dispPR"] / _i.lotPR_[referencia][comp];
			
			if (canCompuesto < min) {
				min = canCompuesto;
			}
		}
	} else {		
		_i.lotPR_[referencia] = _i.dameLote();	
		_i.EPRini_[referencia] = 0;	
		var codAlmacen = "1";
		var qComp = new FLSqlQuery;
		qComp.setTablesList("articuloscomp,stocks");
		qComp.setSelect("ac.refcomponente, SUM(ac.cantidad * ac.factor), s.disponiblepterecibir");
		qComp.setFrom("articuloscomp ac LEFT OUTER JOIN stocks s ON (ac.refcomponente = s.referencia AND s.codalmacen = '" + codAlmacen + "')");
		qComp.setWhere("ac.refcompuesto = '" + referencia + "' AND ac.reservar GROUP BY ac.refcomponente, s.disponiblepterecibir");
		qComp.setForwardOnly(true);
		if (!qComp.exec()) {
			return false;
		}
		var c, f, d, canCompuesto, comp;
		while (qComp.next()) {
			comp = qComp.value("ac.refcomponente");		
			f  = qComp.value("SUM(ac.cantidad * ac.factor)");			
			f  = f ? f : 1;
			_i.lotPR_[referencia][comp] = f; /// Factor del componente respecto al compuesto			
			d = qComp.value("s.disponiblepterecibir");			
			d = d ? d : 0;
			if (!(comp in _i.refPR_)) {
				_i.refPR_[comp] = _i.dameReferenciaPR();
			}			
			_i.refPR_[comp]["stockPR"] = d;
			_i.refPR_[comp]["dispPR"] = d;			
			canCompuesto = d / f;
			
			if (canCompuesto < min) {
				min = canCompuesto;
			}
			var minIni = min;
			minIni = minIni == Number.MAX_VALUE ? 0 : minIni;
			minIni = Math.floor(minIni);
			
			_i.EPRini_[referencia] = minIni;
		}
	}
	
  	min = min == Number.MAX_VALUE ? 0 : min;
	min=  AQUtil.roundFieldValue(min,"movistock", "reservaaf");
	min = Math.floor(min);	
  return min;
}

function oficial_dameReferenciaPR()
{
	var ref = [];
	ref["stockPR"] = 0;
	ref["dispPR"] = 0;
	return ref;
}

function oficial_restaStockLotePR(referencia, cantidad)
{
	//debug("oficial_restaStockLotePR");
	var _i = this.iface;
	for (var comp in _i.lotPR_[referencia]) {
		//debug("oficial_restaStockLotePR 1");
		_i.refPR_[comp]["dispPR"] -= (cantidad * _i.lotPR_[referencia][comp]);
		//debug("oficial_restaStockLotePR 2");
	}
	//debug("oficial_restaStockLotePR 3");
	if (!_i.actualizaEPR()) {
		return false;
	}
	//debug("oficial_restaStockLotePR OK");
	return true;
}

function oficial_sumaStockLotePR(referencia, cantidad)
{
	var _i = this.iface;
	for (var comp in _i.lotPR_[referencia]) {
		_i.refPR_[comp]["dispPR"] += (cantidad * _i.lotPR_[referencia][comp]);

	}
	if (!_i.actualizaEPR()) {
		return false;
	}
	return true;
}

function oficial_actualizaEPR()
{
	//debug("actualizaEPR");
	var _i = this.iface;
	var t =  _i.t_;
	
	var nF = t.numRows();
	var maxLinea, extraPR;
	for (var f = 0; f < nF; f++) {
		extraPR = _i.extraPR(t.text(f, _i.cREF)); 
		t.setText(f, _i.cEPR, extraPR);
	}
	//debug("actualizaEPR OK");
	return true;
}
function oficial_gramajesOrdenesProd(oAdicionales,referencia)
{
	//sacar el anverso de la referencia
	//ir a articulos y sacar el metros del anverso
	//meter en el array
	var refCompNapa = AQUtil.sqlSelect("articuloscomp","refcomponente", "refcompuesto ='" + referencia + "' AND componormal IN ('NAPA') ORDER BY componormal");	

	var metrosAnverso = AQUtil.sqlSelect("articulos","em_pesom2", "referencia ='" + refCompNapa + "'");
	
	if(metrosAnverso && metrosAnverso != "") {		
		if(!(metrosAnverso in oAdicionales.gramajes)) {
			oAdicionales.gramajes[metrosAnverso] = metrosAnverso;
		}
	}

	var refCompAnv = AQUtil.sqlSelect("articuloscomp","refcomponente", "refcompuesto ='" + referencia + "' AND componormal IN ('ANVERSO', 'ANVERSO COJIN') ORDER BY componormal");



	var q = new AQSqlQuery;
	q.setSelect("subfamilias.em_alias");
	q.setFrom("articulos inner join subfamilias on articulos.codsubfamilia = subfamilias.codsubfamilia");
	q.setWhere("referencia ='" + refCompAnv + "'");
	if (!q.exec()) {
		return false;
	}
	
	if(q.first()) {

		var tejido =  q.value("subfamilias.em_alias");
		if(tejido && tejido != "") {
			if(!(tejido in oAdicionales.tejidos)) {
				oAdicionales.tejidos[tejido] = tejido;
			}
		}
	}

	var q = new AQSqlQuery;
	q.setSelect("acabado");
	q.setFrom("em_acabadosart");
	q.setWhere("referencia = '" + referencia + "'");
	if (!q.exec()) {
		return false;
	}
	var acabado;
	while (q.next()) {
		acabado = q.value("acabado");
		if(acabado && acabado != "") {
			if(!(acabado in oAdicionales.acabados)) {
				oAdicionales.acabados[acabado] = acabado;
			}
		}
	}

	return true;
}

function oficial_dameCantAFabricar(qryProcesos)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var aFabricar, canPedida;
	var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
	var porAFab; 
	if(fabPorcentaje) {
		canPedida = qryProcesos.value("lp.cantidad");
		porAFab = cursor.valueBuffer("porafabricar");
		aFabricar = (parseFloat(porAFab) * parseFloat(canPedida)) / 100;
		aFabricar = Math.ceil(aFabricar);
	} else {
		aFabricar = qryProcesos.value("ms.reservaaf");
	}
	return aFabricar;
}

function oficial_dameCantAFabricarComp(qryProcesos)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var aFabricar, canPedida;
	var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
	var porAFab; 
	if(fabPorcentaje) {


		canPedida  = qryProcesos.value("lp.cantidad") * qryProcesos.value("ac.cantidad*ac.factor");

		var oAnverso = flfactalma.iface.dameReferenciaAnverso(qryProcesos.value("lp.referencia"), qryProcesos.value("a.referencia"), qryProcesos.value("ac.id"));
		var referenciaMargen = oAnverso.referenciaAnverso;
		var factor = oAnverso.factor;
		
		debug("referenciaMargen: "+referenciaMargen);
		debug("factor: "+factor);

		if(referenciaMargen) {
			var codSubfamProd = AQUtil.sqlSelect("articulos","codsubfamilia","referencia = '" + qryProcesos.value("lp.referencia") + "' ");
			//cantidad = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, cantidad, true)	
			var oParamMargen = new Object;
			oParamMargen.referencia = referenciaMargen;
			oParamMargen.codSubfamilia = codSubfamProd
			oParamMargen.cantidad = canPedida;
			oParamMargen.noInicio = true
			oParamMargen.factor = factor;
			oParamMargen.cantidadM = qryProcesos.value("lp.cantidad");
			oParamMargen.cantidadFT = qryProcesos.value("ac.cantidad");
			oParamMargen.piezasAncho =  qryProcesos.value("ac.piezasancho");

			//margen = fleumoesta.iface.dameCantidadMargen(referenciaMargen, codSubfamProd, cantidad, true, factor);
			margen = fleumoesta.iface.dameCantidadMargen(oParamMargen);
			debug("margen: "+margen);
			/*var piezasAncho = qryFT.value("ac.piezasancho"); 15-11-2017
			if(piezasAncho && piezasAncho != 0)  {
				margen = margen / piezasAncho;
			}*/
		}

		if(factor && factor != "" && referenciaMargen) {
			//factor += margen; 15-11-2017
			//cantidad = -1 * curMS.valueBuffer("reservaaf") * factor; 15-11-2017
			canPedida = qryProcesos.value("lp.cantidad") * factor + margen;
			
		}


		//canPedida = qryProcesos.value("lp.cantidad");
		porAFab = cursor.valueBuffer("porafabricar");
		aFabricar = (parseFloat(porAFab) * parseFloat(canPedida)) / 100;
		aFabricar = Math.ceil(aFabricar);
	} else {
		aFabricar = qryProcesos.value("ms2.reservaaf");
	}
	return aFabricar;
}

/*function oficial_habilitaPorFabPorcentaje()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(this.child("chkBuscarPedidos").checked) {
		if(!this.child("chkBuscarStocks").checked) {
			sys.enableObj(this, "chkFabPorcentaje");			
		} else {
			sys.disableObj(this, "chkFabPorcentaje");	
			this.child("chkFabPorcentaje").setValue(false);
		}		
		sys.enableObj(this, "fdbCodSerie");
		
	} else {
		sys.disableObj(this, "chkFabPorcentaje");	
		this.child("chkFabPorcentaje").setValue(false);
		sys.disableObj(this, "fdbCodSerie");	
		this.child("fdbCodSerie").setValue("");
	} 
	var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
	if(fabPorcentaje) {
		sys.enableObj(this, "fdbPorAFabricar");
		this.child("fdbPorAFabricar").setValue(100);
	} else {
		sys.disableObj(this, "fdbPorAFabricar");
		this.child("fdbPorAFabricar").setValue("");
	}
}*/

function oficial_habilitaPorFabPorcentaje()
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.valueBuffer("busqpedidos")) {
		if(!cursor.valueBuffer("busqstocks")) {		
			sys.enableObj(this, "chkFabPorcentaje");			
		} else {
			sys.disableObj(this, "chkFabPorcentaje");	
			this.child("chkFabPorcentaje").setValue(false);
		}		
		sys.enableObj(this, "fdbCodSerie");
		sys.enableObj(this, "chkBuscarComponentes");
		sys.enableObj(this, "chkSoloComponentes");
		
	} else {
		sys.disableObj(this, "chkFabPorcentaje");	
		this.child("chkFabPorcentaje").setValue(false);
		sys.disableObj(this, "chkBuscarComponentes");
		this.child("chkBuscarComponentes").setValue(false);
		sys.disableObj(this, "chkSoloComponentes");
		this.child("chkSoloComponentes").setValue(false);
		sys.disableObj(this, "fdbCodSerie");	
		this.child("fdbCodSerie").setValue("");
	} 
	var fabPorcentaje = cursor.valueBuffer("fabporcentaje");
	if(fabPorcentaje) {
		sys.enableObj(this, "fdbPorAFabricar");
		this.child("fdbPorAFabricar").setValue(100);
	} else {
		sys.disableObj(this, "fdbPorAFabricar");
		this.child("fdbPorAFabricar").setValue("");
	}
}


/*function oficial_criterioAgrupacion(oParamOrd)
{
	var cursor = this.cursor();
	var fusionarPedidos = cursor.valueBuffer("fusionarpedidos");
	var unLoteXop = cursor.valueBuffer("unlotexop");
	var _i = this.iface;
	var std = "";
	if(!unLoteXop) {

		var qGR = new AQSqlQuery;	
		qGR.setSelect("agrupado, orden");
		qGR.setFrom("em_gruposordenprod");
		qGR.setWhere("1 = 1 order by orden"); 			
		if (!qGR.exec()){
			return;
		}  
		while(qGR.next())
		{
			var campo = qGR.value("agrupado");
			var orden = qGR.value("orden");


			switch (campo) {
				case "Subfamilia Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.codSubfamilia;						
					break;
				}
				case "Dibujo Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.codDibujo;	
							
					break;
				}
				case "Pedido Cliente": {
					std += std == "" ? "" : _i.sep_;
					if(fusionarPedidos) {
						std += "0";        
					} else {
						std += oParamOrd.idPedido;        	
					}				
					break;
				}
				case "Referencia Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.referencia;       
					
					break;
				}		
				default: {

				}		
			}
		}
	} else {	
		std += std == "" ? "" : _i.sep_;
		std += oParamOrd.referencia;  
		if(!fusionarPedidos) {
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.idPedido;        	
		}
	}
	return std;
      
}*/

/*function oficial_criterioAgrupacion(oParamOrd)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var fusionarPedidos = cursor.valueBuffer("fusionarpedidos");
	var unLoteXop = cursor.valueBuffer("unlotexop");
	var codTamanos = cursor.valueBuffer("codtamanoem");
	var codColores = cursor.valueBuffer("codcolorem");
	var aTamanos = [];
	if(codTamanos && codTamanos != "") {
		aTamanos = codTamanos.split(",");
		codTamanos = flfactppal.iface.pub_replace(codTamanos,",",_i.sep_);
	}
	var aColores = [];
	if(codColores && codColores != "") {
		aColores = codColores.split(",");
		codColores = flfactppal.iface.pub_replace(codColores,",",_i.sep_);
	}
	
	
	var separadoPor = cursor.valueBuffer("separadopor");
	
	var std = "";
	if(!unLoteXop) {

		var qGR = new AQSqlQuery;	
		qGR.setSelect("agrupado, orden");
		qGR.setFrom("em_gruposordenprod");
		qGR.setWhere("1 = 1 order by orden"); 			
		if (!qGR.exec()){
			return;
		}  
		while(qGR.next())
		{
			var campo = qGR.value("agrupado");
			var orden = qGR.value("orden");


			switch (campo) {
				case "Subfamilia Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.codSubfamilia;						
					break;
				}
				case "Dibujo Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.codDibujo;	
							
					break;
				}
				case "Pedido Cliente": {
					std += std == "" ? "" : _i.sep_;
					if(fusionarPedidos) {
						std += "0";        
					} else {
						std += oParamOrd.idPedido;        	
					}				
					break;
				}
				case "Referencia Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.referencia;       
					
					break;
				}		
				default: {

				}		
			}
		}		
		if(separadoPor == "Color prenda") {			
			var encontrado = false;
			for(k=0; k<aColores.length && !encontrado; k++){
				if(aColores[k]==oParamOrd.colorPrenda) {
					encontrado = true;
				}
			} 
			if(encontrado) {
				std += std == "" ? "" : _i.sep_;
				std += codColores;	
			}				
		} else if(separadoPor == "Tama�o") {
			var encontrado = false;
			for(k=0; k<aTamanos.length && !encontrado; k++){
				if(aTamanos[k]==oParamOrd.tamanio) {
					encontrado = true;
				}
			} 
			if(encontrado) {
				std += std == "" ? "" : _i.sep_;
				std += codTamanos;	
			}	
		} else if(separadoPor == "Color prenda-Tama�o") {
			var encontrado = false;
			for(k=0; k<aColores.length && !encontrado; k++){
				if(aColores[k]==oParamOrd.colorPrenda) {
					encontrado = true;
				}
			} 
			if(encontrado) {
				encontrado = false;
				for(k=0; k<aTamanos.length && !encontrado; k++){
					if(aTamanos[k]==oParamOrd.tamanio) {
						encontrado = true;
					}
				} 
			}
			if(encontrado) {
				std += std == "" ? "" : _i.sep_;
				std += codColores;						
				std += std == "" ? "" : _i.sep_;
				std += codTamanos;	
			}	
		} else if(separadoPor == "Tama�o-Color prenda") {
			var encontrado = false;
			for(k=0; k<aTamanos.length && !encontrado; k++){
				if(aTamanos[k]==oParamOrd.tamanio) {
					encontrado = true;
				}
			} 
			if(encontrado) {
				encontrado = false;
				for(k=0; k<aColores.length && !encontrado; k++){
					if(aColores[k]==oParamOrd.colorPrenda) {
						encontrado = true;
					}
				}	
			}
			if(encontrado) {
				std += std == "" ? "" : _i.sep_;
				std += codTamanos;						
				std += std == "" ? "" : _i.sep_;
				std += codColores;	
			}	
		}
	} else {	
		std += std == "" ? "" : _i.sep_;
		std += oParamOrd.referencia;  
		if(!fusionarPedidos) {
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.idPedido;        	
		}
	}
	return std;
      
}*/

function oficial_criterioAgrupacion(oParamOrd)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var fusionarPedidos = cursor.valueBuffer("fusionarpedidos");
	var unLoteXop = cursor.valueBuffer("unlotexop");	
	var separadoPor = cursor.valueBuffer("separadopor");
	
	var std = "";
	if(!unLoteXop) {

		var qGR = new AQSqlQuery;	
		qGR.setSelect("agrupado, orden");
		qGR.setFrom("em_gruposordenprod");
		qGR.setWhere("1 = 1 order by orden"); 			
		if (!qGR.exec()){
			return;
		}  
		while(qGR.next())
		{
			var campo = qGR.value("agrupado");
			var orden = qGR.value("orden");


			switch (campo) {
				case "Subfamilia Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.codSubfamilia;						
					break;
				}
				case "Dibujo Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.codDibujo;	
							
					break;
				}
				case "Pedido Cliente": {
					std += std == "" ? "" : _i.sep_;
					if(fusionarPedidos) {
						std += "0";        
					} else {
						std += oParamOrd.idPedido;        	
					}				
					break;
				}
				case "Referencia Prenda": {					
					std += std == "" ? "" : _i.sep_;
					std += oParamOrd.referencia;       
					
					break;
				}		
				default: {

				}		
			}
		}		
		if(separadoPor == "Color prenda") {	
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.colorPrenda;	
							
		} else if(separadoPor == "Tama�o") {			
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.tamanio;	
			
		} else if(separadoPor == "Color prenda-Tama�o") {
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.colorPrenda;	
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.tamanio;	
		} else if(separadoPor == "Tama�o-Color prenda") {
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.tamanio;
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.colorPrenda;				
		}
	} else {	
		std += std == "" ? "" : _i.sep_;
		std += oParamOrd.referencia;  
		if(!fusionarPedidos) {
			std += std == "" ? "" : _i.sep_;
			std += oParamOrd.idPedido;        	
		}
	}
	return std;
      
}

function oficial_limpiarTabla()
{
	var _i = this.iface;
	var t = _i.t_;
	t.setNumRows(0);
}

function oficial_compruebaCampoPedido(codPedido)
{
	var _i = this.iface;
	var pedido;
	if (codPedido.find(",") >= 0) {
		var aPedidos =  codPedido.split(",");
		for(var i=0; i< aPedidos.length; i++) {
			pedido = aPedidos[i];
			if(!AQUtil.sqlSelect("pedidoscli","codigo","codigo = '" + pedido + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Pedido(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(pedido),"warn",this);
				return false;
			}			
		}
	} else if (codPedido.find("-") >= 0) {
		var min = codPedido.split("-")[0];
		var max = codPedido.split("-")[1];
		if(!AQUtil.sqlSelect("pedidoscli","codigo","codigo = '" + min + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Pedido(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(min),"warn",this);
			return false;
		}	
		if(!AQUtil.sqlSelect("pedidoscli","codigo","codigo = '" + max + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Pedido(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(max),"warn",this);
			return false;
		}			
	} else {
		pedido = codPedido;
		if(!AQUtil.sqlSelect("pedidoscli","codigo","codigo = '" + pedido + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Pedido(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(pedido),"warn",this);
			return false;
		}	
	}
	return true;
}

function oficial_compruebaCampoFamEx(famExcluidas)
{
	var _i = this.iface;
	var codFamilia;
	if (famExcluidas.find(",") >= 0) {
		var aFamilias = famExcluidas.split(",");
		for(var i=0; i< aFamilias.length; i++) {
			codFamilia = aFamilias[i];
			if(!AQUtil.sqlSelect("familias","codfamilia","codfamilia = '" + codFamilia + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Fam.(s) excluida(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(codFamilia),"warn",this);
				return false;
			}			
		}
	} else {
		codFamilia = famExcluidas;
		if(!AQUtil.sqlSelect("familias","codfamilia","codfamilia = '" + codFamilia + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Fam.(s) excluida(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(codFamilia),"warn",this);
			return false;
		}		
	}
	return true;
}

function oficial_compruebaCampoSubFamEx(subFamExcluidas)
{
	var _i = this.iface;
	var codSubfamilia;
	if (subFamExcluidas.find(",") >= 0) {
		var aSubfamilias = subFamExcluidas.split(",");
		for(var i=0; i< aSubfamilias.length; i++) {
			codSubfamilia = aSubfamilias[i];
			if(!AQUtil.sqlSelect("subfamilias","codsubfamilia","codsubfamilia = '" + codSubfamilia + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Subfam.(s) excluida(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(codSubfamilia),"warn",this);
				return false;
			}			
		}
	} else {
		codSubfamilia = subFamExcluidas;
		if(!AQUtil.sqlSelect("subfamilias","codsubfamilia","codsubfamilia = '" + codSubfamilia + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Subfam.(s) excluida(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(codSubfamilia),"warn",this);
			return false;
		}		
	}
	return true;
}

function oficial_compruebaCampoCliente(codCliente)
{
	var _i = this.iface;
	var cliente;
	if (codCliente.find(",") >= 0) {
		var aClientes =  codCliente.split(",");
		for(var i=0; i< aClientes.length; i++) {
			cliente = aClientes[i];
			if(!AQUtil.sqlSelect("clientes","codcliente","codcliente = '" + cliente + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Cod.Cliente(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(cliente),"warn",this);
				return false;
			}			
		}
	} else if (codCliente.find("-") >= 0) {
		var min = codCliente.split("-")[0];
		var max = codCliente.split("-")[1];
		if(!AQUtil.sqlSelect("clientes","codcliente","codcliente = '" + min + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Cod.Cliente(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(min),"warn",this);
			return false;
		}	
		if(!AQUtil.sqlSelect("clientes","codcliente","codcliente = '" + max + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Cod.Cliente(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(max),"warn",this);
			return false;
		}			
	} else {
		cliente = codCliente;
		if(!AQUtil.sqlSelect("clientes","codcliente","codcliente = '" + cliente + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Cod.Cliente(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(cliente),"warn",this);
			return false;
		}	
	}
	return true;
}

function oficial_compruebaCampoGrupoCli(codGrupoCli)
{
	var _i = this.iface;
	var grupoCli;
	if (codGrupoCli.find(",") >= 0) {
		var aGrupos =  codGrupoCli.split(",");
		for(var i=0; i< aGrupos.length; i++) {
			grupoCli = aGrupos[i];
			if(!AQUtil.sqlSelect("gruposclientes","codgrupo","codgrupo = '" + grupoCli + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Grupo(s) clientes, el valor %1 hemos comprobado que no existe en su tabla asociada").arg(grupoCli),"warn",this);
				return false;
			}			
		}
	} else if (codGrupoCli.find("-") >= 0) {
		var min = codGrupoCli.split("-")[0];
		var max = codGrupoCli.split("-")[1];
		if(!AQUtil.sqlSelect("gruposclientes","codgrupo","codgrupo = '" + min + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Grupo(s) clientes, el valor %1 hemos comprobado que no existe en su tabla asociada").arg(min),"warn",this);
			return false;
		}	
		if(!AQUtil.sqlSelect("gruposclientes","codgrupo","codgrupo = '" + max + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Grupo(s) clientes, el valor %1 hemos comprobado que no existe en su tabla asociada").arg(max),"warn",this);
			return false;
		}			
	} else {
		grupoCli = codGrupoCli;
		if(!AQUtil.sqlSelect("gruposclientes","codgrupo","codgrupo = '" + grupoCli + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Grupo(s) clientes, el valor %1 hemos comprobado que no existe en su tabla asociada").arg(grupoCli),"warn",this);
			return false;
		}	
	}
	return true;
}

function oficial_ordenSTD(oParamOrd, ascDesc)
{
	var _i = this.iface;

	var descSubfamilia = flfactppal.iface.pub_espaciosDerecha(oParamOrd.descSubfamilia,100);
	var descDibujo = flfactppal.iface.pub_espaciosDerecha(oParamOrd.descDibujo,100);
	var codTamano = flfactppal.iface.pub_espaciosDerecha(oParamOrd.codTamano,25);		
	
	return descSubfamilia+codTamano+descDibujo;	

}

function oficial_ordenSDT(oParamOrd, ascDesc)

{
	var descSubfamilia = flfactppal.iface.pub_espaciosDerecha(oParamOrd.descSubfamilia,100);
	var descDibujo = flfactppal.iface.pub_espaciosDerecha(oParamOrd.descDibujo,100);
	var codTamano = flfactppal.iface.pub_espaciosDerecha(oParamOrd.codTamano,25);		
	
	return descSubfamilia+descDibujo+codTamano;	

}

function oficial_compruebaCampoTamano(codTamanoEM)
{
	var _i = this.iface;
	var tamano;
	if (codTamanoEM.find(",") >= 0) {
		var aTamanos =  codTamanoEM.split(",");
		for(var i=0; i< aTamanos.length; i++) {
			tamano = aTamanos[i];
			if(!AQUtil.sqlSelect("em_tamanos","codtamanoem","codtamanoem = '" + tamano + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Tama�o(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(tamano),"warn",this);
				return false;
			}			
		}
	} else if (codTamanoEM.find("-") >= 0) {
		var min = codTamanoEM.split("-")[0];
		var max = codTamanoEM.split("-")[1];
		if(!AQUtil.sqlSelect("em_tamanos","codtamanoem","codtamanoem = '" + min + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Tama�o(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(min),"warn",this);
			return false;
		}	
		if(!AQUtil.sqlSelect("em_tamanos","codtamanoem","codtamanoem = '" + max + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Tama�o(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(max),"warn",this);
			return false;
		}			
	} else {
		tamano = codTamanoEM;
		if(!AQUtil.sqlSelect("em_tamanos","codtamanoem","codtamanoem = '" + tamano + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Tama�o(s), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(tamano),"warn",this);
			return false;
		}	
	}
	return true;
}

function oficial_compruebaCampoColor(codColorEM)
{
	var _i = this.iface;
	var color;
	if (codColorEM.find(",") >= 0) {
		var aColores =  codColorEM.split(",");
		for(var i=0; i< aColores.length; i++) {
			color = aColores[i];
			if(!AQUtil.sqlSelect("em_colores","codcolorem","codcolorem = '" + color + "'")) {
				flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Color(es), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(color),"warn",this);
				return false;
			}			
		}
	} else if (codColorEM.find("-") >= 0) {
		var min = codColorEM.split("-")[0];
		var max = codColorEM.split("-")[1];
		if(!AQUtil.sqlSelect("em_colores","codcolorem","codcolorem = '" + min + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Color(es), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(min),"warn",this);
			return false;
		}	
		if(!AQUtil.sqlSelect("em_colores","codcolorem","codcolorem = '" + max + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Color(es), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(max),"warn",this);
			return false;
		}			
	} else {
		color = codColorEM;
		if(!AQUtil.sqlSelect("em_colores","codcolorem","codcolorem = '" + color + "'")) {
			flfactppal.iface.ponMsgError(sys.translate("Revise el valor indicado en el campo Color(es), el valor %1 hemos comprobado que no existe en su tabla asociada").arg(color),"warn",this);
			return false;
		}	
	}
	return true;
}

function oficial_habilitaSoloComponentes()
{
	var _i = this.iface;

	var _i = this.iface;
	var cursor = this.cursor();
	if(cursor.valueBuffer("busqcomponentes")) {
		sys.enableObj(this, "chkSoloComponentes");

	} else {
		sys.disableObj(this, "chkSoloComponentes");
		this.child("chkSoloComponentes").setValue(false);

	}
}

function oficial_debugReservasPedido(desc)
{
	return true;
	debug("\n\n-----------" + desc + " ----------------");
	var q = new FLSqlQuery();	
	q.setSelect("idrlp,codlote,idlineapc,idarticulocomp");
	q.setFrom("em_reservaslotepedido");
	q.setWhere("idlineapc = 1219390");	
	if (!q.exec()){
		return false;
	}
	while(q.next()) {
		debug("idrlp: " + q.value("idrlp") + " codLote: "+q.value("codlote") + " idLineaPc: " + q.value("idlineapc") + " idArticuloComp: " + q.value("idarticulocomp"));
		debug("idReservaPte: "+AQUtil.sqlSelect("em_reservaspterx","id","idrlp = " + q.value("idrlp"))+ "\n");
	}
	debug("\n------------------------------------------");
}

function oficial_tbnPonerFechaNulo_clicked()
{
	var _i = this.iface;
	
	var cursor = this.cursor();
	if (!cursor.isNull("nuevafechaentrega")) {
		cursor.setNull("nuevafechaentrega");
		this.child("fdbNuevaFechaEntrega").setValue("");
	}
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
