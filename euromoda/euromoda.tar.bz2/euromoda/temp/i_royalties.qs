/***************************************************************************
                 i_royalties.qs  -  description
                             -------------------
    begin                : lun may 7 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 
/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  function oficial( context ) { interna( context ); } 
  function bufferChanged(fN:String) {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function habilitarPorFiltroDto() {
		return this.ctx.oficial_habilitarPorFiltroDto();
	}
	function cargaAgentes() {
		this.ctx.oficial_cargaAgentes();
	}
	function guardaAgentes() {
		return this.ctx.oficial_guardaAgentes();
	}
	function chkAgentesSel_clicked() {
		return this.ctx.oficial_chkAgentesSel_clicked();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
  function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor()
  this.iface.habilitarPorFiltroDto();
  connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("chkAgentesSel"), "clicked()", _i, "chkAgentesSel_clicked");
	
	_i.cargaAgentes();
	_i.chkAgentesSel_clicked();
}

function interna_validateForm()
{
	var _i = this.iface;
  var cursor = this.cursor()
  
  if (!_i.guardaAgentes()) {
		MessageBox.warning(sys.translate("Error al guardar la lista de agentes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_chkAgentesSel_clicked()
{
	var _i = this.iface;
	var filtro;
	if (this.child("chkAgentesSel").checked) {
		var aAgentes = this.child("tdbAgentes").primarysKeysChecked();
		filtro = "1 = 2";
		if (aAgentes) {
			filtro = "codagente IN ('" + aAgentes.join("', '") + "')";
		}
	} else {
		filtro = "";
	}
	this.child("tdbAgentes").setFilter(filtro);
	this.child("tdbAgentes").refresh();
}

function oficial_cargaAgentes()
{
	var _i = this.iface;
  var cursor = this.cursor()

	var listaAgentes = cursor.valueBuffer("listaagentes");
	if (!listaAgentes || listaAgentes == "") {
		return;
	}
	var aAgentes = listaAgentes.split(",");
	for (var a = 0; a < aAgentes.length; a++) {
		this.child("tdbAgentes").setPrimaryKeyChecked(aAgentes[a], true);
	}
}

function oficial_guardaAgentes()
{
	var _i = this.iface;
  var cursor = this.cursor()
  
  var aAgentes = this.child("tdbAgentes").primarysKeysChecked();
	if (aAgentes) {
		cursor.setValueBuffer("listaagentes", aAgentes.join(","));
	} else {
		cursor.setNull("listaagentes");
	}
	return true;
}

function oficial_bufferChanged(fN:String)
{
  var cursor:FLSqlCursor = this.cursor();
  
  switch(fN){
    /** \C Si cambia el intervalo se recalculan las fechas.
    \end */
    case "codintervalo":{
      var intervalo:Array = [];
      if(cursor.valueBuffer("codintervalo")){
	intervalo = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalo"));
	cursor.setValueBuffer("d_facturascli_fecha", intervalo.desde);
	cursor.setValueBuffer("h_facturascli_fecha", intervalo.hasta);
      }
      break;
    }
    case "filtrardto": {
      this.iface.habilitarPorFiltroDto();
      break;
    }
  }
}

function oficial_habilitarPorFiltroDto()
{
	var cursor:FLSqlCursor = this.cursor();
	
	if (cursor.valueBuffer("filtrardto")) {
		this.child("fdbDesdeDto").setDisabled(false);
		this.child("fdbHastaDto").setDisabled(false);
	} else {
		this.child("fdbDesdeDto").setValue("");
		this.child("fdbHastaDto").setValue("");
		this.child("fdbHastaDto").setDisabled(false);
		this.child("fdbDesdeDto").setDisabled(true);
		this.child("fdbHastaDto").setDisabled(true);
	}
}

//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
