var form = this;
/***************************************************************************
                 em_cambioubicacion.qs  -  description
                             -------------------
    begin                : lun jun 04 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
  function oficial( context ) { interna( context ); }
  function bufferChanged(fN) {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function buscarLotes() {
    return this.ctx.oficial_buscarLotes();
  }
  function seleccionarTodoDe() {
    return this.ctx.oficial_seleccionarTodoDe();
  }
  function deseleccionarTodoDe() {
    return this.ctx.oficial_deseleccionarTodoDe();
  }
  function seleccionarTodoHacia() {
    return this.ctx.oficial_seleccionarTodoHacia();
  }
  function deseleccionarTodoHacia() {
    return this.ctx.oficial_deseleccionarTodoHacia();
  }
  function deHacia() {
    return this.ctx.oficial_deHacia();
  }
  function haciaDe() {
    return this.ctx.oficial_haciaDe();
  }
  function refrescarTablas() {
    return this.ctx.oficial_refrescarTablas();
  }
  function dameFiltroDe() {
    return this.ctx.oficial_dameFiltroDe();
	}
	function dameFiltroHacia() {
		return this.ctx.oficial_dameFiltroHacia();
	}
	function ordenarTablas() {
		return this.ctx.oficial_ordenarTablas();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();

	_i.ordenarTablas();

	this.child("tdbLineasLotesStockDe").setReadOnly(true);
	this.child("tdbLineasLotesStockHacia").setReadOnly(true);

	connect(this.child("pbnBuscar"), "clicked()", _i, "buscarLotes");
  connect(this.child("pbnDeHacia"), "clicked()", _i, "deHacia");
  connect(this.child("pbnHaciaDe"), "clicked()", _i, "haciaDe");
  connect(this.child("pbnSeleccionarDe"), "clicked()", _i, "seleccionarTodoDe");
  connect(this.child("pbnDeseleccionarDe"), "clicked()", _i, "deseleccionarTodoDe");
  connect(this.child("pbnSeleccionarHacia"), "clicked()", _i, "seleccionarTodoHacia");
  connect(this.child("pbnDeseleccionarHacia"), "clicked()", _i, "deseleccionarTodoHacia");
  connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");

  switch (cursor.modeAccess()) {
		case cursor.Insert: {
			sys.setObjText(this, "fdbIdUsuario", sys.nameUser());
			break;
		}
		case cursor.Edit: {
      break;
    }
  }
  _i.refrescarTablas();
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
		case "referencia":
		case "codalmacen":
		case "deubicacion": {
			if(this.child("tdbLineasLotesStockDe").cursor().size() > 0){
				var filtro = "1 = 2";
				this.child("tdbLineasLotesStockDe").clearChecked();
				this.child("tdbLineasLotesStockDe").cursor().setMainFilter(filtro);
				this.child("tdbLineasLotesStockDe").refresh();
			}
			break;
		}
		case "haciaubicacion": {
			if(this.child("tdbLineasLotesStockHacia").cursor().size() > 0){
				var filtro = "1 = 2";
				this.child("tdbLineasLotesStockHacia").clearChecked();
				this.child("tdbLineasLotesStockHacia").cursor().setMainFilter(filtro);
				this.child("tdbLineasLotesStockHacia").refresh();
			}
			break;
		}
		default:{
			break;
		}
	}
}

function oficial_buscarLotes()
{
  var _i = this.iface;
  var cursor = this.cursor();

	var filtro = _i.dameFiltroDe();
	this.child("tdbLineasLotesStockDe").cursor().setMainFilter(filtro);

	this.child("tdbLineasLotesStockDe").refresh();
}

function oficial_seleccionarTodoDe()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var filtro = _i.dameFiltroDe();

	var q = new FLSqlQuery();
	q.setSelect("codlote");
	q.setFrom("lotesstock");
	q.setWhere(filtro);
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	while (q.next()) {
		this.child("tdbLineasLotesStockDe").setPrimaryKeyChecked(q.value("codlote"), true);
	}
	this.child("tdbLineasLotesStockDe").refresh();
}

function oficial_deseleccionarTodoDe()
{
	this.child("tdbLineasLotesStockDe").clearChecked();
	this.child("tdbLineasLotesStockDe").refresh();
}

function oficial_seleccionarTodoHacia()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var filtro = _i.dameFiltroHacia();

	var q = new FLSqlQuery();
	q.setSelect("codlote");
	q.setFrom("lotesstock");
	q.setWhere(filtro);
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	while (q.next()) {
		this.child("tdbLineasLotesStockHacia").setPrimaryKeyChecked(q.value("codlote"), true);
	}
	this.child("tdbLineasLotesStockHacia").refresh();
}

function oficial_deseleccionarTodoHacia()
{
	this.child("tdbLineasLotesStockHacia").clearChecked();
	this.child("tdbLineasLotesStockHacia").refresh();
}

function oficial_deHacia()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var haciaUbicacion = cursor.valueBuffer("haciaubicacion");
	if(!haciaUbicacion || haciaUbicacion == ""){
		MessageBox.information(sys.translate("Debe indicar una ubicaci�n nueva."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return;
	}

	var progress = 0;
	var seleccionados = this.child("tdbLineasLotesStockDe").primarysKeysChecked();

	if(seleccionados.length > 0){
		var curT = new FLSqlCursor("empresa");
		curT.transaction(false);
		AQUtil.createProgressDialog(AQUtil.translate("scripts", "Cambiando ubicaci�n de los lotes..."), seleccionados.length);

		var curTabla = new FLSqlCursor("lotesstock");

		for (var i = 0; i < seleccionados.length; i++) {
			AQUtil.setProgress(progress++);
			curTabla.select("codlote = '" + seleccionados[i] + "'");
			curTabla.first();
			curTabla.setModeAccess(curTabla.Edit);
			curTabla.refreshBuffer();

			try {
					curTabla.setValueBuffer("ubicacion", haciaUbicacion);

					if(!curTabla.commitBuffer()){
						curT.rollback();
						MessageBox.warning(sys.translate("Error al cambiar la ubicaci�n de los lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
						return;
					}
					curT.commit();
			} catch(e) {
				curT.rollback();
				MessageBox.warning(sys.translate("Error al cambiar la ubicaci�n del lote %1").arg(curTabla.valueBuffer("codlote")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return;
			}
		}
		this.child("tdbLineasLotesStockDe").cursor().setMainFilter(_i.dameFiltroDe());
		this.child("tdbLineasLotesStockHacia").cursor().setMainFilter(_i.dameFiltroHacia());
		this.child("tdbLineasLotesStockDe").refresh();
		this.child("tdbLineasLotesStockHacia").refresh();
		MessageBox.information(sys.translate("Han sido cambiados de ubicaci�n %1 lotes satisfactoriamente.").arg(seleccionados.length), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		AQUtil.destroyProgressDialog();
		_i.deseleccionarTodoDe();
	}
	else{
		MessageBox.warning(sys.translate("Debe seleccionar alguna l�nea para cambiar la ubicaci�n."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	}
}

function oficial_haciaDe()
{
	var _i = this.iface;
  var cursor = this.cursor();

	var deUbicacion = cursor.valueBuffer("deubicacion");
	if(!deUbicacion || deUbicacion == ""){
		MessageBox.information(sys.translate("Debe indicar la ubicaci�n anterior."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return;
	}

	var progress = 0;
	var seleccionados = this.child("tdbLineasLotesStockHacia").primarysKeysChecked();

	if(seleccionados.length > 0){
		var curT = new FLSqlCursor("empresa");
		curT.transaction(false);
		AQUtil.createProgressDialog(AQUtil.translate("scripts", "Cambiando ubicaci�n de los lotes..."), seleccionados.length);

		var curTabla = new FLSqlCursor("lotesstock");

		for (var i = 0; i < seleccionados.length; i++) {
			AQUtil.setProgress(progress++);
			curTabla.select("codlote = '" + seleccionados[i] + "'");
			curTabla.first();
			curTabla.setModeAccess(curTabla.Edit);
			curTabla.refreshBuffer();

			try {
					curTabla.setValueBuffer("ubicacion", deUbicacion);

					if(!curTabla.commitBuffer()){
						curT.rollback();
						MessageBox.warning(sys.translate("Error al cambiar la ubicaci�n de los lotes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
						return;
					}
					curT.commit();
			} catch(e) {
				curT.rollback();
				MessageBox.warning(sys.translate("Error al cambiar la ubicaci�n del lote %1").arg(curTabla.valueBuffer("codlote")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
				return;
			}
		}
		this.child("tdbLineasLotesStockDe").cursor().setMainFilter(_i.dameFiltroDe());
		this.child("tdbLineasLotesStockHacia").cursor().setMainFilter(_i.dameFiltroHacia());
		this.child("tdbLineasLotesStockDe").refresh();
		this.child("tdbLineasLotesStockHacia").refresh();
		MessageBox.information(sys.translate("Han sido cambiados de ubicaci�n %1 lotes satisfactoriamente.").arg(seleccionados.length), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		AQUtil.destroyProgressDialog();
		_i.deseleccionarTodoDe();
	}
	else{
		MessageBox.warning(sys.translate("Debe seleccionar alguna l�nea para cambiar la ubicaci�n."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	}
}


function oficial_refrescarTablas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtroDe = cursor.valueBuffer("filtrode");
	var filtroHacia = cursor.valueBuffer("filtrohacia");
	if (!filtroDe){
		filtroDe = "1 = 2";
	}
	if (!filtroHacia){
		filtroHacia = "1 = 2";
	}
	this.child("tdbLineasLotesStockDe").cursor().setMainFilter(filtroDe);
	this.child("tdbLineasLotesStockHacia").cursor().setMainFilter(filtroHacia);
	this.child("tdbLineasLotesStockDe").refresh();
	this.child("tdbLineasLotesStockHacia").refresh();

}

function oficial_dameFiltroDe()
{
	var cursor = this.cursor();
	var _i = this.iface;

	var filtro = "1 = 2";

	var deUbicacion = cursor.valueBuffer("deubicacion");
	var haciaUbicacion = cursor.valueBuffer("haciaubicacion");
	var codAlmacen = cursor.valueBuffer("codalmacen");
	var referencia = cursor.valueBuffer("referencia");

	if (!codAlmacen || !referencia || codAlmacen == "" || referencia  == ""){
		sys.infoMsgBox(sys.translate("Debe rellenar todos los campos para realizar la b�squeda."));
		return filtro;
	}

	if (deUbicacion && deUbicacion != "")
	{
		filtro = "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "' AND ubicacion = '" + deUbicacion + "' AND candisponible > 0";
	} else {
    filtro = "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "' AND candisponible > 0";
    if (haciaUbicacion && haciaUbicacion != "")
		filtro += " AND ubicacion <> '" + haciaUbicacion + "'";
	}
debug("filtro " + filtro);
	cursor.setValueBuffer("filtrode", filtro);
	return filtro;
}

function oficial_dameFiltroHacia()
{
	var cursor = this.cursor();
	var _i = this.iface;

	var filtro = "1 = 2";

	var referencia = cursor.valueBuffer("referencia");
	var codAlmacen = cursor.valueBuffer("codalmacen");
	var haciaUbicacion = cursor.valueBuffer("haciaubicacion");

	if (!haciaUbicacion || haciaUbicacion == ""){
		MessageBox.information(sys.translate("Debe rellenar la nueva ubicaci�n."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return filtro;
	}

	filtro = "referencia = '" + referencia + "' AND codalmacen = '" + codAlmacen + "' AND ubicacion = '" + haciaUbicacion + "'";

	cursor.setValueBuffer("filtrohacia", filtro);
	return filtro;
}

function oficial_ordenarTablas()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var oC = ["ubicacion", "codlote", "candisponible", "referencia", "articulo", "codpartida"];
	this.child("tdbLineasLotesStockDe").setOrderCols(oC);
	this.child("tdbLineasLotesStockHacia").setOrderCols(oC);

	this.child("tdbLineasLotesStockDe").refresh();
	this.child("tdbLineasLotesStockHacia").refresh();
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////