
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	var desSubcuenta_, codSubcuenta_;
	function euromoda( context ) { oficial ( context ); }
	function saldoInicial(nodo, campo) {
		return this.ctx.euromoda_saldoInicial(nodo, campo);
	}
	function ponDatosSubcuenta(cursor) {
		return this.ctx.euromoda_ponDatosSubcuenta(cursor);
	}
	function dameDesSubcuenta(nodo, campo) {
		return this.ctx.euromoda_dameDesSubcuenta(nodo, campo);
	}
	function dameCodSubcuenta(nodo, campo) {
		return this.ctx.euromoda_dameCodSubcuenta(nodo, campo);
	}
	function lanzar() {
		return this.ctx.euromoda_lanzar();
	}
	function obtenerParamInforme() {
		return this.ctx.euromoda_obtenerParamInforme();
	}
	function obtenerOrdenCliProv(nivel, cursor) {
		return this.ctx.euromoda_obtenerOrdenCliProv(nivel, cursor);
	}
	function listaSubcuentasCli(codCliente) {
		return this.ctx.euromoda_listaSubcuentasCli(codCliente);
	}
	function listaSubcuentasProv(codProveedor) {
		return this.ctx.euromoda_listaSubcuentasProv(codProveedor);
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_ponDatosSubcuenta(cursor) {
		return this.ponDatosSubcuenta(cursor);
	}
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_saldoInicial(nodo, campo)
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if (!cursor || !_i.calcularSaldoInicial) {
		_i.saldoAcumulado = 0;
		return 0;
	}
	var where = "";
	if (cursor.valueBuffer("i_co__partidas_codcliente")) {
		var listaSubcuentas = _i.listaSubcuentasCli(cursor.valueBuffer("i_co__partidas_codcliente"));
		if (!listaSubcuentas) {
			return false;
		}
		where = " AND p.codcliente = '" + cursor.valueBuffer("i_co__partidas_codcliente") + "' AND p.codsubcuenta IN (" + listaSubcuentas + ")";
	} else if (cursor.valueBuffer("i_co__partidas_codproveedor")) {
		var listaSubcuentas = _i.listaSubcuentasProv(cursor.valueBuffer("i_co__partidas_codproveedor"));
		if (!listaSubcuentas) {
			return false;
		}
		where = "  AND p.codproveedor = '" + cursor.valueBuffer("i_co__partidas_codproveedor") + "' AND p.codsubcuenta IN (" + listaSubcuentas + ")";
	} else if (cursor.valueBuffer("i_co__partidas_codactivo")) {
		var codSubcuenta = nodo.attributeValue("co_subcuentas.codsubcuenta");
		where = " AND p.codsubcuenta = '" + codSubcuenta + "' AND p.codactivo = '" + cursor.valueBuffer("i_co__partidas_codactivo") + "'";
	} else {
		var codSubcuenta = nodo.attributeValue("co_subcuentas.codsubcuenta");
		where = " AND p.codsubcuenta = '" + codSubcuenta + "'";
	}
	var fecha = nodo.attributeValue("co_asientos.fecha");
	var saldoInicial = AQUtil.sqlSelect("co_partidas p INNER JOIN co_asientos a ON p.idasiento = a.idasiento", "SUM(debe) - SUM(haber)", "a.fecha < '" + fecha + "'" + where, "co_partidas,co_asientos");
	if (!saldoInicial) {
		saldoInicial = 0;
	}
	_i.saldoAcumulado = saldoInicial;
	return saldoInicial;
}

function euromoda_listaSubcuentasCli(codCliente)
{
	var codGrupoCliente = AQUtil.sqlSelect("clientes", "codgrupocontablecli", "codcliente = '" + codCliente + "'");
	if (!codGrupoCliente) {
		MessageBox.warning(sys.translate("No se ha encontrado el grupo contable de cliente asociado al c�digo de cliente %1").arg(codCliente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	var listaSubcuentas = formRecordclientes.iface.pub_dameListaSubcuentas(codGrupoCliente);
debug("lista " + listaSubcuentas);
	if (!listaSubcuentas) {
		MessageBox.warning(sys.translate("No se ha encontrado la lista de subcuentas asociada al grupo contable de clientes %1").arg(codGrupoCliente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	return listaSubcuentas;
}

function euromoda_listaSubcuentasProv(codProveedor)
{
	var codGrupoProv = AQUtil.sqlSelect("proveedores", "codgrupocontableprov", "codproveedor = '" + codProveedor + "'");
	if (!codGrupoProv) {
		MessageBox.warning(sys.translate("No se ha encontrado el grupo contable de proveedor asociado al c�digo de proveedor %1").arg(codProveedor), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	var listaSubcuentas = formRecordproveedores.iface.pub_dameListaSubcuentas(codGrupoProv);
debug("lista " + listaSubcuentas);
	if (!listaSubcuentas) {
		MessageBox.warning(sys.translate("No se ha encontrado la lista de subcuentas asociada al grupo contable de proveedores %1").arg(codGrupoProv), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
		return false;
	}
	return listaSubcuentas;
}

function euromoda_ponDatosSubcuenta(cursor)
{
	var _i = this.iface;
	
	_i.desSubcuenta_ = false;
	if (cursor.valueBuffer("i_co__partidas_codcliente")) {
		_i.desSubcuenta_ = AQUtil.sqlSelect("clientes", "nombre", "codcliente = '" + cursor.valueBuffer("i_co__partidas_codcliente") + "'");
		_i.codSubcuenta_ = cursor.valueBuffer("i_co__partidas_codcliente");
	}
	if (cursor.valueBuffer("i_co__partidas_codproveedor")) {
		_i.desSubcuenta_ = AQUtil.sqlSelect("proveedores", "nombre", "codproveedor = '" + cursor.valueBuffer("i_co__partidas_codproveedor") + "'");
		_i.codSubcuenta_ = cursor.valueBuffer("i_co__partidas_codproveedor");
	}
	if (cursor.valueBuffer("i_co__partidas_codactivo")) {
		_i.desSubcuenta_ = AQUtil.sqlSelect("co_amortizaciones", "elemento", "codamortizacion = '" + cursor.valueBuffer("i_co__partidas_codactivo") + "'");
		_i.codSubcuenta_ = cursor.valueBuffer("i_co__partidas_codactivo");
	}
}

function euromoda_dameDesSubcuenta(nodo, campo)
{
	var _i = this.iface;
	
	if (_i.desSubcuenta_) {
		return _i.desSubcuenta_;
	} else {
		return nodo.attributeValue("co_subcuentas.descripcion");
	}
}

function euromoda_dameCodSubcuenta(nodo, campo)
{
	var _i = this.iface;
	
	if (_i.codSubcuenta_) {
		return _i.codSubcuenta_;
	} else {
		return nodo.attributeValue("co_subcuentas.codsubcuenta");
	}
}

function euromoda_lanzar()
{
	var _i = this.iface;
	var cursor:FLSqlCursor = this.cursor();
	if (!cursor.isValid()) {
		return;
	}
	_i.ponDatosSubcuenta(cursor);
	_i.ultimaSubcuenta = 0;
	_i.calcularSaldoInicial = cursor.valueBuffer("saldoinicial");
	
	var pI = this.iface.obtenerParamInforme();
	if (!pI) {
		return;
	}
	flcontinfo.iface.pub_lanzarInforme(cursor, pI.nombreInforme, pI.nombreReport, pI.orderBy, "", pI.masWhere, cursor.valueBuffer("id"));
}

function euromoda_obtenerParamInforme()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var seleccion= cursor.valueBuffer("id");
	if (!seleccion) {
		return false;
	}
	var paramInforme = flfactinfo.iface.pub_dameParamInforme();
	paramInforme.nombreInforme = cursor.action();
	paramInforme.nombreReport = cursor.action();
	
	if (cursor.valueBuffer("i_co__partidas_codcliente")) {
		var listaSubcuentas = _i.listaSubcuentasCli(cursor.valueBuffer("i_co__partidas_codcliente"));
		if (!listaSubcuentas) {
			return false;
		}
		paramInforme.orderBy = "co_partidas.codcliente";
		paramInforme.masWhere = " AND co_partidas.codsubcuenta IN (" + listaSubcuentas + ")";
		paramInforme.nombreInforme = "co_i_mayor_cli";
	} else if (cursor.valueBuffer("i_co__partidas_codproveedor")) {
		var listaSubcuentas = _i.listaSubcuentasProv(cursor.valueBuffer("i_co__partidas_codproveedor"));
		if (!listaSubcuentas) {
			return false;
		}
		paramInforme.orderBy = "co_partidas.codproveedor";
		paramInforme.masWhere = " AND co_partidas.codsubcuenta IN (" + listaSubcuentas + ")";
		paramInforme.nombreInforme = "co_i_mayor_prov";
	} else {
		paramInforme.masWhere = false;
		paramInforme.orderBy = "co_subcuentas.codsubcuenta";
	}
	var o;
	for (var i= 1; i < 3; i++) {
		o = _i.obtenerOrdenCliProv(i, cursor);
		if (o) {
			paramInforme.orderBy += paramInforme.orderBy == "" ? "" : ", ";
			paramInforme.orderBy += o;
		}
	}
	
	return paramInforme;
}

function euromoda_obtenerOrdenCliProv(nivel, cursor)
{
	var ret = "";
	var orden = cursor.valueBuffer("orden" + nivel.toString());

	var descAsc = "";
	var tipoOrden = cursor.valueBuffer("tipoorden" + nivel.toString());
	if (tipoOrden == "Descendente") {
		descAsc = " DESC";
	}

	switch (orden) {
		case "Asiento": {
// 			ret += ret == "" ? "" : ", ";
			ret += "co_asientos.numero " + descAsc;
			break;
		}
		case "Fecha": {
// 			ret += ret == "" ? "" : ", ";
			ret += "co_asientos.fecha " + descAsc + ", co_asientos.numero";
			break;
		}
	}

	return ret;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
