
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends pgc2008 {
	function euromoda( context ) { pgc2008 ( context ); }
	function asientoCierre() {
		return this.ctx.euromoda_asientoCierre()
	}
	function asientoApertura(idAsientoCierre, ejNuevo) {
		return this.ctx.euromoda_asientoApertura(idAsientoCierre, ejNuevo);
	}
	function comprobarSaldos() {
		return this.ctx.euromoda_comprobarSaldos();
	}
	function asientoPyG() {
		return this.ctx.euromoda_asientoPyG();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
/// Agrupa saldos por cliente, proveedor, cuenta, activo
function euromoda_asientoCierre()
{
// 	return true;
	
	var util:FLUtil = new FLUtil();
	var cursor:FLSqlCursor = this.cursor();
	
	var codEjercicio:String = cursor.valueBuffer("codejercicio");
	var planContable:String = util.sqlSelect("ejercicios", "plancontable", "codejercicio = '" + codEjercicio + "'");
	
	if (planContable != "08")
		return this.iface.__asientoCierre();


	var curAsiento:FLSqlCursor = new FLSqlCursor("co_asientos");
	curAsiento.setForwardOnly(true);
	curAsiento.setModeAccess(curAsiento.Insert);
	curAsiento.refreshBuffer();
	curAsiento.setValueBuffer("numero", 0);
	curAsiento.setValueBuffer("fecha", this.child("dedFecha").date);
	curAsiento.setValueBuffer("codejercicio", cursor.valueBuffer("codejercicio"));
	curAsiento.setValueBuffer("concepto", util.translate("scripts", "Asiento de cierre de ejercicio ") + cursor.valueBuffer("nombre"));

	if (!curAsiento.commitBuffer())
			return false;

	var idAsiento:Number = curAsiento.valueBuffer("idasiento");
	var curPartida:FLSqlCursor = new FLSqlCursor("co_partidas");
	curPartida.setForwardOnly(true);
	var debe:Number = 0;
	var haber:Number = 0;
	var totalDebe:Number = 0;
	var totalHaber:Number = 0;
	var paso:Number = 0;

	/* Lo quitamos porque a estas alturas todo lo que tiene saldo es porque hay que incluirlo en el asiento de cierre
	var q:FLSqlQuery = new FLSqlQuery();
	q.setForwardOnly(true);
	q.setTablesList("co_cuentascb");
	q.setFrom("co_cuentascb");
	q.setSelect("codcuenta");
	q.setWhere("codbalance like 'A-%' or codbalance like 'P-%' order by codcuenta");
	
	if (!q.exec())
		return false;
*/
	
	//while(q.next()) {
		var qSC:FLSqlQuery = new FLSqlQuery();
		qSC.setTablesList("co_subcuentas,co_cuentas");
		qSC.setFrom("co_subcuentas s INNER JOIN co_cuentas c on s.idcuenta=c.idcuenta INNER JOIN co_partidas p ON s.idsubcuenta = p.idsubcuenta");
		qSC.setSelect("SUM(p.debe-p.haber), s.idsubcuenta, s.codsubcuenta, p.codcliente, p.codproveedor, p.codcuentabanco, p.codactivo");
		qSC.setWhere("s.codejercicio = '" + codEjercicio + "' GROUP BY s.idsubcuenta, s.codsubcuenta, p.codcliente, p.codproveedor, p.codcuentabanco, p.codactivo HAVING SUM(p.debe-p.haber) <> 0 ORDER BY s.idsubcuenta, s.codsubcuenta, p.codcliente, p.codproveedor, p.codcuentabanco, p.codactivo ");
		if (!qSC.exec()) {
			return false;
		}
		util.createProgressDialog( util.translate( "scripts", "Creando asiento de cierre..." ), qSC.size() );
		util.setProgress(1);
	
		debug(qSC.sql());
		while(qSC.next()) {
		
			
			
			if (Math.abs(parseFloat(qSC.value(0))) < 0.0001) {
				continue;
			}
			if (parseFloat(qSC.value(0)) > 0) {
				debe = 0;
				haber = parseFloat(qSC.value(0));
			} else {
				debe = 0 - parseFloat(qSC.value(0));
				haber = 0;
			}

			totalDebe += debe;
			totalHaber += haber;

			curPartida.setModeAccess(curPartida.Insert);
			curPartida.refreshBuffer();
			curPartida.setValueBuffer("concepto", util.translate("scripts", "Asiento de cierre de ejercicio ") +
			cursor.valueBuffer("nombre"));
			curPartida.setValueBuffer("idsubcuenta", qSC.value(1));
			curPartida.setValueBuffer("codsubcuenta", qSC.value(2));
			curPartida.setValueBuffer("idasiento", idAsiento);
			curPartida.setValueBuffer("debe", debe);
			curPartida.setValueBuffer("haber", haber);
			curPartida.setValueBuffer("coddivisa", this.iface.divisaEmpresa);
			curPartida.setValueBuffer("tasaconv", 1);
			curPartida.setValueBuffer("debeME", 0);
			curPartida.setValueBuffer("haberME", 0);
			
			curPartida.setValueBuffer("codcliente", qSC.value("p.codcliente"));
			curPartida.setValueBuffer("codproveedor", qSC.value("p.codproveedor"));
			curPartida.setValueBuffer("codcuentabanco", qSC.value("p.codcuentabanco"));
			curPartida.setValueBuffer("codactivo", qSC.value("p.codactivo"));

			if (!curPartida.commitBuffer()) {
					util.destroyProgressDialog();
					return false;
			}
			util.setProgress(paso++);
		}
		//util.setProgress(paso++);
	//}
debug("totalDebe " + totalDebe);
debug("totalHaber " + totalHaber);
	if (Math.abs(parseFloat(totalDebe) -  parseFloat(totalHaber)) > 0.01) {
			MessageBox.critical(util.translate("scripts",
					"Asiento de cierre: los totales de debe y haber no coinciden\n" +
					"DEBE : " + Math.round(parseFloat(totalDebe)) + "  HABER : " + Math.round(parseFloat(totalHaber)) ),
						MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton);
			util.destroyProgressDialog();
			return false;
	}
	totalDebe = AQUtil.roundFieldValue(totalDebe, "co_asientos", "importe");
	curAsiento.select("idasiento = " + idAsiento);
	curAsiento.first();
	curAsiento.setModeAccess(curAsiento.Edit);
	curAsiento.refreshBuffer();
	curAsiento.setValueBuffer("importe", totalDebe);
	curAsiento.setValueBuffer("editable", false);
	if (!curAsiento.commitBuffer()) {
		return false;
	}

	cursor.setValueBuffer("estado", "CERRADO");
	
		
	cursor.setValueBuffer("idasientocierre", idAsiento);
	util.destroyProgressDialog();
	return true;
}

function euromoda_asientoApertura(idAsientoCierre, ejNuevo)
{
	var util:FLUtil = new FLUtil();

	if (ejNuevo == "")
		return false;

	if (!util.sqlSelect("co_subcuentas", "idsubcuenta", "codejercicio = '" + ejNuevo + "'"))
		return false;

	var curAsiento:FLSqlCursor = new FLSqlCursor("co_asientos");
	curAsiento.setForwardOnly(true);
	var fechaAsiento:String = util.sqlSelect("ejercicios", "fechainicio", "codejercicio = '" + ejNuevo + "'");
	var nombreEjercicio:String = util.sqlSelect("ejercicios", "nombre", "codejercicio = '" + ejNuevo + "'");

	curAsiento.setModeAccess(curAsiento.Insert);
	curAsiento.refreshBuffer();
	curAsiento.setValueBuffer("numero", 0);
	curAsiento.setValueBuffer("fecha", fechaAsiento);
	curAsiento.setValueBuffer("codejercicio", ejNuevo);
	curAsiento.setValueBuffer("concepto", sys.translate("Asiento de apertura de ejercicio ") + nombreEjercicio);

	if (!curAsiento.commitBuffer())
		return false;

	var idAsiento:Number = curAsiento.valueBuffer("idasiento");
	var qryCierre:FLSqlQuery = new FLSqlQuery();
	qryCierre.setForwardOnly(true);
	with (qryCierre) {
		setTablesList("co_partidas");
		setSelect("codsubcuenta, debe, haber, coddivisa, tasaconv, debeME, haberME, codcliente, codproveedor, codcuentabanco, codactivo");
		setFrom("co_partidas");
		setWhere("idasiento = " + idAsientoCierre);
	}
	if (!qryCierre.exec())
		return false;

	util.createProgressDialog( util.translate( "scripts", "Creando asiento de apertura..." ), qryCierre.size() );
	util.setProgress(1);

	var curApertura:FLSqlCursor = new FLSqlCursor("co_partidas");
	curApertura.setForwardOnly(true);
	var paso:Number = 0;
	var idSubcuentaAp:String;
	var totalDebe = 0;
	while (qryCierre.next()) {
		idSubcuentaAp = util.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + qryCierre.value("codsubcuenta") + "' AND codejercicio = '" + ejNuevo + "'");
		if (!idSubcuentaAp) {
			util.destroyProgressDialog();
			var res:Number = MessageBox.warning(util.translate("scripts", "No existe la subcuenta %1 en el ejercicio %2.\n�Desea crearla?").arg(qryCierre.value("codsubcuenta")).arg(ejNuevo), MessageBox.Yes, MessageBox.Cancel);
			if (res != MessageBox.Yes)
				return false;
			idSubcuentaAp = this.iface.crearSubcuentaApertura(qryCierre.value("codsubcuenta"), ejNuevo);
			if (!idSubcuentaAp)
				return false;
		}

		curApertura.setModeAccess(curApertura.Insert);
		curApertura.refreshBuffer();
		curApertura.setValueBuffer("concepto", util.translate("scripts", "Asiento de apertura de ejercicio ") + nombreEjercicio);
		curApertura.setValueBuffer("idsubcuenta", idSubcuentaAp);
		curApertura.setValueBuffer("codsubcuenta", qryCierre.value("codsubcuenta"));
		curApertura.setValueBuffer("idasiento", idAsiento);
		curApertura.setValueBuffer("debe", qryCierre.value("haber"));
		curApertura.setValueBuffer("haber", qryCierre.value("debe"));
		curApertura.setValueBuffer("coddivisa", qryCierre.value("coddivisa"));
		curApertura.setValueBuffer("tasaconv", qryCierre.value("tasaconv"));
		curApertura.setValueBuffer("debeME", qryCierre.value("haberME"));
		curApertura.setValueBuffer("haberME", qryCierre.value("debeME"));
		curApertura.setValueBuffer("codcliente", qryCierre.value("codcliente"));
		curApertura.setValueBuffer("codproveedor", qryCierre.value("codproveedor"));
		curApertura.setValueBuffer("codcuentabanco", qryCierre.value("codcuentabanco"));
		curApertura.setValueBuffer("codactivo", qryCierre.value("codactivo"));
		util.setProgress(paso++);

		if (!curApertura.commitBuffer()) {
			util.destroyProgressDialog();
			return false;
		}
		totalDebe += parseFloat(qryCierre.value("haber"));
	}

	if (!util.sqlUpdate("ejercicios", "idasientoapertura", idAsiento, "codejercicio = '" + ejNuevo + "'")) {
		util.destroyProgressDialog();
		return false;
	}

	totalDebe = AQUtil.roundFieldValue(totalDebe, "co_asientos", "importe");
	curAsiento.select("idasiento = " + idAsiento);
	curAsiento.first();
	curAsiento.setModeAccess(curAsiento.Edit);
	curAsiento.refreshBuffer();
	curAsiento.setValueBuffer("importe", totalDebe);
	curAsiento.setValueBuffer("editable", false);
	if (!curAsiento.commitBuffer()) {
		return false;
	}

	util.destroyProgressDialog();
	return true;
}

function euromoda_comprobarSaldos()
{
	var util:FLUtil = new FLUtil;
	
	var qrySaldos:FLSqlQuery = new FLSqlQuery;
	qrySaldos.setTablesList("co_subcuentas");
	qrySaldos.setSelect("idsubcuenta");
	qrySaldos.setFrom("co_subcuentas");
	qrySaldos.setWhere("codejercicio = '" + this.cursor().valueBuffer("codejercicio") + "'");
	try { qrySaldos.setForwardOnly( true ); } catch (e) {}
	if (!qrySaldos.exec())
		return false;
		
	util.createProgressDialog( util.translate( "scripts", "Revisando saldos" ), qrySaldos.size() );
	var progress:Number = 0;
	while (qrySaldos.next()) {
		util.setProgress(progress++);
		if (!flcontppal.iface.pub_calcularSaldo(qrySaldos.value(0), true)) {
			util.destroyProgressDialog();
			return false;
		}
	}
	util.destroyProgressDialog();
	return true;
}

function euromoda_asientoPyG()
{
	var _i = this.iface;
	flcontppal.iface.enCierre_ = true;
	return _i.__asientoPyG();
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

