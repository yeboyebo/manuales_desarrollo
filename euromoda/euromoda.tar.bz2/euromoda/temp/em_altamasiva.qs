/***************************************************************************
                 em_altamasiva.qs  -  description
                             -------------------
    begin                : mie nov 23 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx: Object;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    return this.ctx.interna_init();
  }
  function calculateField(fN)
  {
    return this.ctx.interna_calculateField(fN);
  }
  function validateForm()
  {
    return this.ctx.interna_validateForm();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
	var refCoordinado_;
	var modificado_;
	var tblDibujos_;
	var modo_;
	var cxTx_;
	var curDibujo_;
	var tblCostes_;
	var curArticulo_;
  function oficial(context)
  {
    interna(context);
  }
  function calculaDibujos(soloNuevos)
  {
    return this.ctx.oficial_calculaDibujos(soloNuevos);
  }
  function pbnCalcularNuevos_clicked()
  {
    return this.ctx.oficial_pbnCalcularNuevos_clicked();
  }
  function pbnCalcular_clicked()
  {
    return this.ctx.oficial_pbnCalcular_clicked();
  }
  function creaAltas()
  {
    return this.ctx.oficial_creaAltas();
  }
  function seleccionarTodo()
  {
    return this.ctx.oficial_seleccionarTodo();
  }
  function seleccionarNuevos()
  {
    return this.ctx.oficial_seleccionarNuevos();
  }
  function deseleccionarTodo()
  {
    return this.ctx.oficial_deseleccionarTodo();
  }
  function creaArticulo(oParam)
  {
    return this.ctx.oficial_creaArticulo(oParam);
  }
  function creaSubtablaColeccion(oParam)
  {
  	return this.ctx.oficial_creaSubtablaColeccion(oParam);
  }
  function creaFichaTecnica(curArticulo, oParam)
  {
    return this.ctx.oficial_creaFichaTecnica(curArticulo, oParam);
  }
  function plantillaProducto(curArticulo)
  {
    return this.ctx.oficial_plantillaProducto(curArticulo);
  }
  function plantillaDibujo(curArticulo, oPlantilla)
  {
    return this.ctx.oficial_plantillaDibujo(curArticulo, oPlantilla);
  }
  function valoresAPlantilla(curArticulo, oPlantilla)
  {
    return this.ctx.oficial_valoresAPlantilla(curArticulo, oPlantilla);
  }
  function filtraArticulos()
  {
    return this.ctx.oficial_filtraArticulos();
  }
  function ordenTablaArticulos()
  {
    return this.ctx.oficial_ordenTablaArticulos();
  }
  function crearLineaColeccion(referencia, codColeccion, descColeccion)
  {
    return this.ctx.oficial_crearLineaColeccion(referencia, codColeccion, descColeccion);
  }
  function habilitarBoton()
  {
    return this.ctx.oficial_habilitarBoton();
  }
  function bufferChanged(fN)
  {
    return this.ctx.oficial_bufferChanged(fN);
  }
  function habilitaPorModo()
  {
    return this.ctx.oficial_habilitaPorModo();
  }
  function datosComunesProducto(codSubfamiliaProd, codColorProd)
  {
    return this.ctx.oficial_datosComunesProducto(codSubfamiliaProd, codColorProd);
  }
  function pushButtonCancel_clicked()
  {
    return this.ctx.oficial_pushButtonCancel_clicked();
  }
  function tdbArticulos_bufferCommited()
  {
    return this.ctx.oficial_tdbArticulos_bufferCommited();
  }
  function guardaAltaMasiva(curFT)
  {
    return this.ctx.oficial_guardaAltaMasiva(curFT);
  }
  function filtrarTablaDibujos(tipo)
  {
  	return this.ctx.oficial_filtrarTablaDibujos(tipo);
  }
  function pbnSelectDibujos_clicked()
  {
  	return this.ctx.oficial_pbnSelectDibujos_clicked();
  }
  /*function marcarSeleccionadosLista()
  {
  	return this.ctx.oficial_marcarSeleccionadosLista();
  }*/
  function guardarListaDibujos()
  {
  	return this.ctx.oficial_guardarListaDibujos();
  }
  function dameListaDibujos(listaDibujos)
  {
  	return this.ctx.oficial_dameListaDibujos(listaDibujos);
  }
  function dameListaDisenos(listaDisenos)
  {
  	return this.ctx.oficial_dameListaDisenos(listaDisenos);
  }
  function formateaStringFiltro(cadena)
  {
  	return this.ctx.oficial_formateaStringFiltro(cadena);
  }
  function marcarSeleccionados(listaSel)
  {
	return this.ctx.oficial_marcarSeleccionados(listaSel);
  }

	function seleccionarTodoArt() {
		return this.ctx.oficial_seleccionarTodoArt();
	}
	function deseleccionarTodoArt() {
		return this.ctx.oficial_deseleccionarTodoArt();
	}
	function tbnGenerarFT_clicked() {
		return this.ctx.oficial_tbnGenerarFT_clicked();
	}
	function pbnEnRevision_clicked() {
		return this.ctx.oficial_pbnEnRevision_clicked();
	}
	function pbnEnProduccion_clicked() {
		return this.ctx.oficial_pbnEnProduccion_clicked();
	}
	function liberaUsuario() {
		return this.ctx.oficial_liberaUsuario();
	}
	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}
	function abreCxTx() {
		return this.ctx.oficial_abreCxTx();
	}

	function cargaDatosDibujos() {
		return this.ctx.oficial_cargaDatosDibujos();
	}
	function dameTablaDibujos() {
		return this.ctx.oficial_dameTablaDibujos();
	}
	function creaSubtablaDibujos() {
		return this.ctx.oficial_creaSubtablaDibujos();
	}
	function obtenerDibujosSeleccionados() {
		return this.ctx.oficial_obtenerDibujosSeleccionados();
	}
	function editaDibujo() {
		return this.ctx.oficial_editaDibujo();
	}
	function commitDibujos() {
		return this.ctx.oficial_commitDibujos();
	}
	function borrarTabla() {
		return this.ctx.oficial_borrarTabla();
	}
	function subirOrden() {
		return this.ctx.oficial_subirOrden();
	}
	function bajarOrden() {
		return this.ctx.oficial_bajarOrden();
	}
	function reordenar() {
		return this.ctx.oficial_reordenar();
	}
	function currentChangedFunction() {
		return this.ctx.oficial_currentChangedFunction();
	}
	function selectedFunction(pk,sel) {
		return this.ctx.oficial_selectedFunction(pk,sel);
	}
	function intercambiarOrden(cursor, row1, direccion) {
		return this.ctx.oficial_intercambiarOrden(cursor, row1, direccion);
	}
	function cargaDatosCostes() {
		return this.ctx.oficial_cargaDatosCostes();
	}
	function dameTablaCostes() {
		return this.ctx.oficial_dameTablaCostes();
	}
  	function pbnTodosCostes_clicked() {
  		return this.ctx.oficial_pbnTodosCostes_clicked();
  	}
	function pbnNingunoCostes_clicked() {
  		return this.ctx.oficial_pbnNingunoCostes_clicked();
  	}
	function tbnEmRegenerarCostes_clicked() {
  		return this.ctx.oficial_tbnEmRegenerarCostes_clicked();
  	}
	function tbnEmCargarCostes_clicked() {
  		return this.ctx.oficial_tbnEmCargarCostes_clicked();
  	}
	function pbnEditarTama_clicked() {
  		return this.ctx.oficial_pbnEditarTama_clicked();
  	}
	function pbnEditarPlantilla_clicked() {
  		return this.ctx.oficial_pbnEditarPlantilla_clicked();
  	}
  	function editarArticulo() {
  		return this.ctx.oficial_editarArticulo();
  	}
  	function refrescaTabla() {
  		return this.ctx.oficial_refrescaTabla();
  	}
  	function tbwArticulo_currentChanged(nombreTab) {
  		return this.ctx.oficial_tbwArticulo_currentChanged(nombreTab);
  	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	if (!_i.abreCxTx()) {
		return false;
	}
	var cursor = this.cursor();

	_i.curArticulo_ = new FLSqlCursor("articulos");
	connect(_i.curArticulo_, "commited()", _i, "refrescaTabla");

	cursor.setAskForCancelChanges(false);
	
	_i.modificado_ = false;

	connect(this.child("pbnCalcular"), "clicked()", _i, "pbnCalcular_clicked");
	connect(this.child("pbnCalcularNuevos"), "clicked()", _i, "pbnCalcularNuevos_clicked");
	connect(this.child("pbnCrear"), "clicked()", _i, "creaAltas");
	connect(this.child("pbnSeleccionar"), "clicked()", _i, "seleccionarTodo");
	connect(this.child("pbnSelNuevos"), "clicked()", _i, "seleccionarNuevos");
	connect(this.child("tdbArticulos").cursor(), "bufferCommited()", _i, "tdbArticulos_bufferCommited");
	connect(this.child("pbnBorrar"), "clicked()", _i, "borrarTabla");
	connect(this.child("tbwArticulo"), "currentChanged(QString)", _i, "tbwArticulo_currentChanged()");
	if(cursor.modeAccess() == cursor.Insert) {
		this.child("tdbArticulos").cursor().setAction("em_fichatecnica");
	}

	connect(this.child("pbnDeseleccionar"), "clicked()", _i, "deseleccionarTodo");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");

	disconnect(this.child("pushButtonCancel"), "clicked()", this.obj(), "reject()");
	connect(this.child("pushButtonCancel"), "clicked()", _i, "pushButtonCancel_clicked");

	connect(this.child("pbnSelectDibujos"),"clicked()", _i, "pbnSelectDibujos_clicked");


	connect(this.child("pbnSeleccionarArt"), "clicked()", _i, "seleccionarTodoArt");
	
	connect(this.child("pbnDeseleccionarArt"), "clicked()", _i, "deseleccionarTodoArt");

	connect(this.child("tbnGenerarFT"), "clicked()", _i, "tbnGenerarFT_clicked");

	connect(this.child("pbnEnRevision"), "clicked()", _i, "pbnEnRevision_clicked");
	connect(this.child("pbnEnProduccion"), "clicked()", _i, "pbnEnProduccion_clicked");
	connect(this.child("tbnSubir"),"clicked()", _i, "subirOrden");
	connect(this.child("tbnBajar"),"clicked()", _i, "bajarOrden");
	connect(this.child("tbnReordenar"),"clicked()", _i, "reordenar");


	connect(this.child("pbnTodosCostes"),"clicked()", _i, "pbnTodosCostes_clicked");
	connect(this.child("pbnNingunoCostes"),"clicked()", _i, "pbnNingunoCostes_clicked");
	connect(this.child("tbnEmRegenerarCostes"),"clicked()", _i, "tbnEmRegenerarCostes_clicked");
	connect(this.child("tbnEmCargarCostes"),"clicked()", _i, "tbnEmCargarCostes_clicked");
	connect(this.child("pbnEditarTama"),"clicked()", _i, "pbnEditarTama_clicked");
	connect(this.child("pbnEditarPlantilla"),"clicked()", _i, "pbnEditarPlantilla_clicked");
	//this.child("pbnEditarPlantilla").close();

	if(this.child("pushButtonAccept")) {
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
		connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	}

	_i.tblDibujos_ = false;
	_i.curDibujo_ = new FLSqlCursor("em_dibujos");

	var tdbLineasAltaMasiva = this.child("tdbLineasAltaMasiva");
	var dtbLineasAM = this.mainWidget().child("tdbLineasAltaMasiva").tableRecords();
	dtbLineasAM.setSort(["idlinea ASC"]);
	dtbLineasAM.refresh(AQS.RefreshData);

	_i.cargaDatosDibujos();


	_i.marcarSeleccionados();

	_i.habilitarBoton();
	_i.habilitaPorModo();
	_i.ordenTablaArticulos();
	_i.filtraArticulos();
	_i.tblCostes_ = false;
	_i.cargaDatosCostes();


}

function interna_calculateField(fN)
{
  return 0;
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(cursor.valueBuffer("modo") == "alta") {
		_i.guardarListaDibujos();
	}

  	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
  case "coddiseno": {

  	if(cursor.valueBuffer("coddiseno") && cursor.valueBuffer("coddiseno") != "") {
  		this.child("fdbCodDibujo").setDisabled(true);
  	}
  	else {
  		this.child("fdbCodDibujo").setDisabled(false);
  	}

  	 if (!AQSql.del("em_lineasaltamasiva", "idalta = '" + cursor.valueBuffer("idalta") + "'")) {
        return false;
      }
      this.child("tdbLineasAltaMasiva").refresh();
      _i.habilitarBoton();
      break;
  }
  case "coddibujoem": {
  	if(cursor.valueBuffer("coddibujoem") && cursor.valueBuffer("coddibujoem") != "") {
  		this.child("fdbCodDiseno").setDisabled(true);
  	}
  	else {
  		this.child("fdbCodDiseno").setDisabled(false);
  	}
  	
      //      var curD = new FLSqlCursor("em_dibujos");
      //      curD.select("coddibujoem = '" + cursor.valueBuffer("coddibujoem") + "'");
      //      if(curD.first()){
      //        this.child("fdbDesDibujo").setValue(curD.valueBuffer("descripcion"));
      //      }
 	  //sys.setObjText(this, "fdbCodDibujoHasta", cursor.valueBuffer("coddibujoem"));
      
      if (!AQSql.del("em_lineasaltamasiva", "idalta = '" + cursor.valueBuffer("idalta") + "'")) {
        return false;
      }
      this.child("tdbLineasAltaMasiva").refresh();
      _i.habilitarBoton();
      break;
    }
    //    case "codcoleccionem": {
    //      var curD = new FLSqlCursor("em_colecciones");
    //      curD.select("codcoleccionem = '" + cursor.valueBuffer("codcoleccionem") + "'");
    //      if(curD.first()){
    //        this.child("fdbDesColeccion").setValue(curD.valueBuffer("descripcion"));
    //      }
    //       break;
    //    }
  default: {
      return;
    }
  }
}
function oficial_pbnCalcular_clicked()
{
	var _i = this.iface;
	_i.calculaDibujos(false);
}

function oficial_pbnCalcularNuevos_clicked()
{
	var _i = this.iface;
	_i.calculaDibujos(true);
}

function oficial_calculaDibujos(soloNuevos)
{
  var _i = this.iface;

   var cursor = this.cursor();

  if(!cursor.valueBuffer("codcoleccionem") || cursor.valueBuffer("codcoleccionem") == "") {
  		sys.warnMsgBox(sys.translate("Debe establecer antes la colecci�n"));
		return false;
  }

  _i.guardarListaDibujos();

  _i.modificado_ = true;
   
  var aDibujos = _i.obtenerDibujosSeleccionados();
  
  if (!aDibujos || aDibujos.length == 0) {
    MessageBox.information(sys.translate("Debe seleccionar el/los dibujo/s para calcular los posibles colores y tama�os."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  
  
  // Simula un commit sobre el registro altamasiva en el que se crean las lineas.
  if (cursor.modeAccess() == cursor.Insert) {
    if (!this.child("tdbLineasAltaMasiva").cursor().commitBufferCursorRelation()) {
      return false;
    }
  }
  
  

  if (!AQSql.del("em_lineasaltamasiva", "idalta = '" + cursor.valueBuffer("idalta") + "'")) {
    return false;
  }
  
  var curLAM = new FLSqlCursor("em_lineasaltamasiva");
  var q = new FLSqlQuery;

  q.setSelect("c.descripcion,c.codcolorem,s.descripcion, t.descripcion, dts.codsubfamilia, dts.codtamanoem, s.codfamilia, s.em_tipoarticulo, d.descripcion");
  q.setFrom("em_dibujos d INNER JOIN em_dibujoscolor dc ON d.coddibujoem = dc.coddibujoem INNER JOIN em_colores c ON c.codcolorem = dc.codcolorem INNER JOIN em_dibujostamsub dts ON d.coddibujoem = dts.coddibujoem INNER JOIN subfamilias s ON s.codsubfamilia = dts.codsubfamilia INNER JOIN em_tamanos t ON t.codtamanoem = dts.codtamanoem INNER JOIN em_tamanossubfam ts ON (dts.codsubfamilia = ts.codsubfamilia AND dts.codtamanoem = ts.codtamanoem)");

  AQUtil.createProgressDialog(sys.translate("Calculando colores y tama�os..."), aDibujos.length);
  var p = 0;
  var dibujosSinColores = "";
  for(var i=0;i<aDibujos.length;i++) {
  	AQUtil.setProgress(p++);

	  q.setWhere("d.coddibujoem = '" + aDibujos[i] + "' ORDER BY dts.codsubfamilia, c.codcolorem, ts.orden");
	  
	  q.setForwardOnly(true);
	  if (!q.exec()) {
	    return false;
	  }
	  var codSubFamiliaPrev = false, codTamanoPrev = false;
		var codSubFamilia, codTamano, ref, codColor;
	  if (q.size() > 0) {
	    
	    while (q.next()) {
				codSubfamilia = q.value("dts.codsubfamilia");
				codTamano = q.value("dts.codtamanoem");
				codColor = q.value("c.codcolorem");
	// 			if (q.value("s.em_tipoarticulo") != "Producto") {
	// 				if (!flfactalma.iface.pub_esFamiliaEstampado(q.value("s.codfamilia"))) {
	// 					codColor = "";
	// 					if (codSubfamilia == codSubfamiliaPrev && codTamano == codTamanoPrev) {
	// 						continue; /// Para art�culos que nos son producto ni tejido se crea una �nica combinaci�n de color, sin indicar el color
	// 					}
	// 				}
	// 			}
				codSubfamiliaPrev = codSubfamilia;
				codTamanoPrev = codTamano;
				
	      //ref = AQUtil.sqlSelect("articulos", "referencia", "codcolorem " + (codColor == "" ? " IS NULL" : ("= '" + codColor + "'")) + " AND codtamanoem = '" + codTamano + "' AND codsubfamilia = '" + codSubfamilia + "' AND coddibestamp = '" + cursor.valueBuffer("coddibujoem") + "'");
				ref = AQUtil.sqlSelect("articulos", "referencia", "codcolorem " + (codColor == "" ? " IS NULL" : ("= '" + codColor + "'")) + " AND codtamanoem = '" + codTamano + "' AND codsubfamilia = '" + codSubfamilia + "' AND coddibestamp = '" + aDibujos[i] + "'");
				if (ref && soloNuevos) {
					continue;
				}
	      
	      //if (!ref) {
	        curLAM.setModeAccess(curLAM.Insert);
	        curLAM.refreshBuffer();
	        
	        curLAM.setValueBuffer("idalta", cursor.valueBuffer("idalta"));
					if (codColor != "") {
						curLAM.setValueBuffer("codcolorem", codColor);
					}

			curLAM.setValueBuffer("coddibujoem", aDibujos[i]);
			curLAM.setValueBuffer("descdibujo", q.value("d.descripcion"));
	        curLAM.setValueBuffer("subfamiliaem", q.value("s.descripcion"));
	        curLAM.setValueBuffer("codtamanoem", codTamano);
	        curLAM.setValueBuffer("codsubfamilia", codSubfamilia);
	        if (ref) {
	          curLAM.setValueBuffer("referencia", ref);
	        }
	        
	        if (!curLAM.commitBuffer()) {
	          sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	          return false;
	        }
	      //}
	    }
	    sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	    this.child("tdbLineasAltaMasiva").refresh();
	    _i.habilitarBoton();
	  } else {
	  	if(dibujosSinColores && dibujosSinColores != "") {
	  		dibujosSinColores += ",";
	  	}
	  	dibujosSinColores += aDibujos[i];
	    	continue;
	  }
	}

	if(dibujosSinColores && dibujosSinColores != "") {
		MessageBox.information(sys.translate("No hay relaci�n de colores y tama�os para los dibujos:\n" + dibujosSinColores), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
	}

	cursor.setValueBuffer("modo","seleccionprevia");
   _i.habilitaPorModo("seleccionprevia");
}

function oficial_creaAltas()
{
  var _i = this.iface;
	_i.modificado_ = true;
  var cursor = this.cursor();

   if(!cursor.valueBuffer("codcoleccionem") || cursor.valueBuffer("codcoleccionem") == "") {
  		sys.warnMsgBox(sys.translate("Debe establecer antes la colecci�n"));
		return false;
  }
  
  var progress = 0;
  var seleccionados = this.child("tdbLineasAltaMasiva").primarysKeysChecked();
  
  var tipoArticulo, combinacion;
  var creados = 0;
  var oParam = new Object;
  var f = new Function("oParam", "return formRecordem_altamasiva.iface.creaArticulo(oParam)");
  if (seleccionados.length > 0) {
//    var curT = new FLSqlCursor("empresa");
//    curT.transaction(false);
    AQUtil.createProgressDialog(AQUtil.translate("scripts", "Creando articulos nuevos..."), seleccionados.length);
    
    var curTabla = new FLSqlCursor("em_lineasaltamasiva");
    AQUtil.setProgress(0);
    var fT, codSubfamilia;
    for (var p = 0; p < 2; p++) { /// 2 pasadas, la primera crea componentes, la segunda productos
      for (var i = 0; i < seleccionados.length; i++) {
        curTabla.select("idLinea = '" + seleccionados[i] + "' order by idlinea");
        curTabla.first();
        curTabla.setModeAccess(curTabla.Edit);
        curTabla.refreshBuffer();
        codSubfamilia = curTabla.valueBuffer("codsubfamilia");
        fT = AQUtil.sqlSelect("subfamilias sf INNER JOIN familias f ON sf.codfamilia = f.codfamilia", "f.fichatecnica", "sf.codsubfamilia = '" + codSubfamilia + "'", "familias");
        if ((fT && p == 0) || (!fT && p == 1)) {
          continue;
        }
        combinacion = AQUtil.sqlSelect("subfamilias", "descripcion", "codsubfamilia = '" + codSubfamilia  + "'") + " - " + curTabla.valueBuffer("codtamanoem") + " - " + curTabla.valueBuffer("codcolorem");
        AQUtil.setLabelText((p == 0) ? sys.translate("Creando componente %1").arg(combinacion) : sys.translate("Creando producto %1").arg(combinacion))
            AQUtil.setProgress(progress++);
        oParam.errorMsg = sys.translate("Error al crear el art�culo para la combinaci�n %1").arg(combinacion);
        oParam.curTabla = curTabla;
        if (!sys.runTransaction(f, oParam)) {
          var res = MessageBox.warning(sys.translate("La creaci�n del art�culo %1 ha fallado.\n�Desea continuar?").arg(combinacion), MessageBox.Yes, MessageBox.No);
          if (res != MessageBox.Yes) {
            return false;
          }
          continue;
        }
        creados++;
        this.child("tdbLineasAltaMasiva").setPrimaryKeyChecked(seleccionados[i], false);
        this.child("tdbLineasAltaMasiva").refresh();
        /*
        try {
          var referencia = _i.creaArticulo(curTabla);
          if (referencia && referencia != "") {
            curTabla.setValueBuffer("referencia", referencia);
            
          if (!curTabla.commitBuffer()) {
            ;
            curT.rollback();
            MessageBox.warning(sys.translate("Error al crear el articulo de la linea %1").arg(curTabla.valueBuffer("idLinea")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
            return;
          }
          curT.commit();
        } else {
          curT.rollback();
          MessageBox.warning(sys.translate("Error al crear el articulo de la linea %1").arg(curTabla.valueBuffer("idLinea")), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
          return;
        }
      } catch (e) {
        curT.rollback();
        MessageBox.warning(sys.translate("Error al crear el articulo de la linea %1: ").arg(curTabla.valueBuffer("idLinea") + e), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
        return;
      }*/
      }
    }
    sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
    
    this.child("tdbLineasAltaMasiva").refresh();
    MessageBox.information(sys.translate("Han sido creados %1 art�culos satisfactoriamente.").arg(creados), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    //_i.deseleccionarTodo();
  } else {
    MessageBox.warning(sys.translate("Debe seleccionar alguna linea para crear el art�culo correspondiente."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
  }
  _i.filtraArticulos();
  _i.habilitarBoton();
}

function oficial_filtraArticulos()
{
  this.child("tdbArticulos").refresh();
}

function oficial_ordenTablaArticulos()
{
	var c = ["referencia", "descripcion", "codtamanoem", "codcolorem", "fabricado", "em_situaciongenft","em_resultadogenft","em_motivogenft"];
	this.child("tdbArticulos").setOrderCols(c);
}

function oficial_creaArticulo(oParam)
{
	var _i = this.iface;
	var curTabla = oParam.curTabla;
	var cursor = this.cursor();
	var cursorArticulos = new FLSqlCursor("articulos");

	if(!("identificador" in oParam)) {
		oParam.identificador = "idaltamasiva";
	}

	if(!("clave" in oParam)) {
		oParam.clave = cursor.valueBuffer("idalta");
	}

	if(!("coleccion" in oParam)) {
		oParam.coleccion = cursor.valueBuffer("codcoleccionem");
	}

	cursorArticulos.setModeAccess(cursorArticulos.Insert);
	cursorArticulos.refreshBuffer();

	var codFamilia = AQUtil.sqlSelect("subfamilias", "codfamilia", "codsubfamilia = '" + curTabla.valueBuffer("codsubfamilia") + "'");
	var tipoArticulo, desArticulo;
	oParam.descColeccion = AQUtil.sqlSelect("em_colecciones","descripcion","codcoleccionem = '" + oParam.coleccion + "'");

	cursorArticulos.setValueBuffer(oParam.identificador, oParam.clave);
	cursorArticulos.setValueBuffer("codcoleccionem", oParam.coleccion);
	cursorArticulos.setValueBuffer("descoleccion", oParam.descColeccion);
	cursorArticulos.setValueBuffer("fechaalta", new Date());
	cursorArticulos.setValueBuffer("idusuarioalta", sys.nameUser());
	cursorArticulos.setValueBuffer("codfamilia", codFamilia);
	cursorArticulos.setValueBuffer("codsubfamilia", curTabla.valueBuffer("codsubfamilia"));
	cursorArticulos.setValueBuffer("codtamanoem", curTabla.valueBuffer("codtamanoem"));
	cursorArticulos.setValueBuffer("coddibestamp", curTabla.valueBuffer("coddibujoem"));
	cursorArticulos.setValueBuffer("emdibujo", AQUtil.sqlSelect("em_dibujos","descripcion","coddibujoem = " + curTabla.valueBuffer("coddibujoem")));
	cursorArticulos.setValueBuffer("codcolorem", curTabla.valueBuffer("codcolorem"));
	cursorArticulos.setValueBuffer("codunidad", formRecordarticulos.iface.pub_commonCalculateField("codunidad", cursorArticulos));
	tipoArticulo = formRecordarticulos.iface.pub_commonCalculateField("em_tipoarticulo", cursorArticulos);
	cursorArticulos.setValueBuffer("em_tipoarticulo", tipoArticulo);
	cursorArticulos.setValueBuffer("secompra", formRecordarticulos.iface.pub_commonCalculateField("secompra", cursorArticulos));
	desArticulo = formRecordarticulos.iface.pub_commonCalculateField("descripcion", cursorArticulos);
	if (desArticulo.length > 100) {
		sys.warnMsgBox(sys.translate("La descripci�n \"%1\" es demasiado larga.\nEste art�culo no se crear�").arg(desArticulo));
		return false;
	}
	cursorArticulos.setValueBuffer("descripcion", desArticulo);
	cursorArticulos.setValueBuffer("codimpuesto", formRecordarticulos.iface.pub_commonCalculateField("codimpuesto", cursorArticulos));
	cursorArticulos.setValueBuffer("tipostock", formRecordarticulos.iface.pub_commonCalculateField("tipostock", cursorArticulos));
	cursorArticulos.setValueBuffer("codgrupocontablepro", formRecordarticulos.iface.pub_commonCalculateField("codgrupocontablepro", cursorArticulos));
	cursorArticulos.setValueBuffer("codgrupocontableexi", formRecordarticulos.iface.pub_commonCalculateField("codgrupocontableexi", cursorArticulos));
	cursorArticulos.setValueBuffer("panotcont", formRecordarticulos.iface.pub_commonCalculateField("panotcont", cursorArticulos));


	if (!cursorArticulos.commitBuffer()) {
		return false;
	}

	oParam.referencia = cursorArticulos.valueBuffer("referencia");
  

	var fT = AQUtil.sqlSelect("familias", "fichatecnica", "codFamilia = '" + codFamilia + "'", "familias");
	if (fT) {
		if (!_i.creaFichaTecnica(cursorArticulos, oParam)) {
			return false;
		}
	}
	cursorArticulos.select("referencia = '" + oParam.referencia + "'");
	if (!cursorArticulos.first()) {
		return false;
	}
	cursorArticulos.setModeAccess(cursorArticulos.Edit);
	cursorArticulos.refreshBuffer();
	if (!formRecordarticulos.iface.calculaFactoresFT(cursorArticulos, true)) {
		return false;
	}

	if(!formRecordarticulos.iface.heredarCosteMargenProd(cursorArticulos, true)) {
		return false;
	}

	/*if(!formRecordarticulos.iface.heredarCosteProd(cursorArticulos, true, false)) {
		return false;
	}
	if(!formRecordarticulos.iface.heredarMargenProd(cursorArticulos, true, true)) {
		return false;
	}*/

	if (!cursorArticulos.commitBuffer()) {
		AQUtil.destroyProgressDialog();
		return false;
	}
	curTabla.setValueBuffer("referencia", oParam.referencia);
	if (!curTabla.commitBuffer()) {
		return false;
	}
	_i.crearLineaColeccion(oParam.referencia, oParam.coleccion, oParam.descColeccion);
  	return true;
}

function oficial_creaSubtablaColeccion(oParam)
{
	var _i = this.iface;

	if(!oParam) {
		return false;
	}

	if(!("referencia" in oParam)) {
		return false;
	}

	if(!("coleccion" in oParam)) {
		return false;
	}

	var ref = oParam.referencia;
	var coleccion = oParam.coleccion;

	if(!ref || ref == "" || !coleccion || coleccion == "") {
		return false;
	}

	var descColeccion = "";
	if("descColeccion" in oParam) {
		descColeccion = oParam.descColeccion;
	}

	if(!AQUtil.sqlInsert("em_coleccionesart","referencia,codcoleccionem,descripcion,principal",ref + "," + coleccion + "," + descColeccion + ",true")) {
		return false;
	}

	return true;
}
function oficial_creaFichaTecnica(curArticulo, oParam)
{
	return true; /// Hasta que se decida hacer
	
  var _i = this.iface;

	if (!_i.datosComunesProducto(curArticulo.valueBuffer("codsubfamilia"), curArticulo.valueBuffer("codcolorem"))) {
		return false;
	}

  var oPlantilla = _i.plantillaProducto(curArticulo);
  if (!oPlantilla) {
    return false;
  }
  oPlantilla = _i.plantillaDibujo(curArticulo, oPlantilla);
  if (!oPlantilla) {
    return false;
  }
  if (!_i.valoresAPlantilla(curArticulo, oPlantilla)) {
		return false;
	}
  var referencia, cantidad, componente;
  var curAC = new AQSqlCursor("articuloscomp");
  for (var c in oPlantilla) {
    cantidad = oPlantilla[c]["cantidad"];
    if (cantidad == 0) {
      continue;
    }
    componente = oPlantilla[c]["componente"];
    referencia = oPlantilla[c]["refcomponente"];
    if (!referencia || referencia == "") {
      MessageBox.warning(sys.translate("Error al crear la ficha t�cnica. No se ha obtenido una referencia para el componente %1").arg(componente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
      return false;
    }
    curAC.setModeAccess(AQSql.Insert);
    curAC.refreshBuffer();
    curAC.setValueBuffer("refcompuesto", curArticulo.valueBuffer("referencia"));
    curAC.setValueBuffer("orden", oPlantilla[c]["orden"]);
    curAC.setValueBuffer("refcomponente", referencia);
    curAC.setValueBuffer("desccomponente", AQUtil.sqlSelect("articulos", "descripcion", "referencia = '" + referencia + "'"));
    curAC.setValueBuffer("codtamanoem", oPlantilla[c]["codtamanoem"]);
    curAC.setValueBuffer("codcolorem", oPlantilla[c]["codcolorem"]);
    curAC.setValueBuffer("cantidad", oPlantilla[c]["cantidad"]);
    curAC.setValueBuffer("largo", oPlantilla[c]["largo"]);
    curAC.setValueBuffer("ancho", oPlantilla[c]["ancho"]);
    curAC.setValueBuffer("alto", oPlantilla[c]["alto"]);
    curAC.setValueBuffer("piezasancho", oPlantilla[c]["piezasancho"]);
    curAC.setValueBuffer("factor", oPlantilla[c]["factor"]);
    curAC.setValueBuffer("em_codcomponente", c);
    curAC.setValueBuffer("componente", componente);
    curAC.setValueBuffer("reservar", oPlantilla[c]["reservar"]);
    curAC.setValueBuffer("codunidad", oPlantilla[c]["codunidad"]);
    curAC.setValueBuffer("idseccion", oPlantilla[c]["idseccion"]);
    curAC.setValueBuffer("observaciones", oPlantilla[c]["observaciones"]);
    if (!curAC.commitBuffer()) {
      return false;
    }
  }
  return true;
}

function oficial_plantillaDibujo(curArticulo, oPlantilla)
{
  /*for (var c in oPlantilla) {
    debug("c " + c + " " +  oPlantilla[c]["componente"]);
  }*/
  var _i = this.iface;
  var codSubfamilia = curArticulo.valueBuffer("codsubfamilia");
  var codTamano = curArticulo.valueBuffer("codtamanoem");
  var codColor = curArticulo.valueBuffer("codcolorem");
  var codDibujo = curArticulo.valueBuffer("coddibestamp") ;
  var subfamilia = AQUtil.sqlSelect("subfamilias", "descripcion", "codsubfamilia = '" + codSubfamilia + "'");
  var dibujo = AQUtil.sqlSelect("em_dibujos", "descripcion", "coddibujoem = " + codDibujo);
  var q = new AQSqlQuery;
  q.setSelect("emcodcomponente");
  q.setFrom("em_lineasplantilladib");
  q.setWhere("coddibujoem = " + codDibujo + " AND codsubfamiliaprod = '" + codSubfamilia + "' AND (codtamanoemprod = '" + codTamano + "' OR codtamanoemprod IS NULL) AND (codcoloremprod = '" + codColor + "' OR codcoloremprod IS NULL) GROUP BY emcodcomponente");
  if (!q.exec()) {
    return false;
  }
  var idComp, componente, referencia, codFamilia, codTamanoTejido, tipoDibujo, cantidad;
	qTPpal = new AQSqlQuery;
  var qL = new AQSqlQuery;
  qL.setSelect("emcodcomponente, componente, refcomponente, codsubfamilia, desccomponente, codtamanoem, codcolorem, cantidad, observaciones, dibujo");
  qL.setFrom("em_lineasplantilladib");
//debug(q.sql());
  while (q.next()) {
    idComp = q.value("emcodcomponente");
    qL.setWhere("coddibujoem = " + codDibujo + " AND codsubfamiliaprod = '" + codSubfamilia + "' AND (codtamanoemprod = '" + codTamano + "' OR codtamanoemprod IS NULL) AND (codcoloremprod = '" + codColor + "' OR codcoloremprod IS NULL) AND emcodcomponente = " + idComp + " ORDER BY codcoloremprod, codtamanoemprod");
    if (!qL.exec()) {
      return false;
    }
    if (!qL.first()) {
      return false;
    }
    //debug(qL.sql());
    if (idComp in oPlantilla) {
      componente = oPlantilla[idComp]["componente"];
      cantidad = qL.value("cantidad");
      if (!isNaN(cantidad) && cantidad == 0) {
        oPlantilla[idComp]["cantidad"] = 0;
        continue;
      }
      oPlantilla[idComp]["dibujo"] = qL.value("dibujo");
			oPlantilla[idComp]["subfamilia"] = qL.value("subfamilia");
			oPlantilla[idComp]["refcomponente"] = qL.value("refcomponente");
			oPlantilla[idComp]["observaciones"] = qL.value("observaciones");
		} else { /// El componente no est� en la plantilla
      oPlantilla[idComp] = new Object;
      oPlantilla[idComp]["emcodcomponente"] = qL.value("emcodcomponente");
      oPlantilla[idComp]["componente"] = qL.value("componente");
      /// Debe comprobarse que el componente no es tejido (si lo es, deber�a estar siempre en la plantilla, no solo en el dibujo)
      oPlantilla[idComp]["refcomponente"] = qL.value("refcomponente");
			oPlantilla[idComp]["codsubfamilia"] = qL.value("codsubfamilia");
      oPlantilla[idComp]["cantidad"] = qL.value("cantidad");
      oPlantilla[idComp]["codunidad"] = qL.value("codunidad");
      oPlantilla[idComp]["idseccion"] = qL.value("idseccion");
      oPlantilla[idComp]["observaciones"] = qL.value("observaciones");
    }
  }
  
  return oPlantilla;
}

function oficial_valoresAPlantilla(curArticulo, oPlantilla)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codSFComp, cantidad, codTamanoTejido, codFamilia;
	var codDibujo = cursor.valueBuffer("coddibujoem");
	var codColor = curArticulo.valueBuffer("codcolorem");
  for (var c in oPlantilla) { /// Valores en plantilla producto no modificados por plantilla dibujo
    cantidad = oPlantilla[c]["cantidad"];
    if (cantidad == 0) {
      continue;
    }
    if (oPlantilla[c]["refcomponente"] && oPlantilla[c]["refcomponente"] != "") {
      continue;
    }
    codSFComp = oPlantilla[c]["codsubfamilia"];
		if (oPlantilla[c]["reservar"]) { /// Es tejido
			if (oPlantilla[c]["dibujo"] == "Coordinado") {
				oPlantilla[c]["refcomponente"] = _i.refCoordinado_;
				if (!oPlantilla[c]["refcomponente"]) {
					MessageBox.warning(sys.translate("Para el componente %1 se ha establecido un dibujo coordinado pero no se ha especificado la referencia").arg(componente), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
					return false;
				}
			} else { /// Tejido con dibujo principal
				codTamanoTejido = oPlantilla[c]["codtamanoem"]
				codFamilia = 3; /// Tejido
				qTPpal.setSelect("referencia");
				qTPpal.setFrom("articulos");
				qTPpal.setWhere("coddibestamp = " + codDibujo + " AND codtamanoem = '" + codTamanoTejido + "' AND codfamilia = '" + codFamilia + "' AND codcolorem = '" + codColor + "'");
				if (!qTPpal.exec()) {
					return false;
				}
				if (qTPpal.size() > 1) {
					MessageBox.warning(sys.translate("Componente %1. Se ha encontrado m�s de art�culo de tejido correspondiente al dibujo %2, el tama�o %3 y la familia %4.\nEspecifique la subfamilia de tejido en la plantilla del dibujo").arg(componente).arg(codDibujo).arg(codTamanoTejido).arg(codFamilia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
					return false;
				}
				if (!qTPpal.first()) {
					MessageBox.warning(sys.translate("No se ha encontrado el art�culo tejido correspondiente al dibujo %1, el tama�o %1 y la familia %3").arg(codDibujo).arg(codTamanoTejido).arg(codFamilia), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
					return false;
				}
				oPlantilla[c]["refcomponente"] = qTPpal.value("referencia");
			}
		} else { /// No es tejido
			if (codSFComp && codSFComp != "") {
				var w = "coddibestamp = " + codDibujo + " AND codsubfamilia = '" + codSFComp + "'"; /// Para componentes como la foto
				oPlantilla[c]["refcomponente"] = AQUtil.sqlSelect("articulos", "referencia", w);
				if (!oPlantilla[c]["refcomponente"]) {
					MessageBox.warning(sys.translate("No se ha encontrado el art�culo correspondiente al dibujo %1, y la subfamilia %3").arg(dibujo).arg(codSFComp), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
					return false;
				}
			}
    }
    if (oPlantilla[c]["refcomponente"] && oPlantilla[c]["refcomponente"] != "") {
      oPlantilla[c]["codtamanoem"] = AQUtil.sqlSelect("articulos", "codtamanoem", "referencia = '" + oPlantilla[c]["refcomponente"] + "'");
      oPlantilla[c]["codcolorem"] = AQUtil.sqlSelect("articulos", "codcolorem", "referencia = '" + oPlantilla[c]["refcomponente"] + "'");
    }
  }
  return true;
}

function oficial_plantillaProducto(curArticulo)
{
  var _i = this.iface;
  var codSubfamilia = curArticulo.valueBuffer("codsubfamilia");

  var codTamano = curArticulo.valueBuffer("codtamanoem");
  /// Cambiar por una primera selecci�n en dibujos / subfamilias / tama�os y si no se encuentra, buscar la DEFAULT
  var variante = "DEFAULT";
  var combinacion = AQUtil.sqlSelect("subfamilias", "descripcion", "codsubfamilia = '" + codSubfamilia  + "'") + " - " + codTamano + " - " + variante;
  var idPlantilla = AQUtil.sqlSelect("em_plantillasprod", "idplantilla", "codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "' AND variante = '" + variante + "'");
  if (!idPlantilla) {
    MessageBox.warning(sys.translate("No se ha encontrado la plantilla asociada a la combinaci�n %1").arg(combinacion), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
    return false;
  }
  
  var campos = ["emcodcomponente", "componente", "orden", "refcomponente", "desccomponente", "codtamanoem", "codcolorem", "cantidad", "largo", "ancho", "alto", "piezasancho", "factor", "reservar", "codunidad", "idseccion", "observaciones", "dibujo", "codsubfamilia"];
  var q = new AQSqlQuery();
  q.setSelect(campos.join(", "));
  q.setWhere("idplantilla = " + idPlantilla);
  q.setFrom("em_lineasplantillaprod");
  if (!q.exec()) {
    return false;
  }
  var oPlantilla = new Object;
  var idComp, valores = "";;
  while (q.next()) {
    idComp = q.value("emcodcomponente");
    oPlantilla[idComp] = new Object;
    for (var i = 0; i < campos.length; i++) {
      oPlantilla[idComp][campos[i]] = q.value(campos[i]);
      valores += (campos[i] + " = " + q.value(campos[i]) + ", ");
    }
    
    valores = "";
  }
  return oPlantilla;
}



function oficial_seleccionarTodo()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  var curLAM = new FLSqlCursor("em_lineasaltamasiva");
  curLAM.select("idalta = '" + cursor.valueBuffer("idalta") + "'");
  while (curLAM.next()) {
    this.child("tdbLineasAltaMasiva").setPrimaryKeyChecked(curLAM.valueBuffer("idlinea"), true);
  }
  this.child("tdbLineasAltaMasiva").refresh();
}

function oficial_seleccionarNuevos()
{
  var _i = this.iface;
  var cursor = this.cursor();
  
  var curLAM = new FLSqlCursor("em_lineasaltamasiva");
  curLAM.select("idalta = '" + cursor.valueBuffer("idalta") + "' AND referencia is NULL");
  while (curLAM.next()) {
    this.child("tdbLineasAltaMasiva").setPrimaryKeyChecked(curLAM.valueBuffer("idlinea"), true);
  }
  this.child("tdbLineasAltaMasiva").refresh();
}

function oficial_crearLineaColeccion(referencia, codColeccion, descColeccion)
{
  var _i = this.iface;
  var cursor = this.cursor();
  
//  var codColeccion = cursor.valueBuffer("codcoleccionem");
  if (!codColeccion || codColeccion == "") {
    return true;
  }
  
  var curLC = new FLSqlCursor("em_coleccionesart");
  curLC.setModeAccess(curLC.Insert);
  curLC.refreshBuffer();
  
  curLC.setValueBuffer("referencia", referencia);
  curLC.setValueBuffer("codcoleccionem", codColeccion);
  curLC.setValueBuffer("descripcion", descColeccion);
  curLC.setValueBuffer("principal", true);
  
  if (!curLC.commitBuffer()) {
    MessageBox.warning(sys.translate("No se ha podido crear la linea de colecci�n principal.\n    Introduzcala a mano si lo desea."), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
  }
  
}

function oficial_deseleccionarTodo()
{
  this.child("tdbLineasAltaMasiva").clearChecked();
  this.child("tdbLineasAltaMasiva").refresh();
}

function oficial_habilitarBoton()
{
  if (this.child("tdbLineasAltaMasiva").cursor().size() > 0) {
  	if(AQUtil.sqlSelect("articulos","referencia","idaltamasiva = " + this.cursor().valueBuffer("idalta"))) {
  		this.child("pbnCrear").enabled = false;	
  	}
  	else {
    	this.child("pbnCrear").enabled = true;
    }
  } else {
    this.child("pbnCrear").enabled = false;
  }
}

function oficial_habilitaPorModo(modo)
{
  var _i = this.iface; 
  var cursor = this.cursor();
  if(!modo || modo == "") {
  	modo = cursor.valueBuffer("modo");
  }

  var cursor = this.cursor();
  if(modo == "seleccionprevia") {
  //switch (cursor.modeAccess()) {
  //case cursor.Edit: {
      this.child("fdbCodDibujo").setDisabled(true);
      this.child("fdbCodDiseno").setDisabled(true);
      this.child("fdbCodColeccion").setDisabled(true);
      //this.child("fdbDesDibujo").setDisabled(true);
      this.child("fdbDesColeccion").setDisabled(true);
     // this.child("fdbCodDibujoHasta").setDisabled(true);
      //this.child("fdbDesDibujoHasta").setDisabled(true);
      
      this.child("pbnCalcular").enabled = false;
	  this.child("pbnCalcularNuevos").enabled = false;
	  this.child("pbnSelectDibujos").enabled = false;
	  this.child("pbnBorrar").enabled = false;

	  /*this.child("tdbDibujos").setDisabled(true);
	  this.child("tdbDibujos").setEnabled(false);
	  this.child("tdbDibujos").enabled = false;*/

	  _i.tblDibujos_.checkColumnLocked(true);
	  this.child("tbnSubir").setDisabled(true);
	  this.child("tbnBajar").setDisabled(true);
	  this.child("tbnReordenar").setDisabled(true);
	  //sys.disableObj(this, "mte_tblExt_Dibujos");


			//break;
    //}
  }
}

function oficial_datosComunesProducto(codSubfamiliaProd, codColorProd)
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.refCoordinado_ = AQUtil.sqlSelect("em_lineasplantilladib", "refcomponente", "coddibujoem = " + cursor.valueBuffer("coddibujoem") + " AND emcodcomponente IS NULL AND dibujo = 'Coordinado' AND (codsubfamiliaprod = '" + codSubfamiliaProd + "' OR codsubfamiliaprod IS NULL) AND (codcoloremprod = '" + codColorProd + "' OR codcoloremprod IS NULL) ORDER BY codsubfamiliaprod, codcoloremprod");
	return true;
}

function oficial_pushButtonCancel_clicked()
{
	var _i = this.iface;
	//if (_i.modificado_) {
		var res = MessageBox.warning(sys.translate("�Desea cancelar los cambios realizados hasta ahora?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {			
			return;
		}
	//}
	if(!_i.liberaUsuario()) {
		sys.errorMsgBox(sys.translate("Error al liberar usuario."));
	}
	sys.AQTimer.singleShot(0, formRecordem_altamasiva.reject);
}


function oficial_tdbArticulos_bufferCommited()
{
	var _i = this.iface;
	_i.modificado_ = true;
  var curFT = this.child("tdbArticulos").cursor();
	_i.guardaAltaMasiva(curFT);
}

function oficial_guardaAltaMasiva(curFT)
{
  var _i = this.iface;
  var cursor = this.cursor();

  var commitLineas = (cursor.transactionLevel() == 2);
  if (curFT == undefined) {
    commitLineas = false;
  }

  if (cursor.modeAccess() != cursor.Edit) {
    return true;
  }

  if (!_i.validateForm()) {
    return false;
  }

  var indice = cursor.atFrom();
  if (!cursor.commitBuffer()) {
    return false;
  }

  if (commitLineas)
    curFT.commit();
  if (!cursor.commit()) {
    if (commitLineas)
      curFT.transaction(false);
    return false;
  }

  if (!cursor.transaction(false)) {
    if (commitLineas)
      curFT.transaction(false);
    return false;
  }
  if (commitLineas)
    curFT.transaction(false);

  if (!cursor.seek(indice)) {
    return false;
  }

  cursor.setModeAccess(cursor.Edit);
  cursor.refreshBuffer();

  return true;
}

function oficial_filtrarTablaDibujos(tipo)
{
	var _i = this.iface;
	var cursor = this.cursor();

	var filtro = "";
	//var filtro = _i.tdbDibujos_.cursor().mainFilter();
	//var dibujoDesde = cursor.valueBuffer("coddibujoem");
	//var dibujoHasta = cursor.valueBuffer("coddibujoemhasta");
	var listaDibujos = cursor.valueBuffer("coddibujoem");
	var listaDisenos = cursor.valueBuffer("coddiseno");

	/*if(filtro == "1=2") {
		filtro = "";
	}*/
	//switch(tipo) {
		//default:
		//	filtro = "1=2";
	//	case "lista": {
			var aDibujos = _i.dameListaDibujos(listaDibujos);
			var aDisenos = _i.dameListaDisenos(listaDisenos);

			var sDibujos = aDibujos.join(",");
			if(sDibujos && sDibujos != "") {
				filtro += filtro == "" ? "" : " OR ";
				filtro += "(coddibujoem in (" + sDibujos +"))";
			}			

			var sDisenos = aDisenos.join(",");
			if(sDisenos && sDisenos != "") {
				filtro += filtro == "" ? "" : " OR ";
				filtro += "(coddiseno in (" + sDisenos +"))";
			}

			if(!filtro || filtro == "") {
				filtro = "1=2";
			}
		//}
		/*case "desdehasta": {
			if(!filtro || filtro == "" || filtro == "1=2") {
				if(dibujoDesde && dibujoDesde != "") {
					filtro = "coddibujoem >= " + dibujoDesde;
				}
				if(dibujoHasta && dibujoHasta != "") {
					if(filtro && filtro != "") {
						if(filtro == "1=2")
							filtro == "";
						else
							filtro +=" and ";
					}
					filtro += "coddibujoem <= " + dibujoHasta;
				}
			}
			break;
		}*/
	//}
	return filtro;

	//_i.tblDibujos_.cursor().setMainFilter(filtro);	
	//_i.tblDibujos_.refresh();
}

function oficial_pbnSelectDibujos_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	
	_i.creaSubtablaDibujos();
	_i.cargaDatosDibujos();
	
}


function oficial_dameListaDibujos(listaDibujos)
{
	var _i = this.iface;
	var cursor = this.cursor();

	listaDibujos = _i.formateaStringFiltro(listaDibujos);

	var dibujosComa = [];
	var dibujosGuion = [];

	var aDibujos = [];
	//Esto es para leerlos
	if (listaDibujos && listaDibujos != "") {
		dibujosComa = listaDibujos.split(",");

		for(var i=0;i<dibujosComa.length;i++) {
			dibujosGuion = dibujosComa[i].split("-");
			if(dibujosGuion && dibujosGuion.length > 1) {
				var ultimoDibujo = dibujosGuion[1];
				var dibujoActual = dibujosGuion[0];
				while(dibujoActual <= ultimoDibujo) {
					
					aDibujos.push(dibujoActual);
					dibujoActual++;
				}
			} else {
				aDibujos.push(dibujosComa[i]);
				
			}
		}
	}

	return aDibujos;
	
}

function oficial_formateaStringFiltro(cadena)
{
	if(!cadena || cadena == "") {
		return "";
	}

	while(isNaN(cadena.right(1))) {
		cadena = cadena.left(cadena.length-1);
	}

	while(isNaN(cadena.left(1))) {
		cadena = cadena.right(cadena.length-1);
	}

	var aCadena = cadena.split("");

	for(var i=0;i<aCadena.length;i++) {
		if(isNaN(aCadena[i])) {
			switch(aCadena[i]) {
				case "-":
				case ",": {
					break;
				}
				default: {
					sys.warnMsgBox(sys.translate("Formato de campo incorrecto. Solo debe contener n�meros, ',' o '-':\n " + cadena));
					return "";
				}
			}
		}
	}

	return cadena;
}

function oficial_dameListaDisenos(listaDisenos)
{
	var _i = this.iface;
	var cursor = this.cursor();

	listaDisenos = _i.formateaStringFiltro(listaDisenos);

	var disenosComa = [];
	var disenosGuion = [];

	var aDisenos = [];
	//Esto es para leerlos
	if (listaDisenos && listaDisenos != "") {
		disenosComa = listaDisenos.split(",");

		for(var i=0;i<disenosComa.length;i++) {
			disenosGuion = disenosComa[i].split("-");
			if(disenosGuion && disenosGuion.length > 1) {
				var ultimoDiseno = disenosGuion[1];
				var disenoActual = disenosGuion[0];
				while(disenoActual <= ultimoDiseno) {
					//_i.tdbDibujos_.setPrimaryKeyChecked(disenoActual, true);
					aDisenos.push(disenoActual);
					disenoActual++;
				}
			} else {
				aDisenos.push(disenosComa[i]);
				
			}
		}
	}

	return aDisenos;
	
}

function oficial_guardarListaDibujos()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(cursor.valueBuffer("modo") == "seleccionprevia") {
		return false;
	}
	
	var aDibujos = _i.tblDibujos_.primarysKeysChecked();

	var listaDibujos = aDibujos.toString();

	if(listaDibujos.endsWith(",")) {
		listaDibujos = listaDibujos.left(listaDibujos.length-1);
	}

	cursor.setValueBuffer("listaseleccionados",listaDibujos);

	return listaDibujos;
}

function oficial_marcarSeleccionados(listaSel)
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(!listaSel || listaSel == "") {
		listaSel = cursor.valueBuffer("listaseleccionados");
	}


	var aSel = listaSel.split(",");

	for(var d = 0;d < aSel.length;d++) {
		if(aSel[d] && aSel[d] != "") {
			_i.tblDibujos_.setPrimaryKeyChecked(aSel[d], true, true);
		}
	}

	_i.tblDibujos_.refresh();

	return true;
}


function oficial_seleccionarTodoArt()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var curART = new FLSqlCursor("articulos");
	curART.select("idaltamasiva = '" + cursor.valueBuffer("idalta") + "' and em_tipoarticulo = 'Producto'");
	while (curART.next()) {
		this.child("tdbArticulos").setPrimaryKeyChecked(curART.valueBuffer("referencia"), true);
	}
	this.child("tdbArticulos").refresh();
}

function oficial_deseleccionarTodoArt()
{
  this.child("tdbArticulos").clearChecked();
  this.child("tdbArticulos").refresh();
}

function oficial_tbnGenerarFT_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var seleccionados = this.child("tdbArticulos").primarysKeysChecked();

	if(!seleccionados || seleccionados == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No ha seleccionado ning�n producto"),"warn",this);		
		return false;
	}

	var curArt = new FLSqlCursor("articulos");

	for (var i = 0; i < seleccionados.length; i++) {
		curArt.select("referencia = '" + seleccionados[i] + "'");
		curArt.first();
		curArt.setModeAccess(curArt.Edit);
		curArt.refreshBuffer();

		if(!formRecordarticulos.iface.generarFT(curArt)) {
			return false;
		}	 

		if(!curArt.commitBuffer()) {
			return false;
		}       

		this.child("tdbArticulos").refresh();
	}
	
	return true;
}

function oficial_pbnEnRevision_clicked()
{	
	var _i = this.iface;
	var cursor = this.cursor();

	var seleccionados = this.child("tdbArticulos").primarysKeysChecked();

	if(!seleccionados || seleccionados == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No ha seleccionado ning�n producto"),"warn",this);		
		return false;
	}

	var curArt = new FLSqlCursor("articulos");

	for (var i = 0; i < seleccionados.length; i++) {
		curArt.select("referencia = '" + seleccionados[i] + "'");
		curArt.first();
		curArt.setModeAccess(curArt.Edit);
		curArt.refreshBuffer();

		formRecordarticulos.iface.ponEnRevision(curArt);
		curArt.setValueBuffer("tipostock",formRecordarticulos.iface.commonCalculateField("tipostock", curArt));
		if(!curArt.commitBuffer()) {
			return false;
		}       

		this.child("tdbArticulos").refresh();
	}
	
	return true;
}

function oficial_pbnEnProduccion_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var seleccionados = this.child("tdbArticulos").primarysKeysChecked();

	if(!seleccionados || seleccionados == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No ha seleccionado ning�n producto"),"warn",this);		
		return false;
	}

	var curArt = new FLSqlCursor("articulos");

	for (var i = 0; i < seleccionados.length; i++) {
		curArt.select("referencia = '" + seleccionados[i] + "'");
		curArt.first();
		curArt.setModeAccess(curArt.Edit);
		curArt.refreshBuffer();

		formRecordarticulos.iface.ponEnProduccion(curArt);
		curArt.setValueBuffer("tipostock",formRecordarticulos.iface.commonCalculateField("tipostock", curArt));
		if(!curArt.commitBuffer()) {
			return false;
		}       

		this.child("tdbArticulos").refresh();
	}
	
	return true;
}

function oficial_liberaUsuario()
{
	var _i = this.iface;
	
	var cursor = this.cursor();
	var usuario = sys.nameUser();
	var idAlta = cursor.valueBuffer("idalta");
	//var usuarioCon = AQUtil.sqlSelect("em_ctrlusualtamasiva","idusuario","idaltamasiva = " + idAlta, "em_ctrlusualtamasiva", _i.cxTx_);
	var usuarioCon = AQUtil.sqlSelect("em_ctrlusualtamasiva","idusuario","1=1", "em_ctrlusualtamasiva", _i.cxTx_);
	if (usuarioCon && usuarioCon == usuario) { 
		//if (!AQUtil.sqlDelete("em_ctrlusualtamasiva", "idaltamasiva = " + idAlta,_i.cxTx_)) {
		if (!AQUtil.sqlDelete("em_ctrlusualtamasiva", "1=1",_i.cxTx_)) {
			return false;
		}		
	}
	return true;
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if(!_i.liberaUsuario()) {
		sys.errorMsgBox(sys.translate("Error al liberar usuario."));
	}
	this.accept();
}

function oficial_abreCxTx()
{
	var _i = this.iface;
	
	if (!_i.cxTx_) {
		_i.cxTx_ = "CxTx";
	}
	var dbTx= AQSql.database(_i.cxTx_);
	
	if (_i.cxTx_ && dbTx.connectionName() == _i.cxTx_ ) {
		/// Porque aunque se deje abierta a los 15min de inactividad TCP muere y no se detecta que se haya roto la conexi�n
		if (!sys.removeDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error en la desconexi�n."), "info");
			return false;
		}
		dbTx = AQSql.database(_i.cxTx_);
	}
	if (dbTx.connectionName() != _i.cxTx_ || !dbTx.isOpen()) {
		if (!sys.addDatabase(_i.cxTx_)) {
			flfactppal.iface.ponMsgError(sys.translate("Error al establecer la conexi�n de comprobaci�n de transacciones."), "warn");
			return false;
		}
	}
	return true;
}

function oficial_cargaDatosDibujos()
{
	var _i = this.iface;

	var obj = _i.dameTablaDibujos();

	var cursor = this.cursor();
	var idAlta = cursor.valueBuffer("idalta");
	if(!idAlta) {
		return obj;
	}

	var miTabla = obj.miTabla;

	var q = new FLSqlQuery;
	q.setSelect("em_dibujosaltamasiva.id, em_dibujosaltamasiva.orden, em_dibujosaltamasiva.coddibujoem,em_dibujos.descripcion,em_dibujos.tipo,em_dibujos.coddiseno,em_dibujos.codproveedor,em_dibujos.panotcont,em_dibujos.em_margenest,em_dibujos.liso");
	q.setFrom("em_dibujosaltamasiva inner join em_dibujos on em_dibujosaltamasiva.coddibujoem = em_dibujos.coddibujoem");
	q.setWhere("em_dibujosaltamasiva.idalta = " + idAlta);
	q.setOrderBy("em_dibujosaltamasiva.orden");
	miTabla.setQuery(q);

	/*
	var tamanios = _i.dameTamaniosHistorico(tab);
	for(var i = 0; i < tamanios.length; i++) {
		miTabla.setColumnWidth(tamanios[i][0], tamanios[i][1]);
	}

	var hidden = _i.dameCamposOcultosHistorico(tab);
	for(var i = 0; i < hidden.length; i++) {
		miTabla.hideColumn(hidden[i]);
	}

	var showed = _i.dameCamposVisiblesHistorico(tab);
	for(var i = 0; i < showed.length; i++) {
		miTabla.showColumn(showed[i]);
	}

	var cabecera = _i.dameCabeceraHistorico(tab);
	miTabla.setColumnLabels("*", cabecera.join("*"));

	miTabla.setLimit(_i.dameLimit());
	*/

	miTabla.setReadOnly(true);
	miTabla.refresh();

	return true;	
}

function oficial_dameTablaDibujos()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblDibujos_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Dibujos");
	obj.gb = this.child("mte_gbExt_Dibujos");

	if (!obj.creado) {
		_i.tblDibujos_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblDibujos_.checkColumnEnabled(true);
		_i.tblDibujos_.setAliasCheckColumn("Sel.");
		_i.tblDibujos_.setSearchEnabled(false);

		_i.tblDibujos_.setDoubleClickedFunction("formRecordem_altamasiva.iface.editaDibujo");
		_i.tblDibujos_.setSelectedFunction("formRecordem_altamasiva.iface.selectedFunction");
		_i.tblDibujos_.setCurrentChangedFunction("formRecordem_altamasiva.iface.currentChangedFunction");
	}
	
	obj.miTabla = _i.tblDibujos_;

	return obj;
}

function oficial_currentChangedFunction()
{
	var _i = this.iface;

	if(_i.tblDibujos_.isCheckColumnLocked()) {
		this.child("tbnSubir").setDisabled(true);
		this.child("tbnBajar").setDisabled(true);
	}
	else {
		var id = _i.tblDibujos_.cellValue(_i.tblDibujos_.fActual_, "em_dibujosaltamasiva.id");
	
		var aDibujos = _i.tblDibujos_.primarysKeysChecked();
		var listaSel = aDibujos.toString();

		if(listaSel.find(id,0) == -1) {
			this.child("tbnSubir").setDisabled(true);
			this.child("tbnBajar").setDisabled(true);
		}
		else {
			this.child("tbnSubir").setDisabled(false);
			this.child("tbnBajar").setDisabled(false);
		}
	}
}

function oficial_selectedFunction(pk,sel)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codAlta = cursor.valueBuffer("idalta");

	if(!codAlta) {
		return;
	}

	if(sel) {
		var aDibujos = _i.tblDibujos_.primarysKeysChecked();

		var listaSel = aDibujos.toString();

		if(listaSel.endsWith(",")) {
			listaSel = listaSel.left(listaSel.length-1);
		}

		var orden = 1;
		if(listaSel && listaSel != "" && aDibujos.length > 1) {
			orden = AQUtil.sqlSelect("em_dibujosaltamasiva","max(orden)","id IN (" + listaSel + ") and id <> " + pk);

			if(!orden) {
				orden = 1;
			}
			else {
				orden++;
			}
		}

		if(!AQUtil.sqlUpdate("em_dibujosaltamasiva","orden",orden,"id = " + pk))
			return false;

		_i.tblDibujos_.refresh();
	}
}

function oficial_editaDibujo()
{
	var _i = this.iface;

	var row = _i.tblDibujos_.fActual_;
	//var idDibujo = _i.tblDibujos_.cellValue(row, "em_dibujos.coddibujoem");
	var idDibujo = _i.tblDibujos_.dameCursor().valueBuffer("coddibujoem");
	if(!idDibujo || idDibujo == "")
		return;

	if(!idDibujo) {
		sys.warnMsgBox(sys.translate("El registro seleccionado no contiene ning�n dibujo"));
		return false;
	}

	_i.curDibujo_.select("coddibujoem = " + idDibujo);
	if(!_i.curDibujo_.first()) {
		return;
	}

	disconnect(_i.curDibujo_, "bufferCommited()", _i, "commitDibujos");
	connect(_i.curDibujo_, "bufferCommited()", _i, "commitDibujos");	

	if(this.cursor().valueBuffer("modo") != "alta") {
		_i.curDibujo_.browseRecord();
	}
	else {
		_i.curDibujo_.editRecord();
	}

	/*var f = new FLFormSearchDB("em_editdibujos");
	var cursor = f.cursor();

	cursor.select("coddibujoem = " + idDibujo);
	if(!cursor.first()) {
		sys.warnMsgBox(sys.translate("No se encontr� el dibujo " + idDibujo));
		return false;
	}
	
	if(this.cursor().valueBuffer("modo") != "alta") {
		cursor.setModeAccess(cursor.Browse);	
	}
	else {
		cursor.setModeAccess(cursor.Edit);

	}

	f.setMainWidget();
	//Este filtro lo pongo porque recien creado el dibujo no le aplica el filro que lleva el formulario.
	f.child("tdbDibujosColor").setFilter("coddibujoem = " + idDibujo);
	f.child("tdbDibujosColor").refresh();

	f.child("tdbCoordinados").setFilter("coddibujoem = " + idDibujo);
	f.child("tdbCoordinados").refresh();
	
	cursor.refreshBuffer();
	//cursor.setValueBuffer("coddibujoem",idDibujo);
	cursor.transaction(false);

	
	f.exec("coddibujoem");
	var	acpt = f.accepted();
	if (!acpt) {
		cursor.rollback();
	} else {
		if (cursor.commitBuffer()) {
			cursor.commit();
			_i.cargaDatosDibujos();
		}
	}

	_i.tblDibujos_.currentChanged(row,"em_disenosaltamasivacompleta.orden");
	*/
	return true;
}

function oficial_commitDibujos()
{
	var _i = this.iface;

	var row = _i.tblDibujos_.fActual_;

	_i.cargaDatosDibujos();

	_i.tblDibujos_.currentChanged(row,"em_disenosaltamasiva.orden");
}

function oficial_creaSubtablaDibujos()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbLineasAltaMasiva").cursor().commitBufferCursorRelation()) {
			return false;
		}
	}

	var idAlta = cursor.valueBuffer("idalta");
	if(!idAlta) {
		return false;
	}


	/*if(!AQUtil.sqlDelete("em_dibujosaltamasiva", "idalta = " + idAlta)) {
		return false;
	}*/

	//var filtro = _i.filtrarTablaDibujos();

	var listaDibujos = cursor.valueBuffer("coddibujoem");
	var listaDisenos = cursor.valueBuffer("coddiseno");
	var aDibujos = _i.dameListaDibujos(listaDibujos);
	var aDisenos = _i.dameListaDisenos(listaDisenos);

	var disenosActual = cursor.valueBuffer("disenos");
	if(!disenosActual || disenosActual == "unidefined")
		disenosActual = "";

	if(disenosActual.find(cursor.valueBuffer("coddiseno"),0) == -1) {
		if(disenosActual || disenosActual != "")
			disenosActual += ", ";

		disenosActual += cursor.valueBuffer("coddiseno");
	}
	cursor.setValueBuffer("disenos",disenosActual);

	var dibujosActual = cursor.valueBuffer("dibujos");
	if(!dibujosActual || dibujosActual == "unidefined")
		dibujosActual = "";
	
	if(dibujosActual.find(cursor.valueBuffer("coddibujoem"),0) == -1) {
		if(dibujosActual || dibujosActual != "")
			dibujosActual += ", ";
		dibujosActual += cursor.valueBuffer("coddibujoem");
	}

	cursor.setValueBuffer("dibujos",dibujosActual);


	var curDA = new FLSqlCursor("em_dibujosaltamasiva");


	var orden = parseInt(AQUtil.sqlSelect("em_dibujosaltamasiva","max(orden)","idalta = " + idAlta));
	if(orden) {
		orden++;
	}
	else {
		orden = 1;
	}

	for(var i=0;i<aDibujos.length;i++) {
		if(aDibujos[i] && aDibujos[i] != "") {
			if(!AQUtil.sqlSelect("em_dibujos","coddibujoem","coddibujoem = '" + aDibujos[i] + "'")) {
					continue;
			}
			if(AQUtil.sqlSelect("em_dibujosaltamasiva","id","idalta = " + idAlta + " and coddibujoem = '" + aDibujos[i] + "'")) {
				continue;
			}

			while(parseInt(AQUtil.sqlSelect("em_dibujosaltamasiva","orden","idalta = " + idAlta + " and orden = " + orden)) && parseInt(AQUtil.sqlSelect("em_dibujosaltamasiva","orden","idalta = '" + idAlta + "'")) != 0) {
				orden++;
			}

			curDA.setModeAccess(curDA.Insert);
			curDA.refreshBuffer();
			curDA.setValueBuffer("idalta",idAlta);
			curDA.setValueBuffer("orden",orden++);
			curDA.setValueBuffer("coddibujoem",aDibujos[i]);

			if(!curDA.commitBuffer()) {
				return false;
			}
		}

	}

	var q = new FLSqlQuery;
	q.setSelect("coddibujoem");
	q.setFrom("em_dibujos");

	for(var i=0;i<aDisenos.length;i++) {
		if(aDisenos[i] && aDisenos[i] != "") {
			q.setWhere("coddiseno = '" + aDisenos[i] + "'");
			if(!q.exec()) {
				continue;
			}

			while(q.next()) {
				if(AQUtil.sqlSelect("em_dibujosaltamasiva","id","idalta = " + idAlta + " and coddibujoem = '" + q.value("coddibujoem") + "'")) {
					continue;
				}
				curDA.setModeAccess(curDA.Insert);
				curDA.refreshBuffer();
				curDA.setValueBuffer("idalta",idAlta);
				curDA.setValueBuffer("orden",orden++);
				curDA.setValueBuffer("coddibujoem",q.value("coddibujoem"));

				if(!curDA.commitBuffer()) {
					return false;
				}
			}
		}
	}
	
	return true;
}

function oficial_obtenerDibujosSeleccionados()
{
	var _i = this.iface;
	
	var aDA = _i.tblDibujos_.primarysKeysChecked();

	if(aDA.length == 0) {
		return [];
	}

	var ids = aDA.toString();
	var dibujos = "";

	if(!ids || ids == "") {
		return "";
	}

	var q = new FLSqlQuery();
	q.setSelect("coddibujoem");
	q.setFrom("em_dibujosaltamasiva");
	q.setWhere("id in (" + ids + ") order by orden");
	if(!q.exec())
		return false;

	while(q.next()) {
		if(!q.value("coddibujoem") || q.value("coddibujoem") == "")
			continue;

		if(dibujos != "") {
			dibujos += ",";
		}
	
		dibujos += q.value("coddibujoem");
	}
	/*for(var i=0;i<aDA.length;i++) {
		if(dibujos != "") {
			dibujos += ",";
		}
		if(!aDA[i] || aDA[i] == "")
			continue;

		dibujos += AQUtil.sqlSelect("em_dibujosaltamasiva","coddibujoem","id = " + aDA[i]);
	}*/

	return dibujos.split(",");
}

function oficial_borrarTabla()
{
	var _i = this.iface;
	var cursor = this.cursor();

	
	var idAlta = cursor.valueBuffer("idalta");
	if(!idAlta) {
		return false;
	}

	if(!AQUtil.sqlDelete("em_dibujosaltamasiva", "idalta = " + idAlta)) {
		return false;
	}

	this.child("fdbCodDiseno").setValue("");
	this.child("fdbCodDibujo").setValue("");
	this.child("fdbDisenosB").setValue("");
	this.child("fdbDibujosB").setValue("");

	_i.cargaDatosDibujos();
}

function oficial_subirOrden()
{
	var _i = this.iface;

	var cursor = _i.tblDibujos_.dameCursor();
	
	var row = _i.tblDibujos_.fActual_;
	
	

	if (!_i.intercambiarOrden(cursor, row, -1)) {
		return false;
	}

	_i.tblDibujos_.refresh();
	_i.tblDibujos_.currentChanged(row-1,"em_dibujosaltamasiva.orden");

	return true;
}

function oficial_bajarOrden()
{
		var _i = this.iface;

	var cursor = _i.tblDibujos_.dameCursor();
	
	var row = _i.tblDibujos_.fActual_;
	
	

	if (!_i.intercambiarOrden(cursor, row, 1)) {
		return false;
	}

	_i.tblDibujos_.refresh();
	_i.tblDibujos_.currentChanged(row+1,"em_dibujosaltamasiva.orden");

	return true;
}

function oficial_reordenar()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codAlta = cursor.valueBuffer("idalta");
	if(!codAlta) {
		return;
	}

	var aDibujos = _i.tblDibujos_.primarysKeysChecked();

	var listaSel = aDibujos.toString();

	if(listaSel.endsWith(",")) {
		listaSel = listaSel.left(listaSel.length-1);
	}

	if(!listaSel || listaSel == "") {
		return;
	}

	var q = new FLSqlQuery();
	q.setSelect("id");
	q.setFrom("em_dibujosaltamasiva");  
	q.setWhere("idalta = '" + codAlta + "' and id not in (" + listaSel + ") order by orden");

	if (!q.exec()) {
    	return false;
    }

    var orden = AQUtil.sqlSelect("em_dibujosaltamasiva","max(orden)","id in (" + listaSel + ")");

    var cur = new FLSqlCursor("em_dibujosaltamasiva");

    while(q.next()) {
    	orden++;
    	cur.select("id = " + q.value("id"));
    	if(!cur.first()) {
    		return false;
    	}
    	cur.setModeAccess(cur.Edit);
    	cur.refreshBuffer();
    	cur.setValueBuffer("orden", orden);
    	if(!cur.commitBuffer()) {
    		return false;
    	}
    }


    _i.tblDibujos_.refresh();
	return true;
}

function oficial_intercambiarOrden(cursor, row1, direccion)
{
	var _i = this.iface;
	var tablaLineas = cursor.table();

	var row2 = row1+direccion;

	var id1 = _i.tblDibujos_.cellValue(row1, "em_dibujosaltamasiva.id");
	var id2 = _i.tblDibujos_.cellValue(row2, "em_dibujosaltamasiva.id");
	
	if(!id1 || !id2) {
		return;
	}

	var aDibujos = _i.tblDibujos_.primarysKeysChecked();
	var listaSel = aDibujos.toString();
	if(listaSel.find(id1,0) == -1) {
		sys.warnMsgBox(sys.translate("S�lo puede ordenar registros seleccionados"));
		return;
	}

	var orden1 = AQUtil.sqlSelect(tablaLineas, "orden","id = " + id1);
	var orden2 = AQUtil.sqlSelect(tablaLineas, "orden","id = " + id2);

	if (!orden1 || !orden2) {
		return false;
	}

	var cur1 = new FLSqlCursor(tablaLineas);
	cur1.select("id = " + id1);
	if (!cur1.first()) {
		return false;
	}
	cur1.setModeAccess(cur1.Edit);
	cur1.refreshBuffer();
	cur1.setValueBuffer("orden", orden2);
	if(!cur1.commitBuffer()) {
		return false;
	}

	var cur2 = new FLSqlCursor(tablaLineas);
	cur2.select("id = " + id2);
	if (!cur2.first()) {
		return false;
	}
	cur2.setModeAccess(cur2.Edit);
	cur2.refreshBuffer();
	cur2.setValueBuffer("orden", orden1);
	if(!cur2.commitBuffer()) {
		return false;
	}


	return true;
}

function oficial_cargaDatosCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var obj = _i.dameTablaCostes();	
	var miTabla = obj.miTabla;
	
	var q = new FLSqlQuery;
	q.setSelect("v_articuloslog.referencia, v_articuloslog.descripcion, v_articuloslog.codtamanoem, v_articuloslog.codcolorem, v_articuloslog.codfamilia, v_articuloslog.codsubfamilia, v_articuloslog.em_costeprod, v_articuloslog.em_margenprod, v_articuloslog.em_origencoste, v_articuloslog.em_origenmargen");		
	q.setFrom("v_articuloslog");
	q.setWhere("idaltamasiva = " + cursor.valueBuffer("idalta"));
	q.setOrderBy("v_articuloslog.referencia");		
	miTabla.setQuery(q);	
	
	miTabla.setColumnWidth("v_articuloslog.referencia", 80);
	miTabla.setColumnWidth("v_articuloslog.descripcion", 450);
	miTabla.setColumnWidth("v_articuloslog.codtamanoem", 120);
	miTabla.setColumnWidth("v_articuloslog.codcolorem", 120);
	miTabla.setColumnWidth("v_articuloslog.codfamilia", 80);
	miTabla.setColumnWidth("v_articuloslog.codsubfamilia", 80);
	miTabla.setColumnWidth("v_articuloslog.em_costeprod", 120);
	miTabla.setColumnWidth("v_articuloslog.em_margenprod", 120);
	miTabla.setColumnWidth("v_articuloslog.em_origencoste", 140);
	miTabla.setColumnWidth("v_articuloslog.em_origenmargen", 140);
	

	miTabla.setReadOnly(true);	
	miTabla.refresh();

	return true;	
}

function oficial_dameTablaCostes()
{
	var _i = this.iface;
	
	var obj = {};
	obj.creado = _i.tblCostes_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Costes");
	obj.gb = this.child("mte_gbExt_Costes");
	
	if (!obj.creado) {		
		_i.tblCostes_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);		
		_i.tblCostes_.checkColumnEnabled(true);		
		_i.tblCostes_.setAliasCheckColumn("Seleccionar");	
		_i.tblCostes_.setSearchEnabled(true);	
		_i.tblCostes_.tbnSelAll_.close();
      	_i.tblCostes_.tbnSelNot_.close();	
		_i.tblCostes_.setDoubleClickedFunction("formRecordem_altamasiva.iface.editarArticulo");
	}

	obj.miTabla = _i.tblCostes_;

	return obj;
}

function oficial_pbnTodosCostes_clicked() 
{
	var _i = this.iface;
	_i.tblCostes_.checkAll();
  		
}

function oficial_pbnNingunoCostes_clicked() 
{
	var _i = this.iface;
  	_i.tblCostes_.clearChecked(false);
}
	
function oficial_tbnEmRegenerarCostes_clicked() 
{
	var _i = this.iface;
	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length == 0) {
		formUI.ponMsgBox("Primero marque 1 o varios art�culos a recargar los costes/m�rgenes","warn");
		return false;
	} 
	var cursorArticulos = new FLSqlCursor("articulos");
	for(var i=0; i<aSel.length;i++) {		
		cursorArticulos.select("referencia = '" + aSel[i] + "'");
		if (!cursorArticulos.first()) {
			return false;
		}
		cursorArticulos.setModeAccess(cursorArticulos.Edit);
		cursorArticulos.refreshBuffer();		
		/*if(!formRecordarticulos.iface.heredarCosteProd(cursorArticulos, true, false)) {
			return false;
		}
		if(!formRecordarticulos.iface.heredarMargenProd(cursorArticulos, true, true)) {
			return false;
		}*/
		if(!formRecordarticulos.iface.heredarCosteMargenProd(cursorArticulos, true)) {
			return false;
		}	
		if (!cursorArticulos.commitBuffer()) {		
			return false;
		}
	}
	_i.tblCostes_.refresh();
	return true;
}
	
function oficial_tbnEmCargarCostes_clicked() 
{
  	var _i = this.iface;
	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length == 0) {
		formUI.ponMsgBox("Primero marque 1 o varios art�culos a recargar los costes/m�rgenes","warn");
		return false;
	} 
	var cursorArticulos = new FLSqlCursor("articulos");
	var heredarCoste;
	var heredarMargen;
	for(var i=0; i<aSel.length;i++) {		
		cursorArticulos.select("referencia = '" + aSel[i] + "'");
		if (!cursorArticulos.first()) {
			return false;
		}
		cursorArticulos.setModeAccess(cursorArticulos.Edit);
		cursorArticulos.refreshBuffer();
		heredarCoste = false;
		heredarCoste = false;

		/*if(!cursorArticulos.valueBuffer("em_costeprod") || cursorArticulos.isNull("em_costeprod")) {
			if(!formRecordarticulos.iface.heredarCosteProd(cursorArticulos, true, true)) {
				return false;
			}			
		}
		if(!cursorArticulos.valueBuffer("em_margenprod") || cursorArticulos.isNull("em_margenprod")) {
			if(!formRecordarticulos.iface.heredarMargenProd(cursorArticulos, true, true)) {
				return false;
			}
		}*/
		if(!cursorArticulos.valueBuffer("em_costeprod") || cursorArticulos.isNull("em_costeprod")) {
			heredarCoste = true;
		}
		if(!cursorArticulos.valueBuffer("em_margenprod") || cursorArticulos.isNull("em_margenprod")) {
			heredarMargen = true;
		}
		

		if(heredarCoste && heredarMargen) {
			if(!formRecordarticulos.iface.heredarCosteMargenProd(cursorArticulos, true)) {
				return false;
			}	
		} else if(heredarCoste) {
			if(!formRecordarticulos.iface.heredarCosteProd(cursorArticulos, true, true)) {
				return false;
			}

		} else if(heredarMargen) {
			if(!formRecordarticulos.iface.heredarMargenProd(cursorArticulos, true, true)) {
				return false;
			}
		}

		if (!cursorArticulos.commitBuffer()) {		
			return false;
		}
	}
	_i.tblCostes_.refresh();
	return true;
}
	
function oficial_pbnEditarTama_clicked() 
{
	var _i = this.iface;
	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length != 1) {
		formUI.ponMsgBox("Primero marque un solo art�culo y luego use este bot�n","warn");
		return false;
	} 
	var referencia = aSel[0];

	var q = new AQSqlQuery;	
	q.setSelect("codtamanoem,codsubfamilia");
	q.setFrom("articulos");
	q.setWhere("referencia = '" + referencia + "'");	
	if (!q.exec()){
		return;
	}  
	if(!q.first())
	{
		return false;			
	}	

	var codTamano = q.value("codtamanoem");
	var codSubfamilia = q.value("codsubfamilia");

	var curTama = new FLSqlCursor("em_tamanossubfam");
	curTama.select("codtamanoem = '" + codTamano + "' and codsubfamilia = '" + codSubfamilia + "'");
	curTama.first();
	curTama.editRecord();

  	return true;
}
	
function oficial_pbnEditarPlantilla_clicked() 
{
	var _i = this.iface;

	var aSel = _i.tblCostes_.primarysKeysChecked();
	if(aSel.length != 1) {
		formUI.ponMsgBox("Primero marque un solo art�culo y luego use este bot�n","warn");
		return false;
	} 
	var referencia = aSel[0];
				
	var q = new AQSqlQuery;	
	q.setSelect("codtamanoem,codsubfamilia,codcoleccionem,codcolorem");
	q.setFrom("articulos");
	q.setWhere("referencia = '" + referencia + "'");	
	if (!q.exec()){
		return;
	}  
	if(!q.first())
	{
		return false;			
	}	

	var codTamano = q.value("codtamanoem");
	var codSubfamilia = q.value("codsubfamilia");
	var codColeccion = q.value("codcoleccionem"); 
	var codColor = q.value("codcolorem");

	var curPlantilla = new FLSqlCursor("em_plantillasprod");
	curPlantilla.select("codtamanoem = '" + codTamano + "' and codsubfamilia = '" + codSubfamilia + "' and codcoleccionem = '" + codColeccion + "' and codcolorem = '" + codColor + "'");
	if(!curPlantilla.first()) {
		formUI.ponMsgBox("No hay plantilla asociada.","warn");
		return true;
	}
	curPlantilla.editRecord();
  	return true;
}

function oficial_editarArticulo()
{
	var _i = this.iface;
	var row = _i.tblCostes_.fActual_;
	var referencia = _i.tblCostes_.cellValue(row, "v_articuloslog.referencia");

	_i.curArticulo_.select("referencia = '" + referencia + "'");
	_i.curArticulo_.first();
	_i.curArticulo_.editRecord();

	
  	return true;
}	

function oficial_refrescaTabla()
{	
	var _i = this.iface;
	_i.tblCostes_.refresh();
}

function oficial_tbwArticulo_currentChanged(nombreTab)
{
	var _i = this.iface;
	if(nombreTab == "em_costes") {
		_i.cargaDatosCostes();
	}

}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
