var form = this;
/***************************************************************************
                 em_preparacionmat.qs  -  description
                             -------------------
    begin                : mie jun 4 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var usuarioActual_;
	var oColorLinea_, codAsigConfAnt_;
	var codOrdenDesde_;
	var codOrdenHasta_;
	function oficial( context ) { interna( context ); }
	function dameColorLinea(fN, fV, cursor, sel, fT) {
		return this.ctx.oficial_dameColorLinea(fN, fV, cursor, sel, fT);
	}
	function tbnCambiarUsuario_clicked() {
		return this.ctx.oficial_tbnCambiarUsuario_clicked();
	}
	function filtra() {
    return this.ctx.oficial_filtra();
  }
  function tdbOrdenes_recordChoosed() {
    return this.ctx.oficial_tdbOrdenes_recordChoosed();
  }
  function tdbOrdenesPrep_recordChoosed() {
    return this.ctx.oficial_tdbOrdenesPrep_recordChoosed();
  }
  function verificaUsuario() {
    return this.ctx.oficial_verificaUsuario();
  }
  function muestraUsuarioActual() {
		return this.ctx.oficial_muestraUsuarioActual();
	}
  function asociaOrden(oParam) {
		return this.ctx.oficial_asociaOrden(oParam);
	}
	function controlModo() {
		return this.ctx.oficial_controlModo();
	}
	function quitaOrden(oParam) {
		return this.ctx.oficial_quitaOrden(oParam);
	}
	function tbnBuscaPrep_clicked() {
		return this.ctx.oficial_tbnBuscaPrep_clicked();
	}
	function tbnBorraFiltro_clicked() {
    return this.ctx.oficial_tbnBorraFiltro_clicked();
  }
  function ordenaCols() {
    return this.ctx.oficial_ordenaCols();
  }
  function tbnInforme_clicked() {
    return this.ctx.oficial_tbnInforme_clicked();
  }
  function dameParamInforme(codPreparaMat) {
    return this.ctx.oficial_dameParamInforme(codPreparaMat);
  }
  function listaOrdenes(nodo, campo) {
    return this.ctx.oficial_listaOrdenes(nodo, campo);
  }
//   function formatoTabla(tabla) {
//     return this.ctx.oficial_formatoTabla(tabla);
//   }
  function tbnEtiquetas_clicked() {
    return this.ctx.oficial_tbnEtiquetas_clicked();
  }
  function marcaMaterialOk(oParam) {
    return this.ctx.oficial_marcaMaterialOk(oParam);
  }
  function tbnAceptar_clicked() {
    return this.ctx.oficial_tbnAceptar_clicked();
  }
  function dameFechaInforme(nodo, campo) {
    return this.ctx.oficial_dameFechaInforme(nodo, campo);
  }
  function formateaFechaInforme(fecha) {
    return this.ctx.oficial_formateaFechaInforme(fecha);
  }
	function tbnInformeMat_clicked() {
    return this.ctx.oficial_tbnInformeMat_clicked();
  }
	function tbnAplicarFiltros_clicked() {
		return this.ctx.oficial_tbnAplicarFiltros_clicked();
	}
	function tbnBuscarBobina_clicked() {
		return this.ctx.oficial_tbnBuscarBobina_clicked();
	}


}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  /*if (sys.nameBD() == "abanq_creaciones") {
    sys.warnMsgBox(sys.translate("Funconalidad s�lo disponible en pruebas"));
    this.close();
    return;
  }*/
	var _i = this.iface;
	
	_i.codOrdenDesde_ = "";
	_i.codOrdenHasta_ = "";

	this.child("tbnBorraFiltro").close();

	connect(this.child("tbnCambiarUsuario"), "clicked()", _i, "tbnCambiarUsuario_clicked");
	connect(this.child("tbnBuscaPrep"), "clicked()", _i, "tbnBuscaPrep_clicked");
	connect(this.child("tbnAnadir"), "clicked()", _i, "tdbOrdenes_recordChoosed");
// 	connect(this.child("tdbOrdenes").cursor(), "recordChoosed()", _i, "tdbOrdenes_recordChoosed");
	connect(this.child("tbnQuitar"), "clicked()", _i, "tdbOrdenesPrep_recordChoosed");
// 	connect(this.child("tdbOrdenesPrep").cursor(), "recordChoosed()", _i, "tdbOrdenesPrep_recordChoosed");
	connect(this.child("tbnBorraFiltro"), "clicked()", _i, "tbnBorraFiltro_clicked");
	connect(this.child("tbnInforme"), "clicked()", _i, "tbnInforme_clicked");
	connect(this.child("tbnEtiquetas"), "clicked()", _i, "tbnEtiquetas_clicked");
	connect(this.child("tbnAceptar"), "clicked()", _i, "tbnAceptar_clicked");
	connect(this.child("tbnInformeMat"), "clicked()", _i, "tbnInformeMat_clicked");
	connect(this.child("tbnAplicarFiltros"), "clicked()", _i, "tbnAplicarFiltros_clicked");
	connect(this.child("tbnBuscarBobina"), "clicked()", _i, "tbnBuscarBobina_clicked");
	
	
	_i.ordenaCols()
  _i.filtra();
	
	this.child("ledCodPreparaMat").setFocus();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_tbnBuscaPrep_clicked()
{
	var _i = this.iface;
	
	if (!this.child("tbnBuscaPrep").on) {
		this.child("ledCodPreparaMat").enabled = true;
		_i.tbnBorraFiltro_clicked();
		return;
	}
	
	this.child("ledCodPreparaMat").enabled = false;
	var codPreparaMat = this.child("ledCodPreparaMat").text;
	if (codPreparaMat && codPreparaMat != "") {
		codPreparaMat = flfactppal.iface.pub_cerosIzquierda(codPreparaMat, 8);
		this.child("ledCodPreparaMat").text = codPreparaMat;
	}
	var usuarioPrep = AQUtil.sqlSelect("em_preparacionesmat", "iduser", "codpreparamat = '" + codPreparaMat+ "'");
	if (!usuarioPrep) {
		sys.warnMsgBox(sys.translate("El grupo de preparaci�n %1 no existe").arg(codPreparaMat));
		_i.controlModo();
	}
	_i.usuarioActual_ = usuarioPrep;
	_i.muestraUsuarioActual();
  _i.filtra();
	_i.controlModo();
}

function oficial_dameColorLinea(fN, fV, cursor, sel, fT)
{
	debug("oficial_dameColorLinea");
  var _i = this.iface;
  var codAsigConf = cursor.valueBuffer("codasigconf");
  if (!sel && codAsigConf == _i.codAsigConfAnt_) {
    return _i.oColorLinea_;
  }
  if (!sel) {
    _i.codAsigConfAnt_ = codAsigConf;
	} else {
    _i.codAsigConfAnt_ = -1;
	}
	var color = "";
  if (cursor.valueBuffer("estado") == "Enviada") {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_azul_sel" : "fondo_azul");
  } else {
    color = flfactppal.iface.pub_dameColor(sel ? "fondo_gris_sel" : "fondo_gris");
  }
  if (color != "") {
    _i.oColorLinea_ = [color, sel ? "#FFFFFF" : "#000000", "SolidPattern", "SolidPattern"];
    return _i.oColorLinea_;
  } else
    _i.codAsigConfAnt_ = -1;
}

function oficial_tbnCambiarUsuario_clicked()
{
	var _i = this.iface;
	
	var f = new FLFormSearchDB("pr_bustrabajador");
	var curU = f.cursor();
	
	f.setMainWidget();
	var idUsuario = f.exec("idtrabajador");

	if (!idUsuario) {
		return;
	}
	_i.usuarioActual_ = idUsuario;
	_i.muestraUsuarioActual();
}

function oficial_muestraUsuarioActual()
{
	var _i = this.iface;
	var usuario;
	if (_i.usuarioActual_) {
		var n = AQUtil.sqlSelect("pr_trabajadores", "nombre", "idtrabajador = '" + _i.usuarioActual_ + "'");
		usuario = n + " (" + _i.usuarioActual_ + ")";
	} else {
		usuario = sys.translate("Usuario actual no establecido");
	}
	sys.setObjText(this, "lblUsuario", usuario);
}

function oficial_filtra()
{
	var _i  = this.iface;
	var pteConfeccion = this.child("chkPteConfeccion").checked;
	var enCurso = this.child("chkEnCurso").checked;
	var pte = this.child("chkPte").checked;

	var codBobina = this.child("txtCodBobina").text;

	var filtro = "NOT materialconfok AND codconfeccionista IS NULL";
	var filtrosCheck = "";
	if(pteConfeccion) {
		filtrosCheck = "estado = 'PTE CONFECCION'";
	} 	

	if(enCurso) {
		if(filtrosCheck && filtrosCheck != "") {
			filtrosCheck += " OR ";
		}
		filtrosCheck += "estado = 'EN CURSO'";
	}

	if(pte) {
		if(filtrosCheck && filtrosCheck != "") {
			filtrosCheck += " OR ";
		}
		filtrosCheck += "estado = 'PTE'";
	}
	if(!filtrosCheck || filtrosCheck == "") {
		filtrosCheck = "1 = 2";
	}

	//var fO = "estado = 'PTE CONFECCION' AND NOT materialconfok AND codconfeccionista IS NULL";
	//var fP = "estado = 'PTE CONFECCION' AND codconfeccionista IS NULL";;
	var fO = filtro;
	var fP = filtro;
	if(filtrosCheck && filtrosCheck != "") {
		fO += " AND (" + filtrosCheck + ")";
		//fP += " AND (" + filtrosCheck + ")";
	}

	if(codBobina && codBobina != "") {
		fO += " AND codorden IN (SELECT codordenproduccion FROM v_oppiezasroll where codbobina = '" + codBobina + "')";
		fP += " AND codorden IN (SELECT codordenproduccion FROM v_oppiezasroll where codbobina = '" + codBobina + "')";
	}

	

	var codPreparaMat = this.child("ledCodPreparaMat").text;
	if (codPreparaMat && codPreparaMat != "") {
		fO += (" AND (codpreparamat <> '" + codPreparaMat + "' OR codpreparamat IS NULL)")
		fP += (" AND codpreparamat = '" + codPreparaMat + "'")
	} else {
		fP = "false";
	}
	debug("fP " + fP);
	debug("fO " + fO);
	this.child("tdbOrdenes").cursor().setMainFilter(fO);
	this.child("tdbOrdenes").refresh();

	this.child("tdbOrdenesPrep").cursor().setMainFilter(fP);
	this.child("tdbOrdenesPrep").refresh();
}

function oficial_verificaUsuario()
{
  var _i = this.iface;
  var cursor = this.child("tdbOrdenes").cursor();
	var idUsuario = _i.usuarioActual_;
  if (!idUsuario) {
		_i.tbnCambiarUsuario_clicked()
		if (!_i.usuarioActual_) {
			sys.warnMsgBox(sys.translate("No ha establecido el usuario"));
			return false;
		}
		idUsuario = _i.usuarioActual_;
  }
  return true;
}

function oficial_tdbOrdenes_recordChoosed()
{
  var _i = this.iface;
  var cursor = this.child("tdbOrdenes").cursor();
	
	if (!_i.verificaUsuario()) {
		return;
	}
	var row = this.child("tdbOrdenes").currentRow();
	var codPreparaActual = cursor.valueBuffer("codpreparamat");
	if (codPreparaActual) {
		var res = MessageBox.warning(sys.translate("La orden seleccionada ya est� asociada al grupo de preparaci�n %1.\n�Desea continuar?").arg(codPreparaActual), MessageBox.Yes, MessageBox.No, "AbanQ");
		if (res != MessageBox.Yes) {
			return;
		}
	}
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al crear el registro de preparaci�n");
	oParam.codOrden = cursor.valueBuffer("codorden");
	oParam.codPreparaMat = this.child("ledCodPreparaMat").text;
	if (AQUtil.sqlSelect("em_preparacionesmat", "codpreparamat", "codpreparamat = '" + oParam.codPreparaMat + "' AND materialconfok")) {
		sys.warnMsgBox(sys.translate("La preparaci�n %1 ya est� marcada como Material Listo.\nNo puede a�adir m�s �rdenes").arg(oParam.codPreparaMat));
		return false;
	}
	var f = new Function("oParam", "return formem_preparacionmat.iface.asociaOrden(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	
	this.child("ledCodPreparaMat").text = oParam.codPreparaMat;
	_i.filtra();
	_i.controlModo();
	this.child("tdbOrdenes").setCurrentRow(row);
	return true;
}

function oficial_controlModo()
{
	var codPreparaMat = this.child("ledCodPreparaMat").text;
	if (codPreparaMat && codPreparaMat != "") {
		this.child("ledCodPreparaMat").enabled = false;
		this.child("tbnBuscaPrep").on = true;
	} else {
		this.child("ledCodPreparaMat").enabled = true;
		this.child("tbnBuscaPrep").on = false;
		this.child("ledCodPreparaMat").setFocus();
	}
}

function oficial_asociaOrden(oParam)
{
	var _i = this.iface;
	
	var ahora = new Date;
	var codOrden = oParam.codOrden;
	var codPreparaMat = oParam.codPreparaMat;
	
	if (!codPreparaMat || codPreparaMat == "") {
		var curPM = new FLSqlCursor("em_preparacionesmat");
		curPM.setModeAccess(curPM.Insert);
		curPM.refreshBuffer();
		codPreparaMat = AQUtil.nextCounter("codpreparamat", curPM);
		oParam.codPreparaMat = codPreparaMat;
		curPM.setValueBuffer("codpreparamat", codPreparaMat);
		curPM.setValueBuffer("fecha", ahora.toString().left(10));
		curPM.setValueBuffer("iduser",  _i.usuarioActual_);
		if (!curPM.commitBuffer()) {
			return false;
		}
	}
	if (codPreparaMat && codPreparaMat.length == 8) {
		var oP = AQUtil.sqlSelect("pr_ordenesproduccion", "ordenpremat", "codpreparamat = '" + codPreparaMat + "' ORDER BY ordenpremat DESC");
		oP = oP ? oP : 0;
		if (!AQSql.update("pr_ordenesproduccion", ["codpreparamat", "ordenpremat" ], [codPreparaMat, ++oP], "codorden = '" + codOrden + "'")) {
			return false;
		}
	}
	return true;
}

function oficial_quitaOrden(oParam)
{
	var _i = this.iface;
	
	var ahora = new Date;
	var codOrden = oParam.codOrden;
	var codPreparaMat = oParam.codPreparaMat;
	
	if (codPreparaMat && codPreparaMat.length == 8) {
		var curOrden = new FLSqlCursor("pr_ordenesproduccion");
		curOrden.select("codorden = '" + codOrden + "'");
		if (!curOrden.first()) {
			return false;
		}
		curOrden.setModeAccess(curOrden.Edit);
		curOrden.refreshBuffer();
		curOrden.setNull("codpreparamat");
		if (!curOrden.commitBuffer()) {
			return false;
		}
	}
	return true;
}

function oficial_tdbOrdenesPrep_recordChoosed()
{
	var _i = this.iface;
  var cursor = this.child("tdbOrdenesPrep").cursor();
	var row = this.child("tdbOrdenesPrep").currentRow();
	if (!_i.verificaUsuario()) {
		return;
	}
	
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al crear el registro de preparaci�n");
	oParam.codOrden = cursor.valueBuffer("codorden");
	oParam.codPreparaMat = this.child("ledCodPreparaMat").text;
	if (AQUtil.sqlSelect("em_preparacionesmat", "codpreparamat", "codpreparamat = '" + oParam.codPreparaMat + "' AND materialconfok")) {
		sys.warnMsgBox(sys.translate("La preparaci�n %1 ya est� marcada como Material Listo.\nNo puede quitar �rdenes").arg(oParam.codPreparaMat));
		return false;
	}
	var f = new Function("oParam", "return formem_preparacionmat.iface.quitaOrden(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	
	this.child("ledCodPreparaMat").text = oParam.codPreparaMat;
	_i.filtra();
	this.child("tdbOrdenesPrep").setCurrentRow(row);
	return true;
	
}

function oficial_tbnBorraFiltro_clicked()
{
	var _i = this.iface;
	
	this.child("ledCodPreparaMat").text = "";
	this.child("ledCodPreparaMat").setFocus();
	_i.filtra();
	_i.controlModo();
}

// function oficial_formatoTabla(tabla)
// {
// 	var dtb = this.mainWidget().child(tabla).tableRecords();
// 	dtb.defaultRowHeight = flprodppal.iface.pub_alturaFilasProd();
// 	dtb.setNumRows(0);
//   dtb.setNumRows(dtb.numRows());
// 	
// 	dtb.setLeftMargin(0);
//   dtb.verticalHeader().hide();
// 	
// 	dtb.verticalScrollBar().minimumWidth = 25;
//   dtb.horizontalScrollBar().minimumWidth = 25;
// 
// }

function oficial_ordenaCols()
{
	var _i = this.iface;
	
	var oCO = ["codorden", "codpreparamat", "fecha", "totaluds", "subfamilia", "dibujo"];
	var oCP = ["codorden", "codpreparamat", "fecha", "totaluds", "subfamilia", "dibujo"];
	
	flprodppal.iface.pub_formatoTablaProd(this.mainWidget().child("tdbOrdenes").tableRecords());
	flprodppal.iface.pub_formatoTablaProd(this.mainWidget().child("tdbOrdenesPrep").tableRecords());
	
	var tdbOrdenesPrep = this.child("tdbOrdenesPrep");
	var dtbOrdenesPrep = this.mainWidget().child("tdbOrdenesPrep").tableRecords();
	
	var oCAncho = [["ordenpremat", 50], ["codorden", 170], ["codpreparamat", 150]];
	for (var c = 0; c < oCAncho.length; c++) {
		this.child("tdbOrdenes").setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
		tdbOrdenesPrep.setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
	this.child("tdbOrdenes").setOrderCols(oCO);
	tdbOrdenesPrep.setOrderCols(oCP);
	
	tdbOrdenesPrep.autoSortColumn = false;
	var hHeader = dtbOrdenesPrep.horizontalHeader();
  hHeader.setClickEnabled(false);
  hHeader.setSortIndicator(-1, AQS.Ascending);
	dtbOrdenesPrep.setSort(["ordenpremat ASC"]);
	dtbOrdenesPrep.refresh(AQS.RefreshData);
}

function oficial_tbnInforme_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codPreparaMat = this.child("ledCodPreparaMat").text;
	if (!codPreparaMat || codPreparaMat == "") {
		sys.warnMsgBox(sys.translate("Debe indicar el c�digo de preparaci�n"));
		return;
	}
	var oParam = _i.dameParamInforme(codPreparaMat);
	if (!oParam) {
		return;
	}
	
	flfactinfo.iface.pub_lanzaInforme(cursor, oParam);
	if (!AQSql.update("em_preparacionesmat", ["impreso"], [true], "codpreparamat = '" + codPreparaMat + "'")) {
		return false;
	}

	var idUsuarioMod = sys.nameUser();
	var fechaMod = flfactppal.iface.dameFechaActual();
	var horaMod = flfactppal.iface.dameHoraActual();

	AQSql.update("pr_ordenesproduccion", ["idusuariomodiagmat","fechamodiagmat","horamodiagmat"], [idUsuarioMod,fechaMod,horaMod], "codpreparamat = '" + codPreparaMat + "'");
}

function oficial_dameParamInforme(codPreparaMat)
{
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	
	oParam.whereFijo = "em_preparacionesmat.codpreparamat = '" + codPreparaMat + "'";
	if (this.child("chkInfoResumido").checked) {
		oParam.nombreInforme = "pr_i_preparamat_res";
		oParam.groupBy = "em_preparacionesmat.codpreparamat, movistock.referencia, articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion, articulos.codtamanoem, articulos.codcolorem, empresa.nombre, articuloscomp.componormal, articuloscomp.ancho";
		oParam.orderBy = "articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion";
	} else {
		oParam.nombreInforme = "pr_i_preparamat";
		oParam.groupBy = "em_preparacionesmat.codpreparamat, pr_ordenesproduccion.codorden, pr_ordenesproduccion.ordenpremat, movistock.referencia, articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion, articulos.codtamanoem, articulos.codcolorem, empresa.nombre, lotesstock.canlote,articuloscomp.componormal, articuloscomp.ancho";
		oParam.orderBy = "articulos.codfamilia, articulos.codsubfamilia, articulos.descripcion, pr_ordenesproduccion.ordenpremat";
	}
	var listaFamEstampado = flfactalma.iface.pub_dameFamEstampado();
	var listaFamCrudo = flfactalma.iface.pub_dameFamCrudo();
// 	oParam.whereFijo += " AND articulos.codfamilia NOT IN (" + listaFamEstampado + ") AND articulos.codfamilia NOT IN (" + listaFamCrudo+ ")";
	oParam.whereFijo += " AND (articuloscomp.idseccion = '9' OR articuloscomp.id IS NULL OR articuloscomp.componormal = 'BIES')";
		
	return oParam;
}

function oficial_tbnEtiquetas_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codPreparaMat = this.child("ledCodPreparaMat").text;
	if (!codPreparaMat || codPreparaMat == "") {
		sys.warnMsgBox(sys.translate("Debe indicar el c�digo de preparaci�n"));
		return;
	}
	var w = "op.codpreparamat = '" + codPreparaMat + "'";
	var oB = this.child("chkEtiOrdenInverso").checked ? "ordenpremat DESC, referencia DESC" : "ordenpremat, referencia";
	formpr_ordenesproduccion.iface.pub_imprimeEtiquetas(w + " ORDER BY " + oB);
	if (!AQSql.update("em_preparacionesmat", ["etiquetas"], [true], "codpreparamat = '" + codPreparaMat + "'")) {
		return false;
	}
}

function oficial_listaOrdenes(nodo, campo)
{
	var _i = this.iface;
	var sWhere = "";
	if((_i.codOrdenDesde_ && _i.codOrdenDesde_ != "") || (_i.codOrdenHasta_ && _i.codOrdenHasta_ != "")) {
		sWhere = "NOT materialconfok AND pr_ordenesproduccion.estado <> 'TERMINADA'";
		if(_i.codOrdenDesde_ != "VACIO") {
			if(sWhere && sWhere != "") {
				sWhere += " AND ";
			}
			sWhere += "codorden >= '" + _i.codOrdenDesde_ + "'";
		}
		if(_i.codOrdenHasta_ != "VACIO") {
			if(sWhere && sWhere != "") {
				sWhere += " AND ";
			}
			sWhere += "codorden <= '" + _i.codOrdenHasta_ + "'";
		}
		if(sWhere == "") {
			sWhere = "1 = 1";
		}
		sWhere += " ORDER BY codorden";

	} else {
		var codPreparaMat = nodo.attributeValue("em_preparacionesmat.codpreparamat");
		sWhere = "codpreparamat = '" + codPreparaMat + "' ORDER BY ordenpremat";
	}
	
	var q = new AQSqlQuery;
	q.setSelect("codorden");
	q.setFrom("pr_ordenesproduccion");
	q.setWhere(sWhere);
	//q.setWhere("codpreparamat = '" + codPreparaMat + "' ORDER BY ordenpremat");
	if (!q.exec()) {
		return;
	}
	var lista = "";
	while (q.next()) {
		lista += lista != "" ? ", " : "";
		lista += q.value("codorden");
	}

	//_i.codOrdenDesde_ = "";
	//_i.codOrdenHasta_ = "";
	return lista;
}

function oficial_tbnAceptar_clicked()
{
	var _i = this.iface;
	
	var codPreparaMat = this.child("ledCodPreparaMat").text;
	if (!codPreparaMat || codPreparaMat == "") {
		sys.warnMsgBox(sys.translate("Debe indicar el c�digo de preparaci�n"));
		return;
	}
	if (AQUtil.sqlSelect("em_preparacionesmat", "codpreparamat", "codpreparamat = '" + codPreparaMat + "' AND materialconfok")) {
		sys.warnMsgBox(sys.translate("La preparaci�n %1 ya est� marcada como Material Listo").arg(codPreparaMat));
		return false;
	}	
	var res;
	if (AQUtil.sqlSelect("em_preparacionesmat", "codpreparamat", "codpreparamat = '" + codPreparaMat + "' AND NOT impreso")) {
		res = MessageBox.warning(sys.translate("La preparaci�n %1 no est� marcada como impresa.\n�Desea continuar?").arg(codPreparaMat), MessageBox.Yes, MessageBox.No, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	if (AQUtil.sqlSelect("em_preparacionesmat", "codpreparamat", "codpreparamat = '" + codPreparaMat + "' AND NOT etiquetas")) {
		res = MessageBox.warning(sys.translate("No ha impreso las etiqutas de la preparaci�n %1.\n�Desea continuar?").arg(codPreparaMat), MessageBox.Yes, MessageBox.No, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	res = MessageBox.information(sys.translate("Va a marcar como Material Listo las �rdenes seleccionadas.\n�Est� seguro?"), MessageBox.Yes, MessageBox.No, "AbanQ");
	if (res != MessageBox.Yes) {
		return;
	}
	var oParam = new Object;
	oParam.errorMsg = sys.translate("Error al marcar las �rdenes como Material Listo");
	oParam.codPreparaMat = codPreparaMat;
	var f = new Function("oParam", "return formem_preparacionmat.iface.marcaMaterialOk(oParam)");
	if (!sys.runTransaction(f, oParam)) {
		return false;
	}
	sys.infoMsgBox(sys.translate("Ordenes marcadas correctamente"));
	
	this.child("ledCodPreparaMat").text = "";
	_i.filtra();
	_i.controlModo();
	return;
}

function oficial_marcaMaterialOk(oParam)
{
	var _i = this.iface;
	
	var ahora = new Date;
	var codPreparaMat = oParam.codPreparaMat;
	
	if (!AQSql.update("pr_ordenesproduccion", ["materialconfok", "idusuariomatok", "fechamatok", "horamatok"], [true, _i.usuarioActual_, ahora.toString().left(10), ahora.toString().right(8)], "codpreparamat = '" + codPreparaMat + "'")) {
		return false;
	}
	if (!AQSql.update("em_preparacionesmat", ["materialconfok"], [true], "codpreparamat = '" + codPreparaMat + "'")) {
		return false;
	}
	return true;
}

function oficial_dameFechaInforme(nodo, campo)
{
	var _i = this.iface;
	var f = new Date();
	var fF = _i.formateaFechaInforme(f);
	return fF;
}

function oficial_formateaFechaInforme(fecha)
{
	var _i = this.iface;

	var anio = fecha.getYear();
	var mes = fecha.getMonth();
	var dia = fecha.getDate();
	var hora = fecha.getHours();
	var minuto = fecha.getMinutes();

	var arrayMeses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

	if (hora < 10) {
		hora = "0" + hora;
	}

	if (minuto < 10) {
		minuto = "0" + minuto;
	}

	return dia + " de " + arrayMeses[mes-1] + " de " + anio + " - " + hora + ":" + minuto;
}

function oficial_tbnInformeMat_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codPreparaMat = this.child("ledCodPreparaMat").text;
	if (!codPreparaMat || codPreparaMat == "") {
		sys.warnMsgBox(sys.translate("Debe indicar el c�digo de preparaci�n"));
		return;
	}
	
	var oP = new Object;
	oP.codpreparamat= codPreparaMat;
	formpr_ordenesproduccion.iface.pub_imprimeOrdenMat(oP);
}

function oficial_tbnAplicarFiltros_clicked()
{
	var _i = this.iface;
	_i.filtra();

}

function oficial_tbnBuscarBobina_clicked()
{
	var _i = this.iface;
	var f = new FLFormSearchDB("em_busbobinapiezaroll");	
	f.setMainWidget();
	//f.cursor().setMainFilter(filtro);
	var codBobina = f.exec("codbobina");
	this.child("txtCodBobina").text = codBobina;

}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
