# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa
import json

# lotesstock = qsa.class_("em_ubicaciones")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */ 
# UBICACIONES 
class Oficial(Base):

    def get(self, params, username=None):

        mapa = self.get_mapa()
        obj = qsa.from_project("formAPI").get_resources('em_ubicaciones', params, mapa, username)

        return obj

    # def cortarPieza(self, params, username=None):
    #     print(params)
    #     obj = qsa.from_project("formau_automata").iface.cortaPiezaJson(params)
    #     return True


    def get_mapa(self):
        return {
            'join': 'em_ubicaciones',
            'order': 'em_codubicacion',
            'map': {
                'em_ubinave': {'field': 'em_ubicaciones.em_ubinave', 'type': 'string'},
                'em_ubipasillo': {'field': 'em_ubicaciones.em_ubipasillo', 'type': 'string'},
                'em_ubiestante': {'field': 'em_ubicaciones.em_ubiestante', 'type': 'string'},
                'em_ubialtura': {'field': 'em_ubicaciones.em_ubialtura', 'type': 'string'},
                'em_codubicacion': {'field': 'em_ubicaciones.em_codubicacion', 'type': 'string'}
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
