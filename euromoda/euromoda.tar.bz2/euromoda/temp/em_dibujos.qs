/***************************************************************************
                 em_dibujos.qs  -  description
                             -------------------
    begin                : mar ago 16 2011
    copyright            : (C) 2011 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN:String):String { return this.ctx.interna_calculateField(fN); }
	function calculateCounter() { return this.ctx.interna_calculateCounter(); }
	function validateForm():Boolean {return this.ctx.interna_validateForm();}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var aColores_;
	function oficial( context ) { interna( context ); } 
	function tbnPonColores_clicked() {
		return this.ctx.oficial_tbnPonColores_clicked();
	}
	function cargaColores() {
		return this.ctx.oficial_cargaColores();
	}
	function validarDescripcion() {
		return this.ctx.oficial_validarDescripcion();
	}
	function conectar() {
		return this.ctx.oficial_conectar();
	}
	function controlBloqueo() {
		return this.ctx.oficial_controlBloqueo();
	}
	function pushButtonCancel_clicked()
  {
    return this.ctx.oficial_pushButtonCancel_clicked();
  }
  function filtraTamanos()
  {
    return this.ctx.oficial_filtraTamanos();
  }
  function cargaTamanos()
  {
    return this.ctx.oficial_cargaTamanos();
  }
  function tdbTamanosSubfam_primaryKeyToggled(idTS, sel)
  {
    return this.ctx.oficial_tdbTamanosSubfam_primaryKeyToggled(idTS, sel);
  }
  function tdbDibujosSubfamilia_bufferCommited()
  {
    return this.ctx.oficial_tdbDibujosSubfamilia_bufferCommited();
  }
  	function formateaDescripcionSelect(d)
  	{
    	return this.ctx.oficial_formateaDescripcionSelect(d);
  	}
  	function validaPanotCont()
  	{
  		return this.ctx.oficial_validaPanotCont();
  	}
  	function tbnSubir() {
		return this.ctx.oficial_tbnSubir();
	}
	function tbnBajar() {
		return this.ctx.oficial_tbnBajar();
	}
	function tbnExploraCoord_clicked() {
		return this.ctx.oficial_tbnExploraCoord_clicked();
	}
	function labelsTablaCoord() {
		return this.ctx.oficial_labelsTablaCoord();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/*function interna_calculateCounter()
{
	var cursor = this.cursor();
	var num = AQUtil.quickSqlSelect("em_dibujos", "coddibujoem", "1 = 1 ORDER BY coddibujoem DESC");
	num = num ? num : 0;
	return ++num;
}*/


function interna_calculateCounter()
{	
	var prefijo = "DD";
	var ultimoDibujo = AQUtil.sqlSelect("secuenciaslotes","valor","prefijo = '" + prefijo + "'");

	if(!ultimoDibujo) {
		var idUltimo = AQUtil.sqlSelect("em_dibujos", "coddibujoem", "1=1 ORDER BY coddibujoem DESC");

		if (idUltimo) {
			ultimoDibujo = idUltimo
		} else {
			ultimoDibujo = 0;
		}
		ultimoDibujo += 1;
		AQUtil.sqlInsert("secuenciaslotes","prefijo,valor",prefijo + "," + ultimoDibujo)
	} else {
		ultimoDibujo += 1;
		AQUtil.sqlUpdate("secuenciaslotes","valor",ultimoDibujo,"prefijo = '" + prefijo + "'");
	}

	return ultimoDibujo;
	
}


/** \C El valor de --stockfis-- se calcula autom�ticamente para cada art�culo como la suma de existencias del art�culo en todos los almacenes.
\end */
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();	

	/*if(!cursor.action() || cursor.action() == "") {
		cursor.setAction("em_editdibujos");
	}*/
	//cursor.setAction("em_dibujos");
	debug("accion " + cursor.action());

	var cols = ["codsubfamilia", "dessubfamilia"];
	this.child("tdbDibujosSubfamilia").setOrderCols(cols);
	this.child("tdbTamanosSubfam").setColumnWidth("orden", 1);
	
	connect(this.child("tbnPonColores"), "clicked()", _i, "tbnPonColores_clicked");
	disconnect(this.child("pushButtonCancel"), "clicked()", this.obj(), "reject()");
    connect(this.child("pushButtonCancel"), "clicked()", _i, "pushButtonCancel_clicked");
	connect(this.child("tdbDibujosSubfamilia").cursor(), "bufferCommited()", _i, "tdbDibujosSubfamilia_bufferCommited");
	connect(this.child("tdbTamanosSubfam"), "primaryKeyToggled(QVariant, bool)", _i, "tdbTamanosSubfam_primaryKeyToggled");
	connect(this, "formReady()", _i, "conectar");
  	connect(this.child("tbnSubir"), "clicked()", _i, "tbnSubir");
	connect(this.child("tbnBajar"), "clicked()", _i, "tbnBajar");
	connect(this.child("tbnExploraCoord"), "clicked()", _i, "tbnExploraCoord_clicked");
	
	this.child("tbwDibujos").setTabEnabled("Plantilla", false);
	_i.labelsTablaCoord();
}

function interna_calculateField(fN)
{
	return 0;
}

function interna_validateForm()
{
	var _i = this.iface;	
	if (!_i.validarDescripcion()) {
		return false;
	}
	if (!_i.controlBloqueo()) {
		return false;
	}
	if(!_i.validaPanotCont()) {
		return false;
	}
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_conectar()
{
	var _i = this.iface;
	connect(this.child("tdbDibujosSubfamilia").cursor(), "newBuffer()", _i, "filtraTamanos()");
	_i.filtraTamanos();
}

function oficial_formateaDescripcionSelect(d)
{
	if (!d || d == "") {
		return "";
	}
	var s = "";
	var c;
	var sD = d.toString();
	for (var i = 0; i < sD.length; i++) {
		c = sD.charAt(i);
		s += c.toString();
		if (c == "'") {
			s += c.toString();
		}
	}
	return s;
}

function oficial_validarDescripcion()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var descripcion = cursor.valueBuffer("descripcion");
	if (!descripcion || descripcion == "") {
		MessageBox.warning(sys.translate("Debe indicar la descripci�n"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	descripcion = descripcion.toUpperCase();
	var idDibujo = cursor.valueBuffer("coddibujoem");
	
	var descripcionF = _i.formateaDescripcionSelect(descripcion);
	var idDibujoRep = AQUtil.sqlSelect("em_dibujos", "coddibujoem", "UPPER(descripcion) = '" + descripcionF + "' AND coddibujoem <> " + idDibujo);
	if (idDibujoRep) {
		var res = MessageBox.warning(sys.translate("Ya existe otro dibujo (c�digo %1) con la descripci�n:\n%2\n�Desea continuar?").arg(idDibujoRep).arg(descripcion), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
		if (res != MessageBox.Yes) {
			return false;
		}
	}
	
	return true;
}

function oficial_tbnPonColores_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  if (cursor.modeAccess() == cursor.Insert) {
  	if(this.child("tdbDibujosColor").cursor().cursorRelation()) {
	    if (!this.child("tdbDibujosColor").cursor().commitBufferCursorRelation()) {
	      return false;
	    }
	}
  }

  _i.aColores_ = false;
  if (!_i.cargaColores()) {
    return false;
  }

  var f = new FLFormSearchDB("em_selcoloresdibujo");
	var c = f.cursor();
// 	c.setMainFilter("codsubfamilia = '" + cursor.valueBuffer("codsubfamilia") + "'");
  f.setMainWidget();
  f.exec();
  if (!f.accepted()) {
    return;
  }
  if (!_i.aColores_) {
    return;
  }
  var codDibujoEm = cursor.valueBuffer("coddibujoem");
  if (!AQSql.del("em_dibujoscolor", "coddibujoem = " + codDibujoEm)) {
    return false;
  }
//   var codSubfamilia = cursor.valueBuffer("codsubfamilia");
// 	var codDibujo = cursor.valueBuffer("coddibujoem");
  for (var i = 0; i < _i.aColores_.length; i++) {
    if (!AQSql.insert("em_dibujoscolor", ["coddibujoem", "codcolorem"], [codDibujoEm, _i.aColores_[i]])) {
      return false;
    }
  }
  this.child("tdbDibujosColor").refresh();
}

function oficial_cargaColores()
{
  var cursor = this.cursor();
  var _i = this.iface;

//   var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codDibujoEm = cursor.valueBuffer("coddibujoem");
  var q = new FLSqlQuery();
  q.setTablesList("em_dibujoscolor");
  q.setSelect("codcolorem");
  q.setFrom("em_dibujoscolor");
  q.setWhere("coddibujoem = " + codDibujoEm);
  q.setForwardOnly(true);
  if (!q.exec()) {
    return false;
  }
  _i.aColores_ = [];
  var i = 0;
  while (q.next()) {
    _i.aColores_[i++] = q.value("codcolorem");
  }
  return true;
}

function oficial_controlBloqueo()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codProveedor = cursor.valueBuffer("codproveedor");
  if (codProveedor && codProveedor != "") {
    if (!flfacturac.iface.pub_controlBloqueoProveedor(codProveedor, "Todo")) {
      return false;
    }
  }
	return true;
}

function oficial_pushButtonCancel_clicked()
{
  var res = MessageBox.warning(sys.translate("�Desea cancelar los cambios realizados hasta ahora?"), MessageBox.Yes, MessageBox.No, MessageBox.NoButton, "AbanQ");
  if (res != MessageBox.Yes) {
    return;
  }

   this.obj().reject();
}

function oficial_filtraTamanos()
{
	var _i = this.iface;
	
	var tT = this.child("tdbTamanosSubfam");
	var tS = this.child("tdbDibujosSubfamilia");
	tT.clearChecked();
	
	var filtro = "1 = 2";
	var curS = tS.cursor();

	var codSubfamilia = curS.valueBuffer("codsubfamilia");
	if (codSubfamilia) {
		filtro = "codsubfamilia = '" + codSubfamilia + "'";
	}
	tT.cursor().setMainFilter(filtro);
	tT.refresh();
	_i.cargaTamanos();
}

function oficial_cargaTamanos()
{
	var _i = this.iface;
	
	var tT = this.child("tdbTamanosSubfam");
	var tS = this.child("tdbDibujosSubfamilia");
	var curS = tS.cursor();
	var idDibujoSubFam = curS.valueBuffer("iddibujosubfam");
debug("idDibujoSubFam " + idDibujoSubFam);
	if (!idDibujoSubFam) {
debug("Sale");
		return;
	}
	var codSubfamilia = curS.valueBuffer("codsubfamilia");

	var q = new AQSqlQuery;
	q.setSelect("codtamanoem");
	q.setFrom("em_dibujostamsub");
	q.setWhere("iddibujosubfam = " + idDibujoSubFam);
	if (!q.exec()) {
		return;
	}
debug(q.sql());
	var idTS;
	while (q.next()) {
		idTS = AQUtil.sqlSelect("em_tamanossubfam", "idtamanosubfam", "codtamanoem = '" + q.value("codtamanoem") + "' AND codsubfamilia = '" + codSubfamilia + "'");
debug("idTS " + idTS );
		if (idTS) {
			tT.setPrimaryKeyChecked(idTS, true);
		}
	}
	tT.refresh();
}

function oficial_tdbTamanosSubfam_primaryKeyToggled(idTS, sel)
{
	var _i = this.iface;
	
	if (!idTS || idTS == false) {
		return;
	}
	
	var tS = this.child("tdbDibujosSubfamilia");
	var curS = tS.cursor();
	var cursor = this.cursor();
	
	var codSubfamilia = curS.valueBuffer("codsubfamilia");
	if(!codSubfamilia || codSubfamilia == "") {
		return;
	}
	var codTamano = AQUtil.sqlSelect("em_tamanossubfam", "codtamanoem", "idtamanosubfam = " + idTS);
	if(!codTamano || codTamano == "") {
		return;
	}
	var codDibujo = cursor.valueBuffer("coddibujoem");
	if(!codDibujo || codDibujo == "") {
		/// lo cojo del formulario porque al abrirlo con un formsearch por alguna raz�n lo coge bien del cursor
		codDibujo = this.child("fdbCodDibujoEM").value();
		if(!codDibujo || codDibujo == "") {
			return;
		}
	}
	var idDibujoSubFam = curS.valueBuffer("iddibujosubfam");
	if(!idDibujoSubFam || idDibujoSubFam == "") {
		return;
	}


	if (sel) {
		if (AQUtil.sqlSelect("em_dibujostamsub", "iddibujotamsub", "coddibujoem = '" + codDibujo + "' AND codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "'")) {
			return true;
		}
		var curDTS = new FLSqlCursor("em_dibujostamsub");
		curDTS.setModeAccess(curDTS.Insert);
		curDTS.refreshBuffer();
		curDTS.setValueBuffer("coddibujoem", codDibujo);
		curDTS.setValueBuffer("codsubfamilia", codSubfamilia);
		curDTS.setValueBuffer("codtamanoem", codTamano);
		curDTS.setValueBuffer("iddibujosubfam", idDibujoSubFam);
		if (!curDTS.commitBuffer()) {
			return false;
		}
	} else {
		if (!AQSql.del("em_dibujostamsub", "coddibujoem = '" + codDibujo + "' AND codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "'")) {
			return false;
		}
	}
}

function oficial_tdbDibujosSubfamilia_bufferCommited()
{
	var _i = this.iface;
	_i.cargaTamanos();
}
function oficial_validaPanotCont()
{
	var cursor = this.cursor();
	if (cursor.valueBuffer("panotcont") == " ") {
		cursor.setNull("panotcont");
	}
	return true;
}

function oficial_tbnSubir()
{
	var cursor = this.child("tdbCoordinados").cursor();
	if(cursor.size() < 2){
		return;
	}	
	var row = this.child("tdbCoordinados").currentRow();

	if (!flfacturac.iface.intercambiarOrden(cursor, -1, "coddibujoem")) {
		return false;
	}
	this.child("tdbCoordinados").refresh();
	row += -1;
	this.child("tdbCoordinados").setCurrentRow(row);
}

function oficial_tbnBajar()
{
	var cursor = this.child("tdbCoordinados").cursor();

	if(cursor.size() < 2){
		return;
	}	

	var row = this.child("tdbCoordinados").currentRow();

	if (!flfacturac.iface.intercambiarOrden(cursor, 1, "coddibujoem")) {
		return false;
	}
	this.child("tdbCoordinados").refresh();
	row += 1;
	this.child("tdbCoordinados").setCurrentRow(row);
}

function oficial_tbnExploraCoord_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codDibujo = cursor.valueBuffer("coddibujoem");
	debug("codDibujo: "+codDibujo);
	if(!codDibujo || codDibujo == "") {
		return false;
	}
	var f = new FLFormSearchDB("v_coordinados");
	var c = f.cursor();
	c.setMainFilter("coddibestamp = '" + codDibujo + "'");
	f.setMainWidget();
	f.exec();
	if (!f.accepted()) {
		return;
	}
	return true;
}

function oficial_labelsTablaCoord()
{
	/*var t = this.child("tdbCoordinados").obj();
	var cH = ["L","ColorDib","CodCoord","DibujoCoord","ColorCoord","Componente","Colec","ColDescripcion","FamCod","FamDescripcion","SubFaCod","SubFaDescripcion","Tama�o"];
	t.setColumnLabels("*", cH.join("*"));*/
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
