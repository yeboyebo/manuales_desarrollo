/***************************************************************************
				 em_ubicaciones.qs  -  description
							 -------------------
	begin                : vie jul 17 2020
	copyright            : (C) 2020 by YeboYebo S.L.U
	email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function calculateField(fN) {
		return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); }
	function iniciaValoresCursor(cursor) {
		return this.ctx.oficial_iniciaValoresCursor(cursor);
	}	
	function bufferChanged(fN) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function bChPreCursor(fN, cursor) {
		return this.ctx.oficial_bChPreCursor(fN, cursor);
	}
	function bChCursor(fN, cursor) {
		return this.ctx.oficial_bChCursor(fN, cursor);
	}
	function bChPostCursor(fN, cursor) {
		return this.ctx.oficial_bChPostCursor(fN, cursor);
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function validateCursor(cursor) {
		return this.ctx.oficial_validateCursor(cursor);
	} 
	function creaCodigoUbicacion(cursor) {
		return this.ctx.oficial_creaCodigoUbicacion(cursor);
	}
	function compruebaUsado(cursor) {
		return this.ctx.oficial_compruebaUsado(cursor);
	}
	function validaCodigo(codigo) {
		return this.ctx.oficial_validaCodigo(codigo);
	}
	function validaCodigoRepetido(codigo) {
		return this.ctx.oficial_validaCodigoRepetido(codigo);
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE //////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE //////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////

function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	sys.disableObj(this, "fdbEmCodUbicacion");
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");

	if(cursor.modeAccess() == cursor.Insert) {
		_i.iniciaValoresCursor(cursor);
	}
	_i.compruebaUsado(cursor);
}

function interna_calculateField(fN)
{
	return this.iface.commonCalculateField(fN, this.cursor());
}

function interna_validateForm()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if(!_i.validateCursor(cursor)) {
		return false;
	}

	return true;
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_iniciaValoresCursor(cursor)
{
	var _i = this.iface;
	var _fP = flfactppal.iface;

	
}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();

	_i.bChPreCursor(fN, cursor);
	_i.bChCursor(fN, cursor);
	_i.bChPostCursor(fN, cursor);
}

function oficial_bChPreCursor(fN, cursor)
{
	var _i = this.iface;

}

function oficial_bChCursor(fN, cursor)
{
	var _i = this.iface;
	var _fP = flfactppal.iface;

	if (fN == "em_ubinave" || fN == "em_ubipasillo" || fN == "em_ubiestante" || fN == "em_ubialtura") {
		_fP.setValueBufferCursor(cursor, "em_codubicacion",_i.commonCalculateField("em_codubicacion",cursor));
	}
}

function oficial_bChPostCursor(fN, cursor)
{
	var _i = this.iface;
}

function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
	var valor;

	if(fN == "em_codubicacion") {
		valor = _i.creaCodigoUbicacion(cursor);
	}

	return valor;
}

function oficial_validateCursor(cursor)
{
	var _i = this.iface;

	var codigo = cursor.valueBuffer("em_codubicacion");
	if(!_i.validaCodigo(codigo)) {
		return false;
	}
	if(!_i.validaCodigoRepetido(codigo)) {
		return false;
	}
	return true;
}

function oficial_creaCodigoUbicacion(cursor)
{
	var _i = this.iface;
	var nave = cursor.valueBuffer("em_ubinave");
	var pasillo = cursor.valueBuffer("em_ubipasillo");
	var estante = cursor.valueBuffer("em_ubiestante");
	var altura = cursor.valueBuffer("em_ubialtura");

	if(nave && nave != "") {
		nave = "N" + nave;
	} else {
		nave = "N" + "xx";
	}

	if(pasillo && pasillo != "") {
		pasillo = "P" + pasillo;
	} else {
		pasillo = "P" + "xx";
	}

	if(estante && estante != "") {
		estante = "E" + estante;
	} else {
		estante = "E" + "xx";
	}

	if(altura && altura != "") {
		altura = "A" + altura;
	} else {
		altura = "A" + "xx";
	}

	valor = nave + "-" + pasillo + "-" + estante + "-" + altura;
	return valor;
}

function oficial_compruebaUsado(cursor)
{
	var codUbicacion = cursor.valueBuffer("em_codubicacion");
	if(AQUtil.sqlSelect("articulos","em_ubiactual","em_ubiactual = '" + codUbicacion + "'") || AQUtil.sqlSelect("em_articulosxubicacion","em_ubialternativa","em_ubialternativa = '" + codUbicacion + "'")) {

		sys.disableObj(this, "fdbEmUbiNave");
		sys.disableObj(this, "fdbEmUbiPasillo");
		sys.disableObj(this, "fdbEmUbiEstante");
		sys.disableObj(this, "fdbEmUbiAltura");
	}
}

function oficial_validaCodigo(codigo)
{
	

	if(!codigo || codigo == "") {
		formUI.ponMsgWarn(sys.translate("El c�digo introducido es incorrecto, por favor revise los par�metros."));
		return false;
	}
	return true;
}

function oficial_validaCodigoRepetido(codigo)
{
	if(AQUtil.sqlSelect("em_ubicaciones","em_codubicacion","em_codubicacion = '" + codigo + "'")) {
		formUI.ponMsgWarn(sys.translate("Ya existe una ubicaci�n con el c�digo %1, por favor modifique los par�metros").arg(valor));		
		return false;
	}
	return true;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
