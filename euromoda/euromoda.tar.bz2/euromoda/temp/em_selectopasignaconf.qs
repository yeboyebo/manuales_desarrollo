/***************************************************************************
                 em_selectopasignaconf.qs  -  description
                             -------------------
    begin                : vie abr 20 2012
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_declaration interna */
//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var tdbRecords_;
	function oficial( context ) { interna( context ); } 
	function pbnSeleccionar_clicked() {
		return this.ctx.oficial_pbnSeleccionar_clicked();
	}
	function marcaArticulos() {
		return this.ctx.oficial_marcaArticulos();
	}
	function ordenarCols() {
		return this.ctx.oficial_ordenarCols();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C
\end */
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();

	_i.tdbRecords_ = this.child("tableDBRecords");
	_i.ordenarCols();
	
	disconnect(this.child("pushButtonAccept"), "clicked()", this, "accept()");
	connect(this.child("pushButtonAccept"), "clicked()", _i, "pbnSeleccionar_clicked()");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_ordenarCols()
{
	var _i = this.iface;
  var cols = ["codorden", "emobservaciones", "fecha", "codasigconf", "codconfeccionista", "nombreconfeccionista", "materialconfok", "subfamilia", "dibujo", "fechaentrega", "estado", "totaluds", "totallotes", "codpedidocli", "codpedidocli", "fechadesde", "fechahasta", "atiempo", "impresoorden", "impresomaterial", "codpedidoconf", "codpedidofaltas", "codalbaranconf", "codalbaranfaltas", "codcliente", "nombrecliente"];
	
	var oCAncho = [["codorden", 90], ["fecha", 80], ["codasigconf", 70], ["codconfeccionista", 60], ["materialconfok", 50], ["fechaentrega", 80], ["totaluds", 60], ["totallotes", 60], ["codpedidocli", 90], ["fechadesde", 80], ["fechahasta", 80], ["atiempo", 30], ["impresoorden", 40], ["impresomaterial", 40], ["codpedidoconf", 90], ["codpedidofaltas", 90], ["codalbaranconf", 90], ["codalbaranfaltas", 90], ["codcliente", 60]];
	for (var c = 0; c < oCAncho.length; c++) {
		_i.tdbRecords_.setColumnWidth(oCAncho[c][0], oCAncho[c][1]);
	}
	
  _i.tdbRecords_.setOrderCols(cols);
  _i.tdbRecords_.refresh();
}

function oficial_pbnSeleccionar_clicked()
{
	var arrayOP = this.child("tableDBRecords").primarysKeysChecked();
// 	var listaOPs = "";
// 	for (var i = 0; i < arrayOP.length; i++) {
// 		if (listaOPs && listaOPs != "") {
// 			listaOPs += ",";
// 		}
// 		listaOPs += "'" + arrayOP[i] + "'";
// 	}

	formRecordem_asignacionesconf.iface.pub_ponListaOPSel(arrayOP);
	this.accept();
}

function oficial_marcaArticulos()
{
	var _i = this.iface;
	var cursor = this.cursor();
		
	var q = new FLSqlQuery();
	q.setSelect("referencia");
	q.setFrom("articulos");
	
	if(!q.exec()){
		return;
	}
	
	if(q.size() > 0){
		AQUtil.createProgressDialog(sys.translate("Marcando TODOS los art�culos..."), q.size());
		var i = 0;
		
		while (q.next()) {
			AQUtil.setProgress(i++);
			this.child("tableDBRecords").setPrimaryKeyChecked(q.value("referencia"), true);
		}
		sys.AQTimer.singleShot(0, AQUtil.destroyProgressDialog);
	}
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////