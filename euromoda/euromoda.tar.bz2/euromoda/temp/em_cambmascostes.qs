/***************************************************************************
                 em_cambmascostes.qs  -  description
                             -------------------
    begin                : lun abr 14 2019
    copyright            : (C) 2019 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
	function calculateField(fN) {
		return this.ctx.interna_calculateField(fN);
	}
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var t_;
	var cSEL_,cCODCOLEC_, cDESCOLEC_, cCODFAM_, cDESFAM_, cCODSUBFAM_, cDESSUBFAM_,cORDEN_,cCODTAMA_, cCODCOLOR_, cCOSTEACT_, cCOSTENUEVO_, cCOSTEART_, cMARGENACT_, cMARGENNUEVO_, cMARGENART_, cEXIS_, cPTEREC_,cAFALTA_,cREVISAR_,cNUMREF_,cNUMREFHERC_,cNUMREFMANC_,cNUMREFHERM_,cNUMREFMANM_, cIDPLANTILLA_, cColorSel_, cColorNoSel_;	
	var modo_, filtro_;
	var cambiarMargen_, cambiarCostes_;	
	var eventWatcher_;
	var teclaPulsada_;
  	function oficial( context ) { interna( context ); } 
  	function bufferChanged(fN) {
    	return this.ctx.oficial_bufferChanged(fN);
  	}
  	function iniciarTabla() {
  		return this.ctx.oficial_iniciarTabla();
  	}
 	function pbnBuscar_clicked() {
    	return this.ctx.oficial_pbnBuscar_clicked();
  	}
  	function buscar(cursor) {
  		return this.ctx.oficial_buscar(cursor);
  	}
  	function colores() {
  		return this.ctx.oficial_colores();
  	}
  	function tblLineas_clicked(f, c) {
  		return this.ctx.oficial_tblLineas_clicked(f, c);
  	}
  	function tbnTodosSel_clicked() {
		return this.ctx.oficial_tbnTodosSel_clicked();
	}
	function tbnNingunoSel_clicked() {
		return this.ctx.oficial_tbnNingunoSel_clicked();
	}
	function colSelClicked(f) {
		return this.ctx.oficial_colSelClicked(f);
	}
	function habilitaPorModo() {
		return this.ctx.oficial_habilitaPorModo();
	}
	function cambiaModo(m) {
		return this.ctx.oficial_cambiaModo(m);
	}
	function habilitaCostes() {
  		return this.ctx.oficial_habilitaCostes();
  	}
  	function habilitaCamposCostesProd() {
  		return this.ctx.oficial_habilitaCamposCostesProd();
  	}
  	function habilitaAumentoCoste() {
		return this.ctx.oficial_habilitaAumentoCoste();
	}
	function habilitaDisminuirCoste() {
		return this.ctx.oficial_habilitaDisminuirCoste();
	}
	function habilitaAumentoMargen() {
		return this.ctx.oficial_habilitaAumentoMargen();
	}
	function habilitaDisminuirMargen() {
		return this.ctx.oficial_habilitaDisminuirMargen();
	}
	function pbnActualizaTabla_clicked() {
		return this.ctx.oficial_pbnActualizaTabla_clicked();
	}
	function pbnLimpiar_clicked() {
		return this.ctx.oficial_pbnLimpiar_clicked();
	}
	function pbnCancelar_clicked() {
    	return this.ctx.oficial_pbnCancelar_clicked();
  	}
  	function pbnAplicar_clicked() {
    	return this.ctx.oficial_pbnAplicar_clicked();
  	}
  	function calculaReferencias() {
		return this.ctx.oficial_calculaReferencias();
	}
  	function informaLabels() {
  		return this.ctx.oficial_informaLabels();
  	}
  	function dameNumRefHer(f) {
  		return this.ctx.oficial_dameNumRefHer(f);
  	}
  	function dameNumRefMan(f) {
  		return this.ctx.oficial_dameNumRefMan(f);
  	}
  	function cambiaDatos() {
  		return this.ctx.oficial_cambiaDatos();
  	}
  	function guardaLineas() {
  		return this.ctx.oficial_guardaLineas();
  	}
  	function cargaLineas() {
  		return this.ctx.oficial_cargaLineas();
  	}
  	function habilitaAplicaPlan() {
  		return this.ctx.oficial_habilitaAplicaPlan();
  	}
  	function habilitaAplicaTama() {
  		return this.ctx.oficial_habilitaAplicaTama();
  	}
  	function marcaComoAplicado() {
  		return this.ctx.oficial_marcaComoAplicado();
  	}
  	function informaLabelsAct() {
  		return this.ctx.oficial_informaLabelsAct();
  	}
  	function informaEtiquetas() {
  		return this.ctx.oficial_informaEtiquetas();
  	}
  	function permisosUsuario() {
  		return this.ctx.oficial_permisosUsuario();
  	}
  	function pushButtonAccept_clicked() {
		return this.ctx.oficial_pushButtonAccept_clicked();
	}

	function initEventFilter()  {
		return this.ctx.oficial_initEventFilter();
	}
	function eventFilter(o, e)  {
		return this.ctx.oficial_eventFilter(o, e);
	}
	function initWatch(obj) {
		return this.ctx.oficial_initWatch(obj);
	}
	function finishWatch(obj)  {
		return this.ctx.oficial_finishWatch(obj);
	}
	function tblLineas_valueChanged(f, c) {
    	return this.ctx.oficial_tblLineas_valueChanged(f, c);
  	}
	
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
	function pub_eventFilter(o, e)  {
		this.eventFilter(o, e);
	}
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.t_ = this.child("tblLineas");
	_i.cambiarMargen_ = false;
	_i.cambiarCostes_ = false;
	_i.permisosUsuario();
	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
	connect(this.child("pbnBuscar"), "clicked()", _i, "pbnBuscar_clicked");
	connect(this.child("tbnTodosSel"), "clicked()", _i, "tbnTodosSel_clicked()");
	connect(this.child("tbnNingunoSel"), "clicked()", _i, "tbnNingunoSel_clicked()");
	connect(this.child("pbnActualizaTabla"), "clicked()", _i, "pbnActualizaTabla_clicked");
	connect(this.child("pbnLimpiar"), "clicked()", _i, "pbnLimpiar_clicked");	
	connect(this.child("pbnCancelar"), "clicked()", _i, "pbnCancelar_clicked");
	connect(this.child("pbnAplicar"), "clicked()", _i, "pbnAplicar_clicked");
	connect(_i.t_, "doubleClicked(int, int)", _i, "tblLineas_clicked");
	connect(_i.t_, "valueChanged(int, int)", _i, "tblLineas_valueChanged");
	if(this.child("pushButtonAccept")) {
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
		connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	}
	_i.habilitaAplicaPlan();
	_i.habilitaAumentoCoste();
	_i.habilitaDisminuirCoste();
	_i.habilitaAumentoMargen();
	_i.habilitaDisminuirMargen();
	_i.colores();

	_i.iniciarTabla();
	_i.informaEtiquetas();
	if(cursor.modeAccess() == cursor.Insert) {		
		sys.setObjText(this, "fdbIdUsuario", sys.nameUser());			
		_i.cambiaModo("BUS");			
		_i.t_.setNumRows(0);
	} else if(cursor.modeAccess() == cursor.Edit) {			
		_i.cargaLineas();		
		_i.cambiaModo("ACT");			
	}

	 _i.initEventFilter();
	 _i.initWatch(this.mainWidget().child("tblLineas"));
}

function interna_calculateField(fN)
{

	var _i = this.iface;
	var cursor = this.cursor();
	var valor;

	switch (fN) {		
		default: {
			valor = "";
			break;
		}
	}

	return valor;
}

function interna_validateForm()
{
	return true;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_permisosUsuario()
{
	var _i = this.iface;
	var usuario = sys.nameUser();
	
	var q = new AQSqlQuery;	
	q.setSelect("em_cambiarmargenesprod,em_cambiarcostesprod");
	q.setFrom("usuarios");
	q.setWhere("idusuario = '" + usuario + "'");	
	if (!q.exec()){
		return;
	}  
	if(q.first()) {
		_i.cambiarMargen_ = q.value("em_cambiarmargenesprod");
		_i.cambiarCostes_ = q.value("em_cambiarcostesprod");		
	}
}
function oficial_iniciarTabla()
{
	var _i = this.iface;

	var c = 0, cH = [];

	_i.cSEL_ = c++;
	_i.cCODCOLEC_ = c++;
	_i.cDESCOLEC_ = c++;
	_i.cCODFAM_ = c++; 
	_i.cDESFAM_ = c++; 
	_i.cCODSUBFAM_ = c++; 
	_i.cDESSUBFAM_ = c++;
	_i.cORDEN_ = c++;
	_i.cCODTAMA_ = c++; 
	_i.cCODCOLOR_ = c++;
	_i.cCOSTEACT_ = c++; 
	_i.cCOSTENUEVO_ = c++; 
	_i.cCOSTEART_ = c++; 
	_i.cMARGENACT_ = c++; 
	_i.cMARGENNUEVO_ = c++; 
	_i.cMARGENART_ = c++; 
	_i.cEXIS_ = c++; 
	_i.cPTEREC_ = c++;
	_i.cAFALTA_ = c++;
	_i.cREVISAR_ = c++;
	_i.cNUMREF_ = c++;
	_i.cNUMREFHERC_ = c++;
	_i.cNUMREFHERM_ = c++;
	_i.cNUMREFMANC_ = c++;
	_i.cNUMREFMANM_ = c++;
	_i.cIDPLANTILLA_ = c++;

  
	cH[_i.cSEL_] = AQUtil.translate("scripts", "Sel.");
	cH[_i.cCODCOLEC_] = AQUtil.translate("scripts", "Cod.Col.");
	cH[_i.cDESCOLEC_] = AQUtil.translate("scripts", "Colecci�n");
	cH[_i.cCODFAM_] = AQUtil.translate("scripts", "Cod.Fam.");
	cH[_i.cDESFAM_] = AQUtil.translate("scripts", "Familia");
	cH[_i.cCODSUBFAM_] = AQUtil.translate("scripts", "Cod.Subfam.");
	cH[_i.cDESSUBFAM_] = AQUtil.translate("scripts", "Subfamilia");
	cH[_i.cORDEN_] = AQUtil.translate("scripts", "Orden");
	cH[_i.cCODTAMA_] = AQUtil.translate("scripts", "Tama�o");
	cH[_i.cCODCOLOR_] = AQUtil.translate("scripts", "Color");
	cH[_i.cCOSTEACT_] = AQUtil.translate("scripts", "Coste Actual"); 
	cH[_i.cCOSTENUEVO_] = AQUtil.translate("scripts", "Coste Nuevo");
	cH[_i.cCOSTEART_] = AQUtil.translate("scripts", "Coste en art�culos");
	cH[_i.cMARGENACT_] = AQUtil.translate("scripts", "Margen Actual");
	cH[_i.cMARGENNUEVO_] = AQUtil.translate("scripts", "Margen Nuevo");
	cH[_i.cMARGENART_] = AQUtil.translate("scripts", "Margen en art�culos");
	cH[_i.cEXIS_] = AQUtil.translate("scripts", "Existencias");
	cH[_i.cPTEREC_] = AQUtil.translate("scripts", "Pte.Rec.");
	cH[_i.cAFALTA_] = AQUtil.translate("scripts", "A faltas");
	cH[_i.cREVISAR_] = AQUtil.translate("scripts", "Revisar");
	cH[_i.cNUMREF_] = AQUtil.translate("scripts", "Num.Referencias");
	cH[_i.cNUMREFHERM_] = AQUtil.translate("scripts", "REF.HEREDADAS POR MARGEN");
	cH[_i.cNUMREFHERC_] = AQUtil.translate("scripts", "REF.HEREDADAS POR COSTE");
	cH[_i.cNUMREFMANM_] = AQUtil.translate("scripts", "REF.MANUAL POR MARGEN");
	cH[_i.cNUMREFMANC_] = AQUtil.translate("scripts", "REF.MANUAL POR COSTE");
	cH[_i.cIDPLANTILLA_] = AQUtil.translate("scripts", "Id.Plantilla");
  

	//var t = this.child("tblLineas");
  	_i.t_.setNumCols(c); 
	_i.t_.setColumnWidth(_i.cSEL_, 30);
	_i.t_.setColumnWidth(_i.cCODCOLEC_, 55);
	_i.t_.setColumnWidth(_i.cDESCOLEC_, 200);
	_i.t_.setColumnWidth(_i.cCODFAM_, 60); 
	_i.t_.setColumnWidth(_i.cDESFAM_, 200); 
	_i.t_.setColumnWidth(_i.cCODSUBFAM_, 60); 
	_i.t_.setColumnWidth(_i.cDESSUBFAM_, 200);
	_i.t_.setColumnWidth(_i.cORDEN_, 60);
	_i.t_.setColumnWidth(_i.cCODTAMA_, 80); 
	_i.t_.setColumnWidth(_i.cCODCOLOR_, 60);
	_i.t_.setColumnWidth(_i.cCOSTEACT_, 80);
	_i.t_.setColumnWidth(_i.cCOSTENUEVO_, 80);
	_i.t_.setColumnWidth(_i.cCOSTEART_, 140); 
	_i.t_.setColumnWidth(_i.cMARGENACT_, 90); 
	_i.t_.setColumnWidth(_i.cMARGENNUEVO_, 90); 
	_i.t_.setColumnWidth(_i.cMARGENART_, 120);
	_i.t_.setColumnWidth(_i.cEXIS_, 70); 
	_i.t_.setColumnWidth(_i.cPTEREC_, 55);
	_i.t_.setColumnWidth(_i.cAFALTA_, 55);
	_i.t_.setColumnWidth(_i.cREVISAR_, 60);
	_i.t_.setColumnWidth(_i.cNUMREF_, 60);
	_i.t_.setColumnWidth(_i.cNUMREFHERC_, 60);
	_i.t_.setColumnWidth(_i.cNUMREFHERM_, 60);
	_i.t_.setColumnWidth(_i.cNUMREFMANC_, 60);
	_i.t_.setColumnWidth(_i.cNUMREFMANM_, 60);
	_i.t_.setColumnWidth(_i.cIDPLANTILLA_, 60);

	_i.t_.setColumnReadOnly(_i.cSEL_, true);
	_i.t_.setColumnReadOnly(_i.cCODCOLEC_, true);
	_i.t_.setColumnReadOnly(_i.cDESCOLEC_, true);
	_i.t_.setColumnReadOnly(_i.cCODFAM_, true);
	_i.t_.setColumnReadOnly(_i.cDESFAM_, true); 
	_i.t_.setColumnReadOnly(_i.cCODSUBFAM_, true); 
	_i.t_.setColumnReadOnly(_i.cDESSUBFAM_, true);
	_i.t_.setColumnReadOnly(_i.cORDEN_, true);
	_i.t_.setColumnReadOnly(_i.cCODTAMA_, true); 
	_i.t_.setColumnReadOnly(_i.cCODCOLOR_, true);
	_i.t_.setColumnReadOnly(_i.cCOSTEACT_, true); 
	if(_i.cambiarCostes_) {
		_i.t_.setColumnReadOnly(_i.cCOSTENUEVO_, false);
	} else {
		_i.t_.setColumnReadOnly(_i.cCOSTENUEVO_, true);	
	}
	 
	_i.t_.setColumnReadOnly(_i.cCOSTEART_, true); 
	_i.t_.setColumnReadOnly(_i.cMARGENACT_, true); 
	if(_i.cambiarMargen_) {
		_i.t_.setColumnReadOnly(_i.cMARGENNUEVO_, false); 
	} else {		
		_i.t_.setColumnReadOnly(_i.cMARGENNUEVO_, true); 
	}
	_i.t_.setColumnReadOnly(_i.cMARGENART_, true); 
	_i.t_.setColumnReadOnly(_i.cEXIS_, true); 
	_i.t_.setColumnReadOnly(_i.cPTEREC_, true);
	_i.t_.setColumnReadOnly(_i.cAFALTA_, true);
	_i.t_.setColumnReadOnly(_i.cREVISAR_, true);  
	_i.t_.setColumnReadOnly(_i.cNUMREF_, true);  
	_i.t_.setColumnReadOnly(_i.cNUMREFHERC_, true);  
	_i.t_.setColumnReadOnly(_i.cNUMREFHERM_, true);  
	_i.t_.setColumnReadOnly(_i.cNUMREFMANC_, true);  
	_i.t_.setColumnReadOnly(_i.cNUMREFMANM_, true);  
	_i.t_.setColumnReadOnly(_i.cIDPLANTILLA_, true);
  
  	_i.t_.setColumnLabels("*", cH.join("*"));

	_i.t_.hideColumn(_i.cIDPLANTILLA_);
	_i.t_.hideColumn(_i.cNUMREF_);
	_i.t_.hideColumn(_i.cNUMREFHERC_);
	_i.t_.hideColumn(_i.cNUMREFHERM_);
	_i.t_.hideColumn(_i.cNUMREFMANC_);
	_i.t_.hideColumn(_i.cNUMREFMANM_);


  	this.child("txtVPlanActualizables").text = 0;	
	this.child("txtVTamaActualizables").text = 0;
	this.child("txtVArtActualizables").text = 0;	
	this.child("txtVArtActualizablesMargen").text = 0;
}

function oficial_pbnBuscar_clicked()
{ 
	var _i = this.iface;
	var cursor = this.cursor();
	_i.buscar(cursor);	
	//_i.filtro_ = formem_filtrosarticulos.iface.pub_construirFiltro(cursor);
	//_i.refresca();
	_i.cambiaModo("ACT");
}

function oficial_buscar(cursor)
{
	var _i = this.iface;

	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");

	var filtroPlantillas = "";
	//var filtroTamanoSubfam = "p.idplantilla IS NULL ";
	var filtroTamanoSubfam = "";
	var filtro = "";
	var filtroStocks = "";

	var coleccion = cursor.valueBuffer("codcoleccionem");	
	if (coleccion && coleccion != "") {
		if (filtroPlantillas != "") {
			filtroPlantillas += " AND ";
		}
		if (coleccion.find(",") >= 0) {
			filtroPlantillas += ("p.codcoleccionem IN ('" + coleccion.split(",").join("', '") + "')");
		} else {
			if (coleccion.find("-") >= 0) {
				var min = coleccion.split("-")[0];
				var max = coleccion.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtroPlantillas += ("p.codcoleccionem SIMILAR TO '[0-9]+' AND CAST(p.codcoleccionem AS INTEGER) BETWEEN " + min + " AND " + max);
				}
			} else {
				filtroPlantillas += "p.codcoleccionem = '" + coleccion + "'";
			}
		}
	}

	var familia = cursor.valueBuffer("codfamilia");	
	if (familia && familia != "") {
		if (filtroPlantillas != "") {
			filtroPlantillas += " AND ";
		}
		if (familia.find(",") >= 0) {
			filtroPlantillas += ("f.codfamilia IN ('" + familia.split(",").join("', '") + "')");
		} else {
			if (familia.find("-") >= 0) {
				var min = familia.split("-")[0];
				var max = familia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtroPlantillas += ("f.codfamilia SIMILAR TO '[0-9]+' AND CAST(f.codfamilia AS INTEGER) BETWEEN " + min + " AND " + max);
				}
			} else {
				filtroPlantillas += "f.codfamilia = '" + familia + "'";
			}
		}

		if (filtroTamanoSubfam != "") {
			filtroTamanoSubfam += " AND ";
		}
		if (familia.find(",") >= 0) {
			filtroTamanoSubfam += ("f.codfamilia IN ('" + familia.split(",").join("', '") + "')");
		} else {
			if (familia.find("-") >= 0) {
				var min = familia.split("-")[0];
				var max = familia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtroTamanoSubfam += ("f.codfamilia SIMILAR TO '[0-9]+' AND CAST(f.codfamilia AS INTEGER) BETWEEN " + min + " AND " + max);
				}
			} else {
				filtroTamanoSubfam += "f.codfamilia = '" + familia + "'";
			}
		}
	}

	var subFamilia = cursor.valueBuffer("codsubfamilia");	
	if(subFamilia && subFamilia != "") {
		if (filtroPlantillas != "") {
			filtroPlantillas += " AND ";
		}
		if (subFamilia.find(",") >= 0) {
			filtroPlantillas += ("p.codsubfamilia IN ('" + subFamilia.split(",").join("', '") + "')");
		} else {
			if (subFamilia.find("-") >= 0) {
				var min = subFamilia.split("-")[0];
				var max = subFamilia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtroPlantillas += ("p.codsubfamilia SIMILAR TO '[0-9]+' AND CAST(p.codsubfamilia AS INTEGER) BETWEEN " + min + " AND " + max);
				}
			} else {
				filtroPlantillas += "p.codsubfamilia = '" + subFamilia + "'";
			}
		}

		if (filtroTamanoSubfam != "") {
			filtroTamanoSubfam += " AND ";
		}
		if (subFamilia.find(",") >= 0) {
			filtroTamanoSubfam += ("tam.codsubfamilia IN ('" + subFamilia.split(",").join("', '") + "')");
		} else {
			if (subFamilia.find("-") >= 0) {
				var min = subFamilia.split("-")[0];
				var max = subFamilia.split("-")[1];
				if (!isNaN(min) && !isNaN(min)) {
					filtroTamanoSubfam += ("tam.codsubfamilia SIMILAR TO '[0-9]+' AND CAST(tam.codsubfamilia AS INTEGER) BETWEEN " + min + " AND " + max);
				}
			} else {
				filtroTamanoSubfam += "tam.codsubfamilia = '" + subFamilia + "'";
			}
		}
	}


	var tamano = cursor.valueBuffer("codtamanoem");	
	if(tamano && tamano != "") {
		if(filtroPlantillas != "") {
			filtroPlantillas += " AND ";
		}
		filtroPlantillas += "p.codtamanoem = '" + tamano + "'";

		if(filtroTamanoSubfam != "") {
			filtroTamanoSubfam += " AND ";
		}
		filtroTamanoSubfam += "tam.codtamanoem = '" + tamano + "'";
	}

	var color = cursor.valueBuffer("codcolorem");	
	if(color && color != "") {
		if(filtroPlantillas != "") {
			filtroPlantillas += " AND ";
		}
		filtroPlantillas += "p.codcolorem = '" + color + "'";
	}


	/****************************/

	var sinCosteF = cursor.valueBuffer("sincostef");	
	if(sinCosteF) {
		if (filtroPlantillas != "") {
			filtroPlantillas += " AND ";
		}	
		filtroPlantillas += " p.em_costeprod IS NULL";

		if(filtroTamanoSubfam != "") {
			filtroTamanoSubfam += " AND ";
		}
		filtroTamanoSubfam += " tam.em_costeprod IS NULL";
	}

	var sinMargenF = cursor.valueBuffer("sinmargenf");	
	if(sinMargenF) {
		if (filtroPlantillas != "") {
			filtroPlantillas += " AND ";
		}	
		filtroPlantillas += " p.em_margenprod IS NULL";

		if (filtroTamanoSubfam != "") {
			filtroTamanoSubfam += " AND ";
		}	
		filtroTamanoSubfam += " tam.em_margenprod IS NULL";
	}

/*	var codAlmacenF = cursor.valueBuffer("codalmacenf");
	debug("codAlmacenF: "+codAlmacenF);

	var conExisF = cursor.valueBuffer("conexispterecf");
	debug("conExisF: "+conExisF);

	var sinStockF = cursor.valueBuffer("sinstockf");
	debug("sinStockF: "+sinStockF);	


	if(codAlmacenF && codAlmacenF!= "") {
		if (filtro != "") {
			filtro += " AND ";
		}
		if (codAlmacenF.find(",") >= 0) {
				filtro += ("stocks.codalmacen IN ('" + codAlmacenF.split(",").join("', '") + "')");
			} else {
				if (codAlmacenF.find("-") >= 0) {
					var min = codAlmacenF.split("-")[0];
					var max = codAlmacenF.split("-")[1];
					if (!isNaN(min) && !isNaN(min)) {
						filtro += ("stocks.codalmacen SIMILAR TO '[0-9]+' AND  CAST(stocks.codalmacen AS INTEGER) BETWEEN " + min + " AND " + max);
					}
				} else {
					filtro += "stocks.codalmacen = '" + codAlmacenF + "'";
				}
			}

	} else {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += " almacenes.em_tipoalmacen = 'Interno'";
	}


	if(conExisF) {
		if (filtro != "") {
			filtro += " AND ";
		}

		filtro += "(stocks.cantidad <> 0 OR stocks.pterecibir <>0 OR stocks.afaltas <>0)";		
	}
	if(sinStockF) {
		if (filtro != "") {
			filtro += " AND ";
		}
		filtro += " (stocks.cantidad IS NULL OR stocks.cantidad = 0)";
	}*/


	var codAlmacenF = cursor.valueBuffer("codalmacenf");
	var conExisF = cursor.valueBuffer("conexispterecf");
	var sinStockF = cursor.valueBuffer("sinstockf");	

	if(conExisF || sinStockF) {
		if(codAlmacenF && codAlmacenF!= "") {
			if (filtro != "") {
				filtro += " AND ";
			}
			if (codAlmacenF.find(",") >= 0) {
					filtro += ("stocks.codalmacen IN ('" + codAlmacenF.split(",").join("', '") + "')");
				} else {
					if (codAlmacenF.find("-") >= 0) {
						var min = codAlmacenF.split("-")[0];
						var max = codAlmacenF.split("-")[1];
						if (!isNaN(min) && !isNaN(min)) {
							filtro += ("stocks.codalmacen SIMILAR TO '[0-9]+' AND  CAST(stocks.codalmacen AS INTEGER) BETWEEN " + min + " AND " + max);
						}
					} else {
						filtro += "stocks.codalmacen = '" + codAlmacenF + "'";
					}
				}

		} else {
			if (filtro != "") {
				filtro += " AND ";
			}
			filtro += " almacenes.em_tipoalmacen = 'Interno'";
		}


		if(conExisF) {
			if (filtro != "") {
				filtro += " AND ";
			}

			filtro += "(stocks.cantidad <> 0 OR stocks.pterecibir <>0 OR stocks.afaltas <>0)";		
		}
		if(sinStockF) {
			if (filtro != "") {
				filtro += " AND ";
			}
			filtro += " (stocks.cantidad IS NULL OR stocks.cantidad = 0)";
		}

	}

	_i.t_.setNumRows(0);
	var f = 0;
	var p = 0;

	//Siempre va a haber 2 filtros, 
	//1 filtro para aplicar plantillas y otro para art�culos
	var oParam = new Object;
 	var costesArt;
 	var margenesArt;
	if(apPlantillas) {	

		if(filtroPlantillas != "" && filtro != "") {
			filtro = " AND "+filtro;
		}
		var oParam = new Object;
		oParam.caption = "Cargando datos";
		formUI.creaDialogoEstado(oParam);	
		formUI.ponLogDialogo("Cargando datos plantillas");


		var q = new AQSqlQuery;	
		q.setSelect("count(distinct(articulos.referencia)),p.idplantilla,p.codcoleccionem, c.descripcion, f.codfamilia, f.descripcion, p.codsubfamilia, sf.descripcion, tam.orden, p.codtamanoem,p.codcolorem, p.em_costeprod,p.em_margenprod,costesart.costes, margenesart.margenes,SUM(stocks.cantidad),SUM(stocks.pterecibir),SUM(stocks.afaltas)");
		q.setFrom("em_plantillasprod p INNER JOIN em_colecciones c ON p.codcoleccionem = c.codcoleccionem INNER JOIN subfamilias sf ON sf.codsubfamilia = p.codsubfamilia INNER JOIN familias f ON f.codfamilia = sf.codfamilia LEFT OUTER JOIN em_tamanossubfam tam ON tam.codtamanoem = p.codtamanoem AND tam.codsubfamilia = p.codsubfamilia LEFT OUTER JOIN (select art.codcoleccionem,art.codsubfamilia,art.codtamanoem,art.codcolorem,array_to_string(array_agg((em_costeprod)),', ') as costes from (select distinct codcoleccionem,codsubfamilia,codtamanoem,codcolorem,em_costeprod from articulos where em_costeprod is not null group by codcoleccionem,codsubfamilia,codtamanoem,codcolorem,em_costeprod order by em_costeprod) as art group by art.codcoleccionem,art.codsubfamilia,art.codtamanoem,art.codcolorem) as costesart ON costesart.codcoleccionem = p.codcoleccionem AND costesart.codsubfamilia = p.codsubfamilia AND costesart.codtamanoem = p.codtamanoem AND costesart.codcolorem = p.codcolorem LEFT OUTER JOIN (select art.codcoleccionem,art.codsubfamilia,art.codtamanoem,art.codcolorem,array_to_string(array_agg((em_margenprod)),', ') as margenes from (select distinct codcoleccionem,codsubfamilia,codtamanoem,codcolorem,em_margenprod from articulos where em_margenprod is not null group by codcoleccionem,codsubfamilia,codtamanoem,codcolorem,em_margenprod order by em_margenprod) as art group by art.codcoleccionem,art.codsubfamilia,art.codtamanoem,art.codcolorem) as margenesart ON margenesart.codcoleccionem = p.codcoleccionem AND margenesart.codsubfamilia = p.codsubfamilia AND margenesart.codtamanoem = p.codtamanoem AND margenesart.codcolorem = p.codcolorem LEFT OUTER JOIN articulos ON articulos.codcoleccionem = p.codcoleccionem AND articulos.codsubfamilia = p.codsubfamilia AND articulos.codtamanoem = p.codtamanoem AND articulos.codcolorem = p.codcolorem LEFT OUTER JOIN stocks ON articulos.referencia = stocks.referencia LEFT OUTER JOIN almacenes ON almacenes.codalmacen = stocks.codalmacen ");
		q.setWhere(filtroPlantillas + filtro + " GROUP BY p.idplantilla,p.codcoleccionem, c.descripcion, f.codfamilia, f.descripcion, p.codsubfamilia, sf.descripcion, tam.orden, p.codtamanoem,p.codcolorem, p.em_costeprod, p.em_margenprod,costesart.costes, margenesart.margenes ORDER BY p.codcoleccionem, f.codfamilia,p.codsubfamilia,tam.orden");				
		if (!q.exec()){
			return;
		}  
		//flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando datos"), q.size());
		//debug("sql: "+q.sql());
		while(q.next())
		{
			formUI.ponLogDialogo("Datos plantilla: "+q.value("p.idplantilla"));
			//AQUtil.setProgress(p++);
			_i.t_.insertRows(f);  
			//_i.t_.setText(f, _i.cSEL_,"X");    		
      		//_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorSel_);
      		_i.t_.setText(f, _i.cSEL_,"");
      		_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorNoSel_);
      		_i.t_.setText(f, _i.cIDPLANTILLA_, q.value("p.idplantilla"));
      		_i.t_.setText(f, _i.cCODCOLEC_, q.value("p.codcoleccionem"));
      		_i.t_.setText(f, _i.cDESCOLEC_, q.value("c.descripcion"));
      		_i.t_.setText(f, _i.cCODFAM_, q.value("f.codfamilia"));
      		_i.t_.setText(f, _i.cDESFAM_, q.value("f.descripcion"));
      		_i.t_.setText(f, _i.cCODSUBFAM_, q.value("p.codsubfamilia"));
      		_i.t_.setText(f, _i.cDESSUBFAM_, q.value("sf.descripcion"));
      		_i.t_.setText(f, _i.cORDEN_, q.value("tam.orden"));       
      		_i.t_.setText(f, _i.cCODTAMA_, q.value("p.codtamanoem"));     
      		_i.t_.setText(f, _i.cCODCOLOR_, q.value("p.codcolorem"));   
      		
			if(!q.isNull(11)) {
				_i.t_.setText(f, _i.cCOSTEACT_, q.value("p.em_costeprod"));	
			} else {
				_i.t_.setText(f, _i.cCOSTEACT_, '');	
			}      		
      		_i.t_.setText(f, _i.cCOSTENUEVO_, "");     	

      		costesArt = q.value("costesart.costes");
      		if(costesArt.toString().find(",")>=0) {
      			costesArt = "VARIOS: "+costesArt;	
      		} else if(!costesArt || costesArt == "") {
      			costesArt = "No encontrados";	
      		}
      		_i.t_.setText(f, _i.cCOSTEART_, costesArt);

      		if(!q.isNull(12)) {
      			_i.t_.setText(f, _i.cMARGENACT_, q.value("p.em_margenprod"));
      		} else {
      			_i.t_.setText(f, _i.cMARGENACT_, "");
      		}      		
			_i.t_.setText(f, _i.cMARGENNUEVO_, ""); 

			margenesArt = q.value("margenesart.margenes");
      		if(margenesArt.toString().find(",")>=0) {
      			margenesArt = "VARIOS: "+margenesArt;	
      		} else if(!margenesArt || margenesArt == "") {
      			margenesArt = "No encontrados";	
      		}
      		_i.t_.setText(f, _i.cMARGENART_, margenesArt);



			_i.t_.setText(f, _i.cEXIS_, q.value("SUM(stocks.cantidad)"));
			_i.t_.setText(f, _i.cPTEREC_, q.value("SUM(stocks.pterecibir)"));
			_i.t_.setText(f, _i.cAFALTA_, q.value("SUM(stocks.afaltas)"));

			if(!q.value("SUM(stocks.cantidad)") || q.value("SUM(stocks.cantidad)") == 0 || !q.value("SUM(stocks.pterecibir)") || q.value("SUM(stocks.pterecibir)") == "" || !q.value("SUM(stocks.afaltas)") || q.value("SUM(stocks.afaltas)") == "") {
				_i.t_.setText(f, _i.cREVISAR_, "REVISAR");	
			} else {
				_i.t_.setText(f, _i.cREVISAR_, "");
			}
			_i.t_.setText(f, _i.cNUMREF_,q.value("count(distinct(articulos.referencia))"));
			_i.t_.setText(f, _i.cNUMREFHERC_,0);
			_i.t_.setText(f, _i.cNUMREFMANC_,0);
			_i.t_.setText(f, _i.cNUMREFHERM_,0);
			_i.t_.setText(f, _i.cNUMREFMANM_,0);
					
			f++;
		}
		//AQUtil.destroyProgressDialog();
		formUI.destruyeDialogoEstado();
	} else if(apTamanoSubFam) {
		if(filtroTamanoSubfam != "" && filtro != "") {
			filtro = " AND "+filtro;
		}
		var oParam = new Object;
		oParam.caption = "Cargando datos";
		formUI.creaDialogoEstado(oParam);	
		formUI.ponLogDialogo("Cargando datos tama�o por subfamilia");


		//2 filtro para aplicar tamano subfamilia y otro para art�culos 
		var q = new AQSqlQuery;	
		q.setSelect("count(distinct(articulos.referencia)),f.codfamilia, f.descripcion, tam.codsubfamilia, sf.descripcion, tam.orden, tam.codtamanoem, tam.em_costeprod, tam.em_margenprod,costesart.costes, margenesart.margenes,SUM(stocks.cantidad),SUM(stocks.pterecibir),SUM(stocks.afaltas)");
		//q.setFrom("em_tamanossubfam tam INNER JOIN subfamilias sf ON sf.codsubfamilia = tam.codsubfamilia INNER JOIN familias f ON f.codfamilia = sf.codfamilia LEFT OUTER JOIN (select art.codsubfamilia,art.codtamanoem,array_to_string(array_agg((em_costeprod)),', ') as costes from (select distinct codsubfamilia,codtamanoem,em_costeprod from articulos where em_costeprod is not null group by codsubfamilia,codtamanoem,em_costeprod order by em_costeprod) as art group by art.codsubfamilia,art.codtamanoem) as costesart ON costesart.codsubfamilia = tam.codsubfamilia AND costesart.codtamanoem = tam.codtamanoem LEFT OUTER JOIN (select art.codsubfamilia,art.codtamanoem,array_to_string(array_agg((em_margenprod)),', ') as margenes from (select distinct codsubfamilia,codtamanoem,em_margenprod from articulos where em_margenprod is not null group by codsubfamilia,codtamanoem,em_margenprod order by em_margenprod) as art group by art.codsubfamilia,art.codtamanoem) as margenesart ON margenesart.codsubfamilia = tam.codsubfamilia AND margenesart.codtamanoem = tam.codtamanoem LEFT OUTER JOIN articulos ON articulos.codsubfamilia = tam.codsubfamilia AND articulos.codtamanoem = tam.codtamanoem LEFT OUTER JOIN stocks ON articulos.referencia = stocks.referencia LEFT OUTER JOIN almacenes ON almacenes.codalmacen = stocks.codalmacen LEFT OUTER JOIN em_plantillasprod p ON articulos.codcoleccionem = p.codcoleccionem AND articulos.codsubfamilia = p.codsubfamilia AND articulos.codtamanoem = p.codtamanoem AND articulos.codcolorem = p.codcolorem ");
		q.setFrom("em_tamanossubfam tam INNER JOIN subfamilias sf ON sf.codsubfamilia = tam.codsubfamilia INNER JOIN familias f ON f.codfamilia = sf.codfamilia LEFT OUTER JOIN (select art.codsubfamilia,art.codtamanoem,array_to_string(array_agg((em_costeprod)),', ') as costes from (select distinct codsubfamilia,codtamanoem,em_costeprod from articulos where em_costeprod is not null group by codsubfamilia,codtamanoem,em_costeprod order by em_costeprod) as art group by art.codsubfamilia,art.codtamanoem) as costesart ON costesart.codsubfamilia = tam.codsubfamilia AND costesart.codtamanoem = tam.codtamanoem LEFT OUTER JOIN (select art.codsubfamilia,art.codtamanoem,array_to_string(array_agg((em_margenprod)),', ') as margenes from (select distinct codsubfamilia,codtamanoem,em_margenprod from articulos where em_margenprod is not null group by codsubfamilia,codtamanoem,em_margenprod order by em_margenprod) as art group by art.codsubfamilia,art.codtamanoem) as margenesart ON margenesart.codsubfamilia = tam.codsubfamilia AND margenesart.codtamanoem = tam.codtamanoem LEFT OUTER JOIN articulos ON articulos.codsubfamilia = tam.codsubfamilia AND articulos.codtamanoem = tam.codtamanoem LEFT OUTER JOIN stocks ON articulos.referencia = stocks.referencia LEFT OUTER JOIN almacenes ON almacenes.codalmacen = stocks.codalmacen");
		q.setWhere(filtroTamanoSubfam + filtro + " GROUP BY f.codfamilia, f.descripcion, tam.codsubfamilia, sf.descripcion, tam.orden, tam.codtamanoem, tam.em_costeprod, tam.em_margenprod,costesart.costes, margenesart.margenes ORDER BY f.codfamilia, tam.codsubfamilia,tam.orden");				
		if (!q.exec()){
			return;
		}  
		//debug("qtamanos: "+q.sql());
		//flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando datos"), q.size());
		while(q.next())
		{
			//AQUtil.setProgress(p++);
			formUI.ponLogDialogo("Datos subfamilia: "+q.value("tam.codsubfamilia") + " Tama�o: "+q.value("tam.codtamanoem"));
			_i.t_.insertRows(f);  
			//_i.t_.setText(f, _i.cSEL_,"X");    		
			_i.t_.setText(f, _i.cSEL_,"");
      		//_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorSel_);
      		_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorNoSel_);
      		_i.t_.setText(f, _i.cCODCOLEC_, "");
      		_i.t_.setText(f, _i.cDESCOLEC_, "");
      		_i.t_.setText(f, _i.cCODFAM_, q.value("f.codfamilia"));
      		_i.t_.setText(f, _i.cDESFAM_, q.value("f.descripcion"));
      		_i.t_.setText(f, _i.cCODSUBFAM_, q.value("tam.codsubfamilia"));
      		_i.t_.setText(f, _i.cDESSUBFAM_, q.value("sf.descripcion"));
      		_i.t_.setText(f, _i.cORDEN_, q.value("tam.orden"));       
      		_i.t_.setText(f, _i.cCODTAMA_, q.value("tam.codtamanoem"));     
      		_i.t_.setText(f, _i.cCODCOLOR_, "");     


      		if(!q.isNull(7)) {
      			_i.t_.setText(f, _i.cCOSTEACT_, q.value("tam.em_costeprod"));	
      		} else {
      			_i.t_.setText(f, _i.cCOSTEACT_, "");
      		}
      		
      		_i.t_.setText(f, _i.cCOSTENUEVO_, "");
      		costesArt = q.value("costesart.costes");
      		if(costesArt.find(",")>=0) {
      			costesArt = "VARIOS: "+costesArt;	
      		} else if(!costesArt || costesArt == "") {
      			costesArt = "No encontrados";	
      		}
      		_i.t_.setText(f, _i.cCOSTEART_, costesArt);



      		if(!q.isNull(8)) {
      			_i.t_.setText(f, _i.cMARGENACT_, q.value("tam.em_margenprod"));
      		} else {
      			_i.t_.setText(f, _i.cMARGENACT_, "");
      		}
			_i.t_.setText(f, _i.cMARGENNUEVO_, ""); 

			margenesArt = q.value("margenesart.margenes");
      		if(margenesArt.find(",")>=0) {
      			margenesArt = "VARIOS: "+margenesArt;	
      		} else if(!margenesArt || margenesArt == "") {
      			margenesArt = "No encontrados";	
      		}
			_i.t_.setText(f, _i.cMARGENART_, margenesArt);
			_i.t_.setText(f, _i.cEXIS_, q.value("SUM(stocks.cantidad)"));
			_i.t_.setText(f, _i.cPTEREC_, q.value("SUM(stocks.pterecibir)"));
			_i.t_.setText(f, _i.cAFALTA_, q.value("SUM(stocks.afaltas)"));
			if(!q.value("SUM(stocks.cantidad)") || q.value("SUM(stocks.cantidad)") == 0 || !q.value("SUM(stocks.pterecibir)") || q.value("SUM(stocks.pterecibir)") == "" || !q.value("SUM(stocks.afaltas)") || q.value("SUM(stocks.afaltas)") == "") {
				_i.t_.setText(f, _i.cREVISAR_, "REVISAR");	
			} else {
				_i.t_.setText(f, _i.cREVISAR_, "");
			}
			_i.t_.setText(f, _i.cNUMREF_,q.value("count(distinct(articulos.referencia))"));	
			_i.t_.setText(f, _i.cNUMREFHERC_,0);
			_i.t_.setText(f, _i.cNUMREFHERM_,0);
			_i.t_.setText(f, _i.cNUMREFMANC_,0);
			_i.t_.setText(f, _i.cNUMREFMANM_,0);
			f++;
		}
		formUI.destruyeDialogoEstado();
		//AQUtil.destroyProgressDialog();

	}
	this.child("txtVPlanActualizables").text = 0;	
	this.child("txtVTamaActualizables").text = 0;
	this.child("txtVArtActualizables").text = 0;	
	this.child("txtVArtActualizablesMargen").text = 0;
	
}

function oficial_colores()
{
	var _i = this.iface;
	_i.cColorNoSel_ = new Color("grey");
	_i.cColorSel_ = new Color("green"); 
}

function oficial_tblLineas_clicked(f, c)
{
	var _i = this.iface;
	if(c == _i.cSEL_) {	
		_i.colSelClicked(f); 	
	}	
}

function oficial_tbnTodosSel_clicked()
{
	var _i = this.iface;	
	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Marcando l�neas"), nF);
	var p = 0;
	for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		if (_i.t_.text(f, c) == "") {
			if (!_i.colSelClicked(f)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
			
		}
	}	
  	AQUtil.destroyProgressDialog();
}

function oficial_tbnNingunoSel_clicked()
{
	

	var _i = this.iface;	
	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Desmarcando l�neas"), nF);
	var p = 0;
	for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		if (_i.t_.text(f, c) == "X") {
			if (!_i.colSelClicked(f)) {
				AQUtil.destroyProgressDialog();
				return false;
			}
			
		}
	}	
	AQUtil.destroyProgressDialog();
}

function oficial_colSelClicked(f)
{
	var _i = this.iface;
	var c = _i.cSEL_;
	
	if (_i.t_.text(f, c) == "") {
		_i.t_.setText(f, c, "X");   
	} else {
		_i.t_.setText(f, c, "");   
	}

	if (_i.t_.text(f, c) == "X") {
		_i.t_.setCellBackgroundColor(f, c, _i.cColorSel_);		
	} else {
		_i.t_.setCellBackgroundColor(f, c, _i.cColorNoSel_);		
	}
 	return true;
}


function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	if(fN == "eliminarcostes" || fN == "eliminarmargenes") {
		_i.habilitaCostes();

	} else if(fN == "aumentarcoste"){
		_i.habilitaAumentoCoste();
	} else if(fN == "disminuircoste") {		
		_i.habilitaDisminuirCoste();
	} else if(fN == "aumentarmargen") {
		_i.habilitaAumentoMargen();
	} else if(fN == "disminuirmargen") {
		_i.habilitaDisminuirMargen();
	} else if(fN == "applantillas") {
		_i.habilitaAplicaPlan();
	} else if(fN == "aptamanosubfam") {
		_i.habilitaAplicaTama();
	}  
}

function oficial_cambiaModo(m)
{
	var _i = this.iface;
	_i.modo_ = m;
	_i.habilitaPorModo();  
}

function oficial_habilitaPorModo()
{
	var _i = this.iface;
	var cursor = this.cursor();


	
	if(_i.modo_ == "BUS") { 
		
		this.child("gbxBus").enabled = true;
		this.child("gbxAct").enabled = false;
		this.child("pbnAplicar").enabled =false;
		this.child("pbnCancelar").enabled =false;
		this.child("tbnTodosSel").enabled =true;
		this.child("tbnNingunoSel").enabled =true;			
	} else if(_i.modo_ == "ACT") {
	
		this.child("gbxBus").enabled = false;
		this.child("gbxAct").enabled = true;
		this.child("pbnAplicar").enabled =true;
		this.child("pbnCancelar").enabled =true;	
		_i.habilitaCamposCostesProd();
		_i.habilitaCostes();		

	}
	//_i.habilitaCamposCostesProd();
	//_i.habilitaCostes();
}

function oficial_habilitaCostes()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var eliminarCostes = cursor.valueBuffer("eliminarcostes");
	var eliminarMargenes = cursor.valueBuffer("eliminarmargenes");
			
	var nF = _i.t_.numRows();
	
	if(_i.cambiarCostes_) {
		this.child("fdbEliminarCostes").setDisabled(false);
		if(eliminarCostes) {
			this.child("fdbEmCosteProd").setValue("");
			this.child("fdbEmCosteProd").setDisabled(true);
			this.child("fdbEmObservCosteProd").setValue("");
			this.child("fdbEmObservCosteProd").setDisabled(true);			
			this.child("fdbAumentarCoste").setValue(false);
			this.child("fdbAumentarCoste").setDisabled(true);
			this.child("fdbPorAumCoste").setValue("");
			this.child("fdbPorAumCoste").setDisabled(true);
			this.child("fdbDisminuirCoste").setValue(false);
			this.child("fdbDisminuirCoste").setDisabled(true);	
			this.child("fdbPorDismCoste").setValue("");
			this.child("fdbPorDismCoste").setDisabled(true);
			for (var f = 0; f < nF; f++) {
				_i.t_.setText(f, _i.cCOSTENUEVO_, "");				
			}
			_i.t_.setColumnReadOnly(_i.cCOSTENUEVO_, true);
		} else {
			
			this.child("fdbEmCosteProd").setDisabled(false);			
			this.child("fdbEmObservCosteProd").setDisabled(false);				
			this.child("fdbAumentarCoste").setDisabled(false);		
			//this.child("fdbPorAumCoste").setDisabled(false);
			this.child("fdbDisminuirCoste").setDisabled(false);
			//this.child("fdbPorDismCoste").setDisabled(false);	
			_i.t_.setColumnReadOnly(_i.cCOSTENUEVO_, false);

		}	
	} else {
		this.child("fdbEliminarCostes").setDisabled(true);
		this.child("fdbEmCosteProd").setDisabled(true);
		this.child("fdbEmObservCosteProd").setDisabled(true);				
		this.child("fdbAumentarCoste").setDisabled(true);		
		this.child("fdbPorAumCoste").setDisabled(true);
		this.child("fdbDisminuirCoste").setDisabled(true);
		this.child("fdbPorDismCoste").setDisabled(true);	
	}
	if(_i.cambiarMargen_) {
		this.child("fdbEliminarMargenes").setDisabled(false);	
		if(eliminarMargenes) {
			this.child("fdbEmMargenProd").setValue("");
			this.child("fdbEmMargenProd").setDisabled(true);
			this.child("fdbEmObservMargenProd").setValue("");
			this.child("fdbEmObservMargenProd").setDisabled(true);
			this.child("fdbAumentarMargen").setValue(false);
			this.child("fdbAumentarMargen").setDisabled(true);
			this.child("fdbPorAumMargen").setValue("");
			this.child("fdbPorAumMargen").setDisabled(true);
			this.child("fdbDisminuirMargen").setValue(false);
			this.child("fdbDisminuirMargen").setDisabled(true);	
			this.child("fdbPorDismMargen").setValue("");
			this.child("fdbPorDismMargen").setDisabled(true);
			for (var f = 0; f < nF; f++) {
				_i.t_.setText(f, _i.cMARGENNUEVO_, "");				
			}
			_i.t_.setColumnReadOnly(_i.cMARGENNUEVO_, true);
		} else {
			
			this.child("fdbEmMargenProd").setDisabled(false);
			this.child("fdbEmObservMargenProd").setDisabled(false);		
			this.child("fdbAumentarMargen").setDisabled(false);
			//this.child("fdbPorAumMargen").setDisabled(false);
			this.child("fdbDisminuirMargen").setDisabled(false);	
			//this.child("fdbPorDismMargen").setDisabled(false);	
			_i.t_.setColumnReadOnly(_i.cMARGENNUEVO_, false);
		}
	} else {
		this.child("fdbEliminarMargenes").setDisabled(true);
		this.child("fdbEmMargenProd").setDisabled(true);
		this.child("fdbEmObservMargenProd").setDisabled(true);		
		this.child("fdbAumentarMargen").setDisabled(true);
		this.child("fdbPorAumMargen").setDisabled(true);
		this.child("fdbDisminuirMargen").setDisabled(true);	
		this.child("fdbPorDismMargen").setDisabled(true);
	}	

}
function oficial_habilitaCamposCostesProd()
{
	var _i = this.iface;
	if(!_i.cambiarCostes_ && !_i.cambiarMargen_) {
		//this.child("fdbCambiarCostes").setDisabled(true);
	} else {
		//this.child("fdbCambiarCostes").setDisabled(false);
		if(_i.cambiarCostes_) {
			this.child("fdbEliminarCostes").setDisabled(false);
			this.child("fdbEmCosteProd").setDisabled(false);
			this.child("fdbEmObservCosteProd").setDisabled(false);	
		} else {
			this.child("fdbEliminarCostes").setDisabled(true);
			this.child("fdbEmCosteProd").setDisabled(true);
			this.child("fdbEmObservCosteProd").setDisabled(true);
		}

		if(_i.cambiarMargen_) {			
			this.child("fdbEliminarMargenes").setDisabled(false);
			this.child("fdbEmMargenProd").setDisabled(false);
			this.child("fdbEmObservMargenProd").setDisabled(false);
		} else {
			this.child("fdbEliminarMargenes").setDisabled(true);
			this.child("fdbEmMargenProd").setDisabled(true);
			this.child("fdbEmObservMargenProd").setDisabled(true);
		}
	}

}

function oficial_habilitaAumentoCoste()
{
	
	var _i = this.iface;
	var cursor = this.cursor(); 
	var aumentarCostes = cursor.valueBuffer("aumentarcoste");	
	var disminuirCostes = cursor.valueBuffer("disminuircoste");		

	if(aumentarCostes) {
		if(disminuirCostes) {
			this.child("fdbDisminuirCoste").setValue(false);
			this.child("fdbPorDismCoste").setValue("");
		}
		this.child("fdbPorAumCoste").setDisabled(false);
		this.child("fdbEmCosteProd").setDisabled(true);
		this.child("fdbEmCosteProd").setValue("");
				
	} else {		
		this.child("fdbPorAumCoste").setDisabled(true);
		this.child("fdbPorAumCoste").setValue("");
		this.child("fdbEmCosteProd").setDisabled(false);
	}
}

function oficial_habilitaDisminuirCoste()
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	var aumentarCostes = cursor.valueBuffer("aumentarcoste");	
	var disminuirCostes = cursor.valueBuffer("disminuircoste");		

	if(disminuirCostes) {
		if(aumentarCostes) {
			this.child("fdbAumentarCoste").setValue(false);	
			this.child("fdbPorAumCoste").setValue("");						
		}		
		this.child("fdbPorDismCoste").setDisabled(false);
		this.child("fdbEmCosteProd").setDisabled(true);
		this.child("fdbEmCosteProd").setValue("");					
	} else {
		this.child("fdbPorDismCoste").setDisabled(true);
		this.child("fdbPorDismCoste").setValue("");
		this.child("fdbEmCosteProd").setDisabled(false);
	}
}

function oficial_habilitaAumentoMargen()
{
	
	var _i = this.iface;
	var cursor = this.cursor();	
	var aumentarMargen = cursor.valueBuffer("aumentarmargen");	
	var disminuirMargen = cursor.valueBuffer("disminuirmargen");	

	if(aumentarMargen) {
		if(disminuirMargen) {
			this.child("fdbDisminuirMargen").setValue(false);
			this.child("fdbPorDismMargen").setValue("");
		}
		this.child("fdbPorAumMargen").setDisabled(false);	
		this.child("fdbEmMargenProd").setDisabled(true);
		this.child("fdbEmMargenProd").setValue("");			
	} else {
		this.child("fdbPorAumMargen").setDisabled(true);
		this.child("fdbPorAumMargen").setValue("");
		this.child("fdbEmMargenProd").setDisabled(false);
	}
}

function oficial_habilitaDisminuirMargen()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var aumentarMargen = cursor.valueBuffer("aumentarmargen");	
	var disminuirMargen = cursor.valueBuffer("disminuirmargen");	

	if(disminuirMargen) {
		if(aumentarMargen) {
			this.child("fdbAumentarMargen").setValue(false);	
			this.child("fdbPorAumMargen").setValue("");						
		}		
		this.child("fdbPorDismMargen").setDisabled(false);	
		this.child("fdbEmMargenProd").setDisabled(true);
		this.child("fdbEmMargenProd").setValue("");						
	} else {
		this.child("fdbPorDismMargen").setDisabled(true);
		this.child("fdbPorDismMargen").setValue("");
		this.child("fdbEmMargenProd").setDisabled(false);
	}

}

function oficial_pbnActualizaTabla_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();
	var eliminarCostes  = cursor.valueBuffer("eliminarcostes");
	var eliminarMargenes  = cursor.valueBuffer("eliminarmargenes");
	var costeProd = cursor.valueBuffer("em_costeprod");
	var margenProd = cursor.valueBuffer("em_margenprod");
	var observProd = cursor.valueBuffer("em_observcosteprod");
	var observMargen = cursor.valueBuffer("em_observmargenprod");
	
	var aumentarCostes = cursor.valueBuffer("aumentarcoste");
	var porAumCoste = cursor.valueBuffer("poraumcoste");
	var disminuirCostes = cursor.valueBuffer("disminuircoste");	
	var porDismCoste = cursor.valueBuffer("pordismcoste"); 
	var aumentarMargen = cursor.valueBuffer("aumentarmargen");
	var porAumMargen = cursor.valueBuffer("poraummargen");
	var disminuirMargen = cursor.valueBuffer("disminuirmargen");
	var porDismMargen = cursor.valueBuffer("pordismmargen");

	var actHeredado = cursor.valueBuffer("actheredado");
	var actManual = cursor.valueBuffer("actmanual");

	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Actualizando tabla"), nF);
	var p = 0;
	var costeActual;
	var costeNuevo;
	var margenActual;
	var margenNuevo;
	for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		if (_i.t_.text(f, c) == "X") {
			if(eliminarCostes) {				      		
      			_i.t_.setText(f, _i.cCOSTENUEVO_, "");
			} else if(costeProd && costeProd != "" && !cursor.isNull("em_costeprod")) {
				_i.t_.setText(f, _i.cCOSTENUEVO_, costeProd);
			} else if(aumentarCostes) {
				costeActual = _i.t_.text(f, _i.cCOSTEACT_)
				costeNuevo = costeActual*(1+porAumCoste/100);
				_i.t_.setText(f, _i.cCOSTENUEVO_, costeNuevo);
			} else if(disminuirCostes) {
				costeActual = _i.t_.text(f, _i.cCOSTEACT_)
				costeNuevo = costeActual*(1-porDismCoste/100);
				_i.t_.setText(f, _i.cCOSTENUEVO_, costeNuevo);
			}
			if(eliminarMargenes) {
				_i.t_.setText(f, _i.cMARGENNUEVO_, ""); 
			} else if(margenProd && margenProd != "" && !cursor.isNull("em_margenprod")) {
				_i.t_.setText(f, _i.cMARGENNUEVO_, margenProd);
			} else if(aumentarMargen) {
				margenActual = _i.t_.text(f, _i.cMARGENACT_)
				margenNuevo = margenActual*(1+porAumMargen/100);
				_i.t_.setText(f, _i.cMARGENNUEVO_, margenNuevo); 
			} else if(disminuirMargen) {
				margenActual = _i.t_.text(f, _i.cMARGENACT_)
				margenNuevo = margenActual*(1-porDismMargen/100);
				_i.t_.setText(f, _i.cMARGENNUEVO_, margenNuevo); 
			}			
		}
	}	
  	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_pbnLimpiar_clicked()
{
	var _i = this.iface;
	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Limpiando tabla"), nF);
	var p = 0;
	for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		_i.t_.setText(f, _i.cCOSTENUEVO_, "");
		_i.t_.setText(f, _i.cMARGENNUEVO_, "");
	}
	this.child("txtVPlanActualizables").text = 0;	
	this.child("txtVTamaActualizables").text = 0;
	this.child("txtVArtActualizables").text = 0;	
	this.child("txtVArtActualizablesMargen").text = 0;
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_pbnCancelar_clicked()
{
	var _i = this.iface;
	_i.cambiaModo("BUS");
	this.child("txtVPlanActualizables").text = 0;	
	this.child("txtVTamaActualizables").text = 0;
	this.child("txtVArtActualizables").text = 0;		
	this.child("txtVArtActualizablesMargen").text = 0;
}

function oficial_pbnAplicar_clicked()
{
	var _i = this.iface;

	if(!_i.calculaReferencias()) {
		return false;
	}	
	if(!_i.informaLabels()) {
		return false;
	}	
	if(!_i.cambiaDatos()) {
		return false;
	}	
	if(!_i.guardaLineas()) {
		return false;
	}	
	if(!_i.marcaComoAplicado()) {
		return false;
	}
	if(!_i.informaLabelsAct()) {
		return false;
	}
	
	return true;
}
function oficial_calculaReferencias() 
{
	var _i = this.iface;
	return true;	
}

function oficial_informaLabels()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	var actHeredado = cursor.valueBuffer("actheredado");
	var actManual = cursor.valueBuffer("actmanual");
	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	var numArticulosC = 0;
	var numArticulosM = 0;
	var numReg = 0;
	var numRegAct = 0;
	var numRefHerC = 0;
	var numRefHerM = 0;
	var numRefManC = 0;
	var numRefManM = 0;
	var totalRefHerC = 0;
	var totalRefHerM = 0;
	var totalRefManC = 0;
	var totalRefManM = 0;
	var costeActual;
	var costeNuevo;
	var margenActual;
	var margenNuevo;
	var oRefHer;
	var oRefMan;
	for (var f = 0; f < nF; f++) {		
		if (_i.t_.text(f, c) == "X") {			
			//numArticulos += parseInt(_i.t_.text(f, _i.cNUMREF_));
			if(actHeredado) {
				oRefHer = _i.dameNumRefHer(f);
				numRefHerC = oRefHer["numRefC"];
				numRefHerM = oRefHer["numRefM"];	
				
				if(!numRefHerC ||numRefHerC == "") {
					numRefHerC = 0;	
				}
				if(!numRefHerM ||numRefHerM == "") {
					numRefHerM = 0;	
				}							
				_i.t_.setText(f, _i.cNUMREFHERC_,numRefHerC);
				_i.t_.setText(f, _i.cNUMREFHERM_,numRefHerM);
			}

			if(actManual) {
				oRefMan = _i.dameNumRefMan(f);
				numRefManC = oRefMan["numRefC"];
				numRefManM = oRefMan["numRefM"];	
				
				if(!numRefManC ||numRefManC == "") {
					numRefManC = 0;	
				}
				if(!numRefManM ||numRefManM == "") {
					numRefManM = 0;	
				}							
				_i.t_.setText(f, _i.cNUMREFMANC_,numRefManC);
				_i.t_.setText(f, _i.cNUMREFMANM_,numRefManM);
			}

			costeActual = parseFloat(_i.t_.text(f, _i.cCOSTEACT_));
			costeNuevo = parseFloat(_i.t_.text(f, _i.cCOSTENUEVO_));
			margenActual = parseFloat(_i.t_.text(f, _i.cMARGENACT_));
			margenNuevo = parseFloat(_i.t_.text(f, _i.cMARGENNUEVO_));

			if(costeActual != costeNuevo || margenActual != margenNuevo) {
				numRegAct++;
			}
			numReg++;

			totalRefHerC += numRefHerC;
			totalRefHerM += numRefHerM;
			totalRefManC += numRefManC;
			totalRefManM += numRefManM;									
		}
	}

	var numPlantillas;
	var numTama;
	var mensaje = "�Desea aplicar los cambios a ";	
	if(apPlantillas) {	
		numPlantillas = numReg;
		numTama = 0;
		mensaje += numPlantillas + " plantillas";
		
	} else if(apTamanoSubFam) {
		numTama = numReg;
		numPlantillas = 0;
		mensaje += numTama + " tama�os en subfamilias";
	}

	/*if(actHeredado && !actManual) {
		numArticulos = parseFloat(totalRefHer);
		mensaje += " y " + numArticulos + " art�culos Heredados";
	} else if(!actHeredado && actManual) {
		numArticulos = parseFloat(totalRefMan);
		mensaje += " y " + numArticulos + " art�culos Manuales";
	} else if(actHeredado && actManual) {
		numArticulos = parseFloat(totalRefHer) + parseFloat(totalRefMan);
		mensaje += " y " + numArticulos + " art�culos Heredados y Manuales";
	}*/



	if(actHeredado && !actManual) {
		numArticulosC = parseFloat(totalRefHerC);
		if(numArticulosC && numArticulosC != "") {
			mensaje += " y " + numArticulosC + " art�culos Heredados por coste";	
		}
		numArticulosM = parseFloat(totalRefHerM);
		if(numArticulosM && numArticulosM != "") {
			mensaje += " y " + numArticulosM + " art�culos Heredados por margen";	
		}
		
	} else if(!actHeredado && actManual) {
		numArticulosC = parseFloat(totalRefManC);
		if(numArticulosC && numArticulosC != "") {
			mensaje += " y " + numArticulosC + " art�culos Manuales por coste";	
		}
		numArticulosM = parseFloat(totalRefManM);
		if(numArticulosM && numArticulosM != "") {
			mensaje += " y " + numArticulosM + " art�culos Manuales por margen";	
		}
	} else if(actHeredado && actManual) {

		numArticulosC = parseFloat(totalRefHerC) + parseFloat(totalRefManC);
		if(numArticulosC && numArticulosC != "") {
			mensaje += " y " + numArticulosC + " art�culos Heredados y Manuales por coste";	
		}
		numArticulosM = parseFloat(totalRefHerM) + parseFloat(totalRefManM);
		if(numArticulosM && numArticulosM != "") {
			mensaje += " y " + numArticulosM + " art�culos Heredados y Manuales por margen";	
		}
	}

	mensaje += "?";

	cursor.setValueBuffer("tamasactualizables",numTama);
	cursor.setValueBuffer("plantactualizables",numPlantillas);
	cursor.setValueBuffer("artactualizables",numArticulosC);
	cursor.setValueBuffer("artactualizablesmargen",numArticulosM);
	
	this.child("txtVPlanActualizables").text = numPlantillas;		
	this.child("txtVTamaActualizables").text = numTama;		
	this.child("txtVArtActualizables").text = numArticulosC;		
	this.child("txtVArtActualizablesMargen").text = numArticulosM;

	var ret = formUI.preguntaMsg(sys.translate(mensaje),"info",this,MessageBox.Yes, MessageBox.No); 

	if(ret != MessageBox.Yes) {
		return false;
	}
	
	return true;

}

function oficial_informaLabelsAct()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	//cursor.setValueBuffer("tamasactualizados",this.child("txtVTamaActualizables").text);
	//cursor.setValueBuffer("plantactualizados",this.child("txtVPlanActualizables").text);
	cursor.setValueBuffer("artactualizados",this.child("txtVArtActualizables").text);
	cursor.setValueBuffer("artactualizadosmargen",this.child("txtVArtActualizablesMargen").text);
	
			
	this.child("txtVTamaActualizados").text = cursor.valueBuffer("tamasactualizados");
	this.child("txtVPlanActualizados").text = cursor.valueBuffer("plantactualizados");		
	this.child("txtVArtActualizados").text = this.child("txtVArtActualizables").text;
	this.child("txtVArtActualizadosMargen").text = this.child("txtVArtActualizablesMargen").text;	
	
	return true;
}

/*function oficial_dameNumRefHer(f)
{
	debug("\n\ndameNumRefHer");
	var _i = this.iface;
	var cursor = this.cursor();
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	var idPlantilla = _i.t_.text(f, _i.cIDPLANTILLA_); 
	var codColeccion = _i.t_.text(f, _i.cCODCOLEC_);
	var codSubfamilia = _i.t_.text(f, _i.cCODSUBFAM_);
	var codTamano = _i.t_.text(f, _i.cCODTAMA_);
	var codColor = _i.t_.text(f, _i.cCODCOLOR_);
	var costeProd  = _i.t_.text(f, _i.cCOSTENUEVO_);
	var margenProd = _i.t_.text(f, _i.cMARGENNUEVO_);
	var obsCosteProd = cursor.valueBuffer("em_observcosteprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");
	var eliminarCostes = cursor.valueBuffer("eliminarcostes");
	var eliminarMargenes = cursor.valueBuffer("eliminarmargenes"); 
	var numRefC = 0;
	var numRefM= 0;
	var oRes = new Object;

	if(apPlantillas) {		
		var where = "codcoleccionem = '" + codColeccion + "' AND codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "' and codcolorem = '" + codColor + "'";	
		var whereCoste = "";
		var whereMargen = "";
		if(eliminarCostes) {
			whereCoste = "(em_costeprod IS NOT NULL AND em_tipocoste = 'Heredado')";
		} else if(costeProd && costeProd != ""){
			whereCoste = "((em_costeprod <> " + costeProd + " OR em_costeprod IS NULL OR em_observcosteprod <> '" + obsCosteProd + "') AND em_tipocoste = 'Heredado')";
		} else {
			whereCoste = "((em_costeprod IS NOT NULL OR em_observcosteprod <> '" + obsCosteProd + "') AND em_tipocoste = 'Heredado')";
		}

		if(eliminarMargenes) {
			whereMargen = "(em_margenprod IS NOT NULL AND em_tipomargen = 'Heredado')";
		} else if(margenProd && margenProd != ""){
			whereMargen = "((em_margenprod <> " + margenProd + " OR em_margenprod IS NULL OR em_observmargenprod <> '" + obsMargenProd + "') AND em_tipomargen = 'Heredado')";
		} else {
			whereMargen = "((em_margenprod IS NOT NULL OR em_observmargenprod <> '" + obsMargenProd + "') AND em_tipomargen = 'Heredado')";
		}

		if(whereCoste && whereCoste != "") {
			whereCoste = where + " AND " + whereCoste;		
			debug("whereCoste: "+whereCoste);	
			numRefC = AQUtil.sqlSelect("articulos","COUNT(*)",whereCoste);
		} else {
			numRefC = 0;
		}	

		if(whereMargen && whereMargen != "") {
			whereMargen = where + " AND " + whereMargen;
			debug("whereMargen: "+whereMargen);
			numRefM = AQUtil.sqlSelect("articulos","COUNT(*)",whereMargen);
		} else {
			numRefM = 0;
		}


	} else if(apTamanoSubFam) {	

		var where = "p.idplantilla IS NULL AND a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "'";
		var whereCoste = "";
		var whereMargen = "";
		if(eliminarCostes) {
			whereCoste = "(a.em_costeprod IS NOT NULL AND a.em_tipocoste = 'Heredado')";
		} else if(costeProd && costeProd != "") {
			whereCoste = "((a.em_costeprod <> " + costeProd + " OR a.em_costeprod IS NULL OR a.em_observcosteprod <> '" + obsCosteProd + "') AND a.em_tipocoste = 'Heredado')";	
		} else {
			//whereCoste = "((OR a.em_costeprod IS NOT NULL OR a.em_observcosteprod <> '" + obsCosteProd + "') AND a.em_tipocoste = 'Heredado')";	
			
		}

		if(eliminarMargenes) {
			whereMargen = "(a.em_margenprod IS NOT NULL AND a.em_tipomargen = 'Heredado')";
		} else if(margenProd && margenProd != "") {
			whereMargen = "((a.em_margenprod <> " + margenProd + " OR a.em_margenprod IS NULL OR a.em_observcosteprod <> '" + obsMargenProd + "') AND a.em_tipomargen = 'Heredado')";
		} else {
			//whereMargen = "((a.em_margenprod IS NOT NULL OR a.em_observcosteprod <> '" + obsMargenProd + "') AND a.em_tipomargen = 'Heredado')";

		}	

		if(whereCoste != "") {
			whereCoste = where + " AND " + whereCoste;
			numRefC = AQUtil.sqlSelect("articulos a LEFT OUTER JOIN em_plantillasprod p ON a.codcoleccionem = p.codcoleccionem AND a.codsubfamilia = p.codsubfamilia AND a.codtamanoem = p.codtamanoem AND a.codcolorem = p.codcolorem AND p.em_costeprod IS NOT NULL","COUNT(*)",whereCoste,"em_plantillasprod");
		} else {
			numRefC = 0;
		} 

		if(whereMargen != "") {
			whereMargen = where +  " AND " + whereMargen;
			numRefM = AQUtil.sqlSelect("articulos a LEFT OUTER JOIN em_plantillasprod p ON a.codcoleccionem = p.codcoleccionem AND a.codsubfamilia = p.codsubfamilia AND a.codtamanoem = p.codtamanoem AND a.codcolorem = p.codcolorem AND p.em_margenprod IS NOT NULL","COUNT(*)",whereMargen,"em_plantillasprod");
		} else {
			numRefM = 0;
		}		

	}
	if(!numRefC || numRefC == "") {
		numRefC = 0;
	}
	if(!numRefM || numRefM == "") {
		numRefM = 0;
	}

	oRes["numRefC"] = numRefC;
	oRes["numRefM"] = numRefM;
	return oRes;
}*/

function oficial_dameNumRefHer(f)
{
	//debug("\n\ndameNumRefHer");
	var _i = this.iface;
	var cursor = this.cursor();
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	var idPlantilla = _i.t_.text(f, _i.cIDPLANTILLA_); 
	var codColeccion = _i.t_.text(f, _i.cCODCOLEC_);
	var codSubfamilia = _i.t_.text(f, _i.cCODSUBFAM_);
	var codTamano = _i.t_.text(f, _i.cCODTAMA_);
	var codColor = _i.t_.text(f, _i.cCODCOLOR_);
	var costeProd  = _i.t_.text(f, _i.cCOSTENUEVO_);
	var margenProd = _i.t_.text(f, _i.cMARGENNUEVO_);
	var obsCosteProd = cursor.valueBuffer("em_observcosteprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");
	var eliminarCostes = cursor.valueBuffer("eliminarcostes");
	var eliminarMargenes = cursor.valueBuffer("eliminarmargenes"); 
	var numRefC = 0;
	var numRefM= 0;
	var oRes = new Object;

	if(apPlantillas) {		
		var where = "a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "' AND a.codcolorem = '" + codColor + "'";
		
		var whereCoste = "";
		var whereMargen = "";
		if(eliminarCostes) {
			whereCoste = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste ='plantilla alternativa')) AND (a.em_tipocoste = 'Heredado' AND a.em_costeprod IS NOT NULL)";
		} else if(costeProd && costeProd != ""){
			whereCoste = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste ='plantilla alternativa')) AND (a.em_tipocoste = 'Heredado' AND (a.em_costeprod <> " + costeProd + " OR a.em_costeprod IS NULL OR a.em_observcosteprod <> '" + obsCosteProd + "'))";
		} else {
			//whereCoste = "((a.em_costeprod IS NOT NULL OR a.em_observcosteprod <> '" + obsCosteProd + "'))";
		}

		if(eliminarMargenes) {
			whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen ='plantilla alternativa')) AND (a.em_tipomargen = 'Heredado' AND a.em_margenprod IS NOT NULL)";
		} else if(margenProd && margenProd != ""){			
			whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen ='plantilla alternativa')) AND (a.em_tipomargen = 'Heredado' AND (a.em_margenprod <> " + margenProd + " OR a.em_margenprod IS NULL OR a.em_observmargenprod <> '" + obsMargenProd + "'))";
		} else {
			//whereMargen = "((a.em_margenprod IS NOT NULL OR a.em_observmargenprod <> '" + obsMargenProd + "'))";
		}

		if(whereCoste && whereCoste != "") {
			whereCoste = where + " AND " + whereCoste;		
			//debug("whereCoste: "+whereCoste);	
			numRefC = AQUtil.sqlSelect("articulos a INNER JOIN v_origencostemargen ori ON a.referencia = ori.referencia","COUNT(*)",whereCoste,"articulos");
		} else {
			numRefC = 0;
		}	

		if(whereMargen && whereMargen != "") {
			whereMargen = where + " AND " + whereMargen;
			//debug("whereMargen: "+whereMargen);
			numRefM = AQUtil.sqlSelect("articulos a INNER JOIN v_origencostemargen ori ON a.referencia = ori.referencia","COUNT(*)",whereMargen,"articulos");
		} else {
			numRefM = 0;
		}


	} else if(apTamanoSubFam) {	

		var where = "a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "'";
		var whereCoste = "";
		var whereMargen = "";
		if(eliminarCostes) {
			whereCoste = "ori.origencoste = 'tama�os por subfamilia' AND (a.em_tipocoste = 'Heredado' AND a.em_costeprod IS NOT NULL)";
		} else if(costeProd && costeProd != "") {
			whereCoste = "ori.origencoste = 'tama�os por subfamilia' AND (a.em_tipocoste = 'Heredado' AND (a.em_costeprod <> " + costeProd + " OR a.em_costeprod IS NULL OR a.em_observcosteprod <> '" + obsCosteProd + "'))";	
		} else {
			//whereCoste = "((OR a.em_costeprod IS NOT NULL OR a.em_observcosteprod <> '" + obsCosteProd + "') AND a.em_tipocoste = 'Heredado')";	
			
		}

		if(eliminarMargenes) {
			whereMargen = "ori.origenmargen = 'tama�os por subfamilia' AND (a.em_tipomargen = 'Heredado' AND a.em_margenprod IS NOT NULL)";
		} else if(margenProd && margenProd != "") {
			whereMargen = "ori.origenmargen = 'tama�os por subfamilia' AND (a.em_tipomargen = 'Heredado' AND (a.em_margenprod <> " + margenProd + " OR a.em_margenprod IS NULL OR a.em_observcosteprod <> '" + obsMargenProd + "'))";
		} else {
			//whereMargen = "((a.em_margenprod IS NOT NULL OR a.em_observcosteprod <> '" + obsMargenProd + "') AND a.em_tipomargen = 'Heredado')";

		}	

		if(whereCoste != "") {
			whereCoste = where + " AND " + whereCoste;
			//debug("whereCoste: "+whereCoste);	
			numRefC = AQUtil.sqlSelect("articulos a INNER JOIN v_origencostemargen ori ON a.referencia = ori.referencia","COUNT(*)",whereCoste,"articulos");
		} else {
			numRefC = 0;
		} 

		if(whereMargen != "") {
			whereMargen = where +  " AND " + whereMargen;
			//debug("whereMargen: "+whereMargen);
			numRefM = AQUtil.sqlSelect("articulos a INNER JOIN v_origencostemargen ori ON a.referencia = ori.referencia","COUNT(*)",whereMargen,"articulos");
		} else {
			numRefM = 0;
		}		

	}
	if(!numRefC || numRefC == "") {
		numRefC = 0;
	}
	if(!numRefM || numRefM == "") {
		numRefM = 0;
	}

	oRes["numRefC"] = numRefC;
	oRes["numRefM"] = numRefM;
	return oRes;
}

/*function oficial_dameNumRefMan(f)
{
	debug("\n\n\noficial_dameNumRefMan");
	var _i = this.iface;
	var cursor = this.cursor();
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	var idPlantilla = _i.t_.text(f, _i.cIDPLANTILLA_); 
	var codColeccion = _i.t_.text(f, _i.cCODCOLEC_);
	var codSubfamilia = _i.t_.text(f, _i.cCODSUBFAM_);
	var codTamano = _i.t_.text(f, _i.cCODTAMA_);
	var codColor = _i.t_.text(f, _i.cCODCOLOR_);
	var costeProd  = _i.t_.text(f, _i.cCOSTENUEVO_);
	var margenProd = _i.t_.text(f, _i.cMARGENNUEVO_);
	var obsCosteProd = cursor.valueBuffer("em_observcosteprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");
	var numRefC = 0;
	var numRefM= 0;
	var oRes = new Object;

	if(apPlantillas) {	
		var where = "codcoleccionem = '" + codColeccion + "' AND codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "' and codcolorem = '" + codColor + "'";	
		var whereCoste = "(em_costeprod = " + costeProd + " AND em_tipocoste = 'Manual')";
		var whereMargen = "(em_margenprod = " + margenProd + " AND em_tipomargen = 'Manual')";
		if(costeProd && costeProd != "") {
			whereCoste = where + " AND " + whereCoste;
			debug("whereCoste: "+whereCoste);
			numRefC = AQUtil.sqlSelect("articulos","COUNT(*)",whereCoste);
		} else {
			numRefC = 0;
		}	

		if(margenProd && margenProd != "") {

			whereMargen = where + " AND " + whereMargen;
			debug("whereMargen: "+whereMargen);
			numRefM = AQUtil.sqlSelect("articulos","COUNT(*)",whereMargen);
		} else {
			numRefM = 0;
		}	

	} else if(apTamanoSubFam) {

		var where = "p.idplantilla IS NULL AND a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "'";
		var whereCoste = "(a.em_costeprod = " + costeProd + " AND a.em_tipocoste = 'Manual')";
		var whereMargen = "(a.em_margenprod = " + margenProd + " AND a.em_tipomargen = 'Manual')";

		if(costeProd && costeProd != "") {
			whereCoste = where + " AND " + whereCoste;
			numRefC = AQUtil.sqlSelect("articulos a LEFT OUTER JOIN em_plantillasprod p ON a.codcoleccionem = p.codcoleccionem AND a.codsubfamilia = p.codsubfamilia AND a.codtamanoem = p.codtamanoem AND a.codcolorem = p.codcolorem AND p.em_costeprod IS NOT NULL","COUNT(*)",whereCoste,"em_plantillasprod");
		} else {
			numRefC = 0;
		}	

		if(margenProd && margenProd != "") {
			whereMargen = where + " AND " + whereMargen;
			numRefM = AQUtil.sqlSelect("articulos a LEFT OUTER JOIN em_plantillasprod p ON a.codcoleccionem = p.codcoleccionem AND a.codsubfamilia = p.codsubfamilia AND a.codtamanoem = p.codtamanoem AND a.codcolorem = p.codcolorem AND p.em_margenprod IS NOT NULL","COUNT(*)",whereMargen,"em_plantillasprod");
		} else {
			numRefM = 0;
		}
		//debug("numRefTamMan: "+numRef);
		//debug("whereTamMan: "+where);
	}
	if(!numRefC || numRefC == "") {
		numRefC = 0;
	}
	if(!numRefM || numRefM == "") {
		numRefM = 0;
	}

	oRes["numRefC"] = numRefC;
	oRes["numRefM"] = numRefM;

	return oRes;

}*/

function oficial_dameNumRefMan(f)
{
	//debug("\n\n\noficial_dameNumRefMan");
	var _i = this.iface;
	var cursor = this.cursor();
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	var idPlantilla = _i.t_.text(f, _i.cIDPLANTILLA_); 
	var codColeccion = _i.t_.text(f, _i.cCODCOLEC_);
	var codSubfamilia = _i.t_.text(f, _i.cCODSUBFAM_);
	var codTamano = _i.t_.text(f, _i.cCODTAMA_);
	var codColor = _i.t_.text(f, _i.cCODCOLOR_);
	var costeProd  = _i.t_.text(f, _i.cCOSTENUEVO_);
	var margenProd = _i.t_.text(f, _i.cMARGENNUEVO_);
	var obsCosteProd = cursor.valueBuffer("em_observcosteprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");
	var numRefC = 0;
	var numRefM= 0;
	var oRes = new Object;

	if(apPlantillas) {	
		var where = "a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "' AND a.codcolorem = '" + codColor + "'";

		var whereCoste = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste = 'plantilla alternativa')) AND (a.em_tipocoste = 'Manual' AND a.em_costeprod = " + costeProd + ")";
		var whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen = 'plantilla alternativa')) AND (a.em_tipomargen = 'Manual' AND a.em_margenprod = " + margenProd + ")";
		if(costeProd && costeProd != "") {
			whereCoste = where + " AND " + whereCoste;
			//debug("whereCoste: "+whereCoste);
			numRefC = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereCoste,"articulos");
		} else {
			numRefC = 0;
		}	

		if(margenProd && margenProd != "") {
			whereMargen = where + " AND " + whereMargen;
			//debug("whereMargen: "+whereMargen);
			numRefM = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereMargen,"articulos");
		} else {
			numRefM = 0;
		}	

	} else if(apTamanoSubFam) {

		var where = "a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "'";
		var whereCoste = "ori.origencoste = 'tama�os por subfamilia' AND a.em_costeprod = " + costeProd + " AND a.em_tipocoste = 'Manual'";
		var whereMargen = "ori.origenmargen = 'tama�os por subfamilia' AND a.em_margenprod = " + margenProd + " AND a.em_tipomargen = 'Manual'";

		if(costeProd && costeProd != "") {
			whereCoste = where + " AND " + whereCoste;
			numRefC = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereCoste,"em_plantillasprod");
		} else {
			numRefC = 0;
		}	

		if(margenProd && margenProd != "") {
			whereMargen = where + " AND " + whereMargen;
			numRefM = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereMargen,"em_plantillasprod");
		} else {
			numRefM = 0;
		}
		//debug("numRefTamMan: "+numRef);
		//debug("whereTamMan: "+where);
	}
	if(!numRefC || numRefC == "") {
		numRefC = 0;
	}
	if(!numRefM || numRefM == "") {
		numRefM = 0;
	}

	oRes["numRefC"] = numRefC;
	oRes["numRefM"] = numRefM;

	return oRes;

}



function oficial_cambiaDatos()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var hoy = new Date();
	var hora = hoy.toString().right(8);
	var idUsuario = sys.nameUser();	

	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	var actHeredado = cursor.valueBuffer("actheredado");
	var actManual = cursor.valueBuffer("actmanual");
	var eliminarCostes = cursor.valueBuffer("eliminarcostes");
	var eliminarMargenes = cursor.valueBuffer("eliminarmargenes"); 
	var costeActual;
	var costeNuevo;
	var margenActual;
	var margenNuevo;
	var numReg = 0;


	var nF = _i.t_.numRows();
	var c = _i.cSEL_;	
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Actualizando datos"), nF);
	var p = 0;
	var costeNuevo, margenNuevo;
	var obsCosteProd = cursor.valueBuffer("em_observcosteprod");
	var obsMargenProd = cursor.valueBuffer("em_observmargenprod");

	var idPlantilla;
	if(!obsCosteProd) {
		obsCosteProd = "";
	}
	if(!obsMargenProd) {
		obsMargenProd = "";
	}	

	if(apPlantillas) {	
		var where;
		var codColeccion, codSubfamilia,codTamano,codColor; 
		for (var f = 0; f < nF; f++) {
			AQUtil.setProgress(p++);
			costeActual = parseFloat(_i.t_.text(f, _i.cCOSTEACT_));
			costeProd = parseFloat(_i.t_.text(f, _i.cCOSTENUEVO_));
			margenActual = parseFloat(_i.t_.text(f, _i.cMARGENACT_));
			margenProd = parseFloat(_i.t_.text(f, _i.cMARGENNUEVO_));

			if(!costeProd || costeProd == "") {
				costeProd = "NULL";
			}				
			if(!margenProd || margenProd == "") {
				margenProd = "NULL";
			}
			if(!costeActual || costeActual == "") {
				costeActual = "NULL";
			}				
			if(!margenActual || margenActual == "") {
				margenActual = "NULL";
			}

			/*debug("\n\n*******************************");
			debug("costeActual: "+costeActual);
			debug("costeProd: "+costeProd);
			debug("margenActual: "+margenActual);
			debug("margenProd: "+margenProd);
			debug("eliminarCostes: "+eliminarCostes);
			debug("eliminarMargenes: "+eliminarMargenes);*/




			//if (_i.t_.text(f, c) == "X" && (costeActual != costeProd || margenActual !=  margenProd || eliminarCostes || eliminarMargenes))  {
			if (_i.t_.text(f, c) == "X")  {	
				

				idPlantilla = _i.t_.text(f, _i.cIDPLANTILLA_); 
				codColeccion = _i.t_.text(f, _i.cCODCOLEC_);
				codSubfamilia = _i.t_.text(f, _i.cCODSUBFAM_);
				codTamano = _i.t_.text(f, _i.cCODTAMA_);
				codColor = _i.t_.text(f, _i.cCODCOLOR_);			
			
				numReg++;



				where = "codcoleccionem = '" + codColeccion + "' AND codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "' and codcolorem = '" + codColor + "'";	

				if(((costeProd != "NULL" && costeActual != costeProd) && (margenProd != "NULL" && margenActual !=  margenProd)) || (eliminarCostes && eliminarMargenes)) {

					if(!AQUtil.execSql("UPDATE em_plantillasprod SET em_costeprod = " + costeProd + ", em_observcosteprod = '" + obsCosteProd + "', em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "', em_margenprod = " + margenProd + ", em_observmargenprod = '" + obsMargenProd + "', em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "' WHERE " + where)) {
						return false;
					}

					if(!AQUtil.execSql("INSERT INTO em_logcostesmargenes(gridasociado,fechahis,horahis,usuariohis,em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod,idplantilla,em_fechacosteprod,em_horacosteprod,em_idusuariocosteprod,em_costeprod, em_observcosteprod, em_actcostes, em_actmargenes,em_activarcostesher,em_activarmargenher) VALUES('plantillas','" + hoy + "','" + hora + "','" + idUsuario + "'," + margenProd + ",'" + hoy + "','" + hora + "','" + idUsuario + "','" + obsMargenProd + "'," + idPlantilla + ",'" + hoy + "','" + hora + "','" + idUsuario + "'," + costeProd + ",'" + obsCosteProd + "'," + actHeredado + "," + actHeredado + "," + actManual + "," + actManual + ")")) {
						return false;					
					}
				} else {
					if((costeProd != "NULL" && costeActual != costeProd) || eliminarCostes) {
						if(!AQUtil.execSql("UPDATE em_plantillasprod SET em_costeprod = " + costeProd + ", em_observcosteprod = '" + obsCosteProd + "', em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "' WHERE " + where)) {
							return false;
						}

						if(!AQUtil.execSql("INSERT INTO em_logcostesmargenes(gridasociado,fechahis,horahis,usuariohis,em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod,idplantilla,em_fechacosteprod,em_horacosteprod,em_idusuariocosteprod,em_costeprod, em_observcosteprod, em_actcostes, em_actmargenes,em_activarcostesher,em_activarmargenher) SELECT 'plantillas','" + hoy + "','" + hora + "','" + idUsuario + "',em_margenprod, em_fechamargenprod,em_horamargenprod,em_idusuariomargenprod, em_observmargenprod," + idPlantilla + ",'" + hoy + "','" + hora + "','" + idUsuario + "'," + costeProd + ",'" + obsCosteProd + "'," + actHeredado + "," + actHeredado + "," + actManual + "," + actManual + " FROM em_plantillasprod WHERE "+ where )) {
							return false;					
						}

					}

					if((margenProd != "NULL" && margenActual !=  margenProd) || eliminarMargenes) {
						if(!AQUtil.execSql("UPDATE em_plantillasprod SET em_margenprod = " + margenProd + ", em_observmargenprod = '" + obsMargenProd + "', em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "' WHERE " + where)) {
							return false;
						}

						if(!AQUtil.execSql("INSERT INTO em_logcostesmargenes(gridasociado,fechahis,horahis,usuariohis,em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod,idplantilla,em_fechacosteprod,em_horacosteprod,em_idusuariocosteprod,em_costeprod, em_observcosteprod, em_actcostes, em_actmargenes,em_activarcostesher,em_activarmargenher) SELECT 'plantillas','" + hoy + "','" + hora + "','" + idUsuario + "'," + margenProd + ",'" + hoy + "','" + hora + "','" + idUsuario + "','" + obsMargenProd + "'," + idPlantilla + ",em_fechacosteprod, em_horacosteprod,em_idusuariocosteprod, em_costeprod, em_observcosteprod, " + actHeredado + "," + actHeredado + "," + actManual + "," + actManual + " FROM em_plantillasprod WHERE " + where)) {
							return false;					
						}
					}

				}

				if(actManual) {



					/*var where = "a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "' AND a.codcolorem = '" + codColor + "'";

					var whereCoste = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste = 'plantilla alternativa')) AND (a.em_tipocoste = 'Manual' AND a.em_costeprod = " + costeProd + ")";
					var whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen = 'plantilla alternativa')) AND (a.em_tipomargen = 'Manual' AND a.em_margenprod = " + margenProd + ")";
					if(costeProd && costeProd != "") {
						whereCoste = where + " AND " + whereCoste;
						debug("whereCoste: "+whereCoste);
						numRefC = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereCoste,"articulos");
					} else {
						numRefC = 0;
					}	

					if(margenProd && margenProd != "") {
						whereMargen = where + " AND " + whereMargen;
						debug("whereMargen: "+whereMargen);
						numRefM = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereMargen,"articulos");
					} else {
						numRefM = 0;
					}	*/

					where = "articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND articulos.codcolorem = '" + codColor + "'";
					var whereCoste = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste = 'plantilla alternativa')) AND (articulos.em_tipocoste = 'Manual' AND articulos.em_costeprod = " + costeProd + ")";
					var whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen = 'plantilla alternativa')) AND (articulos.em_tipomargen = 'Manual' AND articulos.em_margenprod = " + margenProd + ")";

					//COSTES
					//if((costeProd != "NULL" && costeActual != costeProd) || eliminarCostes) {
					if(costeProd != "NULL" || eliminarCostes) {

						//debug("Select log: SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',ori.origencoste,CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END,articulos.em_margenprod,articulos.em_fechamargenprod,articulos.em_horamargenprod, articulos.em_idusuariomargenprod,articulos.em_observmargenprod ,articulos.referencia, articulos.em_fechacosteprod,articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, 'Heredado', articulos.em_tipomargen FROM articulos INNER JOIN v_origenherenciaman ori ON articulos.referencia = ori.referencia WHERE " + where + " AND " + whereCoste);

						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',ori.origencoste,CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END,articulos.em_margenprod,articulos.em_fechamargenprod,articulos.em_horamargenprod, articulos.em_idusuariomargenprod,articulos.em_observmargenprod ,articulos.referencia, articulos.em_fechacosteprod,articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, 'Heredado', articulos.em_tipomargen FROM articulos INNER JOIN v_origenherenciaman ori ON articulos.referencia = ori.referencia WHERE " + where + " AND " + whereCoste)) {
							return false;						
						}



						if(!AQUtil.execSql("UPDATE articulos SET em_tipocoste = 'Heredado', em_origencoste = ori.origencoste FROM v_origenherenciaman ori WHERE articulos.referencia = ori.referencia AND " + where + " AND " + whereCoste)) {
							return false;
						}
					}


					//MARGENES
					//if((margenProd != "NULL" && margenActual !=  margenProd) || eliminarMargenes) {
					if(margenProd != "NULL" || eliminarMargenes) {
						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',CASE articulos.em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origencoste END,ori.origenmargen,articulos.em_margenprod,articulos.em_fechamargenprod,articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod,articulos.referencia,articulos.em_fechacosteprod,articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, articulos.em_tipocoste, 'Heredado' FROM articulos INNER JOIN v_origenherenciaman ori ON articulos.referencia = ori.referencia WHERE " + where + " AND " + whereMargen)) {
							return false;						
						}					

						if(!AQUtil.execSql("UPDATE articulos SET em_tipomargen = 'Heredado', em_origenmargen = ori.origenmargen FROM v_origenherenciaman ori WHERE articulos.referencia = ori.referencia AND " + where + " AND " + whereMargen)) {
							return false;
							
						}
					}
				}



				/*var where = "a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "' AND a.codcolorem = '" + codColor + "'";
				
				var whereCoste = "";
				var whereMargen = "";
				if(eliminarCostes) {
					whereCoste = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste ='plantilla alternativa')) AND (a.em_tipocoste = 'Heredado' AND a.em_costeprod IS NOT NULL)";
				} else if(costeProd && costeProd != ""){
					whereCoste = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste ='plantilla alternativa')) AND (a.em_tipocoste = 'Heredado' AND (a.em_costeprod <> " + costeProd + " OR a.em_costeprod IS NULL OR a.em_observcosteprod <> '" + obsCosteProd + "'))";
				} else {
					//whereCoste = "((a.em_costeprod IS NOT NULL OR a.em_observcosteprod <> '" + obsCosteProd + "'))";
				}

				if(eliminarMargenes) {
					whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen ='plantilla alternativa')) AND (a.em_tipomargen = 'Heredado' AND a.em_margenprod IS NOT NULL)";
				} else if(margenProd && margenProd != ""){			
					whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen ='plantilla alternativa')) AND (a.em_tipomargen = 'Heredado' AND (a.em_margenprod <> " + margenProd + " OR a.em_margenprod IS NULL OR a.em_observmargenprod <> '" + obsMargenProd + "'))";
				} else {
					//whereMargen = "((a.em_margenprod IS NOT NULL OR a.em_observmargenprod <> '" + obsMargenProd + "'))";
				}





				*/

				if(actHeredado) {				
					//obsMargenProd = 'log4';
					//log margenes y articulos tipomargen heredado
					//em_actcostes
					//em_actmargenes

					where = "articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "' AND articulos.codcolorem = '" + codColor + "'";
					if(eliminarCostes) {
						whereCostes = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste ='plantilla alternativa')) AND (articulos.em_tipocoste = 'Heredado' AND articulos.em_costeprod IS NOT NULL)";
					} else {
						whereCostes = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origencoste = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origencoste ='plantilla alternativa')) AND (articulos.em_tipocoste = 'Heredado' AND (articulos.em_costeprod <> " + costeProd + " OR articulos.em_costeprod IS NULL OR articulos.em_observcosteprod <> '" + obsCosteProd + "'))";						
					}
					if(eliminarMargenes) {
						whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen ='plantilla alternativa')) AND (articulos.em_tipomargen = 'Heredado' AND articulos.em_margenprod IS NOT NULL)";						
					} else {
						whereMargen = "((ori.codcoleccionem = '" + codColeccion + "' AND ori.origenmargen = 'plantilla') OR (ori.codcoleccion_alternativa = '" + codColeccion + "' AND ori.origenmargen ='plantilla alternativa')) AND (articulos.em_tipomargen = 'Heredado' AND (articulos.em_margenprod <> " + margenProd + " OR articulos.em_margenprod IS NULL OR articulos.em_observmargenprod <> '" + obsMargenProd + "'))";
					}
					//COSTES
					if((costeProd != "NULL" && costeActual != costeProd) || eliminarCostes) {
						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste,em_origenmargen,em_margenprod, em_fechamargenprod,em_horamargenprod,em_idusuariomargenprod,em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod,em_costeprod, em_idusuariocosteprod,em_observcosteprod,em_tipocoste,em_tipomargen) SELECT 'articulos','" + hoy + "','" + hora + "','" + idUsuario + "',ori.origencoste, CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END, articulos.em_margenprod,articulos.em_fechamargenprod,articulos.em_horamargenprod,articulos.em_idusuariomargenprod, articulos.em_observmargenprod, articulos.referencia,'" + hoy + "','" + hora + "'," + costeProd + ",'" + idUsuario + "','" + obsCosteProd + "',articulos.em_tipocoste, articulos.em_tipomargen FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia WHERE " + where + " AND " + whereCostes)) {
							return false;				

						}		

						if(eliminarCostes) {
							if(!AQUtil.execSql("UPDATE articulos SET em_origencoste = ori.origencoste, em_costeprod = NULL, em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "', em_observcosteprod = '" + obsCosteProd + "' FROM v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereCostes)) {								
								return false;
							}	

						} else {
							//tipocoste heredado
							if(!AQUtil.execSql("UPDATE articulos SET em_origencoste = ori.origencoste, em_costeprod = " + costeProd + ", em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "', em_observcosteprod = '" + obsCosteProd + "' FROM v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereCostes)) {								
								return false;
							}	
						}
					}

					//MARGENES
					if((margenProd != "NULL" && margenActual !=  margenProd) || eliminarMargenes) {

						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste,em_origenmargen,em_margenprod, em_fechamargenprod,em_horamargenprod,em_idusuariomargenprod,em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod,em_costeprod, em_idusuariocosteprod,em_observcosteprod,em_tipocoste,em_tipomargen) SELECT 'articulos','" + hoy + "','" + hora + "','" + idUsuario + "',articulos.em_origencoste, ori.origenmargen, " + margenProd + ", '" + hoy + "', '" + hora + "', '" + idUsuario + "', '" + obsMargenProd + "', articulos.referencia,articulos.em_fechacosteprod,em_horacosteprod,em_costeprod,em_idusuariocosteprod,em_observcosteprod,articulos.em_tipocoste, articulos.em_tipomargen FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia WHERE " + where + " AND " + whereMargen)) {
							return false;				

						}


						if(eliminarMargenes) {
							if(!AQUtil.execSql("UPDATE articulos SET em_origenmargen = ori.origenmargen, em_margenprod = NULL, em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "', em_observmargenprod = '" + obsMargenProd + "' FROM v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereMargen)) {				
								return false;						
							}

						} else {
							//tipomargen heredado
							if(!AQUtil.execSql("UPDATE articulos SET em_origenmargen = ori.origenmargen, em_margenprod = " + margenProd + ", em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "', em_observmargenprod = '" + obsMargenProd + "' FROM v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereMargen)) {				
								return false;						
							}
						}	

					}	
	
				}
			}
		}
		//debug("\n\nNumActualizados: "+numReg);
		cursor.setValueBuffer("tamasactualizados",0);
		cursor.setValueBuffer("plantactualizados",numReg);
		//cursor.setValueBuffer("artactualizados",this.child("txtVArtActualizables").text);



	} else if(apTamanoSubFam) {
		var where;
		var whereArticulos;
		var codSubfamilia,codTamano; 
		for (var f = 0; f < nF; f++) {
			AQUtil.setProgress(p++);

			costeActual = parseFloat(_i.t_.text(f, _i.cCOSTEACT_));
			costeProd = parseFloat(_i.t_.text(f, _i.cCOSTENUEVO_));
			margenActual = parseFloat(_i.t_.text(f, _i.cMARGENACT_));
			margenProd = parseFloat(_i.t_.text(f, _i.cMARGENNUEVO_));

			if(!costeProd || costeProd == "") {
				costeProd = "NULL";
			}				
			if(!margenProd || margenProd == "") {
				margenProd = "NULL";
			}
			if(!costeActual || costeActual == "") {
				costeActual = "NULL";
			}				
			if(!margenActual || margenActual == "") {
				margenActual = "NULL";
			}

			//if (_i.t_.text(f, c) == "X" && (costeActual != costeProd || margenActual !=  margenProd || eliminarCostes || eliminarMargenes))  {				 				
			if (_i.t_.text(f, c) == "X")  {				 				
				codSubfamilia = _i.t_.text(f, _i.cCODSUBFAM_);
				codTamano = _i.t_.text(f, _i.cCODTAMA_);		
				numReg++;

				where = "codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "'";
				whereArticulos = "p.idplantilla IS NULL AND articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "'";

				if(((costeProd != "NULL" && costeActual != costeProd) && (margenProd != "NULL" && margenActual !=  margenProd)) || (eliminarCostes && eliminarMargenes)) {
					//tengo datos en costeprod y en margenprod o tengo eliminar los dos, as� que actualizo a los dos
					if(!AQUtil.execSql("UPDATE em_tamanossubfam SET em_costeprod = " + costeProd + ", em_observcosteprod = '" + obsCosteProd + "', em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "', em_margenprod = " + margenProd + ", em_observmargenprod = '" + obsMargenProd + "', em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "' WHERE  " + where)) {
						return false;
					}

					if(!AQUtil.execSql("INSERT INTO em_logcostesmargenes(gridasociado,fechahis,horahis,usuariohis,em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod,codsubfamilia,codtamanoem,em_fechacosteprod,em_horacosteprod,em_idusuariocosteprod,em_costeprod, em_observcosteprod, em_actcostes, em_actmargenes,em_activarcostesher,em_activarmargenher) VALUES('tama�os por subfamilia','" + hoy + "','" + hora + "','" + idUsuario + "'," + margenProd + ",'" + hoy + "','" + hora + "','" + idUsuario + "','" + obsMargenProd + "','" + codSubfamilia + "','" + codTamano + "','" + hoy + "','" + hora + "','" + idUsuario + "'," + costeProd + ",'" + obsCosteProd + "'," + actHeredado + "," + actHeredado + "," + actManual + "," + actManual + ")")) {
						return false;					
					}			
				} else {

					if((costeProd != "NULL" && costeActual != costeProd) || eliminarCostes) {
					//tengo datos solo en costeprod o tengo marcado el check de borrar costeprod
						if(!AQUtil.execSql("UPDATE em_tamanossubfam SET em_costeprod = " + costeProd + ", em_observcosteprod = '" + obsCosteProd + "', em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "' WHERE  " + where)) {
							return false;
						}
						if(!AQUtil.execSql("INSERT INTO em_logcostesmargenes(gridasociado,fechahis,horahis,usuariohis,em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod,codsubfamilia,codtamanoem,em_fechacosteprod,em_horacosteprod,em_idusuariocosteprod,em_costeprod, em_observcosteprod, em_actcostes, em_actmargenes,em_activarcostesher,em_activarmargenher) SELECT 'tama�os por subfamilia','" + hoy + "','" + hora + "','" + idUsuario + "',em_margenprod, em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod, '" + codSubfamilia + "','" + codTamano + "','" + hoy + "','" + hora + "','" + idUsuario + "'," + costeProd + ",'" + obsCosteProd + "'," + actHeredado + "," + actHeredado + "," + actManual + "," + actManual + " FROM em_tamanossubfam WHERE codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "'")) {
							return false;					
						}
					}

					if((margenProd != "NULL" && margenActual !=  margenProd) || eliminarMargenes) {
					//tengo datos solo en margenprod o tengo marcado el check de borrar margenprod	

						if(!AQUtil.execSql("UPDATE em_tamanossubfam SET em_margenprod = " + margenProd + ", em_observmargenprod = '" + obsMargenProd + "', em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "' WHERE  " + where)) {
							return false;
						}
						if(!AQUtil.execSql("INSERT INTO em_logcostesmargenes(gridasociado,fechahis,horahis,usuariohis,em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod,em_observmargenprod,codsubfamilia,codtamanoem,em_fechacosteprod,em_horacosteprod,em_idusuariocosteprod,em_costeprod, em_observcosteprod, em_actcostes, em_actmargenes,em_activarcostesher,em_activarmargenher) SELECT 'tama�os por subfamilia','" + hoy + "','" + hora + "','" + idUsuario + "'," + margenProd + ",'" + hoy + "','" + hora + "','" + idUsuario + "','" + obsMargenProd + "','" + codSubfamilia + "','" + codTamano + "',em_fechacosteprod,em_horacosteprod,em_idusuariocosteprod,em_costeprod,em_observcosteprod," + actHeredado + "," + actHeredado + "," + actManual + "," + actManual + " FROM em_tamanossubfam WHERE codsubfamilia = '" + codSubfamilia + "' AND codtamanoem = '" + codTamano + "'")) {
							return false;					
						}
					}
				}

				if(actManual) {


					/*var where = "a.codsubfamilia = '" + codSubfamilia + "' AND a.codtamanoem = '" + codTamano + "'";
					var whereCoste = "ori.origencoste = 'tama�os por subfamilia' AND a.em_costeprod = " + costeProd + " AND a.em_tipocoste = 'Manual'";
					var whereMargen = "ori.origenmargen = 'tama�os por subfamilia' AND a.em_margenprod = " + margenProd + " AND a.em_tipomargen = 'Manual'";

					if(costeProd && costeProd != "") {
						whereCoste = where + " AND " + whereCoste;
						numRefC = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereCoste,"em_plantillasprod");
					} else {
						numRefC = 0;
					}	

					if(margenProd && margenProd != "") {
						whereMargen = where + " AND " + whereMargen;
						numRefM = AQUtil.sqlSelect("articulos a INNER JOIN v_origenherenciaman ori ON a.referencia = ori.referencia","COUNT(*)",whereMargen,"em_plantillasprod");
					} else {
						numRefM = 0;
					}*/

					var where = "articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "'";
					var whereCoste = "ori.origencoste = 'tama�os por subfamilia' AND articulos.em_costeprod = " + costeProd + " AND articulos.em_tipocoste = 'Manual'";
					var whereMargen = "ori.origenmargen = 'tama�os por subfamilia' AND articulos.em_margenprod = " + margenProd + " AND articulos.em_tipomargen = 'Manual'";


					//COSTES
					//if((costeProd != "NULL" && costeActual != costeProd) || eliminarCostes) {
					if(costeProd != "NULL" || eliminarCostes) {
						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',ori.origencoste,CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END, articulos.em_margenprod, articulos.em_fechamargenprod, articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod ,articulos.referencia, articulos.em_fechacosteprod, articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, 'Heredado' ,articulos.em_tipomargen FROM articulos INNER JOIN v_origenherenciaman ori ON articulos.referencia = ori.referencia WHERE " + where + " AND  " + whereCoste)) {
							return false;						
						}

						if(!AQUtil.execSql("UPDATE articulos SET em_tipocoste = 'Heredado', em_origencoste = ori.origencoste FROM v_origenherenciaman ori WHERE articulos.referencia = ori.referencia AND " + where + " AND " + whereCoste)) {
							return false;
						}
					}

					//MARGEN
					//if((margenProd != "NULL" && margenActual !=  margenProd) || eliminarMargenes) {
					if(margenProd != "NULL" || eliminarMargenes) {
						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste, em_origenmargen, em_margenprod,em_fechamargenprod,em_horamargenprod, em_idusuariomargenprod, em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod, em_costeprod, em_idusuariocosteprod, em_observcosteprod, em_tipocoste, em_tipomargen) SELECT 'articulos','" + hoy + "', '" + hora + "', '" + idUsuario + "',CASE articulos.em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origencoste END,ori.origenmargen, articulos.em_margenprod, articulos.em_fechamargenprod, articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod, articulos.referencia, articulos.em_fechacosteprod, articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod, articulos.em_observcosteprod, articulos.em_tipocoste, 'Heredado' FROM articulos INNER JOIN v_origenherenciaman ori ON articulos.referencia = ori.referencia WHERE " + where + " AND  " + whereMargen)) {
							return false;						
						}					

						if(!AQUtil.execSql("UPDATE articulos SET em_tipomargen = 'Heredado', em_origenmargen = ori.origenmargen FROM v_origenherenciaman ori WHERE articulos.referencia = ori.referencia AND " + where + " AND " + whereMargen)) {
							return false;
							
						}
					}
				}

				if(actHeredado) {				
					//obsMargenProd = 'log4';
					//log margenes y articulos tipomargen heredado

					where = "articulos.codsubfamilia = '" + codSubfamilia + "' AND articulos.codtamanoem = '" + codTamano + "'";

					if(eliminarCostes) {
						whereCostes = "ori.origencoste = 'tama�os por subfamilia' AND (articulos.em_tipocoste = 'Heredado' AND articulos.em_costeprod IS NOT NULL)";		
					} else {
						whereCostes = "ori.origencoste = 'tama�os por subfamilia' AND (articulos.em_tipocoste = 'Heredado' AND (articulos.em_costeprod <> " + costeProd + " OR articulos.em_costeprod IS NULL OR articulos.em_observcosteprod <> '" + obsCosteProd + "'))";							
						
					}
					if(eliminarMargenes) {
						whereMargen = "ori.origenmargen = 'tama�os por subfamilia' AND (articulos.em_tipomargen = 'Heredado' AND articulos.em_margenprod IS NOT NULL)";		
					} else {
						whereMargen = "ori.origenmargen = 'tama�os por subfamilia' AND (articulos.em_tipomargen = 'Heredado' AND (articulos.em_margenprod <> " + margenProd + " OR articulos.em_margenprod IS NULL OR articulos.em_observcosteprod <> '" + obsMargenProd + "'))";					
					}

					//COSTES	
					if((costeProd != "NULL" && costeActual != costeProd) || eliminarCostes) {	
						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste,em_origenmargen,em_margenprod, em_fechamargenprod,em_horamargenprod,em_idusuariomargenprod,em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod,em_costeprod, em_idusuariocosteprod,em_observcosteprod,em_tipocoste,em_tipomargen) SELECT 'articulos', '" + hoy + "', '" + hora + "', '" + idUsuario + "', ori.origencoste, CASE articulos.em_tipomargen WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origenmargen END, articulos.em_margenprod, articulos.em_fechamargenprod, articulos.em_horamargenprod, articulos.em_idusuariomargenprod, articulos.em_observmargenprod, articulos.referencia, '" + hoy + "', '" + hora + "', " + costeProd + ", '" + idUsuario + "','" + obsCosteProd + "',articulos.em_tipocoste, articulos.em_tipomargen FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia  WHERE " + where + " AND  " + whereCostes)) {
							return false;

						}


						if(eliminarCostes) {
							if(!AQUtil.execSql("UPDATE articulos SET em_origencoste = ori.origencoste, em_costeprod = NULL, em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "', em_observcosteprod = '" + obsCosteProd + "' FROM  v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereCostes)) {						
								return false;
							}	
						} else {
							//tipocoste heredado
							if(!AQUtil.execSql("UPDATE articulos SET em_origencoste = ori.origencoste, em_costeprod = " + costeProd + ", em_fechacosteprod = '" + hoy + "', em_horacosteprod = '" + hora + "', em_idusuariocosteprod = '" + idUsuario + "', em_observcosteprod = '" + obsCosteProd + "' FROM  v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereCostes)) {					
								return false;
							}	
						}
					}

					//MARGENES
					if((margenProd != "NULL" && margenActual !=  margenProd) || eliminarMargenes) {
						if (!AQUtil.execSql("INSERT INTO em_logcostesmargenes (gridasociado,fechahis,horahis,usuariohis,em_origencoste,em_origenmargen,em_margenprod, em_fechamargenprod,em_horamargenprod,em_idusuariomargenprod,em_observmargenprod,referencia,em_fechacosteprod,em_horacosteprod,em_costeprod, em_idusuariocosteprod,em_observcosteprod,em_tipocoste,em_tipomargen) SELECT 'articulos','" + hoy + "','" + hora + "','" + idUsuario + "',CASE articulos.em_tipocoste WHEN 'Manual' THEN 'articulo' ELSE articulos.em_origencoste END, ori.origenmargen," + margenProd + ",'" + hoy + "','" + hora + "','" + idUsuario + "','" + obsMargenProd + "',articulos.referencia,articulos.em_fechacosteprod, articulos.em_horacosteprod, articulos.em_costeprod, articulos.em_idusuariocosteprod,articulos.em_observcosteprod,articulos.em_tipocoste,articulos.em_tipomargen FROM articulos INNER JOIN v_origencostemargen ori ON articulos.referencia = ori.referencia WHERE " + where + " AND " + whereMargen)) {
							return false;

						}					
						if(eliminarMargenes) {
							//tipomargen heredado
							if(!AQUtil.execSql("UPDATE articulos SET em_origenmargen = ori.origenmargen, em_margenprod = NULL, em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "', em_observmargenprod = '" + obsMargenProd + "' FROM  v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereMargen)) {	
								return false;						
							}

						} else {
							//tipomargen heredado
							if(!AQUtil.execSql("UPDATE articulos SET em_origenmargen = ori.origenmargen, em_margenprod = " + margenProd + ", em_fechamargenprod = '" + hoy + "', em_horamargenprod = '" + hora + "', em_idusuariomargenprod = '" + idUsuario + "', em_observmargenprod = '" + obsMargenProd + "' FROM  v_origencostemargen ori WHERE articulos.referencia = ori.referencia AND " + where + " AND  " + whereMargen)) {						
								return false;						
							}
						}
					}
				}
			}
		}
		cursor.setValueBuffer("tamasactualizados",numReg);
		cursor.setValueBuffer("plantactualizados",0);
	}
	AQUtil.destroyProgressDialog();
	return true;

}

function oficial_guardaLineas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codCambio = cursor.valueBuffer("codcambio");
	var nF = _i.t_.numRows();
	if(!AQUtil.execSql("DELETE FROM em_lineascambmascostes WHERE codcambio = '" + codCambio + "'")) {
		return false;
	}
	var costeActual,costeNuevo, margenActual, margenNuevo, existencias,pterecibir,afaltas, numRef, idPlantilla;	
	var numRefHerC,numRefManC,numRefHerM,numRefManM;
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Guardando lineas"), nF);
	var p = 0;
	for (var f = 0; f < nF; f++) {
		AQUtil.setProgress(p++);
		//debug("fila: "+f);
		//codcambio,sel,codcoleccionem,desccoleccion,codfamilia,descfamilia,codsubfamilia,descsubfamilia,orden,codtamanoem,codcolorem,em_costeactual,em_costenuevo,em_costeart,em_margenactual,em_margennuevo,em_margenart,existencias,pterecibir,afaltas,revisar,numref,idplantilla
		sel = _i.t_.text(f, _i.cSEL_);
		if(sel == "X") {
			sel = true;
		} else {
			sel =false;
		}

		costeActual = _i.t_.text(f, _i.cCOSTEACT_);
		if(!costeActual || costeActual == "") {
			costeActual = "NULL";
		}
		costeNuevo = _i.t_.text(f, _i.cCOSTENUEVO_);
		if(!costeNuevo || costeNuevo == "") {
			costeNuevo = "NULL";
		}
		margenActual = _i.t_.text(f, _i.cMARGENACT_);
		if(!margenActual || margenActual == "") {
			margenActual = "NULL";
		}
		margenNuevo = _i.t_.text(f, _i.cMARGENNUEVO_);
		if(!margenNuevo || margenNuevo == "") {
			margenNuevo = "NULL";
		}
		existencias = _i.t_.text(f, _i.cEXIS_);
		if(!existencias || existencias == "") {
			existencias = "NULL";
		}
		pterecibir = _i.t_.text(f, _i.cPTEREC_);
		if(!pterecibir || pterecibir == "") {
			pterecibir = "NULL";
		}
		afaltas = _i.t_.text(f, _i.cAFALTA_);
		if(!afaltas || afaltas == "") {
			afaltas = "NULL";
		}
		numRef = _i.t_.text(f, _i.cNUMREF_);
		if(!numRef || numRef == "") {
			numRef = "NULL";
		}
		idPlantilla = _i.t_.text(f, _i.cIDPLANTILLA_);
		if(!idPlantilla || idPlantilla == "") {
			idPlantilla = "NULL";
		}
		
		numRefHerC = _i.t_.text(f, _i.cNUMREF_);
		if(!numRefHerC || numRefHerC == "") {
			numRefHerC = "NULL";
		}
		numRefManC = _i.t_.text(f, _i.cNUMREF_);
		if(!numRefManC || numRefManC == "") {
			numRefManC = "NULL";
		}
		numRefHerM = _i.t_.text(f, _i.cNUMREF_);
		if(!numRefHerM || numRefHerM == "") {
			numRefHerM = "NULL";
		}
		numRefManM = _i.t_.text(f, _i.cNUMREF_);
		if(!numRefManM || numRefManM == "") {
			numRefManM = "NULL";
		}

		

		if(!AQUtil.execSql("INSERT INTO em_lineascambmascostes (codcambio,sel,codcoleccionem,desccoleccion,codfamilia,descfamilia,codsubfamilia,descsubfamilia,orden,codtamanoem,codcolorem,em_costeactual,em_costenuevo,em_costeart,em_margenactual,em_margennuevo,em_margenart,existencias,pterecibir,afaltas,revisar,numref,idplantilla, numrefherc, numrefmanc, numrefherm, numrefmanm) VALUES('" + codCambio + "'," + sel + ",'" + _i.t_.text(f, _i.cCODCOLEC_) + "','" + _i.t_.text(f, _i.cDESCOLEC_)+ "','" + _i.t_.text(f, _i.cCODFAM_)+ "','" + _i.t_.text(f, _i.cDESFAM_)+ "','" + _i.t_.text(f, _i.cCODSUBFAM_)+ "','" + _i.t_.text(f, _i.cDESSUBFAM_)+ "'," + _i.t_.text(f, _i.cORDEN_)+ ",'" + _i.t_.text(f, _i.cCODTAMA_)+ "','" + _i.t_.text(f, _i.cCODCOLOR_)+ "'," + costeActual + "," + costeNuevo + ",'" + _i.t_.text(f, _i.cCOSTEART_)+ "'," + margenActual + "," + margenNuevo + ",'" + _i.t_.text(f, _i.cMARGENART_)+ "'," + existencias + "," + pterecibir + "," + afaltas + ",'" + _i.t_.text(f, _i.cREVISAR_)+ "'," + numRef + "," + idPlantilla + "," + numRefHerC + "," + numRefManC + "," + numRefHerM + "," + numRefManM + ")")) {
			return false;
		}
	}
	AQUtil.destroyProgressDialog();
	return true;
}

function oficial_cargaLineas()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codCambio = cursor.valueBuffer("codcambio");
	var where = "codcambio = '" + codCambio + "'"; 
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	if(apPlantillas) {
		where += " ORDER BY codcoleccionem, codfamilia,codsubfamilia,orden";
	} else if(apTamanoSubFam) {
		where += " ORDER BY codfamilia, codsubfamilia,orden";
	}	

	var p = 0;
	var f = 0;
	var sel;
	var q = new AQSqlQuery;	
	q.setSelect("sel,codcoleccionem,desccoleccion,codfamilia,descfamilia,codsubfamilia,descsubfamilia,orden,codtamanoem,codcolorem,em_costeactual,em_costenuevo,em_costeart,em_margenactual,em_margennuevo,em_margenart,existencias,pterecibir,afaltas,revisar,numref,numrefherc,numrefherm,numrefmanc,numrefmanm,idplantilla");
	q.setFrom("em_lineascambmascostes");
	q.setWhere(where);	
	if (!q.exec()){
		return;
	}  
	flfactppal.iface.pub_creaDialogoProgreso(sys.translate("Cargando datos"), q.size());
	//debug("sql: "+q.sql());
	while(q.next())
	{
		AQUtil.setProgress(p++);
		_i.t_.insertRows(f);  
		if(q.value("sel")) {
			_i.t_.setText(f, _i.cSEL_,"X");   
			_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorSel_);
		} else{
			_i.t_.setText(f, _i.cSEL_,"");   
			_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorNoSel_);
		}		 		
      	
      	_i.t_.setText(f, _i.cIDPLANTILLA_, q.value("idplantilla"));
      	_i.t_.setText(f, _i.cCODCOLEC_, q.value("codcoleccionem"));
      	_i.t_.setText(f, _i.cDESCOLEC_, q.value("descripcion"));
  		_i.t_.setText(f, _i.cCODFAM_, q.value("codfamilia"));
  		_i.t_.setText(f, _i.cDESFAM_, q.value("descfamilia"));
  		_i.t_.setText(f, _i.cCODSUBFAM_, q.value("codsubfamilia"));
  		_i.t_.setText(f, _i.cDESSUBFAM_, q.value("descsubfamilia"));
  		_i.t_.setText(f, _i.cORDEN_, q.value("orden"));       
  		_i.t_.setText(f, _i.cCODTAMA_, q.value("codtamanoem"));     
  		_i.t_.setText(f, _i.cCODCOLOR_, q.value("codcolorem"));    

  		if(!q.isNull(10)) {
  			_i.t_.setText(f, _i.cCOSTEACT_, q.value("em_costeactual"));
  		} else {
  			_i.t_.setText(f, _i.cCOSTEACT_, "");
  		}
  		if(!q.isNull(11)) {
  			_i.t_.setText(f, _i.cCOSTENUEVO_, q.value("em_costenuevo"));
  		} else {
  			_i.t_.setText(f, _i.cCOSTENUEVO_, "");	
  		} 
  		if(!q.isNull(12)) {	  		
  			_i.t_.setText(f, _i.cCOSTEART_, q.value("em_costeart"));
  		} else {
  			_i.t_.setText(f, _i.cCOSTEART_, "");
  		}
  		if(!q.isNull(13)) {
  			_i.t_.setText(f, _i.cMARGENACT_, q.value("em_margenactual"));
  		} else {
  			_i.t_.setText(f, _i.cMARGENACT_, "");
  		}
  		if(!q.isNull(14)) {
			_i.t_.setText(f, _i.cMARGENNUEVO_, q.value("em_margennuevo"));
		} else {
			_i.t_.setText(f, _i.cMARGENNUEVO_, "");
		}
		if(!q.isNull(15)) {
			_i.t_.setText(f, _i.cMARGENART_, q.value("em_margenart"));
		} else {
			_i.t_.setText(f, _i.cMARGENART_, "");
		}


		_i.t_.setText(f, _i.cEXIS_, q.value("existencias"));
		_i.t_.setText(f, _i.cPTEREC_, q.value("pterecibir"));
		_i.t_.setText(f, _i.cAFALTA_, q.value("afaltas"));
		_i.t_.setText(f, _i.cREVISAR_, q.value("revisar"));		
		_i.t_.setText(f, _i.cNUMREF_,q.value("numref"));
		_i.t_.setText(f, _i.cNUMREFHERC_,q.value("numrefherc"));
		_i.t_.setText(f, _i.cNUMREFHERM_,q.value("numrefherm"));
		_i.t_.setText(f, _i.cNUMREFMANC_,q.value("numrefmanc"));
		_i.t_.setText(f, _i.cNUMREFMANM_,q.value("numrefmanm"));
				
		f++;
	}
	AQUtil.destroyProgressDialog();
}

function oficial_habilitaAplicaPlan()
{
	var cursor = this.cursor();
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	if(apPlantillas) {
		if(apTamanoSubFam) {
			this.child("fdbApTamanoSubfam").setValue(false);		
		}
		this.child("fdbApPlantillas").setDisabled(true);
		this.child("fdbApTamanoSubfam").setDisabled(false);
	}


}

function oficial_habilitaAplicaTama()
{
	var cursor = this.cursor();
	var apPlantillas = cursor.valueBuffer("applantillas");
	var apTamanoSubFam = cursor.valueBuffer("aptamanosubfam");
	if(apTamanoSubFam) {
		if(apPlantillas) {
			this.child("fdbApPlantillas").setValue(false);				
		}
		this.child("fdbApTamanoSubfam").setDisabled(true);
		this.child("fdbApPlantillas").setDisabled(false);
	} 		
}

function oficial_marcaComoAplicado()
{
	var _i = this.iface;
	var cursor = this.cursor();
	cursor.setValueBuffer("aplicado",true);
	return true;
}

function oficial_informaEtiquetas()
{
	var cursor = this.cursor();

	this.child("txtVTamaActualizables").text = cursor.valueBuffer("tamasactualizables");
	this.child("txtVPlanActualizables").text = cursor.valueBuffer("plantactualizables");				
	this.child("txtVArtActualizables").text = cursor.valueBuffer("artactualizables");
	this.child("txtVArtActualizablesMargen").text = cursor.valueBuffer("artactualizablesmargen");
	this.child("txtVTamaActualizados").text = cursor.valueBuffer("tamasactualizados");		
	this.child("txtVPlanActualizados").text = cursor.valueBuffer("plantactualizados");		
	this.child("txtVArtActualizados").text = cursor.valueBuffer("artactualizados");	
	this.child("txtVArtActualizadosMargen").text = cursor.valueBuffer("artactualizadosmargen");	
}

function oficial_pushButtonAccept_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	if(!_i.guardaLineas()) {
		return true;
	}

	this.accept();
}

function oficial_initEventFilter()
{
  var _i = this.iface;

  _i.eventWatcher_ = new QObject;
  _i.eventWatcher_.eventFilterFunction = this.name + ".iface.pub_eventFilter";
  _i.eventWatcher_.allowedEvents = [AQS.KeyPress]; 

}

function oficial_eventFilter(o, e)
{
	var _i = this.iface;
	var cursor = this.cursor();
	if(e.type == AQS.KeyPress) {
		if(e.eventData["key"] == 4103 || e.eventData["key"] == 4099) {
			var fila = this.child("tblLineas").currentRow();
			var columna = this.child("tblLineas").currentColumn();
			if(columna-1 == _i.cCOSTEACT_ || columna-1 == _i.cMARGENACT_) {
				_i.t_.setText(fila, columna,""); 
				_i.tblLineas_valueChanged(fila, columna);

			}  
		} 
		return true;
	}
	return false;
}

function oficial_initWatch(obj)
{
	if (obj == undefined){
		return;
	}
	var _i = this.iface;
	obj.installEventFilter(_i.eventWatcher_);
}

function oficial_finishWatch(obj)
{
	if (obj == undefined) {
		return;
	}
	var _i = this.iface;
	obj.removeEventFilter(_i.eventWatcher_);
}

function oficial_tblLineas_valueChanged(f, c)
{
	var _i = this.iface;	
	var t = _i.t_;
	var cursor = this.cursor();
	if(c == _i.cCOSTENUEVO_ || c == _i.cMARGENNUEVO_) {
		var costeN = _i.t_.text(f, _i.cCOSTENUEVO_);
		var margenN = _i.t_.text(f, _i.cMARGENNUEVO_);


		if((!costeN || costeN == "") && (!margenN || margenN == "")) {
			_i.t_.setText(f, _i.cSEL_,"");  
			_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorNoSel_);
		} else {
			_i.t_.setText(f, _i.cSEL_,"X");  
			_i.t_.setCellBackgroundColor(f, _i.cSEL_, _i.cColorSel_);
		}

	}
	return true;		
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////
