/***************************************************************************
                 em_masterpedestampacion.qs  -  description
                             -------------------
    begin                : jue jun 20 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); }
	function chkSoloPtes_clicked() {
		return this.ctx.oficial_chkSoloPtes_clicked();
	}
	function tbnEstampar_clicked() {
		return this.ctx.oficial_tbnEstampar_clicked();
	}
	function filtra() {
		return this.ctx.oficial_filtra();
	}
	function filtroPpal() {
		return this.ctx.oficial_filtroPpal();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	connect(this.child("tbnEstampar"), "clicked()", _i, "tbnEstampar_clicked");
// 	connect(this.child("tableDBRecords").cursor(), "recordChoosed()", _i, "tbnEstampar_clicked");
	connect(this.child("chkSoloPtes"), "clicked()", _i, "chkSoloPtes_clicked");
	
	_i.filtroPpal();
	_i.filtra();
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_filtroPpal()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var codProvEstampado = flfactppal.iface.pub_valorDefectoEmpresa("codprovinternoest");
	if (!codProvEstampado) {
		sys.warnMsgBox(sys.translate("No tiene definido el proveedor interno de estampado en el formulario de empresa"));
		return;
	}
	var f = "codproveedor = '" + codProvEstampado + "' AND servido IN ('No', 'Parcial')";
	cursor.setMainFilter(f);
}

function oficial_filtra()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var f = "1 = 1";
	if (this.child("chkSoloPtes").checked) {
		f = "em_estadoproceso IS NULL";
	}
	this.child("tableDBRecords").setFilter(f);
	this.child("tableDBRecords").refresh();
}

function oficial_tbnEstampar_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var idPedido = cursor.valueBuffer("idpedido");
	if (!idPedido) {
		return false;
	}
	
	var estado = cursor.valueBuffer("em_estadoproceso");
	cursor.setModeAccess(cursor.Edit);
	cursor.refreshBuffer();
	if (estado == "Estampado") {
		cursor.setNull("em_estadoproceso");
		cursor.setNull("emfechaproceso");
		cursor.setNull("emhoraproceso");
	} else {
		var ahora = new Date;
		cursor.setValueBuffer("em_estadoproceso", "Estampado");
		cursor.setValueBuffer("emfechaproceso", ahora.toString().left(10));
		cursor.setValueBuffer("emhoraproceso", ahora.toString().right(8));
	}
	if (!cursor.commitBuffer()) {
		return false;
	}
}

function oficial_chkSoloPtes_clicked()
{
	var _i = this.iface;
	_i.filtra();	
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////