var form = this;
/***************************************************************************
                 em_reservasop.qs  -  description
                             -------------------
    begin                : jue ene 04 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	var filtroPreload_;
	function interna( context ) { this.ctx = context; }
	function init() {
		return this.ctx.interna_init();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	var curStock_;	
	var curOP_;
	var tblReservas_;
	var tblStocks_;
	var codOrden_;
	var tej_;
	var tabla_;
	function oficial( context ) { interna( context ); } 

	function abrirStocks() {
		return this.ctx.oficial_abrirStocks();
	}
	function abrirOP() {
		return this.ctx.oficial_abrirOP();
	}
	function cargaDatosReservas() {
		return this.ctx.oficial_cargaDatosReservas();
	}
	function dameTablaReservas() {
		return this.ctx.oficial_dameTablaReservas();
	}
	function cargaDatosStocks() {
		return this.ctx.oficial_cargaDatosStocks();
	}
	function dameTablaStocks() {
		return this.ctx.oficial_dameTablaStocks();
	}
}

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
	var _i = this.iface;
	_i.tblReservas_ = undefined;
	_i.tblStocks_ = undefined;
	_i.cargaDatosReservas();
	_i.cargaDatosStocks();
	connect (this.child("mte_tblExt_Reservas"), "clicked(int, int)", _i, "cargaDatosStocks");
}


//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_cargaDatosReservas()
{
	var _i = this.iface;

	var obj = _i.dameTablaReservas();
	var vista = "";	
	var codOrden = _i.codOrden_;
	var miTabla = obj.miTabla;
	

	if(_i.tabla_ == "confirmada") {
		if(_i.tej_) {
			vista = "v_reservalotetejconf";
		} else {
			vista = "v_reservaloteallconf";
		}

	} else if(_i.tabla_ == "cola") {
		if(_i.tej_) {
			vista = "v_reservalotetejcola";
		} else {
			vista = "v_reservaloteallcola";
		}

	}else {
		if(_i.tej_) {
			vista = "v_reservalotetej";
		} else {
			vista = "v_reservaloteall";
		}
	}
	var q = new FLSqlQuery;
	q.setSelect(vista +".codorden,"+vista+".codlote,"+vista+".referencia, "+vista+".cantidad,"+vista+".descripcion,"+vista+".tipotejido,"+vista+".reftejido, "+vista+".descripciontejido, "+vista+".cantidadtejido,"+vista+".reservaex,"+vista+".reservapr, "+vista+".reservaaf, "+vista+".idmovimiento, "+vista+".idstocktej");
	q.setFrom(vista);
	q.setWhere(vista+".codorden = '" + codOrden + "'");
	q.setOrderBy(vista+".codorden,"+vista+".codlote");	
	miTabla.setQuery(q);	


	miTabla.setColumnWidth(vista+".referencia", 80);
	miTabla.setColumnWidth(vista+".reftejido", 80);
	miTabla.setColumnWidth(vista+".tipotejido", 100);
	miTabla.setColumnWidth(vista+".descripcion", 350);
	miTabla.setColumnWidth(vista+".descripciontejido", 450);

	miTabla.setReadOnly(true);	
	miTabla.refresh();
	
	return true;	
}

function oficial_dameTablaReservas()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblReservas_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Reservas");
	obj.gb = this.child("mte_gbExt_Reservas");

	if (!obj.creado) {
		_i.tblReservas_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblReservas_.checkColumnEnabled(false);
		_i.tblReservas_.setAliasCheckColumn("Sel.");
		_i.tblReservas_.setSearchEnabled(true);
		_i.tblReservas_.setDoubleClickedFunction("formem_reservasop.iface.abrirOP");
	}
	
	obj.miTabla = _i.tblReservas_;

	return obj;
}

function oficial_cargaDatosStocks()
{
	var _i = this.iface;

	var obj = _i.dameTablaStocks();
	var codOrden = _i.codOrden_;

	var idStock = _i.tblReservas_.dameCursor().valueBuffer("idstocktej");

	if(!idStock || idStock == "") {
		return true;
	}

	var miTabla = obj.miTabla;

	var q = new FLSqlQuery;
	q.setSelect("v_stocksart.idstock, v_stocksart.codalmacen, v_stocksart.referencia, v_stocksart.descripciontejido, v_stocksart.cantidad, v_stocksart.reservada, v_stocksart.disponible, v_stocksart.pterecibir, v_stocksart.disponiblepterecibir, v_stocksart.afaltas");
	q.setFrom("v_stocksart");
	q.setWhere("v_stocksart.idstock = " + idStock);
	q.setOrderBy("v_stocksart.codalmacen, v_stocksart.referencia");
	miTabla.setQuery(q);

	miTabla.setColumnWidth("v_stocksart.referencia", 80);	
	miTabla.setColumnWidth("v_stocksart.descripciontejido", 450);
	
	miTabla.setReadOnly(true);
	miTabla.refresh();

	return true;	
}

function oficial_dameTablaStocks()
{
	var _i = this.iface;

	var obj = {};
	obj.creado = _i.tblStocks_ ? true : false;
	obj.tabla = this.child("mte_tblExt_Stocks");
	obj.gb = this.child("mte_gbExt_Stocks");

	if (!obj.creado) {
		_i.tblStocks_ = flfactppal.iface.pub_dameObjetoTabla(obj.tabla, obj.gb);

		_i.tblStocks_.checkColumnEnabled(false);
		_i.tblStocks_.setAliasCheckColumn("Sel.");
		_i.tblStocks_.setSearchEnabled(true);

		_i.tblStocks_.setDoubleClickedFunction("formem_reservasop.iface.abrirStocks");
	}
	
	obj.miTabla = _i.tblStocks_;

	return obj;
}

function oficial_abrirStocks()
{
	var _i = this.iface;
	if (!_i.curStock_) {
		_i.curStock_ = new FLSqlCursor("stocks");
	}	
	var idStock = _i.tblStocks_.dameCursor().valueBuffer("idstock");
	_i.curStock_.select("idstock = " + idStock);
	if (_i.curStock_.first()) {
		_i.curStock_.browseRecord();
	}
}

function oficial_abrirOP()
{
	var _i = this.iface;
	if (!_i.curOP_) {
		_i.curOP_ = new FLSqlCursor("pr_ordenesproduccion");
	}
	_i.curOP_.select("codorden = '" + _i.codOrden_ + "'");
	if (_i.curOP_.first()) {
		_i.curOP_.browseRecord();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////

