
/** @class_declaration euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial( context ); }
	function bufferChanged(fN:String) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
}
//// EUROMODA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA /////////////////////////////////////////////////
function euromoda_bufferChanged(fN:String)
{
	var _i = this.iface;
	var cursor = this.cursor();
	if (fN == "em_usucargapp") {
		if(!cursor.valueBuffer("em_usucargapp") || cursor.valueBuffer("em_usucargapp") == "") {
			cursor.setNull("em_fechainicargapp");
			cursor.setNull("em_horainicargapp");
		}		
		
	} else if (fN == "em_usucargaop") {
		if(!cursor.valueBuffer("em_usucargaop") || cursor.valueBuffer("em_usucargaop") == "") {
			cursor.setNull("em_fechainicargaop");
			cursor.setNull("em_horainicargaop");
		}
	} else {
		_i.__bufferChanged(fN);
	}
}
//// EUROMODA /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

