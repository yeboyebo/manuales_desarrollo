
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function init() {
		return this.ctx.euromoda_init();
	}
	function obtenerParamInformeCli() {
		return this.ctx.euromoda_obtenerParamInformeCli();
	}
	function tbnPrintCliente_clicked() {
		return this.ctx.euromoda_tbnPrintCliente_clicked();
	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	var _i = this.iface;
	_i.__init();
	
	if (this.child("tbnPrintCliente")) {
		connect(this.child("tbnPrintCliente"), "clicked()", _i, "tbnPrintCliente_clicked");
	}
}

function euromoda_tbnPrintCliente_clicked()
{
	var cursor = this.cursor();
	var pI = this.iface.obtenerParamInformeCli();
	if (!pI) {
		return;
	}

	flfactinfo.iface.pub_lanzarInforme(cursor, pI.nombreInforme, pI.orderBy, "", false, false, pI.whereFijo);
}

function euromoda_obtenerParamInformeCli()
{
	var paramInforme:Array = [];
	paramInforme["nombreInforme"] = false;
	paramInforme["orderBy"] = false;
	paramInforme["groupBy"] = false;
	paramInforme["etiquetas"] = false;
	paramInforme["impDirecta"] = false;
	paramInforme["whereFijo"] = false;
	paramInforme["nombreReport"] = false;
	paramInforme["numCopias"] = false;

	var cursor:FLSqlCursor = this.cursor();
	var seleccion:String = cursor.valueBuffer("id");
	if (!seleccion) {
		return false;
	}
	paramInforme.nombreInforme = "i_resreciboscli_cli";
	paramInforme.orderBy = "";
	var o:String = "";
	for (var i:Number = 1; i < 3; i++) {
		o = this.iface.obtenerOrden(i, cursor);
		if (o) {
			if (paramInforme.orderBy == "")
				paramInforme.orderBy = o;
			else
				paramInforme.orderBy += ", " + o;
		}
	}
	
	var intervalo:Array = [];
	if (cursor.valueBuffer("codintervalo")){
		intervalo = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalo"));
		cursor.setValueBuffer("d_reciboscli_fecha",intervalo.desde);
		cursor.setValueBuffer("h_reciboscli_fecha",intervalo.hasta);
	}
	var intervalov:Array = [];
	if (cursor.valueBuffer("codintervalov")){
		intervalov = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalov"));
		cursor.setValueBuffer("d_reciboscli_fechav",intervalov.desde);
		cursor.setValueBuffer("h_reciboscli_fechav",intervalov.hasta);
	}
	
	var idRemesa:String = cursor.valueBuffer("idremesa");
	var masWhere:String;
	if (idRemesa && idRemesa != "") {
		masWhere += "idrecibo IN (SELECT idrecibo FROM pagosdevolcli WHERE idremesa = " + idRemesa + ")";
		paramInforme.whereFijo = masWhere;
	}
	
	return paramInforme;
}

//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
