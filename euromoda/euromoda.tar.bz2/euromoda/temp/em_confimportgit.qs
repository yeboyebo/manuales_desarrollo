/***************************************************************************
                             em_confimportgit.qs
                             -------------------
    begin                : vie jun 15 2012
    copyright            : (C) 2003-2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx;

  function interna(context)
  {
    this.ctx = context;
  }
  function main()
  {
    this.ctx.interna_main();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  var cur_;
  var pbSrc_;
  var pbDst_;
  var pbRun_;
  var tedLog_;

  function oficial(context)
  {
    interna(context);
  }
  function init()
  {
    this.ctx.oficial_init();
  }
  function setCsvSrc(csvsrc)
  {
    this.ctx.oficial_setCsvSrc(csvsrc);
  }
  function setCsvDst(csvdst)
  {
    this.ctx.oficial_setCsvDst(csvdst);
  }
  function runProc()
  {
    this.ctx.oficial_runProc();
  }
  function runImportGit(cur)
  {
    return this.ctx.oficial_runImportGit(cur);
  }
  function VBACsvToAbanqCsv(cur)
  {
    return this.ctx.oficial_VBACsvToAbanqCsv(cur);
  }
  function runLote(cur)
  {
    return this.ctx.oficial_runLote(cur);
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx*/
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
  function pub_runImportGit(cur)
  {
    return this.runImportGit(cur);
  }
  function pub_VBACsvToAbanqCsv(cur)
  {
    return this.VBACsvToAbanqCsv(cur);
  }
  function pub_runLote(cur)
  {
    return this.runLote(cur);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_main()
{
  var f = new AQFormSearchDB("em_confimportgit");
  var cursor = f.cursor();

  cursor.select("");
  if (!cursor.first())
    cursor.setModeAccess(AQSql.Insert);
  else
    cursor.setModeAccess(AQSql.Edit);

  f.setMainWidget();
  cursor.refreshBuffer();
  cursor.transaction(false);

  var commitOk = false;
  while (!commitOk) {
    f.exec();
    if (!f.accepted()) {
      if (cursor.rollback())
        commitOk = true;
    } else {
      if (cursor.commitBuffer()) {
        cursor.commit();
        commitOk = true;
      }
    }
  }
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_init()
{
  var _i = this.iface;

  _i.cur_ = this.cursor();
  _i.pbSrc_ = sys.testObj(this, "pbCsvSrc");
  _i.pbDst_ = sys.testObj(this, "pbCsvDst");
  _i.pbRun_ = sys.testObj(this, "pbRun");
  _i.tedLog_ = sys.testObj(this, "tedLog");

  connect(_i.pbSrc_, "clicked()", _i, "setCsvSrc()");
  connect(_i.pbDst_, "clicked()", _i, "setCsvDst()");
  connect(_i.pbRun_, "clicked()", _i, "runProc()");
}

function oficial_setCsvSrc(csvsrc)
{
  var _i = this.iface;

  if (csvsrc == undefined) {
    var dir = FileDialog.getExistingDirectory(false, sys.translate("Directorio Origen"));
    if (!dir)
      return;
    dir = Dir.cleanDirPath(dir);
    dir = Dir.convertSeparators(dir);
    Dir.current = dir;
    csvsrc = dir;
  }
  _i.cur_.setValueBuffer("csvsrc", csvsrc);
}

function oficial_setCsvDst(csvdst)
{
  var _i = this.iface;

  if (csvdst == undefined) {
    var dir = FileDialog.getExistingDirectory(false, sys.translate("Directorio Destino"));
    if (!dir)
      return;
    dir = Dir.cleanDirPath(dir);
    dir = Dir.convertSeparators(dir);
    Dir.current = dir;
    csvdst = dir;
  }
  _i.cur_.setValueBuffer("csvdst", csvdst);
}

function oficial_runProc()
{
  var _i = this.iface;

  if (!_i.cur_.commitBuffer())
    return;

  _i.cur_.commit();
  _i.cur_.transaction(false);
  _i.runImportGit(_i.cur_);

  var now = new Date;
  try {
    var logTxt = _i.tedLog_.text;
    if (logTxt.isEmpty())
      logTxt = "NULL";
    AQSql.insert("dat_logs",
                 ["descripcion", "contenido"],
                 [now.toString(), logTxt]);
  } catch (e) {
    sys.errorMsgBox("Error SQL: " + e);
    debug("Error SQL: " + e);
  }
}

function oficial_runImportGit(cur)
{
  var _i = this.iface;

  if (cur == undefined)
    cur = _i.cur_;

  var ok = _i.VBACsvToAbanqCsv(cur);
  if (ok)
    ok = _i.runLote(cur);
  return ok;
}

function oficial_VBACsvToAbanqCsv(cur)
{
  var _i = this.iface;

  if (cur == undefined)
    cur = _i.cur_;

  var dirSrc = cur.valueBuffer("csvsrc");
  if (!dirSrc) {
    debug("VBACsvToAbanqCsv: !dirSrc");
    return false;
  }
  var dirDst = cur.valueBuffer("csvdst");
  if (!dirDst) {
    debug("VBACsvToAbanqCsv: !dirDst");
    return false;
  }

  var ok = true;
  var listFiles = AQUtil.findFiles([dirSrc], "*.csv", false);
  for (var i = 0; i < listFiles.length; ++i) {
    var f = new File(listFiles[i]);
    ok = fldatosppal.iface.pub_fileVBAToAbanqCsv(listFiles[i],
                                                 dirDst + "/" + f.name, _i.tedLog_ != undefined);
    if (!ok)
      break;
  }
  return ok;
}

function oficial_runLote(cur)
{
  var _i = this.iface;

  if (cur == undefined)
    cur = _i.cur_;

  var dirDst = cur.valueBuffer("csvdst");
  if (!dirDst) {
    debug("runLote: !dirDst");
    return false;
  }
  dirDst += "/";

  var codLote = cur.valueBuffer("codlote");

  var oldRutaDatos = AQUtil.sqlSelect("dat_opciones", "rutadatos", "1=1");
  if (oldRutaDatos == false)
    oldRutaDatos = dirDst;

  try {
    AQSql.update("dat_opciones", ["rutadatos"], [dirDst]);
  } catch (e) {
    if (_i.tedLog_ != undefined)
      sys.errorMsgBox("Error SQL: " + e);
    debug("Error SQL: " + e);
    return false;
  }

  formRecorddat_procesos_lotes.iface.pub_setTedLog(_i.tedLog_);
  formRecorddat_procesos_lotes.iface.pub_cmdRunLote(codLote);

  try {
    AQSql.update("dat_opciones", ["rutadatos"], [oldRutaDatos]);
  } catch (e) {
    if (_i.tedLog_ != undefined)
      sys.errorMsgBox("Error SQL: " + e);
    debug("Error SQL: " + e);
    return false;
  }
  return true;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
