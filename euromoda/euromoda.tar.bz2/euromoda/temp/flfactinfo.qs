
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends liqAgentes {
	var datosEmpresa_;
	var totalesInv_;
	var membrete_;
	var nP_, netoComision_;
	var totalNecesario_;
  var totalNetoComision_, totalComision_;
	function euromoda( context ) { liqAgentes ( context ); }
	function porComisionFactura(nodo, campo) {
		return this.ctx.euromoda_porComisionFactura(nodo, campo);
	}
	function netoComisionFactura(nodo, campo) {
		return this.ctx.euromoda_netoComisionFactura(nodo, campo);
	}
  function iniciarValoresLiq(nodo, campo) {
    return this.ctx.euromoda_iniciarValoresLiq(nodo, campo);
  }
	function totalComisionFactura(nodo, campo) {
		return this.ctx.euromoda_totalComisionFactura(nodo, campo);
	}
  function dameTotalLiquidacion(nodo, campo) {
    return this.ctx.euromoda_dameTotalLiquidacion(nodo, campo);
  }
	function reembolsoEtiAlbaran(nodo, campo) {
		return this.ctx.euromoda_reembolsoEtiAlbaran(nodo, campo);
	}
	function pedidoEtiAlbaran(nodo, campo) {
		return this.ctx.euromoda_pedidoEtiAlbaran(nodo, campo);
	}
	function refORefCliente(nodo, campo) {
		return this.ctx.euromoda_refORefCliente(nodo, campo);
	}
	function soloRefCliente(nodo, campo) {
		return this.ctx.euromoda_soloRefCliente(nodo, campo);
	}
	function labelDtoEsp(nodo, campo) {
		return this.ctx.euromoda_labelDtoEsp(nodo, campo);
	}
  function labelDtoEspInt(nodo, campo) {
    return this.ctx.euromoda_labelDtoEspInt(nodo, campo);
  }
  function datoLineaCliente(nodo, campo) {
    return this.ctx.euromoda_datoLineaCliente(nodo, campo);
  }
  function concatenaTamanoColor(descripcion, tamano, color) {
    return this.ctx.euromoda_concatenaTamanoColor(descripcion, tamano, color);
  }
  function datoLineaProv(nodo, campo) {
    return this.ctx.euromoda_datoLineaProv(nodo, campo);
  }
  function direccionEmpresa(nodo, campo) {
    return this.ctx.euromoda_direccionEmpresa(nodo, campo);
  }
  function traduceArticulo(codPais, referencia) {
    return this.ctx.euromoda_traduceArticulo(codPais, referencia);
  }
  function direccionProvPedProv(nodo, campo) {
    return this.ctx.euromoda_direccionProvPedProv(nodo, campo);
  }
  function ampliarWhere(nombreConsulta) {
    return this.ctx.euromoda_ampliarWhere(nombreConsulta);
  }
  function desPartidaPedProv(nodo, campo) {
    return this.ctx.euromoda_desPartidaPedProv(nodo, campo);
  }
  function acabadosPedProv(nodo, campo) {
    return this.ctx.euromoda_acabadosPedProv(nodo, campo);
  }
  function porIVA(nodo, campo) {
    return this.ctx.euromoda_porIVA(nodo, campo);
  }
  function numPagina(nodo, campo) {
    return this.ctx.euromoda_numPagina(nodo, campo);
  }
  function vencimiento(nodo, campo) {
    return this.ctx.euromoda_vencimiento(nodo, campo);
  }
  function cuentaFacturaCli(nodo, campo) {
    return this.ctx.euromoda_cuentaFacturaCli(nodo, campo);
  }
  function codProforma(nodo, campo) {
    return this.ctx.euromoda_codProforma(nodo, campo);
  }
  function necesarioInv(nodo, campo) {
    return this.ctx.euromoda_necesarioInv(nodo, campo);
  }
  function logoMembrete(nodo, campo) {
    return this.ctx.euromoda_logoMembrete(nodo, campo);
  }
  function ponerMembrete(opcion) {
    return this.ctx.euromoda_ponerMembrete(opcion);
  }
  function dameMembrete() {
    return this.ctx.euromoda_dameMembrete();
  }
  function dameTelefonoProveedor(nodo, campo) {
    return this.ctx.euromoda_dameTelefonoProveedor(nodo, campo);
  }
  function pieLinea1(campo) {
    return this.ctx.euromoda_pieLinea1(campo);
  }
  function pieLinea2(campo) {
    return this.ctx.euromoda_pieLinea2(campo);
  }
  function pieLinea3(campo) {
    return this.ctx.euromoda_pieLinea3(campo);
  }
  function pieLinea4(campo) {
    return this.ctx.euromoda_pieLinea4(campo);
  }
  function datoEmpresa(campo) {
    return this.ctx.euromoda_datoEmpresa(campo);
  }
  function ordenProduccionPP(nodo, campo) {
    return this.ctx.euromoda_ordenProduccionPP(nodo, campo);
  }
  function construyeDir(nodo, campo) {
    return this.ctx.euromoda_construyeDir(nodo, campo);
	}
	function codPartidaTrans(nodo, campo) {
		return this.ctx.euromoda_codPartidaTrans(nodo, campo);
	}
	function inicializaTotalNecesario() {
		return this.ctx.euromoda_inicializaTotalNecesario();
	}
	function actualizaTotalNecesario(v) {
		return this.ctx.euromoda_actualizaTotalNecesario(v);
	}
	function dameTotalNecesario() {
		return this.ctx.euromoda_dameTotalNecesario();
	}
	function acabadosObservPedProv(nodo,campo) {
		return this.ctx.euromoda_acabadosObservPedProv(nodo,campo);
	}
	function preprocesaReportData(nombreReport, rptViewer) {
		return this.ctx.euromoda_preprocesaReportData(nombreReport, rptViewer);
	}
	function dameNombreAseguradora(nodo, campo) {
		return this.ctx.euromoda_dameNombreAseguradora(nodo, campo);
	}
	function dameNombreAseguradoraInt(nodo, campo) {
		return this.ctx.euromoda_dameNombreAseguradoraInt(nodo, campo);
	}
	function referenciaDescripcionTallaColor(nodo, campo) {
		return this.ctx.euromoda_referenciaDescripcionTallaColor(nodo, campo);
	}
	function referenciaDescripcionTallaColorCompra(nodo, campo) {
		return this.ctx.euromoda_referenciaDescripcionTallaColorCompra(nodo, campo);
	}
	function albaranProforma(campo) {
		return this.ctx.euromoda_albaranProforma(campo);
	}
	function descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo) {
		return this.ctx.euromoda_descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo);
	}
	function traduceArticuloCli(codPais, id) {
		return this.ctx.euromoda_traduceArticuloCli(codPais, id);
	}
	function tipoAlbaranDep(nodo, campo) {
		return this.ctx.euromoda_tipoAlbaranDep(nodo, campo);
	}
	function observacionesOrdenEst(nodo, tipo) {
		return this.ctx.euromoda_observacionesOrdenEst(nodo, tipo);
	}
	function turnoUsuario(nodo, campo) {
	    return this.ctx.euromoda_turnoUsuario(nodo, campo);
	}
	function metrosVaporizado(nodo, campo) {
		return this.ctx.euromoda_metrosVaporizado(nodo, campo);
	}	
	function soporteEst(nodo, campo){
	    return this.ctx.euromoda_soporteEst(nodo, campo);
	}
	function incidenciasEst(nodo, campo) {
		return this.ctx.euromoda_incidenciasEst(nodo, campo);
	}
	function acabadosObservAlbProv(nodo,campo) {
		return this.ctx.euromoda_acabadosObservAlbProv(nodo,campo);
	}
	function totalPartida(nodo, campo) {
		return this.ctx.euromoda_totalPartida(nodo, campo);
	}
	function bobinaEstampacion(nodo, campo) {
		return this.ctx.euromoda_bobinaEstampacion(nodo, campo);
	}
	function metrosRolladoLin(nodo, campo) {
		return this.ctx.euromoda_metrosRolladoLin(nodo, campo);
	}
	function bobinaInforme(nodo, campo) {
		return this.ctx.euromoda_bobinaInforme(nodo, campo);
	}
	function totalEstampado(campo) {
		return this.ctx.euromoda_totalEstampado(campo);
	}
	function partidaRefPPE(nodo, campo) {
		return this.ctx.euromoda_partidaRefPPE(nodo, campo);
	}
	function dimePedidoProvAlb(nodo, campo) {
		return this.ctx.euromoda_dimePedidoProvAlb(nodo, campo);
	}
	function codPartidaTransAca(nodo, campo) {
		return this.ctx.euromoda_codPartidaTransAca(nodo, campo);
	}
	function em_dameBarcodeInterleaved(nodo, campo) {
		return this.ctx.euromoda_em_dameBarcodeInterleaved(nodo, campo);
	}
  	function impTelefonoAlbaranTrans(nodo,campo){
    	return this.ctx.euromoda_impTelefonoAlbaranTrans(nodo,campo);
  	}
  	function totalTrackingEnvios(nodo,campo){
  		return this.ctx.euromoda_totalTrackingEnvios(nodo,campo);
  	}
  	function descripcionLPP(nodo,campo) {
  		return this.ctx.euromoda_descripcionLPP(nodo,campo);
  	}
  	function dameNumEnvioDrop(nodo, campo) {
  		return this.ctx.euromoda_dameNumEnvioDrop(nodo, campo);
  	}
  	function etiquetaAcolchado(nodo, campo) {
  		return this.ctx.euromoda_etiquetaAcolchado(nodo, campo);
  	}
  	function lanzaInforme(cursor, oParams) {
  		return this.ctx.euromoda_lanzaInforme(cursor, oParams);
  	}
 	function datoPieProv(nodo, campo) {
    	return this.ctx.euromoda_datoPieProv(nodo, campo);
  	}
  	function dameLabelRectificativaAbono(nodo, campo) {
    	return this.ctx.euromoda_dameLabelRectificativaAbono(nodo, campo);
  	}
  	function facturaRectificada(nodo, campo) {
		return this.ctx.euromoda_facturaRectificada(nodo,campo);
	}
	function labelRectificaA(nodo, campo) {
		return this.ctx.euromoda_labelRectificaA(nodo, campo);
	}
	function preprocesaReportTemplate(cursor, oParams, rptViewer) {
		return this.ctx.euromoda_preprocesaReportTemplate(cursor, oParams, rptViewer);
	}
	function concatenaCodSerieDiseno(descripcion, codseriediseno) {
		return this.ctx.euromoda_concatenaCodSerieDiseno(descripcion, codseriediseno);
	}
	function datosInventario(nodo, campo) {
		return this.ctx.euromoda_datosInventario(nodo, campo);
	}
	function codPedidoCb(nodo, campo) {
		return this.ctx.euromoda_codPedidoCb(nodo, campo);
	}
	function precioLineaCompra(nodo, campo) {
		return this.ctx.euromoda_precioLineaCompra(nodo, campo);
	}
	function concatenaUbiAlterna(descripcion, referencia) {
		return this.ctx.euromoda_concatenaUbiAlterna(descripcion, referencia);
	}
	function labelDecripcion(nodo, campo) {
		return this.ctx.euromoda_labelDecripcion(nodo, campo);
	}
	function selloPyme(nodo, campo) {
    	return this.ctx.euromoda_selloPyme(nodo, campo);
  	}
	function selloPymeInt(nodo, campo) {
    	return this.ctx.euromoda_selloPymeInt(nodo, campo);
  	}

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA //////////////////////////////////////////////
class pubEuromoda extends pubarticuloscomp {
	function pubEuromoda( context ) { pubarticuloscomp ( context ); }
	function pub_ponerMembrete(opcion) {
		return this.ponerMembrete(opcion);
	}
	function pub_dameMembrete() {
		return this.dameMembrete();
	}
	function pub_logoMembrete(nodo, campo) {
		return this.logoMembrete(nodo, campo);
	}
	function pub_pieLinea1(campo) {
		return this.pieLinea1(campo);
	}
	function pub_pieLinea2(campo) {
		return this.pieLinea2(campo);
	}
	function pub_pieLinea3(campo) {
		return this.pieLinea3(campo);
	}
	function pub_pieLinea4(campo) {
		return this.pieLinea4(campo);
	}
}
//// EUROMODA //////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////

function euromoda_iniciarValoresLiq(nodo, campo)
{
  var _i = this.iface;
  _i.__iniciarValoresLiq(nodo, campo);
  _i.totalNetoComision_ = 0;
  _i.totalComision_ = 0;
}

function euromoda_netoComisionFactura(nodo, campo)
{
	var _i = this.iface;

	var idFactura = nodo.attributeValue("facturascli.idfactura");
	var valor = AQUtil.sqlSelect("facturascli f INNER JOIN lineasfacturascli lf ON f.idfactura = lf.idfactura INNER JOIN articulos a ON lf.referencia = a.referencia INNER JOIN em_gamas g ON a.em_codgama = g.em_codgama", "SUM(lf.pvptotal * (100 -  coalesce(f.pordtoesp,0)) / 100)", "f.idfactura = " + idFactura + " AND NOT g.sincomision", "facturascli");

	valor = isNaN(valor) ? 0 : valor;
	_i.netoComision_ = valor;

  _i.totalNetoComision_ = _i.totalNetoComision_ + parseFloat(_i.netoComision_);
  debug("_i.totalNetoComision_ = " + _i.totalNetoComision_ + ", _i.netoComision_ = " + _i.netoComision_);
	return _i.netoComision_;
}

function euromoda_totalComisionFactura(nodo, campo)
{
	var _i = this.iface;
	if (!_i.porComision) {
		return 0;
	}
	if (!_i.netoComision_) {
		return 0;
	}
	var res = _i.netoComision_ * this.iface.porComision / 100;
  _i.totalComision_ = _i.totalComision_ + parseFloat(res);
  debug("_i.totalComision_ = " + _i.totalComision_ + ", _i.totalComisionFactura_ = " + res);
	return res;
}

function euromoda_dameTotalLiquidacion(nodo, campo)
{
  var _i = this.iface;
  var res = 0;
  if (campo == "neto") {
    res = _i.totalNetoComision_;
  }
  else if (campo == "comision") {
    res = _i.totalComision_;
  }
  debug("campo = " + campo + ", valor = " + res);
  return res;
}

function euromoda_porComisionFactura(nodo, campo)
{
	var _i = this.iface;
	debug("liqAgentes_porComisionFactura");

	var comisiones = "";
	var res = parseFloat(nodo.attributeValue("facturascli.porcomision"));
	if(res && res != 0) {
		this.iface.porComision = res;
		return res;
	}

	var idFactura:String = nodo.attributeValue("facturascli.idfactura");
	var porComAnt = -1, porCom;
	var q = new FLSqlQuery;
	q.setSelect("lf.porcomision, SUM(lf.pvptotal)");
	q.setFrom("lineasfacturascli lf INNER JOIN articulos a ON lf.referencia = a.referencia INNER JOIN em_gamas g ON a.em_codgama = g.em_codgama");
	q.setWhere("idfactura = " + idFactura + " AND NOT g.sincomision GROUP BY lf.porcomision ORDER BY lf.porcomision");
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	var numLineas = q.size();
	if(!numLineas) {
		this.iface.porComision = 0;
		return 0;
	}

	var sumCom = 0;
	var total = 0, totalPor;
	while (q.next()) {
		totalPor = q.value("SUM(lf.pvptotal)");
		totalPor = isNaN(totalPor) ? 0 : totalPor;
		porCom = q.value("lf.porcomision");
		porCom = isNaN(porCom) ? 0 : porCom;
		if (porCom != porComAnt) {
			comisiones += (comisiones != "") ? ", " : "";
			comisiones += porCom;
			comisiones += "%";
			porComAnt = porCom;
		}
		sumCom += (porCom * totalPor);
		total += totalPor;
	}
	_i.porComision = sumCom / total;
	res = comisiones;
	return res;
}

function euromoda_reembolsoEtiAlbaran(nodo, campo)
{
	var codPago = nodo.attributeValue("albaranescli.em_codpago");
	if (codPago != "REEMBOLSO") {
		return "";
	}
	var importe = AQUtil.roundFieldValue(nodo.attributeValue("albaranescli.total"), "albaranescli", "total");
	var res = sys.translate("Pago contra reembolso de %1 %2").arg(importe).arg(nodo.attributeValue("albaranescli.coddivisa"));
	return res;
}

function euromoda_pedidoEtiAlbaran(nodo, campo)
{
	return nodo.attributeValue("albaranescli.docexterno");
}

function euromoda_refORefCliente(nodo, campo)
{

	var _i = this.iface;
	var ref = "";
	var campos = campo.split(".");
	var tam = campos[0].length;
	var nTabla = campos[0].right(tam-6);
	var codCliente = nodo.attributeValue(nTabla + ".codcliente");
	var referencia = nodo.attributeValue(campo);
	var codClienteFra = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente='" + codCliente + "'");	
	if (!codClienteFra || codClienteFra == "") {
		codClienteFra = codCliente; 
	}
	
	if(codClienteFra && codClienteFra != "") {
		ref = AQUtil.sqlSelect("em_articuloscli", "referenciacliente", "codcliente='" + codClienteFra + "' and referencia = '" + referencia + "'");	
		
		if (!ref || ref == "") {
			ref = nodo.attributeValue("articulos.aliasart");
			
			if (!ref || ref == "") {
				ref = nodo.attributeValue(campo);
				
			}
		}
	
	}else {
		ref = nodo.attributeValue("articulos.aliasart");
		
		if (!ref || ref == "") {
			ref = nodo.attributeValue(campo);
			debug("ref5: "+ref);
		}
	}
	
	return ref;	
}

function euromoda_soloRefCliente(nodo, campo)
{
	var _i = this.iface;
	
	var refCliente = _i.refORefCliente(nodo, campo);
	var ref = nodo.attributeValue(campo);
	if (refCliente == ref) {
		refCliente = "";
	}
	return refCliente;
}


function euromoda_labelDtoEsp(nodo, campo)
{
	var porDto = parseFloat(nodo.attributeValue(campo));
	if (!porDto) {
		porDto = "";
	}
	return sys.translate("%1% Dto. P.P.").arg(porDto);
}

function euromoda_labelDtoEspInt(nodo, campo)
{
	var porDto = parseFloat(nodo.attributeValue(campo));
	if (!porDto) {
		porDto = "";
	}
	return sys.translate("%1% Disc. P.P.").arg(porDto);
}

function euromoda_datoLineaCliente(nodo, campo)
{
//debug("euromoda_datoLineaCliente " + campo);
	var _i = this.iface;
	var tabla = campo.left(campo.find("."));
	var valor = "", codTamano, codColor;
	if (nodo.attributeValue(tabla + ".tipoconcepto") == "Texto") {
    	switch(campo) {
    		case "lineaspresupuestoscli.descripcion":
    		case "lineaspedidoscli.descripcion":
    		case "lineasalbaranescli.descripcion":
    		case "lineasfacturascli.descripcion": {
        		valor = nodo.attributeValue(tabla + ".texto");
        		break;
      		}
    		default: {
        		valor = "";
        		break;
      		}
    	}
  	} else {
    	valor = nodo.attributeValue(campo);
    	switch(campo) {
    		case "lineasalbaranescli.canfactura": {
    			valor = nodo.attributeValue(campo);
    			break;
    		}
    		case "lineaspresupuestoscli.descripcion":{
				valor = false;
				var paisEmpresa = nodo.attributeValue("empresa.codpais");
				var paisFactura = nodo.attributeValue("presupuestoscli.codpais");
				valor = _i.descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo);
				if (!valor ) {
					if (paisFactura && paisFactura != "" && paisFactura != paisEmpresa) {
						valor = _i.traduceArticulo(paisFactura, nodo.attributeValue("lineaspresupuestoscli.referencia"));
					}
					debug("valor " + valor);
					if (!valor) {
						debug("concatenando");
						valor = _i.concatenaTamanoColor(nodo.attributeValue(campo), nodo.attributeValue("lineaspresupuestoscli.codtamanoem"), nodo.attributeValue("lineaspresupuestoscli.codcolorem"));
						debug("valor con" + valor);
					}				
				}
				break;
			}
    		case "lineaspedidoscli.descripcion": {
				valor = false;
				var paisEmpresa = nodo.attributeValue("empresa.codpais");
				var paisFactura = nodo.attributeValue("pedidoscli.codpais");
				valor = _i.descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo);
				if (!valor ) {
					if (paisFactura && paisFactura != "" && paisFactura != paisEmpresa) {
						valor = _i.traduceArticulo(paisFactura, nodo.attributeValue("lineaspedidoscli.referencia"));
					}
					if (!valor) {
						valor = _i.concatenaTamanoColor(nodo.attributeValue(campo), nodo.attributeValue("lineaspedidoscli.codtamanoem"), nodo.attributeValue("lineaspedidoscli.codcolorem"));
					}
				}
				valor = _i.concatenaCodSerieDiseno(valor, nodo.attributeValue("em_disenos.codseriediseno"));
				break;
			}
			case "lineahojacarga.descripcion": {
				valor = false;
				var paisEmpresa = nodo.attributeValue("empresa.codpais");
				var paisFactura = nodo.attributeValue("pedidoscli.codpais");
				valor = _i.descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo);
				if (!valor ) {
					if (paisFactura && paisFactura != "" && paisFactura != paisEmpresa) {
						valor = _i.traduceArticulo(paisFactura, nodo.attributeValue("lineaspedidoscli.referencia"));
					}
					if (!valor) {
						valor = _i.concatenaTamanoColor(nodo.attributeValue("lineaspedidoscli.descripcion"), nodo.attributeValue("lineaspedidoscli.codtamanoem"), nodo.attributeValue("lineaspedidoscli.codcolorem"));
					}
				}
				valor = _i.concatenaCodSerieDiseno(valor, nodo.attributeValue("em_disenos.codseriediseno"));
				valor = _i.concatenaUbiAlterna(valor, nodo.attributeValue("lineaspedidoscli.referencia"));
				break;
			}
    		case "lineasalbaranescli.descripcion": {
				valor = false;
				var paisEmpresa = nodo.attributeValue("empresa.codpais");
				var paisFactura = nodo.attributeValue("albaranescli.codpais");
				valor = _i.descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo);
				if (!valor ) {
					if (paisFactura && paisFactura != "" && paisFactura != paisEmpresa){
						valor = _i.traduceArticulo(paisFactura, nodo.attributeValue("lineasalbaranescli.referencia"));
					}
					if (!valor) {
						valor = _i.concatenaTamanoColor(nodo.attributeValue(campo), nodo.attributeValue("lineasalbaranescli.codtamanoem"), nodo.attributeValue("lineasalbaranescli.codcolorem"));
					}
				}
				break;
			}
			case "lineasfacturascli.descripcion":{
				valor = false;
				var codCliente = nodo.attributeValue("facturascli.codcliente");
				var ean = "";
				if(AQUtil.sqlSelect("clientes","em_eanenfactura","codcliente = '" + codCliente +"'")) {
					ean = nodo.attributeValue("articulos.codbarras");
				}

	// 			var tamano = nodo.attributeValue("lineasfacturascli.");
				var paisEmpresa = nodo.attributeValue("empresa.codpais");
				var paisFactura = nodo.attributeValue("facturascli.codpais");
				valor = _i.descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo);
				if (!valor ) {
					if (paisFactura && paisFactura != "" && paisFactura != paisEmpresa) {
						valor = _i.traduceArticulo(paisFactura, nodo.attributeValue("lineasfacturascli.referencia"));
					}
					if (!valor) {
						valor = _i.concatenaTamanoColor(nodo.attributeValue(campo), nodo.attributeValue("lineasfacturascli.codtamanoem"), nodo.attributeValue("lineasfacturascli.codcolorem"));
					}
				}

				if(ean && ean != "") {
					valor = ean + " - " + valor;
				}
				break;
			}
			case "em_lineaspacking.descripcion":{
				valor = false;
				var paisEmpresa = nodo.attributeValue("empresa.codpais");
				var paisAlbaran = nodo.attributeValue("albaranescli.codpais");
				if (paisAlbaran && paisAlbaran != "" && paisAlbaran != paisEmpresa) {
					valor = _i.traduceArticulo(paisAlbaran, nodo.attributeValue("em_lineaspacking.referencia"));
				}
				if(!valor){
					valor = nodo.attributeValue(campo);
				}
				break;
			}
			case "lineasalbaranescli.dtopor": {
				if(!nodo.attributeValue("clientes.albaranvalorado")) {
					valor = "";
					break;
				}
			}
			case "lineaspresupuestoscli.dtopor":
			case "lineaspedidoscli.dtopor":
			case "lineasfacturascli.dtopor": {
				if (parseFloat(nodo.attributeValue(campo)) == 0) {
					valor = "";
				} else {
					valor = AQUtil.roundFieldValue(valor, "lineasfacturascli", "dtopor");
				valor = AQUtil.formatoMiles(valor);
				}
				break;
			}
			case "lineasfacturascli.pvpunitario": {
				valor = AQUtil.roundFieldValue(valor, "lineasfacturascli", "pvpunitario");
				valor = AQUtil.formatoMiles(valor);
				break;
			}
			case "lineasalbaranescli.pvpunitario": {
				if(nodo.attributeValue("clientes.albaranvalorado") != "true") {
					valor = "";
					break;
				}

				valor = AQUtil.roundFieldValue(valor, "lineasalbaranescli", "pvpunitario");
				valor = AQUtil.formatoMiles(valor);
				break;
			}
			case "inventario.articulo": {
				valor = nodo.attributeValue("articulos.descripcion");
				var t = nodo.attributeValue("articulos.codtamanoem");
				if (t && t != "") {
					valor += (" " + t);
				}
				var c = nodo.attributeValue("articulos.codcolorem");
				if (c && c != "") {
					valor += (" " + c);
				}
				var cGit = nodo.attributeValue("em_colores.codigogit");
				if (cGit && cGit != "") {
					valor += (" - " + cGit);
				}
				break;
			}
			case "lotesstock.codalmacen": {
			
				valor = nodo.attributeValue(campo);
				if(valor != 1) {
					valor = "*";
				} else {
					valor = "";
				}
				break;
			}
   			default: {
				if(tabla == "lineasalbaranescli") {
					if(nodo.attributeValue("clientes.albaranvalorado") != "true") {
						valor = "";
						break;
					}
				}
        		valor = AQUtil.roundFieldValue(valor, "facturascli", "total");
        		valor = AQUtil.formatoMiles(valor);
       			break;
      		}
    	}
  	}
  	return valor;
}

function euromoda_concatenaTamanoColor(descripcion, tamano, color)
{
	var d = descripcion;
	d += tamano != "" ? (" " + tamano) : "";
	d += color != "" ? (" " + color) : "";
	return d;
}

function euromoda_datoLineaProv(nodo, campo)
{
	debug("euromoda_datoLineaProv");
	var _i = this.iface;
	var tabla = campo.left(campo.find("."));
	var valor = "";
	if (nodo.attributeValue(tabla + ".tipoconcepto") == "Texto") {
		switch(campo) {
			case "lineaspedidosprov.descripcion":
			case "lineasalbaranesprov.descripcion":
			case "lineasfacturasprov.descripcion": {
				valor = nodo.attributeValue(tabla + ".texto");
				break;
			}
			default: {
				valor = "";
				break;
			}
		}
	} else {
		valor = nodo.attributeValue(campo);
		switch(campo) {
			case "em_colores.descripcion": {
				var desColor = nodo.attributeValue("em_colores.descripcion");
				valor = desColor != "" ? (desColor + " - " + nodo.attributeValue("em_colores.codigogit")) : "";
				break;
			}
			case "v_ordenesprod_alag.color": {
				var desColor = nodo.attributeValue("v_ordenesprod_alag.color");
				valor = desColor != "" ? (desColor + " - " + nodo.attributeValue("v_ordenesprod_alag.codigogit")) : "";
				break;
			}
			case "colprod.descripcion": {
				valor = nodo.attributeValue("colprod.descripcion") + " - " + nodo.attributeValue("colprod.codigogit");
				break;
			}
			case "lineasfacturasprov.descripcion":{
				// 			var tamano = nodo.attributeValue("lineasfacturascli.");
				var paisEmpresa = nodo.attributeValue("empresa.codpais");
				var paisFactura = nodo.attributeValue("dirproveedores.codpais");
				if (paisFactura && paisFactura != "" && paisFactura != paisEmpresa) {
					valor = _i.traduceArticulo(paisFactura, nodo.attributeValue("lineasfacturasprov.referencia"));
					if(!valor){
						valor = nodo.attributeValue(campo);
					}
				}
				break;
			}
			case "lineasalbaranesprov.descripcion":{
				valor = _i.concatenaTamanoColor(nodo.attributeValue(campo), nodo.attributeValue("lineasalbaranesprov.codtamanoem"), nodo.attributeValue("lineasalbaranesprov.codcolorem"));
				if(!valor){
					valor = nodo.attributeValue(campo);
				}
				var formato = nodo.attributeValue("lineasalbaranesprov.codformato");
				if(formato && formato != "") {
					valor += " (" + formato + ")";
				}
				break;
			}
			case "lineasfacturascli.dtopor": {
				if (parseFloat(nodo.attributeValue(campo)) == 0) {
					valor = "";
				} else {
					valor = AQUtil.roundFieldValue(valor, "lineasfacturasprov", "dtopor");
					valor = AQUtil.formatoMiles(valor);
				}
				break;
			}
			case "lineasfacturasprov.pvpunitario": {
				valor = AQUtil.roundFieldValue(valor, "lineasfacturascli", "pvpunitario");
				valor = AQUtil.formatoMiles(valor);
				break;
			}
			default: {
				valor = AQUtil.roundFieldValue(valor, "facturascli", "total");
				valor = AQUtil.formatoMiles(valor);
				break;
			}
		}
	}
	return valor;
}

function euromoda_traduceArticulo(codPais, referencia)
{
	var valor = undefined;
	var codIdioma = AQUtil.sqlSelect("paises", "codidioma", "codpais = '" + codPais + "'");
	if (codIdioma && codIdioma != "") {
		valor = AQUtil.sqlSelect("traducciones", "traduccion", "idcampo = '" + referencia + "' AND campo = 'descripcion' AND tabla = 'articulos' AND codidioma = '" + codIdioma + "'");
	}
	return valor;
}


function euromoda_direccionEmpresa(nodo, campo)
{
	var valor = nodo.attributeValue("empresa.codpostal") + " " + nodo.attributeValue("empresa.ciudad") + " (" + nodo.attributeValue("empresa.provincia") + ") - " + AQUtil.sqlSelect("paises", "nombre", "codpais = '" + nodo.attributeValue("empresa.codpais") + "'");
	return valor;
}

function euromoda_direccionProvPedProv(nodo, campo)
{
	debug("euromoda_direccionProvPedProv");
	var valor = "";
	switch (campo) {
		case "origen": {
			valor = nodo.attributeValue("dirproveedores.codpostal");
			valor += valor != "" ? " " : "";
			valor += nodo.attributeValue("dirproveedores.ciudad") + " (" + nodo.attributeValue("dirproveedores.provincia") + ")";
			break;
		}
		case "destino": {
			valor = nodo.attributeValue("pedidosprov.codpostale");
			valor += valor != "" ? " " : "";
			valor += nodo.attributeValue("pedidosprov.ciudade") + " (" + nodo.attributeValue("pedidosprov.provinciae") + ")";
			break;
		}
	}
	return valor;
}

function euromoda_ampliarWhere(nombreConsulta)
{
	var _i = this.iface;
  var where = "";

  switch (nombreConsulta) {
    case "i_pedidosprov": {
			break;
		}
		default: {
			where = _i.__ampliarWhere(nombreConsulta);
			break;
		}
  }
  return where;
}

/*function euromoda_desPartidaPedProv(nodo, campo)
{

	var _i = this.iface;
	var des="";
	var des2="";
	var acabados = nodo.attributeValue("pedidosprov.acabados");   
	if(acabados == "true") {		
		var idLinea = nodo.attributeValue("lineaspedidosprov.idlinea");
		var idPedido = nodo.attributeValue("pedidosprov.idpedido");
		var q = new FLSqlQuery();	
		q.setSelect("t.codbobinavap, SUM(t.cantotal)");
		q.setFrom("em_tramostejido t inner join em_bobinas bob on bob.codbobina = t.codbobinavap and bob.codbobina=t.codbobina");
		q.setWhere("t.idlineapedacabado = " + idLinea +" and bob.idpedidoprov = " + idPedido + " group by t.codbobinavap");		
		if(!q.exec()) {
			return false;
		}
		if (q.first()){
			var metrosBob = q.value("SUM(t.cantotal)");
			metrosBob = AQUtil.roundFieldValue(metrosBob, "em_tramostejido", "cantotal");
			des = "Bobina: "+q.value("t.codbobinavap") + "   " + metrosBob + " metros";
			
			var tamMetrosB = metrosBob.length;
			
			var q2 = new FLSqlQuery();	
			q2.setSelect("t.codpartidappe, sum(t.cantotal)");
			q2.setFrom("em_tramostejido t inner join em_bobinas bob on bob.codbobina = t.codbobinavap and bob.codbobina=t.codbobina");
			q2.setWhere("t.idlineapedacabado = " + idLinea +" and bob.idpedidoprov = " + idPedido + " and t.codbobina = '" + q.value("t.codbobinavap") + "' group by t.codpartidappe");				
			if(!q2.exec()) {
				return false;
			}
			while (q2.next()){
				var metrosPPE = q2.value("sum(t.cantotal)");
				metrosPPE = AQUtil.roundFieldValue(metrosPPE, "em_tramostejido", "cantotal");
				
			
				
				while(metrosPPE.length < tamMetrosB) {
					
					metrosPPE = " "+metrosPPE; 
				}
				var codPartidaPPE = q2.value("t.codpartidappe");
				if(!codPartidaPPE) {
					codPartidaPPE ="";
				}
				var refPPE = "";
				if(codPartidaPPE && codPartidaPPE !="") {
					refPPE = AQUtil.sqlSelect("lotesstock","referencia","codlote = '" + codPartidaPPE + "' ");
					var desc = AQUtil.sqlSelect("articulos","descripcion","referencia = '" + refPPE + "' ");
					refPPE = refPPE +" "+desc;
				}
				
				des = des +"\n"+"  "+codPartidaPPE +" - ("+ refPPE +")" +" " + metrosPPE + " metros";
			
			}
			
		}

	} else {

		var xPartidas = nodo.attributeValue("lineaspedidosprov.xpartidas");
		debug("xPartidas " + xPartidas);
		if (xPartidas != "true") {
			debug("sale");
			return "";
		}
		var idLinea = nodo.attributeValue("lineaspedidosprov.idlinea");
		var codPartida, mPteDist;
		var qPar = new AQSqlQuery;
		qPar.setSelect("ms.codpartida, ms.cantidad, ms.mptedist, ms.canpedida");
		qPar.setFrom("movistock ms INNER JOIN lotesstock p ON ms.codpartida = p.codlote");
		qPar.setWhere("ms.idlineapp = " + idLinea);
		if (!qPar.exec()) {
			return false;
		}
		var canEnPedido;
		while (qPar.next()) {
			codPartida = qPar.value("ms.codpartida")
	// 		canEnPedido = AQUtil.quickSqlSelect("lineaspedidosprov lp INNER JOIN movistock ms ON lp.idlinea = ms.idlineapp", "SUM(ms.canpedida)", "lp.idpedido = " + nodo.attributeValue("pedidosprov.idpedido") + " AND ms.codpartida = '" + codPartida + "'");
	// 		canEnPedido = isNaN(canEnPedido) ? 0 : canEnPedido;
			mPteDist = qPar.value("ms.mptedist");// + parseFloat(canEnPedido);
			var q = new FLSqlQuery;
			q.setSelect("a.codigo, a.fecha");
			q.setFrom("movistock ms INNER JOIN lineasalbaranesprov la ON ms.idlineaap = la.idlinea INNER JOIN albaranesprov a ON la.idalbaran = a.idalbaran");
			q.setWhere("ms.codlote = '" + codPartida + "'");
			q.setForwardOnly(true);
			if (!q.exec()) {
				return false;
			}
			var albaranes = "", numAlb = 0;
			while (q.next()) {
				albaranes += (albaranes != "") ? ", " : "";
				albaranes += q.value("a.codigo") + " " + sys.translate("de") + " " + AQUtil.dateAMDtoDMA(q.value("a.fecha"));
				numAlb++;
			}
			des += des != "" ? "\n" : "";
			des += sys.translate("UTILIZAR %1m DE PARTIDA %2 CON TOTAL %3m").arg(qPar.value("ms.cantidad")).arg(codPartida).arg(mPteDist);
			if (numAlb > 0) {
				if (numAlb == 1) {
					des += " " + sys.translate("ORIGINAL DEL ALBAR�N %1.").arg(albaranes);
				} else {
					des += " " + sys.translate("ORIGINAL DE LOS ALBARANES %1.").arg(albaranes);
				}
			}
		}
	}

	return des;
}*/

function euromoda_desPartidaPedProv(nodo, campo)
{

	var _i = this.iface;
	var des="";
	var des2="";
	var acabados = nodo.attributeValue("pedidosprov.acabados");   
	if(acabados == "true") {		
		var idLinea = nodo.attributeValue("lineaspedidosprov.idlinea");
		var idPedido = nodo.attributeValue("pedidosprov.idpedido");
		var q = new FLSqlQuery();	
		q.setSelect("bob.codbobina,SUM(t.cantotal)");
		q.setFrom("em_tramostejido t inner join em_bobinas bob on (bob.codbobina = t.codbobinavap or bob.codbobina = t.codbobinaprp ) and bob.codbobina=t.codbobina");
		q.setWhere("t.idlineapedacabado = " + idLinea +" and bob.idpedidoprov = " + idPedido + " group by bob.codbobina");		
		if(!q.exec()) {
			return false;
		}
		if (q.first()){
			var metrosBob = q.value("SUM(t.cantotal)");
			metrosBob = AQUtil.roundFieldValue(metrosBob, "em_tramostejido", "cantotal");
			des = "Bobina: "+q.value("bob.codbobina") + "   " + metrosBob + " metros";
			
			var tamMetrosB = metrosBob.length;
			
			var q2 = new FLSqlQuery();	
			q2.setSelect("t.codpartidappe, sum(t.cantotal)");
			q2.setFrom("em_tramostejido t inner join em_bobinas bob on (bob.codbobina = t.codbobinavap or bob.codbobina = t.codbobinaprp ) and bob.codbobina=t.codbobina");
			q2.setWhere("t.idlineapedacabado = " + idLinea +" and bob.idpedidoprov = " + idPedido + " and t.codbobina = '" + q.value("bob.codbobina") + "' group by t.codpartidappe");				
			if(!q2.exec()) {
				return false;
			}
			while (q2.next()){
				var metrosPPE = q2.value("sum(t.cantotal)");
				metrosPPE = AQUtil.roundFieldValue(metrosPPE, "em_tramostejido", "cantotal");
				
			
				
				while(metrosPPE.length < tamMetrosB) {
					
					metrosPPE = " "+metrosPPE; 
				}
				var codPartidaPPE = q2.value("t.codpartidappe");
				if(!codPartidaPPE) {
					codPartidaPPE ="";
				}
				var refPPE = "";
				if(codPartidaPPE && codPartidaPPE !="") {
					refPPE = AQUtil.sqlSelect("lotesstock","referencia","codlote = '" + codPartidaPPE + "' ");
					var desc = AQUtil.sqlSelect("articulos","descripcion","referencia = '" + refPPE + "' ");
					refPPE = refPPE +" "+desc;
				}
				
				des = des +"\n"+"  "+codPartidaPPE +" - ("+ refPPE +")" +" " + metrosPPE + " metros";
			
			}
			
		}

	} else {

		var xPartidas = nodo.attributeValue("lineaspedidosprov.xpartidas");
		debug("xPartidas " + xPartidas);
		if (xPartidas != "true") {
			debug("sale");
			return "";
		}
		var idLinea = nodo.attributeValue("lineaspedidosprov.idlinea");
		var codPartida, mPteDist;
		var qPar = new AQSqlQuery;
		qPar.setSelect("ms.codpartida, ms.cantidad, ms.mptedist, ms.canpedida");
		qPar.setFrom("movistock ms INNER JOIN lotesstock p ON ms.codpartida = p.codlote");
		qPar.setWhere("ms.idlineapp = " + idLinea);
		if (!qPar.exec()) {
			return false;
		}
		var canEnPedido;
		while (qPar.next()) {
			codPartida = qPar.value("ms.codpartida")
	// 		canEnPedido = AQUtil.quickSqlSelect("lineaspedidosprov lp INNER JOIN movistock ms ON lp.idlinea = ms.idlineapp", "SUM(ms.canpedida)", "lp.idpedido = " + nodo.attributeValue("pedidosprov.idpedido") + " AND ms.codpartida = '" + codPartida + "'");
	// 		canEnPedido = isNaN(canEnPedido) ? 0 : canEnPedido;
			mPteDist = qPar.value("ms.mptedist");// + parseFloat(canEnPedido);
			var q = new FLSqlQuery;
			q.setSelect("a.codigo, a.fecha");
			q.setFrom("movistock ms INNER JOIN lineasalbaranesprov la ON ms.idlineaap = la.idlinea INNER JOIN albaranesprov a ON la.idalbaran = a.idalbaran");
			q.setWhere("ms.codlote = '" + codPartida + "'");
			q.setForwardOnly(true);
			if (!q.exec()) {
				return false;
			}
			var albaranes = "", numAlb = 0;
			while (q.next()) {
				albaranes += (albaranes != "") ? ", " : "";
				albaranes += q.value("a.codigo") + " " + sys.translate("de") + " " + AQUtil.dateAMDtoDMA(q.value("a.fecha"));
				numAlb++;
			}
			des += des != "" ? "\n" : "";
			des += sys.translate("UTILIZAR %1m DE PARTIDA %2 CON TOTAL %3m").arg(qPar.value("ms.cantidad")).arg(codPartida).arg(mPteDist);
			if (numAlb > 0) {
				if (numAlb == 1) {
					des += " " + sys.translate("ORIGINAL DEL ALBAR�N %1.").arg(albaranes);
				} else {
					des += " " + sys.translate("ORIGINAL DE LOS ALBARANES %1.").arg(albaranes);
				}
			}
		}
	}

	return des;
}

function euromoda_acabadosPedProv(nodo, campo)
{
	var idPedido = nodo.attributeValue("pedidosprov.idpedido");

	var q = new FLSqlQuery;
	q.setSelect("a.descripcion");
	q.setFrom("em_acabadospedprov ap INNER JOIN em_acabados a ON ap.em_codacabado = a.em_codacabado");
	q.setWhere("ap.idpedido = " + idPedido);
	q.setForwardOnly(true);
	if (!q.exec()) {
		return false;
	}
	var acabados = "";
	while (q.next()) {
		acabados += (acabados != "") ? "\n" : "";
		acabados += q.value("a.descripcion");
	}
	acabados = (acabados != "") ? (sys.translate("ACABADOS DEL PEDIDO\n") + acabados) : "";
	return acabados;
}

function euromoda_porIVA(nodo, campo)
{
  var util = new FLUtil;
  var idDocumento;
  var tablaPadre;
  var tabla;
  var campoClave;
  var porIva, whereTipo = "";
  switch (campo) {
    case "facturacli": {
      tablaPadre = "facturascli";
      tabla = "lineasfacturascli";
      campoClave = "idfactura";
			whereTipo = "tipoconcepto <> 'Texto' AND "
      break;
    }
    case "albarancli": {
      tablaPadre = "albaranescli";
      tabla = "lineasalbaranescli";
      campoClave = "idalbaran";
			whereTipo = "tipoconcepto <> 'Texto' AND "
      break;
    }
    case "pedidocli": {
      tablaPadre = "pedidoscli";
      tabla = "lineaspedidoscli";
      campoClave = "idpedido";
			whereTipo = "tipoconcepto <> 'Texto' AND "
      break;
    }
    case "presupuestocli": {
      tablaPadre = "presupuestoscli";
      tabla = "lineaspresupuestoscli";
      campoClave = "idpresupuesto";
			whereTipo = "tipoconcepto <> 'Texto' AND "
      break;
    }
    case "facturaprov": {
      tablaPadre = "facturasprov";
      tabla = "lineasfacturasprov";
      campoClave = "idfactura";
			whereTipo = "tipoconcepto <> 'Texto' AND "
      break;
    }
    case "albaranprov": {
      tablaPadre = "albaranesprov";
      tabla = "lineasalbaranesprov";
      campoClave = "idalbaran";
      break;
    }
    case "pedidoprov": {
      tablaPadre = "pedidosprov";
      tabla = "lineaspedidosprov";
      campoClave = "idpedido";
      break;
    }
    default: {
      return "I.V.A.";
    }

  }
  idDocumento = nodo.attributeValue(tablaPadre + "." + campoClave);
  this.iface.variosIvas_ = false;
  porIva = parseFloat(util.sqlSelect(tabla, "iva", whereTipo + campoClave + " = " + idDocumento));
  if (!porIva)
    porIva = 0;

  if (util.sqlSelect(tabla, campoClave, whereTipo + campoClave + " = " + idDocumento + " AND iva <> " + porIva)) {
    this.iface.variosIvas_ = true;
    porIva = 0;
  }

  if (porIva.toString() == "0") {
    return "I.V.A.";
  } else {
    return "I.V.A. " + porIva.toString() + "%";
  }
}

function euromoda_numPagina(nodo, campo)
{
	debug("euromoda_numPagina " + campo);
	var _i = this.iface;
	if (campo == "1") {
		_i.nP_ = 1;
	} else {
		_i.nP_++;
	}
	debug("nP = " + _i.nP_);
	return _i.nP_;
}

function euromoda_vencimiento(nodo, campo)
{
	var indice = campo.right(1);

debug("indice = " + indice);
	var campoRecibo = campo.left(campo.length - 1);
debug("campoRecibo = " + campoRecibo);
	var vencimientos = nodo.attributeValue("facturascli.em_vencimientos");
	if (!vencimientos || vencimientos == "") {
		return "";
	}
	var aVs = vencimientos.split(";");
	if (indice >= aVs.length) {
		return "";
	}
	var v = aVs[indice - 1];
	var aV = v.split("*");
	var valor;
	switch (campoRecibo) {
		case "fechav": {
			valor = aV[0];
			valor = AQUtil.dateAMDtoDMA(valor);
			break;
		}
		case "importe": {
			valor = aV[1];
			break;
		}
		case "coddivisa": {
			valor = nodo.attributeValue("facturascli.coddivisa");
			break;
		}
		default: {
			valor = "";
		}
	}
	return valor;

// 	var idFactura = nodo.attributeValue("facturascli.idfactura");
// 	campoRecibo = (campoRecibo == "importe") ? "SUM(importe)" : campoRecibo;
// 	var q = new FLSqlQuery;
// 	q.setSelect(campoRecibo);
// 	q.setFrom("reciboscli");
// 	q.setWhere("idfactura = " + idFactura + " GROUP BY fechav ORDER BY fechav");
// 	q.setForwardOnly(true);
// 	if (!q.exec()) {
// 		return "";
// 	}
// debug(q.sql());
// 	if (q.size() < indice) {
// 		return "";
// 	}
// 	var i = 0;
// 	valor = "";
// 	while (q.next()) {
// 		i++
// 		if (i == indice) {
// 			valor = q.value(campoRecibo);
// 			break;
// 		}
// 	}
// 	if (valor) {
// 		switch (campoRecibo) {
// 			case "fechav": {
// 				valor = AQUtil.dateAMDtoDMA(valor);
// 				break;
// 			}
// 		}
// 	}
// debug("valor = " + valor);
// 	return valor;
}

/*function euromoda_cuentaFacturaCli(nodo, campo)
{
  var datosCuenta;
  var ret;
	var idFactura = nodo.attributeValue("facturascli.idfactura");
	var codPago = nodo.attributeValue("facturascli.em_codpago");
  var domiciliado = (nodo.attributeValue("em_formaspago.domiciliado") == "true");
// 	if (!domiciliado) {
// 		return "";
// 	}
  datosCuenta = flfactppal.iface.pub_ejecutarQry("reciboscli r INNER JOIN em_formaspago fp ON r.em_codpago = fp.em_codpago", "r.ctaentidad,r.ctaagencia,r.cuenta", "r.idfactura = " + idFactura + " AND r.codcuenta IS NOT NULL AND fp.domiciliado", "reciboscli");
	if (!datosCuenta) {
		return "";
	}
	if (datosCuenta.result != 1) {
		return "";
	}

  var dc = AQUtil.calcularDC(datosCuenta["r.ctaentidad"] + datosCuenta["r.ctaagencia"]) + AQUtil.calcularDC(datosCuenta["r.cuenta"]);
  ret = datosCuenta["r.ctaentidad"] + " " + datosCuenta["r.ctaagencia"] + " " + dc + " " + datosCuenta["r.cuenta"];
  return ret;
}*/

/*function euromoda_cuentaFacturaCli(nodo, campo)
{	
	var _i = this.iface;
	var datosCuenta;
	var ret;
	var idFactura = nodo.attributeValue("facturascli.idfactura");
	var codPago = nodo.attributeValue("facturascli.em_codpago");
	var domiciliado = (nodo.attributeValue("em_formaspago.domiciliado") == "true");
	// 	if (!domiciliado) {
	// 		return "";
	// 	}
	datosCuenta = flfactppal.iface.pub_ejecutarQry("reciboscli r INNER JOIN em_formaspago fp ON r.em_codpago = fp.em_codpago INNER JOIN cuentasbcocli c ON r.codcuenta =  c.codcuenta", "r.ctaentidad,r.ctaagencia,r.cuenta,c.codigocuenta,c.codpais", "r.idfactura = " + idFactura + " AND r.codcuenta IS NOT NULL AND fp.domiciliado", "reciboscli");
	if (!datosCuenta) {
		return "";
	}
	if (datosCuenta.result != 1) {
		return "";
	}
	var pais = datosCuenta["c.codpais"];
	if(pais == "ES") {
		var dc = AQUtil.calcularDC(datosCuenta["r.ctaentidad"] + datosCuenta["r.ctaagencia"]) + AQUtil.calcularDC(datosCuenta["r.cuenta"]);
		ret = datosCuenta["r.ctaentidad"] + " " + datosCuenta["r.ctaagencia"] + " " + dc + " " + datosCuenta["r.cuenta"];
		
	} else {
		ret = datosCuenta["c.codigocuenta"];
		
	}
	
	return ret;
}*/

function euromoda_cuentaFacturaCli(nodo, campo)
{	
	var _i = this.iface;
	var datosCuenta;
	var ret, codCuenta,  BIC;
	var idFactura = nodo.attributeValue("facturascli.idfactura");
	var codPago = nodo.attributeValue("facturascli.em_codpago");
	var domiciliado = (nodo.attributeValue("em_formaspago.domiciliado") == "true");
	// 	if (!domiciliado) {
	// 		return "";
	// 	}
	datosCuenta = flfactppal.iface.pub_ejecutarQry("reciboscli r INNER JOIN em_formaspago fp ON r.em_codpago = fp.em_codpago INNER JOIN cuentasbcocli c ON r.codcuenta =  c.codcuenta", "c.codigocuenta,c.codpais,c.bic,c.iban", "r.idfactura = " + idFactura + " AND r.codcuenta IS NOT NULL AND fp.domiciliado", "reciboscli");
	if (!datosCuenta) {
		return "";
	}
	if (datosCuenta.result != 1) {
		return "";
	}
	var pais = datosCuenta["c.codpais"];
	var codCuenta = datosCuenta["c.codigocuenta"];
	var IBAN = datosCuenta["c.iban"];
	var BIC = datosCuenta["c.bic"]; 

    IBAN = _i.ocultaDigitosCuenta(IBAN, true);
    codCuenta = _i.ocultaDigitosCuenta(codCuenta, true);

	ret = "IBAN "+_i.formatoIBAN(IBAN)+"\nSWIFT/BIC "+BIC+"\nCCC "+_i.formatoCCC(codCuenta);
	
	return ret;
}

function euromoda_codProforma(nodo, campo)
{
	return "PR" + nodo.attributeValue("presupuestoscli.codigo");
}

function euromoda_inicializaTotalNecesario()
{
	var _i = this.iface;

	_i.totalNecesario_ = 0.0;

	return "";
}

function euromoda_necesarioInv(nodo, campo)
{
	var _i = this.iface;

	var v = nodo.attributeValue("(stocks.cantidad - (stocks.reservada + stocks.reservadapterecibir + stocks.afaltas))");
	v = parseFloat(v);
	v = isNaN(v) ? 0 : v;
	v *= -1;
	v = (v < 0) ? 0 : v;

	_i.actualizaTotalNecesario(v);
	return v;
}

function euromoda_actualizaTotalNecesario(v)
{
	var _i = this.iface;

	_i.totalNecesario_ = parseFloat(_i.totalNecesario_) + parseFloat(v);
}

function euromoda_dameTotalNecesario()
{
	var _i = this.iface;

	return _i.totalNecesario_;
}

function euromoda_logoMembrete(nodo, campo)
{
	var _i = this.iface;

	if(!_i.membrete_){
		return;
	}
	return _i.__logo(nodo, campo);
}

function euromoda_ponerMembrete(opcion)
{
	var _i = this.iface;
	_i.membrete_ = opcion;
}

function euromoda_dameMembrete()
{
	var _i = this.iface;

	if(_i.membrete_ == undefined){
		_i.membrete_ = false;
	}

	return _i.membrete_;
}

function euromoda_pieLinea1(campo)
{
	var _i = this.iface;

	if(!_i.membrete_){
		return;
	}

	var linea1 = _i.datoEmpresa("direccion") + " � Apartado de Correos, n� " + _i.datoEmpresa("apartado") + " � Telf. " + _i.datoEmpresa("telefono") + " � Fax: " + _i.datoEmpresa("fax");
	return linea1;
}

function euromoda_pieLinea2(campo)
{
	var _i = this.iface;

	if(!_i.membrete_){
		return;
	}

	var linea2 = "Email: " + _i.datoEmpresa("email") + " � http://" + _i.datoEmpresa("web");
	return linea2;
}

function euromoda_pieLinea3(campo)
{
	var _i = this.iface;

	if(!_i.membrete_){
		return;
	}

	var linea3 = _i.datoEmpresa("codpostal") + " " + _i.datoEmpresa("ciudad") + " (" + _i.datoEmpresa("provincia") + ") SPAIN";
	return linea3;
}

function euromoda_pieLinea4(campo)
{
	var _i = this.iface;

	if(!_i.membrete_){
		return;
	}

	var linea4 = _i.datoEmpresa("regmercantil");
	return linea4;
}

function euromoda_datoEmpresa(campo)
{
	var _i = this.iface;

	if (!_i.datosEmpresa_) {
		_i.datosEmpresa_ = flfactppal.iface.pub_ejecutarQry("empresa", "direccion,apartado,telefono,fax,email,web,codpostal,ciudad,provincia,regmercantil", "1 = 1");
		if (_i.datosEmpresa_.result != 1) {
			return "";
		}
	}
	if (!(campo in _i.datosEmpresa_)) {
		return "";
	}
	return _i.datosEmpresa_[campo];
}

function euromoda_dameTelefonoProveedor(nodo, campo)
{
	if (campo == "telefonoprov") {
		var telfPedido = nodo.attributeValue("pedidosprov.telcontacto");
		if (telfPedido && telfPedido != ""){
			return telfPedido;
		}
		return nodo.attributeValue("proveedores.telefono1");
	} else {
		var telfAlmacen = nodo.attributeValue("almacendestino.telefono");
		if(telfAlmacen && telfAlmacen != ""){
			return telfAlmacen;
		}

		var telfProvDestino = nodo.attributeValue("proveedordestino.telefono1");
		if(telfProvDestino && telfProvDestino != ""){
			return telfProvDestino;
		}
	}
	return "";
}

function euromoda_ordenProduccionPP(nodo, campo)
{
	var codOrden = nodo.attributeValue("pedidosprov.codordenprod");

	if (codOrden && codOrden != ""){
		return sys.translate("Orden Producci�n: %1").arg(codOrden);
	}
	return "";
}

function euromoda_construyeDir(nodo, campo)
{
	var d = "", esp = "  ";
	var att = nodo.attributeValue;
	switch (campo) {
		case "hojacarga_dirfac": {
			d += att("dirclientes.descripcion") + "\n";
			d += att("dirclientes.direccion") + "\n";
			d += (att("dirclientes.codpostal") != "" ? ("C.P." + att("dirclientes.codpostal")) : "");
			d += ". " + att("dirclientes.ciudad");
			d += att("dirclientes.provincia").toUpperCase() != att("dirclientes.ciudad").toUpperCase() ? (", " + att("dirclientes.provincia")) : "";
			d += "\n" + att("paises.nombre");
			break;
		}
		case "hojacarga_direnv": {
			d += att("direnvio.descripcion") + "\n";
			d += att("pedidoscli.direccion") + "\n";
			d += (att("pedidoscli.codpostal") != "" ? ("C.P." + att("pedidoscli.codpostal")) : "");
			d += ". " + att("pedidoscli.ciudad");
			d += att("pedidoscli.provincia").toUpperCase() != att("pedidoscli.ciudad").toUpperCase() ? (", " + att("pedidoscli.provincia")) : "";
			d += "\n" + att("paisenvio.nombre");
			break;
		}
	}
	return d;
}

function euromoda_codPartidaTrans(nodo, campo)
{
	var att = nodo.attributeValue;

	var idLinea = att("lineastransstock.idlinea");
	var codAlmacen = att("almacenes.codalmacen");
	var codPartida = AQUtil.quickSqlSelect("movistock ms INNER JOIN stocks s ON (ms.idstock = s.idstock AND s.codalmacen = '" + codAlmacen + "')", "ms.codlote", "ms.idlineats = " + idLinea);
	return codPartida ? codPartida : "";
}

function euromoda_codPartidaTransAca(nodo, campo)
{
	var att = nodo.attributeValue;
	var codAlmacenOri = att("em_transstockaca.codalmaorigen");
	var codAlmacenDest = att("em_transstockaca.codalmadestino");
	var idLinea = att("em_lineastransstockaca.idlinea");
	var codAlmacen = att("almacenes.codalmacen");
	var codPartidaOri = att("em_lineastransstockaca.codpartida");
	var codPartida = "" ;
	if(codAlmacen == codAlmacenOri) {
		codPartida = codPartidaOri;	
	} else {
		codPartida = AQUtil.quickSqlSelect("em_tramostejido", "codpartida", "codpartidaorigen = '" + codPartidaOri + "'");
	}	
	
	return codPartida ? codPartida : "";
}

function euromoda_acabadosObservPedProv(nodo,campo)
{
	debug("\n\neuromoda_acabadosObservPedProv");
	var observaciones = nodo.attributeValue("em_acabadospedprov.observacion");
	var acabados = nodo.attributeValue("em_acabados.descripcion");
	if (observaciones !=""){
		return observaciones;
	}else if (acabados!=""){
		return acabados;
	}else{ 
		return "";	
	}

}

function euromoda_preprocesaReportData(nombreReport, rptViewer)
{
	var _i = this.iface;
	switch (nombreReport) {
	case "pr_i_ordenesprod_dc": {
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();
		var levelAnt = "0", level;		
		var kD = xData.namedItem("KugarData");		
		var refCompuestoAnt ="";
		var pintar = false;
		var contador = 1;
		for (var n = kD.firstChild(); n && !n.isNull(); n = n.nextSibling()) {
			level = n.toElement().attribute("level");			
			debug("levelAnt: "+levelAnt);
			debug("level: "+level);
			if (level == "2" && levelAnt == "1") {
				var obs = flprodinfo.iface.observacionesDConf(n);
				debug("\nen procesar report data obs: "+obs);
				var aObs = obs.split("\n");
				debug("aObs.length: "+aObs.length)
				for (var i = 0; i < aObs.length; i++) {
					var nN = n.cloneNode();
					debug("aObs[i]: "+aObs[i])
					nN.toElement().setAttribute("observaciones", aObs[i]);
					kD.insertBefore(nN, n);
				}
			}
			if (level == "2") {
				n.toElement().setAttribute("level", "3");				
				var refCompuesto = n.toElement().attribute("articulos.referencia");				
				if(refCompuesto != refCompuestoAnt) {
					contador = 1;
					refCompuestoAnt = refCompuesto;
				}
				var numRefCompuesto = AQUtil.sqlSelect("articuloscomp","count(*)","refcompuesto = '" + refCompuesto + "' and idseccion ='3'");
				if(!numRefCompuesto || numRefCompuesto == 0 || numRefCompuesto == 1 || numRefCompuesto == contador) {
					pintar = true;
				} else if(contador == numRefCompuesto) {
					pintar = true;
				} else {
					pintar = false;
					contador++;
				}				
				if(pintar) {					
					var q = new AQSqlQuery;	
					q.setSelect("ac.cantidad,ac.refcomponente,ac.desccomponente,ac.codtamanoem,ac.codcolorem,ac.observaciones,ac.componente,ac.componormal,em_disenos.codseriediseno");
					q.setFrom("articuloscomp ac INNER JOIN articulos a ON ac.refcomponente = a.referencia LEFT OUTER JOIN em_dibujos ON a.coddibestamp = em_dibujos.coddibujoem LEFT OUTER JOIN em_disenos ON em_dibujos.coddiseno = em_disenos.coddiseno");
					q.setWhere("ac.refcompuesto = '" + refCompuesto + "' and ac.idseccion = '9' ORDER BY ac.orden DESC"); 					
					if (!q.exec()){
						return;
					}  
					while(q.next()) {
						var refComponente = q.value("ac.refcomponente");					
						var descripcion = q.value("ac.desccomponente");
						var compoNormal = q.value("ac.componormal");
						var componente = q.value("ac.componente");

						if(compoNormal && compoNormal != "") {
							descripcion = compoNormal+": "+descripcion;
						} else if(componente && componente != "") {	
							descripcion = componente + ": " + descripcion;
						}
						var codseriediseno = q.value("em_disenos.codseriediseno");
						if (codseriediseno && codseriediseno != ""){
							descripcion += " - [" + codseriediseno + "]"
						}

						var nN = n.cloneNode();					
						nN.toElement().setAttribute("cantidad9", q.value("ac.cantidad"));
						nN.toElement().setAttribute("refcomponente9", q.value("ac.refcomponente"));
						nN.toElement().setAttribute("desccomponente9", descripcion);
						nN.toElement().setAttribute("codtamanoem9", q.value("ac.codtamanoem"));
						nN.toElement().setAttribute("codcolorem9", q.value("ac.codcolorem"));
						nN.toElement().setAttribute("observaciones9", q.value("ac.observaciones"));
						nN.toElement().setAttribute("level", "4");
						kD.insertAfter(nN, n);
					}				
				}
			}
			levelAnt = level;
		}
		debug(x.toString(4));		
		rptViewer.setReportData(xData);
		break;
	}
	/*case "i_albaranescli": {
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");
		for (var n = kD.firstChild(); n && !n.isNull(); n = n.nextSibling()) {
			level = n.toElement().attribute("level");
			if (level == "2" && levelAnt == "1") {
				var obs = n.attributeValue("albaranescli.observaciones");
				debug("\nen procesar report data obs: "+obs);
				var aObs = obs.split("\n");
				debug("aObs.length: "+aObs.length)
				for (var i = 0; i < aObs.length; i++) {
					var nN = n.cloneNode();
					debug("aObs[i]: "+aObs[i])
					nN.toElement().setAttribute("observaciones", aObs[i]);
					kD.insertBefore(nN, n);
				}
			}
			if (level == "2") {
				n.toElement().setAttribute("level", "3");
			}
			levelAnt = level;
		}
		debug(x.toString(4));
		rptViewer.setReportData(xData);
		break;
	}*/
	case "i_albaranescli": {
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();	
		debug(x.toString(4));
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");		
		var nUltimo;
		for (var n = kD.firstChild(); n && !n.isNull(); n = n.nextSibling()) {
		
			level = n.toElement().attribute("level");
			debug("\n\n\nLEVEL: "+level);
			if(level == "0") {
				if(levelAnt == "4") {
					//debug("\n\ndeber�a de poner observaciones");				


					var obs = nUltimo.attributeValue("albaranescli.observaciones");
					//debug("\nen procesar report data obs: "+obs);
					if(obs && obs != "") {
						n = n.previousSibling();					
						var aObs = obs.split("\n");

						//debug("aObs.length: "+aObs.length)
						for (var i = 0; i < aObs.length; i++) {

							if(i==0) {
								var nN = n.cloneNode();
								//debug("aObs[i]: "+aObs[i])
								nN.toElement().setAttribute("observaciones", aObs[i]);
								nN.toElement().setAttribute("level", "5");	

								//kD.insertBefore(nN, n);	
								kD.insertAfter(nN, n);

							} else {
								n = n.nextSibling();
								var nN = n.cloneNode();
								//debug("aObs[i]: "+aObs[i])
								nN.toElement().setAttribute("observaciones", aObs[i]);
								nN.toElement().setAttribute("level", "5");	
								//kD.insertBefore(nN, n);	
								kD.insertAfter(nN, n);
							}

						}	

					}
				}
			} else if (level == "3") { 
				var descripcion = _i.datoLineaCliente(n, "lineasalbaranescli.descripcion");
				
				if(descripcion && descripcion != "") {					
					var aDesc = descripcion.split("\n");
					n.toElement().setAttribute("descripcionLin", aDesc[0]);
					for (var i = 0; i < aDesc.length; i++) {																
						if(i==0) {						
							n.toElement().setAttribute("level", "3");
							n.toElement().setAttribute("descripcionLin", aDesc[i]);
							if(n && !n.isNull()) {

							}
						} else {
							if(n && !n.isNull()) {
								var nN = n.cloneNode();					
								nN.toElement().setAttribute("descripcionLin", aDesc[i]);						
								nN.toElement().setAttribute("level", "3");						
								kD.insertAfter(nN, n);
								n = n.nextSibling();	
							}							
						}			
																	 
					}					
				
				}
			} 
			levelAnt = level;
			nUltimo = n;

		}		
		var obs = nUltimo.attributeValue("albaranescli.observaciones");
		if(obs != "") {
			var nN = nUltimo.cloneNode();
			var e = nN.toElement();
			kD.appendChild(nN);				
			var obs = nUltimo.attributeValue("albaranescli.observaciones");
			if(obs && obs != "") {
				e.setAttribute("level", "5");	
				var aObs = obs.split("\n");
				for (var i = 0; i < aObs.length; i++) {
					var nN = nUltimo.cloneNode();
					var e = nN.toElement();
					e.setAttribute("observaciones", aObs[i]);
					e.setAttribute("level", "5");		    
					kD.appendChild(nN);
				}	
			}
		}
		debug(x.toString(4));
		rptViewer.setReportData(xData);
		break;
	}
	case "i_albaranescli_int": {
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();	
		debug(x.toString(4));
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");		
		var nUltimo;
		for (var n = kD.firstChild(); n && !n.isNull(); n = n.nextSibling()) {
		
			level = n.toElement().attribute("level");
			debug("\n\n\nLEVEL: "+level);
			if(level == "0") {
				if(levelAnt == "4") {
					//debug("\n\ndeber�a de poner observaciones");				


					var obs = nUltimo.attributeValue("albaranescli.observaciones");
					//debug("\nen procesar report data obs: "+obs);
					if(obs && obs != "") {
						n = n.previousSibling();					
						var aObs = obs.split("\n");

						//debug("aObs.length: "+aObs.length)
						for (var i = 0; i < aObs.length; i++) {

							if(i==0) {
								var nN = n.cloneNode();
								//debug("aObs[i]: "+aObs[i])
								nN.toElement().setAttribute("observaciones", aObs[i]);
								nN.toElement().setAttribute("level", "5");	

								//kD.insertBefore(nN, n);	
								kD.insertAfter(nN, n);

							} else {
								n = n.nextSibling();
								var nN = n.cloneNode();
								//debug("aObs[i]: "+aObs[i])
								nN.toElement().setAttribute("observaciones", aObs[i]);
								nN.toElement().setAttribute("level", "5");	
								//kD.insertBefore(nN, n);	
								kD.insertAfter(nN, n);
							}

						}	

					}
				}
			} else if (level == "4") {
				debug("level: "+level);
				if(levelAnt == "3") {
					debug("levelAnt_: "+levelAnt);
					var descripcion = _i.datoLineaCliente(n, "lineasalbaranescli.descripcion");
					debug("descripcion: "+descripcion);
					if(descripcion && descripcion != "") {					
						var aDesc = descripcion.split("\n");
						for (var i = 0; i < aDesc.length; i++) {																
							if(i==0) {			
								debug("pongo descripcion: "+ aDesc[i]);			
								n.toElement().setAttribute("level", "4");
								n.toElement().setAttribute("descripcionLin", aDesc[i]);

							} else {
								if(n && !n.isNull()) {
									
									var nN = n.cloneNode();
									
									debug("2pongo descripcion: "+ aDesc[i]);
																		
									nN.toElement().setAttribute("descripcionLin", aDesc[i]);						
									nN.toElement().setAttribute("level", "4");						
									kD.insertAfter(nN, n); 	
									n = n.nextSibling();
								}							
							}			
																		 
						}

					}			
				}
			} 

			levelAnt = level;
			nUltimo = n;

		}		
		var obs = nUltimo.attributeValue("albaranescli.observaciones");
		if(obs != "") {
			var nN = nUltimo.cloneNode();
			var e = nN.toElement();
			kD.appendChild(nN);				
			var obs = nUltimo.attributeValue("albaranescli.observaciones");
			if(obs && obs != "") {
				e.setAttribute("level", "5");	
				var aObs = obs.split("\n");
				for (var i = 0; i < aObs.length; i++) {
					var nN = nUltimo.cloneNode();
					var e = nN.toElement();
					e.setAttribute("observaciones", aObs[i]);
					e.setAttribute("level", "5");		    
					kD.appendChild(nN);
				}	
			}
		}
		debug(x.toString(4));
		rptViewer.setReportData(xData);
		break;
	}
	case "pr_i_ordenesprod_al": {
		debug("\n\n\n\n\n\n");
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");
		
		for (var n = kD.firstChild(); n && !n.isNull(); n = n.nextSibling()) {
			level = n.toElement().attribute("level");
			debug("n: "+n);
			debug("     level: "+level);
			debug("     levelAnt: "+levelAnt);
			debug("     componente: "+n.attributeValue("articulos.referencia"));

			if (level == "2" && levelAnt == "1") {				
				var obs = flprodinfo.iface.observacionesAux(n);
				if(obs && obs != "") {
					debug("          \nen procesar report data obs: "+obs);
					var aObs = obs.split("\n");
					debug("          aObs.length: "+aObs.length)
					for (var i = 0; i < aObs.length; i++) {
						var nN = n.cloneNode();
						debug("               aObs[i]: "+aObs[i])
						nN.toElement().setAttribute("observaciones", aObs[i]);
						if(i == 0) {
							nN.toElement().setAttribute("txtobservaciones", "Observaci�n:");
						}
						kD.insertBefore(nN, n);
					}
				}
			}
			if (level == "3") {
				n.toElement().setAttribute("level", "4");
			}
			levelAnt = level;
		}
		debug("\n\n\n\n\n\n");
		debug(x.toString(4));
		debug("\n\n\n\n\n\n");
		rptViewer.setReportData(xData);
		break;
	}
	case "pr_i_ordenesprod_alag": {
		debug("\n\n\n\n\n\n");
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");
		
		for (var n = kD.firstChild(); n && !n.isNull(); n = n.nextSibling()) {
			level = n.toElement().attribute("level");
			debug("n: "+n);
			debug("     level: "+level);
			debug("     levelAnt: "+levelAnt);
			debug("     componente: "+n.attributeValue("articulodesc.referencia"));

			if (level == "2" && levelAnt == "1") {				
				var obs = flprodinfo.iface.observacionesAuxAg(n);
				if(obs && obs != "") {
					debug("          \nen procesar report data obs: "+obs);
					var aObs = obs.split("\n");
					debug("          aObs.length: "+aObs.length)
					for (var i = 0; i < aObs.length; i++) {
						var nN = n.cloneNode();
						debug("               aObs[i]: "+aObs[i])
						nN.toElement().setAttribute("observaciones", aObs[i]);
						if(i == 0) {
							nN.toElement().setAttribute("txtobservaciones", "Observaci�n:");
						}
						kD.insertBefore(nN, n);
					}
				}
			}
			if (level == "3") {
				n.toElement().setAttribute("level", "4");
			}
			levelAnt = level;
		}
		debug("\n\n\n\n\n\n");
		debug(x.toString(4));
		debug("\n\n\n\n\n\n");
		rptViewer.setReportData(xData);
		break;
	}	

	case "pr_i_ordenesprod_alagttt": {
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();	
		debug(x.toString(4));
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");		
		var nUltimo;
		for (n = kD.firstChild(); n && !n.isNull(); n = n.nextSibling()) {
		
			level = n.toElement().attribute("level");
			debug("\n\n\nLEVEL: "+level);
			debug("levelAnt: "+levelAnt);
			debug("nultimo: "+nUltimo);
			if(level == "0") {
				if(levelAnt == "1") {
					//debug("\n\ndeber�a de poner observaciones");				


					/*var obs = flprodinfo.iface.observacionesAuxAg(n);
					//debug("\nen procesar report data obs: "+obs);
					if(obs && obs != "") {
						n = n.previousSibling();					
						var aObs = obs.split("\n");

						//debug("aObs.length: "+aObs.length)
						for (var i = 0; i < aObs.length; i++) {

							if(i==0) {
								var nN = n.cloneNode();
								//debug("aObs[i]: "+aObs[i])
								nN.toElement().setAttribute("txtobservaciones", "Observaci�n:");
								nN.toElement().setAttribute("observaciones", aObs[i]);
								nN.toElement().setAttribute("level", "2");	

								//kD.insertBefore(nN, n);	
								kD.insertAfter(nN, n);

							} else {
								n = n.nextSibling();
								var nN = n.cloneNode();
								//debug("aObs[i]: "+aObs[i])
								nN.toElement().setAttribute("observaciones", aObs[i]);
								nN.toElement().setAttribute("level", "2");	
								//kD.insertBefore(nN, n);	
								kD.insertAfter(nN, n);
							}

						}	

					}*/
				}
			} 

			levelAnt = level;
			nUltimo = n;

		}		
		/*var obs = nUltimo.attributeValue("albaranescli.observaciones");
		if(obs != "") {
			var nN = nUltimo.cloneNode();
			var e = nN.toElement();
			//debug("			dentro del 0");						 
			kD.appendChild(nN);				
			var obs = nUltimo.attributeValue("albaranescli.observaciones");
			if(obs && obs != "") {
				e.setAttribute("level", "5");	
				var aObs = obs.split("\n");
				for (var i = 0; i < aObs.length; i++) {
					var nN = nUltimo.cloneNode();
					var e = nN.toElement();
					e.setAttribute("observaciones", aObs[i]);
					e.setAttribute("level", "5");		    
					kD.appendChild(nN);
				}	
			}
		}*/
		debug(x.toString(4));
		rptViewer.setReportData(xData);
		break;
	}

	case "em_i_ordenesestampacion": 
	case "em_i_ordenesestampacion_r": {
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();
		debug(x.toString(4));
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");
		
		var nN = kD.firstChild().cloneNode();
		var e = nN.toElement();
		
		e.setAttribute("level", "4");		    
		kD.appendChild(nN);		
		
		var obs = _i.observacionesOrdenEst(kD.firstChild(), "motivoespera");
		var aObs = obs.split("\n");
		for (var i = 0; i < aObs.length; i++) {
		    var nN = kD.firstChild().cloneNode();
		    var e = nN.toElement();
		    e.setAttribute("motivoespera", aObs[i]);
		    e.setAttribute("level", "5");		    
		    kD.appendChild(nN);
		}
		
		
		
		var obs = _i.observacionesOrdenEst(kD.firstChild(), "generales");
		var aObs = obs.split("\n");
		for (var i = 0; i < aObs.length; i++) {
		    var nN = kD.firstChild().cloneNode();
		    var e = nN.toElement();
		    e.setAttribute("observaciones", aObs[i]);
		    e.setAttribute("level", "6");		    
		    kD.appendChild(nN);
		}
		
		var obsEst = _i.observacionesOrdenEst(kD.firstChild(), "estampado");
		var aObsEst = obsEst.split("\n");		
		for (var k = 0; k < aObsEst.length; k++) {
			
		    var nN = kD.firstChild().cloneNode();
		    var e = nN.toElement();
		    e.setAttribute("observestampado", aObsEst[k]);
		    e.setAttribute("level", "7");		    
		    kD.appendChild(nN)
		}
		
		var obsAca = _i.observacionesOrdenEst(kD.firstChild(), "acabado");
		var aObsAca = obsAca.split("\n");		
		for (var k = 0; k < aObsAca.length; k++) {
			
		    var nN = kD.firstChild().cloneNode();
		    var e = nN.toElement();
		    e.setAttribute("observacabado", aObsAca[k]);
		    e.setAttribute("level", "8");		    
		    kD.appendChild(nN);
		}
		
		var obsRoll = _i.observacionesOrdenEst(kD.firstChild(), "rollado");
		var aObsRoll = obsRoll.split("\n");		
		for (var k = 0; k < aObsRoll.length; k++) {
			
		    var nN = kD.firstChild().cloneNode();
		    var e = nN.toElement();
		    e.setAttribute("observrollado", aObsRoll[k]);
		    e.setAttribute("level", "9");		    
		    kD.appendChild(nN);
		}
		debug(x.toString(4));
		rptViewer.setReportData(xData);
		break;
	}
	case "em_i_bobinasA3": {
		
		var xData = rptViewer.reportData().cloneNode();
		var x = xData.ownerDocument();
		debug(x.toString(4));
		var levelAnt = "0", level;
		var kD = xData.namedItem("KugarData");
		var bobinaSal = kD.firstChild().attributeValue("t1.codbobina");
		var listaBobinasEst = [];
		var listaBobinas = [];		
		listaBobinas.push(bobinaSal);		
		var qB = new AQSqlQuery;	
		qB.setSelect("distinct(codbobinaest)");
		qB.setFrom("em_tramostejido");
		qB.setWhere("codbobina = '" + bobinaSal + "' "); 			
		if (!qB.exec()){
			return;
		}  
		while(qB.next())
		{
					
			listaBobinasEst.push(qB.value("distinct(codbobinaest)"));
			listaBobinas.push(qB.value("distinct(codbobinaest)"));				
		}
		listaBobinasEst =  "'" + listaBobinasEst.join("', '") + "'"; 
		listaBobinas =  "'" + listaBobinas.join("', '") + "'"; 
		debug("listaBobinasEst: "+listaBobinasEst);
		debug("listaBobinas: "+listaBobinas);
		
		var q = new AQSqlQuery;	
		q.setSelect("em_incidenciasest.descripcion, em_incidenciasest.fechaini, em_incidenciasest.horaini, em_incidenciasest.fechafin, em_incidenciasest.horafin, em_incidenciasest.idtrabajador, em_incidenciasest.minutos, em_tiposinciest.descripcion, em_incidenciasest.codmecanico ");
		q.setFrom("em_incidenciasest LEFT OUTER JOIN em_tiposinciest ON em_incidenciasest.tipoinciest = em_tiposinciest.codigo");		
		q.setWhere("em_incidenciasest.codbobinasal in (" + listaBobinas + ")  order by em_incidenciasest.fechaini, em_incidenciasest.horaini, em_incidenciasest.fechafin, em_incidenciasest.horafin"); 			 debug("sql1: "+q.sql());
		if (!q.exec()){
			return;
		}  
		while(q.next())
		{
			var incidencia = q.value("em_incidenciasest.descripcion");
			var tipoIncidencia =  q.value("em_tiposinciest.descripcion");
			var fechaIni = AQUtil.dateAMDtoDMA(q.value("em_incidenciasest.fechaini").toString().left(10));
			var horaIni = q.value("em_incidenciasest.horaini").toString().right(8);
			var fechaFin = AQUtil.dateAMDtoDMA(q.value("em_incidenciasest.fechafin").toString().left(10));
			var horaFin = q.value("em_incidenciasest.horafin").toString().right(8);
			var idUsuario = q.value("em_incidenciasest.idtrabajador");
			var minutos = q.value("em_incidenciasest.minutos");
			var codMecanico = q.value("em_incidenciasest.codmecanico");
			if (minutos && minutos != "") {
				minutos = " "+minutos+" minutos";			
			} else {
				minutos = "";
			}
			var texto = "";
			if(incidencia != "" && tipoIncidencia != "") {
				texto = tipoIncidencia + " - " + incidencia;			
			} else if (incidencia != "") {
				texto = incidencia;			
			} else if (tipoIncidencia != "") {
				texto = tipoIncidencia;
			}			

			var nombreTrabajador = AQUtil.sqlSelect("pr_trabajadores", "nombre", "idtrabajador='" + idUsuario + "'");
			var nombreMecanico = "";
			if(codMecanico && codMecanico !="") {
				nombreMecanico  = AQUtil.sqlSelect("em_mecanicos", "nombre", "codmecanico='" + codMecanico + "'");
			}
			var descIncidencia = "FECHA: [" + fechaIni + " " + horaIni + " - " + fechaFin + " " + horaFin + "]"+ minutos + " Operario/a " + nombreTrabajador;
			if(nombreMecanico && nombreMecanico != "") {
				descIncidencia +=" Mec�nico: "+nombreMecanico;
			
			}
			descIncidencia += ": " +texto;

			var nN = kD.firstChild().cloneNode();
		 	var e = nN.toElement();
		 	e.setAttribute("incidencias", descIncidencia);
		  e.setAttribute("level", "3");		    
		 	kD.appendChild(nN);	
		}		
				
		debug(x.toString(4));
		rptViewer.setReportData(xData);
		
		xData = rptViewer.reportData().cloneNode();
		x = xData.ownerDocument();
		kD = xData.namedItem("KugarData");
		
		var qO = new AQSqlQuery;	
		qO.setSelect("SUM(cantotal),em_turnosusuario.codturno, em_turnosusuario.fecha, em_turnosusuario.horadesde, em_turnosusuario.horahasta,em_turnosusuario.codmaquinaest, pr_trabajadores.nombre");
		qO.setFrom("em_tramostejido INNER JOIN  em_turnosusuario ON em_tramostejido.idturnousuario = em_turnosusuario.id INNER JOIN pr_trabajadores ON em_turnosusuario.idtrabajador=pr_trabajadores.idtrabajador");		
		qO.setWhere("codbobina in (" + listaBobinasEst + ") group by em_turnosusuario.codturno, em_turnosusuario.fecha, em_turnosusuario.horadesde, em_turnosusuario.horahasta,em_turnosusuario.codmaquinaest, pr_trabajadores.nombre order by em_turnosusuario.fecha, em_turnosusuario.horadesde, em_turnosusuario.horahasta"); 			 			
		debug("sql2: "+qO.sql());
		if (!qO.exec()){
			return;
		}  
		while(qO.next())
		{
		 	var codTurno = qO.value("em_turnosusuario.codturno");
    		var fecha = qO.value("em_turnosusuario.fecha");
    		var horaDesde = qO.value("em_turnosusuario.horadesde");
    		var horaHasta = qO.value("em_turnosusuario.horahasta");
    		var codMaquinaEst = qO.value("em_turnosusuario.codmaquinaest");    		
    		var nombre = qO.value("pr_trabajadores.nombre");
     		horaDesde = horaDesde.toString().right(8);
     		horaHasta = horaHasta.toString().right(8);
     		fecha = AQUtil.dateAMDtoDMA(fecha.toString().left(10));      
    		var canTotal = qO.value("SUM(cantotal)");
    		valor = "OPERARIO/A: " + nombre + "     D�A: " + fecha + "     TURNO: " + codTurno + "     (" + horaDesde + " - " + horaHasta;
    		valor = valor + ")     M�QUINA: " + codMaquinaEst;    	
    		if(!canTotal  || canTotal =="") {
   			canTotal = 0;
   		}   
   		canTotal = AQUtil.roundFieldValue(canTotal, "em_tramostejido", "cantotal");
			valor +=  "     METROS ESTAMPADOS: " + canTotal;
			var nN = kD.firstChild().cloneNode();
		 	var e = nN.toElement();
		 	e.setAttribute("operariosest", valor);
		  	e.setAttribute("level", "4");		    
		 	kD.appendChild(nN);	
		}				
		
		debug(x.toString(4));		
		rptViewer.setReportData(xData);

		break;
	}	
	default: {
			return _i.__preprocesaReportData(nombreReport, rptViewer);
		}
	}
	return true;
}

function euromoda_dameNombreAseguradora(nodo, campo)
{
	var tabla = campo;
	var fecha = nodo.attributeValue(tabla + ".fecha").toString();
	fecha = new Date(Date.parse(fecha));
	
	var aseguradora = AQUtil.sqlSelect("em_periodosaseguradora", "nombreaseguradora", "fdesde <= '" + fecha + "' AND (fhasta >= '" + fecha + "' OR fhasta is null)");
	
	if(!aseguradora || aseguradora == "") {
		aseguradora = "Periodo no asegurado";
	}
	
	return "Operaci�n asegurada en "+ aseguradora;
}

function euromoda_dameNombreAseguradoraInt(nodo, campo)
{
	var tabla = campo;
	var fecha = nodo.attributeValue(tabla + ".fecha").toString();
	fecha = new Date(Date.parse(fecha));
	
	var aseguradora = AQUtil.sqlSelect("em_periodosaseguradora", "nombreaseguradora", "fdesde <= '" + fecha + "' AND (fhasta >= '" + fecha + "' OR fhasta is null)");
	
	if(!aseguradora || aseguradora == "") {
		aseguradora = "Periodo no asegurado";
	}
	
	return "Transaction guaranteed by "+ aseguradora;
}

function euromoda_referenciaDescripcionTallaColor(nodo, campo)
{
	var texto = "";
	var referencia = nodo.attributeValue("articulos.referencia");
	var descripcion = nodo.attributeValue("articulos.descripcion");
	var talla = nodo.attributeValue("articulos.codtamanoem");
	var color = nodo.attributeValue("articulos.codcolorem");
	
	texto = referencia + " " + descripcion + " " + talla + " " + color;
	
	return texto;
}

function euromoda_referenciaDescripcionTallaColorCompra(nodo, campo)
{
	var texto = "";
	var referencia = nodo.attributeValue("lin.referencia");
	var descripcion = nodo.attributeValue("lin.descripcion");
	var talla = nodo.attributeValue("lin.codtamanoem");
	var color = nodo.attributeValue("lin.codcolorem");
	
	descripcion = descripcion.toUpperCase();
	texto = referencia + " " + descripcion + " " + talla + " " + color;
	return texto;
}

function euromoda_albaranProforma(campo)
{
	var texto = "";
	switch (campo) {
		case "albaran": {
			if (formalbaranescli.iface.proforma_) {
				texto = "Factura Proforma";
			} else {
				texto = "Albar�n Venta";
			}
			break;
		}
		case "numero": {
			if (formalbaranescli.iface.proforma_) {
				texto = "N� Proforma";
			} else {			
				texto = "N� Albar�n";
			}
			break;
		}
		case "total": {
			if (formalbaranescli.iface.proforma_) {
				texto = "Total Proforma";
			} else {			
				texto = "Total Albar�n";
			}
			break;
		}
    case "DeliveryNote":
    {
      texto = "Delivery Note";
      break;
    }
    case "NumAlbaran":
    {
      texto = "Delivery Note No.";
      break;
    }

	}
	return texto;
}
function euromoda_descripcionArtCli(tabla,paisFactura, paisEmpresa, nodo)
{
	var _i = this.iface;
	var tam = tabla.length;
	var tablaCab = tabla.right(tam-6);
	var codCliente = nodo.attributeValue(tablaCab + ".codcliente");
	var referencia = nodo.attributeValue(tabla + ".referencia");
	var codClienteFra = AQUtil.sqlSelect("clientes", "codclientefac", "codcliente='" + codCliente + "'");	
	var valor = false;
	var id;
	var traduccion = false;
	if (!codClienteFra || codClienteFra == "") {
		codClienteFra = codCliente; 
	}
	if(codClienteFra && codClienteFra != "") {
		valor = AQUtil.sqlSelect("em_articuloscli", "descripcioncliente", "codcliente='" + codClienteFra + "' and referencia = '" + referencia + "'");
		var q = new AQSqlQuery;	
		q.setSelect("id, descripcioncliente");
		q.setFrom("em_articuloscli");
		q.setWhere("codcliente = '" + codClienteFra + "' and referencia = '" + referencia + "'"); 			
		if (!q.exec()){
			return;
		}  
		if(q.first())
		{
			valor = q.value("descripcioncliente");
			id = q.value("id");		
		}

	}
	if (valor ) {
		if (paisFactura && paisFactura != "" && paisFactura != paisEmpresa) {
			traduccion = _i.traduceArticuloCli(paisFactura, id);
		}
		if(traduccion && traduccion != "") {
			valor = traduccion;
		}
	}
	return valor;
	
}
function euromoda_traduceArticuloCli(codPais, id)
{
	var valor = undefined;
	var codIdioma = AQUtil.sqlSelect("paises", "codidioma", "codpais = '" + codPais + "'");	
	if (codIdioma && codIdioma != "") {
		valor = AQUtil.sqlSelect("traducciones", "traduccion", "idcampo = '" + id + "' AND campo = 'descripcioncliente' AND tabla = 'em_articuloscli' AND codidioma = '" + codIdioma + "'");
	}
	return valor;
}
function euromoda_tipoAlbaranDep(nodo, campo)
{
	var texto = "";
	if (!formalbaranescli.iface.proforma_) {	
		var	idAlbaran = nodo.attributeValue(campo);
		var tipoAlbaran = AQUtil.sqlSelect("albaranescli", "tipodeposito", "idalbaran=" + idAlbaran);
		if(tipoAlbaran && tipoAlbaran != "Venta") {		
			texto = "Tipo: "+tipoAlbaran;
		}
	}
	
	return texto;
}
function euromoda_observacionesOrdenEst(nodo, tipo)
{	
	var _i = this.iface;	
	var observaciones = "";
	switch (tipo) {
		case "motivoespera": {
			observaciones = nodo.attributeValue("em_ordenesestampacion.motivoespera");
			break;		
		}
		case "generales": {
			observaciones = nodo.attributeValue("em_ordenesestampacion.observaciones");
			break;
		}
		case "estampado": {
			observaciones = nodo.attributeValue("em_ordenesestampacion.observestampado");
			break;		
		}  
		case "acabado": {
			observaciones = nodo.attributeValue("em_ordenesestampacion.observacabado");
			break;		
		}
		case "rollado": {
			observaciones = nodo.attributeValue("em_ordenesestampacion.observrollado");
			break;		
		}	
	}
	return observaciones;
}

function euromoda_turnoUsuario(nodo, campo)
{
	var _i = this.iface;
	var valor="";
	var idTurnoUsuario = nodo.attributeValue("t1.idturnousuario"); 
	var codBobina = nodo.attributeValue("t1.codbobina"); 
	var q = new AQSqlQuery;	
	q.setSelect("SUM(cantotal),em_turnosusuario.codturno, em_turnosusuario.fecha, em_turnosusuario.horadesde, em_turnosusuario.horahasta,em_turnosusuario.codmaquinaest, em_turnosusuario.codmaquinaroll, pr_trabajadores.nombre");
	q.setFrom("em_turnosusuario INNER JOIN pr_trabajadores ON em_turnosusuario.idtrabajador=pr_trabajadores.idtrabajador INNER JOIN em_tramostejido ON em_turnosusuario.id = em_tramostejido.idturnousuario");
	q.setWhere("em_tramostejido.codbobina = '" + codBobina + "' and em_turnosusuario.id = " + idTurnoUsuario + " GROUP BY em_turnosusuario.codturno, em_turnosusuario.fecha, em_turnosusuario.horadesde, em_turnosusuario.horahasta,em_turnosusuario.codmaquinaest, em_turnosusuario.codmaquinaroll, pr_trabajadores.nombre"); 	

	if (!q.exec()){
		return "";
	}  
	if(!q.first())
	{
		return "";
	}	
	var codTurno = q.value("em_turnosusuario.codturno");
	var fecha = q.value("em_turnosusuario.fecha");
	var horaDesde = q.value("em_turnosusuario.horadesde");
	var horaHasta = q.value("em_turnosusuario.horahasta");
	var codMaquinaEst = q.value("em_turnosusuario.codmaquinaest");
	var codMaquinaRoll = q.value("em_turnosusuario.codmaquinaroll");
	var nombre = q.value("pr_trabajadores.nombre");
	var canTotal = q.value("SUM(cantotal)");
	horaDesde = horaDesde.toString().right(8);
	horaHasta = horaHasta.toString().right(8);
	fecha = AQUtil.dateAMDtoDMA(fecha.toString().left(10));   


	valor = "OPERARIO/A: " + nombre + "     D�A: " + fecha + "     TURNO: " + codTurno + "     (" + horaDesde + " - " + horaHasta;

	switch (campo) {
		case "estampacion": {
			valor = valor + ")     M�QUINA: " + codMaquinaEst;
			break;
		}
		case "rollado" : {
			valor = valor + ")     M�QUINA: " + codMaquinaRoll;
			break;
		}
	}

	if(!canTotal  || canTotal =="") {
		canTotal = 0;
	}

	canTotal = AQUtil.roundFieldValue(canTotal, "em_tramostejido", "cantotal");
	valor +=  "     METROS ESTAMPADOS: " + canTotal;
	
	return valor;
}


function euromoda_metrosVaporizado(nodo, campo)
{
	var soporteVaporizado = nodo.attributeValue("em_bobinas.soportedestvap");
	if (soporteVaporizado && soporteVaporizado !="") {
		return nodo.attributeValue("em_bobinas.cantotal");
	} else {
		return 0;
	}
}

function euromoda_soporteEst(nodo, campo)
{
	var soporteVaporizadoOri = nodo.attributeValue("em_bobinas.soporteorivap");
	
	return soporteVaporizadoOri;

}

function euromoda_incidenciasEst(nodo, campo)
{
	return nodo.attributeValue("em_incidenciasest.descripcion");

}
function euromoda_acabadosObservAlbProv(nodo,campo)
{
	return nodo.attributeValue("em_acabadosalbprov.observacion");
}

function euromoda_totalPartida(nodo, campo)
{
    var _i = this.iface;
    var resultado = "";
    if(campo == "em_tramostejido.cantotal")  {
    	resultado = "de " + AQUtil.formatoMiles(AQUtil.roundFieldValue(nodo.attributeValue("em_tramostejido.cantotal"), "em_tramostejido", "cantotal")) + " mtrs. de partida";
    } else {
    	resultado = AQUtil.formatoMiles(AQUtil.roundFieldValue(nodo.attributeValue("em_tramostejido.candisponible"), "em_tramostejido", "candisponible")) + " mtrs.";
    
    }
	return resultado;

}

function euromoda_bobinaEstampacion(nodo, campo)
{
	var _i = this.iface;
	var resultado = "BOBINA EST.";
	var bobinas = "";
	var codBobina = nodo.attributeValue(campo);
	var q = new AQSqlQuery;	
	q.setSelect("distinct(codbobinaest)");
	q.setFrom("em_tramostejido");
	q.setWhere("codbobina = '" + codBobina + "' "); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		bobinas += bobinas == "" ? "" : ", ";
		bobinas += q.value("distinct(codbobinaest)");
		
	}
	if(bobinas && bobinas == codBobina) {
		resultado = "";
	} else if(bobinas && bobinas != "") {
		resultado+=": "+bobinas;
	} else {	
		resultado = "";
	}
	return resultado;

}


function euromoda_bobinaInforme(nodo, campo)
{
	var _i = this.iface;
	var resultado = "BOBINA ";	
	var codBobina = nodo.attributeValue(campo);
	var estado = nodo.attributeValue("em_bobinas.estado");
	var q = new AQSqlQuery;	
	resultado += codBobina + " ("+estado+") ";
	var bobinas = "";
	var q = new AQSqlQuery;	
	q.setSelect("distinct(codbobinaest)");
	q.setFrom("em_tramostejido");
	q.setWhere("codbobina = '" + codBobina + "' "); 			
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		bobinas += bobinas == "" ? "" : ", ";
		bobinas += q.value("distinct(codbobinaest)");
		
	}
	if(bobinas && bobinas != "" && bobinas != codBobina) {
		resultado+=" BOBINA EST.: "+bobinas;
	} 
	return resultado;

}



function euromoda_metrosRolladoLin(nodo, campo)
{
	var codBobinaRoll = nodo.attributeValue("t1.codbobinaroll");
	if(codBobinaRoll && codBobinaRoll != "") {
		return nodo.attributeValue("t1.canusada");
	} else {
		return 0;
	}
}

function euromoda_totalEstampado(campo)
{

	
	var totalEstampado = formem_ordenesestampacion.iface.pub_dameTotalEstampado();	
	if(totalEstampado && totalEstampado != "") {
		valor = "TOTAL ESTAMPADO";
	} else {
		valor = "";
	}
	return valor;
}

function euromoda_partidaRefPPE(nodo, campo)
{
	var valor = "";
	var codPartidaPPE  = nodo.attributeValue("t.codpartidappe");
	var refPPE = nodo.attributeValue("lot2.referencia");	
	if(codPartidaPPE && codPartidaPPE != "") {
		valor = codPartidaPPE+" - ("+refPPE+")";
	}	
	return valor;

}

function euromoda_dimePedidoProvAlb(nodo, campo)
{
	var _i = this.iface;
	var i = 0;
	var idAlbaran = nodo.attributeValue("albaranesprov.idalbaran");
	var valor = AQUtil.sqlSelect("lineasalbaranesprov inner join pedidosprov on lineasalbaranesprov.idpedido = pedidosprov.idpedido","pedidosprov.codigo","lineasalbaranesprov.idalbaran = " + idAlbaran+ " and pedidosprov.acabados","lineasalbaranesprov");
	if(!valor) {
		valor = "";
	}
	if(campo == "labelPedido" && valor != "") {
		valor = "Pedido";
	}
	return valor;

}

function euromoda_em_dameBarcodeInterleaved(nodo, campo)
{
	var _i = this.iface;
	var valor = nodo.attributeValue(campo);
	
	//debug("valor campo "+nodo.attributeValue(campo));
	if(nodo.attributeValue("clientes.em_tipocodbartrack") == "codei25") {
		//debug("es codei25, nos quedamos con los 17");
		valor = nodo.attributeValue(campo).left(17);

	}
	//debug("valor final: "+valor);
	return valor;

}

function euromoda_impTelefonoAlbaranTrans(nodo,campo)
{
    var telfDirCliente = nodo.attributeValue("dirclientes.telefono");
    var telfCliente = nodo.attributeValue("clientes.telefono1");
    
    var valor; 
    if (!telfDirCliente || telfDirCliente == "" || telfDirCliente == 0)
    {
      valor = telfCliente;
    }
    else
    {
      valor = telfDirCliente;
    }
    return valor;
    

}

function euromoda_totalTrackingEnvios(nodo,campo)
{
    var codEnvio = nodo.attributeValue("em_enviodropshipping.emcodenviodrop");
    
    var valor; 
    if (!codEnvio || codEnvio == "" || codEnvio == 0)
    {
      return false;
    }
    else
    {
      valor = AQUtil.sqlSelect("albaranescli a INNER JOIN lineasalbaranescli l ON a.idalbaran = l.idalbaran INNER JOIN em_cargadropshipping c ON l.idpedido = c.idpedido", "count(DISTINCT c.tracking)", "a.emcodenviodrop = '" + codEnvio + "'", "albaranescli,lineasalbaranescli,em_cargadropshipping");
    }
    return valor;
    

}

function euromoda_descripcionLPP(nodo,campo)
{
	var _i = this.iface;
	var valor = "";
	var descripcion = nodo.attributeValue("lineaspedidosprov.descripcion");
	var tama = nodo.attributeValue("em_tamanos.descripcion");
	var color = nodo.attributeValue("em_colores.descripcion");
	valor = descripcion + " " + tama + " " + color;


	return valor;
}

function euromoda_dameNumEnvioDrop(nodo, campo)
{
	var codigo =  nodo.attributeValue("em_dropshipping.codigo");
	var numEnvio =  nodo.attributeValue("em_enviodropshipping.emcodenviodrop");

	return "Hoja de Env�o N�: " + codigo + " / " + numEnvio;

}

function euromoda_etiquetaAcolchado(nodo, campo)
{
	//cogemos el articulo y sacamos su familia
	//vamos a familia y cogemos su etiqueta
	//vamos a em_acabadosart y cogemos todos sus acabados
	var referencia =  nodo.attributeValue("lotesstock.referencia");
	var etiqueta = "";
	var acabado = "";
	//sys.warnMsgBox(sys.translate("La referencia: %1").arg(referencia));
	//1. hacemos select a tabla articulos para coger familia
	var codFamilia=AQUtil.sqlSelect("articulos","codfamilia", "referencia = '" + referencia + "'");	

	/*-----------------------------------------------------------------------*/

	var texto="";
	if(codFamilia){
		//2. Vamos a tabla em_acabadosfam y sacamos sus etiquetas
		var q = new FLSqlQuery;
		q.setSelect("etiqueta");
		q.setFrom("em_acabadosfam");
		q.setWhere("codfamilia = '" + codFamilia + "'");	
		if (!q.exec()) {
			return false;
		}	
		while (q.next()) {
			if(etiqueta == "") {
				etiqueta = q.value("etiqueta");
			} else {
				etiqueta = etiqueta + "," + q.value("etiqueta");
			}

		}
		if(etiqueta){
			texto=etiqueta;
		}


		//3. vamos a tabla em_acabadosart y sacamos sus acabados
		var q2 = new FLSqlQuery;
		q2.setSelect("acabado");
		q2.setFrom("em_acabadosart");
		q2.setWhere("referencia = '" + referencia + "'");	
		if (!q2.exec()) {
			return false;
		}	
		while (q2.next()) {
			if(acabado == "") {
				acabado = q2.value("acabado");
			} else {
				acabado = acabado + "," + q2.value("acabado");
			}

		}
		if(acabado){
			texto=texto + " : " + acabado;
		}

		

	}

	return texto;
	

}

function euromoda_lanzaInforme(cursor, oParams)
{
	var _i = this.iface;
	return _i.__lanzaInforme(cursor, oParams);
  var nombreInforme = oParams.nombreInforme;
  var orderBy = oParams.orderBy;
  var groupBy = oParams.groupBy;
  var etiquetas = oParams.etiquetas;
  var impDirecta = oParams.impDirecta;
  var whereFijo = oParams.whereFijo;
  var nombreReport = oParams.nombreReport;

  debug("nombreReport= "+nombreReport);

  if(nombreReport != "em_i_etidropshippingPie") {
  	return _i.__lanzaInforme(cursor, oParams);
  }

  var numBarcodes = oParams.numBarcodes;
  var numCopias = oParams.numCopias;
  var datosPdf = oParams.datosPdf;
  var limit = oParams.limit;

  var _i = this.iface;
  var etiquetaInicial = [];
  if (etiquetas == true) {
    etiquetaInicial = _i.seleccionEtiquetaInicial();
    if (!etiquetaInicial) {
      sys.warnMsgBox(sys.translate("La impresi�n ha sido cancelada por el usuario."));
      return false;
    }
  } else {
    etiquetaInicial["fila"] = 0;
    etiquetaInicial["col"] = 0;
  }

  _i.ultIdDocPagina = "";
  var q = _i.estableceConsulta(cursor, oParams);
  debug("------ CONSULTA ------- " + q.sql());
  if (!q.exec()) {
    sys.errorMsgBox(sys.translate("Fall� la consulta"));
    return false;
  } else {
    if (!q.first()) {
      sys.warnMsgBox(sys.translate("No hay registros que cumplan los criterios de b�squeda establecidos"));
      return false;
    }
  }

  var tipoReport = "";
  if (!nombreReport || nombreReport == "") {
    nombreReport = nombreInforme;
  }

  var pos = nombreReport.findRev(".");
  var extension = "";
  if (pos && pos != 0) {
    extension = nombreReport.right(nombreReport.length - pos - 1);
    nombreReport = nombreReport.left(pos);
    oParams.nombreReport = nombreReport;
  }
  if (oParams.codIdioma != undefined) {
    sys.setMultiLang(true, oParams.codIdioma);
  }

  if (extension == "jxml" || extension == "jrxml") {
    _i.ejecutarInformeJasper(q, oParams, etiquetaInicial);
  } else {
    var rptViewer = oParams.rptViewer ? oParams.rptViewer : new FLReportViewer();
    var flags = (oParams.display ? rptViewer.Display : 0) | (oParams.append ? rptViewer.Append : 0) | (oParams.pageBreak ? rptViewer.PageBreak : 0);
    rptViewer.setReportData(q);
    if (!_i.preprocesaReportData(nombreReport, rptViewer)) {
      return false;
    }
    rptViewer.setReportTemplate(nombreReport);


    /// CAMBIO
	var x = new FLDomDocument;
	rT = rptViewer.reportTemplate();
	x.appendChild(rT);
	//debug("template = " + x.toString());
	var fields = x.elementsByTagName("CalculatedField");
	for (var n = 0; n < fields.length(); n++) {
		var e = fields.item(n).toElement();
		if (e.attribute("DataType") == "6") {
			var campo = e.attribute("Field");
			if(numBarcodes == 1 && (campo == "barcode2" || campo == "barcode3" || campo == "barcode4" || campo == "barcode5")) {
				e.setAttribute("DataType", "0");
			} else if(numBarcodes == 2 && (campo == "barcode3" || campo == "barcode4" || campo == "barcode5")) {
				e.setAttribute("DataType", "0");
			} else if(numBarcodes == 3 && (campo == "barcode4" || campo == "barcode5")) {
				e.setAttribute("DataType", "0");
			}else if(numBarcodes == 4 && (campo == "barcode5")) {
				e.setAttribute("DataType", "0");
			}			
		}
	}
	//debug("\n\ntemplate = " + x.toString());
	rptViewer.setReportTemplate(rT);

    /// FIN CAMBIO




    rptViewer.renderReport(etiquetaInicial.fila, etiquetaInicial.col, flags);
    if (!oParams.display) {
      return true;
    }
    if (oParams.colorMode) {
      if (oParams.colorMode == AQS.PrintGrayScale) {
        rptViewer.setColorMode(rpt.PrintGrayScale);
      } else if (oParams.colorMode == AQS.PrintColor) {
        rptViewer.setColorMode(rpt.PrintColor);
      }
    }
    if (oParams.printerName) {
      rptViewer.setPrinterName(oParams.printerName);
    }
    if (datosPdf && datosPdf.pdf == true) {
      rptViewer.printReportToPDF(datosPdf.ruta);
    } else {
      if (numCopias)
        rptViewer.setNumCopies(numCopias);
      if (impDirecta)
        rptViewer.printReport();
      else
        rptViewer.exec();
    }
  }
  if (oParams.codIdioma != undefined) {
    sys.setMultiLang(false);
  }
  return true;
}

function euromoda_datoPieProv(nodo, campo)
{
	var idPedido = nodo.attributeValue("pedidosprov.idpedido");
	var valor = 0;
	valor = AQUtil.sqlSelect("lineaspedidosprov","SUM(cantidad)","idpedido = " + idPedido);
	if(!valor || valor == "") {
		valor = 0;
	}
	return valor;
}

function euromoda_dameLabelRectificativaAbono(nodo, campo)
{
	var _i = this.iface;
	var ret = "";
	var idFactura = nodo.attributeValue(campo);
	var paisEmpresa = flfactppal.iface.pub_valorDefectoEmpresa("codpais");
	var paisFactura = AQUtil.sqlSelect("facturascli", "codpais", "idfactura = '" + idFactura + "'");
	var rectificativa = AQUtil.sqlSelect("facturascli", "deabono", "idfactura = " + idFactura);
	var abono = AQUtil.sqlSelect("facturascli", "em_deabono", "idfactura = " + idFactura);
	if (rectificativa) {
		if(paisFactura && paisFactura != "" && paisFactura != paisEmpresa){
			ret = "RECTIFYING Invoice No"
		}else{
			ret = "RECTIFICATIVA";
		}						
	}else if(abono){
		if(paisFactura && paisFactura != "" && paisFactura != paisEmpresa){
			ret = "CREDIT Note No"
		}else{
			ret = "ABONO";
		}					
	}else if(paisFactura && paisFactura != "" && paisFactura != paisEmpresa){
		ret = "Invoice No"
	}
	return ret;	
}

function euromoda_facturaRectificada(nodo, campo)
{
	var _i = this.iface;
	var ret = "";
	var idFacturaRect= nodo.attributeValue("facturascli.idfacturarect");
	if(idFacturaRect && idFacturaRect != ""){
		var fecha = AQUtil.sqlSelect("facturascli", "fecha", "idfactura = " + idFacturaRect);
		fecha = AQUtil.dateAMDtoDMA(fecha);
		fecha = flfactppal.iface.replace(fecha, "-", "/");
		var coFacturaRect= nodo.attributeValue("facturascli.codigorect")
		if (coFacturaRect){
			ret = sys.translate("%1 del %2").arg(coFacturaRect).arg(fecha);			
		}
	}
	
	return ret;
}

function euromoda_labelRectificaA(nodo, campo)
{
	var _i = this.iface;
	var ret = "";
	var idFactura = nodo.attributeValue("facturascli.idfactura");
	var rectificativa = AQUtil.sqlSelect("facturascli", "deabono", "idfactura = " + idFactura);	
	if(rectificativa){
		if(campo == "etiqueta") {
			ret = "RECTIFICA A:";		
		} else if(campo == "subrayado") {
			ret = "____________"
		}
		
	}	
	return ret;
}

function euromoda_preprocesaReportTemplate(cursor, oParams, rptViewer)
{
	
	var _i  = this.iface;

	var nombreInforme = oParams.nombreInforme;
	var nombreReport = oParams.nombreReport;
	
	if(nombreReport == "em_i_etidropshippingPie" || nombreReport == "em_i_etidropshippingPieIT") {

		var codCliente = oParams.codCliente;
		//var codBarType = AQUtil.sqlSelect("clientes","em_tipocodbartrack","codcliente = '" + codCliente + "'");
		var codBarType = "";
		var tipoEtiqueta = "";
		var codEtiquetaCab = "";
		var q = new AQSqlQuery;	
		q.setSelect("em_tipocodbartrack, em_tipoetiquetadrop, em_codeticabdrop");
		q.setFrom("clientes");
		q.setWhere("codcliente = '" + codCliente + "'"); 					
		if (!q.exec()){
			return;
		}  
		if(q.first())
		{
			codBarType = q.value("em_tipocodbartrack");
			tipoEtiqueta = q.value("em_tipoetiquetadrop");
			codEtiquetaCab = q.value("em_codeticabdrop");
				
		}	
		/*debug("******************************************************************");
		debug("codBarType: "+codBarType);
		debug("tipoEtiqueta: "+tipoEtiqueta);
		debug("codEtiquetaCab: "+codEtiquetaCab);
		debug("******************************************************************");*/
		var numBarcodes = oParams.numBarcodes;
		var x = new FLDomDocument;
		rT = rptViewer.reportTemplate();
		x.appendChild(rT);
		//debug("template = " + x.toString());
		var fields = x.elementsByTagName("CalculatedField");
		for (var n = 0; n < fields.length(); n++) {
			var e = fields.item(n).toElement();
			if (e.attribute("DataType") == "6") {
				var campo = e.attribute("Field");
				//debug("\n\n---------------------------campo: "+campo)
				if(numBarcodes == 1 && (campo == "barcode2" || campo == "barcode3" || campo == "barcode4" || campo == "barcode5")) {
					e.setAttribute("DataType", "0");
				} else if(numBarcodes == 2 && (campo == "barcode3" || campo == "barcode4" || campo == "barcode5")) {
					e.setAttribute("DataType", "0");
				} else if(numBarcodes == 3 && (campo == "barcode4" || campo == "barcode5")) {
					e.setAttribute("DataType", "0");
				}else if(numBarcodes == 4 && (campo == "barcode5")) {
					e.setAttribute("DataType", "0");					
				} else if(campo == "em_cargadropshipping.tracking") {					
					e.setAttribute("CodBarType", codBarType);
					if(codBarType == "codei25") {
						e.setAttribute("CodBarRes", "100");	
					} else if(codBarType == "Code128") {
						e.setAttribute("CodBarRes", "72");
					}					
				}  else if(campo == "pedidoscli.codigo") {					
					e.setAttribute("CodBarType", "Code128");					
					e.setAttribute("CodBarRes", "144");										
				} else if(campo == "cdbcab") {
					if(nombreReport == "em_i_etidropshippingPieIT") {						
						if(codEtiquetaCab == "Pedido dropshipping") {
							e.setAttribute("Field", "em_cargadropshipping.pedidoprivalia");
							e.setAttribute("CodBarType", "Code128");					
							e.setAttribute("CodBarRes", "144");
						} else if(codEtiquetaCab == "Pedido AbanQ") {	
							e.setAttribute("Field", "pedidoscli.codigo");
							e.setAttribute("CodBarType", "Code128");					
							e.setAttribute("CodBarRes", "144");
						}else if(codEtiquetaCab == "Traking number") {
							e.setAttribute("Field", "em_cargadropshipping.tracking");
							e.setAttribute("CodBarType", codBarType);
							if(codBarType == "codei25") {
								e.setAttribute("CodBarRes", "100");	
							} else if(codBarType == "Code128") {
								e.setAttribute("CodBarRes", "72");
							}
						}		
					} else {
						if(codEtiquetaCab == "Pedido dropshipping") {
							e.setAttribute("Field", "em_cargadropshipping.pedidoprivalia");
							e.setAttribute("CodBarType", "Code128");					
							e.setAttribute("CodBarRes", "108");
						} else if(codEtiquetaCab == "Pedido AbanQ") {	
							e.setAttribute("Field", "pedidoscli.codigo");
							e.setAttribute("CodBarType", "Code128");					
							e.setAttribute("CodBarRes", "108");
						}else if(codEtiquetaCab == "Traking number") {
							e.setAttribute("Field", "em_cargadropshipping.tracking");
							e.setAttribute("CodBarType", codBarType);
							if(codBarType == "codei25") {
								e.setAttribute("CodBarRes", "100");	
							} else if(codBarType == "Code128") {
								e.setAttribute("CodBarRes", "72");
							}
						}	

					}
				} else if(campo == "cdbpie") {
					if(nombreReport == "em_i_etidropshippingPieIT") {
						if(codEtiquetaCab == "Pedido dropshipping") {
							e.setAttribute("Field", "em_cargadropshipping.pedidoprivalia");
							e.setAttribute("CodBarType", "Code128");					
							e.setAttribute("CodBarRes", "72");
						} else if(codEtiquetaCab == "Pedido AbanQ") {	
							e.setAttribute("Field", "pedidoscli.codigo");
							e.setAttribute("CodBarType", "Code128");					
							e.setAttribute("CodBarRes", "72");
						}else if(codEtiquetaCab == "Traking number") {
							e.setAttribute("Field", "em_cargadropshipping.tracking");
							e.setAttribute("CodBarType", codBarType);
							if(codBarType == "codei25") {
								e.setAttribute("CodBarRes", "100");	
							} else if(codBarType == "Code128") {
								e.setAttribute("CodBarRes", "72");
							}
						}		
					}
				}
			}
		}
		//debug("\n\ntemplate = " + x.toString());
		rptViewer.setReportTemplate(rT);
	} else {
		return _i.__preprocesaReportTemplate(cursor, oParams, rptViewer);
	}
	return true;	
}

function euromoda_concatenaCodSerieDiseno(descripcion, codseriediseno)
{
	var d = descripcion;
	if (codseriediseno && codseriediseno != ""){
		d += " - [" + codseriediseno + "]"
	}
	return d;
}

function euromoda_datosInventario(nodo, campo)
{
	var _i = this.iface;
	var ret = "";
	if(campo == "idusuarioalta" || campo == "idusuariomod") {
		var idUsuario = nodo.attributeValue(campo);
		if(idUsuario == "" || !idUsuario){
			ret = "";
		}else{
			ret = "("+idUsuario+")";
		}
	} else if(campo == "horaalta" || campo == "horamod" || campo == "horamodlin") {
		var hora = nodo.attributeValue(campo);
		if(hora == "00:00:00" || !hora){
			ret = "";
		}else{
			ret = hora;
		}
	} else if(campo == "fechainforme") {
		var fecha = new Date();
		ret = fecha.toString().right(8);
	} else if(campo == "idusuarioimpre") {
		ret = "("+sys.nameUser()+")";
	} else if(campo == "descripcion") {
		var descrip = nodo.attributeValue("desarticulo");
		var tamanio = nodo.attributeValue("codtamanoem");
		var color = nodo.attributeValue("codcolorem");
		var serie = nodo.attributeValue("codseriediseno");
		if(descrip != "" || descrip) {
			ret = descrip + " ";
		}
		if(tamanio != "" || tamanio) {
			ret += tamanio + " ";
		}
		if(color != "" || color) {
			ret += color + " ";
		}
		if(serie != "" || serie) {
			ret += "- ["+serie+"]";
		}
	} else if(campo == "almacen") {
		var codAlmacen = nodo.attributeValue("codalmacen");
		var nombreAlmacen = nodo.attributeValue("nombre");
		if(codAlmacen != "" || codAlmacen) {
			ret = codAlmacen + " ";
		}
		if(nombreAlmacen != "" || nombreAlmacen) {
			ret += "- "+ nombreAlmacen + " ";
		}
	}	
	return ret;
}

function euromoda_codPedidoCb(nodo, campo)
{
	var codPedido = nodo.attributeValue("pedidoscli.codigo");
	var label = "";
	if(campo == "codigo") {
		label = codPedido;	
	} else {
		label = "PEDIDO          "+codPedido;
		
	}
	return label;
}

function euromoda_precioLineaCompra(nodo, campo)
{

	var precio = nodo.attributeValue("lineaspedidosprov.pvpunitario");
	debug("precio: "+precio)
	if(precio < 1) {
		debug("precio 1: "+precio);
		return AQUtil.formatoMiles(precio);
	} else {
		debug("precio 2: "+precio);
		return AQUtil.formatoMiles(AQUtil.roundFieldValue(precio, "articuloscomp", "cantidad")); // 4 decimales
	}
}

function euromoda_concatenaUbiAlterna(descripcion, referencia)
{
	var descripcionCompleta = descripcion;

	var ubiAlterativas = AQUtil.sqlSelect("em_articulosxubicacion INNER JOIN articulos ON em_articulosxubicacion.referencia = articulos.referencia AND em_articulosxubicacion.em_ubialternativa <> articulos.em_ubiactual","array_to_string(array_agg('' || em_ubialternativa || ''),',')","em_articulosxubicacion.referencia = '" + referencia + "'","em_articulosxubicacion");

	if(ubiAlterativas && ubiAlterativas != "") {
		var aUbicaciones = ubiAlterativas.split(",");
		var sUbicaciones = aUbicaciones.join(", ");
		descripcionCompleta = descripcion + "\n" + "Ubic. Altern: " + sUbicaciones;
 
	}

	return descripcionCompleta;
}

function euromoda_labelDecripcion(nodo, campo)
{	
	var _i = this.iface;
	var label = "";
	var codCliente = nodo.attributeValue("facturascli.codcliente");
	debug("codCliente: "+codCliente);
	if(AQUtil.sqlSelect("clientes","em_eanenfactura","codcliente = '" + codCliente +"'")) {
		if(campo == "ES") {
			label = "EAN - CONCEPTO";	
		} else {
			label = "EAN No. - DESCRIPTION";
		}
		
	} else {
		if(campo == "ES") {
			label = "CONCEPTO";
		} else {
			label = "DESCRIPTION";
		}
	}
 
  	return label;
}

function euromoda_selloPyme(nodo, campo)
{
	var _i = this.iface;
	if (_i.membrete_) {
  		return flfactppal.iface.pub_valorDefectoEmpresa("em_sellopyme");
	}
	return "";
}

function euromoda_selloPymeInt(nodo, campo)
{
	var _i = this.iface;
  	if (_i.membrete_) {
  		return flfactppal.iface.pub_valorDefectoEmpresa("em_sellopyme_int");
	}
	return "";

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
