
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends oficial {
	function euromoda( context ) { oficial ( context ); }
	function bufferChanged(fN) {
		return this.ctx.euromoda_bufferChanged(fN);
	}
	function calculateField(fN) {
		return this.ctx.euromoda_calculateField(fN);
	}
	function pushButtonAccept_clicked() {
		return this.ctx.euromoda_pushButtonAccept_clicked();
	}
	function pushButtonAcceptContinue_clicked() {
		return this.ctx.euromoda_pushButtonAcceptContinue_clicked();
	}
	
	function init() {
		return this.ctx.euromoda_init();
	}
	function controlDevolucion() {
		return this.ctx.euromoda_controlDevolucion();
	}
// 	function validateForm() {
// 		return this.ctx.euromoda_validateForm();
// 	}
// 	function informaConcepto() {
// 		return this.ctx.euromoda_informaConcepto();
// 	}
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
	debug("\n\neuromoda_init");
	var _i = this.iface;
	_i.__init();
	if(this.child("pushButtonAccept")) {
	disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
		connect(this.child("pushButtonAccept"), "clicked()", _i, "pushButtonAccept_clicked");
	}
	if(this.child("pushButtonAcceptContinue")) {
	disconnect(this.child("pushButtonAcceptContinue"), "clicked()", this.obj(), "acceptContinue()");
	connect(this.child("pushButtonAcceptContinue"), "clicked()", _i, "pushButtonAcceptContinue_clicked");
	}


}

function euromoda_bufferChanged(fN)
{
debug("euromoda_bufferChanged " + fN);
	var _i = this.iface;
	switch(fN) {
		case "codlote": {
			sys.setObjText(this, "fdbCantidad", _i.calculateField("disponible_lote"));
			sys.setObjText(this, "fdbIdStock", _i.calculateField("idstock_lote"));
			_i.__bufferChanged(fN);
			break;;
		}
		default: {
			_i.__bufferChanged(fN);
		}
	}
}

function euromoda_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch(fN) {
		case "disponible_lote": {
			valor = AQUtil.sqlSelect("lotesstock", "candisponible", "codlote = '" + cursor.valueBuffer("codlote") + "'");
			valor = isNaN(valor) ? 0 : valor;
			break;;
		}
		case "idstock_lote": {
			var codAlmacen = AQUtil.sqlSelect("lotesstock", "codalmacen", "codlote = '" + cursor.valueBuffer("codlote") + "'");
			valor = AQUtil.sqlSelect("stocks", "idstock", "codalmacen = '" + codAlmacen + "' AND referencia = '" + cursor.valueBuffer("referencia") + "'");
			valor = isNaN(valor) ? 0 : valor;
			break;;
		}
		default: {
			valor = _i.__calculateField(fN);
		}
	}
	return valor;
}
function euromoda_pushButtonAccept_clicked()
{
	var _i = this.iface;
	debug("\n\neuromoda_pushButtonAccept");
	_i.controlDevolucion();	
	this.obj().accept();
}

function euromoda_pushButtonAcceptContinue_clicked()
{
	var _i = this.iface;
	debug("\n\neuromoda_pushButtonAcceptContinue");
	_i.controlDevolucion();	
	this.obj().acceptContinue();
}

function euromoda_controlDevolucion()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var codLote = cursor.valueBuffer("codLote");
	
	var oDatosLote = flfactppal.iface.pub_ejecutarQry("lotesstock","candisponible,referencia,codalmacen,ubicacion","codlote= '" + codLote + "' ","lotesstock");
	if(oDatosLote.result != 1) {
		return false;
	}
	var canDisponible = oDatosLote.candisponible;
	var codAlmacenLote = oDatosLote.codalmacen;
	var referencia = oDatosLote.referencia;
	var ubicacion = oDatosLote.ubicacion;		
	var cantidad = cursor.valueBuffer("cantidad");	
	var idLineaAC = cursor.valueBuffer("idlineaac");
	var curAlbaran = cursor.cursorRelation().cursorRelation();
	var codAlmacenAlb = curAlbaran.valueBuffer("codalmacen");
	debug("codLote: "+codLote);
	debug("canDisponible: "+canDisponible);
	debug("cantidad: "+cantidad);
	debug("codAlmacenLote: "+codAlmacenLote);
	debug("idLineaAC: "+idLineaAC);	
	debug("codAlmacenAlb: "+codAlmacenAlb);	
	
	if(canDisponible == 0 && cantidad < 0 && codAlmacenLote != codAlmacenAlb) {
		debug("cambio de almacen");
		if (!AQUtil.execSql("UPDATE lotesstock SET codalmacen = '" + codAlmacenAlb + "', em_codalmacenori = '" + codAlmacenLote + "' WHERE codlote = '" + codLote + "'")) {
				return false;
		}
		var idStock = AQUtil.sqlSelect("stocks","idstock","referencia = '" + referencia + "' and codalmacen = '" + codAlmacenAlb + "' ");		
		sys.setObjText(this, "fdbIdStock", idStock);
		
		//actualizamos el stock del almacen anterior
		var idStockAnt = AQUtil.sqlSelect("stocks", "idstock", "codalmacen = '" + codAlmacenLote + "' AND referencia = '" + referencia + "'");
		flfactalma.iface.pub_actualizarStock(idStockAnt);
	}

}

// function euromoda_validateForm()
// {
// 	var _i = this.iface;
// 	if (!_i.__validateForm()) {
// 		return false;
// 	}
// 	if (!_i.informaConcepto()) {
// 		return false;
// 	}
// 	return true;
// }
// 
// function euromoda_informaConcepto()
// {
// 	var _i = this.iface;
// 	var cursor = this.cursor();
// 	
// 	var aD = flfactalma.iface.dameDatosStockLinea(cursor.cursorRelation());
// 	if (aD && aD.concepto != "") {
// 		cursor.setValueBuffer("concepto", aD.concepto);
// 	}
// 	return true;
// }
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
