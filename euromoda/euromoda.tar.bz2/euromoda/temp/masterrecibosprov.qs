
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends anticiposprov {
    function euromoda( context ) { anticiposprov( context ); }
    function init() { 
     	return this.ctx.euromoda_init();
  	}
  	function romperCompensacion() {
		return this.ctx.euromoda_romperCompensacion();
	}
	function marcarEmitidos(idRecibo, idReciboComp) {
		return this.ctx.euromoda_marcarEmitidos(idRecibo, idReciboComp);
	}
    function tbnDeshacerPagoPartida_clicked() {
        return this.ctx.euromoda_tbnDeshacerPagoPartida_clicked();
    }
    function controlPartidaSaldo() {
        return this.ctx.euromoda_controlPartidaSaldo();
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{ 
    var _i = this.iface;
    _i.__init();
    _i.controlPartidaSaldo();
    connect(this.child("tableDBRecords"), "currentChanged()", _i, "controlPartidaSaldo");
    connect(this.child("tbnRomperCompensacion"), "clicked()", _i, "romperCompensacion");
    connect(this.child("tbnDeshacerPagoPartida"), "clicked()", _i, "tbnDeshacerPagoPartida_clicked");
}

/** \C Rompe la compensaci�n del recibo seleccionado, si la hay
\end */
function euromoda_romperCompensacion()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var idRecibo = cursor.valueBuffer("idrecibo");
	if (!idRecibo || parseFloat(idRecibo) == 0) {
		flfactppal.iface.ponMsgError(sys.translate("No hay ning�n registro seleccionado."), "warn", this);
		return;
	}

	var idReciboComp = cursor.valueBuffer("idrecibocomp");
	if (!idReciboComp || parseFloat(idReciboComp) == 0) {
		flfactppal.iface.ponMsgError(sys.translate("El recibo seleccionado no est� compensado"), "warn", this);
		return;
	}
	
	var res = MessageBox.information(sys.translate("Va a romper la compensaci�n del recibo seleccioado"), MessageBox.Ok, MessageBox.Cancel);
	if (res != MessageBox.Ok)
		return;
		
	cursor.transaction(false);
	try {
		if (_i.marcarEmitidos(idRecibo, idReciboComp))
			cursor.commit();
		else
			cursor.rollback();
	}
	catch (e) {
		cursor.rollback();
		flfactppal.iface.ponMsgError(sys.translate("Hubo un error al romper la compensaci�n:\n" + e), "warn", this);
	}

	this.child("tableDBRecords").refresh();
}

/** \D Marca como emitidos dos recibos Compensados
@param	idRecibo: primer recibo
@param	idReciboComp: segundo recibo
@return	true si la actualizaci�n tiene �xito, false en caso contrario
\end */
function euromoda_marcarEmitidos(idRecibo, idReciboComp)
{
	var _i = this.iface;
	
	var estado;
	var tipo;
	tipo = AQUtil.sqlSelect("pagosdevolprov", "tipo", "idrecibo = " + idRecibo + " ORDER BY idpagodevol DESC");
	if (tipo == "Devoluci�n") {
		estado = "Devuelto";
	} else {
		estado = "Emitido";
	}

	if (!AQUtil.sqlUpdate("recibosprov", "estado,idrecibocomp", estado + ",NULL", "idrecibo = " + idRecibo)) {
		return false;
	}
	

	tipo = AQUtil.sqlSelect("pagosdevolprov", "tipo", "idrecibo = " + idReciboComp + " ORDER BY idpagodevol DESC");
	if (tipo == "Devoluci�n") {
		estado = "Devuelto";
	} else {
		estado = "Emitido";
	}

	if (!AQUtil.sqlUpdate("recibosprov", "estado,idrecibocomp", estado + ",NULL", "idrecibo = " + idReciboComp)) {
		return false;
	}

	return true;
}

function euromoda_tbnDeshacerPagoPartida_clicked()
{
    const _i = this.iface;

    const cursor = this.cursor();
    const idSaldoPartida = cursor.valueBuffer("em_idsaldopartida");

    if (idSaldoPartida == 0) {
        formUI.ponMsgWarn(sys.translate("No se puede deshacer porque no hay un pago pago mediante partida"));
        return false;
    }

    var curSP = new FLSqlCursor("co_em_saldopartidas");
    curSP.select("idsaldo = " + idSaldoPartida);
    if(curSP.next()) {
        curSP.setModeAccess(curSP.Del);
        curSP.refreshBuffer();
        if (!curSP.commitBuffer()){
            return false;
        }
    }

    this.child("tableDBRecords").refresh();
    _i.controlPartidaSaldo();

    return true;
}

function euromoda_controlPartidaSaldo()
{
    var _i = this.iface;
    const cursor = this.cursor();
    const idSaldoPartida = cursor.valueBuffer("em_idsaldopartida");
    if (idSaldoPartida == 0) {
        if(this.child("tbnDeshacerPagoPartida")) {
            this.child("tbnDeshacerPagoPartida").setDisabled(true);
        }
    }else{
        if(this.child("tbnDeshacerPagoPartida")) {
            this.child("tbnDeshacerPagoPartida").setDisabled(false);
        }
    }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
