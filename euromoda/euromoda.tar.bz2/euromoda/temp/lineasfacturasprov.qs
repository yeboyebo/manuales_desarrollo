
/** @class_declaration euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends prod {
  function euromoda( context ) { prod ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function calculateField(fN) {
    return this.ctx.euromoda_calculateField(fN);
  }
  function habilitaTipoConcepto() {
    return this.ctx.euromoda_habilitaTipoConcepto();
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function dameSubcuentaProducto(cursor) {
    return this.ctx.euromoda_dameSubcuentaProducto(cursor);
  }
  function pbnInsertarPlantillaTexto_clicked() {
    return this.ctx.euromoda_pbnInsertarPlantillaTexto_clicked();
  }
	function modoTexto() {
    return this.ctx.euromoda_modoTexto();
  }
  function validaArticuloFabricado() {
    return this.ctx.euromoda_validaArticuloFabricado();
  }
  function dameFiltroReferencia() {
    return this.ctx.euromoda_dameFiltroReferencia();
  }
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
    function pubEuromoda( context ) { ifaceCtx( context ); }
    function pub_dameSubcuentaProducto(cursor) {
      return this.dameSubcuentaProducto(cursor);
    }
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
function euromoda_init()
{
  var _i = this.iface;
  var cursor = this.cursor();
  _i.__init();
  
  connect(this.child("fdbCodSubcuenta").obj(), "lostFocus()", this.child("fdbPvpUnitario"), "setFocus()");
  connect(this.child("fdbCodAmortizacion").obj(), "lostFocus()", this.child("fdbPvpUnitario"), "setFocus()");  
  connect(this.child("pbnInsertarPlantillaTexto"), "clicked()", _i, "pbnInsertarPlantillaTexto_clicked");
  
  switch (cursor.modeAccess()) {
  case cursor.Edit: {
	sys.disableObj(this, "fdbTipoConcepto");
      break;
    }
  }
  
  _i.habilitaTipoConcepto(this);
  _i.modoTexto();
}

function euromoda_bufferChanged(fN)
{
	//debug("euromoda_bufferChanged " + fN + " " + this.cursor().valueBuffer("fN"));
	var cursor = this.cursor();
  var _i = this.iface;
  switch (fN) {
  case "codamortizacion": {
      sys.setObjText(this, "fdbDescripcion", _i.calculateField("desactivo"));
      sys.setObjText(this, "fdbCodSubcuenta", _i.calculateField("codsubcuentaaf"));
			sys.setObjText(this, "fdbPvpUnitario", _i.calculateField("pvpunitarioaf"));
      break;
    }
  case "referencia": {
      sys.setObjText(this, "fdbDescripcion", _i.calculateField("desarticulo"));
      _i.__bufferChanged(fN);
      break;
    }
  case "idsubcuenta": {
		debug("Rompiendo ?");
		if (!cursor.valueBuffer("idsubcuenta") || cursor.valueBuffer("idsubcuenta") == "") {
			debug("Rompiendo");
			break;
		}
		sys.setObjText(this, "fdbDescripcion", _i.calculateField("dessubcuenta"));
		sys.setObjText(this, "fdbCodImpuesto", _i.calculateField("codimpuestosubcuenta", cursor));
		_i.__bufferChanged(fN);
		break;
	}
	case "tipoconcepto": {
		_i.__bufferChanged(fN);
		_i.habilitaTipoConcepto();
		_i.modoTexto();
		break;
	}
	case "codsubcuenta": {
    if (!_i.bloqueoSubcuenta) {
      _i.bloqueoSubcuenta = true;
      _i.posActualPuntoSubcuenta = flcontppal.iface.pub_formatearCodSubcta(this, "fdbCodSubcuenta", _i.longSubcuenta, _i.posActualPuntoSubcuenta);
			sys.setObjText(this, "fdbIdSubcuenta", _i.calculateField("idsubcuenta"));
      _i.bloqueoSubcuenta = false;
    }
    break;
	}
//   case "tipoconcepto": {
//       _i.habilitaTipoConcepto();
//       break;
//     }
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_calculateField(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  var valor;
  switch (fN) {
		case "pvpunitarioaf": {
			valor = AQUtil.sqlSelect("co_amortizaciones", "valoradquisicion", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
			break;
		}
		case "desactivo": {
			valor = AQUtil.sqlSelect("co_amortizaciones", "elemento", "codamortizacion = '" + cursor.valueBuffer("codamortizacion") + "'");
			break;
		}
		case "dessubcuenta": {
			valor = AQUtil.sqlSelect("co_subcuentas", "descripcion", "idsubcuenta = '" + cursor.valueBuffer("idsubcuenta") + "'");
			break;
		}
		case "codsubcuenta": {
			valor = _i.dameSubcuentaProducto(cursor);
			break;
		}
		case "codsubcuentaaf": {
			var codAF = cursor.valueBuffer("codamortizacion");
			if (!codAF || codAF == "") {
				valor = "";
			} else {
				valor = AQUtil.sqlSelect("co_amortizaciones a INNER JOIN co_gruposcontablesamo g ON a.codgrupocontableamo = g.codgrupo", "g.codsubcuentaele", "a.codamortizacion = '" + codAF + "'", "co_amortizaciones,co_gruposcontablesamo");
			}
			break;
		}
		case "codimpuestosubcuenta": {
			valor = AQUtil.sqlSelect("co_subcuentas", "codimpuesto", "idsubcuenta = " + cursor.valueBuffer("idsubcuenta"));
			break;
		}
		case "idsubcuenta": {
			var codEjercicio = cursor.cursorRelation().valueBuffer("codejercicio");
      var codSubcuenta:String = cursor.valueBuffer("codsubcuenta");
      if(!codSubcuenta || codSubcuenta == "") {
        valor = ""; //pineboo 21-08-2019
        break;
      }
      var idsubcuenta = AQUtil.sqlSelect("co_subcuentas", "idsubcuenta", "codsubcuenta = '" + codSubcuenta + "' AND codejercicio = '" + codEjercicio + "'");
      if (!idsubcuenta)
        valor = "";
      else
        valor = idsubcuenta;
      break;
    }
  default: {
      valor = _i.__calculateField(fN);
    }
  }
  return valor;
}

function euromoda_dameSubcuentaProducto(cursor)
{
  var valor;
  var cR = cursor.cursorRelation();
  var codProveedor;
  if (cR) {
    codProveedor = cR.valueBuffer("codproveedor");
    deAbono = cR.valueBuffer("deabono");
  } else {
    codProveedor = AQUtil.sqlSelect("facturasprov", "codproveedor", "idfactura = " + cursor.valueBuffer("idfactura"));
    deAbono = AQUtil.sqlSelect("facturasprov", "deabono", "idfactura = " + cursor.valueBuffer("idfactura"));
  }
  var gCNegocio = AQUtil.sqlSelect("proveedores", "codgrupocontableneg", "codproveedor = '" + codProveedor + "'");
  var referencia = cursor.valueBuffer("referencia");
  if (!referencia || referencia == "") {
    valor = "";
  } else {
    if (deAbono) {
      valor = AQUtil.sqlSelect("articulos a INNER JOIN gruposcontablesproneg g ON a.codgrupocontablepro = g.codgrupocontablepro", "g.codsubcuentadcom", "referencia = '" + referencia + "' AND g.codgrupocontableneg = '" + gCNegocio + "'", "articulos,gruposcontablesproneg");
    } else {
      valor = AQUtil.sqlSelect("articulos a INNER JOIN gruposcontablesproneg g ON a.codgrupocontablepro = g.codgrupocontablepro", "g.codsubcuentacom", "referencia = '" + referencia + "' AND g.codgrupocontableneg = '" + gCNegocio + "'", "articulos,gruposcontablesproneg");
    }
  }
  return valor;
}

function euromoda_habilitaTipoConcepto()
{
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
		case "Producto": {
      this.child("fdbCodAmortizacion").close();
      this.child("fdbCodAmortizacion").setValue("");
      this.child("fdbReferencia").obj().show();
      this.child("fdbReferencia").setFocus();
      this.child("chkFiltrarArtProv").show();
      break;
    }
    case "Activo fijo": {
      this.child("fdbCodAmortizacion").obj().show();
      this.child("fdbCodAmortizacion").setFocus();
      this.child("fdbReferencia").close();
      this.child("fdbReferencia").setValue("");
			this.child("fdbCodSubcuenta").setDisabled(true);
      break;
    }
  }
}

function euromoda_pbnInsertarPlantillaTexto_clicked()
{
  var f = new FLFormSearchDB("em_plantillastexto");
  f.setMainWidget();
  var texto = f.exec("texto");
  if (!texto) {
    return;
  }
  this.child("fdbTexto").setValue(texto);
}

function euromoda_modoTexto()
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (cursor.valueBuffer("tipoconcepto")) {
  case "Texto": {
      this.child("fdbReferencia").setValue("");
      this.child("fdbCantidad").setValue(0);
      this.child("fdbPvpUnitario").setValue(0);
      this.child("fdbCodImpuesto").setValue("");
      this.child("groupBox7").enabled = false;
      this.child("groupBox8").enabled = false;
      this.child("groupBox9").enabled = false;
      this.child("groupBox10").enabled = false;
      this.child("gbxTexto").setDisabled(false);
//       this.child("tbwLinea").showPage("texto");
      this.child("fdbTexto").setFocus();
      break;
    }
  default: {
      this.child("groupBox7").enabled = true;
      this.child("groupBox8").enabled = true;
      this.child("groupBox9").enabled = true;
      this.child("groupBox10").enabled = true;
//       this.child("tbwLinea").showPage("movimientos");
      this.child("gbxTexto").setDisabled(true);
      this.child("fdbTexto").setValue("");
      break;
    }
  }
}

function euromoda_validaArticuloFabricado()
{
	return true;
}

function euromoda_dameFiltroReferencia()
{
	var _i = this.iface;
// 	var f = _i.__dameFiltroReferencia();
	var f = "NOT debaja";
	return f;
}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
