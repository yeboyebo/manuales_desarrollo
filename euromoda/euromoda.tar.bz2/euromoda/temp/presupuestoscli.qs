
/** @class_declaration euromoda*/
/////////////////////////////////////////////////////////////////
//// EUROMODA ///////////////////////////////////////////////////
class euromoda extends cambioIva {
	var pK_;
	var politicaCostes_;
	var ignorarAvisosCostes_ = false;
  function euromoda( context ) { cambioIva ( context ); }
  function bufferChanged(fN) {
    return this.ctx.euromoda_bufferChanged(fN);
  }
  function init() {
    return this.ctx.euromoda_init();
  }
  function calcularTotales() {
    return this.ctx.euromoda_calcularTotales();
  }
  function guardaPrespuesto(curLineas) {
    return this.ctx.euromoda_guardaPrespuesto(curLineas);
  }
	function guardaDocumentoCommit(curLineas)
  {
    return this.ctx.euromoda_guardaDocumentoCommit(curLineas);
  }
	function validateForm(lineas) {
		return this.ctx.euromoda_validateForm(lineas);
	}
  function ocultarCamposContabilidad() {
	return this.ctx.euromoda_ocultarCamposContabilidad();
  }	
	function aceptarFormulario() {
		return this.ctx.euromoda_aceptarFormulario();
	}
	function aceptaContinuaFormulario() {
		return this.ctx.euromoda_aceptaContinuaFormulario();
	}
	function evaluarCostesCab(cursor) {
		return this.ctx.euromoda_evaluarCostesCab(cursor);
	}
	function evaluarCostesGlobales(oParam) {
		return this.ctx.euromoda_evaluarCostesGlobales(oParam);
	}
	function anotarEstadoCostesDocumento(oParam){
		return this.ctx.euromoda_anotarEstadoCostesDocumento(oParam);
	}
	function dameImporteLQ(cursor) {
		return this.ctx.euromoda_dameImporteLQ(cursor);
	}
	function dameImporteLCostes(cursor) {
		return this.ctx.euromoda_dameImporteLCostes(cursor);
	}
	function dameImporteLCostesMargen(cursor) {
		return this.ctx.euromoda_dameImporteLCostesMargen(cursor);
	}
	function dameLineasNoSuperado(cursor) {
		return this.ctx.euromoda_dameLineasNoSuperado(cursor);
	}
	function avisarDocumento(oParam) {
		return this.ctx.euromoda_avisarDocumento(oParam);	
	}
	function tbnEmRegenerarCostes_clicked() {
		return this.ctx.euromoda_tbnEmRegenerarCostes_clicked();
	}
 	function tbnEmCargarCostes_clicked() {
 		return this.ctx.euromoda_tbnEmCargarCostes_clicked();
 	}
 	function actualizaCostes(cursor,curLineas,forzar) {
 		return this.ctx.euromoda_actualizaCostes(cursor,curLineas,forzar);
 	}
	function dameDatosTabla(cursor) {
		return this.ctx.euromoda_dameDatosTabla(cursor);
	}
	function ponPoliticaCostes(tabla, codCliente) {
		return this.ctx.euromoda_ponPoliticaCostes(tabla, codCliente);
	}
 	function pbnImportarCSV_clicked() {
		return this.ctx.euromoda_pbnImportarCSV_clicked();
	}

}
//// EUROMODA ///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_declaration pubEuromoda */
/////////////////////////////////////////////////////////////////
//// PUB EUROMODA ///////////////////////////////////////////////
class pubEuromoda extends ifaceCtx {
	function pubEuromoda( context ) { ifaceCtx( context ); }
	function pub_ponPoliticaCostes(tabla, codCliente) {
		return this.ponPoliticaCostes(tabla, codCliente);
	}
	function pub_evaluarCostesCab(cursor) {
		return this.evaluarCostesCab(cursor);
	}
	function pub_actualizaCostes(cursor, curLineas, forzar) {
		return this.actualizaCostes(cursor, curLineas, forzar);
	}	
}
//// PUB EUROMODA ///////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/** @class_definition euromoda */
//////////////////////////////////////////////////////////////////
//// EUROMODA ////////////////////////////////////////////////////
function euromoda_bufferChanged(fN)
{
  var _i = this.iface;
  var cursor = this.cursor();
  switch (fN) {
  case "codpago": {
      _i.__bufferChanged(fN);
      sys.setObjText(this, "fdbPorDtoEsp", _i.calculateField("pordtoesp_fp"));
      break;
    }
  case "codcliente": {
        sys.setObjText(this, "fdbCodSerie", _i.calculateField("codserie"));
      _i.__bufferChanged(fN);
      this.child("lblDirFacturacion").text = _i.calculateField("dirfacturacion");
		_i.ponPoliticaCostes("presupuestoscli",cursor.valueBuffer("codcliente"));
		formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("presupuestoscli",cursor.valueBuffer("codcliente"));
      break;
    }
  default: {
      _i.__bufferChanged(fN);
    }
  }
}

function euromoda_init()
{
	var _i = this.iface;
	var cursor = this.cursor();
	_i.__init();
	
	_i.ponPoliticaCostes("presupuestoscli",cursor.valueBuffer("codcliente"));
	formRecordlineaspresupuestoscli.iface.pub_ponPoliticaCostes("presupuestoscli",cursor.valueBuffer("codcliente"));

 	connect(this.child("tbnEmRegenerarCostes"), "clicked()", _i, "tbnEmRegenerarCostes_clicked");
 	connect(this.child("tbnEmCargarCostes"), "clicked()", _i, "tbnEmCargarCostes_clicked");

	_i.pK_ = cursor.valueBuffer(cursor.primaryKey());

	this.child("lblDirFacturacion").text = _i.calculateField("dirfacturacion");
	connect(this.child("tdbLineasPresupuestosCli").cursor(), "commited()", _i, "guardaDocumentoCommit()");

	//Desconectamos el boton aceptar
	if(this.child("pushButtonAccept")){
		disconnect(this.child("pushButtonAccept"), "clicked()", this.obj(), "accept()");
	  	connect(this.child("pushButtonAccept"), "clicked()", _i, "aceptarFormulario");
	}

	if(this.child("pushButtonAcceptContinue")){
  		disconnect(this.child("pushButtonAcceptContinue"), "clicked()", this.obj(), "acceptContinue()");
  		connect(this.child("pushButtonAcceptContinue"), "clicked()", _i, "aceptaContinuaFormulario");

  		this.child("pushButtonAcceptContinue").setDisabled(false);
  	}
  	connect(this.child("pbnImportarCSV"), "clicked()", _i, "pbnImportarCSV_clicked");
}

function euromoda_calcularTotales()
{
  var _i = this.iface;
  _i.__calcularTotales();

  //_i.guardaPrespuesto(this.child("tdbLineasPresupuestosCli").cursor());
}

function euromoda_guardaPrespuesto(curLineas)
{
	return;
	
  var _i = this.iface;
  var cursor = this.cursor();
  var pk = cursor.valueBuffer("idpresupuesto");

  var commitLineas = (cursor.transactionLevel() == 2);
  if (curLineas == undefined) {
    commitLineas = false;
  }

  if (cursor.modeAccess() != cursor.Edit) {
    return true;
  }

  if (!_i.validateForm(true)) {
    return false;
  }
  var indice = cursor.atFrom();
  if (!cursor.commitBuffer()) {
    return false;
  }

  if (commitLineas)
    curLineas.commit();
  if (!cursor.commit()) {
    if (commitLineas)
      curLineas.transaction(false);
    return false;
  }

  if (!cursor.transaction(false)) {
    if (commitLineas)
      curLineas.transaction(false);
    return false;
  }
  if (commitLineas)
    curLineas.transaction(false);

  if (!cursor.seek(indice)) {
    return false;
  }

  cursor.setModeAccess(cursor.Edit);
  cursor.refreshBuffer();
  if (cursor.valueBuffer("idpresupuesto") != pk) {
		cursor.select("idpresupuesto = " + pk);
		if (!cursor.first()) {
			sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
			return false;
		}
		cursor.setModeAccess(cursor.Edit);
		cursor.refreshBuffer();
  }

  return true;
}

function euromoda_guardaDocumentoCommit()
{
	
  var _i = this.iface;
  var cursor = this.cursor();

  if (cursor.modeAccess() != cursor.Edit) {
    return true;
  }
  var pk = cursor.valueBuffer(cursor.primaryKey());

  if (!_i.validateForm(true)) {
    return false;
  }
  if (!cursor.commitBuffer()) {
    return false;
  }
  cursor.commit();
  cursor.transaction(false);
  cursor.setModeAccess(cursor.Edit);
  cursor.refreshBuffer();
   if (cursor.valueBuffer(cursor.primaryKey()) != _i.pK_) {
		cursor.select(cursor.primaryKey() + " = " + _i.pK_);
		if (!cursor.first()) {
			sys.errorMsgBox("Error al relocalizar el documento. Gu�rdelo y vu�lvalo a abrir para continuar");
			return false;
		}
		cursor.setModeAccess(cursor.Edit);
		cursor.refreshBuffer();
  }
}

function euromoda_validateForm(lineas)
{

	var _i = this.iface;
	var cursor = this.cursor();
	
	if(!_i.__validateForm()){
		return false;
	}
	if (lineas) {
		return true;
	}
	if(cursor.valueBuffer("fechasalida")<cursor.valueBuffer("fecha")){
			//pregunto la primera vez
		var mensaje = MessageBox.warning(sys.translate("Atenci�n!!, ha indicado como fecha de salida una inferior al del presupuesto, debe corregirla. \n�desea continuar sin corregirlo?"), MessageBox.Yes, MessageBox.No);
		if (mensaje!=MessageBox.Yes){
			if(this.child("pushButtonAcceptContinue")){
				this.child("pushButtonAcceptContinue").setDisabled(false);
			}
			if(this.child("pushButtonAccept")){
				this.child("pushButtonAccept").setDisabled(false);
			}
			return false;
		}
				//pregunto una segunda vez
		var mensaje2 = MessageBox.warning(sys.translate("Creemos que es un error que contin�e con esta fecha de salida\n�desea continuar?"), MessageBox.Yes, MessageBox.No);
		if (mensaje2!=MessageBox.Yes){
			if(this.child("pushButtonAcceptContinue")){
				this.child("pushButtonAcceptContinue").setDisabled(false);
			}
			if(this.child("pushButtonAccept")){
				this.child("pushButtonAccept").setDisabled(false);
			}
			return false;
		}
	}
	if(!_i.evaluarCostesCab(cursor)) {  	
		if(this.child("pushButtonAcceptContinue")){
			this.child("pushButtonAcceptContinue").setDisabled(false);
		}
		if(this.child("pushButtonAccept")){
			this.child("pushButtonAccept").setDisabled(false);
		}
  		return false;
  	}
				
	return true;
}

function euromoda_ocultarCamposContabilidad()
{
	return true;
}

function euromoda_aceptarFormulario()
{
	var _i = this.iface;	
	this.child("pushButtonAccept").setDisabled(true);
	this.obj().accept();
}

function euromoda_aceptaContinuaFormulario()
{
	var _i = this.iface;
	this.child("pushButtonAcceptContinue").setDisabled(true);
	this.obj().acceptContinue();
}

function euromoda_evaluarCostesCab(cursor)
{
	
	var _i = this.iface;	
	var tabla = cursor.table();
	var oParam = formRecordlineaspresupuestoscli.iface.dameParamCostesProdLin(cursor);
	oParam.cursor = cursor;

	var fechaDoc = cursor.valueBuffer("fecha");	

	//proceso5 --> evaluarCostesGlobales
	//proceso6 --> evaluarCostesLinea
	//proceso7 --> avisarDocumento

	if(!_i.politicaCostes_ || _i.politicaCostes_.politica == "") {		
		oParam.caso = "DL1";			
	} else if(_i.politicaCostes_.politica == "1-NO CONTROLADO") {
		oParam.caso = "DL2";		
	} else  {
		var fechaPolitica = _i.politicaCostes_.fecha;
		if( fechaPolitica && fechaPolitica > fechaDoc) {			
			oParam.caso = "DL3";			
			oParam.fechaDoc = fechaDoc;
		} else {
			var resEvaluar = _i.evaluarCostesGlobales(oParam);//PROCESO5			
			if(resEvaluar == "PD.5.2" || resEvaluar == "PD.5.3" || resEvaluar == "PD.5.9" || resEvaluar == "PD.5.15") {
				oParam.caso = "DL4";				
			} else if(resEvaluar == "PD.5.1") {
				oParam.caso = "DL5";				
			} else if(_i.politicaCostes_.politica == "2-No avisar y dejar continuar") {
				oParam.caso = "DL6";				
			} else if(_i.politicaCostes_.politica != "3-Avisar y dejar continuar") {
				oParam.caso = "DL7";				
			} else {
				oParam.caso = "DL8";				
				_i.anotarEstadoCostesDocumento(oParam);//PROCESO7
				oParam.resEvaluar = resEvaluar;
				if(resEvaluar == "PD.5.8b" || resEvaluar == "PD.5.13b") {
					oParam.resEvaluar = "PD.5.5";
					if(!_i.avisarDocumento(oParam)) {
						return false;
					}
					if(resEvaluar == "PD.5.8b") {
						oParam.resEvaluar = "PD.5.8";	
					} else {
						oParam.resEvaluar = "PD.5.13";
					}					
					if(!_i.avisarDocumento(oParam)) {
						return false;
					}					
				} else { 
					if(!_i.avisarDocumento(oParam)) {
						return false;
					}					
				}	
				return true;
				
			}						
		}
	}	
	_i.anotarEstadoCostesDocumento(oParam);//PROCESO7
	return true;
}

/*function euromoda_evaluarCostesGlobales(oParam)
{
	
	//PROCESO 5
	var _i = this.iface;
	var cursor = oParam.cursor;
	if(cursor.valueBuffer("em_autorizadocostes")) {		
		res = "PD.5.1";		
		oParam.estadoCostes = "AUTORIZADO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "AUTORIZADO";	
	} else {
		var importeLQ = _i.dameImporteLQ(cursor);			
		if(importeLQ < 0) {	
			res = "PD.5.2";			
			oParam.estadoCostes = "EXENTO";
			oParam.politicaCostes = _i.politicaCostes_.politica;
			oParam.motivoCostes = "DOC.EXENTO Importe negativo";	
		} else {
			var importeLCostes = _i.dameImporteLCostes(cursor);
			oParam.lineasNoSuperado = _i.dameLineasNoSuperado(cursor);
			if(importeLCostes == 0 && oParam.lineasNoSuperado.length == 0) {
				res = "PD.5.3";				
				oParam.estadoCostes = "EXENTO";
				oParam.politicaCostes = _i.politicaCostes_.politica;
				oParam.motivoCostes = "DOC.EXENTO Costes 0";	
			} else {
				res = "PD.5.4";				
				//oParam.lineasNoSuperado = _i.dameLineasNoSuperado(cursor);
				var aLineas = [];		
				if(oParam.lineasNoSuperado.length >10) {
					for(var k=0; k<10; k++) {
						aLineas[k] = oParam.lineasNoSuperado[k];
					}
				} else {
					aLineas = oParam.lineasNoSuperado;
				}
				var lineas = lineas = aLineas.join(",");
				if(oParam.lineasNoSuperado.length > 10) {
					lineas += " y m�s."
				}
				oParam.lineasMal = lineas;

				if(oParam.lineasNoSuperado.length >0) {
					res = "PD.5.5";					
					oParam.estadoCostes = "NO SUPERADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "L�neas mal "+lineas;	
				} else {
					res = "PD.5.6";					
					oParam.estadoCostes = "APROBADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "Aprobado momentaneamente";	
				}
				if(0 < importeLQ && importeLQ <= importeLCostes) {					
					oParam.estadoCostes = "NO SUPERADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;					
					oParam.motivoCostes = "Estado global por debajo de costes: " + importeLQ + "<="+ importeLCostes;	
					
					if(res == "PD.5.5")	 {
						res = "PD.5.8b";						
						oParam.motivoCostes = "L�neas no cumplen: " + lineas + " y "+oParam.motivoCostes;		
					} else {
						res = "PD.5.8";
					}					
				} else if(res == "PD.5.5") {
					res = "PD.5.10";					
				} else {
					res = "PD.5.9";					
					oParam.estadoCostes = "APROBADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "APROBADO: importe "+ importeLQ + " mayor que importe coste "+importeLCostes;
				}
			}
		}

	}
	return res;
}*/

/*function euromoda_evaluarCostesGlobales(oParam) COMENTADO ANTES DE #EUR #H1705 P0052E Costes e inventarios: evaluaci�n global documento
{
	
	//PROCESO 5
	var _i = this.iface;
	var cursor = oParam.cursor;
	if(cursor.valueBuffer("em_autorizadocostes")) {		
		res = "PD.5.1";		
		oParam.estadoCostes = "AUTORIZADO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "AUTORIZADO";	
	} else {
		var importeLQ = _i.dameImporteLQ(cursor);	
		var importeLCostes = _i.dameImporteLCostes(cursor);
		var importeLCostesMargen = _i.dameImporteLCostesMargen(cursor); 

		debug("globalNeto: "+importeLQ);
		debug("globalCostes: "+importeLCostes);
		debug("globalMargenes: "+importeLCostesMargen);

		cursor.setValueBuffer("em_globalneto",importeLQ);
		cursor.setValueBuffer("em_globalcostes",importeLCostes);
		cursor.setValueBuffer("em_globalmargenes",importeLCostesMargen);

		var netoVScostes = _i.commonCalculateField("em_netovscostes", cursor);
		var netoVSmargenes = _i.commonCalculateField("em_netovsmargenes", cursor);

		debug("netoVScostes: "+netoVScostes);
		debug("netoVSmargenes: "+netoVSmargenes);

		cursor.setValueBuffer("em_netovscostes",netoVScostes);
		cursor.setValueBuffer("em_netovsmargenes",netoVSmargenes);

		
		if(importeLQ < 0) {	
			res = "PD.5.2";			
			oParam.estadoCostes = "EXENTO";
			oParam.politicaCostes = _i.politicaCostes_.politica;
			oParam.motivoCostes = "DOC.EXENTO Importe negativo";	
		} else {
			var importeLCostes = _i.dameImporteLCostes(cursor);	

			oParam.lineasNoSuperado = _i.dameLineasNoSuperado(cursor);
			if(importeLCostes == 0 && oParam.lineasNoSuperado.length == 0) {
				res = "PD.5.3";				
				oParam.estadoCostes = "EXENTO";
				oParam.politicaCostes = _i.politicaCostes_.politica;
				oParam.motivoCostes = "DOC.EXENTO Costes 0";	
			} else {
				res = "PD.5.4";				
				//oParam.lineasNoSuperado = _i.dameLineasNoSuperado(cursor);
				var aLineas = [];		
				if(oParam.lineasNoSuperado.length >10) {
					for(var k=0; k<10; k++) {
						aLineas[k] = oParam.lineasNoSuperado[k];
					}
				} else {
					aLineas = oParam.lineasNoSuperado;
				}
				var lineas = lineas = aLineas.join(",");
				if(oParam.lineasNoSuperado.length > 10) {
					lineas += " y m�s."
				}
				oParam.lineasMal = lineas;

				if(oParam.lineasNoSuperado.length >0) {
					res = "PD.5.5";					
					oParam.estadoCostes = "NO SUPERADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "L�neas mal "+lineas;	
				} else {
					res = "PD.5.6";					
					oParam.estadoCostes = "APROBADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "Aprobado momentaneamente";	
				}
				//if(0 < importeLQ && importeLQ <= importeLCostes) { 20-01-2019 #EUR #H1621					
				if(0 < parseFloat(importeLQ) && parseFloat(importeLQ) < parseFloat(importeLCostes)) {					
					oParam.estadoCostes = "NO SUPERADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;					
					oParam.motivoCostes = "Estado global por debajo de costes: " + importeLQ + "<"+ importeLCostes;	
					
					if(res == "PD.5.5")	 {
						res = "PD.5.8b";						
						oParam.motivoCostes = "L�neas no cumplen: " + lineas + " y "+oParam.motivoCostes;		
					} else {
						res = "PD.5.8";
					}					
				} else if(_i.politicaCostes_.evaluarMargen) {
					var importeLCostesMargen = _i.dameImporteLCostesMargen(cursor); 
					//if(importeLCostesMargen < importeLQ) { 20-01-2019 #EUR #H1621	
					if(parseFloat(importeLCostesMargen) <= parseFloat(importeLQ)) {
						res = "PD.5.12";
						if(oParam.lineasNoSuperado.length >0) {
							res = "PD.5.14";
						} else {
							res = "PD.5.15";															
							oParam.estadoCostes = "APROBADO";
							oParam.politicaCostes = _i.politicaCostes_.politica;
							oParam.motivoCostes = "APROBADO: importe "+ importeLQ + " supera o es igual a los costes + m�rgenes "+importeLCostesMargen;
						}
					} else {
						oParam.estadoCostes = "NO SUPERADO";
						oParam.politicaCostes = _i.politicaCostes_.politica;					
						//oParam.motivoCostes = "Estado global por debajo de costes+m�rgenes: " + importeLQ + "<="+ importeLCostesMargen; 20-01-2019 #EUR #H1621	
						oParam.motivoCostes = "Estado global por debajo de costes+m�rgenes: " + importeLQ + "<"+ importeLCostesMargen;	
						if(res == "PD.5.5")	 {
							res = "PD.5.13b";						
							oParam.motivoCostes = "L�neas no cumplen: " + lineas + " y "+oParam.motivoCostes;		
						} else {
							res = "PD.5.13";
						}	
					}

				} else if(res == "PD.5.5") {
					res = "PD.5.10";					
				} else {
					res = "PD.5.9";					
					oParam.estadoCostes = "APROBADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "APROBADO: importe "+ importeLQ + " mayor o igual que importe coste "+importeLCostes;
				}
			}
		}

	}
	return res;
}*/

function euromoda_evaluarCostesGlobales(oParam)
{
	

	//PROCESO 5
	//debug("\n\n********************************************");
	//debug("euromoda_evaluarCostesGlobales");
	var _i = this.iface;
	var cursor = oParam.cursor;
	if(cursor.valueBuffer("em_autorizadocostes")) {		
		//debug("------------------------------------- 1");
		res = "PD.5.1";		
		oParam.estadoCostes = "AUTORIZADO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "AUTORIZADO";	
	} else {
		//debug("------------------------------------- 2");
		var importeLQ = _i.dameImporteLQ(cursor);	
		var importeLCostes = _i.dameImporteLCostes(cursor);
		var importeLCostesMargen = _i.dameImporteLCostesMargen(cursor); 

		//debug("globalNeto: "+importeLQ);
		//debug("globalCostes: "+importeLCostes);
		//debug("globalMargenes: "+importeLCostesMargen);

		cursor.setValueBuffer("em_globalneto",importeLQ);
		cursor.setValueBuffer("em_globalcostes",importeLCostes);
		cursor.setValueBuffer("em_globalmargenes",importeLCostesMargen);

		var netoVScostes = _i.commonCalculateField("em_netovscostes", cursor);
		var netoVSmargenes = _i.commonCalculateField("em_netovsmargenes", cursor);

		//debug("netoVScostes: "+netoVScostes);
		//debug("netoVSmargenes: "+netoVSmargenes);

		cursor.setValueBuffer("em_netovscostes",netoVScostes);
		cursor.setValueBuffer("em_netovsmargenes",netoVSmargenes);

		
		if(importeLQ < 0) {	
			//debug("------------------------------------- 3");
			res = "PD.5.2";			
			oParam.estadoCostes = "EXENTO";
			oParam.politicaCostes = _i.politicaCostes_.politica;
			oParam.motivoCostes = "DOC.EXENTO Importe negativo";	
		} else {
			//debug("------------------------------------- 4");
			var importeLCostes = _i.dameImporteLCostes(cursor);	

			oParam.lineasNoSuperado = _i.dameLineasNoSuperado(cursor);
			if(importeLCostes == 0 && oParam.lineasNoSuperado.length == 0) {
				//debug("------------------------------------- 5");
				res = "PD.5.3";				
				oParam.estadoCostes = "EXENTO";
				oParam.politicaCostes = _i.politicaCostes_.politica;
				oParam.motivoCostes = "DOC.EXENTO Costes 0";	
			} else {
				//debug("------------------------------------- 6");
				res = "PD.5.4";				
				//oParam.lineasNoSuperado = _i.dameLineasNoSuperado(cursor);
				var aLineas = [];		
				if(oParam.lineasNoSuperado.length >10) {
					//debug("------------------------------------- 7");
					for(var k=0; k<10; k++) {
						aLineas[k] = oParam.lineasNoSuperado[k];
					}
				} else {
					//debug("------------------------------------- 8");
					aLineas = oParam.lineasNoSuperado;
				}
				var lineas = lineas = aLineas.join(",");
				if(oParam.lineasNoSuperado.length > 10) {
					//debug("------------------------------------- 9");
					lineas += " y m�s."
				}
				oParam.lineasMal = lineas;

				if(oParam.lineasNoSuperado.length >0) {
					//debug("------------------------------------- 10");
					res = "PD.5.5";					
					oParam.estadoCostes = "NO SUPERADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "L�neas mal "+lineas;	
				} else {
					//debug("------------------------------------- 11");
					res = "PD.5.6";					
					oParam.estadoCostes = "APROBADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "Aprobado momentaneamente";	
				}
				//debug("------------------------------------- 12");
				//if(0 < importeLQ && importeLQ <= importeLCostes) { 20-01-2019 #EUR #H1621					
				if(0 < parseFloat(importeLQ) && parseFloat(importeLQ) < parseFloat(importeLCostes)) {					
					//debug("------------------------------------- 13");
					oParam.estadoCostes = "NO SUPERADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;					
					oParam.motivoCostes = "Estado global por debajo de costes: " + importeLQ + "<"+ importeLCostes;	
					
					if(res == "PD.5.5")	 {
						//debug("------------------------------------- 14");
						res = "PD.5.8b";						
						oParam.motivoCostes = "L�neas no cumplen: " + lineas + " y "+oParam.motivoCostes;		
					} else {
						//debug("------------------------------------- 15");
						res = "PD.5.8";
					}					
				} else if(_i.politicaCostes_.evaluarMargen) {
					//debug("------------------------------------- 16");
					var importeLCostesMargen = _i.dameImporteLCostesMargen(cursor); 
					//if(importeLCostesMargen < importeLQ) { 20-01-2019 #EUR #H1621	
					//debug("importeLCostesMargen: "+parseFloat(importeLCostesMargen));
					//debug("importeLQ: "+parseFloat(importeLQ));
					if(parseFloat(importeLCostesMargen) <= parseFloat(importeLQ)) {
						//debug("------------------------------------- 17");
						
						res = "PD.5.12";
						//if(oParam.lineasNoSuperado.length >0) { 24-04-2019 #EUR #H1705 P0052E
						if(oParam.lineasNoSuperado.length >0 && !_i.politicaCostes_.aprobarCostesMar) {
							//debug("------------------------------------- 18");
							res = "PD.5.14";
						} else {
							//debug("------------------------------------- 19");
							res = "PD.5.15";															
							oParam.estadoCostes = "APROBADO";
							oParam.politicaCostes = _i.politicaCostes_.politica;							
							oParam.motivoCostes = "APROBADO: importe "+ importeLQ + " supera o es igual a los costes + m�rgenes "+AQUtil.roundFieldValue(importeLCostesMargen,"lineaspresupuestoscli","pvptotal");
						}
					} else {
						//debug("------------------------------------- 20");
						oParam.estadoCostes = "NO SUPERADO";
						oParam.politicaCostes = _i.politicaCostes_.politica;					
						//oParam.motivoCostes = "Estado global por debajo de costes+m�rgenes: " + importeLQ + "<="+ importeLCostesMargen; 20-01-2019 #EUR #H1621	
						oParam.motivoCostes = "Estado global por debajo de costes+m�rgenes: " + importeLQ + "<"+ AQUtil.roundFieldValue(importeLCostesMargen,"lineaspresupuestoscli","pvptotal");	
						if(res == "PD.5.5")	 {
							//debug("------------------------------------- 21");
							res = "PD.5.13b";						
							oParam.motivoCostes = "L�neas no cumplen: " + lineas + " y "+oParam.motivoCostes;		
							
						} else {
							//debug("------------------------------------- 22");
							res = "PD.5.13";
							//debug("7");
						}	
					}

				} else if(res == "PD.5.5" && !_i.politicaCostes_.aprobarCostes) {
					//debug("------------------------------------- 23");
					res = "PD.5.10";					
				} else {
					//debug("------------------------------------- 24");
					res = "PD.5.9";					
					oParam.estadoCostes = "APROBADO";
					oParam.politicaCostes = _i.politicaCostes_.politica;
					oParam.motivoCostes = "APROBADO: importe "+ importeLQ + " mayor o igual que importe coste "+importeLCostes;
				}
			}
		}

	}
	return res;
}

function euromoda_anotarEstadoCostesDocumento(oParam)
{
	//PROCESO4
	var _i = this.iface;
	var hoy = new Date();	
	var fechaHora = AQUtil.dateAMDtoDMA(hoy.toString().left(10)) + " " + hoy.toString().right(8);
	var cursor = oParam.cursor;
	var caso = oParam.caso;
	if(caso == "DL1") {
		//Se ha perdido la configuraci�n de la pol�tica de costes.
		oParam.estadoCostes = "SIN POLITICA";
		oParam.politicaCostes = "No encontrada";
		oParam.motivoCostes = "La configuraci�n de pol�tica no ten�a informaci�n para aplicarla";

	} else if (caso == "DL2") {
		//No comprobar
		oParam.estadoCostes = "EXENTO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "En el d�a de emisi�n " + fechaHora + " la pol�tica era: No controlar";		

	} else if (caso == "DL3") {
		oParam.estadoCostes = "EXENTO";
		oParam.politicaCostes = _i.politicaCostes_.politica;
		oParam.motivoCostes = "Fecha de documento " + AQUtil.dateAMDtoDMA(oParam.fechaDoc.toString().left(10)) + " menor a la fecha de control " + AQUtil.dateAMDtoDMA(_i.politicaCostes_.fecha.toString().left(10));	
		
	} else if (caso == "DL4") {		
		oParam.politicaCostes = _i.politicaCostes_.politica;			
	} else if (caso == "DL5") {
		oParam.politicaCostes = _i.politicaCostes_.politica;
	} else if (caso == "DL6") {
		oParam.politicaCostes = _i.politicaCostes_.politica;
	} else if (caso == "DL7") {
		oParam.politicaCostes = "No encontrada";
	} else if (caso == "DL8") {
		oParam.politicaCostes =_i.politicaCostes_.politica;
	}

	cursor.setValueBuffer("em_estadocostes",oParam.estadoCostes);
	cursor.setValueBuffer("em_politicacostes",oParam.politicaCostes);
	cursor.setValueBuffer("em_motivocostes",oParam.motivoCostes);
}

function euromoda_dameImporteLQ(cursor)
{
	var _i = this.iface;
	//es la suma de cantidadlinea*precionetoq
	
	var oDatosTabla = _i.dameDatosTabla(cursor);
	var id = oDatosTabla.id;
	var tablaLineas = oDatosTabla.tablaLineas;		
	//var importeLQ = AQUtil.sqlSelect(tablaLineas,"SUM(cantidad*em_precionetoq)",id + " = " + cursor.valueBuffer(id));
	var importeLQ = cursor.valueBuffer("neto");
	if(!importeLQ || importeLQ == "") {
		importeLQ = 0;
	}
	var recargoFinanciero = _i.commonCalculateField("lblRecFinanciero", cursor);
	if(!recargoFinanciero || recargoFinanciero == "") {
		recargoFinanciero = 0;
	}
	importeLQ = parseFloat(importeLQ) + parseFloat(recargoFinanciero);
	var tasaConv = cursor.valueBuffer("tasaconv");
	if(!tasaConv || tasaConv == "") {
		tasaConv = 1;
	}
	importeLQ = parseFloat(importeLQ) * parseFloat(tasaConv);

	importeLQ = AQUtil.roundFieldValue(importeLQ,"lineaspresupuestoscli","pvptotal"); //21-01-2019

	return importeLQ;	
}

function euromoda_dameImporteLCostes(cursor)
{
	var _i = this.iface;
	//es la suma de cantidadlinea*precionetoq	
	var oDatosTabla = _i.dameDatosTabla(cursor);
	var id = oDatosTabla.id;
	var tablaLineas = oDatosTabla.tablaLineas;	
	var campo = oDatosTabla.campo;
	var importeLCostes = AQUtil.sqlSelect(tablaLineas,campo,id + " = " + cursor.valueBuffer(id));
	if(!importeLCostes || importeLCostes == "") {
		importeLCostes = 0;
	}

	importeLCostes = AQUtil.roundFieldValue(importeLCostes,"lineaspresupuestoscli","pvptotal"); //21-01-2019

	return importeLCostes;
}

function euromoda_dameImporteLCostesMargen(cursor)
{
	var _i = this.iface;
	//es la suma de cantidadlinea*precionetoq	
	var oDatosTabla = _i.dameDatosTabla(cursor);
	var id = oDatosTabla.id;
	var tablaLineas = oDatosTabla.tablaLineas;	
	var campoMargen = oDatosTabla.campoMargen;
	var importeLCostesMargen = AQUtil.sqlSelect(tablaLineas,campoMargen,id + " = " + cursor.valueBuffer(id));
	if(!importeLCostesMargen || importeLCostesMargen == "") {
		importeLCostesMargen = 0;
	}
	//importeLCostesMargen = AQUtil.roundFieldValue(importeLCostesMargen,"lineaspresupuestoscli","pvptotal"); //21-01-2019
	//redondeamos en la consulta directamente
	
	return importeLCostesMargen;
}

function euromoda_dameLineasNoSuperado(cursor)
{
	var _i = this.iface;			
	var oDatosTabla = _i.dameDatosTabla(cursor);
	var id = oDatosTabla.id;
	var tablaLineas = oDatosTabla.tablaLineas;
	var aLineas = [];
	var q = new AQSqlQuery;	
	q.setSelect("numlinea");
	q.setFrom(tablaLineas);
	q.setWhere(id + " = " + cursor.valueBuffer(id) + " AND em_estadocostes = 'NO SUPERADO' ORDER BY numlinea"); 	
	if (!q.exec()){
		return;
	}  
	while(q.next())
	{
		aLineas.push(q.value("numlinea"));
	}	
	return aLineas;

}

function euromoda_avisarDocumento(oParam)
{
	//PROCESO7
	var _i = this.iface;

	if(_i.ignorarAvisosCostes_) {
		return true;
	}

	var titulo1,titulo2,mensaje;
	//debug("resevaluar: "+oParam.resEvaluar);
	titulo1 = "ATENCI�N: Art�culos por debajo de precios costes de producci�n.";
	if(oParam.resEvaluar == "PD.5.5" || oParam.resEvaluar == "PD.5.10" || oParam.resEvaluar == "PD.5.14") {
		titulo2 ="El documento contiene art�culos con precios+descuentos (l�nea y/o cabecera) por debajo de m�nimos.\nRevise precios y descuentos aplicados.";		
		mensaje = oParam.lineasNoSuperado.length+" art�culos afectados.\nL�NEAS:"+oParam.lineasMal;
	} else if(oParam.resEvaluar == "PD.5.8") {
		titulo2 = "";
		mensaje = "El importe global del documento est� por debajo de costes de producci�n.\nReviste precios y descuentos aplicados.";
	} else if(oParam.resEvaluar == "PD.5.13") {
		titulo1 = "ATENCI�N: Art�culos por debajo de precios costes + m�rgenes de producci�n.";
		titulo2 = "";
		mensaje = "El importe global del documento est� por debajo de costes + m�rgenes de producci�n.\nReviste precios y descuentos aplicados.";
	}

	var f = new FLFormSearchDB("em_preguntamsg");
  	var curC = f.cursor();
  	curC.setModeAccess(curC.Insert);
  	curC.refreshBuffer();
  	curC.setValueBuffer("titulo1",titulo1);  
  	curC.setValueBuffer("titulo2",titulo2);  
  	curC.setValueBuffer("mensaje",mensaje);  
  	f.setMainWidget();
   	f.exec();
  	if (!f.accepted()) {   		
        return false;
    }
    return true;

}

function euromoda_tbnEmRegenerarCostes_clicked() 
{
	var _i = this.iface;
	var cursor = this.cursor();	
	var autorizado = cursor.valueBuffer("em_autorizadocostes");
	//Permite regenerar los costes y m�rgenes de as l�neas. Esto supone borrar los actuales y volver a cargar sin dar avisos.
	var curLineas =  this.child("tdbLineasPresupuestosCli").cursor();
	_i.actualizaCostes(cursor, curLineas, true);
    this.child("tdbLineasPresupuestosCli").refresh();
}

function euromoda_tbnEmCargarCostes_clicked() 
{
	
	var _i = this.iface;
	var cursor = this.cursor();
	//Permite regenerar los costes y m�rgenes de as l�neas que est�n vacios.
	var curLineas =  this.child("tdbLineasPresupuestosCli").cursor();
	_i.actualizaCostes(cursor,curLineas,false);
    this.child("tdbLineasPresupuestosCli").refresh();

}

function euromoda_actualizaCostes(cursor,curLineas,forzar)
{
	var _i = this.iface;
	var tabla = cursor.table();
	var oDatosTabla = _i.dameDatosTabla(cursor);		
	var oParamLin = new Object;
	oParamLin.cursor = curLineas;
	oParamLin.ignorarAvisos = true;
	oParamLin.forzarReg = forzar;
	oParamLin.ignorarCalculoInsert = false; 



	curLineas.select(oDatosTabla.id + " = " + cursor.valueBuffer(oDatosTabla.id) + " AND tipoconcepto = 'Producto'");
	while (curLineas.next()) {
		curLineas.setModeAccess(curLineas.Edit);
		curLineas.refreshBuffer();

		formRecordlineaspresupuestoscli.iface.pub_evaluarCostes(oParamLin);
		if(!curLineas.commitBuffer()) {
			return false;
		}
    }	

}

function euromoda_dameDatosTabla(cursor)
{
	var _i = this.iface;
	var tabla = cursor.table();	
	var oDatosTabla = new Object;
	if(tabla == "presupuestoscli") {
		oDatosTabla.id = "idpresupuesto";	
		oDatosTabla.tablaLineas = "lineaspresupuestoscli";		
		oDatosTabla.campo = "SUM(cantidad*em_costeprod)";
		//oDatosTabla.campoMargen = "SUM(cantidad*(em_costeprod*(1+(em_margenprod/100))))"; 24-01-2019
		oDatosTabla.campoMargen = "SUM(cantidad*round(CAST(em_costeprod*(1+(em_margenprod/100)) as numeric),2))";
	} else if(tabla == "pedidoscli") {
		oDatosTabla.id = "idpedido";	
		oDatosTabla.tablaLineas = "lineaspedidoscli";	
		oDatosTabla.campo = "SUM(cantidad*em_costeprod)";
		//oDatosTabla.campoMargen = "SUM(cantidad*(em_costeprod*(1+(em_margenprod/100))))";	24-01-2019
		oDatosTabla.campoMargen = "SUM(cantidad*round(CAST(em_costeprod*(1+(em_margenprod/100)) as numeric),2))";
	} else if(tabla == "albaranescli") {
		oDatosTabla.id = "idalbaran";	
		oDatosTabla.tablaLineas = "lineasalbaranescli";	
		oDatosTabla.campo = "SUM(canfactura*em_costeprod)";	
		//oDatosTabla.campoMargen = "SUM(canfactura*(em_costeprod*(1+(em_margenprod/100))))"; 24-01-2019
		oDatosTabla.campoMargen = "SUM(canfactura*round(CAST(em_costeprod*(1+(em_margenprod/100)) as numeric),2))";
	} else if(tabla == "facturascli") {
		oDatosTabla.id = "idfactura";	
		oDatosTabla.tablaLineas = "lineasfacturascli";		
		oDatosTabla.campo = "SUM(cantidad*em_costeprod)";
		//oDatosTabla.campoMargen = "SUM(cantidad*(em_costeprod*(1+(em_margenprod/100))))";	24-01-2019
		oDatosTabla.campoMargen = "SUM(cantidad*round(CAST(em_costeprod*(1+(em_margenprod/100)) as numeric),2))";	
	}
	return oDatosTabla;
}

function euromoda_ponPoliticaCostes(tabla, codCliente)
{
	var _i = this.iface;
	_i.politicaCostes_ = new Object;
	if(tabla == "presupuestoscli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicaprescli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapoliprescli");
	} else if (tabla == "pedidoscli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicapedcli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapolipedcli");

	} else if (tabla == "albaranescli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicaalbcli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapolialbcli");

	} else if (tabla == "facturascli") {
		_i.politicaCostes_.politica = flfacturac.iface.pub_valorDefecto("em_politicafaccli");
 		_i.politicaCostes_.fecha = flfacturac.iface.pub_valorDefecto("em_dfechapolifaccli");
	}
	if(codCliente && codCliente != "") {
		var noEvaluarMargenCli = AQUtil.sqlSelect("clientes","em_noevaluarmargencli","codcliente = '" + codCliente + "'");
		if(noEvaluarMargenCli) {
			_i.politicaCostes_.evaluarMargen = false;
			_i.politicaCostes_.avisoMargen = false;
		} else {
			_i.politicaCostes_.evaluarMargen = flfacturac.iface.pub_valorDefecto("em_evaluarmargen");
			_i.politicaCostes_.avisoMargen = flfacturac.iface.pub_valorDefecto("em_avisomargen");			
		}
	} else {
		_i.politicaCostes_.evaluarMargen = flfacturac.iface.pub_valorDefecto("em_evaluarmargen");
		_i.politicaCostes_.avisoMargen = flfacturac.iface.pub_valorDefecto("em_avisomargen");		
	}
	_i.politicaCostes_.aprobarCostesMar = flfacturac.iface.pub_valorDefecto("em_aprdoccostesmar");
	_i.politicaCostes_.aprobarCostes = flfacturac.iface.pub_valorDefecto("em_aprdoccostes");
}

function euromoda_pbnImportarCSV_clicked()
{
	var _i = this.iface;
	var cursor = this.cursor();

	if (cursor.modeAccess() == cursor.Insert) {
		if (!this.child("tdbLineasPresupuestosCli").cursor().commitBufferCursorRelation())
			return false;
	}	
	if(!formRecordpedidoscli.iface.importarDatosCSV(cursor)){
		return false;
	}
	_i.calcularTotales();
	this.child("tdbLineasPresupuestosCli").refresh();	
	return true;

}

//// EUROMODA ////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

