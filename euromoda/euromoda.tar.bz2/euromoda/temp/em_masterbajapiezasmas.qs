/***************************************************************************
                 em_masterbajapiezasmas.qs  -  description
                             -------------------
    begin                : lun sep 3 2018
    copyright            : (C) 2018 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
    var ctx:Object;
    function interna( context ) { this.ctx = context; }
    function init() { this.ctx.interna_init(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); }
	function imprimir(idBaja) {
		return this.ctx.oficial_imprimir(idBaja);
	}
	function dameParamInforme() {
		return this.ctx.oficial_dameParamInforme();
	}	
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
    function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
    function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////


/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
/** \C El Al copiar un art�culo se copian tambi�n sus tarifas y sus precios por proveedor.
\end */
function interna_init()
{
	var _i = this.iface;	
	connect(this.child("toolButtonPrint"), "clicked()", _i, "imprimir");
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////


function oficial_imprimir(idBaja) 
{
	var _i = this.iface;
	var cursor = this.cursor();
	var estadoBaja = "";

	var _i = this.iface;
	if (sys.isLoadedModule("flfactinfo")) {
		var codigo;
		if (idBaja) {
			codigo = idBaja;
		} else {
			if (!cursor.isValid()){
				return;
			}
			codigo = cursor.valueBuffer("idbaja");
		}	

		var oParam = _i.dameParamInforme();
		if (!oParam) {
			return;
		}

		var curImprimir = new FLSqlCursor("em_i_bajapiezasmas");
		curImprimir.setModeAccess(curImprimir.Insert);
		curImprimir.refreshBuffer();
		curImprimir.setValueBuffer("descripcion", "temp");
		curImprimir.setValueBuffer("d_em__bajapiezasmas_idbaja", codigo);
	 	curImprimir.setValueBuffer("h_em__bajapiezasmas_idbaja", codigo);


		var dialog = new Dialog;
		dialog.caption = "Impresi�n por estado";
		dialog.okButtonText = "Imprimir"
		dialog.cancelButtonText = "Cancelar";

		var texto = new Label;
		texto.text = sys.translate("scripts", "Seleccione el estado de la baja");
		dialog.add( texto );

		var bgroup = new GroupBox;
		dialog.add(bgroup);

		var todo = new RadioButton;
		todo.text = "Todo";
		todo.checked = true;
		bgroup.add(todo);

		var estPendientes = new RadioButton;
		estPendientes.text = "Pendientes";
		bgroup.add(estPendientes);

		var estHechos = new RadioButton;
		estHechos.text = "Hechos";
		bgroup.add(estHechos);

		var estNoPosibles = new RadioButton;
		estNoPosibles.text = "No posibles";
		bgroup.add(estNoPosibles);

		if(! dialog.exec() ) {
			return false;
		}

		if(estNoPosibles.checked){
			estadoBaja = "NO POSIBLE";
		}else if(estHechos.checked){
			estadoBaja = "HECHO";
		}else if(estPendientes.checked){
			estadoBaja = "PTE";
		}
debug("estadoBaja : " + estadoBaja);		
		if(estadoBaja && estadoBaja != ""){
			curImprimir.setValueBuffer("estado", estadoBaja);
			if(oParam.whereFijo && oParam.whereFijo != ""){
				oParam.whereFijo += "AND em_lineasbajapiezasmas.estado = '" + estadoBaja + "'";
			}else{
				oParam.whereFijo = "em_lineasbajapiezasmas.estado = '" + estadoBaja + "'";
			}
		}else {
			curImprimir.setNull("estado");
		}
		flfactinfo.iface.pub_lanzaInforme(curImprimir, oParam);	

	} else {
		flfactppal.iface.pub_msgNoDisponible("Informes");
	}		

	
}

function oficial_dameParamInforme()
{
	var _i = this.iface;
	var oParam = flfactinfo.iface.pub_dameParamInforme();
	oParam.nombreInforme = "em_i_bajapiezasmas";

	return oParam;
}
//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
//////////////////////////////////////////////////////