/***************************************************************************
                 em_i_estadisticascompra.qs  -  description
                             -------------------
    begin                : mar feb 13 2018
    copyright            : (C) 2012 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function calculateField(fN:String):String { return this.ctx.interna_calculateField(fN); }
	function validateForm() {
		return this.ctx.interna_validateForm();
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); } 
	function bufferChanged(fN:String) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function commonCalculateField(fN, cursor) {
		return this.ctx.oficial_commonCalculateField(fN, cursor);
	}
	function iniciarControles()	{
		return this.ctx.oficial_iniciarControles();
	}/*
	function cargaAgentes() {
		this.ctx.oficial_cargaAgentes();
	}
	function guardaAgentes() {
		return this.ctx.oficial_guardaAgentes();
	}
	function chkAgentesSel_clicked() {
		return this.ctx.oficial_chkAgentesSel_clicked();
	}*/
	function cargaSeries() {
		this.ctx.oficial_cargaSeries();
	}
	function guardaSeries() {
		return this.ctx.oficial_guardaSeries();
	}
	function chkSeriesSel_clicked() {
		return this.ctx.oficial_chkSeriesSel_clicked();
	}	
	function establecerFiltroSubfamilia() {
		return this.ctx.oficial_establecerFiltroSubfamilia();
	}
	function establecerFiltroDibujos() {
		return this.ctx.oficial_establecerFiltroDibujos();
	}
	function establecerFiltroTamano() {
		return this.ctx.oficial_establecerFiltroTamano();
	}
	function establecerFiltroColores() {
		return this.ctx.oficial_establecerFiltroColores();
	}
	function establecerFiltroRefProveedor() {
		return this.ctx.oficial_establecerFiltroRefProveedor();
	}
	function filtrarTipoTercero() {
		return this.ctx.oficial_filtrarTipoTercero();
	}
	function filtrarSectorTercero() {
		return this.ctx.oficial_filtrarSectorTercero();
	}
	function filtrarCategoriaTercero() {
		return this.ctx.oficial_filtrarCategoriaTercero();
	}
	function filtrarSubcategoriaTercero() {
		return this.ctx.oficial_filtrarSubcategoriaTercero();
	}
	function tbnLimpiarFiltro_clicked() {
	  	return this.ctx.oficial_tbnLimpiarFiltro_clicked();
	}
	function limpiarFiltro(form) {
	  	return this.ctx.oficial_limpiarFiltro(form);
	}
		
	/*
	function informaCodProveedor(cursor) {
		return this.ctx.oficial_informaCodProveedor(cursor);
	}*/
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
  	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  	var _i = this.iface;
  	var cursor = this.cursor()
  	this.child("tbwCriterios").setTabEnabled("agentes", false);
  	connect(cursor, "bufferChanged(QString)", _i, "bufferChanged");
  	connect(this.child("tbnLimpiarFiltro"), "clicked()", _i, "tbnLimpiarFiltro_clicked");
	//connect(this.child("chkAgentesSel"), "clicked()", _i, "chkAgentesSel_clicked");
	connect(this.child("chkSeriesSel"), "clicked()", _i, "chkSeriesSel_clicked");
	_i.iniciarControles();
	//_i.cargaAgentes();
	_i.cargaSeries();
	//_i.chkAgentesSel_clicked();
	_i.chkSeriesSel_clicked();
}

function interna_validateForm()
{
	var _i = this.iface;
  	var cursor = this.cursor()
  	/*
  	if (!_i.guardaAgentes()) {
		MessageBox.warning(sys.translate("Error al guardar la lista de agentes"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}*/
  	if (!_i.guardaSeries()) {
		MessageBox.warning(sys.translate("Error al guardar la lista de series"), MessageBox.Ok, MessageBox.NoButton, MessageBox.NoButton, "AbanQ");
		return false;
	}
	return true;
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;

	switch (fN) {
		
		default: {
			valor = _i.commonCalculateField(fN, cursor);
			break;
		}
	}

	return valor;
}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_bufferChanged(fN:String)
{
	var _i = this.iface;
  	var cursor = this.cursor(); 
  
  	switch(fN){
    /** \C Si cambia el intervalo se recalculan las fechas.
    \end */
	    case "codintervalo":{
			var intervalo:Array = [];
			if(cursor.valueBuffer("codintervalo")){
				intervalo = flfactppal.iface.pub_calcularIntervalo(cursor.valueBuffer("codintervalo"));
				cursor.setValueBuffer("d_cab_fecha", intervalo.desde);
				cursor.setValueBuffer("h_cab_fecha", intervalo.hasta);
			}
			break;
	    }
	    case "codfamilia":{
			_i.establecerFiltroSubfamilia();
			break;
	    }
	    case "codsubfamilia":{
			_i.establecerFiltroDibujos();
			_i.establecerFiltroTamano();
			break;
	    }
	    case "coddibestamp":{
	    	_i.establecerFiltroSubfamilia();
			_i.establecerFiltroColores();
			_i.establecerFiltroTamano();
			break;
	    }
	    case "codproveedor":{
			_i.establecerFiltroRefProveedor();
			break;
	    }

	    case "codtipotercero":{
			_i.filtrarSectorTercero();
			_i.filtrarCategoriaTercero();
			_i.filtrarSubcategoriaTercero();
			break;
	    }
	    case "codsectortercero":{
			_i.filtrarTipoTercero();
			_i.filtrarCategoriaTercero();
			_i.filtrarSubcategoriaTercero();			
			break;
	    }
	    case "codcattercero":{
	    	_i.filtrarTipoTercero();
			_i.filtrarSectorTercero();
			_i.filtrarSubcategoriaTercero();			
			break;
	    }
	    case "codsubcattercero":{
	    	_i.filtrarTipoTercero();
			_i.filtrarSectorTercero();
			_i.filtrarCategoriaTercero();			
			break;
	    }			     	     
  	}

}

function oficial_iniciarControles()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	_i.establecerFiltroDibujos();
	_i.establecerFiltroSubfamilia();
	_i.establecerFiltroTamano();
	_i.establecerFiltroColores();
	_i.establecerFiltroRefProveedor();

	_i.filtrarTipoTercero();
	_i.filtrarSectorTercero();
	_i.filtrarCategoriaTercero();
	_i.filtrarSubcategoriaTercero();		
	
}
function oficial_commonCalculateField(fN, cursor)
{
	var _i = this.iface;
  	var valor = "";
  	switch (fN) {
  		default:{
  			break;
  		}  		
	}
	
	return valor;
}

function oficial_establecerFiltroSubfamilia() 
{
  	var cursor = this.cursor();
	var filtro = "";
	var codDibujo = cursor.valueBuffer("coddibestamp");
	var codFamilia = cursor.valueBuffer("codfamilia");
	if (codFamilia) {
		filtro = "codfamilia = '" + codFamilia + "'";
	}
	if (codDibujo) {
		filtro += filtro != "" ? " AND " : "";
		filtro += ("codsubfamilia IN (SELECT codsubfamilia FROM em_dibujossubfam WHERE coddibujoem = " + codDibujo + ")");
	}
	this.child("fdbSubfamilia").setFilter(filtro);
}

function oficial_establecerFiltroDibujos()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtro = "";
	var codSubfamilia = cursor.valueBuffer("codsubfamilia")
	if(codSubfamilia && codSubfamilia != ""){
		filtro = "coddibujoem IN (SELECT coddibujoem FROM em_dibujossubfam WHERE codsubfamilia = '" + codSubfamilia + "')";				
	} 
	this.child("fdbDibujo").setFilter(filtro);
  
}

function oficial_establecerFiltroTamano()
{
	var _i = this.iface;
  	var cursor = this.cursor();
  	var codSubfamilia = cursor.valueBuffer("codsubfamilia");
	var codDibujo = cursor.valueBuffer("coddibestamp");
	var filtro = "";
	if (codSubfamilia && codDibujo) {
		filtro = "codtamanoem IN (SELECT codtamanoem FROM em_dibujostamsub WHERE codsubfamilia = '" + codSubfamilia + "' AND coddibujoem = " + codDibujo + ")";
	} else if (codSubfamilia) {
		filtro = "codtamanoem IN (SELECT codtamanoem FROM em_tamanossubfam WHERE codsubfamilia = '" + codSubfamilia + "')";
	} else {
		filtro = "";
	}
	this.child("fdbTamano").setFilter(filtro);
}

function oficial_establecerFiltroColores()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtro = "";
	var codDibujo = cursor.valueBuffer("coddibestamp");
	if(codDibujo && codDibujo != ""){
		filtro = "codcolorem IN (SELECT codcolorem FROM em_dibujoscolor WHERE coddibujoem = '" + codDibujo + "')";				
	} 
	this.child("fdbColor").setFilter(filtro);	
}

function oficial_establecerFiltroRefProveedor()
{
	var _i = this.iface;
	var cursor = this.cursor();
	var filtro = "";
	var codProveedor = cursor.valueBuffer("codproveedor");
	if(codProveedor && codProveedor != ""){
		filtro = "codproveedor = '" + codProveedor + "' AND refproveedor IS NOT NULL";				
	} 
	this.child("fdbRefProveedor").setFilter(filtro);	

}

function oficial_filtrarTipoTercero()
{
	var _i = this.iface;
	var filtro = "";

	var sector = this.child("fdbCodSectorTercero").value();
	if(sector && sector != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}

		filtro += "codtipotercero in (select codtipotercero from sectoresterceros where codsectortercero = '" + sector + "')";
	}

	var cat = this.child("fdbCodCatTercero").value();
	if(cat && cat != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}
		filtro += "codtipotercero in (select codtipotercero from sectoresterceros where codsectortercero IN (select codsectortercero from categoriasterceros where codcattercero = '" + cat + "'))";
	}

	var subCat = this.child("fdbCodSubCatTercero").value();
	if(subCat && subCat != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}
		filtro += "codtipotercero in (select codtipotercero from sectoresterceros where codsectortercero IN (select codsectortercero from categoriasterceros where codcattercero IN (select codcattercero from subcategoriasterceros where codsubcattercero = '" + subCat + "')))";
	}

	this.child("fdbCodTipoTercero").setFilter(filtro);
}

function oficial_filtrarSectorTercero()
{
	var _i = this.iface;
	var filtro = "";

	var tipo = this.child("fdbCodTipoTercero").value();
	if(tipo && tipo != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		} 

		filtro += "codtipotercero = '" + tipo + "'";
	}

	var cat = this.child("fdbCodCatTercero").value();
	if(cat && cat != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}

		filtro += "codsectortercero in (select codsectortercero from categoriasterceros where codcattercero = '" + cat + "')";
	}

	var subCat = this.child("fdbCodSubCatTercero").value();
	if(subCat && subCat != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}

		filtro += "codsectortercero in (select codsectortercero from categoriasterceros where codcattercero IN (select codcattercero from subcategoriasterceros where codsubcattercero = '" + subCat + "'))";
	}

	this.child("fdbCodSectorTercero").setFilter(filtro);
}

function oficial_filtrarCategoriaTercero()
{
	var _i = this.iface;	
	var filtro = "";

	var sector = this.child("fdbCodSectorTercero").value();
	if(sector && sector != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}

		filtro += "codsectortercero = '" + sector + "'";
	}

	var tipo = this.child("fdbCodTipoTercero").value();
	if(tipo && tipo != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		} 

		filtro += "codsectortercero IN (select codsectortercero from  sectoresterceros where codtipotercero = '" + tipo + "')";
	}

	var subCat = this.child("fdbCodSubCatTercero").value();
	if(subCat && subCat != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}
		filtro += "codcattercero in (select codcattercero from subcategoriasterceros where codsubcattercero = '" + subCat + "')";
	}

debug("filtro " + filtro);
	this.child("fdbCodCatTercero").setFilter(filtro);
}

function oficial_filtrarSubcategoriaTercero()
{
	var _i = this.iface;	
	var filtro = "";

	var cat = this.child("fdbCodCatTercero").value();
	if(cat && cat != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}

		filtro += "codcattercero = '" + cat + "'";
	}

	var sector = this.child("fdbCodSectorTercero").value();
	if(sector && sector != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		}

		filtro += "codcattercero in (select codcattercero from categoriasterceros  where codsectortercero = '" + sector + "')";
	}

	var tipo = this.child("fdbCodTipoTercero").value();
	if(tipo && tipo != "") {
		if(filtro && filtro != "") {
			filtro += " AND ";
		} 

		filtro += "codcattercero in (select codcattercero from categoriasterceros  where codsectortercero IN (select codsectortercero from sectoresterceros where codtipotercero = '" + tipo + "'))";
	}

	this.child("fdbCodSubCatTercero").setFilter(filtro);
}

function oficial_tbnLimpiarFiltro_clicked()
{
	var _i = this.iface;
	_i.limpiarFiltro(this);
}

function oficial_limpiarFiltro(miForm)
{
	var cursor = miForm.cursor();
	var campos = "fdbIntervalo,fdbDescIntervalo,fdbFechaDesde,fdbFechaHasta,fdbReferencia,fdbDescReferencia,fdbFamilia,fdbDescFamilia,fdbSubfamilia,fdbDescSubfamilia,fdbColeccion,fdbDescColeccion,fdbDibujos,fdbDibujo,fdbDescDibujo,fdbRefComponente,fdbDesComponente,fdbTamano,fdbColor,fdbDescatalogado,fdbDeBaja,fdbaLiquidar,fdbNecesidad,fdbCodProveedor,fdbNombreCliente,fdbRefProveedor,fdbDescRefProv,fdbCodTipoTercero,fdbDescTipoTercero,fdbCodSectorTercero,fdbDescSectorTercero,fdbCodCatTercero,fdbDescCatTercero,fdbCodSubCatTercero,fdbDescSubCatTercero,fdbClasificacion,fdbCodEvalTercero,fdbDescEvalTercero,fdbEvaluacion,fdbDesdeFechaUltEval,fdbHastaFechaUltEval";
	var aCampos = campos.split(",");
	for (var i = 0; i < aCampos.length; i++) {
		sys.setObjText(miForm, aCampos[i], "");
	}
	cursor.setNull("d_cab_fecha");
	cursor.setNull("h_cab_fecha");
	cursor.setNull("desde_fechaulteval");
	cursor.setNull("hasta_fechaulteval");
	
	cursor.setNull("coddibestamp");
	cursor.setValueBuffer("descatalogado", "Todos");
	cursor.setValueBuffer("debaja", "Todos");
	cursor.setValueBuffer("aliquidar", "Todos");
	cursor.setValueBuffer("clasificacion", "Sin valor");

	debug("dibujo " + cursor.valueBuffer("coddibestamp"));
}

/*
function oficial_informaCodProveedor(cursor)
{
	var _i = this.iface;
	var codProveedor = AQUtil.sqlSelect("ariculosprov", "codproveedor", "refproveedor = '" + cursor.valueBuffer("refproveedor") + "'");
debug("informaCodProveedor_codProveedor: " + codProveedor);	
	if(codProveedor){
		this.child("fdbCodProveedor").setValue(codProveedor);
	}
	return true;
}*/
/*function oficial_chkAgentesSel_clicked()
{
	var _i = this.iface;
	var filtro;
	if (this.child("chkAgentesSel").checked) {
		var aAgentes = this.child("tdbAgentes").primarysKeysChecked();
		filtro = "1 = 2";
		if (aAgentes) {
			filtro = "codagente IN ('" + aAgentes.join("', '") + "')";
		}
	} else {
		filtro = "";
	}
	this.child("tdbAgentes").setFilter(filtro);
	this.child("tdbAgentes").refresh();
}*/

function oficial_chkSeriesSel_clicked()
{
	var _i = this.iface;
	var filtro;
	if (this.child("chkSeriesSel").checked) {
		var aSeries = this.child("tdbSeries").primarysKeysChecked();
		filtro = "1 = 2";
		if (aSeries) {
			filtro = "codserie IN ('" + aSeries.join("', '") + "')";
		}
	} else {
		filtro = "";
	}
	this.child("tdbSeries").setFilter(filtro);
	this.child("tdbSeries").refresh();
}
/*
function oficial_cargaAgentes()
{
	var _i = this.iface;
  	var cursor = this.cursor()

	var listaAgentes = cursor.valueBuffer("listaagentes");
	if (!listaAgentes || listaAgentes == "") {
		return;
	}
	var aAgentes = listaAgentes.split(",");
	for (var a = 0; a < aAgentes.length; a++) {
		this.child("tdbAgentes").setPrimaryKeyChecked(aAgentes[a], true);
	}
}*/

function oficial_cargaSeries()
{
	var _i = this.iface;
  	var cursor = this.cursor()

	var listaSeries = cursor.valueBuffer("listaseries");
	if (!listaSeries || listaSeries == "") {
		return;
	}
	var aSeries = listaSeries.split(",");
	for (var a = 0; a < aSeries.length; a++) {
		this.child("tdbSeries").setPrimaryKeyChecked(aSeries[a], true);
	}
}
/*
function oficial_guardaAgentes()
{
	var _i = this.iface;
  	var cursor = this.cursor()
  
 	var aAgentes = this.child("tdbAgentes").primarysKeysChecked();
	if (aAgentes) {
		cursor.setValueBuffer("listaagentes", aAgentes.join(","));
	} else {
		cursor.setNull("listaagentes");
	}
	return true;
}*/

function oficial_guardaSeries()
{
	var _i = this.iface;
  	var cursor = this.cursor()
  
  	var aSeries = this.child("tdbSeries").primarysKeysChecked();
	if (aSeries) {
		cursor.setValueBuffer("listaseries", aSeries.join(","));
	} else {
		cursor.setNull("listaseries");
	}
	return true;
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
