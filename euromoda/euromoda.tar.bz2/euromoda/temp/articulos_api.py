# -*- coding: utf-8 -*-
# Translated with pineboolib v0.45.3
from typing import TYPE_CHECKING, Any
from pineboolib.qsa import qsa
import re
# Articulos = qsa.class_("articulos")


# @class_declaration Base */
class Base(qsa.FormDBWidget):
    pass


# @class_declaration Oficial */
class Oficial(Base):

    def get(self, params, username=None):
        mapa = self.get_mapa()
        obj = qsa.from_project("formAPI").get_resources('articulos', params, mapa, username)
        return obj


    def ubicar_prenda_actual(self, pk, params, username=None):
        ## solucion error this connection is closed??
        session = qsa.thread_session_new()
        session.begin()
        #session = qsa.session_atomic()
        #if session.transaction is None:
        #    session.begin()
        ##
        referencia_articulo = pk
        nueva_ubicacion = params["nueva_ubicacion"]
        self.comprobar_formato_ubicacion(nueva_ubicacion)
        existe_emubicaciones = qsa.FLUtil.sqlSelect("em_ubicaciones", "em_codubicacion", "em_codubicacion = '" + nueva_ubicacion + "'")
        if not existe_emubicaciones:
            self.insertar_ubicacion(nueva_ubicacion)
        
        Em_articulosxubicacion = qsa.orm_("em_articulosxubicacion") #ponemos todas las ubicaciones con actual = false
        ubicaciones = Em_articulosxubicacion.query().filter(Em_articulosxubicacion.referencia == referencia_articulo)
        for ubicacion in ubicaciones:
            ubicacion.actual = False
            ubicacion.save()

        existe_articulosxubicacion = qsa.FLUtil.sqlSelect("em_articulosxubicacion", "id", "em_ubialternativa = '" + nueva_ubicacion + "' AND referencia = '" + referencia_articulo + "'")
        if not existe_articulosxubicacion:
            articuloxubicacion = Em_articulosxubicacion()
            articuloxubicacion.em_ubialternativa = nueva_ubicacion
            articuloxubicacion.referencia = referencia_articulo
            articuloxubicacion.actual = True
            articuloxubicacion.save()
        else:
            articuloxubicacion = Em_articulosxubicacion.get(existe_articulosxubicacion)
            articuloxubicacion.actual = True
            articuloxubicacion.save()
        
        # actualizamos la tabla articulos 
        Articulo = qsa.orm_("articulos")
        articulo = Articulo.get(referencia_articulo)
        articulo.em_ubiactual = nueva_ubicacion
        articulo.save()

        session.commit()
        return True

    def ubicar_prenda_alternativa(self, pk, params, username=None):
        ## solucion error this connection is closed??
        session = qsa.thread_session_new()
        session.begin()
        #session = qsa.session_atomic()
        #if session.transaction is None:
        #    session.begin()
        ##
        referencia_articulo = pk
        nueva_ubicacion = params["nueva_ubicacion"]
        self.comprobar_formato_ubicacion(nueva_ubicacion)
        existe_emubicaciones = qsa.FLUtil.sqlSelect("em_ubicaciones", "em_codubicacion", "em_codubicacion = '" + nueva_ubicacion + "'")
        if not existe_emubicaciones:
            self.insertar_ubicacion(nueva_ubicacion)

        existe_articulosxubicacion = qsa.FLUtil.sqlSelect("em_articulosxubicacion", "id", "em_ubialternativa = '" + nueva_ubicacion + "' AND referencia = '" + referencia_articulo + "'")
        if not existe_articulosxubicacion:
            Em_articulosxubicacion = qsa.orm_("em_articulosxubicacion")
            articuloxubicacion = Em_articulosxubicacion()
            articuloxubicacion.em_ubialternativa = nueva_ubicacion
            articuloxubicacion.referencia = referencia_articulo
            articuloxubicacion.actual = False
            articuloxubicacion.save()

        session.commit()
        return True

    def desubicar_actual(self, pk, params, username=None):
        referencia_articulo = pk
        ubicacion_actual = params["ubicacion_actual"]
        self.comprobar_formato_ubicacion(ubicacion_actual)
        Articulo = qsa.orm_("articulos")
        articulo = Articulo.get(referencia_articulo)
        articulo.em_ubiactual = None
        articulo.save()
        # actualizamos em_articulosxubicacion para poner esa ubicacion a False
        Em_articulosxubicacion = qsa.orm_("em_articulosxubicacion")
        articuloxubicacion = Em_articulosxubicacion.query().filter(Em_articulosxubicacion.referencia == referencia_articulo)\
            .filter(Em_articulosxubicacion.em_ubialternativa == ubicacion_actual)
        for ubicacion in articuloxubicacion:
            ubicacion.actual = False
            ubicacion.save()
        return True

    def desubicar_alternativa(self, pk, params, username=None):
        #referencia_articulo = pk
        id_ubicacion = params["id_ubicacion"]
        Em_articulosxubicacion = qsa.orm_("em_articulosxubicacion")
        articuloxubicacion = Em_articulosxubicacion.get(id_ubicacion)
        articuloxubicacion.delete()
        return True

    @staticmethod
    def insertar_ubicacion(ubicacion):
        zonas = ubicacion.split('-')
        nave = int(zonas[0][1:]) # par evitar problemas ejemplo: N01-P1-E1-A1 seria igual a N1-P1-E1-A1
        pasillo = int(zonas[1][1:])
        estante = int(zonas[2][1:])
        altura = int(zonas[3][1:])
        #print('ubicacion', ubicacion, 'nave', nave, 'altura', altura, 'pasillo', pasillo, 'estante', estante)
        Em_Ubicaciones = qsa.orm_("em_ubicaciones")
        em_ubicacion = Em_Ubicaciones()
        em_ubicacion.em_ubipasillo = pasillo
        em_ubicacion.em_ubiestante = estante
        em_ubicacion.em_ubinave = nave
        em_ubicacion.em_ubialtura = altura
        em_ubicacion.em_codubicacion = ubicacion
        em_ubicacion.save()

    @staticmethod
    def comprobar_formato_ubicacion(text):
        if re.match("^N[0-9]{1,2}-P[0-9]{1,2}-E[0-9]{1,2}-A[0-9]{1,2}$", text) is None:
            raise Exception('Ubicacion no tiene el formato aceptado.')
        
    def get_mapa(self):
        return {
            'join': 'articulos',
            'order': 'descripcion',
            'map': {
                'referencia': {'field': 'articulos.referencia', 'type': 'string'},
                'descripcion': {'field': 'articulos.descripcion', 'type': 'string'}
            }
        }


# @class_declaration FormInternalObj */
class FormInternalObj(Oficial):
    pass


if TYPE_CHECKING:
    form: FormInternalObj = FormInternalObj()
    iface = form.iface
else:
    form = None
