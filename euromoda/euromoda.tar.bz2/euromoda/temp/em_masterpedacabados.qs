var form = this;
/***************************************************************************
                 em_masterpedacabados.qs  -  description
                             -------------------
    begin                : jue jun 20 2013
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna
{
  var ctx;
  function interna(context)
  {
    this.ctx = context;
  }
  function init()
  {
    this.ctx.interna_init();
  }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna
{
  function oficial(context)
  {
    interna(context);
  }
  function cargaCombo()
  {
    return this.ctx.oficial_cargaCombo();
  }
  function filtroPpal()
  {
    return this.ctx.oficial_filtroPpal();
  }
  function tbnEstadoAcabado_clicked()
  {
    return this.ctx.oficial_tbnEstadoAcabado_clicked();
  }
	  function tbnSinEstadoAcabado_clicked()
  {
    return this.ctx.oficial_tbnSinEstadoAcabado_clicked();
  }
	  function chkSoloEstActual_clicked()
  {
    return this.ctx.oficial_chkSoloEstActual_clicked();
  }
	  /*function cbEstadoAcabado_activated()
  {
    return this.ctx.oficial_cbEstadoAcabado_activated();
  }*/
	  function filtra()
  {
    return this.ctx.oficial_filtra();
  }
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial
{
  function head(context)
  {
    oficial(context);
  }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head
{
  function ifaceCtx(context)
  {
    head(context);
  }
}

const iface = new ifaceCtx(this);
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();

  connect(this.child("tbnEstadoAcabado"), "clicked()", _i, "tbnEstadoAcabado_clicked");
  connect(this.child("tbnSinEstadoAcabado"), "clicked()", _i, "tbnSinEstadoAcabado_clicked");
	connect(this.child("chkSoloEstActual"), "clicked()", _i, "chkSoloEstActual_clicked");
	//connect(this.child("cbEstadoAcabado"), "activated(QString)", _i, "cbEstadoAcabado_activated");
	
  _i.cargaCombo();
  _i.filtroPpal();

}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_filtroPpal()
{
  var _i = this.iface;
  var cursor = this.cursor();
    
  var proveedores = flfactppal.iface.pub_valorDefectoEmpresa("proveedoresventanasacabados");
  if (!proveedores) {
    sys.warnMsgBox(sys.translate("No tiene definido los proveedores de acabados en el formulario de empresa"));
    return;
  }
  
  var aProv = proveedores.split(",");
  proveedores = "'" + aProv.join("','") + "'";
  
  var f = "codproveedor IN (" + proveedores + ") AND servido IN ('No', 'Parcial')";
	
  cursor.setMainFilter(f);
}

function oficial_filtra()
{
	var _i = this.iface;
	var cursor = this.cursor();
	
	var f = "1 = 1";
	if (this.child("chkSoloEstActual").checked) {
		var estado = this.child("cbEstadoAcabado").currentText;
		f = "em_estadoacabado = '" + estado + "'";
	}
	this.child("tableDBRecords").setFilter(f);
	this.child("tableDBRecords").refresh();
}


function oficial_tbnEstadoAcabado_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  var idPedido = cursor.valueBuffer("idpedido");
  if (!idPedido) {
    return false;
  }
  var estado = this.child("cbEstadoAcabado").currentText;
  cursor.setModeAccess(cursor.Edit);
  cursor.refreshBuffer();
  cursor.setValueBuffer("em_estadoacabado", estado);
  if (!cursor.commitBuffer()) {
    return false;
  }
	return true;
}


function oficial_tbnSinEstadoAcabado_clicked()
{
  var _i = this.iface;
  var cursor = this.cursor();

  var idPedido = cursor.valueBuffer("idpedido");
  if (!idPedido) {
    return false;
  }
  cursor.setModeAccess(cursor.Edit);
  cursor.refreshBuffer();
  cursor.setNull("em_estadoacabado");
  if (!cursor.commitBuffer()) {
    return false;
  }
	return true;
}

function oficial_chkSoloEstActual_clicked()
{
	var _i = this.iface;
	
	_i.filtra();
}

/*function oficial_cbEstadoAcabado_activated()
{
	var _i = this.iface;
	
	_i.filtra();
}*/

function oficial_cargaCombo()
{

  var _i = this.iface;
  
  var curEstados = new FLSqlCursor("em_estadospedacabado");
  curEstados.select("1=1");
  var arrayEstados = [];
  var i = 0;
  while (curEstados.next()) {
    curEstados.setModeAccess(curEstados.Browse);
    curEstados.refreshBuffer();
    debug("i: " + i);
    arrayEstados[i] = curEstados.valueBuffer("codestado");
    debug("Estado: " + arrayEstados[i]);
    i++;
  }
  this.child("cbEstadoAcabado").clear();
  this.child("cbEstadoAcabado").insertStringList(arrayEstados);

  return true;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
