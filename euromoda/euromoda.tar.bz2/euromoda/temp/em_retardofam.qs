/***************************************************************************
                 em_retardofam.qs  -  description
                             -------------------
    begin                : mar abr 25 2017
    copyright            : (C) 2017 by YeboYebo S.L.U.
    email                : mail@yeboyebo.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx:Object;
	function interna( context ) { this.ctx = context; }
	function init() { this.ctx.interna_init(); }
	function validateForm():Boolean { return this.ctx.interna_validateForm(); }
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {
	function oficial( context ) { interna( context ); } 
	function filtrarAcabados() {
		return this.ctx.oficial_filtrarAcabados();
	}
	function dameFiltroAcabadosFam() {
		return this.ctx.oficial_dameFiltroAcabadosFam();
	} 
	function validaAcabados() {
		return this.ctx.oficial_validaAcabados();
	}
	function validaAlias() {
		return this.ctx.oficial_validaAlias();
	}	
	function validaRetardos() {
		return this.ctx.oficial_validaRetardos();
	}
	function dameFiltroAliasFam() {
		return this.ctx.oficial_dameFiltroAliasFam();
	}

}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
	function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  var _i = this.iface;
  var cursor = this.cursor();

  _i.filtrarAcabados();  
 
}

function interna_validateForm()
{
	var _i = this.iface;

	if(!_i.validaAcabados()) {
		return false;
	}
	if(!_i.validaAlias()) {
		return false;
	}
	if(!_i.validaRetardos()) {
		return false;
	}
	return true;
}

//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////

function oficial_filtrarAcabados()
{
	var _i = this.iface;


	var filtroAcabadosFam = _i.dameFiltroAcabadosFam();	
	this.child("fdbAcabadoInicial").setFilter(filtroAcabadosFam);
	this.child("fdbAcabadoFinal").setFilter(filtroAcabadosFam);

	var filtroAliasFam = _i.dameFiltroAliasFam();	
	this.child("fdbTipTejidoInicial").setFilter(filtroAliasFam);
	this.child("fdbTipTejidoFinal").setFilter(filtroAliasFam);
}

function oficial_dameFiltroAcabadosFam()
{
	var _i = this.iface;
	var filtro = "1=2"
	var cursor = this.cursor();
	var codFamFiltro = cursor.valueBuffer("codfamilia");
	
	var codFamilia = AQUtil.sqlSelect("familias","codfamilia", "codfamilia = '" + codFamFiltro + "'");

	if(codFamilia && codFamilia != "") {
		filtro = "codfamilia = '" + codFamilia + "'";
	}
	return filtro;
}

function oficial_dameFiltroAliasFam()
{
	var _i = this.iface;
	var filtro = "1=2"
	var cursor = this.cursor();
	var codFamFiltro = cursor.valueBuffer("codfamilia");
	if(codFamFiltro && codFamFiltro != "") {
	 	filtro = "alias IN (SELECT em_alias FROM subfamilias WHERE codfamilia = '" + codFamFiltro + "')";
	}
	return filtro;
}

function oficial_validaAcabados()
{
	var cursor = this.cursor();

	var codFamilia = cursor.valueBuffer("codfamilia");
	var acabadoIni = cursor.valueBuffer("acabadoinicial");
	var acabadoFin = cursor.valueBuffer("acabadofinal"); 
	/*var codFamilia = AQUtil.sqlSelect("articulos","codfamilia", "referencia = '" + referencia + "'");*/

	var retardoAcabado  = cursor.valueBuffer("retardoacabado");

	if((!acabadoIni ||  acabadoIni == "") && (!acabadoFin ||  acabadoFin == "") && (!retardoAcabado || retardoAcabado == 0)) {
		return true;
	} 

	if(!acabadoIni ||  acabadoIni == "") {
		sys.warnMsgBox(sys.translate("El campo Acabado inicial es obligatorio si ha informado Acabado final o Retardo de acabado."));
		return false;
	}
	if(!acabadoFin ||  acabadoFin == "") {
		sys.warnMsgBox(sys.translate("El campo Acabado final es obligatorio si ha informado Acabado inicial o Retardo de acabado."));
		return false;
	}
	if(!retardoAcabado || retardoAcabado == 0) {
		sys.warnMsgBox(sys.translate("El campo Retardo acabado es obligatorio si ha informado Acabado inicial y Acabado final."));
		return false;
	}


	if(AQUtil.sqlSelect("em_retardomaquina","count(*)","acabadoinicial = '" + acabadoIni + "' and acabadofinal = '" + acabadoFin + "'")>0) {
		sys.warnMsgBox(sys.translate("Ya hay un registro con acabado inicial %1 y acabado final %2").arg(acabadoIni).arg(acabadoFin));
		return false;
	}
	/*----------------------------------------------------------------------------*/

	/*--------------------------------------------------------------------------------*/

	if(!AQUtil.sqlSelect("em_acabadosfam","acabado","codfamilia = '" + codFamilia +"' and acabado = '" + acabadoIni + "'")) {

		sys.warnMsgBox(sys.translate("El acabado inicial %1 no pertenece a la familia %2").arg(acabadoIni).arg(codFamilia));

		return false;
	}

	if(!AQUtil.sqlSelect("em_acabadosfam","acabado","codfamilia = '" + codFamilia +"' and acabado = '" + acabadoFin + "'")) {

		sys.warnMsgBox(sys.translate("El acabado final %1 no pertenece a la familia %2").arg(acabadoFin).arg(codFamilia));

		return false;
	}

	var id = cursor.valueBuffer("id");

	if(AQUtil.sqlSelect("em_retardofam","count(*)","acabadoinicial = '" + acabadoIni + "' and acabadofinal = '" + acabadoFin + "' and codfamilia = '" + codFamilia + "' and id <>  " + id )>0) {
		sys.warnMsgBox(sys.translate("Ya hay un registro con acabado inicial %1 y acabado final %2 para la familia %3").arg(acabadoIni).arg(acabadoFin).arg(codFamilia));
		return false;
	}

	return true;
}

function oficial_validaAlias()
{
	var cursor = this.cursor();

	var codFamilia = cursor.valueBuffer("codfamilia");
	var aliasIni = cursor.valueBuffer("tipotejidoinicial");
	var aliasFin = cursor.valueBuffer("tipotejidofinal"); 
	/*var codFamilia = AQUtil.sqlSelect("articulos","codfamilia", "referencia = '" + referencia + "'");*/
	var retardoTejido = cursor.valueBuffer("retardotipotejido");

	if((!aliasIni ||  aliasIni == "") && (!aliasFin ||  aliasFin == "") && (!retardoTejido || retardoTejido == 0)) {
		return true;
	} 

	if(!aliasIni ||  aliasIni == "") {
		sys.warnMsgBox(sys.translate("El campo Tejido inicial es obligatorio si ha informado Tejido final o Retardo de acabado."));
		return false;
	}
	if(!aliasFin ||  aliasFin == "") {
		sys.warnMsgBox(sys.translate("El campo Tejido final es obligatorio si ha informado Tejido inicial o Retardo de acabado."));
		return false;
	}
	if(!retardoTejido || retardoTejido == 0) {
		sys.warnMsgBox(sys.translate("El campo Retardo acabado es obligatorio si ha informado Tejido inicial y Tejido final."));
		return false;
	}



	/*-------------------------------------------------------------------------*/
	if(!AQUtil.sqlSelect("subfamilias","em_alias","codfamilia = '" + codFamilia +"' and em_alias = '" + aliasIni + "'")) {

		sys.warnMsgBox(sys.translate("El tipo tejido inicial %1 no pertenece a ninguna subfamilia de la familia %2").arg(aliasIni).arg(codFamilia));

		return false;
	}

	if(!AQUtil.sqlSelect("subfamilias","em_alias","codfamilia = '" + codFamilia +"' and em_alias = '" + aliasFin + "'")) {

		sys.warnMsgBox(sys.translate("El tipo tejido final %1 no pertenece a ninguna subfamilia de la familia %2").arg(aliasFin).arg(codFamilia));

		return false;
	}

	var id = cursor.valueBuffer("id");


	if(AQUtil.sqlSelect("em_retardofam","count(*)","tipotejidoinicial = '" + aliasIni + "' and tipotejidofinal = '" + aliasFin + "' and codfamilia = '" + codFamilia + "' and id <>  " + id )>0) {
		sys.warnMsgBox(sys.translate("Ya hay un registro con tipo tejido inicial %1 y tipo tejido final %2 para la familia %3").arg(aliasIni).arg(aliasFin).arg(codFamilia));
		return false;
	}
	return true;
}

function oficial_validaRetardos()
{
	var cursor = this.cursor();
	var codFamilia = cursor.valueBuffer("codfamilia");
	var id = cursor.valueBuffer("id");
	var retardoAnverso = cursor.valueBuffer("retardoanverso");
	var retardoReverso = cursor.valueBuffer("retardoreverso");


	if(retardoAnverso && retardoAnverso != 0) {

		if(AQUtil.sqlSelect("em_retardofam","count(*)","codfamilia = '" + codFamilia + "' and retardoanverso <>0 and id <>  " + id )>0 ) {
			sys.warnMsgBox(sys.translate("Ya hay un registro con retardo anverso informado para la familia %1").arg(codFamilia));
			return false;
		}
	}

	if(retardoReverso && retardoReverso != 0) {

		if(AQUtil.sqlSelect("em_retardofam","count(*)","codfamilia = '" + codFamilia + "' and retardoreverso <>0 and id <>  " + id )>0) {
			sys.warnMsgBox(sys.translate("Ya hay un registro con retardo reverso informado para la familia %1").arg(codFamilia));
			return false;
		}
	}

	return true;
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
