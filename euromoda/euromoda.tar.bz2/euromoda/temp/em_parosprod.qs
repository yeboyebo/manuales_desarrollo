/***************************************************************************
                 em_parosprdo.qs  -  description
                             -------------------
    begin                : vie may 19 2017
    copyright            : (C) 2013 by InfoSiAL S.L.
    email                : mail@infosial.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/** @file */

/** @class_declaration interna */
////////////////////////////////////////////////////////////////////////////
//// DECLARACION ///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
class interna {
	var ctx;
	function interna( context ) { this.ctx = context; }
	function init() {
		this.ctx.interna_init();
	}
	function validateForm() { 
		return this.ctx.interna_validateForm(); 
	}
}
//// INTERNA /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
class oficial extends interna {

	var tiempParo_;
	var factorMaximo_;
	var existeTipoParo_;
	var existeOperario_;
	function oficial( context ) { interna( context ); }
	function iniciaLabels() {
		return this.ctx.oficial_iniciaLabels();
	}
	function bufferChanged(fN:String) {
		return this.ctx.oficial_bufferChanged(fN);
	}
	function tiempoXFac(){
		return this.ctx.oficial_tiempoXFac();
	}
	function calculateField(fN:String):Number {
		return this.ctx.interna_calculateField(fN);
	}
	function formatearTiempo(s){
		return this.ctx.oficial_formatearTiempo(s);
	}
	function calculaTiempoFin() {
		return this.ctx.oficial_calculaTiempoFin();
	}
}
//// OFICIAL /////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

/** @class_declaration head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////
class head extends oficial {
	function head( context ) { oficial ( context ); }
}
//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_declaration ifaceCtx */
/////////////////////////////////////////////////////////////////
//// INTERFACE  /////////////////////////////////////////////////
class ifaceCtx extends head {
  function ifaceCtx( context ) { head( context ); }
}

const iface = new ifaceCtx( this );
//// INTERFACE  /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition interna */
////////////////////////////////////////////////////////////////////////////
//// DEFINICION ////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//// INTERNA /////////////////////////////////////////////////////
function interna_init()
{
  	var _i = this.iface;
  	_i.tiempParo_ = 0;
  	_i.existeTipoParo_ = false;
  	_i.existeOperario_=false;
  	var cursor = this.cursor();
  
  	_i.iniciaLabels();

  	connect(cursor, "bufferChanged(QString)", this, "iface.bufferChanged");

  	if(this.child("pushButtonAccept")) {
  		this.child("pushButtonAccept").close();	
  		connect(this.child("tbnAceptar"), "clicked()", this.child("pushButtonAccept"), "animateClick()");
  	}
	if(this.child("pushButtonCancel")) {
		this.child("pushButtonCancel").close();	
		connect(this.child("tbnCancelar"), "clicked()", this.child("pushButtonCancel"), "animateClick()");
	}
	

	_i.iniciaLabels();

	//muestro formato d�as h m s
	//base
	var segBase = cursor.valueBuffer("tiempoparobase");
	this.child("labelConversorTBase").setText(_i.formatearTiempo(segBase));
	//real
	var segReal = parseInt(cursor.valueBuffer("tiempoparoreal"));
	this.child("labelConversorTReal").setText(_i.formatearTiempo(segReal));

	
	
}
function interna_validateForm(){
	var cursor = this.cursor();
	var _i = this.iface;
	//var nomOperari = String(cursor.valueBuffer("fdbDescripcionOperario"));
	debug("/////////////////_i.existeOperario_=:"+_i.existeOperario_+"  _i.existeTipoParo_"+_i.existeTipoParo_);
	if(!_i.existeOperario_){
		sys.warnMsgBox(sys.translate("Debe de haber un trabajador."));
		return false;
	}
	if(!_i.existeTipoParo_){
		sys.warnMsgBox(sys.translate("Debe de haber un tipo de paro."));
		return false;
	}else{
		//valido fechas y hora que la final no sea menor a la inicial
		var fechaIni = cursor.valueBuffer("fechainicioparo");
		var fechaFin = cursor.valueBuffer("fechafinparo");
		if(fechaIni>fechaFin){
			sys.warnMsgBox(sys.translate("La fecha final no puede ser menor que la fecha inicio."));
			return false;
		}else{
			//miro fechas y horas 
			var horaIni = cursor.valueBuffer("horainicioparo");
			var horaFin = cursor.valueBuffer("horafinparo");
			if(horaIni>horaFin && fechaIni==fechaFin){
				sys.warnMsgBox(sys.translate("La hora final no puede ser menor que la hora inicio."));
				return false;
			}
		}

		//valido que tenga tipo paro base y tiempo paro real
		var tiempoparoBase = cursor.valueBuffer("tiempoparobase");
		if(tiempoparoBase<=0){
			sys.warnMsgBox(sys.translate("Debe de haber un tiempo de paro base."));
			return false;
		}
		var tiempoparoReal = cursor.valueBuffer("tiempoparoreal");
		if(tiempoparoReal<=0){
			sys.warnMsgBox(sys.translate("Debe de haber un tiempo de paro real."));
			return false;
		}
			
	}


	return true;
		

}
//// INTERNA /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition oficial */
//////////////////////////////////////////////////////////////////
//// OFICIAL /////////////////////////////////////////////////////
function oficial_iniciaLabels() 
{
	var _i = this.iface;
	var cursor = this.cursor();
  	this.child("fdbCodMaqCol").setDisabled(true);
  	this.child("fdbTiempoParBase").setDisabled(true);
  	this.child("fdbLotesProd").setDisabled(true);
  	this.child("fdbCodOrden").setDisabled(true);
  	this.child("fdbTiempoParoReal").setDisabled(true);

}

function oficial_bufferChanged(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	debug("////////////fN:"+fN);
	switch (fN) {
		case "tipoparo": {		
			
			var tipoPar = cursor.valueBuffer("tipoparo");
			debug("////////////tipoPar:"+tipoPar);
			//this.child("fdbSueldoNeto").setValue(valor);
			//tabla, campo que quiero cojer, consulta where000000000000000000
				var qh=new AQSqlQuery;
				qh.setSelect("tiempoparo, factormaximo");
				qh.setFrom("em_tiposparomaq");
				qh.setWhere("tipoparo = '" + tipoPar +"'");
				if(qh.exec()){
					if(qh.next()){
						_i.tiempParo_ = parseFloat(qh.value("tiempoparo"));
						_i.factorMaximo_ = parseFloat(qh.value("factormaximo"));
								
						debug("////////tiempParo:"+_i.tiempParo_+"  factorMaximo:"+_i.factorMaximo_);

						_i.tiempoXFac();
						_i.existeTipoParo_=true;
					}else{
						_i.existeTipoParo_=false;
						this.child("fdbTiempoParBase").setValue(0);
					}
					
				}else{
					_i.existeTipoParo_=false;
					this.child("fdbTiempoParBase").setValue(0);
				}
				


			break;
		}
		case "codmaquinacol":{
				var cpdm = cursor.valueBuffer("codmaquinacol");
  				debug("////cpdm:"+cpdm);
  				var filtroSeccion = "codmaquinacol = '"+cpdm+"'"
  				debug("///////////filtro:"+filtroSeccion);
  				this.child("fdbTipoParo").setFilter(filtroSeccion);
			break;
		}
		case "factor":{
				var fact = parseFloat(cursor.valueBuffer("factor"));
				if(fact>=0 && _i.factorMaximo_>=0){
					_i.tiempoXFac();
				}
				if(fact<0){
					this.child("fdbFactor").setValue(0);
				}
			
			break;
		}
		case "idtrabajador":{
				var idtrabajador = cursor.valueBuffer("idtrabajador");
				var qh=new AQSqlQuery;
				qh.setSelect("count(*)");
				qh.setFrom("pr_trabajadores");
				qh.setWhere("idtrabajador = '" + idtrabajador +"'");
				if(qh.exec()){
					qh.next();
					debug("/////////"+qh.value("count(*)")+"  idtrabajador"+idtrabajador);
					if(qh.value("count(*)")==1){
						_i.existeOperario_=true;
					}else{
						_i.existeOperario_=false;
					}
				}
				break;
		}
		case "fechainicioparo":{
			if (cursor.valueBuffer(fN) && cursor.valueBuffer(fN) != "") {
				_i.calculaTiempoFin();// this.child("fdbTiempoParoReal").setValue(_i.calculateField("minutos"));
			}
			break;
		}
		case "horainicioparo":{
			if (cursor.valueBuffer(fN) && cursor.valueBuffer(fN) != "") {
				_i.calculaTiempoFin();//this.child("fdbTiempoParoReal").setValue(_i.calculateField("minutos"));
			}
			break;
		}
		case "fechafinparo":{
			if (cursor.valueBuffer(fN) && cursor.valueBuffer(fN) != "") {
				this.child("fdbTiempoParoReal").setValue(_i.calculateField("minutos"));
			}
			break;
		}
		case "horafinparo":{ 
			if (cursor.valueBuffer(fN) && cursor.valueBuffer(fN) != "") {
				this.child("fdbTiempoParoReal").setValue(_i.calculateField("minutos"));
			}
			break;
		}
		case "tiempoparobase":{
			debug("///////// entro en case tiempoparobase");
			var s = cursor.valueBuffer("tiempoparobase");
			debug("/////////////tiempo1:"+_i.formatearTiempo(s));
			this.child("labelConversorTBase").setText(_i.formatearTiempo(s));
			_i.calculaTiempoFin();
			break;
		}
		case "tiempoparoreal":{
			debug("///////// entro en case tiempoparoreal");
			var s = parseInt(cursor.valueBuffer("tiempoparoreal"));
			debug("/////////////tiempo2:"+_i.formatearTiempo(s));
			this.child("labelConversorTReal").setText(_i.formatearTiempo(s));
			break;
		}
		
		
	}
}

function interna_calculateField(fN)
{
	var _i = this.iface;
	var cursor = this.cursor();
	var valor;
	switch (fN) {
		case "minutos": {	
		debug("Fecha inicio " + cursor.valueBuffer("fechainicioparo"));
		debug("Parse " + Date.parse(cursor.valueBuffer("fechainicioparo")));
			var fechaIni = cursor.valueBuffer("fechainicioparo");
			var fechaFin = cursor.valueBuffer("fechafinparo");
			var horaIni = cursor.valueBuffer("horainicioparo");
			var horaFin = cursor.valueBuffer("horafinparo");
			if (!fechaIni || !fechaFin || !horaIni || !horaFin || fechaIni == "" || fechaFin == "" || horaIni == "" || horaFin == "" ) {
				valor = 0;
				break;
			}
			fechaIni = new Date(Date.parse(fechaIni.toString().left(10)+horaIni.toString().right(9)));
			fechaFin = new Date(Date.parse(fechaFin.toString().left(10)+horaFin.toString().right(9)));
			fechaIni = fechaIni.getTime();
			fechaFin = fechaFin.getTime();
			//fechaIni y fechaFin estan en milisegundos 1s/1000s.
			var segundosFechaResta = (fechaFin - fechaIni)/1000; 
			debug("///////////fechaIni:"+fechaIni+" fechaFin:"+fechaFin+"  resta="+segundosFechaResta);
   			/*valor = (fechaFin - fechaIni)/60000;   
   			
   			valor = parseInt(valor);
   			if(valor<0){
   				valor=0;
   			}*/
   			valor = Math.round(segundosFechaResta);
   			if (valor < 0) {
   				valor = 0;
   			}
			break;
		}
		
	}
	return valor;
}
function oficial_tiempoXFac(){
	var _i = this.iface;
	var cursor = this.cursor();
	var fact = parseFloat(cursor.valueBuffer("factor"));
	//_i.tiempParo_ _i.factorMaximo_;
	debug("////////fact:"+fact);

	if(_i.factorMaximo_ >= fact){
		debug("///////////fact:"+fact+" tiempoparo:"+_i.tiempParo_);
		this.child("fdbTiempoParBase").setValue(fact*parseFloat(_i.tiempParo_));
	return true;
	}else{
		sys.warnMsgBox(sys.translate("Factor debe de ser menor que el factor m�ximo de tipos de paro por m�quina."));
		this.child("fdbFactor").setValue(0);
		this.child("fdbTiempoParBase").setValue(0);
	}
	
		
	
	
	return false;

}
function oficial_formatearTiempo(s)
{
	var dias = Math.floor(s / 86400);
	s -= dias * 86400; 
	var h = Math.floor(s / 3600);
	s -= h * 3600;
	var m = Math.floor(s / 60);
	s -= m * 60;

	return sys.translate("%1 d�as, %2 horas %3 minutos %4 segundos").arg(dias).arg(h).arg(m).arg(s);
		
} 

function oficial_calculaTiempoFin()
{
	var _i = this.iface;
	var cursor = this.cursor();

	var fechaIni = cursor.valueBuffer("fechainicioparo");
	var horaIni = cursor.valueBuffer("horainicioparo");
	if (!fechaIni || !horaIni || fechaIni == "" || horaIni == "") {
		return;
	}
//debug("Parseando " + fechaIni.toString().left(10) + "T" + horaIni.toString().right(8));
	var dIni = new Date(Date.parse(fechaIni.toString().left(10) + "T" + horaIni.toString().right(8)));
//debug("Fecha ini " + dIni.toString());
	var t0 = cursor.valueBuffer("tiempoparobase");
	if (!t0) {
		t0 = 0;
	}
	var dFin = new Date(dIni.getTime() + (t0 * 1000));
//debug("Fecha dFin " + dFin.toString());
	this.child("fdbFechaFinPar").setValue(dFin.toString().left(10));
	this.child("fdbHoraFinPar").setValue(dFin.toString().right(8));
	//cursor.setValueBuffer("fechafin", dFin.toString());
	//cursor.setValueBuffer("horafin", dFin.toString());
}

//// OFICIAL /////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

/** @class_definition head */
/////////////////////////////////////////////////////////////////
//// DESARROLLO /////////////////////////////////////////////////

//// DESARROLLO /////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////